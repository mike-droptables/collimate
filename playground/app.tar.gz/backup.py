"""Bundle-library I/O for the ``.collimatebackup`` folder.

``.collimatebackup`` is a CWD-relative sibling of ``.collimate`` (genesis.py
``BACKUP_DIR``) holding reusable bundle files:

  * ``.colgen``  — generator bundles  (collimate.packaging archive, v2)
  * ``.colrend`` — renderer bundles   (collimate.packaging archive, v2)
  * ``.colchan`` — channel / standard-cell archives (routes.system schema)

It is the source the native channel-creation picker seeds from, and the
backing store for the file-sync "Backup" surface. This module is pure folder
I/O + metadata reads; HTTP wrapping + wasm guards live in routes/backup.py.
"""
from __future__ import annotations

import os

from genesis import BACKUP_DIR

# The two files the SDK build refreshes on every install (see
# build/install_dev.sh). The create-channel picker pre-selects their cells.
DEFAULT_GENERATORS = "latest_sdk_generators.colgen"
DEFAULT_RENDERERS = "latest_sdk_renderers.colrend"
_DEFAULT_FILES = {DEFAULT_GENERATORS, DEFAULT_RENDERERS}

# extension ↔ bundle kind
_EXT_KIND = {".colgen": "generator", ".colrend": "renderer", ".colchan": "channel"}
_KIND_EXT = {"generator": ".colgen", "renderer": ".colrend", "channel": ".colchan"}


def backup_dir() -> str:
    """Return the backup dir, creating it if absent (idempotent — covers
    already-bootstrapped workspaces whose ``bootstrap()`` early-returned)."""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    return BACKUP_DIR


def _safe_filename(filename: str) -> str:
    """Validate a bundle filename: basename only (no path separators / parent
    traversal), no leading dot, a supported extension. Returns the basename."""
    base = os.path.basename(filename or "")
    if not base or base != filename or base.startswith("."):
        raise ValueError(f"invalid backup filename: {filename!r}")
    if os.path.splitext(base)[1].lower() not in _EXT_KIND:
        raise ValueError(f"unsupported backup extension: {filename!r}")
    return base


def bundle_path(filename: str) -> str:
    return os.path.join(backup_dir(), _safe_filename(filename))


def kind_for_extension(filename: str) -> str | None:
    return _EXT_KIND.get(os.path.splitext(filename)[1].lower())


def extension_for_kind(kind: str) -> str:
    try:
        return _KIND_EXT[kind]
    except KeyError:
        raise ValueError(f"unknown bundle kind: {kind!r}")


def _cells_from_package(raw: bytes) -> list[dict]:
    """Metadata-only cell list for a .colgen / .colrend bundle."""
    from collimate.packaging import inspect as pkg_inspect
    manifest = pkg_inspect(raw)
    return [{"id": c.id, "name": c.name, "summary": c.summary} for c in manifest.cells]


def _cells_from_colchan(raw: bytes) -> list[dict]:
    """Metadata-only cell list for a .colchan — flattens the standard
    main-view stacks (the cells the 'Starting cells' picker offers). Generator
    / renderer stacks are skipped (a colchan ships them separately)."""
    from routes.system import _parse_colchan
    manifest, _ = _parse_colchan(raw)
    out: list[dict] = []
    for stack in manifest.get("main_stacks", []):
        if stack.get("stack_type") in ("generator", "renderer"):
            continue
        for cell in stack.get("cells", []):
            out.append({
                "id": str(cell.get("id")),
                "name": cell.get("name") or "Cell",
                "summary": cell.get("summary") or "",
            })
    return out


def _read_cells(filename: str, raw: bytes) -> list[dict]:
    if kind_for_extension(filename) == "channel":
        return _cells_from_colchan(raw)
    return _cells_from_package(raw)


def list_bundles(kind: str | None = None) -> list[dict]:
    """List bundle files in the library, newest first. ``kind`` filters by
    type (generator|renderer|channel); None = all three. Each entry::

        {filename, kind, mtime, size, is_default,
         cells: [{id, name, summary}], error}

    A bundle that fails to parse yields ``error`` set + ``cells: []`` so one
    bad user file never breaks the listing."""
    if kind is not None and kind not in _KIND_EXT:
        raise ValueError(f"unknown bundle kind: {kind!r}")
    d = backup_dir()
    wanted_ext = _KIND_EXT.get(kind) if kind else None

    out: list[dict] = []
    for name in os.listdir(d):
        ext = os.path.splitext(name)[1].lower()
        if ext not in _EXT_KIND:
            continue  # skips .tmp from a crashed save and anything foreign
        if wanted_ext and ext != wanted_ext:
            continue
        path = os.path.join(d, name)
        try:
            st = os.stat(path)
        except OSError:
            continue
        if not os.path.isfile(path):
            continue
        entry: dict = {
            "filename": name,
            "kind": _EXT_KIND[ext],
            "mtime": st.st_mtime,
            "size": st.st_size,
            "is_default": name in _DEFAULT_FILES,
            "cells": [],
            "error": None,
        }
        try:
            with open(path, "rb") as fh:
                raw = fh.read()
            entry["cells"] = _read_cells(name, raw)
        except Exception as e:  # noqa: BLE001 — one bad file mustn't break the list
            entry["error"] = str(e)
        out.append(entry)

    out.sort(key=lambda e: e["mtime"], reverse=True)
    return out


def read_bundle_bytes(filename: str) -> bytes:
    """Raw bytes of a library file. Raises FileNotFoundError if absent
    (caller → 404), ValueError on a bad name (caller → 400)."""
    with open(bundle_path(filename), "rb") as fh:
        return fh.read()


def save_bytes(filename: str, content: bytes) -> dict:
    """Atomically write ``content`` to ``filename`` in the library, OVERWRITING
    any same-named file (others untouched). Returns {filename, mtime, size}."""
    path = bundle_path(filename)
    tmp = path + ".tmp"
    with open(tmp, "wb") as fh:
        fh.write(content)
    os.replace(tmp, path)
    st = os.stat(path)
    return {"filename": os.path.basename(path), "mtime": st.st_mtime, "size": st.st_size}


def delete_bundle(filename: str) -> None:
    try:
        os.remove(bundle_path(filename))
    except FileNotFoundError:
        pass
