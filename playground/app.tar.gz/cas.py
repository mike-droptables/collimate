"""
CAS (Content Addressable Storage) utilities.

Shared hash-and-store functions used by both ProcessManager (generator commits)
and the JIT draft flush (human edit DAG nodes).
"""

import hashlib
import os
import shutil


def hash_and_store_file(abs_path: str) -> str | None:
    """Hash a file and store it in the CAS. Returns the blob hash or None on error."""
    try:
        stat = os.stat(abs_path)
        if stat.st_size > 50 * 1024 * 1024:
            return None
    except OSError:
        return None

    sha256 = hashlib.sha256()
    try:
        with open(abs_path, "rb") as f:
            while chunk := f.read(65536):
                sha256.update(chunk)
    except OSError:
        return None

    blob_hash = sha256.hexdigest()
    _store_blob(blob_hash, lambda dst: shutil.copy2(abs_path, dst))
    return blob_hash


def hash_and_store_bytes(raw: bytes) -> str | None:
    """Hash raw bytes and store them in the CAS. Returns the blob hash or None on error."""
    if len(raw) > 50 * 1024 * 1024:
        return None

    blob_hash = hashlib.sha256(raw).hexdigest()
    _store_blob(blob_hash, lambda dst: _write_bytes(dst, raw))
    return blob_hash


def _store_blob(blob_hash: str, write_fn):
    """Atomically store a blob in the CAS if it doesn't already exist."""
    cas_dir = os.path.join(".collimate", "objects", blob_hash[:2])
    cas_path = os.path.join(cas_dir, blob_hash[2:])
    if not os.path.exists(cas_path):
        try:
            os.makedirs(cas_dir, exist_ok=True)
            tmp_path = cas_path + ".tmp"
            write_fn(tmp_path)
            os.replace(tmp_path, cas_path)
        except OSError:
            pass


def _write_bytes(path: str, raw: bytes):
    with open(path, "wb") as f:
        f.write(raw)
