"""Mark-and-sweep GC for the CAS blob store.

Soft-deleted cells release their cell_files refs but the blobs they
pointed at accumulate in ``.collimate/objects/`` indefinitely. On a
busy single-tenant install this is "the disk fills up after a few
months."

Two-phase, with a trash directory between sweep and final delete so a
botched mark phase doesn't permanently lose blobs:

  1. **Mark.** Walk every channel DB; collect every ``blob_hash`` from
     ``cell_files`` whose owning cell is not soft-deleted. The result
     is the live set.
  2. **Sweep.** Walk ``.collimate/objects/``; any blob whose hex name
     isn't in the live set moves to
     ``.collimate/objects.trash/<sweep_id>/``. Already-trashed blobs
     older than the grace period (24 h by default) get unlinked.

The 24-hour grace covers two important races:

  * **Pending-commit race.** A chat_session has hashed bytes into the
    CAS but hasn't yet inserted the cell_files row. The blob is
    referenceable but not yet referenced. Trash window protects it.
  * **Mark-phase bug.** A future change to the mark-set scan could miss
    a reference shape (e.g. a new draft table). Trash window keeps the
    data recoverable for a day before deletion.

The GC is *not* meant to run hot — once an hour during idle is
generous. The endpoint at ``/api/maintenance/gc`` is for explicit
operator triggers.
"""

from __future__ import annotations

import logging
import os
import shutil
import sqlite3
import time
import uuid
from typing import Iterable

from database import get_db_connection

logger = logging.getLogger(__name__)


CAS_DIR = os.path.join(".collimate", "objects")
TRASH_DIR = os.path.join(".collimate", "objects.trash")
DEFAULT_GRACE_SECONDS = 24 * 3600


def _channel_dbs() -> list[str]:
    """Return the list of channel slugs whose DB files exist on disk.

    Iterates files instead of in-memory state so the GC works even if
    state isn't loaded (e.g. during a lifespan-init failure recovery)."""
    channels_dir = os.path.join(".collimate", "channels")
    if not os.path.isdir(channels_dir):
        return []
    out: list[str] = []
    for fname in os.listdir(channels_dir):
        if fname.endswith(".db"):
            out.append(fname[:-3])
    return sorted(out)


def _live_blobs_in_channel(conn: sqlite3.Connection) -> set[str]:
    """Live blob hashes referenced by non-deleted cells in this channel.

    A cell whose ``deleted_at`` is non-NULL has been soft-deleted; its
    cell_files rows may already have been purged (see cell_cleanup.py),
    but in case the soft-delete handler didn't reach those rows for any
    reason, exclude them here too.

    Also includes any hash referenced by ``cell_drafts.blob_hash`` — a
    binary file (image, etc.) lives in the draft working tree by CAS
    reference *before* it's promoted into a versioned ``cell_files`` row.
    Without this, GC would trash a dropped-but-not-yet-checkpointed image
    out from under the pending draft.
    """
    rows = conn.execute("""
        SELECT DISTINCT cf.blob_hash
        FROM cell_files cf
        JOIN cells c ON c.id = cf.cell_id
        WHERE c.deleted_at IS NULL AND cf.blob_hash IS NOT NULL
    """).fetchall()
    live = {r["blob_hash"] for r in rows}
    draft_rows = conn.execute(
        "SELECT DISTINCT blob_hash FROM cell_drafts WHERE blob_hash IS NOT NULL"
    ).fetchall()
    live |= {r["blob_hash"] for r in draft_rows}
    return live


def collect_live_blobs() -> set[str]:
    """Walk every channel DB and union their live blob sets."""
    live: set[str] = set()
    for slug in _channel_dbs():
        try:
            conn = get_db_connection(slug)
            live |= _live_blobs_in_channel(conn)
            conn.close()
        except sqlite3.DatabaseError as exc:
            # A corrupt or in-flight channel DB shouldn't take the GC
            # down. Log and skip — better to leave that channel's blobs
            # alone than risk deleting a referenced one.
            logger.warning("GC: skipping channel %s due to DB error: %s", slug, exc)
    return live


def _iter_cas_blobs() -> Iterable[tuple[str, str]]:
    """Yield (full_path, hash) for every file under .collimate/objects/.

    Walks the two-character shard directories. Files whose names don't
    fit the expected sha256 hex shape are skipped — they can be partial
    .tmp uploads or files unrelated to the CAS layout.
    """
    if not os.path.isdir(CAS_DIR):
        return
    for shard in os.listdir(CAS_DIR):
        if shard.startswith(".") or len(shard) != 2:
            continue
        shard_dir = os.path.join(CAS_DIR, shard)
        if not os.path.isdir(shard_dir):
            continue
        for fname in os.listdir(shard_dir):
            full = os.path.join(shard_dir, fname)
            if not os.path.isfile(full):
                continue
            if fname.endswith(".tmp"):
                continue  # in-flight write; leave alone
            blob_hash = shard + fname
            if len(blob_hash) != 64:
                continue
            yield full, blob_hash


def _move_to_trash(src_path: str, sweep_id: str) -> str | None:
    """Move a blob to .collimate/objects.trash/<sweep_id>/ preserving
    the two-char shard layout. Returns the destination path on success
    or None if the move failed (the source survives — fine, GC retries
    next pass)."""
    rel = os.path.relpath(src_path, CAS_DIR)
    dst = os.path.join(TRASH_DIR, sweep_id, rel)
    try:
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.move(src_path, dst)
        return dst
    except OSError as exc:
        logger.warning("GC: failed to move %s to trash: %s", src_path, exc)
        return None


def _purge_expired_trash(grace_seconds: float) -> int:
    """Delete trash sweeps older than ``grace_seconds``. Returns count
    of removed sweep dirs (a sweep dir holds many blobs)."""
    if not os.path.isdir(TRASH_DIR):
        return 0
    cutoff = time.time() - grace_seconds
    removed = 0
    for entry in os.listdir(TRASH_DIR):
        sweep_dir = os.path.join(TRASH_DIR, entry)
        if not os.path.isdir(sweep_dir):
            continue
        try:
            mtime = os.path.getmtime(sweep_dir)
        except OSError:
            continue
        if mtime < cutoff:
            try:
                shutil.rmtree(sweep_dir)
                removed += 1
                logger.info("GC: purged expired trash sweep %s", entry)
            except OSError as exc:
                logger.warning("GC: failed to purge trash %s: %s", sweep_dir, exc)
    return removed


def run_gc(*, grace_seconds: float = DEFAULT_GRACE_SECONDS) -> dict:
    """Execute one mark-and-sweep cycle.

    Returns a status dict with counts so callers (the maintenance
    endpoint, the idle scheduler) can surface results::

        {
          "live": <int>,            # blobs the mark phase saw as referenced
          "swept": <int>,           # blobs moved to trash this pass
          "purged_sweeps": <int>,   # historical sweeps unlinked past grace
          "sweep_id": "<uuid>",
        }
    """
    sweep_id = uuid.uuid4().hex[:12]
    live = collect_live_blobs()
    swept = 0
    for full_path, blob_hash in list(_iter_cas_blobs()):
        if blob_hash in live:
            continue
        if _move_to_trash(full_path, sweep_id):
            swept += 1
    purged = _purge_expired_trash(grace_seconds)
    logger.info(
        "GC pass %s: live=%d swept=%d purged_sweeps=%d",
        sweep_id, len(live), swept, purged,
    )
    return {
        "sweep_id": sweep_id,
        "live": len(live),
        "swept": swept,
        "purged_sweeps": purged,
    }


def disk_usage() -> dict:
    """Return current CAS disk usage for /ready surface.

    Best-effort: an OSError walking the tree returns whatever was
    counted up to that point with an ``error`` field flagged."""
    # Counters are ints; an ``error`` / ``trash_error`` string may be
    # added on OSError, hence the loose value type.
    out: dict = {"blob_count": 0, "bytes": 0, "trash_bytes": 0}
    try:
        for full_path, _ in _iter_cas_blobs():
            try:
                out["bytes"] += os.path.getsize(full_path)
                out["blob_count"] += 1
            except OSError:
                continue
    except OSError as exc:
        out["error"] = str(exc)
    if os.path.isdir(TRASH_DIR):
        try:
            for dirpath, _dirnames, filenames in os.walk(TRASH_DIR):
                for fn in filenames:
                    try:
                        out["trash_bytes"] += os.path.getsize(os.path.join(dirpath, fn))
                    except OSError:
                        continue
        except OSError as exc:
            out["trash_error"] = str(exc)
    return out
