"""Soft-delete + blob refcount cleanup for cells.

User-initiated deletion of a Standard cell:
  1. Walk the cell's full version chain (forward via previous_version).
  2. Flag every cell in the chain with deleted_at = now.
  3. Gather all blob_hashes referenced by the chain's cell_files.
  4. For each blob, check whether any non-deleted cell still references
     it. If not, delete the CAS file and the blobs row.
  5. Purge cell_files rows for the deleted chain (dangling without blobs).

Cell rows themselves are kept — children may still hold input_N edges
pointing at a deleted parent (the input captured a specific version at
the child's creation time; that fact doesn't change when the parent is
later deleted). Queries that display cells must filter on
`deleted_at IS NULL`.
"""

import os


def _walk_chain_forward(conn, start_cell_id: str) -> list[str]:
    """Collect every cell id on the previous_version chain that starts at
    start_cell_id. Cycle-safe via a visited set.
    """
    chain: list[str] = [start_cell_id]
    visited: set[str] = {start_cell_id}
    current = start_cell_id
    while True:
        row = conn.execute(
            "SELECT child_cell_id FROM cell_edges "
            "WHERE parent_cell_id=? AND parent_key='previous_version' LIMIT 1",
            (current,),
        ).fetchone()
        if not row:
            break
        nxt = row[0]
        if nxt in visited:
            break
        visited.add(nxt)
        chain.append(nxt)
        current = nxt
    return chain


def soft_delete_cell(conn, cell_id: str) -> dict:
    """Soft-delete a cell and its version chain; cleanup unreferenced blobs.

    Returns a stats dict: {
      'chain_len': int,       # cells flagged
      'files_purged': int,    # cell_files rows removed
      'blobs_purged': int,    # blobs rows + CAS files removed
    }

    Caller is responsible for the outer transaction and commit.
    """
    chain = _walk_chain_forward(conn, cell_id)
    placeholders = ",".join("?" * len(chain))

    # Collect blob hashes referenced by the chain before we purge.
    blob_rows = conn.execute(
        f"SELECT DISTINCT blob_hash FROM cell_files "
        f"WHERE cell_id IN ({placeholders})",
        chain,
    ).fetchall()
    chain_blobs = [r[0] for r in blob_rows]

    # Flag the chain as deleted.
    conn.execute(
        f"UPDATE cells SET deleted_at=CURRENT_TIMESTAMP "
        f"WHERE id IN ({placeholders})",
        chain,
    )

    # Purge cell_files for the chain — the blobs may be gone shortly.
    files_cur = conn.execute(
        f"DELETE FROM cell_files WHERE cell_id IN ({placeholders})",
        chain,
    )
    files_purged = files_cur.rowcount if files_cur.rowcount is not None else 0

    # Refcount each blob against non-deleted cells. Any blob with zero
    # live references gets its CAS file and blobs row removed.
    blobs_purged = 0
    for blob_hash in chain_blobs:
        refcount_row = conn.execute(
            "SELECT 1 FROM cell_files cf JOIN cells c ON cf.cell_id=c.id "
            "WHERE cf.blob_hash=? AND c.deleted_at IS NULL LIMIT 1",
            (blob_hash,),
        ).fetchone()
        if refcount_row is not None:
            continue
        cas_path = os.path.join(
            ".collimate", "objects", blob_hash[:2], blob_hash[2:],
        )
        try:
            if os.path.exists(cas_path):
                os.remove(cas_path)
        except OSError:
            pass
        conn.execute("DELETE FROM blobs WHERE hash=?", (blob_hash,))
        blobs_purged += 1

    return {
        "chain_len": len(chain),
        "files_purged": files_purged,
        "blobs_purged": blobs_purged,
    }
