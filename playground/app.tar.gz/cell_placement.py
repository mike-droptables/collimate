"""Cell placement rules for new cells from runs and snapshots.

The portal-recursion rule:
- Each new cell from an action (a generator commit, or a snapshot button click)
  lands in a "target stack" tracked per run.
- The initial target is a brand new stack inserted immediately right of the
  source cell's stack.
- Each subsequent placement checks the current target's topmost cell. If that
  topmost cell is a portal (any file ends in `.website`, or its pinned
  ends in `.website`), the target advances by *inserting a brand new empty stack*
  immediately right of the current target. The advance never reuses an existing
  stack — it always creates a fresh one. This keeps the portal cell visible.
- The chosen target is returned to the caller, which inserts the new cell at
  index 0 (the top) and updates the per-run current_target_stack_id.
"""

from models import Cell, Stack, Channel, Placement


def is_portal_cell(cell: Cell) -> bool:
    """A cell is a portal if it shows a live web view as its summary.

    The website renderer interprets `.website` files as proxy URLs and renders
    them in a live iframe. A portal cell needs to stay visible so the iframe
    isn't covered by subsequent cells from the same run.

    `pinned` is checked first because it's semantically precise. If
    the manifest didn't declare one, the file-extension fallback catches it.
    """
    if cell.pinned and cell.pinned.endswith(".website"):
        return True
    return any(f.name.endswith(".website") for f in (cell.files or []))


def find_stack_containing_cell(channel: Channel, cell_id) -> Stack | None:
    """Look up which stack in main_stacks or nav_stacks contains the given cell."""
    cid = str(cell_id)
    for s in channel.main_stacks + channel.nav_stacks:
        for c in s.cells:
            if str(c.id) == cid:
                return s
    return None


def _stack_index(channel: Channel, stack_id) -> int | None:
    sid = str(stack_id) if stack_id is not None else None
    if sid is None:
        return None
    for i, s in enumerate(channel.main_stacks):
        if str(s.id) == sid:
            return i
    return None


def insert_new_stack_right_of(channel: Channel, ref_stack_id) -> Stack:
    """Insert a brand new empty stack immediately right of the referenced stack
    in main_stacks. Existing stacks at and beyond that index shift right.
    Returns the new Stack."""
    idx = _stack_index(channel, ref_stack_id)
    if idx is None:
        raise ValueError(f"reference stack {ref_stack_id} not found in main_stacks")
    new_stack = Stack(name="", cells=[])
    channel.main_stacks.insert(idx + 1, new_stack)
    return new_stack


def reserve_landing_stack_for_placement(
    channel: Channel,
    running_cell: Cell,
    source_stack_id,
) -> tuple[Stack, int]:
    """Pick the (stack, insert_index) for a new ``create``-output cell.

    Driven by the running cell's transient ``placement`` field (set
    when the cell started running, mutable via the log-slot toggle).
    Returns the stack to insert into and the index within that stack
    where the new cell should land.

    ``under`` (default): append to the running cell's stack, directly
    below the running cell.

    ``new_stack``: create a brand-new stack immediately right of the
    source stack and land the cell at the top (index 0).

    ``on_top``: prepend (index 0) to the stack immediately right of
    the source. If no neighbor exists, create one.
    """
    placement = running_cell.placement or Placement.UNDER

    if placement == Placement.UNDER:
        src = find_stack_containing_cell(channel, running_cell.id)
        if src is None:
            # Running cell isn't currently parented in any stack —
            # fall back to a fresh stack right of source.
            return insert_new_stack_right_of(channel, source_stack_id), 0
        # Insert directly below the running cell.
        try:
            running_idx = next(i for i, c in enumerate(src.cells) if str(c.id) == str(running_cell.id))
            return src, running_idx + 1
        except StopIteration:
            return src, len(src.cells)

    if placement == Placement.NEW_STACK:
        return insert_new_stack_right_of(channel, source_stack_id), 0

    if placement == Placement.ON_TOP:
        src_idx = _stack_index(channel, source_stack_id)
        if src_idx is None:
            return insert_new_stack_right_of(channel, source_stack_id), 0
        neighbor_idx = src_idx + 1
        if neighbor_idx >= len(channel.main_stacks):
            return insert_new_stack_right_of(channel, source_stack_id), 0
        return channel.main_stacks[neighbor_idx], 0

    # Defensive fallback — unknown enum value.
    return insert_new_stack_right_of(channel, source_stack_id), 0


def reserve_landing_stack(
    channel: Channel,
    source_stack_id,
    current_target_stack_id,
) -> Stack:
    """Apply the portal-recursion placement rule and return the stack to land in.

    - If `current_target_stack_id` is None or no longer present in the channel,
      insert a brand new stack right of `source_stack_id` and return it. (This
      handles the very first placement when no per-run target has been
      established yet, plus the recovery case where the previous target was
      deleted.)
    - Otherwise look up the current target. If its topmost cell is a portal,
      *insert* a brand new empty stack immediately right of the current target
      and return that. Otherwise return the current target unchanged.

    The advance always creates a new stack — it never reuses an existing
    sibling, even if that sibling already has a non-portal top.
    """
    cur_idx = _stack_index(channel, current_target_stack_id)
    if cur_idx is None:
        return insert_new_stack_right_of(channel, source_stack_id)

    cur_stack = channel.main_stacks[cur_idx]
    if cur_stack.cells and is_portal_cell(cur_stack.cells[0]):
        return insert_new_stack_right_of(channel, cur_stack.id)
    return cur_stack
