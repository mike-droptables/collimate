"""Single source of truth for what can cross a .colchan boundary.

Both the exporter (``routes/system.py::export_channel``) and the
importer (``routes/system.py::merge_channel_archive``) consult this
module so the two ends can't drift. The rule today:

  - Running cells never cross. A running cell is mid-flight state,
    not a stable artifact; its partially-emitted files would ship
    inconsistent snapshots.

  - Standard cells (including chat cells whose generator has
    finished) always cross.

The policy is exported as two boolean predicates so each side can
use the one that makes sense (exporter has a Cell object + a set
of running ids; importer has a raw manifest dict + nothing else).
Extending the policy in one place here makes regressions easy to
spot.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from models import Cell

# Cell states that refuse to cross the archive boundary. Currently
# empty — Draft was removed in the three-type rework; ``Picking`` is
# a client-only UI state that never hits the DB. Kept as a frozenset
# so future non-exportable states can be added without changing the
# predicates' shape.
NON_EXPORTABLE_STATES: frozenset[str] = frozenset()


def is_archive_exportable(cell: "Cell", running_ids: set[str]) -> bool:
    """True iff ``cell`` should be serialized into a .colchan archive.

    ``running_ids`` is typically built by the exporter from
    ``routes.runs.active_managers`` — cells whose placeholder_cell_id
    is attached to a live manager.
    """
    if str(cell.id) in running_ids:
        return False
    state_val = _cell_state_str(cell)
    if state_val in NON_EXPORTABLE_STATES:
        return False
    return True


def is_archive_importable(cell_dict: dict) -> bool:
    """True iff a cell entry in an incoming archive should be
    materialized into the destination channel. Defensive check
    against hand-crafted archives that might include states the
    exporter would have filtered.
    """
    state_val = cell_dict.get("state")
    if state_val in NON_EXPORTABLE_STATES:
        return False
    return True


def _cell_state_str(cell: "Cell") -> str:
    state = getattr(cell, "state", None)
    if state is None:
        return "Standard"
    return state.value if hasattr(state, "value") else str(state)
