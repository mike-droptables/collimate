"""Per-channel key/value config stored in the channel DB's ``ui_state``
table.

Mirrors the ``renderer_preferences`` storage pattern (routes/system.py) but
factored out so the discovery filters (generators/renderers) and the
file-manager "management" view's availability endpoints can share one
reader/writer without import cycles.

Two keys live here:

- ``generator_availability`` → ``{ generatorId: {"ui": bool, "generators": bool} }``
  The eye flag (``ui``) gates the UI picker; the gear flag (``generators``)
  gates programmatic/SDK discovery + running-as-a-child. A missing entry or
  missing sub-flag defaults to ``True`` — availability is opt-OUT, so a
  generator the user hasn't touched is available.

- ``renderer_availability`` → ``{ rendererId: bool }``
  Whether a renderer is served + resolvable in the active channel. Missing
  entry defaults to ``True``.
"""

import json
import threading

from database import get_db_connection

GENERATOR_AVAILABILITY_KEY = "generator_availability"
RENDERER_AVAILABILITY_KEY = "renderer_availability"

# Serializes read-modify-write merges so two concurrent per-id PUTs can't
# clobber each other (the DB write itself is atomic, the read+merge isn't).
_merge_lock = threading.Lock()


def _read_json(db_name: str, key: str, default):
    conn = get_db_connection(db_name)
    try:
        row = conn.execute(
            "SELECT value FROM ui_state WHERE key=?", (key,)
        ).fetchone()
        if not row:
            return default
        try:
            return json.loads(row["value"])
        except Exception:
            return default
    finally:
        conn.close()


def _write_json(db_name: str, key: str, value) -> None:
    conn = get_db_connection(db_name)
    try:
        conn.execute(
            "INSERT INTO ui_state (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, json.dumps(value)),
        )
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Reads (whole dict)
# ---------------------------------------------------------------------------

def read_generator_availability(db_name: str) -> dict:
    data = _read_json(db_name, GENERATOR_AVAILABILITY_KEY, {})
    return data if isinstance(data, dict) else {}


def read_renderer_availability(db_name: str) -> dict:
    data = _read_json(db_name, RENDERER_AVAILABILITY_KEY, {})
    return data if isinstance(data, dict) else {}


# ---------------------------------------------------------------------------
# Flag resolution (default True on any absence)
# ---------------------------------------------------------------------------

def generator_ui_enabled(availability: dict, gid: str) -> bool:
    entry = availability.get(gid)
    if not isinstance(entry, dict):
        return True
    return entry.get("ui", True) is not False


def generator_runs_enabled(availability: dict, gid: str) -> bool:
    """Gear flag: usable by other generators (SDK discovery + child runs)."""
    entry = availability.get(gid)
    if not isinstance(entry, dict):
        return True
    return entry.get("generators", True) is not False


def renderer_enabled(availability: dict, rid: str) -> bool:
    return availability.get(rid, True) is not False


# ---------------------------------------------------------------------------
# Per-id merge writes
# ---------------------------------------------------------------------------

def set_generator_availability(db_name: str, gid: str, patch: dict) -> dict:
    """Merge ``patch`` ({ui?, generators?}) into ``gid``'s entry. Returns the
    full updated dict."""
    with _merge_lock:
        data = read_generator_availability(db_name)
        entry = data.get(gid)
        if not isinstance(entry, dict):
            entry = {}
        if "ui" in patch:
            entry["ui"] = bool(patch["ui"])
        if "generators" in patch:
            entry["generators"] = bool(patch["generators"])
        data[gid] = entry
        _write_json(db_name, GENERATOR_AVAILABILITY_KEY, data)
        return data


def set_renderer_availability(db_name: str, rid: str, enabled: bool) -> dict:
    """Set ``rid``'s enabled flag. Returns the full updated dict."""
    with _merge_lock:
        data = read_renderer_availability(db_name)
        data[rid] = bool(enabled)
        _write_json(db_name, RENDERER_AVAILABILITY_KEY, data)
        return data
