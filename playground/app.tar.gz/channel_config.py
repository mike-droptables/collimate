"""Per-channel key/value config stored in the channel DB's ``ui_state``
table.

Mirrors the ``renderer_preferences`` storage pattern (routes/system.py) but
factored out so the discovery filters (generators/renderers) and the
file-manager "management" view's availability endpoints can share one
reader/writer without import cycles.

Three keys live here:

- ``generator_availability`` → ``{ generatorId: bool }``
  A per-generator on/off switch for the UI picker (the ``available_ui``
  baseline, overridable per channel). Missing entry defaults to ``True``
  (opt-OUT). Symmetric with ``renderer_availability``. Callability by other
  generators is NOT here — it's a CELL-level concern (``cell_exposure`` below).

- ``renderer_availability`` → ``{ rendererId: bool }``
  Whether a renderer is served + resolvable in the active channel. Missing
  entry defaults to ``True``.

- ``cell_exposure`` → ``{ cellId: bool }``
  Whether a generator- or renderer-source cell is "exposed to generators":
  other generators may run its generators, and read + edit (version) the whole
  cell's code. Keyed by the stable visible source-cell id (``str(cell.id)``).
  Missing entry defaults to ``True`` — exposed-by-default — so existing/shipped
  cells (e.g. the hidden ``agent`` generator's cell) stay callable.
"""

import json
import threading

from database import get_db_connection

GENERATOR_AVAILABILITY_KEY = "generator_availability"
RENDERER_AVAILABILITY_KEY = "renderer_availability"
CELL_EXPOSURE_KEY = "cell_exposure"

# Serializes read-modify-write merges so two concurrent per-id PUTs can't
# clobber each other (the DB write itself is atomic, the read+merge isn't).
_merge_lock = threading.Lock()


def _read_json(db_name: str, key: str, default):
    conn = get_db_connection(db_name)
    try:
        row = conn.execute(
            "SELECT value FROM ui_state WHERE key=?", (key,)
        ).fetchone()
        if not row:
            return default
        try:
            return json.loads(row["value"])
        except Exception:
            return default
    finally:
        conn.close()


def _write_json(db_name: str, key: str, value) -> None:
    conn = get_db_connection(db_name)
    try:
        conn.execute(
            "INSERT INTO ui_state (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, json.dumps(value)),
        )
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Reads (whole dict)
# ---------------------------------------------------------------------------

def read_generator_availability(db_name: str) -> dict:
    data = _read_json(db_name, GENERATOR_AVAILABILITY_KEY, {})
    return data if isinstance(data, dict) else {}


def read_renderer_availability(db_name: str) -> dict:
    data = _read_json(db_name, RENDERER_AVAILABILITY_KEY, {})
    return data if isinstance(data, dict) else {}


def read_cell_exposure(db_name: str) -> dict:
    data = _read_json(db_name, CELL_EXPOSURE_KEY, {})
    return data if isinstance(data, dict) else {}


# ---------------------------------------------------------------------------
# Flag resolution (default True on any absence)
# ---------------------------------------------------------------------------

def generator_ui_enabled(availability: dict, gid: str, default: bool = True) -> bool:
    """Whether ``gid`` is visible in the UI picker. ``default`` is the
    manifest-declared baseline (``available_ui``) used when the channel has no
    explicit override — so a generator can ship hidden-by-default yet be
    un-hidden per channel. An explicit channel entry always wins."""
    return availability.get(gid, default) is not False


def renderer_enabled(availability: dict, rid: str) -> bool:
    return availability.get(rid, True) is not False


def cell_exposed(exposure: dict, cell_id: str, default: bool = True) -> bool:
    """Whether a source cell is exposed to generators (run + read + edit).
    Exposed-by-default: a cell with no explicit entry is exposed, so shipped
    composition cells (e.g. the ``agent`` generator's cell) stay callable. An
    explicit ``False`` turns the whole cell off for programmatic access."""
    return exposure.get(cell_id, default) is not False


# ---------------------------------------------------------------------------
# Per-id merge writes
# ---------------------------------------------------------------------------

def set_generator_availability(db_name: str, gid: str, enabled: bool) -> dict:
    """Set ``gid``'s picker-visibility flag. Returns the full updated dict."""
    with _merge_lock:
        data = read_generator_availability(db_name)
        data[gid] = bool(enabled)
        _write_json(db_name, GENERATOR_AVAILABILITY_KEY, data)
        return data


def set_renderer_availability(db_name: str, rid: str, enabled: bool) -> dict:
    """Set ``rid``'s enabled flag. Returns the full updated dict."""
    with _merge_lock:
        data = read_renderer_availability(db_name)
        data[rid] = bool(enabled)
        _write_json(db_name, RENDERER_AVAILABILITY_KEY, data)
        return data


def set_cell_exposure(db_name: str, cell_id: str, exposed: bool) -> dict:
    """Set ``cell_id``'s exposed-to-generators flag. Returns the full updated
    dict."""
    with _merge_lock:
        data = read_cell_exposure(db_name)
        data[cell_id] = bool(exposed)
        _write_json(db_name, CELL_EXPOSURE_KEY, data)
        return data
