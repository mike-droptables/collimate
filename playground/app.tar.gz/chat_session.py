"""Per-cell chat session lifecycle.

A ChatSession wires one cell on the canvas to one session inside a sandbox
daemon container (see api/sandbox.py). The session is created on the first
``chat_start_session`` IPC op from a chat generator, reused on every
``chat_send_turn``, and torn down when the generator process exits or the
host explicitly evicts it.

Sessions are reference-counted by the sandbox registry: when the last
session for a given image closes, the container is shut down. There is no
warm pool — every container exists because some live session needs it.

This module owns:

- the cell_id -> ChatSession mapping
- the per-session async event queue that bridges the sandbox dispatcher
  into the per-turn drain loop
- the workspace sync bookkeeping that decides whether to push files to
  the daemon at the start of each turn
- a staging map of {cell_id: {path: blob_hash}} that ``process_manager``'s
  ``_update_cell`` consumes at turn end so the cell's DB version row
  lands with the freshly-edited file contents
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional

from cas import hash_and_store_bytes
from events import broadcast
import sandbox

_logger = logging.getLogger("chat_session")


class ChatSessionError(RuntimeError):
    pass


# ---------------------------------------------------------------------------
# ChatSession
# ---------------------------------------------------------------------------

@dataclass
class ChatSession:
    channel_db_name: str
    cell_id: str
    model: str
    system_prompt: str
    backend: str
    image: str
    shared: bool
    sandbox_session: sandbox.SandboxSession
    # Bridge between the sandbox event dispatcher (which is invoked by
    # the multiplexing daemon drain loop with one event at a time) and
    # the per-turn drain loop here.
    event_queue: asyncio.Queue = field(default_factory=asyncio.Queue)
    # File changes observed during the current turn.
    pending_file_hashes: dict[str, str] = field(default_factory=dict)
    pending_deleted_files: set[str] = field(default_factory=set)
    # SHA-256 of the last set of files synced into the daemon. Skipping
    # re-sync when hashes match makes steady-state turns cheap.
    synced_file_hashes: dict[str, str] = field(default_factory=dict)
    in_progress_assistant_text: str = ""
    last_turn_at: Optional[float] = None
    _turn_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    pending_redirect: Optional[str] = None
    pending_interrupt: bool = False


_sessions: dict[str, ChatSession] = {}


# ---------------------------------------------------------------------------
# Helpers — state lookup and in-memory cell file mutation
# ---------------------------------------------------------------------------

def _find_cell_in_state(channel_db_name: str, cell_id: str):
    from state import state, channel_db_name as _channel_db_name

    def _slug(s: str) -> str:
        s = s.lower().replace(" ", "_")
        return "".join(c for c in s if c.isalnum() or c in "_-")

    target = _slug(channel_db_name)
    for ch in state.channels:
        if _channel_db_name(ch) != target:
            continue
        for stack in ch.main_stacks + ch.nav_stacks:
            for cell in stack.cells:
                if str(cell.id) == cell_id:
                    return ch, stack, cell
    return None, None, None


def _collect_workspace_files(cell) -> dict[str, str]:
    files: dict[str, str] = {}
    for vf in cell.files or []:
        norm = (vf.name or "").replace("\\", "/").lstrip("/")
        if norm == ".colreserved" or norm.startswith(".colreserved/"):
            continue
        files[vf.name] = vf.content or ""
    return files


def _hash_files(files: dict[str, str]) -> dict[str, str]:
    out: dict[str, str] = {}
    for path, content in files.items():
        out[path] = hashlib.sha256(content.encode("utf-8", errors="replace")).hexdigest()
    return out


def _append_message(cell, role: str, content: str) -> None:
    from models import VirtualFile

    MSG_FILE = ".colreserved/.collimate_messages.json"
    LEGACY_MSG_FILE = ".collimate_messages.json"
    existing: list[dict] = []
    target: Optional[VirtualFile] = None
    for vf in cell.files or []:
        if vf.name == MSG_FILE or vf.name == LEGACY_MSG_FILE:
            target = vf
            if vf.name == LEGACY_MSG_FILE:
                vf.name = MSG_FILE
            try:
                parsed = json.loads(vf.content or "[]")
                if isinstance(parsed, list):
                    existing = parsed
            except (ValueError, TypeError):
                existing = []
            break

    existing.append({"role": role, "content": content})
    new_content = json.dumps(existing, indent=2, ensure_ascii=False)

    if target is None:
        cell.files = list(cell.files or []) + [
            VirtualFile(name=MSG_FILE, language="json", content=new_content)
        ]
    else:
        target.content = new_content

    try:
        cell.updated_at = datetime.now()
    except Exception:
        pass


def _apply_file_changed_to_cell(cell, path: str, content: str) -> None:
    from models import VirtualFile

    lang_map = {
        ".py": "python", ".js": "javascript", ".ts": "typescript",
        ".tsx": "typescript", ".jsx": "javascript", ".json": "json",
        ".md": "markdown", ".yaml": "yaml", ".yml": "yaml",
        ".html": "html", ".css": "css", ".sh": "shell",
    }
    ext = os.path.splitext(path)[1]
    lang = lang_map.get(ext, "plaintext")

    for vf in cell.files or []:
        if vf.name == path:
            vf.content = content
            vf.language = lang
            try:
                cell.updated_at = datetime.now()
            except Exception:
                pass
            return
    cell.files = list(cell.files or []) + [
        VirtualFile(name=path, language=lang, content=content)
    ]
    try:
        cell.updated_at = datetime.now()
    except Exception:
        pass


def _forward_bash_output_to_log(cell_id: str, text: str) -> None:
    """Append a synthetic stdout line to the matching ProcessManager's
    log_buffer so streamed Bash output appears in the standard run log."""
    try:
        from routes.runs import active_managers
    except Exception:
        return
    for manager in list(active_managers.values()):
        if getattr(manager, "placeholder_cell_id", None) == cell_id:
            try:
                manager.log_buffer.append({
                    "type": "stdout",
                    "payload": text + "\n",
                })
            except Exception:
                pass
            return


# ---------------------------------------------------------------------------
# Pending file hash map — consumed by process_manager._update_cell
# ---------------------------------------------------------------------------

def consume_pending_files(cell_id: str) -> dict[str, str]:
    session = _sessions.get(cell_id)
    if session is None:
        return {}
    out = dict(session.pending_file_hashes)
    session.pending_file_hashes.clear()
    return out


def consume_pending_deleted_files(cell_id: str) -> set[str]:
    session = _sessions.get(cell_id)
    if session is None:
        return set()
    out = set(session.pending_deleted_files)
    session.pending_deleted_files.clear()
    return out


# ---------------------------------------------------------------------------
# IPC entry points — called from process_manager._handle_ipc
# ---------------------------------------------------------------------------

async def start_session(
    channel_db_name: str,
    cell_id: str,
    model: str,
    system_prompt: str,
    backend: str,
    image: str,
    dockerfile_dir: str,
    shared: bool = True,
) -> dict[str, Any]:
    """Idempotent: return the existing session for ``cell_id`` if one is
    running, otherwise open a fresh one inside a (possibly newly spawned)
    sandbox container.

    The generator declares ``image`` and ``dockerfile_dir``; the host has
    no system-wide image default. ``shared=True`` lets multiple cells
    share one daemon container.
    """
    existing = _sessions.get(cell_id)
    if existing is not None:
        return {
            "session_id": cell_id,
            "backend": existing.backend,
            "image": existing.image,
            "shared": existing.shared,
            "container_id": existing.sandbox_session.container.container_id,
            "reused": True,
        }

    if not image:
        raise ChatSessionError(
            "chat_start_session requires `image` — generator must declare "
            "the docker image to use."
        )
    if not dockerfile_dir:
        raise ChatSessionError(
            "chat_start_session requires `dockerfile_dir` — generator must "
            "declare where the image's Dockerfile lives so the host can "
            "build lazily on first run."
        )

    def _log(line: str) -> None:
        _forward_bash_output_to_log(cell_id, line)
        # Also surface in the chat panel as a visible daemon_log line so
        # the user can see exactly what is happening (image build,
        # container spawn, daemon ready, teardown) without having to
        # open the run-log panel.
        try:
            broadcast(channel_db_name, {
                "type": "chat_stream",
                "cell_id": cell_id,
                "turn_id": "",
                "event": {"type": "daemon_log", "text": line},
            })
        except Exception:
            pass

    # Allocate the session shell up front so the dispatcher closure can
    # capture a stable reference. Fields that depend on sandbox.open_session
    # are filled in after.
    session = ChatSession(
        channel_db_name=channel_db_name,
        cell_id=cell_id,
        model=model,
        system_prompt=system_prompt,
        backend=backend,
        image=image,
        shared=shared,
        sandbox_session=None,  # type: ignore[arg-type]
    )

    async def _dispatch(event: dict) -> None:
        await session.event_queue.put(event)

    try:
        sb_session = await sandbox.open_session(
            image=image,
            dockerfile_dir=dockerfile_dir,
            session_id=cell_id,
            model=model,
            system_prompt=system_prompt,
            dispatcher=_dispatch,
            shared=shared,
            log=_log,
        )
    except Exception as exc:
        raise ChatSessionError(f"sandbox.open_session failed: {exc}") from exc

    session.sandbox_session = sb_session
    _sessions[cell_id] = session

    # Tell the frontend which sandbox is now bound to this cell so the
    # chat header can render the shared:<image> tag.
    try:
        broadcast(channel_db_name, {
            "type": "chat_stream",
            "cell_id": cell_id,
            "turn_id": "",
            "event": {
                "type": "session_started",
                "image": image,
                "shared": shared,
                "container_id": sb_session.container.container_id,
            },
        })
    except Exception:
        pass

    return {
        "session_id": cell_id,
        "backend": backend,
        "image": image,
        "shared": shared,
        "container_id": sb_session.container.container_id,
        "reused": False,
    }


async def _drain_one_turn(
    session: ChatSession,
    channel_db_name: str,
    cell_id: str,
    turn_id: str,
    cell,
) -> tuple[dict, list[str], Optional[str], bool]:
    usage: dict[str, Any] = {}
    file_changes: list[str] = []
    error_msg: Optional[str] = None
    was_interrupted = False

    while True:
        event = await session.event_queue.get()

        broadcast(channel_db_name, {
            "type": "chat_stream",
            "cell_id": cell_id,
            "turn_id": turn_id,
            "event": event,
        })

        evt_type = event.get("type")
        if evt_type == "text_delta":
            text = event.get("text") or ""
            session.in_progress_assistant_text += text
        elif evt_type == "bash_stdout":
            _forward_bash_output_to_log(cell_id, event.get("text") or "")
        elif evt_type == "file_changed":
            path = event.get("path") or ""
            new_content = event.get("content") or ""
            if path:
                raw = new_content.encode("utf-8")
                blob_hash = hash_and_store_bytes(raw)
                if blob_hash:
                    session.pending_file_hashes[path] = blob_hash
                    file_changes.append(path)
                _apply_file_changed_to_cell(cell, path, new_content)
                session.synced_file_hashes[path] = hashlib.sha256(raw).hexdigest()
        elif evt_type == "file_deleted":
            path = event.get("path") or ""
            if path:
                session.pending_deleted_files.add(path)
                session.pending_file_hashes.pop(path, None)
                session.synced_file_hashes.pop(path, None)
                if cell.files:
                    cell.files = [f for f in cell.files if f.name != path]
        elif evt_type == "turn_interrupted":
            was_interrupted = True
        elif evt_type == "turn_end":
            u = event.get("usage")
            if isinstance(u, dict):
                usage = u
            break
        elif evt_type == "error":
            error_msg = event.get("message") or "unknown daemon error"
            continue

    return usage, file_changes, error_msg, was_interrupted


async def send_turn(
    channel_db_name: str,
    cell_id: str,
    content: str,
) -> dict[str, Any]:
    session = _sessions.get(cell_id)
    if session is None:
        raise ChatSessionError(
            f"no chat session for cell {cell_id}; call start_session first"
        )

    async with session._turn_lock:
        _, _, cell = _find_cell_in_state(channel_db_name, cell_id)
        if cell is None:
            from state import state, channel_db_name as _cdb
            chan_summary = []
            for ch in state.channels:
                slug = _cdb(ch)
                ids = [str(c.id) for s in ch.main_stacks + ch.nav_stacks for c in s.cells]
                chan_summary.append(f"{slug}:[{','.join(ids[:6])}{'...' if len(ids) > 6 else ''}]")
            raise ChatSessionError(
                f"no cell {cell_id} in channel {channel_db_name}. "
                f"state={'; '.join(chan_summary)}"
            )

        session.pending_redirect = None
        session.pending_interrupt = False

        turn_content = content
        is_first_turn_in_call = True
        final_usage: dict[str, Any] = {}
        final_file_changes: list[str] = []
        was_cancelled_by_user = False
        last_turn_id = ""

        while True:
            turn_id = uuid.uuid4().hex
            last_turn_id = turn_id
            session.in_progress_assistant_text = ""

            if is_first_turn_in_call:
                files = _collect_workspace_files(cell)
                new_hashes = _hash_files(files)
                if new_hashes != session.synced_file_hashes:
                    await session.sandbox_session.send_op({
                        "op": "sync_workspace",
                        "files": files,
                        "turn_id": turn_id,
                    })
                    session.synced_file_hashes = new_hashes
                is_first_turn_in_call = False

            _append_message(cell, "user", turn_content)
            try:
                from state import persist_state
                persist_state()
            except Exception:
                pass

            await session.sandbox_session.send_op({
                "op": "user_turn",
                "content": turn_content,
                "turn_id": turn_id,
                "model": session.model,
                "system_prompt": session.system_prompt,
            })

            usage, file_changes, error_msg, was_interrupted = await _drain_one_turn(
                session, channel_db_name, cell_id, turn_id, cell,
            )

            session.last_turn_at = time.time()

            if error_msg:
                raise ChatSessionError(error_msg)

            final_usage = usage
            final_file_changes.extend(file_changes)

            if session.pending_redirect is not None:
                turn_content = session.pending_redirect
                session.pending_redirect = None
                if session.in_progress_assistant_text:
                    _append_message(
                        cell, "assistant",
                        session.in_progress_assistant_text
                            + "\n\n*[interrupted by user]*",
                    )
                continue

            if was_interrupted or session.pending_interrupt:
                was_cancelled_by_user = True
                session.pending_interrupt = False

            break

        appended_assistant = False
        if session.in_progress_assistant_text and not was_cancelled_by_user:
            _append_message(cell, "assistant", session.in_progress_assistant_text)
            appended_assistant = True
        elif was_cancelled_by_user and session.in_progress_assistant_text:
            _append_message(
                cell, "assistant",
                session.in_progress_assistant_text + "\n\n*[interrupted by user]*",
            )
            appended_assistant = True

        if appended_assistant:
            try:
                from state import persist_state
                persist_state()
            except Exception:
                pass

        msgs_content = None
        for vf in cell.files or []:
            if vf.name in (".colreserved/.collimate_messages.json", ".collimate_messages.json"):
                msgs_content = vf.content or ""
                break
        if msgs_content is not None:
            raw = msgs_content.encode("utf-8")
            blob_hash = hash_and_store_bytes(raw)
            if blob_hash:
                session.pending_file_hashes[".colreserved/.collimate_messages.json"] = blob_hash

        return {
            "turn_id": last_turn_id,
            "usage": final_usage,
            "file_changes": final_file_changes,
            "assistant_text": session.in_progress_assistant_text,
            "cancelled": was_cancelled_by_user,
        }


# ---------------------------------------------------------------------------
# Control ops
# ---------------------------------------------------------------------------

async def interrupt_turn(cell_id: str) -> dict[str, Any]:
    session = _sessions.get(cell_id)
    if session is None:
        raise ChatSessionError(f"no chat session for cell {cell_id}")
    session.pending_interrupt = True
    await session.sandbox_session.send_op({"op": "interrupt"})
    return {"ok": True, "cell_id": cell_id}


async def redirect_turn(cell_id: str, content: str) -> dict[str, Any]:
    session = _sessions.get(cell_id)
    if session is None:
        raise ChatSessionError(f"no chat session for cell {cell_id}")
    session.pending_redirect = content
    await session.sandbox_session.send_op({"op": "interrupt"})
    return {"ok": True, "cell_id": cell_id, "redirect_length": len(content)}


# ---------------------------------------------------------------------------
# Inline turn commit — used by the POST /chat/turn endpoint
# ---------------------------------------------------------------------------

def commit_chat_version(
    channel_db_name: str,
    cell_id: str,
    run_id: str,
    pending_file_hashes: dict[str, str],
) -> tuple[str, dict[str, str]]:
    from database import get_db_connection

    conn = get_db_connection(channel_db_name)

    tip_id = cell_id
    for _ in range(10_000):
        row = conn.execute(
            "SELECT child_cell_id FROM cell_edges "
            "WHERE parent_cell_id=? AND parent_key='previous_version' LIMIT 1",
            (tip_id,),
        ).fetchone()
        if not row:
            break
        tip_id = row[0]

    existing = conn.execute(
        "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?",
        (tip_id,),
    ).fetchall()
    merged: dict[str, str] = {r["filepath"]: r["blob_hash"] for r in existing}
    merged.update(pending_file_hashes)

    new_cell_id = str(uuid.uuid4())
    row = conn.execute(
        "SELECT COALESCE(MAX(sequence_num), 0) FROM cells WHERE run_id=?",
        (run_id,),
    ).fetchone()
    seq = (row[0] if row else 0) + 1

    conn.execute(
        "INSERT INTO cells (id, run_id, generator_name, sequence_num, "
        "version_name, version_summary, source_type) "
        "VALUES (?, ?, 'chat', ?, ?, ?, 'chat')",
        (new_cell_id, run_id, seq, "Chat", ""),
    )
    conn.execute(
        "INSERT OR IGNORE INTO cell_edges "
        "(parent_cell_id, child_cell_id, parent_key) VALUES (?, ?, 'previous_version')",
        (tip_id, new_cell_id),
    )

    for filepath, blob_hash in merged.items():
        cas_path = os.path.join(
            ".collimate", "objects", blob_hash[:2], blob_hash[2:]
        )
        size = 0
        if os.path.exists(cas_path):
            try:
                size = os.path.getsize(cas_path)
            except OSError:
                pass
        conn.execute(
            "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
            (blob_hash, size),
        )
        conn.execute(
            "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
            "VALUES (?, ?, ?)",
            (new_cell_id, filepath, blob_hash),
        )

    prev_row = conn.execute(
        "SELECT version_name FROM cells WHERE id=?", (tip_id,),
    ).fetchone()
    prev_name = (prev_row["version_name"] if prev_row and prev_row["version_name"] else "Chat")

    conn.execute(
        "UPDATE cells SET version_name=? WHERE id=?",
        (prev_name, new_cell_id),
    )

    conn.execute(
        "INSERT INTO run_events (run_id, event_type, payload) VALUES (?, 'commit', ?)",
        (
            run_id,
            json.dumps({
                "cell_id": new_cell_id,
                "name": prev_name,
                "summary": "",
                "sequence_num": seq,
                "file_count": len(merged),
            }),
        ),
    )

    conn.commit()
    conn.close()
    return new_cell_id, merged


def apply_chat_version_to_state(
    channel_db_name: str,
    cell_id: str,
    merged_files: dict[str, str],
    run_id: str,
) -> None:
    from models import VirtualFile
    from state import persist_state

    _, _, cell = _find_cell_in_state(channel_db_name, cell_id)
    if cell is None:
        return

    lang_map = {
        ".py": "python", ".js": "javascript", ".ts": "typescript",
        ".tsx": "typescript", ".jsx": "javascript", ".json": "json",
        ".md": "markdown", ".yaml": "yaml", ".yml": "yaml",
        ".html": "html", ".css": "css", ".sh": "shell",
    }

    vfiles = []
    for filepath, blob_hash in merged_files.items():
        cas_path = os.path.join(
            ".collimate", "objects", blob_hash[:2], blob_hash[2:]
        )
        try:
            with open(cas_path, "r", encoding="utf-8", errors="replace") as fh:
                content = fh.read()
        except Exception:
            content = ""
        ext = os.path.splitext(filepath)[1]
        vfiles.append(VirtualFile(
            name=filepath,
            content=content,
            language=lang_map.get(ext, "plaintext"),
        ))

    cell.files = vfiles
    cell.run_id = run_id
    cell.summary_artifact = ".colreserved/.collimate_messages.json"
    cell.updated_at = datetime.now()
    persist_state()


# ---------------------------------------------------------------------------
# Eviction — called when the owning generator subprocess exits, on daemon
# crash, or from explicit teardown paths. Drops the session refcount; if
# the daemon container's refcount hits zero the container is shut down.
# ---------------------------------------------------------------------------

async def evict_session(cell_id: str) -> None:
    session = _sessions.pop(cell_id, None)
    if session is None:
        return

    def _log(line: str) -> None:
        _forward_bash_output_to_log(cell_id, line)
        try:
            broadcast(session.channel_db_name, {
                "type": "chat_stream",
                "cell_id": cell_id,
                "turn_id": "",
                "event": {"type": "daemon_log", "text": line},
            })
        except Exception:
            pass

    try:
        await sandbox.close_session(session.sandbox_session, log=_log)
    except Exception as exc:
        _logger.warning("evict_session for %s: close_session failed: %s", cell_id, exc)
    finally:
        try:
            broadcast(session.channel_db_name, {
                "type": "chat_stream",
                "cell_id": cell_id,
                "turn_id": "",
                "event": {
                    "type": "session_closed",
                    "image": session.image,
                },
            })
        except Exception:
            pass


def get_session_summary(cell_id: str) -> Optional[dict[str, Any]]:
    """Return a small dict describing the active session for this cell, or
    None. Used by the frontend chat header to show the shared:image tag."""
    session = _sessions.get(cell_id)
    if session is None:
        return None
    return {
        "image": session.image,
        "shared": session.shared,
        "container_id": session.sandbox_session.container.container_id,
        "backend": session.backend,
        "model": session.model,
    }
