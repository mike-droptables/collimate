"""collimateapp — start the Collimate server and open the app, then shut
the server down when the app window closes.

Behaviour:
  1. Pick a browser: the user's default if it's Chromium-family
     (Chrome, Chromium, ungoogled-chromium, Brave, Edge, Vivaldi, Opera),
     otherwise fall back to any Chromium-family browser found on the
     system. If none exist, open in the system default as a normal tab.
  2. Start `collimate` as a child subprocess (no terminal window) and
     wait for http://localhost:5001/ to respond.
  3. Launch the browser in app-mode (`--app=URL`) with a dedicated
     user-data-dir, so Chromium spawns its own process for our session
     instead of delegating to an already-running instance. Block until
     that process exits.
  4. When the browser exits, terminate the server subprocess.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import NamedTuple

PORT = 5001


def _server_url(port: int = PORT) -> str:
    return f"http://localhost:{port}/"


SERVER_URL = _server_url()

# How long to wait for the server to exit on its own after SIGTERM before
# we SIGKILL it. SIGTERM triggers uvicorn's lifespan teardown, which stops
# every generator + sandbox container with its own grace window (Docker
# stops can take ~10s). This backstop must comfortably outlast that budget
# so the server finishes a clean teardown rather than getting force-killed
# mid-flight — which would orphan generators (they live in their own
# sessions, so our process-group SIGKILL never reaches them). Override with
# COLLIMATE_APP_SHUTDOWN_TIMEOUT.
SERVER_SHUTDOWN_TIMEOUT = float(
    os.environ.get("COLLIMATE_APP_SHUTDOWN_TIMEOUT") or 30.0
)


class Browser(NamedTuple):
    family: str  # "chromium" | "firefox" | "safari" | "unknown"
    binary: str  # absolute path or PATH-resolvable command
    data_dir: Path | None  # profile root, kept for future use


# ---------- browser tables ----------

def _linux_browsers() -> list[tuple[list[str], str, list[str], Path | None]]:
    """Return (desktop_keys, family, binaries, data_dir) for each browser
    candidate. desktop_keys are basename-substrings to match against the
    output of `xdg-settings get default-web-browser`. Covers native
    packages, Flatpaks, and Snaps — Flatpak/Snap-installed browsers ship
    .desktop files keyed by their package id rather than the generic
    binary name, so a single substring isn't enough."""
    home = Path.home()
    items: list[tuple[list[str], str, list[str], Path | None]] = []

    # --- Native (APT/RPM/etc.) ---
    # Each chromium-family entry's binary list covers stable + beta/dev/
    # nightly channel binaries. Channel desktop-IDs (e.g. google-chrome-beta)
    # substring-match the stable entry's desktop_key, so _resolve picks the
    # right channel binary without needing a separate entry per channel.
    # Distinct forks (ungoogled-chromium, thorium) must precede the generic
    # chromium entry so their longer desktop_keys match first.
    native = [
        (["google-chrome"], "chromium",
         ["google-chrome", "google-chrome-stable",
          "google-chrome-beta", "google-chrome-unstable"],
         home / ".config/google-chrome"),
        (["ungoogled-chromium"], "chromium",
         ["ungoogled-chromium"],
         home / ".config/chromium"),
        (["thorium-browser", "thorium"], "chromium",
         ["thorium-browser", "thorium"],
         home / ".config/chromium"),
        (["chromium"], "chromium",
         ["chromium", "chromium-browser"],
         home / ".config/chromium"),
        (["brave-browser", "brave"], "chromium",
         ["brave-browser", "brave-browser-stable",
          "brave-browser-beta", "brave-browser-nightly", "brave"],
         home / ".config/BraveSoftware/Brave-Browser"),
        (["microsoft-edge"], "chromium",
         ["microsoft-edge", "microsoft-edge-stable",
          "microsoft-edge-beta", "microsoft-edge-dev"],
         home / ".config/microsoft-edge"),
        (["vivaldi"], "chromium",
         ["vivaldi", "vivaldi-stable", "vivaldi-snapshot"],
         home / ".config/vivaldi"),
        (["opera"], "chromium",
         ["opera", "opera-stable", "opera-beta", "opera-developer"],
         home / ".config/opera"),
        (["yandex-browser", "yandex"], "chromium",
         ["yandex-browser", "yandex-browser-stable", "yandex-browser-beta"],
         home / ".config/yandex-browser"),
        (["naver-whale", "whale"], "chromium",
         ["naver-whale-stable", "naver-whale"],
         home / ".config/naver-whale"),
        (["firefox"], "firefox", ["firefox"], home / ".mozilla/firefox"),
    ]
    items.extend(native)

    # --- Flatpak ---
    # Wrapper scripts under exports/bin accept the same flags as the native
    # binary; data lives under ~/.var/app/<flatpak-id>/config/<chromium-name>/.
    flatpak_bin_roots = [
        Path("/var/lib/flatpak/exports/bin"),
        home / ".local/share/flatpak/exports/bin",
    ]
    flatpaks = [
        ("com.google.Chrome", "chromium", "google-chrome"),
        ("org.chromium.Chromium", "chromium", "chromium"),
        ("io.github.ungoogled_software.ungoogled_chromium", "chromium", "chromium"),
        ("com.brave.Browser", "chromium", "BraveSoftware/Brave-Browser"),
        ("com.microsoft.Edge", "chromium", "microsoft-edge"),
        ("com.vivaldi.Vivaldi", "chromium", "vivaldi"),
        ("com.opera.Opera", "chromium", "opera"),
        ("org.mozilla.firefox", "firefox", ""),
    ]
    for app_id, family, config_subdir in flatpaks:
        wrapper = next(
            (root / app_id for root in flatpak_bin_roots if (root / app_id).exists()),
            None,
        )
        if wrapper is None:
            continue
        data_dir: Path | None = None
        if config_subdir:
            candidate = home / ".var/app" / app_id / "config" / config_subdir
            data_dir = candidate if candidate.exists() else None
        items.append(([app_id], family, [str(wrapper)], data_dir))

    # --- Snap ---
    # Snap .desktop files use "<name>_<name>" keys (e.g. "chromium_chromium").
    snaps = [
        ("chromium", "chromium", home / "snap/chromium/current/.config/chromium"),
        ("brave", "chromium", home / "snap/brave/current/.config/BraveSoftware/Brave-Browser"),
        ("microsoft-edge", "chromium", home / "snap/microsoft-edge/current/.config/microsoft-edge"),
        ("opera", "chromium", home / "snap/opera/current/.config/opera"),
        ("firefox", "firefox", None),
    ]
    for name, family, data_dir in snaps:
        wrapper = Path("/snap/bin") / name
        if not wrapper.exists():
            continue
        items.append(
            ([f"{name}_{name}", name], family, [str(wrapper)],
             data_dir if (data_dir and data_dir.exists()) else None),
        )

    return items


def _macos_browsers() -> list[tuple[list[str], str, list[str], Path | None]]:
    # Channel bundle IDs (com.google.chrome.beta, com.brave.browser.nightly,
    # com.microsoft.edgemac.dev, etc.) substring-match the stable entry's
    # key, so listing channel app paths in the binary list lets _resolve
    # pick the right one without separate table entries.
    home = Path.home()
    return [
        (["com.google.chrome"], "chromium",
         ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
          "/Applications/Google Chrome Beta.app/Contents/MacOS/Google Chrome Beta",
          "/Applications/Google Chrome Dev.app/Contents/MacOS/Google Chrome Dev",
          "/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary"],
         home / "Library/Application Support/Google/Chrome"),
        (["org.chromium.chromium"], "chromium",
         ["/Applications/Chromium.app/Contents/MacOS/Chromium"],
         home / "Library/Application Support/Chromium"),
        (["com.brave.browser"], "chromium",
         ["/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
          "/Applications/Brave Browser Beta.app/Contents/MacOS/Brave Browser Beta",
          "/Applications/Brave Browser Nightly.app/Contents/MacOS/Brave Browser Nightly"],
         home / "Library/Application Support/BraveSoftware/Brave-Browser"),
        (["com.microsoft.edgemac"], "chromium",
         ["/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
          "/Applications/Microsoft Edge Beta.app/Contents/MacOS/Microsoft Edge Beta",
          "/Applications/Microsoft Edge Dev.app/Contents/MacOS/Microsoft Edge Dev",
          "/Applications/Microsoft Edge Canary.app/Contents/MacOS/Microsoft Edge Canary"],
         home / "Library/Application Support/Microsoft Edge"),
        (["com.vivaldi.vivaldi"], "chromium",
         ["/Applications/Vivaldi.app/Contents/MacOS/Vivaldi"],
         home / "Library/Application Support/Vivaldi"),
        (["com.operasoftware.operagx"], "chromium",
         ["/Applications/Opera GX.app/Contents/MacOS/Opera"],
         home / "Library/Application Support/com.operasoftware.OperaGX"),
        (["com.operasoftware.opera"], "chromium",
         ["/Applications/Opera.app/Contents/MacOS/Opera"],
         home / "Library/Application Support/com.operasoftware.Opera"),
        (["company.thebrowser.browser", "company.thebrowser.arc"], "chromium",
         ["/Applications/Arc.app/Contents/MacOS/Arc"],
         home / "Library/Application Support/Arc"),
        (["ru.yandex.desktop.yandex-browser", "yandex-browser"], "chromium",
         ["/Applications/Yandex.app/Contents/MacOS/Yandex"],
         home / "Library/Application Support/Yandex/YandexBrowser"),
        (["com.naver.whale"], "chromium",
         ["/Applications/Whale.app/Contents/MacOS/Whale"],
         home / "Library/Application Support/naver/Whale"),
        (["org.mozilla.firefox"], "firefox",
         ["/Applications/Firefox.app/Contents/MacOS/firefox"],
         None),
        (["com.apple.safari"], "safari",
         ["/Applications/Safari.app/Contents/MacOS/Safari"],
         None),
    ]


def _windows_browsers() -> list[tuple[list[str], str, list[str], Path | None]]:
    # ProgID stems ("Chrome", "MSEdge", "Brave", "Vivaldi") catch every
    # channel: ChromeHTML / ChromeBHTML / ChromeDHTML / ChromeSSHTM all
    # contain "Chrome". Channel installs use a "<App> Beta" / "Dev" / "SxS"
    # subdirectory under either %ProgramFiles% or %LOCALAPPDATA%. Lower-cased
    # substring matching means "Chrome" doesn't false-match "Chromium" (the
    # 6th char differs), so the stems stay safe.
    localapp = Path(os.environ.get("LOCALAPPDATA", ""))
    progf = Path(os.environ.get("ProgramFiles", "C:/Program Files"))
    progf86 = Path(os.environ.get("ProgramFiles(x86)", "C:/Program Files (x86)"))
    return [
        (["Chrome"], "chromium",
         [str(progf / "Google/Chrome/Application/chrome.exe"),
          str(progf86 / "Google/Chrome/Application/chrome.exe"),
          str(localapp / "Google/Chrome/Application/chrome.exe"),
          str(progf / "Google/Chrome Beta/Application/chrome.exe"),
          str(localapp / "Google/Chrome Beta/Application/chrome.exe"),
          str(progf / "Google/Chrome Dev/Application/chrome.exe"),
          str(localapp / "Google/Chrome Dev/Application/chrome.exe"),
          str(localapp / "Google/Chrome SxS/Application/chrome.exe")],
         localapp / "Google/Chrome/User Data"),
        (["Brave"], "chromium",
         [str(progf / "BraveSoftware/Brave-Browser/Application/brave.exe"),
          str(progf86 / "BraveSoftware/Brave-Browser/Application/brave.exe"),
          str(progf / "BraveSoftware/Brave-Browser-Beta/Application/brave.exe"),
          str(progf / "BraveSoftware/Brave-Browser-Nightly/Application/brave.exe"),
          str(localapp / "BraveSoftware/Brave-Browser/Application/brave.exe")],
         localapp / "BraveSoftware/Brave-Browser/User Data"),
        (["MSEdge"], "chromium",
         [str(progf / "Microsoft/Edge/Application/msedge.exe"),
          str(progf86 / "Microsoft/Edge/Application/msedge.exe"),
          str(progf / "Microsoft/Edge Beta/Application/msedge.exe"),
          str(progf86 / "Microsoft/Edge Beta/Application/msedge.exe"),
          str(progf / "Microsoft/Edge Dev/Application/msedge.exe"),
          str(progf86 / "Microsoft/Edge Dev/Application/msedge.exe"),
          str(localapp / "Microsoft/Edge SxS/Application/msedge.exe")],
         localapp / "Microsoft/Edge/User Data"),
        (["Chromium"], "chromium",
         [str(localapp / "Chromium/Application/chrome.exe")],
         localapp / "Chromium/User Data"),
        (["Vivaldi"], "chromium",
         [str(localapp / "Vivaldi/Application/vivaldi.exe"),
          str(localapp / "Vivaldi Snapshot/Application/vivaldi.exe")],
         localapp / "Vivaldi/User Data"),
        # OperaGX before Opera: "Opera" is a substring of "OperaGX", so the
        # more specific key must claim its default first.
        (["OperaGX"], "chromium",
         [str(localapp / "Programs/Opera GX/opera.exe")],
         localapp / "Opera Software/Opera GX Stable"),
        (["Opera"], "chromium",
         [str(localapp / "Programs/Opera/opera.exe"),
          str(progf / "Opera/opera.exe")],
         localapp / "Opera Software/Opera Stable"),
        (["Arc"], "chromium",
         [str(localapp / "Arc/Application/Arc.exe"),
          str(localapp / "Microsoft/Arc/Application/Arc.exe")],
         localapp / "Arc/User Data"),
        (["Yandex"], "chromium",
         [str(localapp / "Yandex/YandexBrowser/Application/browser.exe")],
         localapp / "Yandex/YandexBrowser/User Data"),
        (["Whale"], "chromium",
         [str(localapp / "Naver/Naver Whale/Application/whale.exe"),
          str(progf / "Naver/Naver Whale/Application/whale.exe")],
         localapp / "Naver/Naver Whale/User Data"),
        (["FirefoxURL", "Firefox"], "firefox",
         [str(progf / "Mozilla Firefox/firefox.exe"),
          str(progf86 / "Mozilla Firefox/firefox.exe")],
         None),
    ]


def _resolve(binaries: list[str]) -> str | None:
    for b in binaries:
        if b.startswith("/") or (len(b) > 2 and b[1] == ":") or b.endswith(".exe"):
            if Path(b).exists():
                return b
        else:
            p = shutil.which(b)
            if p:
                return p
    return None


def _make_browser(family: str, binaries: list[str], data_dir: Path | None) -> Browser | None:
    binary = _resolve(binaries)
    if not binary:
        return None
    resolved_dir = data_dir if (data_dir is not None and data_dir.exists()) else None
    return Browser(family, binary, resolved_dir)


# ---------- default-browser detection ----------

def detect_default_browser() -> Browser:
    sysname = platform.system()
    if sysname == "Linux":
        return _detect_linux()
    if sysname == "Darwin":
        return _detect_macos()
    if sysname == "Windows":
        return _detect_windows()
    return Browser("unknown", "", None)


def _match_default(table: list[tuple[list[str], str, list[str], Path | None]],
                   default_id: str) -> Browser | None:
    """Iterate the browser table, return the first entry whose desktop
    keys appear (lower-cased substring) in default_id."""
    default_id = default_id.lower().removesuffix(".desktop")
    for keys, family, binaries, data_dir in table:
        if any(k.lower() in default_id for k in keys):
            b = _make_browser(family, binaries, data_dir)
            if b:
                return b
    return None


def _detect_linux() -> Browser:
    desktop = ""
    try:
        result = subprocess.run(
            ["xdg-settings", "get", "default-web-browser"],
            capture_output=True, text=True, timeout=3,
        )
        desktop = result.stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return _match_default(_linux_browsers(), desktop) or Browser("unknown", "", None)


def _detect_macos() -> Browser:
    # Read LaunchServices' http handler. The plist lives in a stable
    # path; convert to JSON via plutil to avoid PyObjC.
    plist = Path.home() / "Library/Preferences/com.apple.LaunchServices/com.apple.launchservices.secure.plist"
    bundle = ""
    if plist.exists():
        try:
            result = subprocess.run(
                ["plutil", "-convert", "json", "-o", "-", str(plist)],
                capture_output=True, text=True, timeout=3,
            )
            data = json.loads(result.stdout or "{}")
            for h in data.get("LSHandlers", []):
                if h.get("LSHandlerURLScheme") == "http":
                    bundle = (h.get("LSHandlerRoleAll")
                              or h.get("LSHandlerRoleViewer") or "")
                    break
        except (subprocess.SubprocessError, json.JSONDecodeError, FileNotFoundError):
            pass
    return _match_default(_macos_browsers(), bundle) or Browser("unknown", "", None)


def _detect_windows() -> Browser:
    progid = ""
    if sys.platform == "win32":
        try:
            import winreg
            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice",
            ) as key:
                progid, _ = winreg.QueryValueEx(key, "ProgId")
        except (OSError, ImportError):
            pass
    return _match_default(_windows_browsers(), progid) or Browser("unknown", "", None)


def find_chromium_fallback() -> Browser | None:
    """Locate any Chromium-family browser on the system, regardless of default."""
    sysname = platform.system()
    if sysname == "Linux":
        table = _linux_browsers()
    elif sysname == "Darwin":
        table = _macos_browsers()
    elif sysname == "Windows":
        table = _windows_browsers()
    else:
        return None
    for _keys, family, binaries, data_dir in table:
        if family != "chromium":
            continue
        b = _make_browser(family, binaries, data_dir)
        if b:
            return b
    return None


# ---------- browser profile (for --user-data-dir) ----------

def _browser_profile_dir(browser: Browser) -> Path:
    """Per-app, browser-accessible profile dir for `--user-data-dir`.

    Chromium-family browsers, when launched with `--app=URL`, normally
    delegate the new window to an already-running browser process via
    IPC — the launcher command then exits immediately. Forcing a unique
    user-data-dir guarantees Chromium spawns a fresh process bound to our
    launch, so we have a real process to wait on.

    The path must be writable by the browser. Native installs can use a
    standard data dir under $HOME. Flatpak and Snap browsers run in a
    sandbox: they can write to their own ~/.var/app or ~/snap area, but
    arbitrary host paths may be denied."""
    binary = browser.binary
    home = Path.home()
    if binary.startswith("/var/lib/flatpak/exports/bin/") or \
       binary.startswith(str(home / ".local/share/flatpak/exports/bin")):
        flatpak_id = Path(binary).name
        return home / ".var/app" / flatpak_id / "data" / "collimate-app-profile"
    if binary.startswith("/snap/bin/"):
        snap_name = Path(binary).name
        return home / "snap" / snap_name / "current" / "collimate-app-profile"
    sysname = platform.system()
    if sysname == "Darwin":
        return home / "Library/Application Support/Collimate/browser-profile"
    if sysname == "Windows":
        return Path(os.environ.get("LOCALAPPDATA", str(home))) / "Collimate" / "browser-profile"
    xdg = os.environ.get("XDG_DATA_HOME") or str(home / ".local/share")
    return Path(xdg) / "collimate" / "browser-profile"


def _log_file_path(port: int = PORT) -> Path:
    """Where the server's stdout/stderr go when collimateapp owns it.
    Truncated each run since only one server can hold the port anyway;
    non-default ports get their own file so two instances don't clobber
    each other's logs."""
    name = "server.log" if port == PORT else f"server-{port}.log"
    home = Path.home()
    sysname = platform.system()
    if sysname == "Darwin":
        return home / "Library/Logs/Collimate" / name
    if sysname == "Windows":
        return Path(os.environ.get("LOCALAPPDATA", str(home))) / "Collimate" / "Logs" / name
    state = os.environ.get("XDG_STATE_HOME") or str(home / ".local/state")
    return Path(state) / "collimate" / name


# ---------- server lifecycle ----------

def is_server_up(url: str = SERVER_URL, timeout: float = 1.0) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return 200 <= r.status < 500
    except (urllib.error.URLError, ConnectionError, socket.timeout, OSError):
        return False


def _find_collimate_command() -> list[str]:
    """Locate the `collimate` entry point installed alongside `collimateapp`.
    Falls back to the current interpreter running `main:cli_main`."""
    here = Path(sys.argv[0]).resolve().parent
    candidates = [here / "collimate"]
    if platform.system() == "Windows":
        candidates = [here / "collimate.exe", here / "collimate"]
    for c in candidates:
        if c.exists():
            return [str(c)]
    on_path = shutil.which("collimate")
    if on_path:
        return [on_path]
    return [sys.executable, "-c", "from main import cli_main; cli_main()"]


def spawn_server(port: int = PORT) -> subprocess.Popen:
    """Start `collimate` as a hidden child process. Output goes to a log
    file so the user can debug failures without a terminal window."""
    log_path = _log_file_path(port)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_fh = open(log_path, "w")  # noqa: SIM115 — handed to subprocess
    cmd = _find_collimate_command() + ["--port", str(port)]
    kwargs: dict = dict(
        stdout=log_fh,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
    )
    if platform.system() == "Windows":
        # CREATE_NEW_PROCESS_GROUP allows sending CTRL_BREAK_EVENT later.
        # CREATE_NO_WINDOW prevents a flash of console window.
        kwargs["creationflags"] = 0x00000200 | 0x08000000
    else:
        # New session = new process group, so killpg targets the whole tree.
        kwargs["start_new_session"] = True
    return subprocess.Popen(cmd, **kwargs)


def wait_for_server(url: str = SERVER_URL, timeout: float = 20.0,
                    proc: subprocess.Popen | None = None) -> bool:
    """Poll until the server is reachable or the process dies / we time out."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if proc is not None and proc.poll() is not None:
            return False
        if is_server_up(url, timeout=1.0):
            return True
        time.sleep(0.3)
    return False


def shutdown_server(proc: subprocess.Popen) -> None:
    if proc.poll() is not None:
        return
    sysname = platform.system()
    try:
        if sysname == "Windows":
            proc.send_signal(signal.CTRL_BREAK_EVENT)  # type: ignore[attr-defined]
        else:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
    except (OSError, ProcessLookupError):
        proc.terminate()
    try:
        proc.wait(timeout=SERVER_SHUTDOWN_TIMEOUT)
    except subprocess.TimeoutExpired:
        try:
            if sysname == "Windows":
                proc.kill()
            else:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
        except (OSError, ProcessLookupError):
            pass
        proc.wait()


# ---------- browser launch ----------

def build_browser_args(browser: Browser, port: int = PORT) -> list[str]:
    """Command line for launching the app window. --user-data-dir forces
    Chromium to spawn its own process for our session (otherwise IPC
    delegation to an already-running browser makes the launcher exit
    immediately, and we'd have nothing to block on). Non-default ports get
    their own profile dir for the same reason: a second instance reusing
    the first one's dir would delegate to that process and exit."""
    profile_dir = _browser_profile_dir(browser)
    if port != PORT:
        profile_dir = profile_dir.with_name(f"{profile_dir.name}-{port}")
    profile_dir.mkdir(parents=True, exist_ok=True)
    return [
        browser.binary,
        f"--user-data-dir={profile_dir}",
        f"--app={_server_url(port)}",
    ]


# ---------- entry point ----------

def main() -> None:
    parser = argparse.ArgumentParser(
        prog="collimateapp",
        description=(
            "Start the Collimate server and open it in an app window; "
            "the server shuts down when the window closes."
        ),
    )
    parser.add_argument(
        "-p", "--port", type=int, default=PORT, metavar="N",
        help=(
            f"port for the server and app window (default: {PORT}). "
            "Forwarded to `collimate --port N`; the server still binds "
            "loopback only (127.0.0.1)."
        ),
    )
    cli = parser.parse_args()
    port = cli.port
    url = _server_url(port)

    primary = detect_default_browser()
    chosen = primary
    if primary.family != "chromium":
        fallback = find_chromium_fallback()
        if fallback is None:
            print("[collimateapp] No Chromium-family browser found. "
                  "collimateapp requires a Chromium-based browser (Chrome, "
                  "Chromium, ungoogled-chromium, Thorium, Brave, Edge, "
                  "Vivaldi, Opera, Opera GX, Arc, Yandex, or Naver Whale — "
                  "native, Flatpak, or Snap). Install one and re-run.",
                  file=sys.stderr)
            sys.exit(1)
        label = primary.family if primary.family != "unknown" else "no default browser"
        print(f"[collimateapp] {label} can't run in app-mode; "
              f"using {fallback.binary}.", file=sys.stderr)
        chosen = fallback

    # Only own the server if we started it. If something else is already
    # serving the port, leave it alone on exit.
    own_server = not is_server_up(url)
    server_proc: subprocess.Popen | None = None
    if own_server:
        server_proc = spawn_server(port)
        if not wait_for_server(url, proc=server_proc):
            print(f"[collimateapp] Server failed to start. "
                  f"See {_log_file_path(port)} for logs.", file=sys.stderr)
            if server_proc.poll() is None:
                shutdown_server(server_proc)
            sys.exit(1)

    args = build_browser_args(chosen, port)
    try:
        # Blocks until the browser process exits. For Chromium with a
        # dedicated --user-data-dir, that means the app window closed.
        subprocess.run(args, check=False)
    except KeyboardInterrupt:
        pass
    finally:
        if server_proc is not None:
            shutdown_server(server_proc)


if __name__ == "__main__":
    main()
