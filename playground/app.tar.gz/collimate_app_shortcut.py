"""collimate-app-shortcut — install a per-OS desktop / menu shortcut that
launches `collimateapp`.

After `uv tool install collimate` (or `pipx install collimate`), running
this once drops a "Collimate" entry in the user's application launcher
(and on the Desktop) with the Collimate icon. Clicking it runs the same
flow as `collimateapp` from a terminal: hidden FastAPI server + Chromium
app-mode window. The plain `collimate` entry point is still available
in the terminal for headless / dev use.

Implementation notes:
  * pyshortcuts owns the OS-specific bits (.desktop on Linux, .app
    bundle on macOS, .lnk on Windows). We pass `noexe=True` so it
    treats the absolute path to `collimateapp` as the full command
    instead of prepending Python.
  * Icons ship pre-rendered next to this module in icons/. The .ico
    is used on Windows, .icns on macOS, .png on Linux — matching what
    each platform's shortcut format expects.
"""

from __future__ import annotations

import platform
import shutil
import sys
from pathlib import Path

APP_NAME = "Collimate"

_ICONS_DIR = Path(__file__).resolve().parent / "icons"


def _icon_path() -> Path | None:
    """Pick the right icon file for this OS. Returns None if the
    expected file is missing — pyshortcuts will fall back to its
    default icon and we'll print a warning."""
    sysname = platform.system()
    if sysname == "Windows":
        candidate = _ICONS_DIR / "app-icon.ico"
    elif sysname == "Darwin":
        candidate = _ICONS_DIR / "app-icon.icns"
    else:
        candidate = _ICONS_DIR / "app-icon.png"
    return candidate if candidate.exists() else None


def _find_collimateapp() -> str | None:
    """Locate the `collimateapp` entry point installed alongside us.

    `collimate-app-shortcut` and `collimateapp` are both console
    entry points from the same wheel, so they live in the same bin/
    directory. We look there first, then fall back to PATH so a
    development checkout (where this file is run directly) still
    works."""
    here = Path(sys.argv[0]).resolve().parent
    candidates = [here / "collimateapp"]
    if platform.system() == "Windows":
        candidates = [here / "collimateapp.exe", here / "collimateapp"]
    for c in candidates:
        if c.exists():
            return str(c)
    on_path = shutil.which("collimateapp")
    return on_path


def main() -> None:
    try:
        from pyshortcuts import make_shortcut
    except ImportError:
        print(
            "[collimate-app-shortcut] pyshortcuts is not installed. "
            "Reinstall collimate (`uv tool install --force collimate`) "
            "to pull it in.",
            file=sys.stderr,
        )
        sys.exit(1)

    target = _find_collimateapp()
    if target is None:
        print(
            "[collimate-app-shortcut] Could not find the `collimateapp` "
            "executable. Make sure collimate is installed in a way that "
            "exposes its console entry points (e.g. `uv tool install "
            "collimate` or `pipx install collimate`).",
            file=sys.stderr,
        )
        sys.exit(1)

    icon = _icon_path()
    if icon is None:
        print(
            f"[collimate-app-shortcut] Bundled icon missing under "
            f"{_ICONS_DIR}. Continuing with the default system icon.",
            file=sys.stderr,
        )

    make_shortcut(
        script=target,
        name=APP_NAME,
        icon=str(icon) if icon else None,
        terminal=False,
        desktop=True,
        # macOS default is False (Applications/ is treated as the start
        # menu equivalent); force True so the app shows up in Spotlight
        # and Launchpad alongside the Desktop link.
        startmenu=True,
        noexe=True,
    )

    print(f"[collimate-app-shortcut] Installed '{APP_NAME}' shortcut "
          f"(target: {target}).")


if __name__ == "__main__":
    main()
