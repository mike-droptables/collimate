"""Config tags — named, manifest-stored sets of default input values.

Shared by the generator catalog (``resolve_config_tags``), the run
path (``overlay_set_yaml_values`` in create_run's seeding layer), and
the tag PUT/DELETE endpoints (``splice_top_level_yaml_block``).

The per-field-type "empty" rule lives in the SDK
(``collimate.config_values``), pinned cross-language by
``collimate-sdk/shared/empty-values-contract.json``. ``is_empty`` is
re-exported here for the routes and tests.
"""

import logging
import re

import yaml

# Re-exported: routes/generator_config_tags.py and the unit tests
# import is_empty from this module.
from collimate.config_values import is_empty, type_empty_default

_logger = logging.getLogger("config_tags")

# Tag names: enforced by SDK lint, the PUT endpoint, and the modal's
# new-tag input.
TAG_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._-]{0,31}$")


def parse_set_yaml(text: str) -> tuple[list[dict], dict]:
    """Parse a ``.set_yaml`` into ``(fields, resolved_values)``.

    ``resolved_values`` layers per-type empty bases ⊕ field
    ``default:``s ⊕ the ``values:`` block — the same merge the SDK's
    ``_host._parse_schema_values`` performs, except every declared
    field key is present (so required-empty checks see the field at
    all). Malformed input yields ``([], {})``.
    """
    try:
        parsed = yaml.safe_load(text or "")
    except yaml.YAMLError:
        return [], {}
    if not isinstance(parsed, dict):
        return [], {}
    raw_fields = parsed.get("fields")
    fields = [
        f for f in (raw_fields if isinstance(raw_fields, list) else [])
        if isinstance(f, dict) and isinstance(f.get("key"), str) and f["key"]
    ]
    values_block = parsed.get("values") if isinstance(parsed.get("values"), dict) else {}
    resolved: dict = {}
    for f in fields:
        key = f["key"]
        resolved[key] = type_empty_default(f.get("type"))
        if "default" in f:
            resolved[key] = f["default"]
    resolved.update(values_block)
    return fields, resolved


def missing_required_fields(rel: str, fields: list[dict], resolved: dict) -> list[dict]:
    """``[{file, key, label}]`` for every required field whose resolved
    value is empty. checkbox is never empty so a (lint-WARNed)
    required checkbox can't block a run."""
    out = []
    for f in fields:
        if not f.get("required"):
            continue
        if is_empty(resolved.get(f["key"]), f.get("type")):
            out.append({
                "file": rel,
                "key": f["key"],
                "label": f.get("label") or f["key"],
            })
    return out


def _resolve_tag(name: str, body, base: dict) -> dict:
    """Resolve one tag against ``base`` ({rel: (fields, values)})."""
    body = body if isinstance(body, dict) else {}
    prompt = body.get("prompt")
    prompt = prompt if isinstance(prompt, str) else None
    files_overlay = body.get("files") if isinstance(body.get("files"), dict) else {}
    values: dict = {}
    missing: list[dict] = []
    for rel, (fields, resolved) in base.items():
        merged = dict(resolved)
        overlay = files_overlay.get(rel)
        if isinstance(overlay, dict):
            for k, v in overlay.items():
                # Only overlay keys the file actually resolves —
                # unknown keys are a lint error, not a runtime one.
                if k in merged:
                    merged[k] = v
        values[rel] = merged
        # Prompt is deliberately excluded from missing_required — the
        # frontend evaluates the live prompt box instead.
        missing.extend(missing_required_fields(rel, fields, merged))
    return {
        "name": name,
        "prompt": prompt,
        "values": values,
        "missing_required": missing,
    }


def resolve_config_tags(manifest: dict, read_rel) -> list[dict]:
    """Resolve a manifest's ``config_tags`` into the catalog shape:
    ``[{name, prompt, values: {rel: {key: value}}, missing_required}]``
    in manifest (insertion) order.

    ``read_rel(rel) -> str | None`` reads a draft file relative to the
    manifest's directory. Never raises and never hides a generator:
    a malformed ``config_tags`` logs and collapses to a synthesized
    pure-defaults ``default`` tag; an absent one yields ``[]``.
    """
    try:
        raw = manifest.get("config_tags")
        if raw is None:
            return []
        base: dict = {}
        for rel in (manifest.get("draft_files") or []):
            if not isinstance(rel, str) or not rel.endswith(".set_yaml"):
                continue
            try:
                text = read_rel(rel)
            except Exception:
                text = None
            base[rel] = parse_set_yaml(text or "")
        if not isinstance(raw, dict) or "default" not in raw:
            raise ValueError(
                f"config_tags must be a mapping with a 'default' entry, got {raw!r}"
            )
        return [_resolve_tag(str(name), body, base) for name, body in raw.items()]
    except Exception:
        _logger.warning(
            "malformed config_tags in manifest %r — synthesizing pure-defaults tag",
            manifest.get("id"), exc_info=True,
        )
        try:
            return [_resolve_tag("default", {}, base)]
        except Exception:
            return [{"name": "default", "prompt": None, "values": {},
                     "missing_required": []}]


def overlay_set_yaml_values(text: str, overlay: dict) -> str:
    """Merge ``overlay`` into the file's top-level ``values:`` block and
    splice the merged block back in, leaving every other line (comments
    included) untouched. Raises ``ValueError`` when the document can't
    be spliced safely."""
    if not overlay:
        return text
    try:
        parsed = yaml.safe_load(text or "")
    except yaml.YAMLError as exc:
        raise ValueError(f"unparseable .set_yaml: {exc}") from exc
    if parsed is None:
        parsed = {}
    if not isinstance(parsed, dict):
        raise ValueError(".set_yaml is not a mapping document")
    existing = parsed.get("values") if isinstance(parsed.get("values"), dict) else {}
    merged = {**existing, **overlay}
    return splice_top_level_yaml_block(text, "values", merged)


def splice_top_level_yaml_block(text: str, key: str, value) -> str:
    """Replace (or append) the top-level ``key:`` block of a YAML doc by
    line-splicing so every line outside the block — comments included —
    survives byte-for-byte.

    Safety reparse: the result must parse back equal to the original on
    every OTHER top-level key and carry exactly ``value`` under ``key``,
    else ``ValueError`` — callers map that to a 500 and persist nothing.
    """
    try:
        old_doc = yaml.safe_load(text or "")
    except yaml.YAMLError as exc:
        raise ValueError(f"unparseable document: {exc}") from exc
    if old_doc is None:
        old_doc = {}
    if not isinstance(old_doc, dict):
        raise ValueError("document is not a top-level mapping")

    lines = text.splitlines(keepends=True)
    key_re = re.compile(rf"^{re.escape(key)}\s*:")
    start = end = None
    for i, ln in enumerate(lines):
        if key_re.match(ln):
            start = i
            end = i + 1
            # The block runs through every following line that is blank
            # or indented; a non-blank column-0 line (incl. comments)
            # belongs to whatever comes next.
            while end < len(lines):
                nxt = lines[end]
                if nxt.strip() == "" or nxt[:1] in (" ", "\t"):
                    end += 1
                else:
                    break
            # Leave trailing blank separator lines in place.
            while end > start + 1 and lines[end - 1].strip() == "":
                end -= 1
            break

    block = yaml.safe_dump(
        {key: value}, sort_keys=False, default_flow_style=False, allow_unicode=True,
    )
    if start is None:
        new_lines = list(lines)
        if new_lines and not new_lines[-1].endswith("\n"):
            new_lines[-1] += "\n"
        new_lines.append(block)
    else:
        new_lines = lines[:start] + [block] + lines[end:]
    new_text = "".join(new_lines)

    try:
        new_doc = yaml.safe_load(new_text)
    except yaml.YAMLError as exc:
        raise ValueError(f"splice produced unparseable YAML: {exc}") from exc
    if not isinstance(new_doc, dict):
        raise ValueError("splice produced a non-mapping document")
    if {k: v for k, v in old_doc.items() if k != key} != \
            {k: v for k, v in new_doc.items() if k != key}:
        raise ValueError("splice altered unrelated top-level keys")
    if new_doc.get(key) != value:
        raise ValueError(f"spliced {key!r} block did not round-trip")
    return new_text
