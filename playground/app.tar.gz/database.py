# --- START FILE: api/database.py ---
import os
import sqlite3
import json

import migrations as _migrations

# Track which database files have already had their schema initialised so
# we don't re-run DDL (which takes an EXCLUSIVE lock) on every connection.
# Keyed by absolute path so tests that chdir into different tmp dirs
# don't collide on the relative ``.collimate/channels/<x>.db`` form —
# every distinct DB file gets its own cache entry. Production behaviour
# is unchanged: a long-running server has one stable cwd.
_initialised_dbs: set[str] = set()


def _resolve_synchronous() -> str:
    """Resolve the SQLite ``synchronous`` pragma value.

    Default is ``NORMAL`` (every commit is fsync'd to the journal but
    not to the main DB file) — this matches the historical behaviour
    and keeps the chat-streaming microbatch writer fast. Operators who
    want stronger durability at the cost of an extra fsync per commit
    can set ``COLLIMATE_SQLITE_SYNCHRONOUS=FULL`` in the environment.

    Anything other than the four documented values silently falls back
    to NORMAL — better a known-good pragma than a typo wedging the
    server.
    """
    value = (os.environ.get("COLLIMATE_SQLITE_SYNCHRONOUS") or "NORMAL").strip().upper()
    if value not in ("OFF", "NORMAL", "FULL", "EXTRA"):
        value = "NORMAL"
    return value


_SYNCHRONOUS = _resolve_synchronous()

def _slug_channel(name: str) -> str:
    """Match state.channel_db_name()'s slug rules so URL path params
    (``Starting``) resolve to the same db file as in-memory state
    (``starting``). Keep here (not in state.py) to avoid a circular
    import and so every DB path construction funnels through one rule.
    """
    s = (name or "").lower().replace(" ", "_")
    slug = "".join(c for c in s if c.isalnum() or c in "_-")
    return slug or name


def get_global_db_connection() -> sqlite3.Connection:
    """Open the global (cross-channel) sqlite DB. Used for user-level
    preferences that apply to new-channel creation, i.e. anything that must
    be readable before any channel exists. Schema is a single ui_state table."""
    os.makedirs(".collimate", exist_ok=True)
    db_path = ".collimate/app.db"
    cache_key = os.path.abspath(db_path)
    conn = sqlite3.connect(db_path, timeout=5.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute(f"PRAGMA synchronous = {_SYNCHRONOUS};")
    conn.execute("PRAGMA busy_timeout = 5000;")
    if cache_key not in _initialised_dbs:
        _migrations.upgrade_global_db(conn)
        _initialised_dbs.add(cache_key)
    return conn


def get_db_connection(channel_name: str) -> sqlite3.Connection:
    os.makedirs(".collimate/channels", exist_ok=True)
    channel_name = _slug_channel(channel_name)
    db_path = f".collimate/channels/{channel_name}.db"
    cache_key = os.path.abspath(db_path)

    conn = sqlite3.connect(db_path, timeout=5.0)
    conn.row_factory = sqlite3.Row

    # Enforce High-Concurrency WAL mode
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute(f"PRAGMA synchronous = {_SYNCHRONOUS};")
    conn.execute("PRAGMA busy_timeout = 5000;")

    if cache_key not in _initialised_dbs:
        _init_schema(conn)
        _initialised_dbs.add(cache_key)
    return conn


def _init_schema(conn: sqlite3.Connection):
    """Bring this channel's DB up to head.

    Pre-existing DBs created before the migrations framework existed
    will have all the v1-v4 schema elements already (the legacy code did
    the same DDL inline). The migrations framework records each version
    on first run; subsequent runs short-circuit on the already-applied
    set lookup. Idempotent in either direction."""
    # Legacy compatibility: DBs created before this framework set a
    # ``migration_version_meta_done`` flag in ui_state. If we see it,
    # pre-stamp the new schema_migrations table so the v5 backfill
    # doesn't re-run on data that's already been backfilled. The first
    # CREATE TABLE call here is harmless on the truly-fresh path.
    legacy_done = False
    try:
        row = conn.execute(
            "SELECT value FROM ui_state WHERE key='migration_version_meta_done'"
        ).fetchone()
        legacy_done = bool(row)
    except sqlite3.OperationalError:
        # ui_state table doesn't exist yet — definitely a fresh DB.
        pass

    if legacy_done:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS schema_migrations (
                version INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
        """)
        for version, name, _ in _migrations.CHANNEL_MIGRATIONS:
            conn.execute(
                "INSERT OR IGNORE INTO schema_migrations (version, name) "
                "VALUES (?, ?)",
                (version, name),
            )
        conn.commit()

    _migrations.upgrade_channel_db(conn)


def save_ui_state(channel: str, state_json: dict):
    conn = get_db_connection(channel)
    conn.execute(
        "INSERT INTO ui_state (key, value) VALUES ('layout', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(state_json),)
    )
    conn.commit()
    conn.close()
# --- END FILE: api/database.py ---
