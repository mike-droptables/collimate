# --- START FILE: api/database.py ---
import sqlite3
import os
import json

# Track which database files have already had their schema initialised so
# we don't re-run DDL (which takes an EXCLUSIVE lock) on every connection.
_initialised_dbs: set[str] = set()

def _slug_channel(name: str) -> str:
    """Match state.channel_db_name()'s slug rules so URL path params
    (``Starting``) resolve to the same db file as in-memory state
    (``starting``). Keep here (not in state.py) to avoid a circular
    import and so every DB path construction funnels through one rule.
    """
    s = (name or "").lower().replace(" ", "_")
    slug = "".join(c for c in s if c.isalnum() or c in "_-")
    return slug or name


def get_global_db_connection() -> sqlite3.Connection:
    """Open the global (cross-channel) sqlite DB. Used for user-level
    preferences that apply to new-channel creation, i.e. anything that must
    be readable before any channel exists. Schema is a single ui_state table."""
    os.makedirs(".collimate", exist_ok=True)
    db_path = ".collimate/app.db"
    conn = sqlite3.connect(db_path, timeout=5.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA synchronous = NORMAL;")
    conn.execute("PRAGMA busy_timeout = 5000;")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS ui_state (
            key TEXT PRIMARY KEY,
            value TEXT
        );
    """)
    conn.commit()
    return conn


def get_db_connection(channel_name: str) -> sqlite3.Connection:
    os.makedirs(".collimate/channels", exist_ok=True)
    channel_name = _slug_channel(channel_name)
    db_path = f".collimate/channels/{channel_name}.db"

    conn = sqlite3.connect(db_path, timeout=5.0)
    conn.row_factory = sqlite3.Row

    # Enforce High-Concurrency WAL mode
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA synchronous = NORMAL;")
    conn.execute("PRAGMA busy_timeout = 5000;")

    if db_path not in _initialised_dbs:
        _init_schema(conn)
        _initialised_dbs.add(db_path)
    return conn

def _init_schema(conn: sqlite3.Connection):
    conn.executescript("""
        -- CONTENT ADDRESSABLE STORAGE (CAS Metadata)
        CREATE TABLE IF NOT EXISTS blobs (
            hash TEXT PRIMARY KEY, -- STRICTLY SHA-256
            mime_type TEXT,
            size INTEGER
        );

        -- THE RUN (SESSION HISTORY)
        CREATE TABLE IF NOT EXISTS runs (
            id TEXT PRIMARY KEY,
            prompt TEXT,
            status TEXT,           -- 'running', 'completed', 'stopped', 'failed'
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- THE EVENT STREAM (Logs & IPC Backlog)
        CREATE TABLE IF NOT EXISTS run_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id TEXT REFERENCES runs(id),
            event_type TEXT,       -- 'stdout', 'stderr', 'port_bound', 'status_change', 'commit'
            payload TEXT,          -- JSON string
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- THE CELLS (NODES IN THE DAG)
        CREATE TABLE IF NOT EXISTS cells (
            id TEXT PRIMARY KEY,
            run_id TEXT REFERENCES runs(id),
            generator_name TEXT,
            generator_cell_id TEXT REFERENCES cells(id), -- ABSOLUTE DETERMINISM
            sequence_num INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(run_id, sequence_num)
        );

        -- THE DAG EDGES (N-to-M LINEAGE)
        CREATE TABLE IF NOT EXISTS cell_edges (
            parent_cell_id TEXT REFERENCES cells(id),
            child_cell_id TEXT REFERENCES cells(id),
            parent_key TEXT NOT NULL,
            PRIMARY KEY (parent_cell_id, child_cell_id),
            UNIQUE (child_cell_id, parent_key)
        );

        -- THE FILES BRIDGE (Full Workspace Snapshot)
        CREATE TABLE IF NOT EXISTS cell_files (
            cell_id TEXT REFERENCES cells(id),
            filepath TEXT,
            blob_hash TEXT REFERENCES blobs(hash),
            PRIMARY KEY (cell_id, filepath)
        );

        -- THE UI LAYOUT BLOB (Stores the 3D Stacks visual configuration)
        CREATE TABLE IF NOT EXISTS ui_state (
            key TEXT PRIMARY KEY,
            value TEXT
        );

        CREATE TABLE IF NOT EXISTS cell_drafts (
            cell_id TEXT NOT NULL,
            filepath TEXT NOT NULL,
            content_text TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (cell_id, filepath)
        );

        -- DRAFT CELL FILES (pre-run config files for state='Draft' cells)
        CREATE TABLE IF NOT EXISTS draft_cell_files (
            cell_id TEXT NOT NULL REFERENCES cells(id),
            filepath TEXT NOT NULL,
            content_text TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (cell_id, filepath)
        );
    """)
    conn.commit()

    # --- Version metadata migration (v2) ---
    # Add version_name, version_summary, source_type columns to cells and
    # a partial index for fast version-chain walking. These columns move
    # metadata from run_events JSON scanning (O(N)) to direct cell-row
    # lookup (O(1)), and add a source discriminator for the timeline view.
    for col in ("version_name TEXT", "version_summary TEXT", "source_type TEXT"):
        try:
            conn.execute(f"ALTER TABLE cells ADD COLUMN {col}")
        except sqlite3.OperationalError:
            pass  # Column already exists

    # --- Cell state migration (v3): explicit state field + pickoptions JSON ---
    # 'Picking' is reserved for client-side transient cells (never persisted),
    # 'Draft' is a pre-run config cell with files in draft_cell_files,
    # 'Standard' is the default — existing cells and committed/running cells.
    for col in (
        "state TEXT NOT NULL DEFAULT 'Standard'",
        "pickoptions_json TEXT",
    ):
        try:
            conn.execute(f"ALTER TABLE cells ADD COLUMN {col}")
        except sqlite3.OperationalError:
            pass  # Column already exists

    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_cell_edges_prev_version
        ON cell_edges (parent_cell_id, parent_key)
        WHERE parent_key = 'previous_version'
    """)
    conn.commit()

    # One-time backfill: populate new columns from existing data.
    row = conn.execute(
        "SELECT value FROM ui_state WHERE key='migration_version_meta_done'"
    ).fetchone()
    if not row:
        # source_type from generator_name
        conn.executescript("""
            UPDATE cells SET source_type = 'genesis'
                WHERE generator_name = 'genesis' AND source_type IS NULL;
            UPDATE cells SET source_type = 'human_edit'
                WHERE generator_name = 'human_edit' AND source_type IS NULL;
            UPDATE cells SET source_type = 'chat'
                WHERE generator_name = 'chat' AND source_type IS NULL;
            UPDATE cells SET source_type = 'restore'
                WHERE generator_name = 'history_scrubber' AND source_type IS NULL;
            UPDATE cells SET source_type = 'fork'
                WHERE generator_name = 'history_scrubber_fork' AND source_type IS NULL;
            UPDATE cells SET source_type = 'generator'
                WHERE source_type IS NULL AND generator_name IS NOT NULL;
        """)
        # version_name / version_summary from run_events commit payloads
        conn.execute("""
            UPDATE cells SET
                version_name = (
                    SELECT json_extract(re.payload, '$.name')
                    FROM run_events re
                    WHERE re.event_type = 'commit'
                      AND json_extract(re.payload, '$.cell_id') = cells.id
                    ORDER BY re.id DESC LIMIT 1
                ),
                version_summary = (
                    SELECT json_extract(re.payload, '$.summary')
                    FROM run_events re
                    WHERE re.event_type = 'commit'
                      AND json_extract(re.payload, '$.cell_id') = cells.id
                    ORDER BY re.id DESC LIMIT 1
                )
            WHERE version_name IS NULL
        """)
        conn.execute(
            "INSERT OR IGNORE INTO ui_state (key, value) "
            "VALUES ('migration_version_meta_done', '1')"
        )
        conn.commit()


def save_ui_state(channel: str, state_json: dict):
    conn = get_db_connection(channel)
    conn.execute(
        "INSERT INTO ui_state (key, value) VALUES ('layout', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(state_json),)
    )
    conn.commit()
    conn.close()
# --- END FILE: api/database.py ---
