# --- START FILE: api/database.py ---
import os
import sqlite3
import json

import migrations as _migrations

# Track which database files have already had their schema initialised so
# we don't re-run DDL (which takes an EXCLUSIVE lock) on every connection.
# Keyed by absolute path so tests that chdir into different tmp dirs
# don't collide on the relative ``.collimate/channels/<x>.db`` form —
# every distinct DB file gets its own cache entry. Production behaviour
# is unchanged: a long-running server has one stable cwd.
_initialised_dbs: set[str] = set()


def _resolve_synchronous() -> str:
    """Resolve the SQLite ``synchronous`` pragma value.

    Default is ``NORMAL`` (every commit is fsync'd to the journal but
    not to the main DB file) — this matches the historical behaviour
    and keeps the chat-streaming microbatch writer fast. Operators who
    want stronger durability at the cost of an extra fsync per commit
    can set ``COLLIMATE_SQLITE_SYNCHRONOUS=FULL`` in the environment.

    Anything other than the four documented values silently falls back
    to NORMAL — better a known-good pragma than a typo wedging the
    server.
    """
    value = (os.environ.get("COLLIMATE_SQLITE_SYNCHRONOUS") or "NORMAL").strip().upper()
    if value not in ("OFF", "NORMAL", "FULL", "EXTRA"):
        value = "NORMAL"
    return value


_SYNCHRONOUS = _resolve_synchronous()

def _slug_channel(name: str) -> str:
    """Match state.channel_db_name()'s slug rules so URL path params
    (``Starting``) resolve to the same db file as in-memory state
    (``starting``). Keep here (not in state.py) to avoid a circular
    import and so every DB path construction funnels through one rule.
    """
    s = (name or "").lower().replace(" ", "_")
    slug = "".join(c for c in s if c.isalnum() or c in "_-")
    return slug or name


def get_global_db_connection() -> sqlite3.Connection:
    """Open the global (cross-channel) sqlite DB. Used for user-level
    preferences that apply to new-channel creation, i.e. anything that must
    be readable before any channel exists. Schema is a single ui_state table."""
    os.makedirs(".collimate", exist_ok=True)
    db_path = ".collimate/app.db"
    cache_key = os.path.abspath(db_path)
    conn = sqlite3.connect(db_path, timeout=5.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute(f"PRAGMA synchronous = {_SYNCHRONOUS};")
    conn.execute("PRAGMA busy_timeout = 5000;")
    if cache_key not in _initialised_dbs:
        _migrations.upgrade_global_db(conn)
        _initialised_dbs.add(cache_key)
    return conn


def get_db_connection(channel_name: str) -> sqlite3.Connection:
    os.makedirs(".collimate/channels", exist_ok=True)
    channel_name = _slug_channel(channel_name)
    db_path = f".collimate/channels/{channel_name}.db"
    cache_key = os.path.abspath(db_path)

    conn = sqlite3.connect(db_path, timeout=5.0)
    conn.row_factory = sqlite3.Row

    # Enforce High-Concurrency WAL mode
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute(f"PRAGMA synchronous = {_SYNCHRONOUS};")
    conn.execute("PRAGMA busy_timeout = 5000;")

    if cache_key not in _initialised_dbs:
        _init_schema(conn)
        _initialised_dbs.add(cache_key)
    return conn


def channel_db_exists(channel_name: str) -> bool:
    """True if a channel's sqlite db file already exists on disk.

    Read-only callers (e.g. loading saved UI state) use this to avoid
    connecting to a non-existent channel: ``sqlite3.connect`` would otherwise
    CREATE an empty db file. Under the no-default-channel model that empty file
    is a "ghost" channel — absent from ``state.channels``, unselectable in the
    UI, yet present on disk, so reads against it return phantom data instead of
    failing. (The wasm demo legitimately seeds a ``starting`` channel; native
    must never materialize one as a side effect.)"""
    db_path = f".collimate/channels/{_slug_channel(channel_name)}.db"
    return os.path.exists(db_path)


def _init_schema(conn: sqlite3.Connection):
    """Bring this channel's DB up to head. A fresh DB runs the single
    schema migration; an already-current DB short-circuits on the
    applied-version lookup."""
    _migrations.upgrade_channel_db(conn)


def forget_db(channel_name: str) -> None:
    """Drop the schema-init cache entry for a channel db so the next
    connection re-runs DDL.

    Must be called after a channel's db file is deleted or moved on disk:
    ``_initialised_dbs`` is keyed by abspath, so without this a channel
    recreated under the same name (same slug → same path) would reuse the
    "already initialised" marker and connect to a now-tableless file. With
    last-channel deletion allowed, that delete→recreate cycle is reachable."""
    channel_name = _slug_channel(channel_name)
    db_path = f".collimate/channels/{channel_name}.db"
    _initialised_dbs.discard(os.path.abspath(db_path))


def save_ui_state(channel: str, state_json: dict):
    conn = get_db_connection(channel)
    conn.execute(
        "INSERT INTO ui_state (key, value) VALUES ('layout', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(state_json),)
    )
    conn.commit()
    conn.close()
# --- END FILE: api/database.py ---
