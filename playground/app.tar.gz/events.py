"""
Event broadcast hub for SSE state streaming.

Provides a simple channel-based pub/sub system using asyncio.Queue.
Subscribers receive events pushed by the backend (DAG commits, status changes).
All operations must be called from the event loop thread.

Backpressure policy: when a subscriber's queue is full (slow client,
suspended browser tab) the broadcaster places a sentinel on the queue
instead of dropping the event silently. The SSE handler sees the
sentinel, closes the connection with 503, and the EventSource's built-
in retry kicks in. Reconnect re-fetches the canonical state from
``/api/state`` so the client's view is consistent regardless of how
many events were missed.
"""

import asyncio
import logging
from collections import defaultdict

logger = logging.getLogger(__name__)


# Marker put on a subscriber queue when broadcast() encounters a full
# queue. The SSE handler treats receipt of this object as "your stream
# is stale, close the connection and let the client reconnect."
OVERFLOW_SENTINEL: dict = {"__overflow__": True}


_subscribers: dict[str, list[asyncio.Queue]] = defaultdict(list)
_main_loop = None


def _slug(name: str) -> str:
    """Same slug rule used by state.channel_db_name() and database
    get_db_connection, so SSE channel keys are unified regardless of
    URL casing (``Starting`` vs ``starting``)."""
    s = (name or "").lower().replace(" ", "_")
    out = "".join(c for c in s if c.isalnum() or c in "_-")
    return out or name


def capture_loop():
    """Capture the main event loop early so broadcast() works before any
    subscriber connects. Called from the FastAPI lifespan startup."""
    global _main_loop
    if _main_loop is None:
        try:
            _main_loop = asyncio.get_running_loop()
        except RuntimeError:
            pass


def subscribe(channel: str) -> asyncio.Queue:
    """Create a new subscriber queue for a channel's event stream."""
    capture_loop()
    channel = _slug(channel)
    q: asyncio.Queue = asyncio.Queue(maxsize=256)
    _subscribers[channel].append(q)
    return q


def unsubscribe(channel: str, q: asyncio.Queue):
    """Remove a subscriber queue."""
    channel = _slug(channel)
    try:
        _subscribers[channel].remove(q)
    except ValueError:
        pass
    if not _subscribers[channel]:
        del _subscribers[channel]


def broadcast(channel: str, event: dict):
    """Push an event to all subscribers of a channel. Thread-safe."""
    global _main_loop
    channel = _slug(channel)

    def _put():
        for q in _subscribers.get(channel, []):
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                # Slow consumer (suspended tab, lagging client). The
                # buffered events are now stale anyway — the client
                # will need to refetch /api/state on reconnect — so
                # drop the entire backlog and post a single overflow
                # sentinel. The SSE handler converts that into a final
                # ``{"type": "overflow"}`` event + close, and the
                # EventSource auto-reconnects.
                logger.warning(
                    "SSE backpressure: dropping %d-event backlog on full queue "
                    "for channel %r; closing stream to force client reconnect",
                    q.qsize(), channel,
                )
                try:
                    while not q.empty():
                        q.get_nowait()
                except asyncio.QueueEmpty:
                    pass
                try:
                    q.put_nowait(OVERFLOW_SENTINEL)
                except asyncio.QueueFull:
                    pass

    try:
        current_loop = asyncio.get_running_loop()
        # Capture the loop on first use if startup didn't get it
        if _main_loop is None:
            _main_loop = current_loop
        if current_loop is _main_loop:
            _put()
            return
    except RuntimeError:
        pass

    if _main_loop is not None and not _main_loop.is_closed():
        _main_loop.call_soon_threadsafe(_put)


# Per-channel pending timers for broadcast_coalesced().
_pending_coalesced: dict[str, object] = {}


def broadcast_coalesced(channel: str, build_event, delay: float = 0.25):
    """Coalesce bursts of an expensive per-channel broadcast.

    Schedules ``build_event()`` to run on the main loop after ``delay``
    seconds and broadcasts its result; further calls for the same channel
    while one is pending are absorbed into it. The event is built fresh at
    fire time, so the latest state wins — this is what keeps a commit burst
    (e.g. a generator checkpointing several times in a second) from shipping
    a full serialized app state per commit. ``build_event`` may return None
    to skip. Thread-safe like :func:`broadcast`."""
    global _main_loop
    channel = _slug(channel)

    def _schedule():
        if channel in _pending_coalesced:
            return
        if not _subscribers.get(channel):
            # Nobody listening — don't burn a timer + build (a fresh
            # subscriber refetches /api/state on connect anyway).
            return

        def _build_and_send():
            try:
                event = build_event()
            except Exception:
                logger.exception(
                    "coalesced broadcast build failed for channel %r", channel,
                )
                return
            if event:
                broadcast(channel, event)

        def _fire():
            _pending_coalesced.pop(channel, None)
            # Building can be expensive (a full state dump) — keep it off
            # the event loop; broadcast() is thread-safe.
            try:
                asyncio.get_running_loop().run_in_executor(None, _build_and_send)
            except RuntimeError:
                _build_and_send()

        _pending_coalesced[channel] = asyncio.get_running_loop().call_later(
            delay, _fire,
        )

    try:
        current_loop = asyncio.get_running_loop()
        if _main_loop is None:
            _main_loop = current_loop
        if current_loop is _main_loop:
            _schedule()
            return
    except RuntimeError:
        pass

    if _main_loop is not None and not _main_loop.is_closed():
        _main_loop.call_soon_threadsafe(_schedule)


def broadcast_all(event: dict):
    """Push an event to every subscriber across all channels. Used for
    system-wide notifications (e.g. server shutdown) where no single
    channel is meaningful. Same loop-dispatch + backpressure semantics
    as :func:`broadcast`."""
    global _main_loop

    def _put():
        for channel_subs in list(_subscribers.values()):
            for q in list(channel_subs):
                try:
                    q.put_nowait(event)
                except asyncio.QueueFull:
                    # On a global broadcast we can't usefully reset
                    # individual channel state, so just drop. The client
                    # will reconnect and refetch on its own.
                    pass

    try:
        current_loop = asyncio.get_running_loop()
        if _main_loop is None:
            _main_loop = current_loop
        if current_loop is _main_loop:
            _put()
            return
    except RuntimeError:
        pass

    if _main_loop is not None and not _main_loop.is_closed():
        _main_loop.call_soon_threadsafe(_put)
