"""
Event broadcast hub for SSE state streaming.

Provides a simple channel-based pub/sub system using asyncio.Queue.
Subscribers receive events pushed by the backend (DAG commits, status changes).
All operations must be called from the event loop thread.
"""

import asyncio
from collections import defaultdict


_subscribers: dict[str, list[asyncio.Queue]] = defaultdict(list)
_main_loop = None


def _slug(name: str) -> str:
    """Same slug rule used by state.channel_db_name() and database
    get_db_connection, so SSE channel keys are unified regardless of
    URL casing (``Starting`` vs ``starting``)."""
    s = (name or "").lower().replace(" ", "_")
    out = "".join(c for c in s if c.isalnum() or c in "_-")
    return out or name


def capture_loop():
    """Capture the main event loop early so broadcast() works before any
    subscriber connects. Called from the FastAPI lifespan startup."""
    global _main_loop
    if _main_loop is None:
        try:
            _main_loop = asyncio.get_running_loop()
        except RuntimeError:
            pass


def subscribe(channel: str) -> asyncio.Queue:
    """Create a new subscriber queue for a channel's event stream."""
    capture_loop()
    channel = _slug(channel)
    q: asyncio.Queue = asyncio.Queue(maxsize=256)
    _subscribers[channel].append(q)
    return q


def unsubscribe(channel: str, q: asyncio.Queue):
    """Remove a subscriber queue."""
    channel = _slug(channel)
    try:
        _subscribers[channel].remove(q)
    except ValueError:
        pass
    if not _subscribers[channel]:
        del _subscribers[channel]


def broadcast(channel: str, event: dict):
    """Push an event to all subscribers of a channel. Thread-safe."""
    global _main_loop
    channel = _slug(channel)

    def _put():
        for q in _subscribers.get(channel, []):
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                pass  # Drop events for slow consumers rather than blocking

    try:
        current_loop = asyncio.get_running_loop()
        # Capture the loop on first use if startup didn't get it
        if _main_loop is None:
            _main_loop = current_loop
        if current_loop is _main_loop:
            _put()
            return
    except RuntimeError:
        pass

    if _main_loop is not None and not _main_loop.is_closed():
        _main_loop.call_soon_threadsafe(_put)
