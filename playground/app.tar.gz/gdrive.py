"""Google Drive service layer for the native-only "gdrive" sync surface.

A peer of ``backup.py``: pure auth + Drive-API I/O. HTTP wrapping + wasm guards
live in ``routes/gdrive.py``; VirtualFile / CAS shaping lives there too, so this
module only knows about Drive (list / download / upload / folders) and the OAuth
token lifecycle.

OAuth model — *user-provided* client (see the plan): the user pastes their own
``client_id`` / ``client_secret`` (a "Desktop app" OAuth client, which permits
the loopback redirect). We run the installed-app loopback flow, then keep the
authorized-user JSON (incl. the refresh token) in the OS keychain via
``keystore.py`` so the login survives restarts.

The Google libraries are imported lazily inside each function so that merely
importing this module (at server startup) never fails when the optional deps are
absent — callers get a clean ``GdriveError`` instead of an ImportError crash.
"""
from __future__ import annotations

import json
import logging

import keystore

_logger = logging.getLogger("gdrive")

# Keystore entries. The client creds are entered in Settings; the token is
# written by the login flow. Both are JSON strings (keystore stores str values).
_CLIENT_KEY = "gdrive_client"   # {"client_id": ..., "client_secret": ...}
_TOKEN_KEY = "gdrive_token"     # Credentials.to_json() + an "email" field
_EMAIL_KEY = "gdrive_email"     # cached account email for cheap status reads

# Full Drive scope — required for free browsing of the user's whole Drive
# (drive.file would only see app-created/opened files). This is a Google
# "restricted" scope; the user's own OAuth client in testing mode is fine.
SCOPES = ["https://www.googleapis.com/auth/drive"]

FOLDER_MIME = "application/vnd.google-apps.folder"
ROOT_ID = "root"

# Caps mirror routes/fs.py so one listing / collect can't pull unbounded work.
MAX_ENTRIES = 5000
_LOGIN_TIMEOUT_SECONDS = 180
_MAX_BREADCRUMB_DEPTH = 40


class GdriveError(Exception):
    """A Drive operation failed (config, network, or API error)."""


class GdriveAuthError(GdriveError):
    """Not signed in / no usable credentials — caller maps to 401."""


# ---------------------------------------------------------------------------
# Credentials (client id/secret) — entered in Settings
# ---------------------------------------------------------------------------

def set_credentials(client_id: str, client_secret: str) -> None:
    client_id = (client_id or "").strip()
    client_secret = (client_secret or "").strip()
    if not client_id or not client_secret:
        raise GdriveError("client_id and client_secret are required")
    ok = keystore.set_key(_CLIENT_KEY, json.dumps({
        "client_id": client_id, "client_secret": client_secret,
    }))
    if not ok:
        raise GdriveError("could not persist credentials (no OS keychain available)")


def _load_client() -> dict | None:
    raw = keystore.get_key(_CLIENT_KEY)
    if not raw:
        return None
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        return None
    if not (data.get("client_id") and data.get("client_secret")):
        return None
    return data


def has_credentials() -> bool:
    return _load_client() is not None


def _client_config() -> dict:
    client = _load_client()
    if not client:
        raise GdriveError("Google Drive credentials are not configured")
    # The shape google_auth_oauthlib.flow.InstalledAppFlow.from_client_config
    # expects for a Desktop / installed-app client.
    return {
        "installed": {
            "client_id": client["client_id"],
            "client_secret": client["client_secret"],
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "redirect_uris": ["http://localhost"],
        }
    }


# ---------------------------------------------------------------------------
# Token lifecycle
# ---------------------------------------------------------------------------

def _stored_token() -> dict | None:
    raw = keystore.get_key(_TOKEN_KEY)
    if not raw:
        return None
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        return None


def auth_status() -> dict:
    """Cheap, network-free status for the Settings UI / Drive views."""
    return {
        "has_credentials": has_credentials(),
        "authenticated": _stored_token() is not None,
        "email": keystore.get_key(_EMAIL_KEY),
    }


def logout() -> None:
    keystore.delete_key(_TOKEN_KEY)
    keystore.delete_key(_EMAIL_KEY)


def start_login() -> dict:
    """Run the installed-app loopback flow (opens the browser, captures the
    redirect on an ephemeral local port), persist the resulting token, and
    return ``{"email": ...}``. Blocking — call via ``asyncio.to_thread``."""
    try:
        from google_auth_oauthlib.flow import InstalledAppFlow
    except ImportError as exc:  # pragma: no cover - dep guaranteed in the wheel
        raise GdriveError(
            "google-auth-oauthlib is not installed; cannot sign in to Google Drive"
        ) from exc

    flow = InstalledAppFlow.from_client_config(_client_config(), SCOPES)
    try:
        creds = flow.run_local_server(
            port=0, open_browser=True, timeout_seconds=_LOGIN_TIMEOUT_SECONDS,
        )
    except Exception as exc:  # noqa: BLE001 — surface any flow failure as our error
        raise GdriveError(f"Google sign-in did not complete: {exc}") from exc

    keystore.set_key(_TOKEN_KEY, creds.to_json())
    email = _fetch_email(creds)
    if email:
        keystore.set_key(_EMAIL_KEY, email)
    return {"email": email}


def _credentials():
    """Return refreshed google credentials, persisting a refreshed token.
    Raises GdriveAuthError when not signed in."""
    info = _stored_token()
    if not info:
        raise GdriveAuthError("Not signed in to Google Drive")
    try:
        from google.oauth2.credentials import Credentials
        from google.auth.transport.requests import Request
    except ImportError as exc:  # pragma: no cover
        raise GdriveError("google-auth is not installed") from exc

    creds = Credentials.from_authorized_user_info(info, SCOPES)
    if creds.expired and creds.refresh_token:
        try:
            creds.refresh(Request())
            keystore.set_key(_TOKEN_KEY, creds.to_json())
        except Exception as exc:  # noqa: BLE001 — revoked / network → re-auth
            raise GdriveAuthError(f"Could not refresh Google credentials: {exc}") from exc
    if not creds.valid:
        raise GdriveAuthError("Google credentials are not valid; sign in again")
    return creds


def _service(creds=None):
    try:
        from googleapiclient.discovery import build
    except ImportError as exc:  # pragma: no cover
        raise GdriveError("google-api-python-client is not installed") from exc
    return build("drive", "v3", credentials=creds or _credentials(), cache_discovery=False)


def service():
    """Build one authorized Drive client. Callers doing many ops in a row
    (collect / write) build once and thread it through the ``svc`` params below
    to avoid rebuilding the client per file."""
    return _service()


def _fetch_email(creds) -> str | None:
    try:
        about = _service(creds).about().get(fields="user(emailAddress)").execute()
        return (about.get("user") or {}).get("emailAddress")
    except Exception:  # noqa: BLE001 — email is best-effort metadata
        return None


# ---------------------------------------------------------------------------
# Drive I/O
# ---------------------------------------------------------------------------

def _entry(f: dict) -> dict:
    is_folder = f.get("mimeType") == FOLDER_MIME
    size = f.get("size")
    return {
        "id": f["id"],
        "name": f.get("name") or "(unnamed)",
        "kind": "dir" if is_folder else "file",
        "size": None if is_folder or size is None else int(size),
        "mimeType": f.get("mimeType"),
    }


def list_folder(folder_id: str | None, svc=None, with_breadcrumb: bool = True) -> dict:
    """List a Drive folder's direct children (folders first, then files; both
    name-sorted), with a breadcrumb of ancestors. ``folder_id`` defaults to the
    My Drive root. ``with_breadcrumb=False`` skips the ancestor walk (used by
    the recursive collect, which only needs the entries)."""
    folder_id = folder_id or ROOT_ID
    svc = svc or _service()
    try:
        meta = svc.files().get(
            fileId=folder_id, fields="id, name, parents",
            supportsAllDrives=True,
        ).execute()
        entries: list[dict] = []
        truncated = False
        page_token = None
        while True:
            resp = svc.files().list(
                q=f"'{folder_id}' in parents and trashed = false",
                fields="nextPageToken, files(id, name, mimeType, size)",
                pageSize=200, orderBy="folder,name",
                supportsAllDrives=True, includeItemsFromAllDrives=True,
                pageToken=page_token,
            ).execute()
            for f in resp.get("files", []):
                if len(entries) >= MAX_ENTRIES:
                    truncated = True
                    break
                entries.append(_entry(f))
            page_token = resp.get("nextPageToken")
            if truncated or not page_token:
                break
    except (GdriveError,):
        raise
    except Exception as exc:  # noqa: BLE001 — googleapiclient HttpError etc.
        raise GdriveError(_describe(exc)) from exc

    parents = meta.get("parents") or []
    parent_id = parents[0] if parents else None
    return {
        "folder_id": meta["id"],
        "name": meta.get("name") or "My Drive",
        "parent_id": parent_id,
        "path": _breadcrumb(svc, meta) if with_breadcrumb else [],
        "entries": entries,
        "truncated": truncated,
    }


def _breadcrumb(svc, meta: dict) -> list[dict]:
    """Build [{id,name}] from the root down to (and including) ``meta``."""
    chain = [{"id": meta["id"], "name": meta.get("name") or "My Drive"}]
    parents = meta.get("parents") or []
    depth = 0
    while parents and depth < _MAX_BREADCRUMB_DEPTH:
        pid = parents[0]
        try:
            p = svc.files().get(fileId=pid, fields="id, name, parents",
                                supportsAllDrives=True).execute()
        except Exception:  # noqa: BLE001 — a missing/shared ancestor ends the walk
            break
        chain.insert(0, {"id": p["id"], "name": p.get("name") or "My Drive"})
        parents = p.get("parents") or []
        depth += 1
    return chain


def get_meta(file_id: str, svc=None) -> dict:
    svc = svc or _service()
    try:
        f = svc.files().get(fileId=file_id, fields="id, name, mimeType, size",
                            supportsAllDrives=True).execute()
    except Exception as exc:  # noqa: BLE001
        raise GdriveError(_describe(exc)) from exc
    return _entry(f)


def download_bytes(file_id: str, svc=None) -> bytes:
    """Raw bytes of a Drive file. Raises GdriveError for Google-native docs
    (Sheets/Docs have no direct media) so callers can skip them gracefully."""
    svc = svc or _service()
    try:
        meta = svc.files().get(fileId=file_id, fields="mimeType",
                               supportsAllDrives=True).execute()
        if (meta.get("mimeType") or "").startswith("application/vnd.google-apps"):
            raise GdriveError("Google-native files cannot be downloaded directly")
        return svc.files().get_media(fileId=file_id, supportsAllDrives=True).execute()
    except GdriveError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise GdriveError(_describe(exc)) from exc


def find_child(parent_id: str, name: str, *, folder: bool | None = None, svc=None) -> str | None:
    """Return the id of a direct child named ``name`` under ``parent_id``, or
    None. ``folder=True/False`` restricts to folders / non-folders."""
    svc = svc or _service()
    safe = name.replace("\\", "\\\\").replace("'", "\\'")
    q = f"'{parent_id}' in parents and name = '{safe}' and trashed = false"
    if folder is True:
        q += f" and mimeType = '{FOLDER_MIME}'"
    elif folder is False:
        q += f" and mimeType != '{FOLDER_MIME}'"
    try:
        resp = svc.files().list(
            q=q, fields="files(id, name)", pageSize=1,
            supportsAllDrives=True, includeItemsFromAllDrives=True,
        ).execute()
    except Exception as exc:  # noqa: BLE001
        raise GdriveError(_describe(exc)) from exc
    files = resp.get("files", [])
    return files[0]["id"] if files else None


def ensure_subfolder(parent_id: str, name: str, svc=None) -> str:
    """Find-or-create a child folder named ``name`` under ``parent_id``."""
    svc = svc or _service()
    existing = find_child(parent_id, name, folder=True, svc=svc)
    if existing:
        return existing
    try:
        created = svc.files().create(
            body={"name": name, "mimeType": FOLDER_MIME, "parents": [parent_id]},
            fields="id", supportsAllDrives=True,
        ).execute()
    except Exception as exc:  # noqa: BLE001
        raise GdriveError(_describe(exc)) from exc
    return created["id"]


def upload_file(parent_id: str, name: str, data: bytes, mime: str,
                existing_id: str | None = None, svc=None) -> str:
    """Create (or update ``existing_id``) a file named ``name`` under
    ``parent_id`` with ``data``. Returns the file id."""
    try:
        from googleapiclient.http import MediaIoBaseUpload
    except ImportError as exc:  # pragma: no cover
        raise GdriveError("google-api-python-client is not installed") from exc
    import io

    svc = svc or _service()
    media = MediaIoBaseUpload(io.BytesIO(data), mimetype=mime or "application/octet-stream",
                              resumable=False)
    try:
        if existing_id:
            f = svc.files().update(fileId=existing_id, media_body=media, fields="id",
                                   supportsAllDrives=True).execute()
        else:
            f = svc.files().create(body={"name": name, "parents": [parent_id]},
                                   media_body=media, fields="id",
                                   supportsAllDrives=True).execute()
    except Exception as exc:  # noqa: BLE001
        raise GdriveError(_describe(exc)) from exc
    return f["id"]


def _describe(exc: Exception) -> str:
    """Best-effort human message for a googleapiclient HttpError or other."""
    try:
        from googleapiclient.errors import HttpError
        if isinstance(exc, HttpError):
            status = getattr(getattr(exc, "resp", None), "status", "?")
            return f"Drive API error {status}: {exc.reason or exc}"
    except ImportError:
        pass
    return str(exc) or exc.__class__.__name__
