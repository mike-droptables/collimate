"""Genesis bootstrapping — initialises .collimate/ on first CWD launch."""
import os
import json
import hashlib
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path

GENESIS_MARKER = os.path.join(".collimate", ".genesis")
_API_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_API_DIR)
TEMPLATES_DIR = os.path.join(_API_DIR, "templates")


def _resolve_assets_dir(kind: str) -> str:
    """Return the directory to read generator/renderer assets from.

    Resolution order:
      1. api/templates/<asset>/ vendored by build_server.sh or vendor_defaults.
      2. The installed collimate-sdk wheel's package data
         (collimate/<asset>/ via importlib.resources). This is what pyodide
         and plain `pip install collimate-sdk` see.
      3. A sibling directory next to the installed `collimate` package —
         handles editable installs where the asset dirs live at the SDK
         repo root as siblings of src/ (see the SDK's [tool.hatch.build.
         targets.wheel.force-include] which only kicks in at wheel time).

    ``kind`` is ``"generators"`` or ``"renderers"``. Under pyodide (IS_WASM)
    the generators asset swaps to ``generators-wasm`` so new channels seed
    with the playground-safe subset authored against collimate.wasm_sdk.
    Renderers are browser-side JS and need no per-runtime variant.
    """
    from runtime import IS_WASM
    sdk_asset_name = "generators-wasm" if (kind == "generators" and IS_WASM) else kind

    # 1. Vendored into api/templates/
    local = os.path.join(TEMPLATES_DIR, sdk_asset_name)
    if os.path.isdir(local) and os.listdir(local):
        return local

    # 2. Installed package resource (wheel install, including pyodide).
    try:
        from importlib.resources import files, as_file
        resource = files("collimate").joinpath(sdk_asset_name)
        with as_file(resource) as p:
            if p.is_dir() and os.listdir(p):
                return str(p)
    except (ModuleNotFoundError, FileNotFoundError):
        pass

    # 3. Editable-install fallback: asset dir as a sibling of src/.
    try:
        import collimate as _collimate_pkg
        pkg_dir = os.path.dirname(os.path.abspath(_collimate_pkg.__file__))
        sdk_root = os.path.dirname(os.path.dirname(pkg_dir))
        sibling = os.path.join(sdk_root, sdk_asset_name)
        if os.path.isdir(sibling) and os.listdir(sibling):
            return sibling
    except (ImportError, OSError):
        pass

    return local  # last-ditch fallback so callers get consistent error paths


GENERATORS_DIR = _resolve_assets_dir("generators")
RENDERERS_DIR = _resolve_assets_dir("renderers")

# Fixed genesis run ID (deterministic, not random)
GENESIS_RUN_ID = "00000000-0000-0000-0000-000000000001"


def is_bootstrapped() -> bool:
    return os.path.exists(GENESIS_MARKER)


def _hash_file(path: str) -> str:
    sha256 = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            sha256.update(chunk)
    return sha256.hexdigest()


def _store_blob(file_path: str, blob_hash: str) -> str:
    """Atomically copy a file into the CAS. Returns the CAS path."""
    cas_dir = os.path.join(".collimate", "objects", blob_hash[:2])
    cas_path = os.path.join(cas_dir, blob_hash[2:])
    if not os.path.exists(cas_path):
        os.makedirs(cas_dir, exist_ok=True)
        tmp = cas_path + ".tmp"
        shutil.copy2(file_path, tmp)
        os.replace(tmp, cas_path)
    return cas_path


def _store_bytes_blob(content: bytes) -> str:
    """Hash bytes, store in the CAS (no-op if already present), return hex sha256."""
    blob_hash = hashlib.sha256(content).hexdigest()
    cas_dir = os.path.join(".collimate", "objects", blob_hash[:2])
    cas_path = os.path.join(cas_dir, blob_hash[2:])
    if not os.path.exists(cas_path):
        os.makedirs(cas_dir, exist_ok=True)
        tmp = cas_path + ".tmp"
        with open(tmp, "wb") as f:
            f.write(content)
        os.replace(tmp, cas_path)
    return blob_hash


def _seed_cell_from_vfiles(conn, run_id: str, cell_id: str, cell_name: str,
                           seq: int, summary: str, vfiles) -> None:
    """Persist an in-memory cell: insert the cell row and each VirtualFile's
    content into the CAS + blobs + cell_files tables. Mirrors `_seed_directory`
    but reads content from VirtualFile objects instead of disk paths."""
    conn.execute(
        "INSERT OR IGNORE INTO cells (id, run_id, generator_name, sequence_num, "
        "version_name, version_summary, source_type) "
        "VALUES (?, ?, 'genesis', ?, ?, ?, 'genesis')",
        (cell_id, run_id, seq, cell_name, summary),
    )
    for vf in vfiles:
        content = vf.content.encode("utf-8")
        blob_hash = _store_bytes_blob(content)
        conn.execute(
            "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
            (blob_hash, len(content)),
        )
        conn.execute(
            "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
            "VALUES (?, ?, ?)",
            (cell_id, vf.name, blob_hash),
        )


def _seed_directory(conn, run_id: str, dir_path: str, cell_id: str,
                    cell_name: str, seq: int, filepath_prefix: str):
    """Walk a template directory, store all files in the CAS, create a DAG cell."""
    if not os.path.isdir(dir_path):
        return

    conn.execute(
        "INSERT OR IGNORE INTO cells (id, run_id, generator_name, sequence_num, "
        "version_name, version_summary, source_type) "
        "VALUES (?, ?, 'genesis', ?, ?, 'Seeded from template', 'genesis')",
        (cell_id, run_id, seq, cell_name),
    )

    for root, _dirs, files in os.walk(dir_path):
        _dirs[:] = [d for d in _dirs if not d.startswith("__")]
        for filename in sorted(files):
            if filename.startswith("__"):
                continue
            abs_path = os.path.join(root, filename)
            rel_to_dir = os.path.relpath(abs_path, dir_path)
            filepath = f"{filepath_prefix}/{rel_to_dir}".replace("\\", "/")

            blob_hash = _hash_file(abs_path)
            _store_blob(abs_path, blob_hash)
            size = os.path.getsize(abs_path)

            conn.execute(
                "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                (blob_hash, size),
            )
            conn.execute(
                "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                "VALUES (?, ?, ?)",
                (cell_id, filepath, blob_hash),
            )


def seed_channel(channel_name: str, ch):
    from database import get_db_connection
    from models import Stack, Cell, VirtualFile
    conn = get_db_connection(channel_name)
    
    # Use deterministic run ID for 'starting', random otherwise
    run_id = GENESIS_RUN_ID if channel_name == "starting" else str(uuid.uuid4())
    
    conn.execute(
        "INSERT OR IGNORE INTO runs (id, prompt, status) VALUES (?, ?, 'completed')",
        (run_id, "Channel initialization"),
    )

    seq = 0

    _ren_lang_map = {".js": "javascript", ".ts": "typescript", ".tsx": "typescript",
                     ".jsx": "javascript", ".yaml": "yaml", ".yml": "yaml", ".json": "json",
                     ".css": "css", ".html": "html", ".md": "markdown",
                     ".gen_yaml": "yaml", ".rend_yaml": "yaml", ".set_yaml": "yaml"}
    _gen_lang_map = {".py": "python", ".yaml": "yaml", ".yml": "yaml", ".json": "json",
                     ".md": "markdown", ".sh": "shell", ".dockerfile": "dockerfile",
                     ".gen_yaml": "yaml", ".rend_yaml": "yaml", ".set_yaml": "yaml"}

    def _list_groups(parent_dir: str) -> list[str]:
        if not os.path.isdir(parent_dir):
            return []
        return sorted(
            d for d in os.listdir(parent_dir)
            if not d.startswith("__") and not d.startswith(".")
            and os.path.isdir(os.path.join(parent_dir, d))
        )

    def _group_display_name(group: str) -> str:
        return group.replace("_", " ").replace("-", " ").title()

    def _build_group_vfiles(group_dir: str, prefix: str, lang_map: dict) -> list:
        vfiles = []
        for root, dirs, files in os.walk(group_dir):
            dirs[:] = [d for d in dirs if not d.startswith("__")]
            for f in sorted(files):
                if f.startswith("__"):
                    continue
                abs_path = os.path.join(root, f)
                rel = os.path.relpath(abs_path, group_dir).replace("\\", "/")
                ext = os.path.splitext(f)[1]
                lang = lang_map.get(ext, "text")
                with open(abs_path, "r", encoding="utf-8") as fb:
                    vfiles.append(VirtualFile(
                        name=f"{prefix}/{rel}",
                        content=fb.read(),
                        language=lang,
                    ))
        return vfiles

    def _seed_stack_from_overrides(conn, run_id: str, channel_name: str,
                                   cfg: dict, seq: int) -> int:
        """Build one gen/rend stack from user_settings defaults instead of
        walking the SDK templates dir. Supports bundle:// (reads from an SDK
        bundle root) and data: (reads a .colgen/.colrend archive)."""
        from user_settings import bundle_root_for, resolve_source_to_bytes
        from collimate.packaging import read_archive, PackageError

        stack_type = cfg["stack_type"]
        lang_map = cfg["lang_map"]
        bundle_root = bundle_root_for(stack_type)
        stack = Stack(name=cfg["stack_name"], stack_type=stack_type)

        for entry_idx, entry in enumerate(cfg["overrides"]):
            source = entry.get("source", "")
            entry_name = entry.get("name", "") or "Imported"

            if source.startswith("bundle://"):
                bundle_name = source[len("bundle://"):]
                if not bundle_root or not (bundle_root / bundle_name).is_dir():
                    print(f"[genesis] skipping unknown bundle {source!r}")
                    continue
                seq += 1
                prefix = f"{stack_type}s/{bundle_name}"
                cell_id = str(uuid.uuid5(
                    uuid.NAMESPACE_DNS,
                    f"{prefix}-{channel_name}-override-{entry_idx}",
                ))
                _seed_directory(
                    conn, run_id=run_id, dir_path=str(bundle_root / bundle_name),
                    cell_id=cell_id, cell_name=entry_name or _group_display_name(bundle_name),
                    seq=seq, filepath_prefix=prefix,
                )
                vfiles = _build_group_vfiles(
                    str(bundle_root / bundle_name), prefix=prefix, lang_map=lang_map,
                )
                stack.cells.append(Cell(
                    id=cell_id,
                    name=entry_name or _group_display_name(bundle_name),
                    summary=f"{stack_type.capitalize()}s in the {bundle_name} group.",
                    files=vfiles,
                ))
                continue

            if source.startswith("data:"):
                try:
                    raw = resolve_source_to_bytes(source, bundle_root)
                    manifest = read_archive(raw)
                except (ValueError, PackageError) as e:
                    print(f"[genesis] skipping bad data: entry {entry_name!r}: {e}")
                    continue
                for cell_spec in manifest.cells:
                    seq += 1
                    cell_id = str(uuid.uuid5(
                        uuid.NAMESPACE_DNS,
                        f"{stack_type}-data-{channel_name}-{entry_idx}-{cell_spec.id}",
                    ))
                    vfiles = [
                        VirtualFile(
                            name=f"{stack_type}s/{entry_name}/{f.name}",
                            language=f.language,
                            content=f.content,
                        )
                        for f in cell_spec.files
                    ]
                    _seed_cell_from_vfiles(
                        conn, run_id=run_id, cell_id=cell_id,
                        cell_name=cell_spec.name or entry_name, seq=seq,
                        summary=cell_spec.summary or "",
                        vfiles=vfiles,
                    )
                    stack.cells.append(Cell(
                        id=cell_id,
                        name=cell_spec.name or entry_name,
                        summary=cell_spec.summary or "",
                        files=vfiles,
                    ))
                continue

            print(f"[genesis] skipping unsupported source scheme: {source!r}")

        if stack.cells:
            cfg["attach_to"].append(stack)
        return seq

    # ── Load user-level default overrides (may be empty) ──
    try:
        from user_settings import load_settings
        user_defaults = load_settings().get("defaults", {}) or {}
    except Exception:
        user_defaults = {}

    # Each kind ("renderer"/"generator") seeds one stack. If the user has
    # supplied override entries, they fully replace the SDK-bundled walk.
    kind_config = [
        {
            "kind": "renderer",
            "stack_name": "Renderers",
            "stack_type": "renderer",
            "dir": RENDERERS_DIR,
            "lang_map": _ren_lang_map,
            "overrides": user_defaults.get("colrend") or [],
            "attach_to": ch.nav_stacks,
        },
        {
            "kind": "generator",
            "stack_name": "Generators",
            "stack_type": "generator",
            "dir": GENERATORS_DIR,
            "lang_map": _gen_lang_map,
            "overrides": user_defaults.get("colgen") or [],
            "attach_to": ch.nav_stacks,
        },
    ]

    for cfg in kind_config:
        overrides = cfg["overrides"]
        if overrides:
            seq = _seed_stack_from_overrides(
                conn=conn,
                run_id=run_id,
                channel_name=channel_name,
                cfg=cfg,
                seq=seq,
            )
        else:
            groups = _list_groups(cfg["dir"])
            if not groups:
                continue
            stack = Stack(name=cfg["stack_name"], stack_type=cfg["stack_type"])
            for group in groups:
                seq += 1
                group_path = os.path.join(cfg["dir"], group)
                filepath_prefix = f"{cfg['stack_type']}s/{group}"
                cell_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, f"{filepath_prefix}-{channel_name}"))
                _seed_directory(
                    conn,
                    run_id=run_id,
                    dir_path=group_path,
                    cell_id=cell_id,
                    cell_name=_group_display_name(group),
                    seq=seq,
                    filepath_prefix=filepath_prefix,
                )
                vfiles = _build_group_vfiles(group_path, prefix=filepath_prefix, lang_map=cfg["lang_map"])
                stack.cells.append(Cell(
                    id=cell_id,
                    name=_group_display_name(group),
                    summary=f"{cfg['stack_type'].capitalize()}s in the {group} group.",
                    files=vfiles,
                ))
            cfg["attach_to"].append(stack)

    ch.main_selection_id = ch.main_stacks[0].id if ch.main_stacks else None
    conn.commit()
    conn.close()

def bootstrap():
    """Initialise the workspace for the CWD if not already done."""
    if is_bootstrapped():
        return

    print("[collimate] Bootstrapping workspace...")

    os.makedirs(".collimate/channels", exist_ok=True)
    os.makedirs(".collimate/objects", exist_ok=True)

    from database import get_db_connection
    from models import AppState, Channel

    app_state = AppState()
    ch = Channel(name="Starting")
    app_state.channels.append(ch)
    app_state.active_channel_id = ch.id

    seed_channel("starting", ch)

    conn = get_db_connection("starting")
    conn.execute(
        "INSERT INTO ui_state (key, value) VALUES ('app_state', ?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (app_state.model_dump_json(),),
    )
    conn.commit()
    conn.close()

    with open(GENESIS_MARKER, "w") as f:
        json.dump({"bootstrapped_at": datetime.now(timezone.utc).isoformat()}, f)

    print("[collimate] Bootstrap complete.")


def load_channel_ui_state(channel_name: str) -> dict | None:
    """Load saved UI AppState JSON from a channel's SQLite db, or None."""
    from database import get_db_connection
    try:
        conn = get_db_connection(channel_name)
        row = conn.execute(
            "SELECT value FROM ui_state WHERE key='app_state'"
        ).fetchone()
        conn.close()
        if row:
            return json.loads(row["value"])
    except Exception:
        pass
    return None


def save_channel_ui_state(channel_name: str, state_dict: dict):
    """Persist UI AppState JSON to a channel's SQLite db."""
    from database import get_db_connection
    conn = get_db_connection(channel_name)
    conn.execute(
        "INSERT INTO ui_state (key, value) VALUES ('app_state', ?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(state_dict),),
    )
    conn.commit()
    conn.close()
