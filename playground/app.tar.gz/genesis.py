"""Genesis bootstrapping — initialises .collimate/ on first CWD launch."""
import os
import json
import hashlib
import logging
import shutil
import uuid
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

GENESIS_MARKER = os.path.join(".collimate", ".genesis")
# Sibling of .collimate (both CWD-relative). The bundle LIBRARY: .colgen /
# .colrend / .colchan files the channel-creation picker seeds from (native)
# and the file-sync "Backup" surface reads/writes. Survives a `--clear` data
# wipe; only `--clearall` removes it. See api/backup.py for the I/O helpers.
BACKUP_DIR = ".collimatebackup"
_API_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_API_DIR)
TEMPLATES_DIR = os.path.join(_API_DIR, "templates")


def _resolve_assets_dir(kind: str) -> str:
    """Return the directory to read generator/renderer assets from.

    Resolution order:
      1. api/templates/<asset>/ vendored by build_server.sh or vendor_defaults.
      2. The installed collimate-sdk wheel's package data
         (collimate/<asset>/ via importlib.resources). This is what pyodide
         and plain `pip install collimate-sdk` see.
      3. A sibling directory next to the installed `collimate` package —
         handles editable installs where the asset dirs live at the SDK
         repo root as siblings of src/ (see the SDK's [tool.hatch.build.
         targets.wheel.force-include] which only kicks in at wheel time).

    ``kind`` is ``"generators"`` or ``"renderers"``. Under pyodide (IS_WASM)
    the generators asset swaps to ``generators-wasm`` so new channels seed
    with the playground-safe subset authored against collimate.wasm_sdk.
    Renderers are browser-side JS and need no per-runtime variant.
    """
    from runtime import IS_WASM
    sdk_asset_name = "generators-wasm" if (kind == "generators" and IS_WASM) else kind

    # 1. Vendored into api/templates/
    local = os.path.join(TEMPLATES_DIR, sdk_asset_name)
    if os.path.isdir(local) and os.listdir(local):
        return local

    # 2. Installed package resource (wheel install, including pyodide).
    try:
        from importlib.resources import files, as_file
        resource = files("collimate").joinpath(sdk_asset_name)
        with as_file(resource) as p:
            if p.is_dir() and os.listdir(p):
                return str(p)
    except (ModuleNotFoundError, FileNotFoundError):
        pass

    # 3. Editable-install fallback: asset dir as a sibling of src/.
    try:
        import collimate as _collimate_pkg
        pkg_dir = os.path.dirname(os.path.abspath(_collimate_pkg.__file__))
        sdk_root = os.path.dirname(os.path.dirname(pkg_dir))
        sibling = os.path.join(sdk_root, sdk_asset_name)
        if os.path.isdir(sibling) and os.listdir(sibling):
            return sibling
    except (ImportError, OSError):
        pass

    return local  # last-ditch fallback so callers get consistent error paths


GENERATORS_DIR = _resolve_assets_dir("generators")
RENDERERS_DIR = _resolve_assets_dir("renderers")

# Fixed genesis run ID (deterministic, not random)
GENESIS_RUN_ID = "00000000-0000-0000-0000-000000000001"


def is_bootstrapped() -> bool:
    return os.path.exists(GENESIS_MARKER)


def _hash_file(path: str) -> str:
    sha256 = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            sha256.update(chunk)
    return sha256.hexdigest()


def _store_blob(file_path: str, blob_hash: str) -> str:
    """Atomically copy a file into the CAS. Returns the CAS path."""
    cas_dir = os.path.join(".collimate", "objects", blob_hash[:2])
    cas_path = os.path.join(cas_dir, blob_hash[2:])
    if not os.path.exists(cas_path):
        os.makedirs(cas_dir, exist_ok=True)
        tmp = cas_path + ".tmp"
        shutil.copy2(file_path, tmp)
        os.replace(tmp, cas_path)
    return cas_path


def _store_bytes_blob(content: bytes) -> str:
    """Hash bytes, store in the CAS (no-op if already present), return hex sha256."""
    blob_hash = hashlib.sha256(content).hexdigest()
    cas_dir = os.path.join(".collimate", "objects", blob_hash[:2])
    cas_path = os.path.join(cas_dir, blob_hash[2:])
    if not os.path.exists(cas_path):
        os.makedirs(cas_dir, exist_ok=True)
        tmp = cas_path + ".tmp"
        with open(tmp, "wb") as f:
            f.write(content)
        os.replace(tmp, cas_path)
    return blob_hash


def _seed_cell_from_vfiles(conn, run_id: str, cell_id: str, cell_name: str,
                           seq: int, summary: str, vfiles) -> None:
    """Persist an in-memory cell: insert the cell row and each VirtualFile's
    content into the CAS + blobs + cell_files tables. Mirrors `_seed_directory`
    but reads content from VirtualFile objects instead of disk paths."""
    conn.execute(
        "INSERT OR IGNORE INTO cells (id, run_id, generator_name, sequence_num, "
        "version_name, version_summary, source_type) "
        "VALUES (?, ?, 'genesis', ?, ?, ?, 'genesis')",
        (cell_id, run_id, seq, cell_name, summary),
    )
    for vf in vfiles:
        content = vf.content.encode("utf-8")
        blob_hash = _store_bytes_blob(content)
        conn.execute(
            "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
            (blob_hash, len(content)),
        )
        conn.execute(
            "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
            "VALUES (?, ?, ?)",
            (cell_id, vf.name, blob_hash),
        )


def _seed_directory(conn, run_id: str, dir_path: str, cell_id: str,
                    cell_name: str, seq: int, filepath_prefix: str):
    """Walk a template directory, store all files in the CAS, create a DAG cell."""
    if not os.path.isdir(dir_path):
        return

    conn.execute(
        "INSERT OR IGNORE INTO cells (id, run_id, generator_name, sequence_num, "
        "version_name, version_summary, source_type) "
        "VALUES (?, ?, 'genesis', ?, ?, 'Seeded from template', 'genesis')",
        (cell_id, run_id, seq, cell_name),
    )

    for root, _dirs, files in os.walk(dir_path):
        _dirs[:] = [d for d in _dirs if not d.startswith("__")]
        for filename in sorted(files):
            if filename.startswith("__"):
                continue
            abs_path = os.path.join(root, filename)
            rel_to_dir = os.path.relpath(abs_path, dir_path)
            filepath = f"{filepath_prefix}/{rel_to_dir}".replace("\\", "/")

            blob_hash = _hash_file(abs_path)
            _store_blob(abs_path, blob_hash)
            size = os.path.getsize(abs_path)

            conn.execute(
                "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                (blob_hash, size),
            )
            conn.execute(
                "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                "VALUES (?, ?, ?)",
                (cell_id, filepath, blob_hash),
            )


def _load_cell_layout(base_dir: str):
    """The cell layout of a vendored templates tree — the parent folders ARE
    the cells (collimate.packaging.layout): each immediate, non-underscore
    subdirectory of ``base_dir`` is one cell, its optional ``cell.yaml``
    carrying the display name / summary / icon / order / shared ``_*``
    libraries / shared docs. Identical whether the tree came from
    ``vendor_defaults`` (dev sibling checkout) or ``install_archives``
    (release archives, which synthesize cell.yaml on extraction).

    Returns a list of plain dicts
    ``{name, summary, icon, order, path, shared, shared_docs}`` in display
    order, or None when the tree is absent or holds no cells."""
    try:
        from collimate.packaging import scan_cells
    except ImportError:
        logger.warning("collimate.packaging.scan_cells unavailable — no cells seeded")
        return None
    try:
        cells = scan_cells(base_dir)
    except FileNotFoundError:
        return None
    except Exception as e:  # noqa: BLE001 — a bad cell.yaml must not kill genesis
        logger.warning("cell layout scan of %s failed: %s", base_dir, e)
        return None
    layout = [
        {
            "name": c.name,
            "summary": c.summary,
            "icon": c.icon,
            "order": c.order,
            "path": str(c.path),
            "shared": list(c.shared),
            "shared_docs": list(c.shared_docs),
        }
        for c in cells
    ]
    return layout or None


def _seed_from_backup(conn, run_id: str, channel_name: str, ch,
                      selected_cells: dict | None, seq: int) -> tuple[int, bool]:
    """NATIVE seeding from the ``.collimatebackup`` bundle library.

    ``selected_cells`` (None = seed the curated defaults in full) is the
    normalized native shape ``{"generators": refs|None, "renderers": refs|None,
    "starting": refs|None}`` where each ``refs`` is a list of
    ``{"filename", "cell_ids": [...]|None}`` (``cell_ids`` None = every cell in
    that bundle). A section mapping to None/absent seeds nothing for that kind.

    Returns ``(seq, seeded)``. ``seeded`` is False ONLY when no explicit
    selection was given AND the library has no curated ``latest_sdk_*`` bundle
    — the caller then falls through to the releases.yaml layout (fresh checkout
    before an install populated the library)."""
    import backup
    from models import Stack, Cell, VirtualFile

    try:
        all_bundles = backup.list_bundles()
    except Exception:
        all_bundles = []

    explicit = selected_cells is not None
    has_defaults = any(
        b["filename"] in (backup.DEFAULT_GENERATORS, backup.DEFAULT_RENDERERS)
        for b in all_bundles
    )
    if not explicit and not has_defaults:
        return seq, False  # nothing curated to seed → use the releases.yaml layout

    def _refs_for(section_key: str, default_filename: str | None):
        # An explicit list (even empty) is honored verbatim; None — whether the
        # whole body was omitted or just this section — falls back to seeding
        # the curated default bundle for this kind in full.
        refs = (selected_cells or {}).get(section_key) if explicit else None
        if refs is not None:
            return refs
        if default_filename and any(b["filename"] == default_filename for b in all_bundles):
            return [{"filename": default_filename, "cell_ids": None}]
        return []

    def _seed_package_refs(refs, kind: str, stack_name: str):
        nonlocal seq
        if not refs:
            return
        from collimate.packaging import read_archive, PackageError
        stack = Stack(name=stack_name, stack_type=kind)
        for ref in refs:
            filename = ref.get("filename")
            want = set(ref.get("cell_ids")) if ref.get("cell_ids") else None
            try:
                manifest = read_archive(backup.read_bundle_bytes(filename))
            except (FileNotFoundError, ValueError, PackageError) as e:
                logger.warning("seed: skipping backup bundle %r: %s", filename, e)
                continue
            for cspec in manifest.cells:
                if want is not None and str(cspec.id) not in want:
                    continue
                seq += 1
                cell_id = str(uuid.uuid5(
                    uuid.NAMESPACE_DNS, f"{kind}-{channel_name}-{filename}-{cspec.id}",
                ))
                vfiles = [VirtualFile(name=f.name, language=f.language, content=f.content)
                          for f in cspec.files]
                _seed_cell_from_vfiles(
                    conn, run_id=run_id, cell_id=cell_id, cell_name=cspec.name,
                    seq=seq, summary=cspec.summary or "", vfiles=vfiles,
                )
                stack.cells.append(Cell(
                    id=cell_id,  # pyright: ignore[reportArgumentType] — pydantic coerces str→UUID
                    name=cspec.name, summary=cspec.summary or "", files=vfiles,
                ))
        if stack.cells:
            ch.nav_stacks.append(stack)

    def _seed_starting_refs(refs):
        nonlocal seq
        if not refs:
            return
        from routes.system import _parse_colchan
        for ref in refs:
            filename = ref.get("filename")
            want = set(ref.get("cell_ids")) if ref.get("cell_ids") else None
            try:
                manifest, file_blobs = _parse_colchan(backup.read_bundle_bytes(filename))
            except (FileNotFoundError, ValueError) as e:
                logger.warning("seed: skipping backup channel %r: %s", filename, e)
                continue
            for stack_dict in manifest.get("main_stacks", []):
                if stack_dict.get("stack_type") in ("generator", "renderer"):
                    continue
                stack = Stack(
                    name=stack_dict.get("name", ""),
                    width=stack_dict.get("width", 33),
                    stack_type="standard",
                )
                for cell_dict in stack_dict.get("cells", []):
                    if want is not None and str(cell_dict.get("id")) not in want:
                        continue
                    seq += 1
                    cell_id = str(uuid.uuid5(
                        uuid.NAMESPACE_DNS,
                        f"standard-{channel_name}-{filename}-{cell_dict.get('id')}",
                    ))
                    vfiles = []
                    for fm in cell_dict.get("files", []):
                        arc_key = f"cells/{cell_dict['id']}/{fm['name'].lstrip('/').replace('..', '_')}"
                        rawf = file_blobs.get(arc_key, b"")
                        vfiles.append(VirtualFile(
                            name=fm["name"], language=fm.get("language", "text"),
                            content=rawf.decode("utf-8", errors="replace"),
                        ))
                    name = cell_dict.get("name") or "Cell"
                    summary = cell_dict.get("summary") or ""
                    _seed_cell_from_vfiles(
                        conn, run_id=run_id, cell_id=cell_id, cell_name=name,
                        seq=seq, summary=summary, vfiles=vfiles,
                    )
                    stack.cells.append(Cell(
                        id=cell_id,  # pyright: ignore[reportArgumentType] — pydantic coerces str→UUID
                        name=name, summary=summary, files=vfiles,
                    ))
                if stack.cells:
                    ch.main_stacks.append(stack)

    _seed_package_refs(_refs_for("generators", backup.DEFAULT_GENERATORS), "generator", "Generators")
    _seed_package_refs(_refs_for("renderers", backup.DEFAULT_RENDERERS), "renderer", "Renderers")
    _seed_starting_refs(_refs_for("starting", None))
    return seq, True


def seed_channel(channel_name: str, ch, selected_cells: dict | None = None):
    """Seed a channel's generator + renderer (and, on native, starting) stacks.

    NATIVE seeds from the ``.collimatebackup`` bundle library
    (``_seed_from_backup``); ``selected_cells`` is the normalized native shape
    ``{"generators": refs, "renderers": refs, "starting": refs}`` of
    ``{"filename", "cell_ids"}`` picks (None = seed the curated ``latest_sdk_*``
    defaults in full). When the library has no curated default (fresh checkout),
    native falls through to the releases.yaml layout below.

    WASM keeps the releases.yaml path verbatim: ``selected_cells`` is then
    ``{"generators": [...names], "renderers": [...names]}`` naming which seed
    cells to include (a kind absent/None seeds in full)."""
    from database import get_db_connection
    from models import Stack, Cell, VirtualFile
    from runtime import IS_WASM
    conn = get_db_connection(channel_name)
    
    # Use deterministic run ID for 'starting', random otherwise
    run_id = GENESIS_RUN_ID if channel_name == "starting" else str(uuid.uuid4())
    
    conn.execute(
        "INSERT OR IGNORE INTO runs (id, prompt, status) VALUES (?, ?, 'completed')",
        (run_id, "Channel initialization"),
    )

    seq = 0

    # NATIVE: seed from the .collimatebackup bundle library. Returns early
    # unless the library has no curated default to seed (fresh checkout), in
    # which case it falls through to the releases.yaml layout below.
    if not IS_WASM:
        seq, seeded = _seed_from_backup(conn, run_id, channel_name, ch, selected_cells, seq)
        if seeded:
            ch.main_selection_id = ch.main_stacks[0].id if ch.main_stacks else None
            conn.commit()
            conn.close()
            return

    _ren_lang_map = {".js": "javascript", ".ts": "typescript", ".tsx": "typescript",
                     ".jsx": "javascript", ".yaml": "yaml", ".yml": "yaml", ".json": "json",
                     ".css": "css", ".html": "html", ".md": "markdown",
                     ".gen_yaml": "yaml", ".rend_yaml": "yaml", ".set_yaml": "yaml"}
    _gen_lang_map = {".py": "python", ".yaml": "yaml", ".yml": "yaml", ".json": "json",
                     ".md": "markdown", ".sh": "shell", ".dockerfile": "dockerfile",
                     ".gen_yaml": "yaml", ".rend_yaml": "yaml", ".set_yaml": "yaml"}

    def _group_display_name(group: str) -> str:
        return group.replace("_", " ").replace("-", " ").title()

    def _build_group_vfiles(group_dir: str, prefix: str, lang_map: dict) -> list:
        vfiles = []
        for root, dirs, files in os.walk(group_dir):
            dirs[:] = [d for d in dirs if not d.startswith("__")]
            for f in sorted(files):
                if f.startswith("__"):
                    continue
                abs_path = os.path.join(root, f)
                rel = os.path.relpath(abs_path, group_dir).replace("\\", "/")
                ext = os.path.splitext(f)[1]
                lang = lang_map.get(ext, "text")
                with open(abs_path, "r", encoding="utf-8") as fb:
                    vfiles.append(VirtualFile(
                        name=f"{prefix}/{rel}",
                        content=fb.read(),
                        language=lang,
                    ))
        return vfiles

    def _seed_stack_from_overrides(conn, run_id: str, channel_name: str,
                                   cfg: dict, seq: int, runtime: str = "native",
                                   selected_names: list | None = None) -> int:
        """Build one gen/rend stack from user_settings defaults instead of
        walking the SDK templates dir. Supports bundle:// (reads from an SDK
        bundle root) and data: (reads a .colgen/.colrend archive).

        ``selected_names`` (None = seed every override entry) filters which
        entries seed, matched by the entry's display name — the same names
        ``list_seed_cells`` surfaces to the channel-creation picker."""
        from user_settings import bundle_root_for, resolve_source_to_bytes
        from collimate.packaging import read_archive, PackageError

        stack_type = cfg["stack_type"]
        lang_map = cfg["lang_map"]
        # Resolve bundles from the same tree the picker used (native vs wasm).
        bundle_root = bundle_root_for(stack_type, runtime)
        stack = Stack(name=cfg["stack_name"], stack_type=stack_type)

        for entry_idx, entry in enumerate(cfg["overrides"]):
            source = entry.get("source", "")
            # Strip to match list_seed_cells' canonical name — otherwise a
            # selected entry whose name has surrounding whitespace fails the
            # membership test and gets silently dropped from seeding.
            entry_name = (entry.get("name") or "").strip() or "Imported"
            if selected_names is not None and entry_name not in selected_names:
                continue

            if source.startswith("bundle://"):
                bundle_name = source[len("bundle://"):]
                if not bundle_root or not (bundle_root / bundle_name).is_dir():
                    logger.warning("skipping unknown bundle %r", source)
                    continue
                seq += 1
                prefix = f"{stack_type}s/{bundle_name}"
                cell_id = str(uuid.uuid5(
                    uuid.NAMESPACE_DNS,
                    f"{prefix}-{channel_name}-override-{entry_idx}",
                ))
                _seed_directory(
                    conn, run_id=run_id, dir_path=str(bundle_root / bundle_name),
                    cell_id=cell_id, cell_name=entry_name or _group_display_name(bundle_name),
                    seq=seq, filepath_prefix=prefix,
                )
                vfiles = _build_group_vfiles(
                    str(bundle_root / bundle_name), prefix=prefix, lang_map=lang_map,
                )
                stack.cells.append(Cell(
                    id=cell_id,  # pyright: ignore[reportArgumentType] — pydantic coerces str→UUID
                    name=entry_name or _group_display_name(bundle_name),
                    summary=f"{stack_type.capitalize()}s in the {bundle_name} group.",
                    files=vfiles,
                ))
                continue

            if source.startswith("data:"):
                try:
                    raw = resolve_source_to_bytes(source, bundle_root)
                    manifest = read_archive(raw)
                except (ValueError, PackageError) as e:
                    logger.warning("skipping bad data: entry %r: %s", entry_name, e)
                    continue
                for cell_spec in manifest.cells:
                    seq += 1
                    cell_id = str(uuid.uuid5(
                        uuid.NAMESPACE_DNS,
                        f"{stack_type}-data-{channel_name}-{entry_idx}-{cell_spec.id}",
                    ))
                    vfiles = [
                        VirtualFile(
                            name=f"{stack_type}s/{entry_name}/{f.name}",
                            language=f.language,
                            content=f.content,
                        )
                        for f in cell_spec.files
                    ]
                    _seed_cell_from_vfiles(
                        conn, run_id=run_id, cell_id=cell_id,
                        cell_name=cell_spec.name or entry_name, seq=seq,
                        summary=cell_spec.summary or "",
                        vfiles=vfiles,
                    )
                    stack.cells.append(Cell(
                        id=cell_id,  # pyright: ignore[reportArgumentType] — pydantic coerces str→UUID
                        name=cell_spec.name or entry_name,
                        summary=cell_spec.summary or "",
                        files=vfiles,
                    ))
                continue

            logger.warning("skipping unsupported source scheme: %r", source)

        if stack.cells:
            cfg["attach_to"].append(stack)
        return seq

    def _seed_stack_from_layout(conn, run_id: str, channel_name: str,
                                cfg: dict, layout: list, seq: int,
                                selected_names: list | None = None) -> int:
        """Build one gen/rend stack from a tree-driven cell layout
        (``_load_cell_layout``: the templates tree's parent folders are the
        cells, described by their ``cell.yaml``).

        ``selected_names`` (None = seed every layout cell) filters which named
        cells seed — the deselect support behind the channel-creation picker.

        Each layout entry is ``{name, summary, icon, path, shared,
        shared_docs}``. The cell's content folders (its subdirectories) are
        placed under their basenames; ``shared`` names top-level ``_*``
        library folders of the asset root materialised into the cell (the
        run host co-locates ``_*`` siblings at runtime —
        runs/helpers._find_generator_dir); ``shared_docs`` are copied from
        the SDK's ``shared/docs/`` into a top-level ``_shared_docs/``
        sibling. A shared ref that isn't on disk is skipped with a warning
        (release-installed trees have them pre-materialised and list none)."""
        stack_type = cfg["stack_type"]
        lang_map = cfg["lang_map"]
        base_dir = cfg["dir"]
        stack = Stack(name=cfg["stack_name"], stack_type=stack_type)

        for cell_def in layout:
            if not isinstance(cell_def, dict):
                continue
            cell_name = cell_def.get("name") or "Cell"
            if selected_names is not None and cell_name not in selected_names:
                continue
            cell_dir = cell_def.get("path") or ""
            shared_refs = cell_def.get("shared") or []
            shared_docs = cell_def.get("shared_docs") or []

            vfiles = []
            if os.path.isdir(cell_dir):
                for child in sorted(os.listdir(cell_dir)):
                    if child == "cell.yaml" or child.startswith("__"):
                        continue
                    abs_child = os.path.join(cell_dir, child)
                    if os.path.isdir(abs_child):
                        vfiles.extend(_build_group_vfiles(abs_child, prefix=child, lang_map=lang_map))
                    elif os.path.isfile(abs_child):
                        ext = os.path.splitext(child)[1]
                        with open(abs_child, "r", encoding="utf-8") as fb:
                            vfiles.append(VirtualFile(
                                name=child, content=fb.read(),
                                language=lang_map.get(ext, "text"),
                            ))
            else:
                logger.warning("cell %r: folder %r not found — skipping", cell_name, cell_dir)

            for ref in shared_refs:
                lib = os.path.join(base_dir, os.path.basename(str(ref).rstrip("/")))
                if os.path.basename(lib).startswith("_") and os.path.isdir(lib):
                    vfiles.extend(_build_group_vfiles(
                        lib, prefix=os.path.basename(lib), lang_map=lang_map,
                    ))
                else:
                    logger.warning(
                        "cell %r: shared library %r not found under %s — skipping",
                        cell_name, ref, base_dir,
                    )

            if shared_docs:
                for doc in shared_docs:
                    try:
                        # Seed-time copy from the canonical SDK docs tree into
                        # the cell. After this the generators read the doc as a
                        # plain cell-local _shared_docs/ sibling (shared_doc),
                        # never via this SDK lookup at run time.
                        from collimate.shared import shared_path
                        content = shared_path("docs", doc).read_text(encoding="utf-8")
                    except Exception as e:
                        logger.warning("cell %r: shared_doc %r not found: %s", cell_name, doc, e)
                        continue
                    vfiles.append(VirtualFile(
                        name=f"_shared_docs/{doc}",
                        content=content,
                        language="markdown",
                    ))

            if not vfiles:
                continue
            seq += 1
            cell_id = str(uuid.uuid5(
                uuid.NAMESPACE_DNS, f"{stack_type}-{cell_name}-{channel_name}",
            ))
            summary = (cell_def.get("summary") or "").strip() \
                or f"{stack_type.capitalize()}s in the {cell_name} group."
            _seed_cell_from_vfiles(
                conn, run_id=run_id, cell_id=cell_id, cell_name=cell_name,
                seq=seq, summary=summary, vfiles=vfiles,
            )
            stack.cells.append(Cell(
                id=cell_id, name=cell_name, summary=summary, files=vfiles,  # pyright: ignore[reportArgumentType] — pydantic coerces str→UUID
                icon=(cell_def.get("icon") or None),
            ))

        if stack.cells:
            cfg["attach_to"].append(stack)
        return seq

    # ── Load user-level default overrides (may be empty) ──
    try:
        from user_settings import load_settings
        user_defaults = load_settings().get("defaults", {}) or {}
    except Exception:
        user_defaults = {}

    # Each kind ("renderer"/"generator") seeds one stack. If the user has
    # supplied override entries, they fully replace the SDK-bundled walk.
    kind_config = [
        {
            "kind": "renderer",
            "stack_name": "Renderers",
            "stack_type": "renderer",
            "dir": RENDERERS_DIR,
            "lang_map": _ren_lang_map,
            "overrides": user_defaults.get("colrend") or [],
            "attach_to": ch.nav_stacks,
        },
        {
            "kind": "generator",
            "stack_name": "Generators",
            "stack_type": "generator",
            "dir": GENERATORS_DIR,
            "lang_map": _gen_lang_map,
            "overrides": user_defaults.get("colgen") or [],
            "attach_to": ch.nav_stacks,
        },
    ]

    runtime = "wasm" if IS_WASM else "native"

    for cfg in kind_config:
        # Selection is keyed by the plural kind ("generators"/"renderers"),
        # matching list_seed_cells + the create-channel request body. A
        # missing key (or None) means "seed all of this kind".
        sel = (None if selected_cells is None
               else selected_cells.get(cfg["kind"] + "s"))

        overrides = cfg["overrides"]
        if overrides:
            seq = _seed_stack_from_overrides(
                conn=conn,
                run_id=run_id,
                channel_name=channel_name,
                cfg=cfg,
                seq=seq,
                runtime=runtime,
                selected_names=sel,
            )
            continue

        # Tree-driven cell layout (the templates tree's parent folders +
        # cell.yaml) — the only seeding path. A kind whose tree holds no
        # cells simply seeds no stack.
        layout = _load_cell_layout(cfg["dir"])
        if not layout:
            continue
        seq = _seed_stack_from_layout(
            conn, run_id, channel_name, cfg, layout, seq,
            selected_names=sel,
        )

    ch.main_selection_id = ch.main_stacks[0].id if ch.main_stacks else None
    conn.commit()
    conn.close()

def list_seed_cells(runtime: str | None = None) -> dict:
    """Return the seed cells the channel-creation picker offers, per kind:
    ``{"generators": [{name, summary}], "renderers": [{name, summary}]}``.

    This mirrors exactly what ``seed_channel`` would materialise for a new
    channel: the user's ``defaults`` overrides (.colgen/.colrend entries) take
    precedence over the SDK's releases.yaml ``cells`` layout, just like
    seeding. ``runtime`` defaults to the active runtime (wasm under pyodide).
    Names are stable identifiers the create request echoes back to select."""
    from runtime import IS_WASM
    if runtime is None:
        runtime = "wasm" if IS_WASM else "native"

    try:
        from user_settings import load_settings
        user_defaults = load_settings().get("defaults", {}) or {}
    except Exception:
        user_defaults = {}

    out: dict = {"generators": [], "renderers": []}
    for kind, plural, override_key, base_dir in (
        ("generator", "generators", "colgen", GENERATORS_DIR),
        ("renderer", "renderers", "colrend", RENDERERS_DIR),
    ):
        overrides = user_defaults.get(override_key) or []
        if overrides:
            for entry in overrides:
                name = (entry.get("name") or "").strip() or "Imported"
                out[plural].append({
                    "name": name,
                    "summary": f"{kind.capitalize()}s from {name}.",
                })
            continue
        layout = _load_cell_layout(base_dir) or []
        for cell_def in layout:
            if not isinstance(cell_def, dict):
                continue
            name = cell_def.get("name") or "Cell"
            entry = {
                "name": name,
                "summary": (cell_def.get("summary") or "").strip()
                           or f"{kind.capitalize()}s in the {name} group.",
            }
            if cell_def.get("icon"):
                entry["icon"] = cell_def["icon"]
            out[plural].append(entry)
    return out


def _seed_starting_channel():
    """Create + seed the default "Starting" channel and persist it as the
    initial app state. Used only by the wasm/playground bootstrap so the demo
    lands on content immediately; the native app opens to the channel-creation
    view instead (no auto channel)."""
    from models import AppState, Channel

    app_state = AppState()
    ch = Channel(name="Starting")
    app_state.channels.append(ch)
    app_state.active_channel_id = ch.id

    seed_channel("starting", ch)

    state_json = app_state.model_dump_json()
    # Global (channel-independent) copy is the source of truth main.py reads.
    save_global_ui_state(json.loads(state_json))


def bootstrap():
    """Initialise the workspace for the CWD if not already done.

    The native app no longer auto-creates a starter channel — it opens to the
    channel-creation view when no channel exists (the user names the channel
    and picks which seed cells to include). The wasm/playground demo keeps the
    auto-seeded channel so visitors land on content immediately."""
    if is_bootstrapped():
        return

    logger.info("Bootstrapping workspace...")

    os.makedirs(".collimate/channels", exist_ok=True)
    os.makedirs(".collimate/objects", exist_ok=True)
    # The bundle library sits next to .collimate. backup.backup_dir() also
    # makedirs on every call (idempotent) so already-bootstrapped workspaces
    # — which return early above — still get the dir lazily.
    os.makedirs(BACKUP_DIR, exist_ok=True)

    from runtime import IS_WASM
    if IS_WASM:
        _seed_starting_channel()

    with open(GENESIS_MARKER, "w") as f:
        json.dump({"bootstrapped_at": datetime.now(timezone.utc).isoformat()}, f)

    logger.info("Bootstrap complete.")


def load_global_ui_state() -> dict | None:
    """Load the channel-independent AppState JSON from the global db, or None.

    This is the source of truth for restoring app state at startup: it's
    readable even when zero channels exist (the native channel-creation view),
    unlike the per-channel copies which vanish with their channel."""
    from database import get_global_db_connection
    try:
        conn = get_global_db_connection()
        row = conn.execute(
            "SELECT value FROM ui_state WHERE key='app_state'"
        ).fetchone()
        conn.close()
        if row:
            return json.loads(row["value"])
    except Exception:
        pass
    return None


def save_global_ui_state(state_dict: dict):
    """Persist the channel-independent AppState JSON to the global db."""
    from database import get_global_db_connection
    conn = get_global_db_connection()
    try:
        conn.execute(
            "INSERT INTO ui_state (key, value) VALUES ('app_state', ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (json.dumps(state_dict),),
        )
        conn.commit()
    finally:
        conn.close()
