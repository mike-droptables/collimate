"""Static analysis: which keys does a generator's source ask for?

Scans a generator entrypoint's Python source for the ``gen.*`` SDK
calls that resolve secrets and returns the set of canonical env-var
names the generator may ask the user for at runtime. Drives the
Settings → Keys "in use" list and the generator-card "keys used" pill.

Three patterns are recognised:

  * ``await gen.api_key("provider")`` — the literal ``provider`` is
    mapped to its canonical env var via
    :data:`collimate.llm.PROVIDER_KEY_ENV` (anthropic →
    ANTHROPIC_API_KEY, groq → GROQ_API_KEY, …).
  * ``await gen.secret("ENV_NAME", …)`` — the literal name is the
    env-var directly.
  * ``await gen.agent(...)`` — the SDK helper that internally resolves
    the API key for whichever provider the config / kwargs select.
    Static analysis usually can't pin the provider down (most
    generators read ``provider`` from the user's settings), so any
    ``gen.agent`` call is treated as "may need any provider key" and
    surfaces the union of every value in ``PROVIDER_KEY_ENV``.

Limitations:

  * Computed first args (variables, function calls) cannot be picked
    up at scan time. When ``gen.api_key`` is called with a non-literal
    arg we fall back to the same union so the user can pre-fill.
    ``gen.secret`` with a non-literal name has no known finite set to
    pre-fill — the runtime modal handles discovery.
  * The scanner accepts any attribute owner for ``.api_key`` /
    ``.secret`` / ``.agent`` (``gen``, ``ctx``, …) so polyglot or
    pre-rework generators pass through; the receiver allowlist
    remains tight on legacy ``.get_key`` to avoid noise from unrelated
    APIs.
"""

from __future__ import annotations

import ast
import logging
import os

logger = logging.getLogger(__name__)


# Provider env-var names per provider. Imported lazily — the SDK is
# part of the api environment but a missing/older SDK shouldn't break
# key scanning. Falls back to a static set if the import fails.
def _provider_key_env() -> dict[str, str]:
    try:
        from collimate.llm import PROVIDER_KEY_ENV
        return dict(PROVIDER_KEY_ENV)
    except ImportError:
        return {
            "anthropic": "ANTHROPIC_API_KEY",
            "openai": "OPENAI_API_KEY",
            "groq": "GROQ_API_KEY",
            "cerebras": "CEREBRAS_API_KEY",
            "openrouter": "OPENROUTER_API_KEY",
            "gemini": "GEMINI_API_KEY",
            "mistral": "MISTRAL_API_KEY",
        }


def _all_provider_keys() -> list[str]:
    """Every distinct env-var name across all known providers."""
    return sorted(set(_provider_key_env().values()))


# Receivers whose ``.api_key(…)`` / ``.secret(…)`` / ``.get_key(…)``
# calls count as Collimate SDK contracts. ``gen`` is the new singleton;
# ``ctx`` covers any pre-rework wasm-style code that still survives
# under another runtime.
_SDK_RECEIVERS = frozenset({"gen", "ctx"})


def _scan_calls(tree: ast.AST) -> tuple[set[str], bool]:
    """Walk ``tree`` and collect:

      * literal env-var names (from ``gen.secret("X", …)`` or any
        legacy ``gen.get_key("X", …)``);
      * literal provider env vars (from ``gen.api_key("provider")``);
      * a ``saw_dynamic`` flag set when (a) any ``api_key`` / ``secret``
        call's first arg is non-literal, or (b) any ``gen.agent(...)``
        call appears at all — both cases mean the caller adds the
        union of all provider env vars so the Keys tab pre-fills
        whichever the runtime ends up resolving.

    Returns ``(names, saw_dynamic)``.
    """
    names: set[str] = set()
    saw_dynamic = False
    provider_env = _provider_key_env()

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        if not isinstance(func, ast.Attribute):
            continue
        receiver = func.value
        if not (isinstance(receiver, ast.Name) and receiver.id in _SDK_RECEIVERS):
            continue

        method = func.attr

        # ``gen.agent(...)`` — the SDK helper resolves the API key
        # internally, so a generator that uses it doesn't need to call
        # ``gen.api_key`` explicitly. We can't (in general) tell which
        # provider it'll pick, so emit the full union.
        if method == "agent":
            saw_dynamic = True
            continue

        if method not in {"api_key", "secret", "get_key"}:
            continue
        if not node.args:
            continue
        first = node.args[0]

        # Literal-arg fast paths.
        if isinstance(first, ast.Constant) and isinstance(first.value, str):
            literal = first.value
            if method == "api_key":
                env = provider_env.get(literal.lower())
                if env:
                    names.add(env)
                else:
                    # Unknown provider — fall back to union so the
                    # user has something to fill.
                    saw_dynamic = True
            else:
                # gen.secret("X") / gen.get_key("X") — literal IS the env var.
                names.add(literal)
            continue

        # Non-literal first arg. We can't statically resolve the name;
        # for api_key, the safer move is to surface every provider env
        # var so the user can pre-fill. For secret/get_key without a
        # literal, the runtime modal handles discovery — no static hint.
        if method == "api_key":
            saw_dynamic = True

    return names, saw_dynamic


# Cache by (path, mtime) so repeated scans (many calls per render of
# the Keys tab + generator-card pills) don't re-parse a file that
# hasn't changed.
_scan_cache: dict[tuple[str, float], list[str]] = {}


def scan_keys_used(entrypoint_path: str) -> list[str]:
    """Return the canonical env-var names a generator's source asks for.

    Returns an empty list on any read/parse failure — the scanner is
    advisory; a syntax error in a draft file shouldn't break the Keys
    tab.
    """
    try:
        st = os.stat(entrypoint_path)
    except OSError:
        return []
    cache_key = (entrypoint_path, st.st_mtime)
    cached = _scan_cache.get(cache_key)
    if cached is not None:
        return cached

    try:
        with open(entrypoint_path, "r", encoding="utf-8") as f:
            source = f.read()
    except OSError:
        return []
    try:
        tree = ast.parse(source, filename=entrypoint_path)
    except SyntaxError as exc:
        logger.debug("key_scan: skipping unparseable %s: %s", entrypoint_path, exc)
        return []

    names, saw_dynamic = _scan_calls(tree)
    if saw_dynamic:
        names.update(_all_provider_keys())
    found = sorted(names)
    _scan_cache[cache_key] = found
    return found


def scan_keys_used_in_source(source: str) -> list[str]:
    """Same as :func:`scan_keys_used` but works on an in-memory string.

    Used when the generator source isn't materialised to disk yet —
    e.g. a draft generator whose entrypoint lives in
    ``cell_files.content_text`` rather than ``api/templates/``.
    """
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []
    names, saw_dynamic = _scan_calls(tree)
    if saw_dynamic:
        names.update(_all_provider_keys())
    return sorted(names)
