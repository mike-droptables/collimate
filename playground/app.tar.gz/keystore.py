"""Secret storage for API keys and similar env-scoped credentials.

Two backends, selected at runtime:

* **Native** — OS keychain via the ``keyring`` library (libsecret / Keychain
  / Credential Manager). Secrets are encrypted at rest by the OS and
  unlocked by the user's login session. A plaintext index of *names only*
  (no values) at ``~/.collimate/keys.json`` lets us enumerate stored keys
  without a cross-backend API.

* **WASM (pyodide playground)** — the OS keychain doesn't exist in-browser,
  so we back the same public API with a row in the global sqlite DB
  (``ui_state.user_keys`` → JSON ``{name: value}``). The global DB is
  IDBFS-persisted, so keys survive page reloads. Plaintext at rest — same
  security model as anything else stored in the playground's IndexedDB.

Callers don't pick the backend — they just call ``available()``,
``list_names()``, ``set_key()``, ``get_key()``, ``delete_key()``,
``load_into_environ()``. The module dispatches on ``runtime.IS_WASM``.
"""

import json
import os
from pathlib import Path

_SERVICE = "collimate"
_INDEX_PATH = Path.home() / ".collimate" / "keys.json"
_WASM_KEYS_ROW = "user_keys"

_native_available: bool | None = None


def _is_wasm() -> bool:
    """Deferred import to avoid circular-import risk at module load."""
    try:
        from runtime import IS_WASM
        return IS_WASM
    except ImportError:
        return False


# ---------------------------------------------------------------------------
# WASM backend (sqlite-backed)
# ---------------------------------------------------------------------------

def _wasm_load() -> dict[str, str]:
    from database import get_global_db_connection
    conn = get_global_db_connection()
    try:
        row = conn.execute(
            "SELECT value FROM ui_state WHERE key=?", (_WASM_KEYS_ROW,)
        ).fetchone()
    finally:
        conn.close()
    if not row:
        return {}
    try:
        data = json.loads(row["value"])
    except (json.JSONDecodeError, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    return {k: v for k, v in data.items() if isinstance(k, str) and isinstance(v, str)}


def _wasm_save(keys: dict[str, str]) -> None:
    from database import get_global_db_connection
    conn = get_global_db_connection()
    try:
        conn.execute(
            "INSERT INTO ui_state (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (_WASM_KEYS_ROW, json.dumps(keys)),
        )
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Native backend (OS keychain via `keyring`)
# ---------------------------------------------------------------------------

def _native_available() -> bool:
    global _native_available
    if _native_available is not None:
        return _native_available
    try:
        import keyring
        try:
            keyring.get_password(_SERVICE, "__collimate_probe__")
            _native_available = True
        except Exception:
            _native_available = False
    except ImportError:
        _native_available = False
    return _native_available


def _load_index() -> list[str]:
    if not _INDEX_PATH.is_file():
        return []
    try:
        data = json.loads(_INDEX_PATH.read_text())
        if isinstance(data, list):
            return [str(x) for x in data]
    except Exception:
        pass
    return []


def _save_index(names: list[str]) -> None:
    _INDEX_PATH.parent.mkdir(parents=True, exist_ok=True)
    _INDEX_PATH.write_text(json.dumps(sorted(set(names))))


# ---------------------------------------------------------------------------
# Public API — dispatches on runtime
# ---------------------------------------------------------------------------

def available() -> bool:
    """Can we persist secrets? Under wasm we always can (sqlite)."""
    if _is_wasm():
        return True
    return _native_available()


def list_names() -> list[str]:
    """Names (not values) of every stored key."""
    if _is_wasm():
        return sorted(_wasm_load().keys())
    return _load_index()


def set_key(name: str, value: str) -> bool:
    """Persist a secret. Returns True on success."""
    if _is_wasm():
        keys = _wasm_load()
        keys[name] = value
        _wasm_save(keys)
        return True
    if not _native_available():
        return False
    import keyring
    try:
        keyring.set_password(_SERVICE, name, value)
    except Exception:
        return False
    names = _load_index()
    if name not in names:
        names.append(name)
        _save_index(names)
    return True


def get_key(name: str) -> str | None:
    """Read a stored secret."""
    if _is_wasm():
        return _wasm_load().get(name)
    if not _native_available():
        return None
    import keyring
    try:
        return keyring.get_password(_SERVICE, name)
    except Exception:
        return None


def delete_key(name: str) -> bool:
    """Remove a stored secret. Returns True if it existed."""
    if _is_wasm():
        keys = _wasm_load()
        existed = name in keys
        if existed:
            keys.pop(name, None)
            _wasm_save(keys)
        return existed
    ok = False
    if _native_available():
        import keyring
        try:
            keyring.delete_password(_SERVICE, name)
            ok = True
        except Exception:
            pass
    names = _load_index()
    if name in names:
        names.remove(name)
        _save_index(names)
    return ok


def load_into_environ() -> int:
    """Populate ``os.environ`` from persisted keys. Returns the count loaded."""
    if _is_wasm():
        keys = _wasm_load()
        for k, v in keys.items():
            os.environ[k] = v
        return len(keys)
    if not _native_available():
        return 0
    count = 0
    for name in list_names():
        val = get_key(name)
        if val is not None:
            os.environ[name] = val
            count += 1
    return count
