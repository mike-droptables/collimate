import sys
import os

# Ensure the api/ directory is on the Python path for relative imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

_sdk_src = os.path.join(os.path.dirname(current_dir), "collimate-sdk", "src")
if os.path.isdir(_sdk_src) and _sdk_src not in sys.path:
    sys.path.insert(0, _sdk_src)

from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from genesis import bootstrap, load_channel_ui_state
from state import state
from routes.system import router as system_router
from routes.windows import router as windows_router
from routes.generation import router as generation_router
from routes.runs import router as runs_router
from routes.proxy import router as proxy_router
from routes.blobs import router as blobs_router
from routes.cells import router as cells_router
from routes.drafts import router as drafts_router
from routes.terminal import router as terminal_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    from runtime import IS_WASM

    # 0. Load persisted secrets into os.environ. The keystore module
    # dispatches internally: OS keychain on native, sqlite-backed
    # (IDBFS-persisted) on wasm. Both go through the same API so
    # downstream code (generators reading os.environ) doesn't care.
    try:
        from keystore import available, load_into_environ
        if available():
            count = load_into_environ()
            if count:
                backend = "IDBFS" if IS_WASM else "OS keychain"
                print(f"[keystore] loaded {count} secret(s) from {backend}")
        else:
            print("[keystore] no persistent backend; secrets will not survive restart")
    except Exception as e:
        print(f"[keystore] failed to load: {e}")

    # 0.5 / 0.6. Docker container reaps (vscode images + sandbox daemons).
    # Docker doesn't exist in pyodide — whole-step skip.
    if not IS_WASM:
        try:
            import subprocess
            result = subprocess.run(
                ["docker", "ps", "-aq", "--filter", "name=^collimate-vscode-"],
                capture_output=True, text=True, timeout=5,
            )
            ids = [x for x in result.stdout.strip().splitlines() if x]
            if ids:
                print(f"[reaper] removing {len(ids)} orphaned collimate-vscode container(s)")
                subprocess.run(
                    ["docker", "rm", "-f", *ids],
                    capture_output=True, timeout=30,
                )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            # Docker may not be installed/running; that's fine, only matters
            # for vscode_docker generators.
            pass
        except Exception as e:
            print(f"[reaper] failed: {e}")

        try:
            from sandbox import reap_orphan_containers
            reap_orphan_containers()
        except Exception as e:
            print(f"[sandbox] orphan reap failed: {e}")

    # 0.7. Capture the event loop early so broadcast() works before any
    # SSE subscriber connects.
    from events import capture_loop
    capture_loop()

    # 1. Bootstrap .collimate/ if this is the first launch in this CWD
    bootstrap()

    # 2. Attempt to restore persisted UI state from the starting channel's DB.
    saved = load_channel_ui_state("starting")
    if saved:
        try:
            from models import AppState
            restored = AppState.model_validate(saved)
            state.channels = restored.channels
            state.active_channel_id = restored.active_channel_id
        except Exception:
            pass

    # 3. Fallback: If state is empty (e.g. DB deleted or schema changed), ensure at least one channel exists
    if not state.channels:
        from models import Channel
        ch = Channel(name="Starting")
        state.channels.append(ch)
        state.active_channel_id = ch.id

    yield

    # Shutdown: terminate any generator processes still running (native only).
    if not IS_WASM:
        from routes.runs import active_managers
        import signal as sig_module
        for manager in list(active_managers.values()):
            try:
                if manager.process and manager.process.returncode is None:
                    os.killpg(os.getpgid(manager.process.pid), sig_module.SIGTERM)
            except Exception:
                pass
        active_managers.clear()

        # Tear down any sandbox daemon containers still running.
        try:
            from sandbox import shutdown_all
            await shutdown_all()
        except Exception as e:
            print(f"[sandbox] shutdown failed: {e}")


app = FastAPI(lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# When a native-only capability (subprocess, Docker, keyring) is invoked
# under pyodide, the code raises WasmNotSupportedError. Translate that to
# a clean 503 so the frontend can render a "not in playground" message
# instead of a generic 500 with a traceback.
from runtime import WasmNotSupportedError
from fastapi.responses import JSONResponse


@app.exception_handler(WasmNotSupportedError)
async def _wasm_not_supported_handler(request, exc: WasmNotSupportedError):
    return JSONResponse(
        status_code=503,
        content={"detail": str(exc), "code": "wasm_not_supported"},
    )

# --- Existing UI routes ---
app.include_router(system_router)
app.include_router(windows_router)
app.include_router(generation_router)

# --- New execution-pipeline routes ---
app.include_router(runs_router)
app.include_router(proxy_router)
app.include_router(blobs_router)
app.include_router(cells_router)
app.include_router(drafts_router)
app.include_router(terminal_router)

# ---------------------------------------------------------------------------
# Static file serving — bundled Vite frontend
# ---------------------------------------------------------------------------
_static_dir = os.path.join(current_dir, "static")
if os.path.isdir(_static_dir):
    app.mount("/", StaticFiles(directory=_static_dir, html=True), name="static")


if __name__ == "__main__":
    import uvicorn
    # Bind to loopback only. Browsers grant http://localhost and
    # http://127.0.0.1 a "secure context" for free, which is what code-server
    # webviews and the Claude Code extension need (service workers, clipboard
    # APIs, etc.). HTTPS would require a trusted cert, which can't be done
    # zero-setup. Loopback-only also means the API isn't exposed to the LAN
    # by accident.
    port = 5001
    print(f"\n  Collimate is running at:  http://localhost:{port}\n")
    uvicorn.run(app, host="127.0.0.1", port=port)
