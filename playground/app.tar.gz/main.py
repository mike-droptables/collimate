import asyncio
import sys
import os
import logging

# Ensure the api/ directory is on the Python path for relative imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

_sdk_src = os.path.join(os.path.dirname(current_dir), "collimate-sdk", "src")
if os.path.isdir(_sdk_src) and _sdk_src not in sys.path:
    sys.path.insert(0, _sdk_src)

from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from fastapi.staticfiles import StaticFiles

logger = logging.getLogger(__name__)

from genesis import bootstrap, load_channel_ui_state
from state import state
from runtime import IS_WASM
from routes.system import router as system_router
from routes.windows import router as windows_router
from routes.generation import router as generation_router
from routes.generator_config_tags import router as generator_config_tags_router
from routes.generator_manifest_edit import router as generator_manifest_edit_router
from routes.runs import router as runs_router
from routes.snapshot import router as snapshot_router
from routes.packages import router as packages_router
# Proxy router forwards traffic to subprocess generators (vscode/codespaces
# tunnels). Pyodide can't spawn subprocesses, so the router is dead weight
# under wasm — skipping it here also lets the wasm boot drop httpx +
# websockets from the micropip install list, saving multiple seconds on
# first boot.
if not IS_WASM:
    from routes.proxy import router as proxy_router
    from routes.session_proxy import SessionSubdomainProxy
from routes.blobs import router as blobs_router
from routes.cells import router as cells_router
from routes.chat_live import router as chat_live_router
from routes.terminal import router as terminal_router
from routes.fs import router as fs_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    # 0. Install a generously-sized default ThreadPoolExecutor.
    #
    # Python's default executor caps at min(32, cpu_count() + 4) — ~36
    # workers on a modern laptop. The async-hygiene cleanup pushes
    # every sync sqlite + filesystem operation through
    # ``asyncio.to_thread``, so under concurrent load (six live chats
    # each emitting cell updates and SSE polls plus a deep DAG /
    # version-history walk per turn) the executor saturates and
    # newly-dispatched tasks queue behind the existing backlog. 256
    # is conservative — well above the saturation estimate, well
    # below any per-process resource cost; workers are lazy and only
    # created on demand. Hitting saturation on this ceiling is a
    # signal that some sync-on-loop violation snuck back in, not a
    # reason to raise the ceiling further. See docs/async-hygiene.md.
    if not IS_WASM:
        try:
            from concurrent.futures import ThreadPoolExecutor
            _executor = ThreadPoolExecutor(
                max_workers=256, thread_name_prefix="collimate-async",
            )
            asyncio.get_running_loop().set_default_executor(_executor)
            logger.info("installed 256-worker default ThreadPoolExecutor")
        except Exception:
            logger.exception("failed to install custom thread pool; falling back to default")

    # 1. Load persisted secrets into os.environ. The keystore module
    # dispatches internally: OS keychain on native, sqlite-backed
    # (IDBFS-persisted) on wasm. Both go through the same API so
    # downstream code (generators reading os.environ) doesn't care.
    try:
        from keystore import available, load_into_environ
        if available():
            count = load_into_environ()
            if count:
                backend = "IDBFS" if IS_WASM else "OS keychain"
                logger.info("keystore loaded %d secret(s) from %s", count, backend)
        else:
            logger.info("keystore: no persistent backend; secrets will not survive restart")
    except Exception:
        logger.exception("keystore failed to load")

    # 0.5 / 0.6. Docker container reaps (vscode images + sandbox daemons).
    # Docker doesn't exist in pyodide — whole-step skip.
    if not IS_WASM:
        try:
            import subprocess
            result = subprocess.run(
                ["docker", "ps", "-aq", "--filter", "name=^collimate-vscode-"],
                capture_output=True, text=True, timeout=5,
            )
            ids = [x for x in result.stdout.strip().splitlines() if x]
            if ids:
                logger.info("reaper removing %d orphaned collimate-vscode container(s)", len(ids))
                subprocess.run(
                    ["docker", "rm", "-f", *ids],
                    capture_output=True, timeout=30,
                )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            # Docker may not be installed/running; that's fine, only matters
            # for vscode_docker generators.
            pass
        except Exception:
            logger.exception("reaper failed")

        try:
            from sandbox import reap_orphan_containers
            reap_orphan_containers()
        except Exception:
            logger.exception("sandbox orphan reap failed")

    # 0.7. Capture the event loop early so broadcast() works before any
    # SSE subscriber connects.
    from events import capture_loop
    capture_loop()

    # 1. Bootstrap .collimate/ if this is the first launch in this CWD
    bootstrap()

    # 2. Attempt to restore persisted UI state from the starting channel's DB.
    saved = load_channel_ui_state("starting")
    if saved:
        try:
            from models import AppState
            restored = AppState.model_validate(saved)
            state.channels = restored.channels
            state.active_channel_id = restored.active_channel_id
        except Exception:
            pass

    # 3. Fallback: If state is empty (e.g. DB deleted or schema changed), ensure at least one channel exists
    if not state.channels:
        from models import Channel
        ch = Channel(name="Starting")
        state.channels.append(ch)
        state.active_channel_id = ch.id

    # 4. Periodic WAL checkpoint. Bounds worst-case data loss to roughly
    # the configured interval — without this, a quiet channel can let
    # the WAL grow until SQLite's auto-checkpoint threshold, leaving a
    # long crash-recovery window. Skipped under wasm where the DB is
    # IDBFS-backed (the browser handles its own durability).
    _wal_task = None
    if not IS_WASM:
        import wal_checkpoint
        interval = float(os.environ.get("COLLIMATE_WAL_CHECKPOINT_SECONDS", "60") or 60)
        _wal_task = asyncio.create_task(wal_checkpoint.run_periodic(interval))

    yield

    # Shutdown: stop the WAL checkpoint task first so its final flush
    # runs while DB connections are still healthy. Generator subprocess
    # teardown follows so any last commits land before checkpoint.
    if _wal_task is not None:
        _wal_task.cancel()
        try:
            await _wal_task
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.exception("wal_checkpoint task shutdown failed")

    # Shutdown: stop every running generator + sandbox container, giving
    # each a grace window to exit cleanly (Docker-using generators spend it
    # calling ``docker stop`` on their own container) before SIGKILLing the
    # stragglers. Same ladder the in-app "Stop all" button uses — see
    # routes/runs/teardown.stop_all_runs. The launcher's window-close path
    # reaches here by SIGTERMing the server, which uvicorn turns into this
    # lifespan teardown; its SIGKILL backstop is sized to outlast this.
    if not IS_WASM:
        from routes.runs import stop_all_runs
        try:
            summary = await stop_all_runs()
            logger.info("shutdown teardown complete: %s", summary)
        except Exception:
            logger.exception("shutdown teardown failed")


app = FastAPI(lifespan=lifespan)

# Body-size middleware. Defends every route from a 1 GB POST that would
# otherwise OOM the worker. Routes that legitimately accept large payloads
# (channel-archive import, package import, websocket-proxy upgrades) are
# whitelisted via path prefix.
_DEFAULT_BODY_LIMIT = 64 * 1024 * 1024
_BODY_LIMIT_OVERRIDES: tuple[tuple[str, int], ...] = (
    # Channel archives can carry every cell + every blob in the channel —
    # easily hundreds of MB on a busy channel.
    ("/api/channels/import", 2 * 1024 * 1024 * 1024),
    ("/api/channels/inspect_archive", 2 * 1024 * 1024 * 1024),
    ("/api/channels/merge_archive", 2 * 1024 * 1024 * 1024),
    # Generator/renderer package archives — bigger than typical bodies but
    # capped so a misuploaded blob can't drown the worker.
    ("/api/packages/", 512 * 1024 * 1024),
    # User-settings export bundle. Modest but can include arbitrary files.
    ("/api/user_settings/", 256 * 1024 * 1024),
    # The vscode / codespaces proxy tunnels through arbitrary client
    # traffic; don't cap.
    ("/api/proxy/", 0),
)


def _limit_for_path(path: str) -> int:
    """Return the body cap (bytes) for a given request path. ``0`` means
    no cap (proxy passthrough). Default applies if no prefix matches."""
    for prefix, limit in _BODY_LIMIT_OVERRIDES:
        if path.startswith(prefix):
            return limit
    return _DEFAULT_BODY_LIMIT


@app.middleware("http")
async def _body_size_limit(request, call_next):
    limit = _limit_for_path(request.url.path)
    if limit > 0:
        cl = request.headers.get("content-length")
        if cl is not None:
            try:
                if int(cl) > limit:
                    return JSONResponse(
                        status_code=413,
                        content={
                            "detail": "request body too large",
                            "limit_bytes": limit,
                        },
                    )
            except ValueError:
                # Malformed Content-Length — let the framework reject it
                # rather than guessing.
                pass
    return await call_next(request)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Per-session live-webview origins: route requests whose Host subdomain is a
# registered session token straight to that session's daemon. Added last so it
# wraps as the OUTERMOST middleware — a session subdomain is fully handled here
# and never reaches normal routing; everything else passes through untouched.
if not IS_WASM:
    app.add_middleware(SessionSubdomainProxy)

# When a native-only capability (subprocess, Docker, keyring) is invoked
# under pyodide, the code raises WasmNotSupportedError. Translate that to
# a clean 503 so the frontend can render a "not in playground" message
# instead of a generic 500 with a traceback.
from runtime import WasmNotSupportedError


@app.exception_handler(WasmNotSupportedError)
async def _wasm_not_supported_handler(request, exc: WasmNotSupportedError):
    return JSONResponse(
        status_code=503,
        content={"detail": str(exc), "code": "wasm_not_supported"},
    )


# Liveness: process is up and the event loop is responsive. Cheap; no I/O.
@app.get("/health")
async def health():
    return {"status": "ok"}


# Readiness: the things the app needs to actually serve traffic — DB
# reachable, blob dir writable. Returns 503 with details so an orchestrator
# can keep traffic off until the install is healthy.
@app.get("/ready")
async def ready():
    checks: dict = {}
    ok = True

    try:
        from database import get_db_connection
        conn = get_db_connection("starting")
        conn.execute("SELECT 1").fetchone()
        conn.close()
        checks["db"] = "ok"
    except Exception as exc:
        ok = False
        checks["db"] = f"error: {exc}"

    cas_dir = os.path.join(".collimate", "objects")
    try:
        os.makedirs(cas_dir, exist_ok=True)
        if not os.access(cas_dir, os.W_OK):
            raise PermissionError(f"{cas_dir} not writable")
        checks["cas"] = "ok"
    except Exception as exc:
        ok = False
        checks["cas"] = f"error: {exc}"

    # CAS disk usage — informational only, never 503's. Surfaces the
    # trend so an operator can spot runaway growth before disks fill.
    try:
        import cas_gc
        usage = cas_gc.disk_usage()
        checks["cas_blobs"] = usage["blob_count"]
        checks["cas_bytes"] = usage["bytes"]
        if usage.get("trash_bytes"):
            checks["cas_trash_bytes"] = usage["trash_bytes"]
    except Exception as exc:
        checks["cas_usage"] = f"error: {exc}"

    # Templates integrity. Drift is a *warning*, not a 503-worthy
    # failure — generators still load with whatever's on disk. But it
    # surfaces the case where someone edited api/templates/ in place
    # and lost their work the next time the build script vendored over
    # them. ``no_manifest`` is fine in local dev where the build was
    # never run.
    try:
        import templates_integrity
        templates_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates")
        result = templates_integrity.verify_manifest(templates_dir)
        if result["status"] == "drift":
            n = (
                len(result["mismatched"])
                + len(result["missing"])
                + len(result["extra"])
            )
            checks["templates"] = f"drift: {n} files differ from .checksum.json"
        elif result["status"] == "no_manifest":
            checks["templates"] = "no_manifest (local dev — run build/build_server.sh to stamp)"
        else:
            checks["templates"] = "ok"
    except Exception as exc:
        # Verification itself failing shouldn't 503 the server.
        checks["templates"] = f"verify_error: {exc}"

    if not ok:
        return JSONResponse(status_code=503, content={"status": "not_ready", "checks": checks})
    return {"status": "ok", "checks": checks}


# --- Existing UI routes ---
app.include_router(system_router)
app.include_router(windows_router)
app.include_router(generation_router)
app.include_router(generator_config_tags_router)
app.include_router(generator_manifest_edit_router)

# --- New execution-pipeline routes ---
app.include_router(runs_router)
app.include_router(snapshot_router)
app.include_router(packages_router)
if not IS_WASM:
    app.include_router(proxy_router)
app.include_router(blobs_router)
app.include_router(cells_router)
app.include_router(terminal_router)
app.include_router(chat_live_router)
# Local-filesystem routes for "file sync" mode. Registered unconditionally;
# the handlers self-guard with WasmNotSupportedError → 503 under pyodide
# (there is no local disk in the playground), and the UI gates the Sync
# affordance on !IS_WASM so they're never called there anyway.
app.include_router(fs_router)

# ---------------------------------------------------------------------------
# Static file serving — bundled Vite frontend
# ---------------------------------------------------------------------------
_static_dir = os.path.join(current_dir, "static")
_INDEX_PATH = os.path.join(_static_dir, "index.html")


def _render_index_with_runtime_config() -> str | None:
    """Read api/static/index.html and inject window.__COLLIMATE_CONFIG__
    inline before </head>.

    Why inject at serve-time instead of bundling a runtime fetch:
    Vite's HTML processor refuses non-module <script src> tags, and
    declaring it as a module makes Vite try to resolve the path as a
    local entry at build time (the config endpoint isn't on disk).
    Doing the injection here keeps the static bundle untouched and
    sidesteps the build-tooling fight.

    Returns None if the index.html doesn't exist (dev mode without a
    bundled frontend); the StaticFiles mount handles that branch.
    """
    if not os.path.isfile(_INDEX_PATH):
        return None
    try:
        with open(_INDEX_PATH, "r", encoding="utf-8") as f:
            html = f.read()
    except OSError:
        return None
    api_base = os.environ.get("COLLIMATE_PUBLIC_API_BASE", "../api")
    import json as _json
    payload = _json.dumps({"apiBase": api_base})
    # The PWA manifest link is *only* injected here (not in the static
    # bundle) so the GitHub Pages playground — which ships the same
    # frontend bundle but is served by Pyodide, not FastAPI — never
    # advertises a manifest. That keeps Chrome's install icon out of
    # the playground UI. main.tsx applies the same gating to SW
    # registration on the frontend side.
    snippet = (
        "<script>"
        f"window.__COLLIMATE_CONFIG__ = {payload};"
        "</script>"
        '<link rel="manifest" href="./manifest.webmanifest">'
    )
    # Inject just before </head>; falls through to <body> for HTML
    # documents that lack a head close tag (shouldn't happen but
    # don't hard-fail). Worst case the snippet ends up nowhere and
    # the frontend uses build-time defaults.
    if "</head>" in html:
        return html.replace("</head>", snippet + "</head>", 1)
    if "<body" in html:
        return html.replace("<body", snippet + "<body", 1)
    return html


if os.path.isdir(_static_dir):
    @app.get("/", include_in_schema=False)
    @app.get("/index.html", include_in_schema=False)
    async def _serve_index_with_config():
        rendered = _render_index_with_runtime_config()
        if rendered is None:
            return JSONResponse(
                status_code=404, content={"detail": "index.html not built"},
            )
        return Response(content=rendered, media_type="text/html")

    app.mount("/", StaticFiles(directory=_static_dir, html=True), name="static")


def cli_main() -> None:
    """Console entry point — `collimate` in PATH after `pip install collimate`.

    Runs the FastAPI app on loopback so pip-installed end users get the
    same behaviour as `python main.py` from a source checkout. Kept
    deliberately thin — further configuration knobs (log level, reload)
    can grow as flags when someone actually asks for them.

    Bind rationale: loopback only. Browsers grant http://localhost and
    http://127.0.0.1 a "secure context" for free, which is what code-
    server webviews and the Claude Code extension need (service
    workers, clipboard APIs, etc.). HTTPS would require a trusted cert,
    which can't be done zero-setup. Loopback-only also means the API
    isn't exposed to the LAN by accident.
    """
    import argparse

    import uvicorn

    parser = argparse.ArgumentParser(
        prog="collimate",
        description=(
            "Run the Collimate server, headless, on loopback. "
            "Open the printed URL in a browser, or use `collimateapp` for a full app window."
        ),
    )
    parser.add_argument(
        "-p", "--port", type=int, default=5001, metavar="N",
        help=(
            "port to listen on (default: 5001). Always binds loopback only "
            "(127.0.0.1), so changing the port never exposes the server to the LAN."
        ),
    )
    args = parser.parse_args()
    port = args.port

    print(f"\n  Collimate is running at:  http://localhost:{port}\n")
    # Discovery hints: `collimate` is the most obvious thing to run, so this
    # is where people learn the other entry points exist.
    print(
        "  Other ways to run it:\n"
        "    collimate --port N            run on a different port (default 5001)\n"
        "    collimateapp                  the same server in a full app window\n"
        "                                  (from uvx: uvx --from collimate collimateapp)\n"
        "    uv tool install collimate     keep it: collimate + collimateapp on PATH\n"
        "    collimate-app-shortcut        desktop launcher with the app icon (after install)\n"
    )
    uvicorn.run(app, host="127.0.0.1", port=port)


if __name__ == "__main__":
    cli_main()
