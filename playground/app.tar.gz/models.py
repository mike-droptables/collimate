from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional
from uuid import UUID, uuid4
from datetime import datetime
from enum import Enum


class Role(str, Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"


class CellState(str, Enum):
    PICKING = "Picking"  # Transient, client-only; reserved enum value
    STANDARD = "Standard"


class Placement(str, Enum):
    """Where additional `create`-output cells emitted during a run land.

    Bound to the running cell. The three-type rework introduces a
    per-cell, channel-defaulted placement toggle that the user can
    flip while a cell is running.

      - under:     new cell appended to the running cell's stack,
                   directly below the running cell.
      - new_stack: new cell goes into a fresh stack to the right of
                   the running cell's stack.
      - on_top:    new cell is prepended to the stack immediately to
                   the right of the running cell's stack (creates the
                   stack if no neighbor exists).
    """
    UNDER = "under"
    NEW_STACK = "new_stack"
    ON_TOP = "on_top"


class Message(BaseModel):
    role: Role = Role.USER
    content: str
    timestamp: datetime = Field(default_factory=datetime.now)


class VirtualFile(BaseModel):
    name: str
    language: str = "markdown"
    content: str = ""
    timestamp: datetime = Field(default_factory=datetime.now)
    # When set, the file's bytes live in CAS under this SHA-256 hash and
    # ``content`` is empty — the representation for binary files (images,
    # etc.). Declared so it round-trips through update_top into state and
    # back out on broadcast; never UTF-8-decoded.
    blob_hash: Optional[str] = None


class Cell(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    name: str = "New Cell"
    summary: str = "Enter a summary..."
    # Optional picker glyph for generator-source cells: a free-form
    # lucide-style icon name the frontend resolves via its ICON_REGISTRY.
    # Stored alongside name/summary; surfaced as the "group icon" for every
    # generator declared in this cell. Null = no custom icon.
    icon: Optional[str] = None
    files: List[VirtualFile] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)
    state: CellState = CellState.STANDARD
    # Flat {key: value} dict of settings the user chose from the
    # generator's settings schema form. Null if the generator has no
    # settings schema.
    settings: Optional[Dict[str, Any]] = None
    logs: List[str] = Field(default_factory=list)
    # Links this UI cell to a run in the execution pipeline
    run_id: Optional[str] = None
    channel: Optional[str] = None
    # File path (within this cell's files) pinned as the cell's preview —
    # rendered in the UI's "Pinned" tab. Mirrors the frontend Cell type.
    pinned: Optional[str] = None
    # Transient: where additional cells this run emits should land.
    # Set when a cell starts running (initialized from the channel's
    # placement_default), updated when the user flips the toggle on
    # the cell's log slot, cleared when the run ends. None on idle
    # cells.
    placement: Optional[Placement] = None


class Stack(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    name: str = ""
    cells: List[Cell] = Field(default_factory=list)
    width: int = 33  # Percentage: 33, 50, 66, 100
    prev_width: int = 33  # For toggling full size
    stack_type: str = "standard"  # 'standard' | 'generator' | 'renderer'


class Channel(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    name: str = "General"
    nav_stacks: List[Stack] = Field(default_factory=list)
    main_stacks: List[Stack] = Field(default_factory=list)
    nav_selection_id: Optional[UUID] = None
    main_selection_id: Optional[UUID] = None
    # Default placement for new cells emitted during a run. Each new
    # running cell inherits this value at run start; flipping the
    # toggle on a running cell's log slot updates both the cell's
    # transient `placement` and this channel default so future runs
    # inherit the same choice.
    placement_default: Placement = Placement.UNDER


class AppState(BaseModel):
    channels: List[Channel] = Field(default_factory=list)
    active_channel_id: Optional[UUID] = None


class DivergenceRequest(BaseModel):
    prompt: str
