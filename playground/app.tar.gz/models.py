from pydantic import BaseModel, Field
from typing import List, Optional
from uuid import UUID, uuid4
from datetime import datetime
from enum import Enum


class Role(str, Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"


class CellState(str, Enum):
    PICKING = "Picking"  # Transient, client-only; reserved enum value
    DRAFT = "Draft"
    STANDARD = "Standard"


class Message(BaseModel):
    role: Role = Role.USER
    content: str
    timestamp: datetime = Field(default_factory=datetime.now)


class VirtualFile(BaseModel):
    name: str
    language: str = "markdown"
    content: str
    timestamp: datetime = Field(default_factory=datetime.now)


class Cell(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    name: str = "New Cell"
    summary: str = "Enter a summary..."
    files: List[VirtualFile] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)
    state: CellState = CellState.STANDARD
    # Ordered values along the user's path through the generator's
    # .pickoptions tree/sequence. Null if no pickoptions were used.
    pickoptions_path: Optional[List] = None
    # Draft-only: generator id that this Draft will run when promoted.
    draft_generator_id: Optional[str] = None
    logs: List[str] = Field(default_factory=list)
    # Per-cell on/off toggle for generator/renderer stacks. Disabled cells stay
    # on the stack but are skipped by generator/renderer discovery.
    enabled: bool = True
    # Links this UI cell to a run in the execution pipeline
    run_id: Optional[str] = None
    channel: Optional[str] = None
    # File path (within this cell's files) that the UI renders as the
    # cell's summary view. Mirrors the frontend Cell type.
    summary_artifact: Optional[str] = None


class Stack(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    name: str = ""
    cells: List[Cell] = Field(default_factory=list)
    width: int = 33  # Percentage: 33, 50, 66, 100
    prev_width: int = 33  # For toggling full size
    stack_type: str = "standard"  # 'standard' | 'generator' | 'renderer'


class Channel(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    name: str = "General"
    nav_stacks: List[Stack] = Field(default_factory=list)
    main_stacks: List[Stack] = Field(default_factory=list)
    nav_selection_id: Optional[UUID] = None
    main_selection_id: Optional[UUID] = None


class AppState(BaseModel):
    channels: List[Channel] = Field(default_factory=list)
    active_channel_id: Optional[UUID] = None


class DivergenceRequest(BaseModel):
    prompt: str
