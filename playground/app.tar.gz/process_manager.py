"""
ProcessManager — manages generator subprocess lifecycle.

Key responsibilities:
  - Launch generator via `uv run <entrypoint>` with strict directory isolation
  - Communicate over a localhost TCP socket for IPC
  - Forward stdout/stderr blindly to the run_events log table
  - Handle explicit artifact commits (no more os.walk snapshotting)
  - ACK commits via the TCP socket so generators can block until CAS write completes
"""

import asyncio
import json
import os
import re
import uuid
from collections import deque
from datetime import datetime
from database import get_db_connection
from cas import hash_and_store_file, hash_and_store_bytes

# Matches 7-bit C1 ANSI sequences
ANSI_ESCAPE_REGEX = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')


class ProcessManager:
    def __init__(
        self,
        channel: str,
        run_id: str,
        app_dir: str,
        workspace_dir: str,
        entrypoint: str,
        generator_name: str = "default",
        params: dict | None = None,
        placeholder_cell_id: str | None = None,
        input_cell_ids: list[str] | None = None,
        initial_settings_content: str | None = None,
        initial_settings_filename: str | None = None,
    ):
        from database import _slug_channel
        self.channel = _slug_channel(channel)
        self.run_id = run_id
        self.app_dir = app_dir              # Generator code dir (CWD, read-only)
        self.workspace_dir = workspace_dir  # Hydrated input files (read/write)
        self.entrypoint = entrypoint
        self.generator_name = generator_name
        self.params = params or {}
        self.input_cell_ids = input_cell_ids or []

        # Settings content accumulated across the run. Flushed into the
        # first cell's version tip at finalization alongside logs.
        # Each tuple: (name_stem, extension, content).
        # The initial settings (from `POST /runs`) start the list; each
        # mid-run `request_settings_update` appends another entry.
        self.settings_history: list[tuple[str, str, str]] = []
        self._settings_update_count: int = 0
        if initial_settings_content is not None and initial_settings_filename:
            ext = os.path.splitext(initial_settings_filename)[1] or ""
            self.settings_history.append(
                ("initial_settings", ext, initial_settings_content)
            )
        # Every run auto-creates a placeholder cell. This is the visible
        # cell id on the canvas that update_cell() mutates.
        self.placeholder_cell_id = placeholder_cell_id

        # Per-run target stack tracking for the portal-recursion placement rule
        # (see api/cell_placement.py). Updated after every commit and snapshot
        # so subsequent placements know where the previous one landed.
        self.current_target_stack_id: str | None = None

        # Stack id used by create_side_cell — first call creates a new
        # stack, subsequent calls append to it.
        self.side_stack_id: str | None = None

        # 10MB Ring Buffer to prevent memory exhaustion
        self.log_buffer: deque = deque(maxlen=10000)
        self.process = None
        self._last_cell_id: str | None = None

        # Snapshot capability — populated when the generator emits a
        # `port_bound` message that includes a `snapshot_source` block.
        # When present, the backend can pull files out of a running docker
        # container on demand (used by the snapshot endpoint).
        self.snapshot_source: dict | None = None

        # Queue of user messages pushed by the frontend, consumed by the
        # generator subprocess via the poll_user_message IPC op.
        self._pending_user_messages: list[str] = []

        # Queue of renderer-emitted action ids (e.g. top-bar button clicks
        # from the .website renderer). Consumed via poll_renderer_action.
        self._pending_renderer_actions: list[str] = []

        # Blocking settings-update flow: generator calls
        # request_settings_update(), we broadcast an SSE event and wait
        # for the user to press Continue via the /settings_continue
        # endpoint which sets the values and signals the event.
        self._pending_settings_update: asyncio.Event | None = None
        self._settings_update_values: dict | None = None

        # IPC via localhost TCP socket
        self._ipc_server: asyncio.Server | None = None
        self._ipc_writer: asyncio.StreamWriter | None = None

        # Wasm run state. Native runs use the subprocess lifecycle + IPC
        # above; wasm runs are dispatched in-process by _run_wasm and
        # cooperate via these flags (see collimate.wasm_sdk.WasmHost).
        self._cancelled: bool = False
        self._emit_partial_called: bool = False
        self._last_emit_cell_name: str | None = None
        self._last_emit_summary: str | None = None

    def append_settings_update(self, content: str, filename: str) -> None:
        """Record a mid-run settings update. Called by the
        /settings_continue endpoint after the user presses Continue.
        The entry is included in the finalization overlay alongside the
        initial settings and the log file."""
        self._settings_update_count += 1
        ext = os.path.splitext(filename or "")[1] or ""
        name_stem = f"update_settings_{self._settings_update_count}"
        self.settings_history.append((name_stem, ext, content))

    async def start(self):
        """Launch the generator subprocess with TCP-based IPC, OR (under wasm)
        dispatch the generator in-process via the collimate.wasm_sdk path."""
        from runtime import IS_WASM, WasmNotSupportedError
        if IS_WASM:
            manifest = self._load_manifest_for_runtime()
            rt = (manifest.get("runtime") or "native").lower()
            if rt not in ("wasm", "both"):
                raise WasmNotSupportedError(
                    f"Generator {self.generator_name!r} declares runtime {rt!r}. "
                    "Only generators with `runtime: wasm` (or `both`) can run "
                    "in the pyodide playground. Try the native backend."
                )
            # Dispatch the wasm run as a background task so POST /runs
            # returns immediately with status=running. The UI observes
            # progress via emit_partial + polling /api/state; _reap_process
            # awaits this task and cleans up active_managers when the
            # generator returns.
            self._cleanup_task = asyncio.create_task(
                self._run_wasm_supervised(manifest)
            )
            return

        env = os.environ.copy()
        env["COLLIMATE_CHANNEL"] = self.channel
        env["COLLIMATE_RUN_ID"] = self.run_id
        env["COLLIMATE_WORKSPACE"] = self.workspace_dir
        merged_params = self._load_params_from_manifest()
        merged_params.update(self.params)
        env["COLLIMATE_PARAMS"] = json.dumps(merged_params)
        # Every run auto-creates a placeholder cell. The generator sees
        # it as its "first cell" and mutates it via update_cell().
        if self.placeholder_cell_id:
            env["COLLIMATE_IN_PLACE_CELL_ID"] = self.placeholder_cell_id

        # Add SDK to PYTHONPATH so generators can import collimate.sdk
        project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        sdk_src = os.path.join(project_root, "collimate-sdk", "src")
        existing = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = sdk_src + os.pathsep + existing if existing else sdk_src

        # Where this generator's runtime copy lives — `gen.shared()` uses
        # this to resolve its own ``shared/`` directory. The generator's
        # cwd already equals this, but we set the env var explicitly so
        # gen.shared() does not depend on cwd remaining unchanged.
        env["COLLIMATE_APP_DIR"] = self.app_dir

        # Source root of all generators on disk — `gen.shared("other")`
        # resolves cross-generator references against this. Points at the
        # bundled api/templates/generators tree by default.
        from genesis import GENERATORS_DIR
        env["COLLIMATE_GENERATORS_DIR"] = GENERATORS_DIR

        # Start a TCP server on an ephemeral port for IPC
        self._ipc_server = await asyncio.start_server(
            self._handle_ipc_connection, "127.0.0.1", 0
        )
        port = self._ipc_server.sockets[0].getsockname()[1]
        env["COLLIMATE_IPC_PORT"] = str(port)

        self.process = await asyncio.create_subprocess_exec(
            "uv", "run", self.entrypoint,
            cwd=self.app_dir,
            env=env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            stdin=asyncio.subprocess.PIPE,
            start_new_session=(os.name != "nt"),
        )

        # Start async readers
        self._stdout_task = asyncio.create_task(self._drain_stdout())
        self._stderr_task = asyncio.create_task(self._drain_stderr())
        self._writer_task = asyncio.create_task(self._microbatch_writer())
        self._cleanup_task = asyncio.create_task(self._wait_and_cleanup())

    def _load_params_from_manifest(self) -> dict:
        """Extract default parameter values from manifest.gen_yaml in the app_dir."""
        manifest_path = os.path.join(self.app_dir, "manifest.gen_yaml")
        if not os.path.isfile(manifest_path):
            return {}
        try:
            import yaml
            with open(manifest_path, "r") as f:
                manifest = yaml.safe_load(f)
            params = manifest.get("parameters") or {}
            return {k: v.get("default", "") for k, v in params.items() if isinstance(v, dict)}
        except Exception:
            return {}

    # ------------------------------------------------------------------
    # Stream draining — stdout/stderr go straight to log buffer
    # ------------------------------------------------------------------

    async def _drain_stdout(self):
        """Forward stdout to the log buffer (human-readable logs only)."""
        assert self.process and self.process.stdout
        while True:
            chunk = await self.process.stdout.read(4096)
            if not chunk:
                break
            clean = ANSI_ESCAPE_REGEX.sub("", chunk.decode("utf-8", errors="replace"))
            if clean:
                self.log_buffer.append({"type": "stdout", "payload": clean})

    async def _drain_stderr(self):
        """Forward stderr to the log buffer."""
        assert self.process and self.process.stderr
        while True:
            chunk = await self.process.stderr.read(4096)
            if not chunk:
                break
            clean = ANSI_ESCAPE_REGEX.sub("", chunk.decode("utf-8", errors="replace"))
            if clean:
                self.log_buffer.append({"type": "stderr", "payload": clean})

    # ------------------------------------------------------------------
    # IPC channel (localhost TCP socket) — JSON-per-line protocol
    # ------------------------------------------------------------------

    async def _handle_ipc_connection(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        """Handle the generator's TCP connection for IPC messages."""
        self._ipc_writer = writer
        try:
            while True:
                line = await reader.readline()
                if not line:
                    break
                if len(line) > 10_000_000:
                    self.log_buffer.append({"type": "stderr", "payload": "[IPC] Message exceeded 10MB limit, dropping"})
                    continue
                await self._handle_ipc(line.decode("utf-8", errors="replace").strip())
        except Exception as e:
            self.log_buffer.append({"type": "stderr", "payload": f"[IPC Error] {e}"})
        finally:
            writer.close()
            await writer.wait_closed()
            self._ipc_writer = None

    async def _handle_ipc(self, line: str):
        """Process a single IPC JSON message."""
        if not line:
            return
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            self.log_buffer.append({"type": "ipc_error", "payload": line})
            return

        op = data.get("op")

        if op == "update_cell":
            try:
                if data.get("initial", False):
                    await asyncio.to_thread(self._update_cell_initial, data)
                else:
                    await asyncio.to_thread(self._update_cell, data)
            except Exception as exc:
                self.log_buffer.append({"type": "stderr", "payload": f"[update_cell error] {exc}"})
            if self._ipc_writer:
                ack = json.dumps({"op": "ack_update", "cell_id": self._last_cell_id or ""}) + "\n"
                self._ipc_writer.write(ack.encode())
                await self._ipc_writer.drain()
            self._broadcast_dag_commit()

        elif op == "create_side_cell":
            try:
                await asyncio.to_thread(self._create_side_cell, data)
            except Exception as exc:
                self.log_buffer.append({"type": "stderr", "payload": f"[create_side_cell error] {exc}"})
            if self._ipc_writer:
                ack = json.dumps({"op": "ack_create_side_cell", "cell_id": self._last_cell_id or ""}) + "\n"
                self._ipc_writer.write(ack.encode())
                await self._ipc_writer.drain()
            self._broadcast_dag_commit()

        elif op == "request_settings_update":
            ack_body: dict = {"op": "ack_settings_update"}
            try:
                settings_file_path = data.get("settings_file_path", "")
                abs_path = os.path.join(self.workspace_dir, settings_file_path)
                if not os.path.isfile(abs_path):
                    raise RuntimeError(f"settings file not found: {settings_file_path}")
                with open(abs_path, "r", encoding="utf-8") as f:
                    settings_content = f.read()

                # Write to run_events so the per-run SSE stream picks it up
                self.log_buffer.append({
                    "type": "settings_update_requested",
                    "payload": json.dumps({
                        "run_id": self.run_id,
                        "cell_id": self.placeholder_cell_id or "",
                        "settings_content": settings_content,
                        "settings_file_path": settings_file_path,
                    }),
                })

                # Block until the user presses Continue
                self._pending_settings_update = asyncio.Event()
                self._settings_update_values = None
                await self._pending_settings_update.wait()

                ack_body["ok"] = True
                ack_body["values"] = self._settings_update_values or {}
            except Exception as exc:
                ack_body["ok"] = False
                ack_body["error"] = str(exc)
            finally:
                self._pending_settings_update = None
            if self._ipc_writer:
                self._ipc_writer.write((json.dumps(ack_body) + "\n").encode())
                await self._ipc_writer.drain()

        elif op == "chat_start_session":
            ack_body = {"op": "ack_chat_start_session"}
            try:
                cell_id = data.get("cell_id", "")
                target_id = self.placeholder_cell_id
                if not target_id or cell_id != target_id:
                    raise RuntimeError(
                        "chat ops are only allowed against the run's target cell"
                    )
                from chat_session import start_session
                result = await start_session(
                    channel_db_name=self.channel,
                    cell_id=cell_id,
                    model=data.get("model", "sonnet"),
                    system_prompt=data.get("system_prompt", "") or "",
                    backend=data.get("backend", "claude_code_session"),
                    image=data.get("image", "") or "",
                    dockerfile_dir=data.get("dockerfile_dir", "") or "",
                    shared=bool(data.get("shared", True)),
                )
                ack_body.update(result)
                ack_body["ok"] = True
            except Exception as exc:
                ack_body["ok"] = False
                ack_body["error"] = str(exc)
            if self._ipc_writer:
                self._ipc_writer.write((json.dumps(ack_body) + "\n").encode())
                await self._ipc_writer.drain()

        elif op == "chat_send_turn":
            ack_body = {"op": "ack_chat_send_turn"}
            try:
                cell_id = data.get("cell_id", "")
                target_id = self.placeholder_cell_id
                if not target_id or cell_id != target_id:
                    raise RuntimeError(
                        "chat ops are only allowed against the run's target cell"
                    )
                from chat_session import send_turn
                result = await send_turn(
                    channel_db_name=self.channel,
                    cell_id=cell_id,
                    content=data.get("content", ""),
                )
                ack_body.update(result)
                ack_body["ok"] = True
            except Exception as exc:
                ack_body["ok"] = False
                ack_body["error"] = str(exc)
            if self._ipc_writer:
                self._ipc_writer.write((json.dumps(ack_body) + "\n").encode())
                await self._ipc_writer.drain()

        elif op == "create_terminal_session":
            ack_body = {"op": "ack_create_terminal_session"}
            try:
                cell_id = data.get("cell_id", "")
                target_id = self.placeholder_cell_id
                if not target_id or cell_id != target_id:
                    raise RuntimeError(
                        "terminal ops are only allowed against the run's target cell"
                    )
                from routes.terminal import register_session
                result = register_session(
                    cell_id=cell_id,
                    container_id=data.get("container_id", "") or "",
                    command=list(data.get("command") or []),
                    cwd=data.get("cwd") or None,
                    env=data.get("env") or {},
                )
                ack_body.update(result)
                ack_body["ok"] = True
            except Exception as exc:
                ack_body["ok"] = False
                ack_body["error"] = str(exc)
            if self._ipc_writer:
                self._ipc_writer.write((json.dumps(ack_body) + "\n").encode())
                await self._ipc_writer.drain()

        elif op == "destroy_terminal_session":
            try:
                from routes.terminal import unregister_session
                unregister_session(data.get("session_id", "") or "")
            except Exception as exc:
                self.log_buffer.append({
                    "type": "stderr",
                    "payload": f"[destroy_terminal_session error] {exc}",
                })

        elif op == "poll_user_message":
            content = None
            if self._pending_user_messages:
                content = self._pending_user_messages.pop(0)
            ack_body = {"op": "ack_poll_user_message", "content": content}
            if self._ipc_writer:
                self._ipc_writer.write((json.dumps(ack_body) + "\n").encode())
                await self._ipc_writer.drain()

        elif op == "poll_renderer_action":
            action_id = None
            if self._pending_renderer_actions:
                action_id = self._pending_renderer_actions.pop(0)
            ack_body = {"op": "ack_poll_renderer_action", "action_id": action_id}
            if self._ipc_writer:
                self._ipc_writer.write((json.dumps(ack_body) + "\n").encode())
                await self._ipc_writer.drain()

        elif op == "chat_stream_event":
            from events import broadcast
            broadcast(self.channel, {
                "type": "chat_stream",
                "cell_id": data.get("cell_id", ""),
                "turn_id": data.get("turn_id", ""),
                "event": data.get("event", {}),
            })

        elif op == "finish":
            success = data.get("success", True)
            status = "completed" if success else "failed"
            error_msg = data.get("error_message", "")
            self.log_buffer.append({
                "type": "finish",
                "payload": json.dumps({"success": success, "error_message": error_msg}),
            })
            conn = get_db_connection(self.channel)
            conn.execute("UPDATE runs SET status=? WHERE id=?", (status, self.run_id))
            conn.commit()
            conn.close()
            self._broadcast_run_status(status)

        else:
            if op == "port_bound":
                src = data.get("snapshot_source")
                if isinstance(src, dict):
                    self.snapshot_source = src
            self.log_buffer.append({"type": op, "payload": json.dumps(data)})

    def _broadcast_dag_commit(self):
        """Broadcast DAG commit + state update to SSE subscribers."""
        from events import broadcast
        broadcast(self.channel, {
            "type": "dag_commit",
            "cell_id": self._last_cell_id,
            "run_id": self.run_id,
            "generator_name": self.generator_name,
        })
        try:
            from state import state, channel_db_name, strip_large_content
            state_dict = state.model_dump(mode="json")
            stripped = strip_large_content(state_dict)
            for ch_obj in state.channels:
                if channel_db_name(ch_obj) == self.channel:
                    broadcast(self.channel, {"type": "state_update", "state": stripped})
                    break
        except Exception:
            pass

    async def _wait_and_cleanup(self):
        """Wait for the process to exit, then finalize status and clean up."""
        await self.process.wait()

        # Wait for the output streams to fully drain
        if hasattr(self, '_stdout_task'):
            await asyncio.gather(self._stdout_task, self._stderr_task, return_exceptions=True)

        # Give IPC a moment to drain any final messages
        await asyncio.sleep(0.2)

        # Wait for the microbatch writer to finish its final flush before
        # we touch the DB — otherwise _finalize_run_status races with the
        # writer's last INSERT and both hit "database is locked".
        if hasattr(self, '_writer_task'):
            await self._writer_task

        await asyncio.to_thread(self._finalize_run_status)

        # Drop any chat sandbox session this run owned. Refcount-based:
        # the sandbox container shuts down when the last session closes.
        # No silent keep-alive — when the cell stops, the container goes.
        if self.placeholder_cell_id:
            try:
                from chat_session import evict_session
                await evict_session(self.placeholder_cell_id)
            except Exception as exc:
                print(f"[process_manager] evict_session failed: {exc}")
            # Drop any terminal sessions attached to this cell. Belt-and-
            # suspenders: well-behaved generators call stop_terminal() in
            # a try/finally, but this catches leaks if they don't.
            try:
                from routes.terminal import unregister_sessions_for_cell
                unregister_sessions_for_cell(self.placeholder_cell_id)
            except Exception as exc:
                print(f"[process_manager] unregister_sessions_for_cell failed: {exc}")

        if self._ipc_server:
            self._ipc_server.close()
            await self._ipc_server.wait_closed()

        # Ensure all remaining logs are flushed after IPC server shuts down
        await asyncio.to_thread(self._flush_log_buffer)

    # ------------------------------------------------------------------
    # Artifact hashing helpers
    # ------------------------------------------------------------------

    def _hash_artifacts(self, data: dict) -> dict[str, str]:
        """Hash artifact list from IPC payload into {cell_path: blob_hash}.

        Shared by update_cell, create_side_cell, and update_cell_initial.
        """
        artifacts = data.get("artifacts", [])
        files: dict[str, str] = {}

        for art in artifacts:
            art_type = art.get("type", "workspace")
            cell_path = art.get("cell_path", "")

            norm = cell_path.replace("\\", "/").lstrip("/")
            if (norm == ".colreserved" or norm.startswith(".colreserved/")) and norm != ".colreserved/.collimate_messages.json":
                continue

            if art_type == "workspace":
                local_path = art.get("local_path", cell_path)
                abs_path = os.path.join(self.workspace_dir, local_path)
                if not os.path.isfile(abs_path):
                    continue
                blob_hash = self._hash_and_store_file(abs_path)
                if blob_hash:
                    files[cell_path] = blob_hash

            elif art_type == "memory":
                content = art.get("content", "")
                encoding = art.get("encoding", "utf-8")
                if encoding == "base64":
                    import base64
                    raw = base64.b64decode(content)
                else:
                    raw = content.encode("utf-8")
                blob_hash = self._hash_and_store_bytes(raw)
                if blob_hash:
                    files[cell_path] = blob_hash

        return files

    def _consume_chat_pending_files(self, target_id: str) -> dict[str, str]:
        """Pull pending file hashes from chat_session (if any)."""
        try:
            from chat_session import consume_pending_files
            return consume_pending_files(target_id) or {}
        except Exception:
            return {}

    def _consume_chat_deleted_files(self, target_id: str) -> set[str]:
        """Pull pending deleted file paths from chat_session (if any)."""
        try:
            from chat_session import consume_pending_deleted_files
            return consume_pending_deleted_files(target_id)
        except Exception:
            return set()

    def _collect_inmemory_cell_files(self, cell_id: str) -> dict[str, str]:
        """Hash files from the in-memory cell that aren't in the DB yet.

        User edits via the Files tab (add file, edit content) update the
        in-memory Cell object but don't create DB rows until the next
        update_cell. This method captures those files so they survive
        the merge.
        """
        from cell_placement import find_stack_containing_cell

        ch = self._find_channel()
        if ch is None:
            return {}

        stack = find_stack_containing_cell(ch, cell_id)
        if stack is None:
            return {}

        result: dict[str, str] = {}
        for c in stack.cells:
            if str(c.id) == cell_id:
                for vf in c.files or []:
                    path = (vf.name or "").replace("\\", "/").lstrip("/")
                    # Skip .colreserved — managed by SDK, not user files.
                    # Exception: chat messages live at
                    # .colreserved/.collimate_messages.json and are
                    # mutated in-memory by chat_session._append_message
                    # (user + assistant turns). If we skipped them here,
                    # an update_cell that fires before the container
                    # flushes its workspace copy would commit with empty
                    # or stale messages, causing the "messages briefly
                    # appear then disappear" flicker.
                    if (path == ".colreserved" or path.startswith(".colreserved/")) \
                            and path != ".colreserved/.collimate_messages.json":
                        continue
                    content = vf.content or ""
                    blob_hash = self._hash_and_store_bytes(content.encode("utf-8"))
                    if blob_hash:
                        result[path] = blob_hash
                break
        return result

    # ------------------------------------------------------------------
    # Cell mutation: update_cell (version row) / update_cell_initial (overwrite)
    # ------------------------------------------------------------------

    def _update_cell(self, data: dict):
        """Mutate the run's first cell with a new internal-version row.

        Finds the version tip from self.placeholder_cell_id and passes
        parents={"previous_version": <tip>} plus in_place=True into
        _record_dag_cell so the cell is mutated on the canvas rather
        than appended as a new one.

        ``name`` and ``summary`` are both Optional — a None value means
        "keep the existing value".
        """
        target_id = self.placeholder_cell_id
        if not target_id:
            self.log_buffer.append({
                "type": "stderr",
                "payload": "[update_cell] refused: no target cell id set",
            })
            return

        files = self._hash_artifacts(data)
        req_name = data.get("name")
        req_summary = data.get("summary")

        tip_id = self._find_version_tip(target_id)

        # Ensure the genesis row exists in the DB. The placeholder cell
        # is created in-memory by the frontend, but _record_dag_cell
        # needs a valid parent to link cell_edges against.
        self._ensure_genesis_row(tip_id)

        prev_name, prev_summary = self._read_version_metadata(tip_id)
        cell_name = req_name if req_name is not None else (prev_name or "Output")
        cell_summary = (
            req_summary if req_summary is not None else (prev_summary or "")
        )

        merged_files = self._read_cell_file_map(tip_id)
        # If the tip has no files (empty placeholder, no prior initial call),
        # seed from input cells so inherited files aren't lost.
        if not merged_files and self.input_cell_ids:
            for input_id in self.input_cell_ids:
                input_tip = self._find_version_tip(input_id)
                merged_files.update(self._read_cell_file_map(input_tip))

        # Pick up files the user added/edited via the UI that aren't in the
        # DB tip yet (e.g. new files added in the Files tab during a session).
        merged_files.update(self._collect_inmemory_cell_files(target_id))

        pending = self._consume_chat_pending_files(target_id)
        chat_deleted = self._consume_chat_deleted_files(target_id)
        merged_files.update(files)
        merged_files.update(pending)

        # Remove files deleted by the daemon or explicitly by the generator
        for path in chat_deleted:
            merged_files.pop(path, None)
        for path in data.get("deleted_files", []):
            merged_files.pop(path, None)

        st = "chat" if self.generator_name in (
            "claude_code_chat", "anthropic_chat", "chat",
            "gemini_chat", "goose_chat",
        ) else "generator"
        self._record_dag_cell(
            data,
            merged_files,
            cell_name,
            cell_summary,
            {"previous_version": tip_id},
            in_place=True,
            source_type=st,
        )

    def _update_cell_initial(self, data: dict):
        """Overwrite the first cell's content without creating a version row.

        Used for the very first update (initial=True) that populates the
        auto-created placeholder with content. The placeholder only exists
        in-memory (no DB row yet), so we INSERT OR REPLACE the cells row
        and do NOT create cell_edges — the version scrubber never shows
        this transient state.
        """
        target_id = self.placeholder_cell_id
        if not target_id:
            self.log_buffer.append({
                "type": "stderr",
                "payload": "[update_cell_initial] refused: no target cell id set",
            })
            return

        files = self._hash_artifacts(data)
        req_name = data.get("name")
        req_summary = data.get("summary")

        # The placeholder may not have a cells row yet (it's created
        # in-memory by the frontend). Check if a tip exists; if not,
        # the target_id IS the tip (it's the genesis row we're about
        # to create).
        tip_id = self._find_version_tip(target_id)

        # Seed from input cells — the placeholder starts empty but the
        # workspace was hydrated from input cell files. Carry those forward
        # so the cell inherits its parent's files.
        merged_files: dict[str, str] = {}
        for input_id in self.input_cell_ids:
            input_tip = self._find_version_tip(input_id)
            merged_files.update(self._read_cell_file_map(input_tip))

        merged_files.update(self._read_cell_file_map(tip_id))
        merged_files.update(self._collect_inmemory_cell_files(target_id))
        pending = self._consume_chat_pending_files(target_id)
        chat_deleted = self._consume_chat_deleted_files(target_id)
        merged_files.update(files)
        merged_files.update(pending)

        # Remove files deleted by the daemon or explicitly by the generator
        for path in chat_deleted:
            merged_files.pop(path, None)
        for path in data.get("deleted_files", []):
            merged_files.pop(path, None)

        cell_name = req_name or "Output"
        cell_summary = req_summary or ""

        conn = get_db_connection(self.channel)

        # Upsert the cells row — the placeholder may not have one yet.
        conn.execute(
            "INSERT INTO cells (id, run_id, generator_name, sequence_num, "
            "version_name, version_summary, source_type) "
            "VALUES (?, ?, ?, 1, ?, ?, 'genesis') "
            "ON CONFLICT(id) DO UPDATE SET "
            "version_name=excluded.version_name, "
            "version_summary=excluded.version_summary",
            (tip_id, self.run_id, self.generator_name,
             cell_name, cell_summary),
        )

        # Replace cell_files for this tip
        conn.execute("DELETE FROM cell_files WHERE cell_id=?", (tip_id,))
        for filepath, blob_hash in merged_files.items():
            cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
            size = 0
            if os.path.exists(cas_path):
                try:
                    size = os.path.getsize(cas_path)
                except OSError:
                    pass
            conn.execute(
                "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                (blob_hash, size),
            )
            conn.execute(
                "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                "VALUES (?, ?, ?)",
                (tip_id, filepath, blob_hash),
            )
        conn.commit()
        conn.close()
        self._last_cell_id = tip_id

        # Refresh in-memory state
        try:
            self._apply_update_to_state(
                tip_id, merged_files, cell_name, cell_summary
            )
        except Exception:
            import traceback
            self.log_buffer.append({
                "type": "stderr",
                "payload": "[update_cell_initial placement] " + traceback.format_exc(),
            })

    # ------------------------------------------------------------------
    # Side cell creation (gen.create_cell)
    # ------------------------------------------------------------------

    def _create_side_cell(self, data: dict):
        """Create a new cell in a side stack.

        First call creates a new stack to the right of the first cell's
        stack; subsequent calls append to the same side stack.
        """
        files = self._hash_artifacts(data)
        cell_name = data.get("name", "Output")
        cell_summary = data.get("summary", "")

        # Pull any chat pending files
        if self.placeholder_cell_id:
            files.update(self._consume_chat_pending_files(self.placeholder_cell_id))

        self._record_side_cell(data, files, cell_name, cell_summary)

    def _record_side_cell(
        self,
        data: dict,
        files: dict[str, str],
        cell_name: str,
        cell_summary: str,
    ):
        """Write a new side cell into the DB and place it in the side stack."""
        import time as _time
        for attempt in range(3):
            try:
                self._record_side_cell_inner(data, files, cell_name, cell_summary)
                return
            except Exception:
                if attempt < 2:
                    _time.sleep(0.5)
                else:
                    raise

    def _record_side_cell_inner(
        self,
        data: dict,
        files: dict[str, str],
        cell_name: str,
        cell_summary: str,
    ):
        conn = get_db_connection(self.channel)

        row = conn.execute(
            "SELECT COALESCE(MAX(sequence_num), 0) FROM cells WHERE run_id=?",
            (self.run_id,),
        ).fetchone()
        seq = row[0] + 1

        cell_id = str(uuid.uuid4())
        generator_name = data.get("generator", self.generator_name)

        conn.execute(
            "INSERT INTO cells (id, run_id, generator_name, sequence_num, "
            "version_name, version_summary, source_type) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (cell_id, self.run_id, generator_name, seq,
             cell_name, cell_summary, "generator"),
        )

        for filepath, blob_hash in files.items():
            cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
            size = 0
            if os.path.exists(cas_path):
                try:
                    size = os.path.getsize(cas_path)
                except OSError:
                    pass
            conn.execute(
                "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                (blob_hash, size),
            )
            conn.execute(
                "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                "VALUES (?, ?, ?)",
                (cell_id, filepath, blob_hash),
            )

        commit_payload = json.dumps({
            "cell_id": cell_id,
            "name": cell_name,
            "summary": cell_summary,
            "sequence_num": seq,
            "file_count": len(files),
        })
        cur = conn.execute(
            "INSERT INTO run_events (run_id, event_type, payload) VALUES (?, 'commit', ?)",
            (self.run_id, commit_payload),
        )
        commit_event_id = cur.lastrowid
        commit_event_created_at = conn.execute(
            "SELECT created_at FROM run_events WHERE id=?",
            (commit_event_id,),
        ).fetchone()[0]

        conn.commit()
        conn.close()
        self._last_cell_id = cell_id

        # Route this commit event through the channel SSE alongside the
        # microbatch-written rows so the frontend has a single source of
        # truth regardless of which code path persisted the event.
        self._broadcast_run_events([{
            "id": commit_event_id,
            "event_type": "commit",
            "payload": commit_payload,
            "created_at": commit_event_created_at,
        }])

        # Place the cell in the side stack
        try:
            self._apply_side_cell_to_state(cell_id, files, cell_name, cell_summary)
        except Exception:
            import traceback
            self.log_buffer.append({
                "type": "stderr",
                "payload": "[side_cell placement] " + traceback.format_exc(),
            })

    def _apply_side_cell_to_state(
        self,
        cell_id: str,
        files: dict[str, str],
        cell_name: str,
        cell_summary: str,
    ):
        """Place a new side cell into the in-memory channel state.

        All side cells land in the same stack as the placeholder (primary
        running) cell, inserted directly under it so the primary stays on
        top and each newest side cell sits closest to it.
        """
        from cell_placement import find_stack_containing_cell
        from models import Cell as CellModel
        from state import persist_state

        ch = self._find_channel()
        if ch is None:
            return

        vfiles = self._build_virtual_files(files)
        manifest_summary_artifact = self._manifest_summary_artifact()

        target, insert_idx = self._resolve_under_primary(ch)
        if target is None:
            return

        new_cell = CellModel(
            id=cell_id,
            name=cell_name,
            summary=cell_summary,
            files=vfiles,
            summary_artifact=manifest_summary_artifact,
            run_id=self.run_id,
            channel=self.channel,
        )
        target.cells.insert(insert_idx, new_cell)
        self.side_stack_id = str(target.id)

        persist_state()

    def _resolve_under_primary(self, ch):
        """Return (stack, insert_index) for placing a new cell directly under
        the placeholder (primary running) cell in its stack.

        Falls back to (None, 0) if no placeholder stack can be found — the
        caller should bail out in that case.
        """
        from cell_placement import find_stack_containing_cell

        if not self.placeholder_cell_id:
            return None, 0
        stack = find_stack_containing_cell(ch, self.placeholder_cell_id)
        if stack is None:
            return None, 0
        for i, c in enumerate(stack.cells):
            if str(c.id) == str(self.placeholder_cell_id):
                return stack, i + 1
        return stack, len(stack.cells)

    def _ensure_genesis_row(self, cell_id: str) -> None:
        """Ensure a cells row exists for the given id.

        Placeholder cells are created in-memory by the frontend but have
        no DB row. Before linking cell_edges against a placeholder, we
        need at least a stub row so the version chain is walkable.
        """
        conn = get_db_connection(self.channel)
        existing = conn.execute(
            "SELECT 1 FROM cells WHERE id=? LIMIT 1", (cell_id,)
        ).fetchone()
        if not existing:
            conn.execute(
                "INSERT INTO cells (id, run_id, generator_name, sequence_num, "
                "version_name, version_summary, source_type) "
                "VALUES (?, ?, ?, 0, '', '', 'genesis')",
                (cell_id, self.run_id, self.generator_name),
            )
            conn.commit()
        conn.close()

    def _find_version_tip(self, start_cell_id: str) -> str:
        """Walk cell_edges forward from start_cell_id via
        parent_key='previous_version' until no child exists. Returns the tip.
        """
        conn = get_db_connection(self.channel)
        try:
            current = start_cell_id
            # Bounded walk to defend against accidental cycles — version
            # lists in practice are short (tens of turns).
            for _ in range(10_000):
                row = conn.execute(
                    "SELECT child_cell_id FROM cell_edges "
                    "WHERE parent_cell_id=? AND parent_key='previous_version' "
                    "LIMIT 1",
                    (current,),
                ).fetchone()
                if not row:
                    break
                current = row[0]
            return current
        finally:
            conn.close()

    def _read_version_metadata(self, cell_id: str) -> tuple[str | None, str | None]:
        """Return (name, summary) for a cell from the cell row. O(1)."""
        conn = get_db_connection(self.channel)
        try:
            row = conn.execute(
                "SELECT version_name, version_summary FROM cells WHERE id=?",
                (cell_id,),
            ).fetchone()
            if row:
                return row["version_name"], row["version_summary"]
            return None, None
        finally:
            conn.close()

    def _read_cell_file_map(self, cell_id: str) -> dict[str, str]:
        """Return {filepath: blob_hash} for every file stored against a cell."""
        conn = get_db_connection(self.channel)
        try:
            rows = conn.execute(
                "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?",
                (cell_id,),
            ).fetchall()
            return {r["filepath"]: r["blob_hash"] for r in rows}
        finally:
            conn.close()

    def _hash_and_store_file(self, abs_path: str) -> str | None:
        """Hash a file and store it in the CAS. Returns the blob hash."""
        return hash_and_store_file(abs_path)

    def _hash_and_store_bytes(self, raw: bytes) -> str | None:
        """Hash raw bytes and store them in the CAS. Returns the blob hash."""
        return hash_and_store_bytes(raw)

    def _manifest_summary_artifact(self) -> str | None:
        """Read summary_artifact from this generator's manifest.gen_yaml.

        Used so committed cells inherit the manifest's declared portal/summary
        file. Returns None if the manifest is missing or doesn't declare one.
        """
        manifest_path = os.path.join(self.app_dir, "manifest.gen_yaml")
        if not os.path.isfile(manifest_path):
            return None
        try:
            import yaml
            with open(manifest_path, "r") as f:
                manifest = yaml.safe_load(f)
            return manifest.get("summary_artifact") if isinstance(manifest, dict) else None
        except Exception:
            return None

    def _build_virtual_files(self, files: dict[str, str]) -> list:
        """Read each blob from the CAS and build VirtualFile objects for the
        in-memory channel state. Binary files end up with replacement-character
        garbage in `content`, which `strip_large_content` will then drop on
        broadcast based on size."""
        from models import VirtualFile

        lang_map = {
            ".py": "python", ".js": "javascript", ".ts": "typescript",
            ".tsx": "typescript", ".jsx": "javascript", ".json": "json",
            ".md": "markdown", ".yaml": "yaml", ".yml": "yaml",
            ".html": "html", ".css": "css", ".sh": "shell",
            ".gen_yaml": "yaml", ".rend_yaml": "yaml", ".set_yaml": "yaml",
            ".website": "plaintext",
        }

        vfiles = []
        for filepath, blob_hash in files.items():
            cas_path = os.path.join(
                ".collimate", "objects", blob_hash[:2], blob_hash[2:]
            )
            if not os.path.exists(cas_path):
                continue
            try:
                with open(cas_path, "r", encoding="utf-8", errors="replace") as fh:
                    content = fh.read()
            except Exception:
                content = ""
            ext = os.path.splitext(filepath)[1]
            vfiles.append(VirtualFile(
                name=filepath,
                content=content,
                language=lang_map.get(ext, "plaintext"),
            ))
        return vfiles

    def _find_channel(self):
        """Find this run's in-memory Channel by db-name slug."""
        from state import state, channel_db_name
        for c in state.channels:
            if channel_db_name(c) == self.channel:
                return c
        return None

    def _apply_commit_to_state(
        self,
        cell_id: str,
        files: dict[str, str],
        cell_name: str,
        cell_summary: str,
        seq: int,
    ):
        """Mutate the in-memory channel state to reflect a freshly-recorded
        DAG cell. The first commit populates the placeholder in place;
        subsequent commits stack under the placeholder in the same stack.
        Calls persist_state() so the SSE state_update broadcast carries the
        new layout to the frontend.
        """
        from cell_placement import find_stack_containing_cell
        from models import Cell as CellModel
        from state import persist_state

        ch = self._find_channel()
        if ch is None:
            return

        vfiles = self._build_virtual_files(files)
        manifest_summary_artifact = self._manifest_summary_artifact()

        if seq == 1 and self.placeholder_cell_id:
            # First commit reuses the placeholder cell that create_placeholder
            # already inserted into a fresh stack right of the source. We
            # populate it in place rather than creating a new cell.
            placeholder_stack = find_stack_containing_cell(
                ch, self.placeholder_cell_id
            )
            if placeholder_stack is None:
                return
            for c in placeholder_stack.cells:
                if str(c.id) == self.placeholder_cell_id:
                    c.name = cell_name or c.name
                    c.summary = cell_summary or c.summary
                    c.files = vfiles
                    if manifest_summary_artifact:
                        c.summary_artifact = manifest_summary_artifact
                    c.run_id = self.run_id
                    c.channel = self.channel
                    # Bump updated_at so the frontend's applyServerState
                    # overwrites its cell cache with the new files. Without
                    # this the client-side timestamp (set by handleUpdateMessages)
                    # is newer and the state_update is silently ignored.
                    c.updated_at = datetime.now()
                    break
            self.current_target_stack_id = str(placeholder_stack.id)
        else:
            # Subsequent commits land in the same stack as the placeholder,
            # inserted directly under it so the primary running cell stays
            # on top and the newest commit sits closest to it.
            target, insert_idx = self._resolve_under_primary(ch)
            if target is None:
                return
            new_cell = CellModel(
                id=cell_id,
                name=cell_name,
                summary=cell_summary,
                files=vfiles,
                summary_artifact=manifest_summary_artifact,
                run_id=self.run_id,
                channel=self.channel,
            )
            target.cells.insert(insert_idx, new_cell)
            self.current_target_stack_id = str(target.id)

        persist_state()

    def _apply_update_to_state(
        self,
        new_cell_id: str,
        files: dict[str, str],
        cell_name: str,
        cell_summary: str,
    ):
        """Mutate the in-memory visible cell in place with new files, name
        and summary. Does NOT touch the cell id — the canvas must not
        flicker — and does NOT invoke the placement rule, because in-place
        updates don't create new visible cells.

        ``new_cell_id`` is the id of the freshly-minted internal-version
        row in the cells table. It is not the visible cell id. We only use
        it to seed the internal VirtualFile cache path lookups; the visible
        cell id stays stable across turns.
        """
        from cell_placement import find_stack_containing_cell
        from state import persist_state

        ch = self._find_channel()
        if ch is None:
            return

        target_cell_id = self.placeholder_cell_id
        if not target_cell_id:
            print("[_apply_update_to_state] BAIL: no placeholder_cell_id")
            return

        target_stack = find_stack_containing_cell(ch, target_cell_id)
        if target_stack is None:
            return

        vfiles = self._build_virtual_files(files)
        manifest_summary_artifact = self._manifest_summary_artifact()

        for c in target_stack.cells:
            if str(c.id) == target_cell_id:
                if cell_name is not None:
                    c.name = cell_name
                if cell_summary is not None:
                    c.summary = cell_summary
                c.files = vfiles
                if manifest_summary_artifact:
                    c.summary_artifact = manifest_summary_artifact
                c.run_id = self.run_id
                c.channel = self.channel
                # Bump updated_at so the frontend's applyServerState
                # overwrites its cell cache with the new files. Without
                # this the client-side timestamp (set by handleUpdateMessages)
                # is newer and the state_update is silently ignored.
                c.updated_at = datetime.now()
                break

        # CRITICAL: do NOT change c.id. The visible cell id stays stable.
        # Do NOT call reserve_landing_stack. The placement rule is
        # irrelevant to in-place updates.

        persist_state()

    def _record_dag_cell(
        self,
        data: dict,
        files: dict[str, str],
        cell_name: str,
        cell_summary: str,
        parents: dict,
        in_place: bool = False,
        source_type: str = "generator",
    ):
        """Write a new DAG cell + blob records + cell_files edges into the channel DB,
        then mutate the in-memory channel state via the placement rule and broadcast.
        """
        import time as _time

        for attempt in range(3):
            try:
                self._record_dag_cell_inner(
                    data, files, cell_name, cell_summary,
                    parents, in_place, source_type,
                )
                return
            except Exception:
                if attempt < 2:
                    _time.sleep(0.5)
                else:
                    raise

    def _record_dag_cell_inner(
        self,
        data: dict,
        files: dict[str, str],
        cell_name: str,
        cell_summary: str,
        parents: dict,
        in_place: bool = False,
        source_type: str = "generator",
    ):
        conn = get_db_connection(self.channel)

        row = conn.execute(
            "SELECT COALESCE(MAX(sequence_num), 0) FROM cells WHERE run_id=?",
            (self.run_id,),
        ).fetchone()
        seq = row[0] + 1

        # Use placeholder_cell_id for the first commit so the frontend can
        # show an empty cell immediately when a run starts. Skipped for
        # in-place updates — those runs target an existing visible cell
        # that was not created via a placeholder.
        if not in_place and seq == 1 and self.placeholder_cell_id:
            cell_id = self.placeholder_cell_id
        else:
            cell_id = str(uuid.uuid4())
        generator_name = data.get("generator", self.generator_name)
        generator_cell_id = data.get("generator_cell_id")

        conn.execute(
            "INSERT INTO cells (id, run_id, generator_name, generator_cell_id, sequence_num, "
            "version_name, version_summary, source_type) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (cell_id, self.run_id, generator_name, generator_cell_id, seq,
             cell_name, cell_summary, source_type),
        )

        for parent_key, parent_cell_id in parents.items():
            conn.execute(
                "INSERT OR IGNORE INTO cell_edges "
                "(parent_cell_id, child_cell_id, parent_key) VALUES (?, ?, ?)",
                (parent_cell_id, cell_id, parent_key),
            )

        for filepath, blob_hash in files.items():
            cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
            size = 0
            if os.path.exists(cas_path):
                try:
                    size = os.path.getsize(cas_path)
                except OSError:
                    pass

            conn.execute(
                "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                (blob_hash, size),
            )
            conn.execute(
                "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                "VALUES (?, ?, ?)",
                (cell_id, filepath, blob_hash),
            )

        commit_payload = json.dumps({
            "cell_id": cell_id,
            "name": cell_name,
            "summary": cell_summary,
            "sequence_num": seq,
            "file_count": len(files),
        })
        cur = conn.execute(
            "INSERT INTO run_events (run_id, event_type, payload) VALUES (?, 'commit', ?)",
            (self.run_id, commit_payload),
        )
        commit_event_id = cur.lastrowid
        commit_event_created_at = conn.execute(
            "SELECT created_at FROM run_events WHERE id=?",
            (commit_event_id,),
        ).fetchone()[0]

        conn.commit()
        conn.close()
        self._last_cell_id = cell_id

        self._broadcast_run_events([{
            "id": commit_event_id,
            "event_type": "commit",
            "payload": commit_payload,
            "created_at": commit_event_created_at,
        }])

        # Mutate in-memory channel state. For normal commits this runs
        # through the portal-recursion placement rule; for in-place updates
        # it mutates the visible target cell in place without creating a
        # new one on the canvas.
        try:
            if in_place:
                self._apply_update_to_state(
                    cell_id, files, cell_name, cell_summary
                )
            else:
                self._apply_commit_to_state(
                    cell_id, files, cell_name, cell_summary, seq
                )
        except Exception:
            import traceback
            err = traceback.format_exc()
            self.log_buffer.append({
                "type": "stderr",
                "payload": "[placement] " + err,
            })

    # ------------------------------------------------------------------
    # Run finalization
    # ------------------------------------------------------------------

    def _finalize_run_status(self):
        """Mark run as completed/failed based on process exit code.

        Only updates if the run is still 'running' — if the generator already
        sent an IPC 'finish' message, its status takes precedence over the
        process exit code.
        """
        conn = get_db_connection(self.channel)
        row = conn.execute("SELECT status FROM runs WHERE id=?", (self.run_id,)).fetchone()
        final_status: str | None = None
        if row and row["status"] == "running":
            final_status = "completed" if self.process.returncode == 0 else "failed"
            conn.execute("UPDATE runs SET status=? WHERE id=?", (final_status, self.run_id))
            conn.commit()
        elif row:
            final_status = row["status"]
        conn.close()

        if final_status:
            self._broadcast_run_status(final_status)

        # Write accumulated logs into the first cell's latest version
        self._commit_logs_to_first_cell()
        # Write accumulated settings history (initial + update_settings_N)
        self._commit_settings_to_first_cell()
        # Snapshot .colreserved/config/ (draft-authored pickoptions +
        # config files) as private cell artifacts. Parallels the logs
        # treatment — persisted with the cell, hidden from the editor,
        # SDK-only access via gen.config.*.
        self._commit_config_to_first_cell()

    def _commit_logs_to_first_cell(self):
        """Write the run log to .colreserved/logs.txt in the first cell's
        version tip, without creating a new version chain entry.

        This is a silent in-place update so the logs are persisted as a
        cell artifact but don't clutter the version scrubber.
        """
        if not self.placeholder_cell_id:
            return

        # Collect all log text from run_events
        conn = get_db_connection(self.channel)
        rows = conn.execute(
            "SELECT event_type, payload FROM run_events WHERE run_id=? ORDER BY id",
            (self.run_id,),
        ).fetchall()

        log_lines = []
        for row in rows:
            if row["event_type"] in ("stdout", "stderr"):
                log_lines.append(row["payload"] or "")

        if not log_lines:
            conn.close()
            return

        log_text = "".join(log_lines)

        # Hash and store the log blob
        blob_hash = hash_and_store_bytes(log_text.encode("utf-8"))
        if not blob_hash:
            conn.close()
            return

        # Find the version tip of the first cell
        tip_id = self._find_version_tip(self.placeholder_cell_id)

        # Ensure the blob row exists
        cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
        size = 0
        if os.path.exists(cas_path):
            try:
                size = os.path.getsize(cas_path)
            except OSError:
                pass
        conn.execute(
            "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
            (blob_hash, size),
        )

        # Upsert the logs file into the tip's cell_files (no new version row)
        conn.execute(
            "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
            "VALUES (?, ?, ?)",
            (tip_id, ".colreserved/logs.txt", blob_hash),
        )
        conn.commit()
        conn.close()

        # Update the in-memory cell so the frontend sees the logs file
        try:
            from models import VirtualFile
            from cell_placement import find_stack_containing_cell
            from state import persist_state

            ch = self._find_channel()
            if ch:
                stack = find_stack_containing_cell(ch, self.placeholder_cell_id)
                if stack:
                    for c in stack.cells:
                        if str(c.id) == self.placeholder_cell_id:
                            # Add or update logs.txt in the cell's files
                            existing = [f for f in (c.files or [])
                                        if f.name != ".colreserved/logs.txt"]
                            existing.append(VirtualFile(
                                name=".colreserved/logs.txt",
                                content=log_text,
                                language="plaintext",
                            ))
                            c.files = existing
                            # Bump updated_at so the frontend's applyServerState
                            # accepts the state_update instead of filtering it
                            # out as stale.
                            c.updated_at = datetime.now()
                            break
                    persist_state()
        except Exception:
            pass

    def _commit_settings_to_first_cell(self):
        """Write every settings file (initial + any update_settings_N)
        into .colreserved/ on the first cell's version tip, without
        creating a new version chain entry.

        Mirrors _commit_logs_to_first_cell — a silent in-place upsert so
        the settings trail is persisted as a cell artifact but does not
        clutter the version scrubber.
        """
        if not self.placeholder_cell_id or not self.settings_history:
            return

        tip_id = self._find_version_tip(self.placeholder_cell_id)

        # Hash + upsert each entry
        conn = get_db_connection(self.channel)
        written: list[tuple[str, str]] = []  # (filepath, content) for in-memory update
        try:
            for name_stem, ext, content in self.settings_history:
                blob_hash = hash_and_store_bytes(content.encode("utf-8"))
                if not blob_hash:
                    continue
                cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
                size = 0
                if os.path.exists(cas_path):
                    try:
                        size = os.path.getsize(cas_path)
                    except OSError:
                        pass
                conn.execute(
                    "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                    (blob_hash, size),
                )
                filepath = f".colreserved/{name_stem}{ext}"
                conn.execute(
                    "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                    "VALUES (?, ?, ?)",
                    (tip_id, filepath, blob_hash),
                )
                written.append((filepath, content))
            conn.commit()
        finally:
            conn.close()

        # Update the in-memory cell so the frontend sees the settings files
        try:
            from models import VirtualFile
            from cell_placement import find_stack_containing_cell
            from state import persist_state

            ch = self._find_channel()
            if ch is None:
                return
            stack = find_stack_containing_cell(ch, self.placeholder_cell_id)
            if stack is None:
                return
            for c in stack.cells:
                if str(c.id) == self.placeholder_cell_id:
                    # Remove any existing settings entries we're about to re-add
                    new_paths = {fp for fp, _ in written}
                    existing = [f for f in (c.files or []) if f.name not in new_paths]
                    for filepath, content in written:
                        ext = os.path.splitext(filepath)[1]
                        lang = {
                            ".set_yaml": "yaml",
                            ".yaml": "yaml",
                            ".yml": "yaml",
                            ".md": "markdown",
                            ".json": "json",
                        }.get(ext, "plaintext")
                        existing.append(VirtualFile(
                            name=filepath, content=content, language=lang,
                        ))
                    c.files = existing
                    # Bump updated_at so the frontend accepts this
                    # state_update (applyServerState filters by timestamp).
                    c.updated_at = datetime.now()
                    break
            persist_state()
        except Exception:
            pass

    def _commit_config_to_first_cell(self):
        """Snapshot the workspace's ``.colreserved/config/`` tree into
        the first cell's version tip as private cell artifacts.

        Same shape as ``_commit_logs_to_first_cell`` / settings: upsert
        into cell_files at the tip with no new version row. The
        generator reads these at run-time via the SDK's
        ``gen.config.*`` API (which resolves paths under
        ``.colreserved/config/files/``); persisting them here makes the
        config travel with the cell for history / restore / export.
        """
        if not self.placeholder_cell_id:
            return

        cfg_root = os.path.join(self.workspace_dir, ".colreserved", "config")
        if not os.path.isdir(cfg_root):
            return

        # Walk the config tree and collect (rel_path_under_.colreserved, content)
        collected: list[tuple[str, str]] = []
        for dirpath, _, filenames in os.walk(cfg_root):
            for fname in filenames:
                abs_path = os.path.join(dirpath, fname)
                rel = os.path.relpath(abs_path, self.workspace_dir).replace("\\", "/")
                try:
                    with open(abs_path, "r", encoding="utf-8", errors="replace") as fh:
                        content = fh.read()
                except Exception:
                    continue
                collected.append((rel, content))

        if not collected:
            return

        tip_id = self._find_version_tip(self.placeholder_cell_id)

        conn = get_db_connection(self.channel)
        written: list[tuple[str, str]] = []
        try:
            for filepath, content in collected:
                blob_hash = hash_and_store_bytes(content.encode("utf-8"))
                if not blob_hash:
                    continue
                cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
                size = os.path.getsize(cas_path) if os.path.exists(cas_path) else 0
                conn.execute(
                    "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                    (blob_hash, size),
                )
                conn.execute(
                    "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                    "VALUES (?, ?, ?)",
                    (tip_id, filepath, blob_hash),
                )
                written.append((filepath, content))
            conn.commit()
        finally:
            conn.close()

        # Mirror onto the in-memory cell so the frontend's state stream
        # sees the files. The editor already hides ``.colreserved/*``
        # from its tabs, so these stay private to the SDK.
        try:
            from models import VirtualFile
            from cell_placement import find_stack_containing_cell
            from state import persist_state

            ch = self._find_channel()
            if ch is None:
                return
            stack = find_stack_containing_cell(ch, self.placeholder_cell_id)
            if stack is None:
                return
            lang_map = {
                ".json": "json", ".yaml": "yaml", ".yml": "yaml",
                ".md": "markdown", ".set_yaml": "yaml",
            }
            for c in stack.cells:
                if str(c.id) == self.placeholder_cell_id:
                    new_paths = {fp for fp, _ in written}
                    existing = [f for f in (c.files or []) if f.name not in new_paths]
                    for filepath, content in written:
                        ext = os.path.splitext(filepath)[1]
                        existing.append(VirtualFile(
                            name=filepath,
                            content=content,
                            language=lang_map.get(ext, "plaintext"),
                        ))
                    c.files = existing
                    c.updated_at = datetime.now()
                    break
            persist_state()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Microbatch SQLite Writer
    # ------------------------------------------------------------------

    async def _microbatch_writer(self):
        """Writes logs to SQLite in batches every 500ms to prevent DB locks."""
        while self.process.returncode is None:
            await asyncio.sleep(0.5)
            await asyncio.to_thread(self._flush_log_buffer)

        # Final flush after process exits
        await asyncio.sleep(0.1)
        await asyncio.to_thread(self._flush_log_buffer)

    def _flush_log_buffer(self):
        if not self.log_buffer:
            return
        batch = []
        while True:
            try:
                batch.append(self.log_buffer.popleft())
            except IndexError:
                break
        if not batch:
            return
        import time as _time
        for attempt in range(3):
            try:
                conn = get_db_connection(self.channel)
                conn.executemany(
                    "INSERT INTO run_events (run_id, event_type, payload) VALUES (?, ?, ?)",
                    [(self.run_id, item["type"], item["payload"]) for item in batch],
                )
                conn.commit()
                # Read back the ids + created_at we just wrote so we can
                # broadcast each event through the per-channel SSE stream
                # (see _broadcast_run_events below — routed through the
                # channel's single SSE to avoid per-run EventSource cap).
                rows = conn.execute(
                    "SELECT id, event_type, payload, created_at "
                    "FROM run_events WHERE run_id=? ORDER BY id DESC LIMIT ?",
                    (self.run_id, len(batch)),
                ).fetchall()
                conn.close()
                self._broadcast_run_events(list(reversed(rows)))
                return
            except Exception:
                if attempt < 2:
                    _time.sleep(0.3)
                # Last attempt failed — put items back so the next flush
                # picks them up rather than losing log lines.
                else:
                    self.log_buffer.extendleft(reversed(batch))

    def _broadcast_run_status(self, status: str) -> None:
        """Announce a run's terminal status on the channel SSE.

        Emitted in two spots: the explicit ``finish`` IPC handler (clean
        shutdown initiated by the generator) and ``_finalize_run_status``
        (process exit without a finish message). The frontend uses this
        as the signal to close its in-memory run state and render the
        final status — a replacement for the old per-run SSE's synthetic
        ``stream_end`` event.
        """
        from events import broadcast
        broadcast(self.channel, {
            "type": "run_status",
            "run_id": self.run_id,
            "status": status,
        })

    def _broadcast_run_events(self, rows) -> None:
        """Push freshly-persisted run_events rows through the channel SSE.

        Funnels every run's event stream through the single per-channel
        EventSource the frontend already maintains, so opening many chat
        cells doesn't exhaust the browser's per-host HTTP/1.1 connection
        cap (~6) with a persistent EventSource per run.
        """
        from events import broadcast
        for row in rows:
            broadcast(self.channel, {
                "type": "run_event",
                "run_id": self.run_id,
                "event": {
                    "id": row["id"],
                    "type": row["event_type"],
                    "payload": row["payload"],
                    "created_at": row["created_at"],
                },
            })

    # ------------------------------------------------------------------
    # WASM in-process dispatch (pyodide playground)
    # ------------------------------------------------------------------

    def _load_manifest_for_runtime(self) -> dict:
        """Load the generator's manifest.gen_yaml without running the full
        _load_params_from_manifest pipeline. Used to check the `runtime` field
        before deciding how to dispatch."""
        import yaml
        mp = os.path.join(self.app_dir, "manifest.gen_yaml")
        if not os.path.isfile(mp):
            return {}
        try:
            with open(mp, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        except (yaml.YAMLError, OSError):
            return {}

    async def _run_wasm(self, manifest: dict) -> None:
        """Drive a wasm-runtime generator in-process.

        Unlike the native path, there's no subprocess, no TCP IPC, and no
        streaming. We:
          1. Hydrate the WasmContext (config files, messages, params).
          2. Import the generator module and call its ``run(ctx)`` coroutine.
          3. Translate the returned WasmResult into an ``update_cell_initial``
             call so the placeholder cell is populated identically to a
             native run's first commit.
          4. Flip the run row to completed (or failed on exception).
        """
        import importlib.util
        import sys as _sys
        import traceback

        from collimate.wasm_sdk import Message, WasmContext, WasmResult

        try:
            # ── 1. Hydrate the context ──
            config_files: dict[str, str] = {}
            config_dir = os.path.join(self.workspace_dir, ".colreserved", "config", "files")
            if os.path.isdir(config_dir):
                for name in sorted(os.listdir(config_dir)):
                    p = os.path.join(config_dir, name)
                    if os.path.isfile(p):
                        try:
                            with open(p, "r", encoding="utf-8") as f:
                                config_files[name] = f.read()
                        except OSError:
                            pass

            messages: list[Message] = []
            msgs_path = os.path.join(
                self.workspace_dir, ".colreserved", ".collimate_messages.json"
            )
            if os.path.isfile(msgs_path):
                try:
                    with open(msgs_path, "r", encoding="utf-8") as f:
                        raw = json.load(f)
                    if isinstance(raw, list):
                        messages = [
                            Message(
                                role=m.get("role", "user"),
                                content=m.get("content", ""),
                                timestamp=m.get("timestamp", ""),
                            )
                            for m in raw if isinstance(m, dict)
                        ]
                except (json.JSONDecodeError, OSError):
                    pass

            merged_params = self._load_params_from_manifest()
            merged_params.update(self.params)

            ctx = WasmContext(
                workspace=self.workspace_dir,
                params=merged_params,
                channel=self.channel,
                run_id=self.run_id,
                config_files=config_files,
                messages=messages,
                placeholder_cell_id=self.placeholder_cell_id,
                _host=self,  # satisfies wasm_sdk.WasmHost protocol
            )

            # ── 2. Load the generator module ──
            script_path = os.path.join(self.app_dir, self.entrypoint)
            if not os.path.isfile(script_path):
                raise FileNotFoundError(
                    f"Wasm generator entrypoint not found: {script_path}"
                )
            mod_name = f"_collimate_wasm_gen_{uuid.uuid4().hex}"
            spec = importlib.util.spec_from_file_location(mod_name, script_path)
            if spec is None or spec.loader is None:
                raise RuntimeError(f"Cannot build module spec for {script_path}")
            module = importlib.util.module_from_spec(spec)
            _sys.modules[mod_name] = module
            try:
                spec.loader.exec_module(module)
                if not hasattr(module, "run"):
                    raise RuntimeError(
                        f"Wasm generator {self.generator_name!r} must export "
                        f"`async def run(ctx)`; found no `run` attribute."
                    )

                # ── 3. Invoke run(ctx) ──
                run_fn = module.run
                if asyncio.iscoroutinefunction(run_fn):
                    result = await run_fn(ctx)
                else:
                    # Allow plain sync run(ctx); wrap for uniformity
                    result = await asyncio.to_thread(run_fn, ctx)

            finally:
                _sys.modules.pop(mod_name, None)

            if not isinstance(result, WasmResult):
                raise RuntimeError(
                    f"Wasm generator {self.generator_name!r} must return a "
                    f"WasmResult; got {type(result).__name__}."
                )

            # ── 4. Final commit — translate WasmResult into update_cell_initial.
            # When the generator already emitted partials, an empty
            # WasmResult is valid: we preserve the last emit values so
            # the visible cell keeps whatever state the generator left it in.
            artifacts = [
                {"type": "memory", "cell_path": path, "content": content, "encoding": "utf-8"}
                for path, content in result.files.items()
            ]
            if result.chat_messages:
                artifacts.append({
                    "type": "memory",
                    "cell_path": ".colreserved/.collimate_messages.json",
                    "content": json.dumps(
                        [m.to_dict() for m in result.chat_messages], indent=2
                    ),
                    "encoding": "utf-8",
                })
            cell_name = (
                result.cell_name
                or self._last_emit_cell_name
                or self.generator_name
                or "Output"
            )
            cell_summary = (
                result.summary
                if result.summary
                else (self._last_emit_summary or "")
            )
            data = {
                "artifacts": artifacts,
                "name": cell_name,
                "summary": cell_summary,
            }
            self._update_cell_initial(data)

            # ── 5. Mark the run completed ──
            conn = get_db_connection(self.channel)
            try:
                status = "stopped" if self._cancelled else "completed"
                conn.execute(
                    "UPDATE runs SET status=? WHERE id=?", (status, self.run_id)
                )
                conn.commit()
            finally:
                conn.close()

            self.log_buffer.append({
                "type": "stdout",
                "payload": f"[wasm_run] {status}: {cell_name}"
                           f"{' (after ' + str(self._emit_partial_called) + ' partial emits)' if self._emit_partial_called else ''}",
            })

        except Exception:
            # Record the failure — don't re-raise. The supervised wrapper
            # will complete the _cleanup_task so _reap_process can pop us
            # from active_managers cleanly.
            self.log_buffer.append({
                "type": "stderr",
                "payload": "[wasm_run] " + traceback.format_exc(),
            })
            conn = get_db_connection(self.channel)
            try:
                conn.execute(
                    "UPDATE runs SET status='failed' WHERE id=?", (self.run_id,)
                )
                conn.commit()
            finally:
                conn.close()

    async def _run_wasm_supervised(self, manifest: dict) -> None:
        """Wrapper for _run_wasm that always completes cleanly so the task
        (stored as _cleanup_task) can be awaited by _reap_process without
        leaking active_managers on generator exceptions."""
        try:
            await self._run_wasm(manifest)
        except Exception:
            # _run_wasm already logged + recorded the failure.
            pass

    # ---- WasmHost protocol (used by wasm generators via WasmContext) ----

    async def emit_partial(
        self,
        *,
        files: dict[str, str] | None = None,
        cell_name: str | None = None,
        summary: str | None = None,
        chat_messages: list | None = None,
    ) -> None:
        """Push a mid-run snapshot. Writes files via _update_cell_initial,
        refreshes the in-memory channel state, and yields so concurrent
        pollers can observe the new state."""
        self._emit_partial_called = True
        if cell_name is not None:
            self._last_emit_cell_name = cell_name
        if summary is not None:
            self._last_emit_summary = summary

        artifacts = [
            {"type": "memory", "cell_path": path, "content": content, "encoding": "utf-8"}
            for path, content in (files or {}).items()
        ]
        if chat_messages:
            artifacts.append({
                "type": "memory",
                "cell_path": ".colreserved/.collimate_messages.json",
                "content": json.dumps(
                    [m.to_dict() for m in chat_messages], indent=2
                ),
                "encoding": "utf-8",
            })

        data: dict = {"artifacts": artifacts}
        # Use last-known values if the caller didn't supply — keeps the UI
        # stable if a generator only wants to update one facet per emit.
        data["name"] = (
            cell_name
            if cell_name is not None
            else (self._last_emit_cell_name or self.generator_name or "Output")
        )
        data["summary"] = (
            summary
            if summary is not None
            else (self._last_emit_summary or "")
        )

        # Run the DB+state update synchronously but yield to the event
        # loop so concurrent /api/state pollers can see the new state.
        self._update_cell_initial(data)
        await asyncio.sleep(0)

    def is_cancelled(self) -> bool:
        """True once the user has POSTed to the interrupt endpoint."""
        return self._cancelled

    def push_log(self, line: str) -> None:
        """Append a line to the run's log buffer."""
        self.log_buffer.append({"type": "stdout", "payload": line})

    def poll_user_message(self):
        """Pop and return the next queued user message, or None.

        The ``POST /api/channels/{c}/cells/{id}/chat/push_message`` endpoint
        appends to ``_pending_user_messages``. Native generators consume it
        via the ``poll_user_message`` IPC op; wasm generators call
        ``ctx.poll_user_message()`` which routes here.

        Returns a ``collimate.wasm_sdk.Message`` so wasm callers can
        append directly to ``ctx.messages`` / their ``chat_messages``
        list without further conversion."""
        if not self._pending_user_messages:
            return None
        content = self._pending_user_messages.pop(0)
        from collimate.wasm_sdk import Message
        return Message(role="user", content=content)

    # ---- Universal run-state predicates (native + wasm) ----

    def is_running(self) -> bool:
        """True if this manager still has a live worker that could respond
        to queued operations (push_message, etc.).

        Covers both backends:
          * Native — ``process`` alive and hasn't exited.
          * Wasm   — ``_cleanup_task`` has been scheduled and hasn't finished.
        """
        if self._cleanup_task is not None and not self._cleanup_task.done():
            return True
        if self.process is not None and self.process.returncode is None:
            return True
        return False
