"""Artifact hashing + file-state helpers shared by the cell write path."""
# pyright: reportAttributeAccessIssue=false
# (mixin: attributes like log_buffer/workspace_dir live on the composed
# ProcessManager in manager.py, not on the mixin class itself)

import os

from cas import hash_and_store_file, hash_and_store_bytes
from reserved_paths import is_reserved_path


class ArtifactsMixin:
    def _hash_artifacts(self, data: dict) -> dict[str, str]:
        """Hash artifact list from IPC payload into {cell_path: blob_hash}.

        Shared by update_cell, create_side_cell, and update_cell_initial.
        """
        artifacts = data.get("artifacts", [])
        files: dict[str, str] = {}

        for art in artifacts:
            art_type = art.get("type", "workspace")
            cell_path = art.get("cell_path", "")

            if is_reserved_path(cell_path):
                continue

            if art_type == "workspace":
                local_path = art.get("local_path", cell_path)
                # The generator controls local_path over IPC; resolve it
                # and refuse anything that escapes the workspace so a
                # hostile payload can't pull host files into the CAS.
                base = os.path.realpath(self.workspace_dir)
                abs_path = os.path.realpath(os.path.join(base, local_path))
                if abs_path != base and not abs_path.startswith(base + os.sep):
                    continue
                if not os.path.isfile(abs_path):
                    continue
                blob_hash = self._hash_and_store_file(abs_path)
                if blob_hash:
                    files[cell_path] = blob_hash

            elif art_type == "memory":
                content = art.get("content", "")
                encoding = art.get("encoding", "utf-8")
                if encoding == "base64":
                    import base64
                    raw = base64.b64decode(content)
                else:
                    raw = content.encode("utf-8")
                blob_hash = self._hash_and_store_bytes(raw)
                if blob_hash:
                    files[cell_path] = blob_hash

        return files

    def _collect_inmemory_cell_files(self, cell_id: str) -> dict[str, str]:
        """Hash files from the in-memory cell that aren't in the DB yet.

        User edits via the Files tab (add file, edit content) update the
        in-memory Cell object but don't create DB rows until the next
        update_cell. This method captures those files so they survive
        the merge.
        """
        ch = self._find_channel()
        if ch is None:
            return {}

        from cell_placement import find_stack_containing_cell
        stack = find_stack_containing_cell(ch, cell_id)
        if stack is None:
            return {}

        result: dict[str, str] = {}
        for c in stack.cells:
            if str(c.id) == cell_id:
                for vf in c.files or []:
                    path = (vf.name or "").replace("\\", "/").lstrip("/")
                    # Skip .colreserved — managed by SDK, not user files.
                    # The chat transcript (.chatlog) and live pointer
                    # (.chatlive) are ordinary visible files, so they flow
                    # through here like any other artifact.
                    if is_reserved_path(path):
                        continue
                    content = vf.content or ""
                    blob_hash = self._hash_and_store_bytes(content.encode("utf-8"))
                    if blob_hash:
                        result[path] = blob_hash
                break
        return result

    def _hash_and_store_file(self, abs_path: str) -> str | None:
        """Hash a file and store it in the CAS. Returns the blob hash."""
        return hash_and_store_file(abs_path)

    def _hash_and_store_bytes(self, raw: bytes) -> str | None:
        """Hash raw bytes and store them in the CAS. Returns the blob hash."""
        return hash_and_store_bytes(raw)

    def _manifest_pinned(self) -> str | None:
        """Read pinned from this generator's manifest.gen_yaml.

        Used so committed cells inherit the manifest's declared portal/summary
        file. Returns None if the manifest is missing or doesn't declare one.
        """
        manifest_path = os.path.join(self.app_dir, "manifest.gen_yaml")
        if not os.path.isfile(manifest_path):
            return None
        try:
            import yaml
            with open(manifest_path, "r") as f:
                manifest = yaml.safe_load(f)
            return manifest.get("pinned") if isinstance(manifest, dict) else None
        except Exception:
            return None

    def _build_virtual_files(self, files: dict[str, str]) -> list:
        """Read each blob from the CAS and build VirtualFile objects for the
        in-memory channel state. Text files decode to ``content``; binary
        files (non-UTF-8, e.g. images a generator produced) keep ``content``
        empty and carry a ``blob_hash`` referencing CAS, so they're broadcast
        as proper binary files rather than replacement-character garbage."""
        from models import VirtualFile

        lang_map = {
            ".py": "python", ".js": "javascript", ".ts": "typescript",
            ".tsx": "typescript", ".jsx": "javascript", ".json": "json",
            ".md": "markdown", ".yaml": "yaml", ".yml": "yaml",
            ".html": "html", ".css": "css", ".sh": "shell",
            ".gen_yaml": "yaml", ".rend_yaml": "yaml", ".set_yaml": "yaml",
            ".website": "plaintext",
        }

        vfiles = []
        for filepath, blob_hash in files.items():
            cas_path = os.path.join(
                ".collimate", "objects", blob_hash[:2], blob_hash[2:]
            )
            if not os.path.exists(cas_path):
                continue
            try:
                with open(cas_path, "rb") as fh:
                    raw = fh.read()
            except Exception:
                continue
            ext = os.path.splitext(filepath)[1]
            try:
                content = raw.decode("utf-8")
            except UnicodeDecodeError:
                vfiles.append(VirtualFile(
                    name=filepath, content="", language="binary", blob_hash=blob_hash,
                ))
                continue
            vfiles.append(VirtualFile(
                name=filepath,
                content=content,
                language=lang_map.get(ext, "plaintext"),
            ))
        return vfiles

    def _find_channel(self):
        """Find this run's in-memory Channel by db-name slug."""
        from state import state, channel_db_name
        for c in state.channels:
            if channel_db_name(c) == self.channel:
                return c
        return None
