"""Cross-cell read / write for the generator composition API.

A running generator may introspect, read, and edit OTHER source cells — but
only cells the user marked "expose to generators" (generator- AND
renderer-source cells; exposed-by-default). Every ``write_cell`` commits a
normal, undoable cell VERSION (``source_type='generator_edit'``) AND syncs the
cell's in-memory state, so the edit appears in the version scrubber and takes
effect on that cell's next run.

The IPC handlers in ``process_manager/ipc.py`` are thin adapters over these
functions. ``channel`` throughout is a channel db-name slug (``self.channel``).
"""
import uuid
from datetime import datetime

import yaml

from channel_config import cell_exposed, read_cell_exposure, set_cell_exposure
from database import get_db_connection
from reserved_paths import is_reserved_path

_MANIFEST = "manifest.gen_yaml"
_REND_MANIFEST = "manifest.rend_yaml"
_REQUIRED_MANIFEST_FIELDS = ("id", "name", "entrypoint", "summary", "type")
_REQUIRED_REND_FIELDS = ("id", "name", "entrypoint", "summary")


class CellNotExposed(Exception):
    """The target cell exists but is not exposed to generators."""


class CellNotFound(Exception):
    """No exposed source cell with that id in the channel."""


def _channel_obj(channel: str):
    """The in-memory Channel whose db-name matches ``channel``, or None."""
    from state import channel_db_name, state
    for ch in state.channels:
        if channel_db_name(ch) == channel:
            return ch
    return None


def _iter_source_cells(ch):
    """Yield ``(cell, stack)`` for every generator- or renderer-source cell."""
    for stk in [*ch.main_stacks, *ch.nav_stacks]:
        if stk.stack_type in ("generator", "renderer"):
            for c in stk.cells:
                yield c, stk


def _cell_generator_ids(cell) -> list:
    gids = []
    for f in cell.files:
        if not f.name.endswith(_MANIFEST):
            continue
        try:
            m = yaml.safe_load(f.content) or {}
        except Exception:
            continue
        if isinstance(m, dict) and m.get("id"):
            gids.append(m["id"])
    return gids


def list_exposed_cells(channel: str) -> list:
    """Every exposed source cell, as
    ``{cell_id, name, stack_type, generators: [id], files: [path]}``."""
    ch = _channel_obj(channel)
    if ch is None:
        return []
    exposure = read_cell_exposure(channel)
    out = []
    for cell, stk in _iter_source_cells(ch):
        cid = str(cell.id)
        if not cell_exposed(exposure, cid):
            continue
        out.append({
            "cell_id": cid,
            "name": cell.name or "",
            "stack_type": stk.stack_type,
            "generators": _cell_generator_ids(cell) if stk.stack_type == "generator" else [],
            "files": sorted(f.name for f in cell.files),
        })
    return out


def _find_exposed_cell(channel: str, cell_id: str):
    """Return ``(ch, cell, stack)`` for an EXPOSED source cell, else raise
    :class:`CellNotFound` / :class:`CellNotExposed`."""
    ch = _channel_obj(channel)
    if ch is None:
        raise CellNotFound(f"channel {channel!r} not found")
    for cell, stk in _iter_source_cells(ch):
        if str(cell.id) == cell_id:
            if not cell_exposed(read_cell_exposure(channel), cell_id):
                raise CellNotExposed(
                    f"cell {cell_id!r} is not exposed to generators"
                )
            return ch, cell, stk
    raise CellNotFound(f"exposed source cell {cell_id!r} not found")


def read_cell(channel: str, cell_id: str) -> dict:
    """The exposed cell's current files as ``{path: str | bytes}`` — the same
    files a run of that cell materializes from (its in-memory state)."""
    _ch, cell, _stk = _find_exposed_cell(channel, cell_id)
    return {f.name: (f.content if f.content is not None else "") for f in cell.files}


def _illegal_path(p: str) -> bool:
    return (
        not p
        or p.startswith("/")
        or ".." in p.split("/")
        or is_reserved_path(p)
    )


def _validate_manifest_text(path, content, merged_paths, *, manifest_name, required, kind) -> None:
    """Validate one generator/renderer manifest overlay entry. Raises
    ``ValueError`` (mapped to ``reason='lint'`` over IPC) on a bad manifest."""
    text = content.decode("utf-8") if isinstance(content, bytes) else content
    try:
        m = yaml.safe_load(text)
    except Exception as exc:
        raise ValueError(f"{path}: invalid YAML ({exc})")
    if not isinstance(m, dict):
        raise ValueError(f"{path}: manifest must be a mapping")
    missing = [k for k in required if not m.get(k)]
    if missing:
        raise ValueError(
            f"{path}: manifest missing required field(s): {', '.join(missing)}"
        )
    if kind == "generator" and (not isinstance(m.get("type"), list) or not m["type"]):
        raise ValueError(f"{path}: manifest 'type' must be a non-empty list")
    prefix = path[: -len(manifest_name)]
    entrypoint = prefix + str(m["entrypoint"])
    if entrypoint not in merged_paths:
        raise ValueError(
            f"{path}: entrypoint {m['entrypoint']!r} is not present in the cell"
        )


def _validate_overlay_manifests(overlay: dict, merged_paths: set) -> None:
    """Refuse a write whose ``manifest.gen_yaml`` / ``manifest.rend_yaml`` is
    unparseable, missing a required field, or names an ``entrypoint`` absent
    from the resulting cell. Raises ``ValueError``."""
    for path, content in overlay.items():
        if path.endswith(_MANIFEST):
            _validate_manifest_text(
                path, content, merged_paths,
                manifest_name=_MANIFEST, required=_REQUIRED_MANIFEST_FIELDS,
                kind="generator",
            )
        elif path.endswith(_REND_MANIFEST):
            _validate_manifest_text(
                path, content, merged_paths,
                manifest_name=_REND_MANIFEST, required=_REQUIRED_REND_FIELDS,
                kind="renderer",
            )


def write_cell(
    channel: str,
    cell_id: str,
    overlay: dict,
    deleted,
    *,
    summary,
    generator_name: str,
) -> str:
    """Commit a new version of an EXPOSED cell from a partial overlay, then sync
    its in-memory state so the edit applies on the cell's next run. Returns the
    new version id. Raises :class:`CellNotExposed` / :class:`CellNotFound` /
    ``ValueError`` (illegal path or bad manifest)."""
    from routes.runs.helpers import _write_version_from_overlay

    _ch, cell, _stk = _find_exposed_cell(channel, cell_id)
    overlay = dict(overlay or {})
    deleted = list(deleted or [])

    for p in list(overlay.keys()) + deleted:
        if _illegal_path(p):
            raise ValueError(f"illegal cell path: {p!r}")

    merged_paths = ({f.name for f in cell.files} - set(deleted)) | set(overlay.keys())
    _validate_overlay_manifests(overlay, merged_paths)

    changes = [(p, "set", c) for p, c in overlay.items()]
    changes += [(p, "delete", None) for p in deleted]
    if not changes:
        raise ValueError("write_cell: empty overlay (no files to set or delete)")

    current_files = [
        {"filepath": f.name, "content": f.content, "blob_hash": f.blob_hash}
        for f in cell.files
    ]

    conn = get_db_connection(channel)
    try:
        run_id = str(uuid.uuid4())
        conn.execute(
            "INSERT INTO runs (id, prompt, status) VALUES (?, ?, 'completed')",
            (run_id, f"generator edit: {generator_name}"),
        )
        version_id = _write_version_from_overlay(
            conn, cell_id, run_id, changes,
            version_name="Generator Edit",
            summary=summary or f"Edited by {generator_name}",
            source_type="generator_edit",
            generator_name=generator_name,
            current_files=current_files,
        )
        conn.commit()
    finally:
        conn.close()

    _sync_cell_state(channel, cell_id)
    return version_id


def create_source_cell(
    channel: str,
    stack_type: str,
    name: str,
    files: dict,
    *,
    summary=None,
    pinned=None,
) -> str:
    """Create a brand-new SOURCE cell in the channel's generator or renderer
    stack (``stack_type`` ∈ {"generator", "renderer"}), persist it as the
    cell's first version, place it in the matching ``nav_stacks`` stack, and
    **expose it to generators** so the creating run can immediately read/edit
    it. Returns the new cell id.

    Raises :class:`CellNotFound` (channel gone) / ``ValueError`` (bad
    ``stack_type``, illegal path, empty files, or a missing/invalid manifest of
    the required kind)."""
    if stack_type not in ("generator", "renderer"):
        raise ValueError(
            f"stack must be 'generator' or 'renderer', got {stack_type!r}"
        )
    ch = _channel_obj(channel)
    if ch is None:
        raise CellNotFound(f"channel {channel!r} not found")

    files = dict(files or {})
    if not files:
        raise ValueError("create_source_cell: no files provided")
    for p in files:
        if _illegal_path(p):
            raise ValueError(f"illegal cell path: {p!r}")

    merged_paths = set(files.keys())
    _validate_overlay_manifests(files, merged_paths)
    want = _MANIFEST if stack_type == "generator" else _REND_MANIFEST
    if not any(p.endswith(want) for p in files):
        raise ValueError(
            f"create_source_cell: a {want} is required for a {stack_type} cell"
        )

    from genesis import _store_bytes_blob

    cell_id = str(uuid.uuid4())
    run_id = str(uuid.uuid4())
    conn = get_db_connection(channel)
    try:
        conn.execute(
            "INSERT INTO runs (id, prompt, status) VALUES (?, ?, 'completed')",
            (run_id, f"create source cell: {name}"),
        )
        conn.execute(
            "INSERT INTO cells (id, run_id, generator_name, sequence_num, "
            "version_name, version_summary, source_type) "
            "VALUES (?, ?, 'generator', 0, ?, ?, 'generator_create')",
            (cell_id, run_id, name or "New Cell", summary or ""),
        )
        for path, content in files.items():
            b = content.encode("utf-8") if isinstance(content, str) else bytes(content)
            blob_hash = _store_bytes_blob(b)
            conn.execute(
                "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                (blob_hash, len(b)),
            )
            conn.execute(
                "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                "VALUES (?, ?, ?)",
                (cell_id, path, blob_hash),
            )
        conn.commit()
    finally:
        conn.close()

    _place_source_cell_in_state(channel, stack_type, cell_id, name, summary or "", files, pinned)
    set_cell_exposure(channel, cell_id, True)
    return cell_id


def _place_source_cell_in_state(
    channel: str, stack_type: str, cell_id: str, name: str,
    summary: str, files: dict, pinned,
) -> None:
    """Append the new source cell to the channel's matching nav stack
    (find-or-create the stack), then persist."""
    from genesis import _store_bytes_blob
    from models import Cell, Stack, VirtualFile
    from routes.cells import _language_for
    from state import channel_db_name, persist_state, state, state_lock

    vfiles = []
    for path, content in files.items():
        if isinstance(content, (bytes, bytearray)):
            b = bytes(content)
            vfiles.append(VirtualFile(
                name=path, content="", language="binary",
                blob_hash=_store_bytes_blob(b),
            ))
        else:
            vfiles.append(VirtualFile(
                name=path, content=content, language=_language_for(path),
            ))

    with state_lock:
        for ch in state.channels:
            if channel_db_name(ch) != channel:
                continue
            stack = next(
                (s for s in ch.nav_stacks if s.stack_type == stack_type), None
            )
            if stack is None:
                stack = Stack(name=f"{stack_type.capitalize()}s", stack_type=stack_type)
                ch.nav_stacks.append(stack)
            stack.cells.append(Cell(
                id=uuid.UUID(cell_id),
                name=name or "New Cell",
                summary=summary,
                files=vfiles,
                channel=channel,
                pinned=pinned,
            ))
            break
    persist_state()


def _sync_cell_state(channel: str, cell_id: str) -> None:
    """Rebuild the cell's in-memory files from its new version tip so the edit
    takes effect on the next run — mirrors ``checkpoint_cell``'s state sync."""
    from cell_placement import find_stack_containing_cell
    from models import VirtualFile
    from routes.cells import _language_for, _read_blob_text_or_ref
    from routes.runs import _find_version_tip
    from state import channel_db_name, persist_state, state, state_lock

    for ch in state.channels:
        if channel_db_name(ch) != channel:
            continue
        stack = find_stack_containing_cell(ch, cell_id)
        if not stack:
            return
        conn = get_db_connection(channel)
        try:
            tip_id = _find_version_tip(conn, cell_id)
            rows = conn.execute(
                "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?",
                (tip_id,),
            ).fetchall()
        finally:
            conn.close()
        vfiles = []
        for r in rows:
            content, bh = _read_blob_text_or_ref(r["blob_hash"])
            vfiles.append(VirtualFile(
                name=r["filepath"],
                content=content,
                language="binary" if bh else _language_for(r["filepath"]),
                blob_hash=bh,
            ))
        with state_lock:
            for c in stack.cells:
                if str(c.id) == cell_id:
                    c.files = vfiles
                    c.updated_at = datetime.now()
                    break
        persist_state()
        return
