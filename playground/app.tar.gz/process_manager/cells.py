"""Cell mutation — update_cell / update_cell_initial / create_side_cell
plus the DAG-write + in-memory-state placement helpers they share."""

import json
import os
import uuid
from datetime import datetime

from database import get_db_connection


class CellsMixin:
    # ------------------------------------------------------------------
    # Cell mutation: update_cell (version row) / update_cell_initial (overwrite)
    # ------------------------------------------------------------------

    def _update_cell(self, data: dict):
        """Mutate the run's first cell with a new internal-version row.

        Finds the version tip from self.placeholder_cell_id and passes
        parents={"previous_version": <tip>} plus in_place=True into
        _record_dag_cell so the cell is mutated on the canvas rather
        than appended as a new one.

        ``name`` and ``summary`` are both Optional — a None value means
        "keep the existing value".
        """
        target_id = self.placeholder_cell_id
        if not target_id:
            self.log_buffer.append({
                "type": "stderr",
                "payload": "[update_cell] refused: no target cell id set",
            })
            return

        files = self._hash_artifacts(data)
        req_name = data.get("name")
        req_summary = data.get("summary")

        tip_id = self._find_version_tip(target_id)

        # Ensure the genesis row exists in the DB. The placeholder cell
        # is created in-memory by the frontend, but _record_dag_cell
        # needs a valid parent to link cell_edges against.
        self._ensure_genesis_row(tip_id)

        prev_name, prev_summary = self._read_version_metadata(tip_id)
        cell_name = req_name if req_name is not None else (prev_name or "Output")
        cell_summary = (
            req_summary if req_summary is not None else (prev_summary or "")
        )

        merged_files = self._read_cell_file_map(tip_id)
        # If the tip has no files (empty placeholder, no prior initial call),
        # seed from input cells so inherited files aren't lost.
        if not merged_files and self.input_cell_ids:
            for input_id in self.input_cell_ids:
                input_tip = self._find_version_tip(input_id)
                merged_files.update(self._read_cell_file_map(input_tip))

        # Pick up files the user added/edited via the UI that aren't in the
        # DB tip yet (e.g. new files added in the Files tab during a session).
        merged_files.update(self._collect_inmemory_cell_files(target_id))

        pending = self._consume_chat_pending_files(target_id)
        chat_deleted = self._consume_chat_deleted_files(target_id)
        merged_files.update(files)
        merged_files.update(pending)

        # Remove files deleted by the daemon or explicitly by the generator
        for path in chat_deleted:
            merged_files.pop(path, None)
        for path in data.get("deleted_files", []):
            merged_files.pop(path, None)

        st = "chat" if self.generator_name in (
            "claude_code_chat", "anthropic_chat", "chat",
            "gemini_chat", "goose_chat",
        ) else "generator"
        self._record_dag_cell(
            data,
            merged_files,
            cell_name,
            cell_summary,
            {"previous_version": tip_id},
            in_place=True,
            source_type=st,
        )

    def _update_cell_initial(self, data: dict):
        """Overwrite the first cell's content without creating a version row.

        Used for the very first update (initial=True) that populates the
        auto-created placeholder with content. The placeholder only exists
        in-memory (no DB row yet), so we INSERT OR REPLACE the cells row
        and do NOT create cell_edges — the version scrubber never shows
        this transient state.
        """
        target_id = self.placeholder_cell_id
        if not target_id:
            self.log_buffer.append({
                "type": "stderr",
                "payload": "[update_cell_initial] refused: no target cell id set",
            })
            return

        files = self._hash_artifacts(data)
        req_name = data.get("name")
        req_summary = data.get("summary")
        req_summary_artifact = data.get("summary_artifact")

        # The placeholder may not have a cells row yet (it's created
        # in-memory by the frontend). Check if a tip exists; if not,
        # the target_id IS the tip (it's the genesis row we're about
        # to create).
        tip_id = self._find_version_tip(target_id)

        # Seed from input cells — the placeholder starts empty but the
        # workspace was hydrated from input cell files. Carry those forward
        # so the cell inherits its parent's files.
        merged_files: dict[str, str] = {}
        for input_id in self.input_cell_ids:
            input_tip = self._find_version_tip(input_id)
            merged_files.update(self._read_cell_file_map(input_tip))

        merged_files.update(self._read_cell_file_map(tip_id))
        merged_files.update(self._collect_inmemory_cell_files(target_id))
        pending = self._consume_chat_pending_files(target_id)
        chat_deleted = self._consume_chat_deleted_files(target_id)
        merged_files.update(files)
        merged_files.update(pending)

        # Remove files deleted by the daemon or explicitly by the generator
        for path in chat_deleted:
            merged_files.pop(path, None)
        for path in data.get("deleted_files", []):
            merged_files.pop(path, None)

        cell_name = req_name or "Output"
        cell_summary = req_summary or ""

        conn = get_db_connection(self.channel)

        # Compute the placeholder's sequence_num as MAX+1 within this
        # run. JIT flush may have already inserted a Human Edit cell
        # under the same run_id (seq=1 for a fresh run), so a hardcoded
        # 1 here would collide with the (run_id, sequence_num) UNIQUE
        # constraint and the ON CONFLICT(id) clause wouldn't catch it
        # — the conflict target differs. We only compute MAX+1 when
        # the placeholder has no existing row; on subsequent emits the
        # ON CONFLICT(id) UPDATE branch is the right path.
        existing = conn.execute(
            "SELECT sequence_num FROM cells WHERE id=?", (tip_id,),
        ).fetchone()
        if existing is None:
            row = conn.execute(
                "SELECT COALESCE(MAX(sequence_num), 0) FROM cells WHERE run_id=?",
                (self.run_id,),
            ).fetchone()
            seq = (row[0] or 0) + 1
        else:
            seq = existing["sequence_num"]

        # Upsert the cells row — the placeholder may not have one yet.
        conn.execute(
            "INSERT INTO cells (id, run_id, generator_name, sequence_num, "
            "version_name, version_summary, source_type) "
            "VALUES (?, ?, ?, ?, ?, ?, 'genesis') "
            "ON CONFLICT(id) DO UPDATE SET "
            "version_name=excluded.version_name, "
            "version_summary=excluded.version_summary",
            (tip_id, self.run_id, self.generator_name, seq,
             cell_name, cell_summary),
        )

        # Replace cell_files for this tip
        conn.execute("DELETE FROM cell_files WHERE cell_id=?", (tip_id,))
        for filepath, blob_hash in merged_files.items():
            cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
            size = 0
            if os.path.exists(cas_path):
                try:
                    size = os.path.getsize(cas_path)
                except OSError:
                    pass
            conn.execute(
                "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                (blob_hash, size),
            )
            conn.execute(
                "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                "VALUES (?, ?, ?)",
                (tip_id, filepath, blob_hash),
            )
        conn.commit()
        conn.close()
        self._last_cell_id = tip_id

        # Refresh in-memory state
        try:
            self._apply_update_to_state(
                tip_id, merged_files, cell_name, cell_summary,
                summary_artifact=req_summary_artifact,
            )
        except Exception:
            import traceback
            self.log_buffer.append({
                "type": "stderr",
                "payload": "[update_cell_initial placement] " + traceback.format_exc(),
            })

    # ------------------------------------------------------------------
    # Side cell creation (gen.create_cell)
    # ------------------------------------------------------------------

    def _create_side_cell(self, data: dict):
        """Create a new cell in a side stack.

        First call creates a new stack to the right of the first cell's
        stack; subsequent calls append to the same side stack.
        """
        files = self._hash_artifacts(data)
        cell_name = data.get("name", "Output")
        cell_summary = data.get("summary", "")
        # Optional per-cell override. Generators producing N siblings
        # along a single axis (seed-ideas → SeedIdea.md, evaluate-best
        # → Score.md, …) want each side cell's summary view to render
        # its own file rather than the manifest's primary-cell artifact.
        summary_artifact = data.get("summary_artifact")

        # Pull any chat pending files
        if self.placeholder_cell_id:
            files.update(self._consume_chat_pending_files(self.placeholder_cell_id))

        self._record_side_cell(data, files, cell_name, cell_summary, summary_artifact)

    def _record_side_cell(
        self,
        data: dict,
        files: dict[str, str],
        cell_name: str,
        cell_summary: str,
        summary_artifact: str | None,
    ):
        """Write a new side cell into the DB and place it in the side stack."""
        import time as _time
        for attempt in range(3):
            try:
                self._record_side_cell_inner(
                    data, files, cell_name, cell_summary, summary_artifact,
                )
                return
            except Exception:
                if attempt < 2:
                    _time.sleep(0.5)
                else:
                    raise

    def _record_side_cell_inner(
        self,
        data: dict,
        files: dict[str, str],
        cell_name: str,
        cell_summary: str,
        summary_artifact: str | None,
    ):
        conn = get_db_connection(self.channel)

        row = conn.execute(
            "SELECT COALESCE(MAX(sequence_num), 0) FROM cells WHERE run_id=?",
            (self.run_id,),
        ).fetchone()
        seq = row[0] + 1

        cell_id = str(uuid.uuid4())
        generator_name = data.get("generator", self.generator_name)

        conn.execute(
            "INSERT INTO cells (id, run_id, generator_name, sequence_num, "
            "version_name, version_summary, source_type) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (cell_id, self.run_id, generator_name, seq,
             cell_name, cell_summary, "generator"),
        )

        for filepath, blob_hash in files.items():
            cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
            size = 0
            if os.path.exists(cas_path):
                try:
                    size = os.path.getsize(cas_path)
                except OSError:
                    pass
            conn.execute(
                "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                (blob_hash, size),
            )
            conn.execute(
                "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                "VALUES (?, ?, ?)",
                (cell_id, filepath, blob_hash),
            )

        commit_payload = json.dumps({
            "cell_id": cell_id,
            "name": cell_name,
            "summary": cell_summary,
            "sequence_num": seq,
            "file_count": len(files),
        })
        cur = conn.execute(
            "INSERT INTO run_events (run_id, event_type, payload) VALUES (?, 'commit', ?)",
            (self.run_id, commit_payload),
        )
        commit_event_id = cur.lastrowid
        commit_event_created_at = conn.execute(
            "SELECT created_at FROM run_events WHERE id=?",
            (commit_event_id,),
        ).fetchone()[0]

        conn.commit()
        conn.close()
        self._last_cell_id = cell_id

        # Route this commit event through the channel SSE alongside the
        # microbatch-written rows so the frontend has a single source of
        # truth regardless of which code path persisted the event.
        self._broadcast_run_events([{
            "id": commit_event_id,
            "event_type": "commit",
            "payload": commit_payload,
            "created_at": commit_event_created_at,
        }])

        # Place the cell in the side stack
        try:
            self._apply_side_cell_to_state(
                cell_id, files, cell_name, cell_summary, summary_artifact,
            )
        except Exception:
            import traceback
            self.log_buffer.append({
                "type": "stderr",
                "payload": "[side_cell placement] " + traceback.format_exc(),
            })

    def _apply_side_cell_to_state(
        self,
        cell_id: str,
        files: dict[str, str],
        cell_name: str,
        cell_summary: str,
        summary_artifact: str | None,
    ):
        """Place a new side cell into the in-memory channel state.

        All side cells land in the same stack as the placeholder (primary
        running) cell, inserted directly under it so the primary stays on
        top and each newest side cell sits closest to it.
        """
        from models import Cell as CellModel
        from state import persist_state

        ch = self._find_channel()
        if ch is None:
            return

        vfiles = self._build_virtual_files(files)
        # Explicit per-cell override wins over the manifest fallback —
        # multi-output generators (seed-ideas, evaluate-best, …) point
        # the manifest's ``summary_artifact`` at the *primary* cell's
        # index file, but each side cell carries a different artifact
        # that should drive its own summary view.
        effective_summary_artifact = (
            summary_artifact
            if summary_artifact is not None
            else self._manifest_summary_artifact()
        )

        target, insert_idx = self._resolve_under_primary(ch)
        if target is None:
            return

        new_cell = CellModel(
            id=cell_id,
            name=cell_name,
            summary=cell_summary,
            files=vfiles,
            summary_artifact=effective_summary_artifact,
            run_id=self.run_id,
            channel=self.channel,
        )
        target.cells.insert(insert_idx, new_cell)
        self.side_stack_id = str(target.id)

        persist_state()

    def _resolve_under_primary(self, ch):
        """Return (stack, insert_index) for placing a new cell directly under
        the placeholder (primary running) cell in its stack.

        Falls back to (None, 0) if no placeholder stack can be found — the
        caller should bail out in that case.
        """
        from cell_placement import find_stack_containing_cell

        if not self.placeholder_cell_id:
            return None, 0
        stack = find_stack_containing_cell(ch, self.placeholder_cell_id)
        if stack is None:
            return None, 0
        for i, c in enumerate(stack.cells):
            if str(c.id) == str(self.placeholder_cell_id):
                return stack, i + 1
        return stack, len(stack.cells)

    def _ensure_genesis_row(self, cell_id: str) -> None:
        """Ensure a cells row exists for the given id.

        Placeholder cells are created in-memory by the frontend but have
        no DB row. Before linking cell_edges against a placeholder, we
        need at least a stub row so the version chain is walkable.
        """
        conn = get_db_connection(self.channel)
        existing = conn.execute(
            "SELECT 1 FROM cells WHERE id=? LIMIT 1", (cell_id,)
        ).fetchone()
        if not existing:
            conn.execute(
                "INSERT INTO cells (id, run_id, generator_name, sequence_num, "
                "version_name, version_summary, source_type) "
                "VALUES (?, ?, ?, 0, '', '', 'genesis')",
                (cell_id, self.run_id, self.generator_name),
            )
            conn.commit()
        conn.close()

    def _find_version_tip(self, start_cell_id: str) -> str:
        """Walk cell_edges forward from start_cell_id via
        parent_key='previous_version' until no child exists. Returns the tip.

        Tracks visited ids so a corrupt A→B→A cycle in the version
        chain breaks out with a warning rather than spinning until the
        old fixed 10k cap hit.

        Per-run cache: chat sessions call this function many times per
        turn (once per input per merge pass). The cache on self._tip_cache
        turns repeat lookups into dict reads. It is kept coherent by
        _record_dag_cell_inner, which re-points entries when a new
        'previous_version' edge is written.
        """
        cached = self._tip_cache.get(start_cell_id)
        if cached is not None:
            return cached

        conn = get_db_connection(self.channel)
        try:
            current = start_cell_id
            visited: set[str] = {current}
            while True:
                row = conn.execute(
                    "SELECT child_cell_id FROM cell_edges "
                    "WHERE parent_cell_id=? AND parent_key='previous_version' "
                    "LIMIT 1",
                    (current,),
                ).fetchone()
                if not row:
                    break
                nxt = row[0]
                if nxt in visited:
                    self.log_buffer.append({
                        "type": "stderr",
                        "payload": f"[version-walk] cycle detected at {nxt} — stopping at {current}",
                    })
                    break
                visited.add(nxt)
                current = nxt
            self._tip_cache[start_cell_id] = current
            return current
        finally:
            conn.close()

    def _read_version_metadata(self, cell_id: str) -> tuple[str | None, str | None]:
        """Return (name, summary) for a cell from the cell row. O(1)."""
        conn = get_db_connection(self.channel)
        try:
            row = conn.execute(
                "SELECT version_name, version_summary FROM cells WHERE id=?",
                (cell_id,),
            ).fetchone()
            if row:
                return row["version_name"], row["version_summary"]
            return None, None
        finally:
            conn.close()

    def _read_cell_file_map(self, cell_id: str) -> dict[str, str]:
        """Return {filepath: blob_hash} for every file stored against a cell."""
        conn = get_db_connection(self.channel)
        try:
            rows = conn.execute(
                "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?",
                (cell_id,),
            ).fetchall()
            return {r["filepath"]: r["blob_hash"] for r in rows}
        finally:
            conn.close()

    # ------------------------------------------------------------------
    # In-memory state application for DAG commits
    # ------------------------------------------------------------------

    def _apply_commit_to_state(
        self,
        cell_id: str,
        files: dict[str, str],
        cell_name: str,
        cell_summary: str,
        seq: int,
    ):
        """Mutate the in-memory channel state to reflect a freshly-recorded
        DAG cell. The first commit populates the placeholder in place;
        subsequent commits stack under the placeholder in the same stack.
        Calls persist_state() so the SSE state_update broadcast carries the
        new layout to the frontend.
        """
        from cell_placement import find_stack_containing_cell
        from models import Cell as CellModel
        from state import persist_state

        ch = self._find_channel()
        if ch is None:
            return

        vfiles = self._build_virtual_files(files)
        manifest_summary_artifact = self._manifest_summary_artifact()

        if seq == 1 and self.placeholder_cell_id:
            # First commit reuses the placeholder cell that create_placeholder
            # already inserted into a fresh stack right of the source. We
            # populate it in place rather than creating a new cell.
            placeholder_stack = find_stack_containing_cell(
                ch, self.placeholder_cell_id
            )
            if placeholder_stack is None:
                return
            for c in placeholder_stack.cells:
                if str(c.id) == self.placeholder_cell_id:
                    c.name = cell_name or c.name
                    c.summary = cell_summary or c.summary
                    c.files = vfiles
                    if manifest_summary_artifact:
                        c.summary_artifact = manifest_summary_artifact
                    c.run_id = self.run_id
                    c.channel = self.channel
                    # Bump updated_at so the frontend's applyServerState
                    # overwrites its cell cache with the new files. Without
                    # this the client-side timestamp (set by handleUpdateMessages)
                    # is newer and the state_update is silently ignored.
                    c.updated_at = datetime.now()
                    break
            self.current_target_stack_id = str(placeholder_stack.id)
        else:
            # Subsequent commits land in the same stack as the placeholder,
            # inserted directly under it so the primary running cell stays
            # on top and the newest commit sits closest to it.
            target, insert_idx = self._resolve_under_primary(ch)
            if target is None:
                return
            new_cell = CellModel(
                id=cell_id,
                name=cell_name,
                summary=cell_summary,
                files=vfiles,
                summary_artifact=manifest_summary_artifact,
                run_id=self.run_id,
                channel=self.channel,
            )
            target.cells.insert(insert_idx, new_cell)
            self.current_target_stack_id = str(target.id)

        persist_state()

    def _apply_update_to_state(
        self,
        new_cell_id: str,
        files: dict[str, str],
        cell_name: str,
        cell_summary: str,
        *,
        summary_artifact: str | None = None,
    ):
        """Mutate the in-memory visible cell in place with new files, name
        and summary. Does NOT touch the cell id — the canvas must not
        flicker — and does NOT invoke the placement rule, because in-place
        updates don't create new visible cells.

        ``new_cell_id`` is the id of the freshly-minted internal-version
        row in the cells table. It is not the visible cell id. We only use
        it to seed the internal VirtualFile cache path lookups; the visible
        cell id stays stable across turns.

        ``summary_artifact`` is the per-call override (from
        ``gen.update(summary_artifact=...)``). When ``None``, falls back to
        the manifest's ``summary_artifact`` so legacy native generators
        keep working unchanged.
        """
        from cell_placement import find_stack_containing_cell
        from state import persist_state

        ch = self._find_channel()
        if ch is None:
            return

        target_cell_id = self.placeholder_cell_id
        if not target_cell_id:
            print("[_apply_update_to_state] BAIL: no placeholder_cell_id")
            return

        target_stack = find_stack_containing_cell(ch, target_cell_id)
        if target_stack is None:
            return

        vfiles = self._build_virtual_files(files)
        effective_summary_artifact = (
            summary_artifact
            if summary_artifact is not None
            else self._manifest_summary_artifact()
        )

        for c in target_stack.cells:
            if str(c.id) == target_cell_id:
                if cell_name is not None:
                    c.name = cell_name
                if cell_summary is not None:
                    c.summary = cell_summary
                c.files = vfiles
                if effective_summary_artifact:
                    c.summary_artifact = effective_summary_artifact
                c.run_id = self.run_id
                c.channel = self.channel
                # Bump updated_at so the frontend's applyServerState
                # overwrites its cell cache with the new files. Without
                # this the client-side timestamp (set by handleUpdateMessages)
                # is newer and the state_update is silently ignored.
                c.updated_at = datetime.now()
                break

        # CRITICAL: do NOT change c.id. The visible cell id stays stable.
        # Do NOT call reserve_landing_stack. The placement rule is
        # irrelevant to in-place updates.

        persist_state()

    def _record_dag_cell(
        self,
        data: dict,
        files: dict[str, str],
        cell_name: str,
        cell_summary: str,
        parents: dict,
        in_place: bool = False,
        source_type: str = "generator",
    ):
        """Write a new DAG cell + blob records + cell_files edges into the channel DB,
        then mutate the in-memory channel state via the placement rule and broadcast.
        """
        import time as _time

        for attempt in range(3):
            try:
                self._record_dag_cell_inner(
                    data, files, cell_name, cell_summary,
                    parents, in_place, source_type,
                )
                return
            except Exception:
                if attempt < 2:
                    _time.sleep(0.5)
                else:
                    raise

    def _record_dag_cell_inner(
        self,
        data: dict,
        files: dict[str, str],
        cell_name: str,
        cell_summary: str,
        parents: dict,
        in_place: bool = False,
        source_type: str = "generator",
    ):
        conn = get_db_connection(self.channel)

        row = conn.execute(
            "SELECT COALESCE(MAX(sequence_num), 0) FROM cells WHERE run_id=?",
            (self.run_id,),
        ).fetchone()
        seq = row[0] + 1

        # Use placeholder_cell_id for the first commit so the frontend can
        # show an empty cell immediately when a run starts. Skipped for
        # in-place updates — those runs target an existing visible cell
        # that was not created via a placeholder.
        if not in_place and seq == 1 and self.placeholder_cell_id:
            cell_id = self.placeholder_cell_id
        else:
            cell_id = str(uuid.uuid4())
        generator_name = data.get("generator", self.generator_name)
        generator_cell_id = data.get("generator_cell_id")

        conn.execute(
            "INSERT INTO cells (id, run_id, generator_name, generator_cell_id, sequence_num, "
            "version_name, version_summary, source_type) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (cell_id, self.run_id, generator_name, generator_cell_id, seq,
             cell_name, cell_summary, source_type),
        )

        for parent_key, parent_cell_id in parents.items():
            conn.execute(
                "INSERT OR IGNORE INTO cell_edges "
                "(parent_cell_id, child_cell_id, parent_key) VALUES (?, ?, ?)",
                (parent_cell_id, cell_id, parent_key),
            )
            # Keep the tip cache coherent with the version chain. When
            # we add a 'previous_version' edge from parent→cell_id, any
            # cached lookup whose current tip equalled the parent now
            # resolves to cell_id. Other parent_key values (input_N,
            # branched_from, forked_from) don't affect version tips.
            if parent_key == "previous_version":
                for key, value in list(self._tip_cache.items()):
                    if value == parent_cell_id:
                        self._tip_cache[key] = cell_id

        for filepath, blob_hash in files.items():
            cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
            size = 0
            if os.path.exists(cas_path):
                try:
                    size = os.path.getsize(cas_path)
                except OSError:
                    pass

            conn.execute(
                "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                (blob_hash, size),
            )
            conn.execute(
                "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                "VALUES (?, ?, ?)",
                (cell_id, filepath, blob_hash),
            )

        commit_payload = json.dumps({
            "cell_id": cell_id,
            "name": cell_name,
            "summary": cell_summary,
            "sequence_num": seq,
            "file_count": len(files),
        })
        cur = conn.execute(
            "INSERT INTO run_events (run_id, event_type, payload) VALUES (?, 'commit', ?)",
            (self.run_id, commit_payload),
        )
        commit_event_id = cur.lastrowid
        commit_event_created_at = conn.execute(
            "SELECT created_at FROM run_events WHERE id=?",
            (commit_event_id,),
        ).fetchone()[0]

        conn.commit()
        conn.close()
        self._last_cell_id = cell_id

        self._broadcast_run_events([{
            "id": commit_event_id,
            "event_type": "commit",
            "payload": commit_payload,
            "created_at": commit_event_created_at,
        }])

        # Mutate in-memory channel state. For normal commits this runs
        # through the portal-recursion placement rule; for in-place updates
        # it mutates the visible target cell in place without creating a
        # new one on the canvas.
        try:
            if in_place:
                self._apply_update_to_state(
                    cell_id, files, cell_name, cell_summary,
                    summary_artifact=data.get("summary_artifact"),
                )
            else:
                self._apply_commit_to_state(
                    cell_id, files, cell_name, cell_summary, seq
                )
        except Exception:
            import traceback
            err = traceback.format_exc()
            self.log_buffer.append({
                "type": "stderr",
                "payload": "[placement] " + err,
            })
