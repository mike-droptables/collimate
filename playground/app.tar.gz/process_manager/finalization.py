"""Run finalization — mark the run row, commit logs/settings/config
artifacts onto the first cell's version tip."""

import os
from datetime import datetime

from cas import hash_and_store_bytes
from database import get_db_connection


class FinalizationMixin:
    def _finalize_run_status(self):
        """Mark run as completed/failed based on process exit code.

        Only updates if the run is still 'running' — if the generator already
        sent an IPC 'finish' message (or a /stop endpoint marked it 'stopped'),
        that status takes precedence over the process exit code. Performed as
        a single conditional UPDATE so a concurrent stop can't race between
        the SELECT and UPDATE and have its 'stopped' row silently overwritten.
        """
        candidate = "completed" if self.process and self.process.returncode == 0 else "failed"
        conn = get_db_connection(self.channel)
        conn.execute(
            "UPDATE runs SET status=? WHERE id=? AND status='running'",
            (candidate, self.run_id),
        )
        conn.commit()
        row = conn.execute("SELECT status FROM runs WHERE id=?", (self.run_id,)).fetchone()
        conn.close()
        final_status = row["status"] if row else None

        if final_status:
            self._broadcast_run_status(final_status)
        # If the watchdog killed the process, surface the reason as a
        # dedicated log row so the frontend drawer shows "Timed out"
        # instead of a bare non-zero exit code.
        if self.timeout_reason and final_status == "failed":
            try:
                conn = get_db_connection(self.channel)
                conn.execute(
                    "INSERT INTO run_events (run_id, event_type, payload) VALUES (?, 'timeout', ?)",
                    (self.run_id, self.timeout_reason),
                )
                conn.commit()
                conn.close()
            except Exception:
                pass

        # Write accumulated logs into the first cell's latest version
        self._commit_logs_to_first_cell()
        # Write accumulated settings history (initial + update_settings_N)
        self._commit_settings_to_first_cell()
        # Snapshot .colreserved/config/ (draft-authored settings + config
        # files) as private cell artifacts. Parallels the logs
        # treatment — persisted with the cell, hidden from the editor,
        # SDK-only access via gen.config.*.
        self._commit_config_to_first_cell()

    def _commit_logs_to_first_cell(self):
        """Write the run log to .colreserved/logs.txt in the first cell's
        version tip, without creating a new version chain entry.

        This is a silent in-place update so the logs are persisted as a
        cell artifact but don't clutter the version scrubber.
        """
        if not self.placeholder_cell_id:
            return

        # Collect all log text from run_events
        conn = get_db_connection(self.channel)
        rows = conn.execute(
            "SELECT event_type, payload FROM run_events WHERE run_id=? ORDER BY id",
            (self.run_id,),
        ).fetchall()

        log_lines = []
        for row in rows:
            if row["event_type"] in ("stdout", "stderr"):
                log_lines.append(row["payload"] or "")

        if not log_lines:
            conn.close()
            return

        log_text = "".join(log_lines)

        # Hash and store the log blob
        blob_hash = hash_and_store_bytes(log_text.encode("utf-8"))
        if not blob_hash:
            conn.close()
            return

        # Find the version tip of the first cell.
        tip_id = self._find_version_tip(self.placeholder_cell_id)

        # Ensure a cells row exists at the tip. If the generator crashed
        # before running any update_cell (e.g. ModuleNotFoundError on
        # startup), there's no cells row yet — inserting into cell_files
        # with a dangling cell_id trips the FK and swallows the logs
        # that would tell the user *why* the run failed.
        conn.close()
        self._ensure_genesis_row(tip_id)

        conn = get_db_connection(self.channel)
        # Ensure the blob row exists
        cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
        size = 0
        if os.path.exists(cas_path):
            try:
                size = os.path.getsize(cas_path)
            except OSError:
                pass
        conn.execute(
            "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
            (blob_hash, size),
        )

        # Upsert the logs file into the tip's cell_files (no new version row)
        conn.execute(
            "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
            "VALUES (?, ?, ?)",
            (tip_id, ".colreserved/logs.txt", blob_hash),
        )
        conn.commit()
        conn.close()

        # Update the in-memory cell so the frontend sees the logs file
        try:
            from models import VirtualFile
            from cell_placement import find_stack_containing_cell
            from state import persist_state

            ch = self._find_channel()
            if ch:
                stack = find_stack_containing_cell(ch, self.placeholder_cell_id)
                if stack:
                    for c in stack.cells:
                        if str(c.id) == self.placeholder_cell_id:
                            # Add or update logs.txt in the cell's files
                            existing = [f for f in (c.files or [])
                                        if f.name != ".colreserved/logs.txt"]
                            existing.append(VirtualFile(
                                name=".colreserved/logs.txt",
                                content=log_text,
                                language="plaintext",
                            ))
                            c.files = existing
                            # Bump updated_at so the frontend's applyServerState
                            # accepts the state_update instead of filtering it
                            # out as stale.
                            c.updated_at = datetime.now()
                            break
                    persist_state()
        except Exception:
            pass

    def _commit_settings_to_first_cell(self):
        """Write every settings file (initial + any update_settings_N)
        into .colreserved/ on the first cell's version tip, without
        creating a new version chain entry.

        Mirrors _commit_logs_to_first_cell — a silent in-place upsert so
        the settings trail is persisted as a cell artifact but does not
        clutter the version scrubber.
        """
        if not self.placeholder_cell_id or not self.settings_history:
            return

        tip_id = self._find_version_tip(self.placeholder_cell_id)
        # Same FK protection as _commit_logs_to_first_cell — settings can
        # be persisted on a run that crashed before any update_cell.
        self._ensure_genesis_row(tip_id)

        # Hash + upsert each entry
        conn = get_db_connection(self.channel)
        written: list[tuple[str, str]] = []  # (filepath, content) for in-memory update
        try:
            for name_stem, ext, content in self.settings_history:
                blob_hash = hash_and_store_bytes(content.encode("utf-8"))
                if not blob_hash:
                    continue
                cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
                size = 0
                if os.path.exists(cas_path):
                    try:
                        size = os.path.getsize(cas_path)
                    except OSError:
                        pass
                conn.execute(
                    "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                    (blob_hash, size),
                )
                filepath = f".colreserved/{name_stem}{ext}"
                conn.execute(
                    "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                    "VALUES (?, ?, ?)",
                    (tip_id, filepath, blob_hash),
                )
                written.append((filepath, content))
            conn.commit()
        finally:
            conn.close()

        # Update the in-memory cell so the frontend sees the settings files
        try:
            from models import VirtualFile
            from cell_placement import find_stack_containing_cell
            from state import persist_state

            ch = self._find_channel()
            if ch is None:
                return
            stack = find_stack_containing_cell(ch, self.placeholder_cell_id)
            if stack is None:
                return
            for c in stack.cells:
                if str(c.id) == self.placeholder_cell_id:
                    # Remove any existing settings entries we're about to re-add
                    new_paths = {fp for fp, _ in written}
                    existing = [f for f in (c.files or []) if f.name not in new_paths]
                    for filepath, content in written:
                        ext = os.path.splitext(filepath)[1]
                        lang = {
                            ".set_yaml": "yaml",
                            ".yaml": "yaml",
                            ".yml": "yaml",
                            ".md": "markdown",
                            ".json": "json",
                        }.get(ext, "plaintext")
                        existing.append(VirtualFile(
                            name=filepath, content=content, language=lang,
                        ))
                    c.files = existing
                    # Bump updated_at so the frontend accepts this
                    # state_update (applyServerState filters by timestamp).
                    c.updated_at = datetime.now()
                    break
            persist_state()
        except Exception:
            pass

    def _commit_config_to_first_cell(self):
        """Snapshot the workspace's ``.colreserved/config/`` tree into
        the first cell's version tip as private cell artifacts.

        Same shape as ``_commit_logs_to_first_cell`` / settings: upsert
        into cell_files at the tip with no new version row. The
        generator reads these at run-time via the SDK's
        ``gen.config.*`` API (which resolves paths under
        ``.colreserved/config/files/``); persisting them here makes the
        config travel with the cell for history / restore / export.
        """
        if not self.placeholder_cell_id:
            return

        cfg_root = os.path.join(self.workspace_dir, ".colreserved", "config")
        if not os.path.isdir(cfg_root):
            return

        # Walk the config tree and collect (rel_path_under_.colreserved, content)
        collected: list[tuple[str, str]] = []
        for dirpath, _, filenames in os.walk(cfg_root):
            for fname in filenames:
                abs_path = os.path.join(dirpath, fname)
                rel = os.path.relpath(abs_path, self.workspace_dir).replace("\\", "/")
                try:
                    with open(abs_path, "r", encoding="utf-8", errors="replace") as fh:
                        content = fh.read()
                except Exception:
                    continue
                collected.append((rel, content))

        if not collected:
            return

        tip_id = self._find_version_tip(self.placeholder_cell_id)
        # Same FK protection — a config-only crash (generator exits before
        # update_cell) still needs the config persisted under a valid
        # cells row so the FK on cell_files is satisfied.
        self._ensure_genesis_row(tip_id)

        conn = get_db_connection(self.channel)
        written: list[tuple[str, str]] = []
        try:
            for filepath, content in collected:
                blob_hash = hash_and_store_bytes(content.encode("utf-8"))
                if not blob_hash:
                    continue
                cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
                size = os.path.getsize(cas_path) if os.path.exists(cas_path) else 0
                conn.execute(
                    "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                    (blob_hash, size),
                )
                conn.execute(
                    "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                    "VALUES (?, ?, ?)",
                    (tip_id, filepath, blob_hash),
                )
                written.append((filepath, content))
            conn.commit()
        finally:
            conn.close()

        # Mirror onto the in-memory cell so the frontend's state stream
        # sees the files. The editor already hides ``.colreserved/*``
        # from its tabs, so these stay private to the SDK.
        try:
            from models import VirtualFile
            from cell_placement import find_stack_containing_cell
            from state import persist_state

            ch = self._find_channel()
            if ch is None:
                return
            stack = find_stack_containing_cell(ch, self.placeholder_cell_id)
            if stack is None:
                return
            lang_map = {
                ".json": "json", ".yaml": "yaml", ".yml": "yaml",
                ".md": "markdown", ".set_yaml": "yaml",
            }
            for c in stack.cells:
                if str(c.id) == self.placeholder_cell_id:
                    new_paths = {fp for fp, _ in written}
                    existing = [f for f in (c.files or []) if f.name not in new_paths]
                    for filepath, content in written:
                        ext = os.path.splitext(filepath)[1]
                        existing.append(VirtualFile(
                            name=filepath,
                            content=content,
                            language=lang_map.get(ext, "plaintext"),
                        ))
                    c.files = existing
                    c.updated_at = datetime.now()
                    break
            persist_state()
        except Exception:
            pass
