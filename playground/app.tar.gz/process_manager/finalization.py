"""Run finalization — mark the run row, commit logs/settings/config
artifacts onto the first cell's version tip."""
# pyright: reportAttributeAccessIssue=false
# (mixin: attributes like log_buffer/workspace_dir live on the composed
# ProcessManager in manager.py, not on the mixin class itself)

import logging
import os
from datetime import datetime

from cas import hash_and_store_bytes
from database import get_db_connection

_logger = logging.getLogger("process_manager.finalization")


class FinalizationMixin:
    def _finalize_run_status(self):
        """Mark run as completed/failed based on process exit code.

        Only updates if the run is still 'running' — if the generator already
        sent an IPC 'finish' message (or a /stop endpoint marked it 'stopped'),
        that status takes precedence over the process exit code. Performed as
        a single conditional UPDATE so a concurrent stop can't race between
        the SELECT and UPDATE and have its 'stopped' row silently overwritten.
        """
        candidate = "completed" if self.process and self.process.returncode == 0 else "failed"
        conn = get_db_connection(self.channel)
        conn.execute(
            "UPDATE runs SET status=? WHERE id=? AND status='running'",
            (candidate, self.run_id),
        )
        conn.commit()
        row = conn.execute("SELECT status FROM runs WHERE id=?", (self.run_id,)).fetchone()
        conn.close()
        final_status = row["status"] if row else None

        if final_status:
            self._broadcast_run_status(final_status)
            # Mirror the terminal status onto the phase so the cell indicator
            # leaves "running"/"spinning up" and the reconnect column is
            # authoritative. Single chokepoint for native completed/failed/
            # stopped (this runs on every run end via _wait_and_cleanup).
            self._apply_phase(final_status, self.timeout_reason or "")
        # If the watchdog killed the process, surface the reason as a
        # dedicated log row so the frontend drawer shows "Timed out"
        # instead of a bare non-zero exit code.
        if self.timeout_reason and final_status == "failed":
            try:
                conn = get_db_connection(self.channel)
                conn.execute(
                    "INSERT INTO run_events (run_id, event_type, payload) VALUES (?, 'timeout', ?)",
                    (self.run_id, self.timeout_reason),
                )
                conn.commit()
                conn.close()
            except Exception:
                _logger.warning(
                    "run %s: failed to record timeout event (%r)",
                    self.run_id, self.timeout_reason, exc_info=True,
                )

        # Write accumulated logs into the first cell's latest version
        self._commit_logs_to_first_cell()
        # Write accumulated settings history (initial + update_settings_N)
        self._commit_settings_to_first_cell()
        # Snapshot .colreserved/config/ (the run's effective settings +
        # prompt) onto the produced version as the DAG's record of "what
        # settings made this version". Parallels the logs treatment —
        # persisted with the cell, hidden from the editor's file tree,
        # surfaced as the "Run settings" band in version history.
        self._commit_config_to_first_cell()

    def _commit_logs_to_first_cell(self):
        """Write the run log to .colreserved/logs.txt in the first cell's
        version tip, without creating a new version chain entry.

        This is a silent in-place update so the logs are persisted as a
        cell artifact but don't clutter the version scrubber.
        """
        if not self.placeholder_cell_id:
            return

        # Collect the canonical log from run_events. This is the SAME
        # format_log_line projection the live drawer renders (see
        # frontend/src/lib/runLogFormat.ts), over the SAME rows, so the saved
        # logs.txt matches what the user watched live — labeled, timestamped,
        # with the allow-list dropping internal plumbing rows. (Previously
        # this filtered to raw stdout/stderr only, which both lost the
        # status/phase/error metadata and diverged from the live view.)
        from process_manager.log_format import format_log_line

        conn = get_db_connection(self.channel)
        rows = conn.execute(
            "SELECT event_type, payload, created_at FROM run_events "
            "WHERE run_id=? ORDER BY id",
            (self.run_id,),
        ).fetchall()

        log_lines = []
        for row in rows:
            line = format_log_line(row["event_type"], row["payload"], row["created_at"])
            if line is not None:
                log_lines.append(line + "\n")

        if not log_lines:
            conn.close()
            return

        log_text = "".join(log_lines)

        # Hash and store the log blob
        blob_hash = hash_and_store_bytes(log_text.encode("utf-8"))
        if not blob_hash:
            conn.close()
            return

        # Find the version tip of the first cell.
        tip_id = self._find_version_tip(self.placeholder_cell_id)

        # Ensure a cells row exists at the tip. If the generator crashed
        # before running any update_cell (e.g. ModuleNotFoundError on
        # startup), there's no cells row yet — inserting into cell_files
        # with a dangling cell_id trips the FK and swallows the logs
        # that would tell the user *why* the run failed.
        conn.close()
        self._ensure_genesis_row(tip_id)

        conn = get_db_connection(self.channel)
        # Ensure the blob row exists
        cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
        size = 0
        if os.path.exists(cas_path):
            try:
                size = os.path.getsize(cas_path)
            except OSError:
                pass
        conn.execute(
            "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
            (blob_hash, size),
        )

        # Upsert the logs file into the tip's cell_files (no new version row)
        conn.execute(
            "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
            "VALUES (?, ?, ?)",
            (tip_id, ".colreserved/logs.txt", blob_hash),
        )
        conn.commit()
        conn.close()

        # Update the in-memory cell so the frontend sees the logs file
        try:
            from models import VirtualFile
            from cell_placement import find_stack_containing_cell
            from state import persist_state, state_lock

            with state_lock:
                ch = self._find_channel()
                if ch:
                    stack = find_stack_containing_cell(ch, self.placeholder_cell_id)
                    if stack:
                        for c in stack.cells:
                            if str(c.id) == self.placeholder_cell_id:
                                # Add or update logs.txt in the cell's files
                                existing = [f for f in (c.files or [])
                                            if f.name != ".colreserved/logs.txt"]
                                existing.append(VirtualFile(
                                    name=".colreserved/logs.txt",
                                    content=log_text,
                                    language="plaintext",
                                ))
                                c.files = existing
                                # Bump updated_at so the frontend's applyServerState
                                # accepts the state_update instead of filtering it
                                # out as stale.
                                c.updated_at = datetime.now()
                                break
                        persist_state()
        except Exception:
            _logger.warning(
                "run %s: failed to mirror logs.txt onto in-memory cell %s",
                self.run_id, self.placeholder_cell_id, exc_info=True,
            )

    def _commit_settings_to_first_cell(self):
        """Write every settings file (initial + any update_settings_N)
        into .colreserved/ on the first cell's version tip, without
        creating a new version chain entry.

        Mirrors _commit_logs_to_first_cell — a silent in-place upsert so
        the settings trail is persisted as a cell artifact but does not
        clutter the version scrubber.
        """
        if not self.placeholder_cell_id or not self.settings_history:
            return

        tip_id = self._find_version_tip(self.placeholder_cell_id)
        # Same FK protection as _commit_logs_to_first_cell — settings can
        # be persisted on a run that crashed before any update_cell.
        self._ensure_genesis_row(tip_id)

        # Hash + upsert each entry
        conn = get_db_connection(self.channel)
        written: list[tuple[str, str]] = []  # (filepath, content) for in-memory update
        try:
            for name_stem, ext, content in self.settings_history:
                blob_hash = hash_and_store_bytes(content.encode("utf-8"))
                if not blob_hash:
                    continue
                cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
                size = 0
                if os.path.exists(cas_path):
                    try:
                        size = os.path.getsize(cas_path)
                    except OSError:
                        pass
                conn.execute(
                    "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                    (blob_hash, size),
                )
                filepath = f".colreserved/{name_stem}{ext}"
                conn.execute(
                    "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                    "VALUES (?, ?, ?)",
                    (tip_id, filepath, blob_hash),
                )
                written.append((filepath, content))
            conn.commit()
        finally:
            conn.close()

        # Update the in-memory cell so the frontend sees the settings files
        try:
            from models import VirtualFile
            from cell_placement import find_stack_containing_cell
            from state import persist_state, state_lock

            with state_lock:
                ch = self._find_channel()
                if ch is None:
                    return
                stack = find_stack_containing_cell(ch, self.placeholder_cell_id)
                if stack is None:
                    return
                for c in stack.cells:
                    if str(c.id) == self.placeholder_cell_id:
                        # Remove any existing settings entries we're about to re-add
                        new_paths = {fp for fp, _ in written}
                        existing = [f for f in (c.files or []) if f.name not in new_paths]
                        for filepath, content in written:
                            ext = os.path.splitext(filepath)[1]
                            lang = {
                                ".set_yaml": "yaml",
                                ".yaml": "yaml",
                                ".yml": "yaml",
                                ".md": "markdown",
                                ".json": "json",
                            }.get(ext, "plaintext")
                            existing.append(VirtualFile(
                                name=filepath, content=content, language=lang,
                            ))
                        c.files = existing
                        # Bump updated_at so the frontend accepts this
                        # state_update (applyServerState filters by timestamp).
                        c.updated_at = datetime.now()
                        break
                persist_state()
        except Exception:
            _logger.warning(
                "run %s: failed to mirror settings files onto in-memory cell %s",
                self.run_id, self.placeholder_cell_id, exc_info=True,
            )

    def _effective_run_prompt(self) -> str | None:
        """The prompt this run actually saw: the workspace's
        ``.colreserved/prompt.md`` when present (req.prompt always wins
        there, falling back to the seeded tag prompt), else the
        prompt stored on the runs row."""
        path = os.path.join(self.workspace_dir, ".colreserved", "prompt.md")
        try:
            if os.path.isfile(path):
                with open(path, "r", encoding="utf-8", errors="replace") as fh:
                    return fh.read()
        except OSError:
            pass
        try:
            conn = get_db_connection(self.channel)
            try:
                row = conn.execute(
                    "SELECT prompt FROM runs WHERE id=?", (self.run_id,),
                ).fetchone()
            finally:
                conn.close()
            return row["prompt"] if row else None
        except Exception:
            return None

    def _commit_config_to_first_cell(self):
        """Snapshot the workspace's ``.colreserved/config/`` tree into
        the produced version (the first cell's tip) as private cell
        artifacts — the DAG's record of the settings that made this
        version.

        Same shape as ``_commit_logs_to_first_cell`` / settings: upsert
        into cell_files at the tip with no new version row. These are NOT
        re-seeded into a later run (the config tag is the authoritative
        starting point — see create_run); they exist purely so version
        history can surface and diff "what settings produced each
        version" (the CellHistoryView "Run settings" band).
        """
        if not self.placeholder_cell_id:
            return

        cfg_root = os.path.join(self.workspace_dir, ".colreserved", "config")

        # Walk the config tree and collect (rel_path_under_.colreserved, content)
        collected: list[tuple[str, str]] = []
        if os.path.isdir(cfg_root):
            for dirpath, _, filenames in os.walk(cfg_root):
                for fname in filenames:
                    abs_path = os.path.join(dirpath, fname)
                    rel = os.path.relpath(abs_path, self.workspace_dir).replace("\\", "/")
                    try:
                        with open(abs_path, "r", encoding="utf-8", errors="replace") as fh:
                            content = fh.read()
                    except Exception:
                        _logger.warning(
                            "run %s: skipping unreadable config file %s",
                            self.run_id, abs_path, exc_info=True,
                        )
                        continue
                    collected.append((rel, content))

        # Snapshot the effective run prompt alongside the config files so
        # the run-settings record (and its history diff) includes the
        # prompt this version actually ran with, not just the .set_yaml
        # knobs.
        prompt_text = self._effective_run_prompt()
        if prompt_text and prompt_text.strip():
            prompt_rel = ".colreserved/config/files/prompt.md"
            collected = [(p, c) for p, c in collected if p != prompt_rel]
            collected.append((prompt_rel, prompt_text))

        if not collected:
            return

        tip_id = self._find_version_tip(self.placeholder_cell_id)
        # Same FK protection — a config-only crash (generator exits before
        # update_cell) still needs the config persisted under a valid
        # cells row so the FK on cell_files is satisfied.
        self._ensure_genesis_row(tip_id)

        conn = get_db_connection(self.channel)
        written: list[tuple[str, str]] = []
        try:
            for filepath, content in collected:
                blob_hash = hash_and_store_bytes(content.encode("utf-8"))
                if not blob_hash:
                    continue
                cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
                size = os.path.getsize(cas_path) if os.path.exists(cas_path) else 0
                conn.execute(
                    "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                    (blob_hash, size),
                )
                conn.execute(
                    "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                    "VALUES (?, ?, ?)",
                    (tip_id, filepath, blob_hash),
                )
                written.append((filepath, content))
            conn.commit()
        finally:
            conn.close()

        # Mirror onto the in-memory cell so the frontend's state stream
        # sees the files. The editor already hides ``.colreserved/*``
        # from its tabs, so these stay private to the SDK.
        try:
            from models import VirtualFile
            from cell_placement import find_stack_containing_cell
            from state import persist_state, state_lock

            with state_lock:
                ch = self._find_channel()
                if ch is None:
                    return
                stack = find_stack_containing_cell(ch, self.placeholder_cell_id)
                if stack is None:
                    return
                lang_map = {
                    ".json": "json", ".yaml": "yaml", ".yml": "yaml",
                    ".md": "markdown", ".set_yaml": "yaml",
                }
                for c in stack.cells:
                    if str(c.id) == self.placeholder_cell_id:
                        new_paths = {fp for fp, _ in written}
                        existing = [f for f in (c.files or []) if f.name not in new_paths]
                        for filepath, content in written:
                            ext = os.path.splitext(filepath)[1]
                            existing.append(VirtualFile(
                                name=filepath,
                                content=content,
                                language=lang_map.get(ext, "plaintext"),
                            ))
                        c.files = existing
                        c.updated_at = datetime.now()
                        break
                persist_state()
        except Exception:
            _logger.warning(
                "run %s: failed to mirror config files onto in-memory cell %s",
                self.run_id, self.placeholder_cell_id, exc_info=True,
            )
