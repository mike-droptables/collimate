"""Shared 7-method Host protocol implementation.

Both runtime backends (in-process WASM, subprocess Native) dispatch
the core cell-write + lifecycle operations through these methods so
the cell merge, broadcast, log/status buffering, and key/message
poll semantics are bit-for-bit identical regardless of how the
generator is hosted.

The contract mirrors :class:`collimate.host_protocol.Host` exactly.
Anything outside the 7 methods (terminals, ports, subprocess
streaming, mid-run settings modal, renderer action polling,
snapshot diffing, daemon-backed sandbox chats) is **Tier B** and
lives in other mixins (``ipc.py`` op handlers for native, dedicated
attributes for wasm).
"""
# pyright: reportAttributeAccessIssue=false
# (mixin: attributes like log_buffer/workspace_dir live on the composed
# ProcessManager in manager.py, not on the mixin class itself)

import asyncio
import base64
import json


def _file_artifact(path: str, content: "str | bytes") -> dict:
    """Build a memory-type artifact entry for the manager's
    ``_update_cell`` / ``_update_cell_initial`` / ``_create_side_cell``.

    Text rides as utf-8; bytes ride as base64 (the artifacts pipeline
    in ``api/process_manager/artifacts.py`` already handles the
    decode step). Same shape used by ``wasm_runner._file_artifact`` —
    factored here so native callers (Phase 3) can build artifacts
    the same way without importing the wasm-specific module.
    """
    if isinstance(content, bytes):
        return {
            "type": "memory",
            "cell_path": path,
            "content": base64.b64encode(content).decode("ascii"),
            "encoding": "base64",
        }
    return {
        "type": "memory",
        "cell_path": path,
        "content": content,
        "encoding": "utf-8",
    }


class HostMixin:
    """Implements :class:`collimate.host_protocol.Host` against a
    :class:`process_manager.manager.ProcessManager`.

    Composed into ``ProcessManager`` so both the wasm dispatch
    (in-process awaits) and the native IPC handler (worker-thread
    via ``asyncio.to_thread``) can dispatch through the same
    methods. The sync core (``_emit_partial_core``) is exposed
    separately so native's IPC ``update_cell`` op can run it
    inside ``to_thread`` without re-implementing the artifact-
    build / merge / broadcast sequence.
    """

    # ------------------------------------------------------------------
    # emit_partial — the cell-write entry point
    # ------------------------------------------------------------------

    def _emit_partial_core(
        self,
        *,
        files: dict[str, "str | bytes"] | None = None,
        artifacts: list[dict] | None = None,
        cell_name: str | None = None,
        summary: str | None = None,
        pinned: str | None = None,
        chat_messages: list | None = None,
        deleted_files: list[str] | None = None,
        version: bool = False,
    ) -> None:
        """Synchronous core. Builds artifacts, calls the cell-write
        helper (``_update_cell`` if ``version=True``, else
        ``_update_cell_initial``), broadcasts dag_commit. Safe to
        call from a worker thread (under ``asyncio.to_thread``) or
        from the event loop directly.

        Two ways to provide payload:

        * ``files`` — a dict {path: str | bytes}. The mixin builds
          memory-type artifacts internally. This is what wasm
          generators emit through ``ctx.emit_partial(files=...)``.
        * ``artifacts`` — a pre-built list of artifact dicts (with
          ``type``, ``cell_path``, ``local_path`` or ``content``,
          ``encoding``). This is what the native IPC handler
          receives from the SDK's ``HostBridge.update_cell``,
          which has already iterated ``tracked_writes`` to build
          workspace-type artifacts.

        Either / both / neither is acceptable. ``chat_messages``,
        when present, appends a memory-type artifact at
        ``.colreserved/.collimate_messages.json``.

        ``version=True`` selects the version-chain write path
        (``_update_cell`` → new ``cells`` row + ``cell_edges``
        ``previous_version`` edge → version scrubber sees a new
        checkpoint). ``version=False`` upserts the placeholder
        cell row in place. Native's chat-style runs use
        ``version=True`` for every emit after the first; wasm
        always uses ``version=False``.
        """
        # Counter (truthy on every call; the run-end log line shows
        # the count, not just a bool).
        self._emit_partial_called = (self._emit_partial_called or 0) + 1
        if cell_name is not None:
            self._last_emit_cell_name = cell_name
        if summary is not None:
            self._last_emit_summary = summary
        if pinned is not None:
            self._last_emit_pinned = pinned

        final_artifacts: list[dict] = list(artifacts or [])
        if files:
            for path, content in files.items():
                final_artifacts.append(_file_artifact(path, content))
        if chat_messages:
            final_artifacts.append({
                "type": "memory",
                "cell_path": ".colreserved/.collimate_messages.json",
                "content": json.dumps(
                    [m.to_dict() for m in chat_messages], indent=2,
                ),
                "encoding": "utf-8",
            })

        data: dict = {"artifacts": final_artifacts}
        # Use last-known values when this call doesn't override —
        # keeps the UI stable when a generator only refreshes one
        # facet per emit (e.g. summary mid-stream while files are
        # unchanged).
        data["name"] = (
            cell_name
            if cell_name is not None
            else (self._last_emit_cell_name or self.generator_name or "Output")
        )
        data["summary"] = (
            summary
            if summary is not None
            else (self._last_emit_summary or "")
        )
        # ``pinned`` only flows when explicitly set —
        # otherwise the cell record's existing value (manifest
        # default or a previous override) stays in place.
        sa = (
            pinned
            if pinned is not None
            else self._last_emit_pinned
        )
        if sa is not None:
            data["pinned"] = sa
        if deleted_files:
            data["deleted_files"] = list(deleted_files)

        if version:
            self._update_cell(data)
        else:
            self._update_cell_initial(data)

        # Broadcast dag_commit so the frontend's iframe pool fans out
        # FILES_CHANGED to sandboxed renderers (milkdown / monaco /
        # website) mounted on this cell — without it, the SSE handler
        # only triggers FILES_CHANGED on dag_commit, and the cellCache
        # gets the new files but the iframe stays on whatever content
        # it had at mount.
        try:
            self._broadcast_dag_commit()
        except Exception as exc:
            self.log_buffer.append({
                "type": "stderr",
                "payload": f"[emit_partial broadcast error] {exc}",
            })

    async def emit_partial(
        self,
        *,
        files: dict[str, "str | bytes"] | None = None,
        cell_name: str | None = None,
        summary: str | None = None,
        pinned: str | None = None,
        chat_messages: list | None = None,
    ) -> None:
        """Public Host-protocol entry point used by wasm generators.

        Wasm runs in-process so the cell-write is sync and we just
        ``await asyncio.sleep(0)`` afterward to let any concurrent
        ``/api/state`` poller observe the new state. Native runs
        bypass this method and call ``_emit_partial_core`` from
        inside ``asyncio.to_thread`` so the slow DB+broadcast
        doesn't stall the IPC reader's event loop.
        """
        self._emit_partial_core(
            files=files,
            cell_name=cell_name,
            summary=summary,
            pinned=pinned,
            chat_messages=chat_messages,
            version=False,
        )
        await asyncio.sleep(0)

    # ------------------------------------------------------------------
    # is_cancelled / push_log / set_status — fire-and-forget primitives
    # ------------------------------------------------------------------

    def is_cancelled(self) -> bool:
        """True once the user has POSTed to the interrupt endpoint
        OR a SIGTERM signal handler set the cancel flag (native).
        Generators should poll this cooperatively between chunks of
        work."""
        return self._cancelled

    def push_log(self, line: str) -> None:
        """Append a ``gen.log(msg)`` line. WASM in-process path — emits a
        dedicated ``log`` row so it renders as ``LOG`` in the canonical log,
        matching native (where gen.log rides the ``[INFO]``-framed stderr the
        formatter re-tags to LOG). The native path never reaches here."""
        self.log_buffer.append({"type": "log", "payload": line})

    def set_status(self, message: str) -> None:
        """``gen.status(msg)`` — update the CURRENT phase's sub-message. Status
        is no longer a separate concept: it's the message of the live phase.
        WASM in-process path (native goes over IPC to _op_phase)."""
        from process_manager.phases import RUNNING
        self._apply_phase(self.current_phase or RUNNING, message)

    def set_phase(self, phase: str, message: str = "") -> None:
        """``gen.phase(name, msg)`` — set the run's lifecycle phase. WASM
        in-process path (native goes over IPC to _op_phase)."""
        self._apply_phase(phase, message)

    # ------------------------------------------------------------------
    # create_side_cell — fan-out cell creation
    # ------------------------------------------------------------------

    async def create_side_cell(
        self,
        *,
        name: str | None = None,
        summary: str | None = None,
        pinned: str | None = None,
        files: dict[str, "str | bytes"] | None = None,
    ) -> str:
        """Append a new sibling cell below in the right-side stack.

        Wraps the manager's existing ``_create_side_cell``. Returns
        the new cell's id. ``files`` values may be ``str`` or
        ``bytes``; bytes ride the ``encoding: base64`` path.
        """
        artifacts = [
            _file_artifact(path, content)
            for path, content in (files or {}).items()
        ]
        data: dict = {"artifacts": artifacts}
        if name is not None:
            data["name"] = name
        if summary is not None:
            data["summary"] = summary
        if pinned is not None:
            data["pinned"] = pinned
        # Sync DB I/O. wasm calls this inline (pyodide has no real
        # threads, so to_thread parks forever); native callers from
        # the IPC handler should wrap in to_thread themselves.
        self._create_side_cell(data)
        try:
            self._broadcast_dag_commit()
        except Exception as exc:
            self.log_buffer.append({
                "type": "stderr",
                "payload": f"[create_side_cell broadcast error] {exc}",
            })
        await asyncio.sleep(0)
        return self._last_cell_id or ""

    # ------------------------------------------------------------------
    # request_key — modal-driven secret request
    # ------------------------------------------------------------------

    async def request_key(
        self,
        key_name: str,
        description: str = "",
        force: bool = False,
    ) -> str:
        """Resolve a user-held secret via the in-cell modal. Fast
        path: ``os.environ[key_name]`` when set and not ``force``.
        Slow path: pop the modal; the user submits;
        ``/key_continue`` persists the value to the keystore,
        mirrors it into ``os.environ``, and unblocks this coroutine.

        Re-raises ``KeyRequestCancelled`` (the SDK-public type) on
        user cancel so wasm generators can catch it without
        crossing module boundaries. Native generators see the same
        exception identity through the SDK alias.
        """
        from collimate.wasm_sdk import KeyRequestCancelled as _SDKCancelled
        from .ipc import KeyRequestCancelled as _MgrCancelled
        try:
            return await self.await_key_value(
                key_name=key_name,
                description=description,
                force=force,
            )
        except _MgrCancelled as exc:
            raise _SDKCancelled(exc.key_name) from None


__all__ = ["HostMixin", "_file_artifact"]
