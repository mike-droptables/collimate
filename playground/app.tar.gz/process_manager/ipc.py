"""IPC protocol — localhost TCP socket, JSON-per-line.

All ops the generator can invoke on the host run through ``_handle_ipc``.

NAK frames: when the host can't parse or process a message that the
generator may be awaiting an ack for, it sends back a one-line frame::

    {"op": "nak", "for_op": <str>, "reason": <str>}

The SDK's ``_emit_and_wait`` recognises this and raises ``IPCNakError``
so the generator can decide whether to retry, downsize, or abort. Before
this, oversize and malformed-JSON messages were silently dropped on the
host and the generator blocked forever waiting for an ack that would
never come.
"""

import asyncio
import json
import os

from database import get_db_connection


# Match the size cap the SDK uses on its outbound emit path. Anything
# larger than this on the wire is treated as a protocol error (a single
# IPC frame should never legitimately exceed 10 MB).
IPC_MAX_LINE_BYTES = 10_000_000


class KeyRequestCancelled(Exception):
    """The user pressed Cancel on the in-cell key-request modal.

    Raised by ``await_key_value`` when ``/key_continue`` fires with
    ``cancel=True``. Both the native IPC handler and the wasm dispatch
    catch this — native turns it into a ``cancelled=True`` ack so the
    SDK raises ``StopSignal``; wasm treats it as a cooperative stop.
    """

    def __init__(self, key_name: str):
        super().__init__(f"key request for {key_name!r} cancelled by user")
        self.key_name = key_name


class IPCMixin:
    async def await_settings_update(
        self,
        settings_file_path: str,
        timeout: float = 600.0,
    ) -> dict:
        """Pop the in-cell settings-update modal and block until the
        user submits.

        Single source of truth for the settings-update flow. Used by:

          * the native ``request_settings_update`` IPC handler below
          * ``WasmRunnerMixin.request_settings_update``

        Reads the schema-form file from the workspace, broadcasts a
        ``settings_update_requested`` event the frontend listens for,
        then awaits ``self._pending_settings_update`` — the
        ``/settings_continue`` endpoint sets ``_settings_update_values``
        and signals the event.

        Returns the merged values dict the user submitted. Raises
        ``RuntimeError`` on timeout or missing-file.
        """
        abs_path = os.path.join(self.workspace_dir, settings_file_path)
        if not os.path.isfile(abs_path):
            raise RuntimeError(f"settings file not found: {settings_file_path}")
        with open(abs_path, "r", encoding="utf-8") as f:
            settings_content = f.read()

        self.log_buffer.append({
            "type": "settings_update_requested",
            "payload": json.dumps({
                "run_id": self.run_id,
                "cell_id": self.placeholder_cell_id or "",
                "settings_content": settings_content,
                "settings_file_path": settings_file_path,
            }),
        })

        self._pending_settings_update = asyncio.Event()
        self._settings_update_values = None
        try:
            try:
                await asyncio.wait_for(
                    self._pending_settings_update.wait(),
                    timeout=timeout,
                )
            except asyncio.TimeoutError as exc:
                self.log_buffer.append({
                    "type": "ipc_error",
                    "payload": (
                        "settings_update timed out after 10 min — "
                        "frontend did not respond"
                    ),
                })
                raise RuntimeError("settings_update timed out") from exc
            values = self._settings_update_values or {}
        finally:
            self._pending_settings_update = None
            self._settings_update_values = None
        return dict(values)

    async def await_key_value(
        self,
        key_name: str,
        description: str = "",
        force: bool = False,
        attempt: int = 1,
        timeout: float = 600.0,
    ) -> str:
        """Resolve a user-held secret, prompting via the in-cell modal
        if needed.

        Single source of truth for the key-request flow. Used by:

          * the native ``request_key`` IPC handler below
          * the wasm dispatch (``WasmRunnerMixin.request_key``)

        Fast path: returns ``os.environ[key_name]`` when set and
        ``force=False``. Slow path: broadcasts a ``key_requested`` event
        on ``log_buffer`` (which the SSE channel surfaces to the
        ``KeyRequestOverlay``), then awaits ``self._pending_key_request``
        — the ``/key_continue`` endpoint sets ``_key_request_value`` /
        ``_key_request_cancelled`` and signals the event.

        Raises ``KeyRequestCancelled`` if the user cancelled, or
        ``RuntimeError`` on timeout / blank submission.
        """
        if not key_name or not isinstance(key_name, str):
            raise RuntimeError("await_key_value requires a non-empty key_name")

        if not force:
            existing = (os.environ.get(key_name) or "").strip()
            if existing:
                return existing

        self.log_buffer.append({
            "type": "key_requested",
            "payload": json.dumps({
                "run_id": self.run_id,
                "cell_id": self.placeholder_cell_id or "",
                "key_name": key_name,
                "description": description,
                "attempt": attempt,
            }),
        })

        self._pending_key_request = asyncio.Event()
        self._key_request_value = None
        self._key_request_cancelled = False
        try:
            try:
                await asyncio.wait_for(
                    self._pending_key_request.wait(),
                    timeout=timeout,
                )
            except asyncio.TimeoutError as exc:
                self.log_buffer.append({
                    "type": "ipc_error",
                    "payload": (
                        f"key_request for {key_name!r} timed out "
                        f"after {int(timeout)}s — user did not respond"
                    ),
                })
                raise RuntimeError(
                    f"key_request for {key_name!r} timed out"
                ) from exc
            cancelled = self._key_request_cancelled
            value = self._key_request_value
        finally:
            self._pending_key_request = None
            self._key_request_value = None
            self._key_request_cancelled = False

        if cancelled:
            raise KeyRequestCancelled(key_name)
        val = (value or "").strip()
        if not val:
            # /key_continue should have rejected this; belt-and-suspenders.
            raise RuntimeError(
                "key_request returned empty value — "
                "/key_continue accepted a blank submission"
            )
        return val

    async def _send_nak(self, for_op: str, reason: str) -> None:
        """Write a NAK frame to the IPC channel.

        Failing to write (writer torn down mid-handshake) is logged but
        not raised — there's nothing useful to do once the channel is
        gone, and the SDK will see EOF and surface its own error.
        """
        if self._ipc_writer is None:
            return
        try:
            frame = json.dumps({"op": "nak", "for_op": for_op, "reason": reason}) + "\n"
            self._ipc_writer.write(frame.encode())
            await self._ipc_writer.drain()
        except Exception as exc:
            self.log_buffer.append({
                "type": "stderr",
                "payload": f"[IPC] failed to send NAK ({reason!r} for {for_op!r}): {exc}",
            })

    async def _handle_ipc_connection(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        """Handle the generator's TCP connection for IPC messages."""
        self._ipc_writer = writer
        try:
            while True:
                line = await reader.readline()
                if not line:
                    break
                if len(line) > IPC_MAX_LINE_BYTES:
                    self.log_buffer.append({
                        "type": "ipc_error",
                        "payload": f"oversize: {len(line)} bytes > {IPC_MAX_LINE_BYTES}",
                    })
                    await self._send_nak("unknown", "oversize")
                    continue
                await self._handle_ipc(line.decode("utf-8", errors="replace").strip())
        except Exception as e:
            self.log_buffer.append({"type": "stderr", "payload": f"[IPC Error] {e}"})
        finally:
            writer.close()
            await writer.wait_closed()
            self._ipc_writer = None

    async def _handle_ipc(self, line: str):
        """Process a single IPC JSON message."""
        if not line:
            return
        try:
            data = json.loads(line)
        except json.JSONDecodeError as exc:
            # Truncate the bad payload in the log to avoid drowning the
            # ipc_error stream when a generator emits a few MB of garbage.
            preview = line[:200] + ("…" if len(line) > 200 else "")
            self.log_buffer.append({
                "type": "ipc_error",
                "payload": f"JSON decode error: {exc.msg}; preview: {preview!r}",
            })
            await self._send_nak("unknown", f"json_decode_error: {exc.msg}")
            return

        op = data.get("op")

        if op == "update_cell":
            try:
                if data.get("initial", False):
                    await asyncio.to_thread(self._update_cell_initial, data)
                else:
                    await asyncio.to_thread(self._update_cell, data)
            except Exception as exc:
                self.log_buffer.append({"type": "stderr", "payload": f"[update_cell error] {exc}"})
            if self._ipc_writer:
                ack = json.dumps({"op": "ack_update", "cell_id": self._last_cell_id or ""}) + "\n"
                self._ipc_writer.write(ack.encode())
                await self._ipc_writer.drain()
            self._broadcast_dag_commit()

        elif op == "create_side_cell":
            try:
                await asyncio.to_thread(self._create_side_cell, data)
            except Exception as exc:
                self.log_buffer.append({"type": "stderr", "payload": f"[create_side_cell error] {exc}"})
            if self._ipc_writer:
                ack = json.dumps({"op": "ack_create_side_cell", "cell_id": self._last_cell_id or ""}) + "\n"
                self._ipc_writer.write(ack.encode())
                await self._ipc_writer.drain()
            self._broadcast_dag_commit()

        elif op == "request_settings_update":
            # Delegate to await_settings_update which handles the
            # broadcast / wait / clear; same helper the wasm dispatch
            # uses so the modal flow has one implementation.
            ack_body: dict = {"op": "ack_settings_update"}
            try:
                values = await self.await_settings_update(
                    settings_file_path=data.get("settings_file_path", ""),
                )
                ack_body["ok"] = True
                ack_body["values"] = values
            except Exception as exc:
                ack_body["ok"] = False
                ack_body["error"] = str(exc)
            if self._ipc_writer:
                self._ipc_writer.write((json.dumps(ack_body) + "\n").encode())
                await self._ipc_writer.drain()

        elif op == "request_key":
            # Generator asked for a secret. Delegate to await_key_value
            # which handles fast-path / broadcast / wait / clear; map
            # KeyRequestCancelled onto the ack's cancelled=True branch
            # so the SDK raises StopSignal.
            ack_body = {
                "op": "ack_request_key",
                "ok": False,
                "value": None,
                "cancelled": False,
                "error": None,
            }
            try:
                value = await self.await_key_value(
                    key_name=data.get("key_name", ""),
                    description=(data.get("description", "") or ""),
                    force=bool(data.get("force", False)),
                    attempt=int(data.get("attempt", 1) or 1),
                )
                ack_body["ok"] = True
                ack_body["value"] = value
            except KeyRequestCancelled:
                ack_body["ok"] = False
                ack_body["cancelled"] = True
            except Exception as exc:
                ack_body["ok"] = False
                ack_body["error"] = str(exc)
            if self._ipc_writer:
                self._ipc_writer.write((json.dumps(ack_body) + "\n").encode())
                await self._ipc_writer.drain()

        elif op == "chat_start_session":
            ack_body = {"op": "ack_chat_start_session"}
            try:
                cell_id = data.get("cell_id", "")
                target_id = self.placeholder_cell_id
                if not target_id or cell_id != target_id:
                    raise RuntimeError(
                        "chat ops are only allowed against the run's target cell"
                    )
                from chat_session import start_session
                result = await start_session(
                    channel_db_name=self.channel,
                    cell_id=cell_id,
                    model=data.get("model", "sonnet"),
                    system_prompt=data.get("system_prompt", "") or "",
                    backend=data.get("backend", "claude_code_session"),
                    image=data.get("image", "") or "",
                    dockerfile_dir=data.get("dockerfile_dir", "") or "",
                    shared=bool(data.get("shared", True)),
                )
                ack_body.update(result)
                ack_body["ok"] = True
            except Exception as exc:
                ack_body["ok"] = False
                ack_body["error"] = str(exc)
            if self._ipc_writer:
                self._ipc_writer.write((json.dumps(ack_body) + "\n").encode())
                await self._ipc_writer.drain()

        elif op == "chat_send_turn":
            ack_body = {"op": "ack_chat_send_turn"}
            try:
                cell_id = data.get("cell_id", "")
                target_id = self.placeholder_cell_id
                if not target_id or cell_id != target_id:
                    raise RuntimeError(
                        "chat ops are only allowed against the run's target cell"
                    )
                from chat_session import send_turn
                result = await send_turn(
                    channel_db_name=self.channel,
                    cell_id=cell_id,
                    content=data.get("content", ""),
                )
                ack_body.update(result)
                ack_body["ok"] = True
            except Exception as exc:
                ack_body["ok"] = False
                ack_body["error"] = str(exc)
            if self._ipc_writer:
                self._ipc_writer.write((json.dumps(ack_body) + "\n").encode())
                await self._ipc_writer.drain()

        elif op == "create_terminal_session":
            ack_body = {"op": "ack_create_terminal_session"}
            try:
                cell_id = data.get("cell_id", "")
                target_id = self.placeholder_cell_id
                if not target_id or cell_id != target_id:
                    raise RuntimeError(
                        "terminal ops are only allowed against the run's target cell"
                    )
                from routes.terminal import register_session
                result = register_session(
                    cell_id=cell_id,
                    container_id=data.get("container_id", "") or "",
                    command=list(data.get("command") or []),
                    cwd=data.get("cwd") or None,
                    env=data.get("env") or {},
                )
                ack_body.update(result)
                ack_body["ok"] = True
            except Exception as exc:
                ack_body["ok"] = False
                ack_body["error"] = str(exc)
            if self._ipc_writer:
                self._ipc_writer.write((json.dumps(ack_body) + "\n").encode())
                await self._ipc_writer.drain()

        elif op == "destroy_terminal_session":
            try:
                from routes.terminal import unregister_session
                unregister_session(data.get("session_id", "") or "")
            except Exception as exc:
                self.log_buffer.append({
                    "type": "stderr",
                    "payload": f"[destroy_terminal_session error] {exc}",
                })

        elif op == "poll_user_message":
            content = None
            if self._pending_user_messages:
                content = self._pending_user_messages.pop(0)
            ack_body = {"op": "ack_poll_user_message", "content": content}
            if self._ipc_writer:
                self._ipc_writer.write((json.dumps(ack_body) + "\n").encode())
                await self._ipc_writer.drain()

        elif op == "poll_renderer_action":
            action_id = None
            if self._pending_renderer_actions:
                action_id = self._pending_renderer_actions.pop(0)
            ack_body = {"op": "ack_poll_renderer_action", "action_id": action_id}
            if self._ipc_writer:
                self._ipc_writer.write((json.dumps(ack_body) + "\n").encode())
                await self._ipc_writer.drain()

        elif op == "chat_stream_event":
            from events import broadcast
            broadcast(self.channel, {
                "type": "chat_stream",
                "cell_id": data.get("cell_id", ""),
                "turn_id": data.get("turn_id", ""),
                "event": data.get("event", {}),
            })

        elif op == "finish":
            success = data.get("success", True)
            status = "completed" if success else "failed"
            error_msg = data.get("error_message", "")
            self.log_buffer.append({
                "type": "finish",
                "payload": json.dumps({"success": success, "error_message": error_msg}),
            })
            conn = get_db_connection(self.channel)
            conn.execute("UPDATE runs SET status=? WHERE id=?", (status, self.run_id))
            conn.commit()
            conn.close()
            self._broadcast_run_status(status)

        else:
            # Fall-through: SDKs newer than this API may emit opcodes
            # the backend doesn't have an explicit branch for. Persist
            # the row so the client can still consume it, but also
            # emit a dedicated ipc_error log so operators see that an
            # unrecognized op reached the bus.
            #
            # ``status`` and ``progress`` are emitted by the SDK on
            # every gen.status= / gen.progress() call and are consumed
            # by the SSE channel via the type=op row below — they're
            # fall-through *by design*, not unknown ops, so they don't
            # earn an ipc_error tag.
            if op == "port_bound":
                src = data.get("snapshot_source")
                if isinstance(src, dict):
                    self.snapshot_source = src
            elif op not in ("status", "progress"):
                self.log_buffer.append({
                    "type": "ipc_error",
                    "payload": f"unknown IPC op: {op!r} (forwarding as event anyway)",
                })
            self.log_buffer.append({"type": op, "payload": json.dumps(data)})

    def _broadcast_dag_commit(self):
        """Broadcast DAG commit + state update to SSE subscribers."""
        from events import broadcast
        broadcast(self.channel, {
            "type": "dag_commit",
            "cell_id": self._last_cell_id,
            "run_id": self.run_id,
            "generator_name": self.generator_name,
        })
        try:
            from state import state, channel_db_name, strip_large_content
            state_dict = state.model_dump(mode="json")
            stripped = strip_large_content(state_dict)
            for ch_obj in state.channels:
                if channel_db_name(ch_obj) == self.channel:
                    broadcast(self.channel, {"type": "state_update", "state": stripped})
                    break
        except Exception:
            pass

    async def _wait_and_cleanup(self):
        """Wait for the process to exit, then finalize status and clean up."""
        await self.process.wait()

        # Wait for the output streams to fully drain
        if hasattr(self, '_stdout_task'):
            await asyncio.gather(self._stdout_task, self._stderr_task, return_exceptions=True)

        # Give IPC a moment to drain any final messages
        await asyncio.sleep(0.2)

        # Wait for the microbatch writer to finish its final flush before
        # we touch the DB — otherwise _finalize_run_status races with the
        # writer's last INSERT and both hit "database is locked".
        if hasattr(self, '_writer_task'):
            await self._writer_task

        await asyncio.to_thread(self._finalize_run_status)

        # Drop any chat sandbox session this run owned. Refcount-based:
        # the sandbox container shuts down when the last session closes.
        # No silent keep-alive — when the cell stops, the container goes.
        if self.placeholder_cell_id:
            try:
                from chat_session import evict_session
                await evict_session(self.placeholder_cell_id)
            except Exception as exc:
                print(f"[process_manager] evict_session failed: {exc}")
            # Drop any terminal sessions attached to this cell. Belt-and-
            # suspenders: well-behaved generators call stop_terminal() in
            # a try/finally, but this catches leaks if they don't.
            try:
                from routes.terminal import unregister_sessions_for_cell
                unregister_sessions_for_cell(self.placeholder_cell_id)
            except Exception as exc:
                print(f"[process_manager] unregister_sessions_for_cell failed: {exc}")

        if self._ipc_server:
            self._ipc_server.close()
            await self._ipc_server.wait_closed()

        # Ensure all remaining logs are flushed after IPC server shuts down
        await asyncio.to_thread(self._flush_log_buffer)
