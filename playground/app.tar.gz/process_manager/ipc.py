"""IPC protocol — localhost TCP socket, JSON-per-line.

All ops the generator can invoke on the host run through ``_handle_ipc``.

NAK frames: when the host can't parse or process a message that the
generator may be awaiting an ack for, it sends back a one-line frame::

    {"op": "nak", "for_op": <str>, "reason": <str>}

The SDK's ``_emit_and_wait`` recognises this and raises ``IPCNakError``
so the generator can decide whether to retry, downsize, or abort. Before
this, oversize and malformed-JSON messages were silently dropped on the
host and the generator blocked forever waiting for an ack that would
never come.
"""
# pyright: reportAttributeAccessIssue=false
# (mixin: attributes like log_buffer/workspace_dir live on the composed
# ProcessManager in manager.py, not on the mixin class itself)

import asyncio
import json
import os

from database import get_db_connection


# Match the size cap the SDK uses on its outbound emit path. Anything
# larger than this on the wire is treated as a protocol error (a single
# IPC frame should never legitimately exceed 10 MB).
IPC_MAX_LINE_BYTES = 10_000_000


class KeyRequestCancelled(Exception):
    """The user pressed Cancel on the in-cell key-request modal.

    Raised by ``await_key_value`` when ``/key_continue`` fires with
    ``cancel=True``. Both the native IPC handler and the wasm dispatch
    catch this — native turns it into a ``cancelled=True`` ack so the
    SDK raises ``StopSignal``; wasm treats it as a cooperative stop.
    """

    def __init__(self, key_name: str):
        super().__init__(f"key request for {key_name!r} cancelled by user")
        self.key_name = key_name


class IPCMixin:
    async def await_settings_update(
        self,
        settings_file_path: str,
        timeout: float = 600.0,
    ) -> dict:
        """Pop the in-cell settings-update modal and block until the
        user submits.

        Single source of truth for the settings-update flow. Used by:

          * the native ``request_settings_update`` IPC handler below
          * ``WasmRunnerMixin.request_settings_update``

        Reads the schema-form file from the workspace, broadcasts a
        ``settings_update_requested`` event the frontend listens for,
        then awaits ``self._pending_settings_update`` — the
        ``/settings_continue`` endpoint sets ``_settings_update_values``
        and signals the event.

        Returns the merged values dict the user submitted. Raises
        ``RuntimeError`` on timeout or missing-file.
        """
        abs_path = os.path.join(self.workspace_dir, settings_file_path)
        if not os.path.isfile(abs_path):
            raise RuntimeError(f"settings file not found: {settings_file_path}")
        with open(abs_path, "r", encoding="utf-8") as f:
            settings_content = f.read()

        self.log_buffer.append({
            "type": "settings_update_requested",
            "payload": json.dumps({
                "run_id": self.run_id,
                "cell_id": self.placeholder_cell_id or "",
                "settings_content": settings_content,
                "settings_file_path": settings_file_path,
            }),
        })

        self._pending_settings_update = asyncio.Event()
        self._settings_update_values = None
        try:
            try:
                await asyncio.wait_for(
                    self._pending_settings_update.wait(),
                    timeout=timeout,
                )
            except asyncio.TimeoutError as exc:
                self.log_buffer.append({
                    "type": "ipc_error",
                    "payload": (
                        "settings_update timed out after 10 min — "
                        "frontend did not respond"
                    ),
                })
                raise RuntimeError("settings_update timed out") from exc
            values = self._settings_update_values or {}
        finally:
            self._pending_settings_update = None
            self._settings_update_values = None
        return dict(values)

    async def await_key_value(
        self,
        key_name: str,
        description: str = "",
        force: bool = False,
        attempt: int = 1,
        timeout: float = 600.0,
    ) -> str:
        """Resolve a user-held secret, prompting via the in-cell modal
        if needed.

        Single source of truth for the key-request flow. Used by:

          * the native ``request_key`` IPC handler below
          * the wasm dispatch (``WasmRunnerMixin.request_key``)

        Fast path: returns ``os.environ[key_name]`` when set and
        ``force=False``. Slow path: broadcasts a ``key_requested`` event
        on ``log_buffer`` (which the SSE channel surfaces to the
        ``KeyRequestOverlay``), then awaits ``self._pending_key_request``
        — the ``/key_continue`` endpoint sets ``_key_request_value`` /
        ``_key_request_cancelled`` and signals the event.

        Raises ``KeyRequestCancelled`` if the user cancelled, or
        ``RuntimeError`` on timeout / blank submission.
        """
        if not key_name or not isinstance(key_name, str):
            raise RuntimeError("await_key_value requires a non-empty key_name")

        if not force:
            existing = (os.environ.get(key_name) or "").strip()
            if existing:
                return existing

        self.log_buffer.append({
            "type": "key_requested",
            "payload": json.dumps({
                "run_id": self.run_id,
                "cell_id": self.placeholder_cell_id or "",
                "key_name": key_name,
                "description": description,
                "attempt": attempt,
            }),
        })

        self._pending_key_request = asyncio.Event()
        self._key_request_value = None
        self._key_request_cancelled = False
        try:
            try:
                await asyncio.wait_for(
                    self._pending_key_request.wait(),
                    timeout=timeout,
                )
            except asyncio.TimeoutError as exc:
                self.log_buffer.append({
                    "type": "ipc_error",
                    "payload": (
                        f"key_request for {key_name!r} timed out "
                        f"after {int(timeout)}s — user did not respond"
                    ),
                })
                raise RuntimeError(
                    f"key_request for {key_name!r} timed out"
                ) from exc
            cancelled = self._key_request_cancelled
            value = self._key_request_value
        finally:
            self._pending_key_request = None
            self._key_request_value = None
            self._key_request_cancelled = False

        if cancelled:
            raise KeyRequestCancelled(key_name)
        val = (value or "").strip()
        if not val:
            # /key_continue should have rejected this; belt-and-suspenders.
            raise RuntimeError(
                "key_request returned empty value — "
                "/key_continue accepted a blank submission"
            )
        return val

    async def _send_nak(self, for_op: str, reason: str) -> None:
        """Write a NAK frame to the IPC channel.

        Failing to write (writer torn down mid-handshake) is logged but
        not raised — there's nothing useful to do once the channel is
        gone, and the SDK will see EOF and surface its own error.
        """
        if self._ipc_writer is None:
            return
        try:
            frame = json.dumps({"op": "nak", "for_op": for_op, "reason": reason}) + "\n"
            self._ipc_writer.write(frame.encode())
            await self._ipc_writer.drain()
        except Exception as exc:
            self.log_buffer.append({
                "type": "stderr",
                "payload": f"[IPC] failed to send NAK ({reason!r} for {for_op!r}): {exc}",
            })

    async def _handle_ipc_connection(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        """Handle the generator's TCP connection for IPC messages."""
        self._ipc_writer = writer
        try:
            while True:
                try:
                    line = await reader.readline()
                except ValueError:
                    # Line exceeded the StreamReader limit (raised as
                    # ValueError, wrapping LimitOverrunError). The stream
                    # is mid-frame and can't be resynced — NAK and drop
                    # the connection rather than keep buffering.
                    self.log_buffer.append({
                        "type": "ipc_error",
                        "payload": f"oversize: line exceeds {IPC_MAX_LINE_BYTES} bytes",
                    })
                    await self._send_nak("unknown", "oversize")
                    break
                if not line:
                    break
                if len(line) > IPC_MAX_LINE_BYTES:
                    # Belt-and-suspenders behind the reader limit; close
                    # rather than keep reading from a peer that ignores
                    # the frame cap.
                    self.log_buffer.append({
                        "type": "ipc_error",
                        "payload": f"oversize: {len(line)} bytes > {IPC_MAX_LINE_BYTES}",
                    })
                    await self._send_nak("unknown", "oversize")
                    break
                await self._handle_ipc(line.decode("utf-8", errors="replace").strip())
        except Exception as e:
            self.log_buffer.append({"type": "stderr", "payload": f"[IPC Error] {e}"})
        finally:
            writer.close()
            await writer.wait_closed()
            self._ipc_writer = None

    # ------------------------------------------------------------------
    # IPC dispatch
    #
    # Three categories of ops, dispatched via a single name → handler
    # table built once in ``_handle_ipc`` and consulted per message:
    #
    # **Core** — the 7-method Host protocol. update_cell + create_side_cell
    # + request_key + poll_user_message reach this manager from both
    # native (over TCP-JSON) and WASM (in-process via HostMixin); the
    # IPC handler dispatches to the same HostMixin methods the wasm
    # runner uses, so cell-write semantics, log buffering, key/message
    # poll behavior are identical across runtimes.
    #
    # **Tier B** — native-only operations (terminals, ports, subprocess
    # streaming, mid-run settings modal, renderer action polling,
    # snapshot diffing, daemon-backed sandbox chats, streaming text-
    # delta side-channel). No protocol contract — each op has its own
    # bespoke shape.
    #
    # **Lifecycle** — finish; called once per run on the way out.
    #
    # Anything else is a fall-through (SDKs newer than this backend
    # may emit ops we don't know about) — the row is persisted so the
    # client can consume it but tagged with ipc_error in logs.
    # ------------------------------------------------------------------

    async def _handle_ipc(self, line: str):
        """Process a single IPC JSON message."""
        if not line:
            return
        try:
            data = json.loads(line)
        except json.JSONDecodeError as exc:
            # Truncate the bad payload in the log to avoid drowning the
            # ipc_error stream when a generator emits a few MB of garbage.
            preview = line[:200] + ("…" if len(line) > 200 else "")
            self.log_buffer.append({
                "type": "ipc_error",
                "payload": f"JSON decode error: {exc.msg}; preview: {preview!r}",
            })
            await self._send_nak("unknown", f"json_decode_error: {exc.msg}")
            return

        op = data.get("op")
        handler = self._ipc_handlers.get(op) if op else None
        if handler is None:
            await self._op_unknown(data)
            return
        await handler(data)

    @property
    def _ipc_handlers(self):
        """Lazy-built op → handler table. Cached on the instance after
        first build so dispatch is O(1) per message."""
        cached = getattr(self, "_ipc_handlers_cache", None)
        if cached is not None:
            return cached
        cached = {
            # Core (Host protocol)
            "update_cell": self._op_update_cell,
            "create_side_cell": self._op_create_side_cell,
            "request_key": self._op_request_key,
            # Tier B (native-only)
            "request_settings_update": self._op_request_settings_update,
            "create_terminal_session": self._op_create_terminal_session,
            "destroy_terminal_session": self._op_destroy_terminal_session,
            "poll_renderer_action": self._op_poll_renderer_action,
            # Live chat (renderer-served streaming chat)
            "chat_register": self._op_chat_register,
            "chat_poll": self._op_chat_poll,
            "stream_event": self._op_stream_event,
            # Composition + renderer compile (host-backed gen.* capabilities)
            "list_generators": self._op_list_generators,
            "start_sub_run": self._op_start_sub_run,
            "sub_run_endpoints": self._op_sub_run_endpoints,
            "sub_run_status": self._op_sub_run_status,
            "sub_run_files": self._op_sub_run_files,
            "sub_run_wait": self._op_sub_run_wait,
            "stop_sub_run": self._op_stop_sub_run,
            "surface_sub_run": self._op_surface_sub_run,
            "check_renderer": self._op_check_renderer,
            # Environments — capabilities, workspace plane, execution plane,
            # and the env-author serve channel.
            "sub_run_capabilities": self._op_sub_run_capabilities,
            "sub_run_exec": self._op_sub_run_exec,
            "sub_run_exec_background": self._op_sub_run_exec_background,
            "sub_run_wait_process": self._op_sub_run_wait_process,
            "sub_run_stop_process": self._op_sub_run_stop_process,
            "sub_run_expose_port": self._op_sub_run_expose_port,
            "sub_run_open_terminal": self._op_sub_run_open_terminal,
            "sub_run_put_files": self._op_sub_run_put_files,
            "sub_run_read_file": self._op_sub_run_read_file,
            "sub_run_delete_file": self._op_sub_run_delete_file,
            "sub_run_list_files": self._op_sub_run_list_files,
            "sub_run_snapshot": self._op_sub_run_snapshot,
            "serve_environment_register": self._op_serve_environment_register,
            "serve_environment_poll": self._op_serve_environment_poll,
            "serve_environment_reply": self._op_serve_environment_reply,
            # Lifecycle
            "finish": self._op_finish,
        }
        self._ipc_handlers_cache = cached
        return cached

    async def _send_ack(self, ack_body: dict) -> None:
        """Write an ack frame back to the IPC writer. No-op if the
        writer was torn down (e.g. process died mid-handle)."""
        if self._ipc_writer is None:
            return
        self._ipc_writer.write((json.dumps(ack_body) + "\n").encode())
        await self._ipc_writer.drain()

    # ------------------------------------------------------------------
    # Core ops (Host protocol)
    # ------------------------------------------------------------------

    async def _op_update_cell(self, data: dict) -> None:
        """Dispatch through the shared HostMixin emit_partial path so
        the native IPC handler and the WASM runner share a single
        artifact-build → merge → broadcast sequence. ``initial=True``
        on the first emit picks the in-place upsert path; subsequent
        emits create a new version row + cell_edges ``previous_version``
        edge so the version scrubber records each turn as a checkpoint.
        """
        initial = bool(data.get("initial", False))
        meta = data.get("metadata") or {}
        try:
            await asyncio.to_thread(
                self._emit_partial_core,
                artifacts=data.get("artifacts") or [],
                cell_name=data.get("name"),
                summary=data.get("summary"),
                pinned=meta.get("pinned"),
                deleted_files=data.get("deleted_files"),
                version=not initial,
            )
        except Exception as exc:
            self.log_buffer.append({
                "type": "stderr",
                "payload": f"[update_cell error] {exc}",
            })
        await self._send_ack({
            "op": "ack_update", "cell_id": self._last_cell_id or "",
        })
        # _emit_partial_core already broadcasts dag_commit; this is the
        # belt for the (rare) case where to_thread raised before
        # reaching the broadcast — keeps the SSE beat alive on partial
        # failures.
        self._broadcast_dag_commit()

    async def _op_create_side_cell(self, data: dict) -> None:
        try:
            await asyncio.to_thread(self._create_side_cell, data)
        except Exception as exc:
            self.log_buffer.append({
                "type": "stderr",
                "payload": f"[create_side_cell error] {exc}",
            })
        await self._send_ack({
            "op": "ack_create_side_cell", "cell_id": self._last_cell_id or "",
        })
        self._broadcast_dag_commit()

    async def _op_request_key(self, data: dict) -> None:
        """Generator asked for a secret. Delegate to await_key_value
        which handles fast-path / broadcast / wait / clear; map
        KeyRequestCancelled onto the ack's cancelled=True branch so
        the SDK raises StopSignal."""
        ack_body = {
            "op": "ack_request_key",
            "ok": False,
            "value": None,
            "cancelled": False,
            "error": None,
        }
        try:
            value = await self.await_key_value(
                key_name=data.get("key_name", ""),
                description=(data.get("description", "") or ""),
                force=bool(data.get("force", False)),
                attempt=int(data.get("attempt", 1) or 1),
            )
            ack_body["ok"] = True
            ack_body["value"] = value
        except KeyRequestCancelled:
            ack_body["ok"] = False
            ack_body["cancelled"] = True
        except Exception as exc:
            ack_body["ok"] = False
            ack_body["error"] = str(exc)
        await self._send_ack(ack_body)

    # ------------------------------------------------------------------
    # Tier B ops (native-only)
    # ------------------------------------------------------------------

    async def _op_request_settings_update(self, data: dict) -> None:
        """Mid-run settings modal. await_settings_update broadcasts +
        waits for /settings_continue + clears the asyncio.Event."""
        ack_body: dict = {"op": "ack_settings_update"}
        try:
            values = await self.await_settings_update(
                settings_file_path=data.get("settings_file_path", ""),
            )
            ack_body["ok"] = True
            ack_body["values"] = values
        except Exception as exc:
            ack_body["ok"] = False
            ack_body["error"] = str(exc)
        await self._send_ack(ack_body)

    async def _op_chat_register(self, data: dict) -> None:
        """Allocate a live chat session for the run's target cell and return
        its ``{session_id, ws_path, token}`` for the generator's ``.chatlive``
        pointer. The chat renderer opens a WebSocket against ``ws_path``."""
        ack_body: dict = {"op": "ack_chat_register"}
        try:
            cell_id = data.get("cell_id", "")
            target_id = self.placeholder_cell_id
            if not target_id or cell_id != target_id:
                raise RuntimeError(
                    "chat ops are only allowed against the run's target cell"
                )
            from routes.chat_live import register_chat_session
            result = register_chat_session(cell_id=cell_id, run_id=self.run_id)
            ack_body.update(result)
            ack_body["ok"] = True
        except Exception as exc:
            ack_body["ok"] = False
            ack_body["error"] = str(exc)
        await self._send_ack(ack_body)

    async def _op_chat_poll(self, data: dict) -> None:
        """Non-blocking pop of the next inbound renderer command (user_msg /
        interrupt / redirect) for the run's chat session.

        Before handing the generator a turn-triggering message, flush the
        user's pending Files-tab edits into the workspace + version chain so
        the agent reads them on this turn. This is the generic equivalent of
        the old ``/chat/push_message`` draft flush — it makes mid-chat file
        edits visible to the next turn for any chat generator."""
        command = None
        try:
            from routes.chat_live import pop_command
            command = pop_command(self.placeholder_cell_id or "")
        except Exception:
            command = None
        if command and command.get("kind") in ("user_msg", "redirect"):
            try:
                await asyncio.to_thread(self._flush_chat_drafts_to_workspace)
            except Exception as exc:
                self.log_buffer.append({
                    "type": "stderr",
                    "payload": f"[chat draft flush] {exc}",
                })
        await self._send_ack({"op": "ack_chat_poll", "command": command})

    def _flush_chat_drafts_to_workspace(self) -> None:
        """Write the cell's pending Files-tab drafts into the generator's
        workspace and promote them into a 'Human Edit' version, so a mid-chat
        file edit is visible to the agent on the next turn. Sync (sqlite +
        filesystem) — call via ``asyncio.to_thread``."""
        cell_id = self.placeholder_cell_id
        workspace = getattr(self, "workspace_dir", None)
        if not cell_id or not workspace:
            return
        import shutil
        from routes.runs import _promote_drafts_to_version
        conn = get_db_connection(self.channel)
        try:
            drafts = conn.execute(
                "SELECT filepath, content_text, blob_hash FROM cell_drafts WHERE cell_id=?",
                (cell_id,),
            ).fetchall()
            if not drafts:
                return
            for draft in drafts:
                dst = os.path.join(workspace, draft["filepath"])
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                draft_blob = draft["blob_hash"]
                if draft_blob:
                    # Binary draft — copy the CAS bytes verbatim so the agent
                    # sees the real file on disk (text-encoding corrupts it).
                    cas_path = os.path.join(".collimate", "objects", draft_blob[:2], draft_blob[2:])
                    if os.path.exists(cas_path):
                        shutil.copy2(cas_path, dst)
                    continue
                with open(dst, "w", encoding="utf-8") as f:
                    f.write(draft["content_text"] or "")
            # Seed the genesis row's cell_files from state.json when versioning
            # this cell for the first time, else unchanged files would vanish.
            current_files = None
            try:
                from state import state as _state, channel_db_name as _cdn
                for ch in _state.channels:
                    if _cdn(ch) != self.channel:
                        continue
                    for stk in [*ch.main_stacks, *ch.nav_stacks]:
                        for c in stk.cells:
                            if str(c.id) == cell_id:
                                current_files = [
                                    {"filepath": f.name, "content": f.content, "blob_hash": f.blob_hash}
                                    for f in c.files
                                ]
                                break
                        if current_files is not None:
                            break
                    break
            except Exception:
                current_files = None
            _promote_drafts_to_version(
                conn, cell_id, self.run_id, current_files=current_files,
            )
            conn.commit()
        finally:
            try:
                conn.close()
            except Exception:
                pass

    async def _op_create_terminal_session(self, data: dict) -> None:
        ack_body: dict = {"op": "ack_create_terminal_session"}
        try:
            cell_id = data.get("cell_id", "")
            target_id = self.placeholder_cell_id
            if not target_id or cell_id != target_id:
                raise RuntimeError(
                    "terminal ops are only allowed against the run's target cell"
                )
            from routes.terminal import register_session
            result = register_session(
                cell_id=cell_id,
                container_id=data.get("container_id", "") or "",
                command=list(data.get("command") or []),
                cwd=data.get("cwd") or None,
                env=data.get("env") or {},
            )
            ack_body.update(result)
            ack_body["ok"] = True
        except Exception as exc:
            ack_body["ok"] = False
            ack_body["error"] = str(exc)
        await self._send_ack(ack_body)

    async def _op_destroy_terminal_session(self, data: dict) -> None:
        try:
            from routes.terminal import unregister_session
            unregister_session(data.get("session_id", "") or "")
        except Exception as exc:
            self.log_buffer.append({
                "type": "stderr",
                "payload": f"[destroy_terminal_session error] {exc}",
            })

    async def _op_poll_renderer_action(self, data: dict) -> None:
        action_id = None
        if self._pending_renderer_actions:
            action_id = self._pending_renderer_actions.pop(0)
        await self._send_ack({
            "op": "ack_poll_renderer_action", "action_id": action_id,
        })

    async def _op_stream_event(self, data: dict) -> None:
        """Streaming turn_start / text_delta / tool / turn_end / error events
        from the generator. Fire-and-forget — no ack. Routed to the cell's
        live chat session, which forwards them over the renderer WebSocket.
        Canonical text lives in the cell's ``.chatlog``; these deltas are the
        live overlay."""
        from routes.chat_live import push_event
        push_event(
            data.get("cell_id", "") or self.placeholder_cell_id or "",
            data.get("turn_id", ""),
            data.get("event", {}),
        )

    # ------------------------------------------------------------------
    # Composition + renderer compile (host-backed gen.* capabilities)
    #
    # Implemented in process_manager/sub_runs.py. Child runs are
    # parent-bound: stopped in _wait_and_cleanup when this run ends.
    # ------------------------------------------------------------------

    async def _op_list_generators(self, data: dict) -> None:
        from process_manager.sub_runs import list_installed_generators
        gens = await asyncio.to_thread(list_installed_generators, self.channel)
        await self._send_ack({"op": "ack_list_generators", "generators": gens})

    async def _op_start_sub_run(self, data: dict) -> None:
        from process_manager.sub_runs import spawn_sub_run
        await self._send_ack(await spawn_sub_run(self, data))

    async def _op_sub_run_wait(self, data: dict) -> None:
        from process_manager.sub_runs import wait_sub_run
        await self._send_ack(await wait_sub_run(self, data))

    async def _op_sub_run_endpoints(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_endpoints
        await self._send_ack(sub_run_endpoints(self, data))

    async def _op_sub_run_status(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_status
        await self._send_ack(await asyncio.to_thread(sub_run_status, self, data))

    async def _op_sub_run_files(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_files
        await self._send_ack(await asyncio.to_thread(sub_run_files, self, data))

    async def _op_stop_sub_run(self, data: dict) -> None:
        # Fire-and-forget (SDK uses emit, not emit_and_wait) — no ack.
        from process_manager.sub_runs import stop_sub_run
        await stop_sub_run(self, data)

    async def _op_surface_sub_run(self, data: dict) -> None:
        from process_manager.sub_runs import surface_sub_run
        await self._send_ack(await surface_sub_run(self, data))

    async def _op_check_renderer(self, data: dict) -> None:
        from process_manager.sub_runs import check_renderer_files
        ack = await check_renderer_files(
            data.get("files") or {}, data.get("entrypoint") or "main.tsx",
        )
        ack["op"] = "ack_check_renderer"
        await self._send_ack(ack)

    # ------------------------------------------------------------------
    # Environments
    # ------------------------------------------------------------------

    async def _op_sub_run_capabilities(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_capabilities
        await self._send_ack(sub_run_capabilities(self, data))

    async def _op_sub_run_exec(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_route
        await self._send_ack(await sub_run_route(self, data, "exec", "ack_sub_run_exec"))

    async def _op_sub_run_exec_background(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_route
        await self._send_ack(await sub_run_route(self, data, "exec_background", "ack_sub_run_exec_background"))

    async def _op_sub_run_wait_process(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_route
        await self._send_ack(await sub_run_route(self, data, "wait_process", "ack_sub_run_wait_process"))

    async def _op_sub_run_stop_process(self, data: dict) -> None:
        # Fire-and-forget (SDK emits, no wait).
        from process_manager.sub_runs import sub_run_route_oneway
        await sub_run_route_oneway(self, data, "stop_process")

    async def _op_sub_run_expose_port(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_route
        await self._send_ack(await sub_run_route(self, data, "expose_port", "ack_sub_run_expose_port"))

    async def _op_sub_run_open_terminal(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_route
        await self._send_ack(await sub_run_route(self, data, "open_terminal", "ack_sub_run_open_terminal"))

    async def _op_sub_run_put_files(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_put_files
        await self._send_ack(await asyncio.to_thread(sub_run_put_files, self, data))

    async def _op_sub_run_read_file(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_read_file
        await self._send_ack(await asyncio.to_thread(sub_run_read_file, self, data))

    async def _op_sub_run_delete_file(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_delete_file
        await self._send_ack(await asyncio.to_thread(sub_run_delete_file, self, data))

    async def _op_sub_run_list_files(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_list_files
        await self._send_ack(await asyncio.to_thread(sub_run_list_files, self, data))

    async def _op_sub_run_snapshot(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_snapshot
        await self._send_ack(await asyncio.to_thread(sub_run_snapshot, self, data))

    async def _op_serve_environment_register(self, data: dict) -> None:
        from process_manager.sub_runs import serve_environment_register
        await self._send_ack(serve_environment_register(self, data))

    async def _op_serve_environment_poll(self, data: dict) -> None:
        from process_manager.sub_runs import serve_environment_poll
        await self._send_ack(await serve_environment_poll(self, data))

    async def _op_serve_environment_reply(self, data: dict) -> None:
        # Fire-and-forget (SDK emits the reply); resolves the parent's future.
        from process_manager.sub_runs import serve_environment_reply
        serve_environment_reply(self, data)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def _op_finish(self, data: dict) -> None:
        """Generator's clean shutdown signal. Marks the run row +
        broadcasts the terminal status. Run exit without finish (e.g.
        SIGKILL) is handled by _wait_and_cleanup → _finalize_run_status."""
        success = data.get("success", True)
        status = "completed" if success else "failed"
        error_msg = data.get("error_message", "")
        self.log_buffer.append({
            "type": "finish",
            "payload": json.dumps({"success": success, "error_message": error_msg}),
        })
        conn = get_db_connection(self.channel)
        conn.execute("UPDATE runs SET status=? WHERE id=?", (status, self.run_id))
        conn.commit()
        conn.close()
        self._broadcast_run_status(status)

    # ------------------------------------------------------------------
    # Fall-through (unknown ops)
    # ------------------------------------------------------------------

    async def _op_unknown(self, data: dict) -> None:
        """Forward unrecognized ops as event-bus rows so a newer SDK
        emitting ops this backend doesn't know about doesn't drop them
        on the floor — they appear in the run-events panel and the
        client can consume them. ``status`` and ``progress`` are
        fall-through *by design* (SDK convenience APIs that the SSE
        channel handles via the type=op row below) so they skip the
        ipc_error tag.

        ``port_bound`` carries the snapshot_source block — capture it
        on the manager so the snapshot endpoint can pull files out
        of the running container later.
        """
        op = data.get("op")
        if op == "port_bound":
            src = data.get("snapshot_source")
            if isinstance(src, dict):
                self.snapshot_source = src
            # Record the bound port so the reverse proxy can verify this
            # run actually owns it before forwarding (see manager.bound_ports).
            port_val = data.get("port")
            if port_val is not None:
                try:
                    self.bound_ports.add(int(port_val))
                except (TypeError, ValueError):
                    pass
        elif op not in ("status", "progress"):
            self.log_buffer.append({
                "type": "ipc_error",
                "payload": f"unknown IPC op: {op!r} (forwarding as event anyway)",
            })
        self.log_buffer.append({"type": op or "unknown", "payload": json.dumps(data)})

    def _broadcast_dag_commit(self):
        """Broadcast DAG commit + state update to SSE subscribers."""
        from events import broadcast
        broadcast(self.channel, {
            "type": "dag_commit",
            "cell_id": self._last_cell_id,
            "run_id": self.run_id,
            "generator_name": self.generator_name,
        })
        try:
            from state import state, channel_db_name, strip_large_content
            state_dict = state.model_dump(mode="json")
            stripped = strip_large_content(state_dict)
            for ch_obj in state.channels:
                if channel_db_name(ch_obj) == self.channel:
                    broadcast(self.channel, {"type": "state_update", "state": stripped})
                    break
        except Exception:
            pass

    async def _wait_and_cleanup(self):
        """Wait for the process to exit, then finalize status and clean up.

        Cleanup runs in a ``try/finally`` so the chat-session + terminal-
        session unregister + IPC server close + log flush always execute on
        the way out, even if ``_finalize_run_status`` or one of the upstream
        awaits raises. With the finally, every run-end path — clean exit,
        SIGTERM, SIGKILL, finalize crash — reaches the unregister, so a
        WebSocket (chat or terminal) can't outlive its generator.
        """
        await self.process.wait()

        try:
            # Wait for the output streams to fully drain
            if hasattr(self, '_stdout_task'):
                await asyncio.gather(self._stdout_task, self._stderr_task, return_exceptions=True)

            # Give IPC a moment to drain any final messages
            await asyncio.sleep(0.2)

            # Wait for the microbatch writer to finish its final flush before
            # we touch the DB — otherwise _finalize_run_status races with the
            # writer's last INSERT and both hit "database is locked".
            if hasattr(self, '_writer_task'):
                await self._writer_task

            await asyncio.to_thread(self._finalize_run_status)
        finally:
            # ---------------------------------------------------------
            # Always-run cleanup. Each step independently wrapped in
            # try/except so one failure can't cascade and skip the
            # next.
            # ---------------------------------------------------------

            # Tear down any live chat session this run served. The
            # WebSocket closes, and the chat renderer falls back to the
            # read-only .chatlog transcript.
            if self.placeholder_cell_id:
                try:
                    from routes.chat_live import unregister_chat_sessions_for_cell
                    unregister_chat_sessions_for_cell(self.placeholder_cell_id)
                except Exception as exc:
                    print(f"[process_manager] unregister_chat_sessions_for_cell failed: {exc}")

                # Drop any terminal sessions attached to this cell.
                # Belt-and-suspenders: well-behaved generators call
                # stop_terminal() in their own try/finally, but this
                # catches leaks if they don't.
                try:
                    from routes.terminal import unregister_sessions_for_cell
                    unregister_sessions_for_cell(self.placeholder_cell_id)
                except Exception as exc:
                    print(f"[process_manager] unregister_sessions_for_cell failed: {exc}")

            # Parent-bound composition: stop every sub-run this run spawned,
            # so a forgotten child (esp. a daemon) can't leak past the parent.
            if getattr(self, "_sub_runs", None):
                try:
                    from process_manager.sub_runs import stop_all_sub_runs
                    await stop_all_sub_runs(self)
                except Exception as exc:
                    print(f"[process_manager] stop_all_sub_runs failed: {exc}")

            if self._ipc_server:
                try:
                    self._ipc_server.close()
                    await self._ipc_server.wait_closed()
                except Exception as exc:
                    print(f"[process_manager] _ipc_server.close failed: {exc}")

            # Ensure all remaining logs are flushed after IPC server shuts down
            try:
                await asyncio.to_thread(self._flush_log_buffer)
            except Exception as exc:
                print(f"[process_manager] _flush_log_buffer failed: {exc}")
