"""IPC protocol — localhost TCP socket, JSON-per-line.

All ops the generator can invoke on the host run through ``_handle_ipc``.

NAK frames: when the host can't parse or process a message that the
generator may be awaiting an ack for, it sends back a one-line frame::

    {"op": "nak", "for_op": <str>, "reason": <str>}

The SDK's ``_emit_and_wait`` recognises this and raises ``IPCNakError``
so the generator can decide whether to retry, downsize, or abort. Before
this, oversize and malformed-JSON messages were silently dropped on the
host and the generator blocked forever waiting for an ack that would
never come.
"""
# pyright: reportAttributeAccessIssue=false
# (mixin: attributes like log_buffer/workspace_dir live on the composed
# ProcessManager in manager.py, not on the mixin class itself)

import asyncio
import json
import os

from database import get_db_connection


# Match the size cap the SDK uses on its outbound emit path. Anything
# larger than this on the wire is treated as a protocol error (a single
# IPC frame should never legitimately exceed 10 MB).
IPC_MAX_LINE_BYTES = 10_000_000


class KeyRequestCancelled(Exception):
    """The user pressed Cancel on the in-cell key-request modal.

    Raised by ``await_key_value`` when ``/key_continue`` fires with
    ``cancel=True``. Both the native IPC handler and the wasm dispatch
    catch this — native turns it into a ``cancelled=True`` ack so the
    SDK raises ``StopSignal``; wasm treats it as a cooperative stop.
    """

    def __init__(self, key_name: str):
        super().__init__(f"key request for {key_name!r} cancelled by user")
        self.key_name = key_name


class IPCMixin:
    async def await_settings_update(
        self,
        settings_file_path: str,
        timeout: float = 600.0,
    ) -> dict:
        """Pop the in-cell settings-update modal and block until the
        user submits.

        Single source of truth for the settings-update flow. Used by:

          * the native ``request_settings_update`` IPC handler below
          * ``WasmRunnerMixin.request_settings_update``

        Reads the schema-form file from the workspace, broadcasts a
        ``settings_update_requested`` event the frontend listens for,
        then awaits ``self._pending_settings_update`` — the
        ``/settings_continue`` endpoint sets ``_settings_update_values``
        and signals the event.

        Returns the merged values dict the user submitted. Raises
        ``RuntimeError`` on timeout or missing-file.
        """
        abs_path = os.path.join(self.workspace_dir, settings_file_path)
        if not os.path.isfile(abs_path):
            raise RuntimeError(f"settings file not found: {settings_file_path}")
        with open(abs_path, "r", encoding="utf-8") as f:
            settings_content = f.read()

        self.log_buffer.append({
            "type": "settings_update_requested",
            "payload": json.dumps({
                "run_id": self.run_id,
                "cell_id": self.placeholder_cell_id or "",
                "settings_content": settings_content,
                "settings_file_path": settings_file_path,
            }),
        })

        self._pending_settings_update = asyncio.Event()
        self._settings_update_values = None
        try:
            try:
                await asyncio.wait_for(
                    self._pending_settings_update.wait(),
                    timeout=timeout,
                )
            except asyncio.TimeoutError as exc:
                self.log_buffer.append({
                    "type": "ipc_error",
                    "payload": (
                        "settings_update timed out after 10 min — "
                        "frontend did not respond"
                    ),
                })
                raise RuntimeError("settings_update timed out") from exc
            values = self._settings_update_values or {}
        finally:
            self._pending_settings_update = None
            self._settings_update_values = None
        return dict(values)

    async def await_key_value(
        self,
        key_name: str,
        description: str = "",
        force: bool = False,
        attempt: int = 1,
        timeout: float = 600.0,
    ) -> str:
        """Resolve a user-held secret, prompting via the in-cell modal
        if needed.

        Single source of truth for the key-request flow. Used by:

          * the native ``request_key`` IPC handler below
          * the wasm dispatch (``WasmRunnerMixin.request_key``)

        Fast path: returns ``os.environ[key_name]`` when set and
        ``force=False``. Slow path: broadcasts a ``key_requested`` event
        on ``log_buffer`` (which the SSE channel surfaces to the
        ``KeyRequestOverlay``), then awaits ``self._pending_key_request``
        — the ``/key_continue`` endpoint sets ``_key_request_value`` /
        ``_key_request_cancelled`` and signals the event.

        Raises ``KeyRequestCancelled`` if the user cancelled, or
        ``RuntimeError`` on timeout / blank submission.
        """
        if not key_name or not isinstance(key_name, str):
            raise RuntimeError("await_key_value requires a non-empty key_name")

        if not force:
            existing = (os.environ.get(key_name) or "").strip()
            if existing:
                return existing

        self.log_buffer.append({
            "type": "key_requested",
            "payload": json.dumps({
                "run_id": self.run_id,
                "cell_id": self.placeholder_cell_id or "",
                "key_name": key_name,
                "description": description,
                "attempt": attempt,
            }),
        })

        self._pending_key_request = asyncio.Event()
        self._key_request_value = None
        self._key_request_cancelled = False
        try:
            try:
                await asyncio.wait_for(
                    self._pending_key_request.wait(),
                    timeout=timeout,
                )
            except asyncio.TimeoutError as exc:
                self.log_buffer.append({
                    "type": "ipc_error",
                    "payload": (
                        f"key_request for {key_name!r} timed out "
                        f"after {int(timeout)}s — user did not respond"
                    ),
                })
                raise RuntimeError(
                    f"key_request for {key_name!r} timed out"
                ) from exc
            cancelled = self._key_request_cancelled
            value = self._key_request_value
        finally:
            self._pending_key_request = None
            self._key_request_value = None
            self._key_request_cancelled = False

        if cancelled:
            raise KeyRequestCancelled(key_name)
        val = (value or "").strip()
        if not val:
            # /key_continue should have rejected this; belt-and-suspenders.
            raise RuntimeError(
                "key_request returned empty value — "
                "/key_continue accepted a blank submission"
            )
        return val

    async def _send_nak(self, for_op: str, reason: str) -> None:
        """Write a NAK frame to the IPC channel.

        Failing to write (writer torn down mid-handshake) is logged but
        not raised — there's nothing useful to do once the channel is
        gone, and the SDK will see EOF and surface its own error.
        """
        if self._ipc_writer is None:
            return
        try:
            frame = json.dumps({"op": "nak", "for_op": for_op, "reason": reason}) + "\n"
            self._ipc_writer.write(frame.encode())
            await self._ipc_writer.drain()
        except Exception as exc:
            self.log_buffer.append({
                "type": "stderr",
                "payload": f"[IPC] failed to send NAK ({reason!r} for {for_op!r}): {exc}",
            })

    async def _handle_ipc_connection(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        """Handle the generator's TCP connection for IPC messages."""
        self._ipc_writer = writer
        try:
            while True:
                try:
                    line = await reader.readline()
                except ValueError:
                    # Line exceeded the StreamReader limit (raised as
                    # ValueError, wrapping LimitOverrunError). The stream
                    # is mid-frame and can't be resynced — NAK and drop
                    # the connection rather than keep buffering.
                    self.log_buffer.append({
                        "type": "ipc_error",
                        "payload": f"oversize: line exceeds {IPC_MAX_LINE_BYTES} bytes",
                    })
                    await self._send_nak("unknown", "oversize")
                    break
                if not line:
                    break
                if len(line) > IPC_MAX_LINE_BYTES:
                    # Belt-and-suspenders behind the reader limit; close
                    # rather than keep reading from a peer that ignores
                    # the frame cap.
                    self.log_buffer.append({
                        "type": "ipc_error",
                        "payload": f"oversize: {len(line)} bytes > {IPC_MAX_LINE_BYTES}",
                    })
                    await self._send_nak("unknown", "oversize")
                    break
                await self._handle_ipc(line.decode("utf-8", errors="replace").strip())
        except Exception as e:
            self.log_buffer.append({"type": "stderr", "payload": f"[IPC Error] {e}"})
        finally:
            writer.close()
            await writer.wait_closed()
            self._ipc_writer = None

    # ------------------------------------------------------------------
    # IPC dispatch
    #
    # Three categories of ops, dispatched via a single name → handler
    # table built once in ``_handle_ipc`` and consulted per message:
    #
    # **Core** — the 7-method Host protocol. update_cell + create_side_cell
    # + request_key + poll_user_message reach this manager from both
    # native (over TCP-JSON) and WASM (in-process via HostMixin); the
    # IPC handler dispatches to the same HostMixin methods the wasm
    # runner uses, so cell-write semantics, log buffering, key/message
    # poll behavior are identical across runtimes.
    #
    # **Tier B** — native-only operations (terminals, ports, subprocess
    # streaming, mid-run settings modal, renderer action polling,
    # snapshot diffing, daemon-backed sandbox chats, streaming text-
    # delta side-channel). No protocol contract — each op has its own
    # bespoke shape.
    #
    # **Lifecycle** — finish; called once per run on the way out.
    #
    # Anything else is a fall-through (SDKs newer than this backend
    # may emit ops we don't know about) — the row is persisted so the
    # client can consume it but tagged with ipc_error in logs.
    # ------------------------------------------------------------------

    async def _handle_ipc(self, line: str):
        """Process a single IPC JSON message."""
        if not line:
            return
        try:
            data = json.loads(line)
        except json.JSONDecodeError as exc:
            # Truncate the bad payload in the log to avoid drowning the
            # ipc_error stream when a generator emits a few MB of garbage.
            preview = line[:200] + ("…" if len(line) > 200 else "")
            self.log_buffer.append({
                "type": "ipc_error",
                "payload": f"JSON decode error: {exc.msg}; preview: {preview!r}",
            })
            await self._send_nak("unknown", f"json_decode_error: {exc.msg}")
            return

        op = data.get("op")
        handler = self._ipc_handlers.get(op) if op else None
        if handler is None:
            await self._op_unknown(data)
            return
        await handler(data)

    @property
    def _ipc_handlers(self):
        """Lazy-built op → handler table. Cached on the instance after
        first build so dispatch is O(1) per message."""
        cached = getattr(self, "_ipc_handlers_cache", None)
        if cached is not None:
            return cached
        cached = {
            # Core (Host protocol)
            "update_cell": self._op_update_cell,
            "create_side_cell": self._op_create_side_cell,
            "request_key": self._op_request_key,
            # Lifecycle phase + progress (gen.phase / gen.status / gen.progress)
            "phase": self._op_phase,
            "progress": self._op_progress,
            # Tier B (native-only)
            "request_settings_update": self._op_request_settings_update,
            "create_terminal_session": self._op_create_terminal_session,
            "destroy_terminal_session": self._op_destroy_terminal_session,
            "poll_renderer_action": self._op_poll_renderer_action,
            # Live chat (renderer-served streaming chat)
            "chat_register": self._op_chat_register,
            "chat_poll": self._op_chat_poll,
            "stream_event": self._op_stream_event,
            # live_files: read the cell's live file state (tip + Files-tab drafts)
            "read_cell_files": self._op_read_cell_files,
            # Composition + renderer compile (host-backed gen.* capabilities)
            "list_generators": self._op_list_generators,
            "start_sub_run": self._op_start_sub_run,
            "sub_run_endpoints": self._op_sub_run_endpoints,
            "sub_run_status": self._op_sub_run_status,
            "sub_run_poll_events": self._op_sub_run_poll_events,
            "sub_run_emit": self._op_sub_run_emit,
            "sub_run_files": self._op_sub_run_files,
            "sub_run_wait": self._op_sub_run_wait,
            "stop_sub_run": self._op_stop_sub_run,
            "surface_sub_run": self._op_surface_sub_run,
            "check_renderer": self._op_check_renderer,
            # One-shot modify handoff on a just-created side cell
            "start_modify_run": self._op_start_modify_run,
            # Cross-cell read / write (gated on cell exposure)
            "list_exposed_cells": self._op_list_exposed_cells,
            "read_cell": self._op_read_cell,
            "write_cell": self._op_write_cell,
            "create_source_cell": self._op_create_source_cell,
            # Environments — capabilities, workspace plane, execution plane,
            # and the env-author serve channel.
            "sub_run_capabilities": self._op_sub_run_capabilities,
            "sub_run_exec": self._op_sub_run_exec,
            "sub_run_exec_background": self._op_sub_run_exec_background,
            "sub_run_wait_process": self._op_sub_run_wait_process,
            "sub_run_stop_process": self._op_sub_run_stop_process,
            "sub_run_expose_port": self._op_sub_run_expose_port,
            "sub_run_open_terminal": self._op_sub_run_open_terminal,
            "sub_run_put_files": self._op_sub_run_put_files,
            "sub_run_read_file": self._op_sub_run_read_file,
            "sub_run_delete_file": self._op_sub_run_delete_file,
            "sub_run_list_files": self._op_sub_run_list_files,
            "sub_run_snapshot": self._op_sub_run_snapshot,
            "serve_environment_register": self._op_serve_environment_register,
            "serve_environment_poll": self._op_serve_environment_poll,
            "serve_environment_reply": self._op_serve_environment_reply,
            # Lifecycle
            "finish": self._op_finish,
        }
        self._ipc_handlers_cache = cached
        return cached

    async def _send_ack(self, ack_body: dict) -> None:
        """Write an ack frame back to the IPC writer. No-op if the
        writer was torn down (e.g. process died mid-handle)."""
        if self._ipc_writer is None:
            return
        self._ipc_writer.write((json.dumps(ack_body) + "\n").encode())
        await self._ipc_writer.drain()

    # ------------------------------------------------------------------
    # Core ops (Host protocol)
    # ------------------------------------------------------------------

    async def _op_update_cell(self, data: dict) -> None:
        """Dispatch through the shared HostMixin emit_partial path so
        the native IPC handler and the WASM runner share a single
        artifact-build → merge → broadcast sequence. ``initial=True``
        on the first emit picks the in-place upsert path; subsequent
        emits create a new version row + cell_edges ``previous_version``
        edge so the version scrubber records each turn as a checkpoint.
        """
        # A cell write is real activity ⇒ advance spinning_up → running
        # (no-ops once past spinning_up, and won't clobber an explicit phase).
        self._maybe_auto_running()
        initial = bool(data.get("initial", False))
        meta = data.get("metadata") or {}
        try:
            await asyncio.to_thread(
                self._emit_partial_core,
                artifacts=data.get("artifacts") or [],
                cell_name=data.get("name"),
                summary=data.get("summary"),
                pinned=meta.get("pinned"),
                deleted_files=data.get("deleted_files"),
                version=not initial,
            )
        except Exception as exc:
            self.log_buffer.append({
                "type": "stderr",
                "payload": f"[update_cell error] {exc}",
            })
            # _emit_partial_core broadcasts dag_commit itself on success;
            # it may have raised before reaching the broadcast, so keep the
            # SSE beat alive on partial failures. Success must NOT broadcast
            # again here — that doubled every commit's SSE traffic.
            self._broadcast_dag_commit()
        await self._send_ack({
            "op": "ack_update", "cell_id": self._last_cell_id or "",
        })

    async def _op_create_side_cell(self, data: dict) -> None:
        try:
            await asyncio.to_thread(self._create_side_cell, data)
        except Exception as exc:
            self.log_buffer.append({
                "type": "stderr",
                "payload": f"[create_side_cell error] {exc}",
            })
        await self._send_ack({
            "op": "ack_create_side_cell", "cell_id": self._last_cell_id or "",
        })
        self._broadcast_dag_commit()

    async def _op_request_key(self, data: dict) -> None:
        """Generator asked for a secret. Delegate to await_key_value
        which handles fast-path / broadcast / wait / clear; map
        KeyRequestCancelled onto the ack's cancelled=True branch so
        the SDK raises StopSignal."""
        ack_body = {
            "op": "ack_request_key",
            "ok": False,
            "value": None,
            "cancelled": False,
            "error": None,
        }
        try:
            value = await self.await_key_value(
                key_name=data.get("key_name", ""),
                description=(data.get("description", "") or ""),
                force=bool(data.get("force", False)),
                attempt=int(data.get("attempt", 1) or 1),
            )
            ack_body["ok"] = True
            ack_body["value"] = value
        except KeyRequestCancelled:
            ack_body["ok"] = False
            ack_body["cancelled"] = True
        except Exception as exc:
            ack_body["ok"] = False
            ack_body["error"] = str(exc)
        await self._send_ack(ack_body)

    # ------------------------------------------------------------------
    # Lifecycle phase + progress
    # ------------------------------------------------------------------

    async def _op_phase(self, data: dict) -> None:
        """Set the run's lifecycle phase. Fire-and-forget (no ack).

        ``gen.phase(name, message)`` sends both; ``gen.status(message)`` sends
        only a message (no ``phase`` key), which updates the message of the
        CURRENT phase — that's the whole status concept now: a phase with a
        sub-message. There is no separate 'status' op or event type.
        """
        from process_manager.phases import RUNNING
        phase = data.get("phase") or self.current_phase or RUNNING
        message = data.get("message") or ""
        self._apply_phase(phase, message)

    async def _op_progress(self, data: dict) -> None:
        """``gen.progress(current, total)`` — a live progress counter. Fire-
        and-forget; rendered as a PROG line in the canonical log."""
        self.log_buffer.append({
            "type": "progress",
            "payload": json.dumps({
                "current": data.get("current"),
                "total": data.get("total"),
            }),
        })

    # ------------------------------------------------------------------
    # Tier B ops (native-only)
    # ------------------------------------------------------------------

    async def _op_request_settings_update(self, data: dict) -> None:
        """Mid-run settings modal. await_settings_update broadcasts +
        waits for /settings_continue + clears the asyncio.Event."""
        ack_body: dict = {"op": "ack_settings_update"}
        try:
            values = await self.await_settings_update(
                settings_file_path=data.get("settings_file_path", ""),
            )
            ack_body["ok"] = True
            ack_body["values"] = values
        except Exception as exc:
            ack_body["ok"] = False
            ack_body["error"] = str(exc)
        await self._send_ack(ack_body)

    async def _op_chat_register(self, data: dict) -> None:
        """Allocate a live chat session for the run's target cell and return
        its ``{session_id, ws_path, token}`` for the generator's ``.chat``
        pointer. The chat renderer opens a WebSocket against ``ws_path``."""
        ack_body: dict = {"op": "ack_chat_register"}
        try:
            cell_id = data.get("cell_id", "")
            target_id = self.placeholder_cell_id
            if not target_id or cell_id != target_id:
                raise RuntimeError(
                    "chat ops are only allowed against the run's target cell"
                )
            from routes.chat_live import register_chat_session
            result = register_chat_session(cell_id=cell_id, run_id=self.run_id)
            ack_body.update(result)
            ack_body["ok"] = True
        except Exception as exc:
            ack_body["ok"] = False
            ack_body["error"] = str(exc)
        await self._send_ack(ack_body)

    async def _op_chat_poll(self, data: dict) -> None:
        """Non-blocking pop of the next inbound renderer command (user_msg /
        interrupt / redirect) for the run's chat session.

        Before handing the generator a turn-triggering message, flush the
        user's pending Files-tab edits into the workspace + version chain so
        the agent reads them on this turn. This is the generic equivalent of
        the old ``/chat/push_message`` draft flush — it makes mid-chat file
        edits visible to the next turn for any chat generator. Transcript
        curation commands (edit/delete/insert/move/regenerate) get the same
        flush: serve_chat re-seeds its history from the workspace file before
        applying them by index, so pending draft edits (Files tab, or the
        assistant renderer's offline curation) must land first or the indices
        drift."""
        command = None
        try:
            from routes.chat_live import pop_command
            command = pop_command(self.placeholder_cell_id or "")
        except Exception:
            command = None
        if command and command.get("kind") in (
            "user_msg", "redirect",
            "edit", "delete", "insert", "move", "regenerate",
        ):
            # While a turn is streaming (background turns keep running across
            # thread switches), the committed tip lags the generator's live
            # workspace writes — reconciling it would REVERT the busy turn's
            # in-progress files (its transcript, its file-tool output). Skip
            # the tip layer then; explicit user edits (drafts) still land.
            include_tip = True
            try:
                from routes.chat_live import get_session_for_cell
                sess = get_session_for_cell(self.placeholder_cell_id or "")
                include_tip = not (sess and sess.in_progress_turn_id)
            except Exception:
                include_tip = True
            try:
                await asyncio.to_thread(
                    self._flush_chat_drafts_to_workspace, include_tip,
                )
            except Exception as exc:
                self.log_buffer.append({
                    "type": "stderr",
                    "payload": f"[chat draft flush] {exc}",
                })
        await self._send_ack({"op": "ack_chat_poll", "command": command})

    def _flush_chat_drafts_to_workspace(self, include_tip: bool = True) -> None:
        """Reconcile the cell's committed files AND pending Files-tab drafts into
        the generator's workspace so user-created/edited files (and transcript
        edits) are visible to the agent on the next turn.

        Two layers: (1) the committed version tip — covers user files committed
        without a pending draft, which the old drafts-only flush missed entirely;
        (2) pending drafts overlaid on top, so uncommitted Files-tab edits win.
        ``.colreserved/`` stays private throughout. Drafts are still promoted to
        a 'Manual Edit' version (only when present, so a pure tip reconcile never
        churns versions). Sync (sqlite + filesystem) — call via to_thread."""
        cell_id = self.placeholder_cell_id
        workspace = getattr(self, "workspace_dir", None)
        if not cell_id or not workspace:
            return
        import shutil
        from routes.runs import _promote_drafts_to_version
        from routes.runs.helpers import (
            _find_version_tip, _is_colreserved, _safe_dest_under,
        )
        conn = get_db_connection(self.channel)
        try:
            # 1. Committed version tip -> workspace. Skipped while a chat turn
            #    is in flight (include_tip=False): the tip lags the busy
            #    turn's live writes and would revert them.
            try:
                if include_tip:
                    tip_id = _find_version_tip(conn, cell_id)
                    rows = conn.execute(
                        "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?",
                        (tip_id,),
                    ).fetchall()
                    for row in rows:
                        fp, blob_hash = row["filepath"], row["blob_hash"]
                        if not blob_hash or _is_colreserved(fp):
                            continue
                        dst = _safe_dest_under(workspace, fp)
                        if not dst:
                            continue
                        cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
                        if not os.path.exists(cas_path):
                            continue
                        os.makedirs(os.path.dirname(dst) or workspace, exist_ok=True)
                        shutil.copy2(cas_path, dst)
            except Exception as exc:
                self.log_buffer.append({"type": "stderr", "payload": f"[chat tip reconcile] {exc}"})

            # 2. Pending Files-tab drafts overlay the committed tip.
            drafts = conn.execute(
                "SELECT filepath, content_text, blob_hash FROM cell_drafts WHERE cell_id=?",
                (cell_id,),
            ).fetchall()
            for draft in drafts:
                fp = draft["filepath"]
                if _is_colreserved(fp):
                    continue
                dst = _safe_dest_under(workspace, fp)
                if not dst:
                    continue
                os.makedirs(os.path.dirname(dst) or workspace, exist_ok=True)
                draft_blob = draft["blob_hash"]
                if draft_blob:
                    # Binary draft — copy the CAS bytes verbatim so the agent
                    # sees the real file on disk (text-encoding corrupts it).
                    cas_path = os.path.join(".collimate", "objects", draft_blob[:2], draft_blob[2:])
                    if os.path.exists(cas_path):
                        shutil.copy2(cas_path, dst)
                    continue
                with open(dst, "w", encoding="utf-8") as f:
                    f.write(draft["content_text"] or "")
            if not drafts:
                return
            # Seed the genesis row's cell_files from state.json when versioning
            # this cell for the first time, else unchanged files would vanish.
            current_files = None
            try:
                from state import state as _state, channel_db_name as _cdn
                for ch in _state.channels:
                    if _cdn(ch) != self.channel:
                        continue
                    for stk in [*ch.main_stacks, *ch.nav_stacks]:
                        for c in stk.cells:
                            if str(c.id) == cell_id:
                                current_files = [
                                    {"filepath": f.name, "content": f.content, "blob_hash": f.blob_hash}
                                    for f in c.files
                                ]
                                break
                        if current_files is not None:
                            break
                    break
            except Exception:
                current_files = None
            _promote_drafts_to_version(
                conn, cell_id, self.run_id, current_files=current_files,
            )
            conn.commit()
        finally:
            try:
                conn.close()
            except Exception:
                pass

    def _compute_cell_live_files(self) -> dict:
        """The cell's live file state as the user sees it in the Files tab:
        the committed version tip overlaid with pending Files-tab drafts, as
        ``{path: bytes}``. ``.colreserved/`` stays private. Pure read (no
        workspace writes) — the read half of ``live_files`` (the write half is
        :meth:`_flush_chat_drafts_to_workspace`). Sync sqlite — call via
        ``to_thread``."""
        cell_id = self.placeholder_cell_id
        if not cell_id:
            return {}
        from routes.runs.helpers import _find_version_tip, _is_colreserved

        def _cas_bytes(blob_hash: str):
            if not blob_hash:
                return None
            p = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
            if not os.path.exists(p):
                return None
            with open(p, "rb") as f:
                return f.read()

        out: dict = {}
        conn = get_db_connection(self.channel)
        try:
            # 1. Committed version tip. A failure here (e.g. sqlite 'database is
            # locked' under concurrent writes) must PROPAGATE — it bubbles to
            # _op_read_cell_files, which reports it as an error so the SDK mirror
            # skips the tick. Swallowing it and returning a partial set would
            # look like "those tip files were deleted" and the mirror would
            # delete them from the workspace.
            tip_id = _find_version_tip(conn, cell_id)
            for row in conn.execute(
                "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?", (tip_id,),
            ).fetchall():
                fp = row["filepath"]
                if _is_colreserved(fp):
                    continue
                data = _cas_bytes(row["blob_hash"])
                if data is not None:
                    out[fp] = data
            # 2. Pending Files-tab drafts overlay the tip.
            for draft in conn.execute(
                "SELECT filepath, content_text, blob_hash FROM cell_drafts WHERE cell_id=?", (cell_id,),
            ).fetchall():
                fp = draft["filepath"]
                if _is_colreserved(fp):
                    continue
                if draft["blob_hash"]:
                    data = _cas_bytes(draft["blob_hash"])
                    if data is not None:
                        out[fp] = data
                else:
                    out[fp] = (draft["content_text"] or "").encode("utf-8")
        finally:
            try:
                conn.close()
            except Exception:
                pass
        return out

    async def _op_read_cell_files(self, data: dict) -> None:
        """live_files read half: hand the running generator the cell's live
        files ({text}/{b64} encoded, the inverse of the SDK's _decode_files)."""
        import base64

        ack_body: dict = {"op": "ack_read_cell_files", "files": {}}
        try:
            files = await asyncio.to_thread(self._compute_cell_live_files)
            encoded: dict = {}
            for path, raw in files.items():
                try:
                    encoded[path] = {"text": raw.decode("utf-8")}
                except UnicodeDecodeError:
                    encoded[path] = {"b64": base64.b64encode(raw).decode("ascii")}
            ack_body["files"] = encoded
        except Exception as exc:
            ack_body["error"] = str(exc)
        await self._send_ack(ack_body)

    async def _op_create_terminal_session(self, data: dict) -> None:
        ack_body: dict = {"op": "ack_create_terminal_session"}
        try:
            cell_id = data.get("cell_id", "")
            target_id = self.placeholder_cell_id
            if not target_id or cell_id != target_id:
                raise RuntimeError(
                    "terminal ops are only allowed against the run's target cell"
                )
            from routes.terminal import register_session
            result = register_session(
                cell_id=cell_id,
                container_id=data.get("container_id", "") or "",
                command=list(data.get("command") or []),
                cwd=data.get("cwd") or None,
                env=data.get("env") or {},
            )
            ack_body.update(result)
            ack_body["ok"] = True
        except Exception as exc:
            ack_body["ok"] = False
            ack_body["error"] = str(exc)
        await self._send_ack(ack_body)

    async def _op_destroy_terminal_session(self, data: dict) -> None:
        try:
            from routes.terminal import unregister_session
            unregister_session(data.get("session_id", "") or "")
        except Exception as exc:
            self.log_buffer.append({
                "type": "stderr",
                "payload": f"[destroy_terminal_session error] {exc}",
            })

    async def _op_poll_renderer_action(self, data: dict) -> None:
        action_id = None
        if self._pending_renderer_actions:
            action_id = self._pending_renderer_actions.pop(0)
        await self._send_ack({
            "op": "ack_poll_renderer_action", "action_id": action_id,
        })

    async def _op_stream_event(self, data: dict) -> None:
        """Streaming turn_start / text_delta / tool / turn_end / error events
        from the generator. Fire-and-forget — no ack. Routed to the cell's
        live chat session, which forwards them over the renderer WebSocket.
        Canonical text lives in the cell's ``.chatlog``; these deltas are the
        live overlay."""
        from routes.chat_live import push_event
        push_event(
            data.get("cell_id", "") or self.placeholder_cell_id or "",
            data.get("turn_id", ""),
            data.get("event", {}),
        )

    # ------------------------------------------------------------------
    # Composition + renderer compile (host-backed gen.* capabilities)
    #
    # Implemented in process_manager/sub_runs.py. Child runs are
    # parent-bound: stopped in _wait_and_cleanup when this run ends.
    # ------------------------------------------------------------------

    async def _op_list_generators(self, data: dict) -> None:
        from process_manager.sub_runs import list_installed_generators
        gens = await asyncio.to_thread(list_installed_generators, self.channel)
        await self._send_ack({"op": "ack_list_generators", "generators": gens})

    async def _op_start_sub_run(self, data: dict) -> None:
        from process_manager.sub_runs import spawn_sub_run
        await self._send_ack(await spawn_sub_run(self, data))

    async def _op_sub_run_wait(self, data: dict) -> None:
        from process_manager.sub_runs import wait_sub_run
        await self._send_ack(await wait_sub_run(self, data))

    async def _op_sub_run_endpoints(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_endpoints
        await self._send_ack(sub_run_endpoints(self, data))

    async def _op_sub_run_status(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_status
        await self._send_ack(await asyncio.to_thread(sub_run_status, self, data))

    async def _op_sub_run_files(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_files
        await self._send_ack(await asyncio.to_thread(sub_run_files, self, data))

    async def _op_sub_run_poll_events(self, data: dict) -> None:
        # Parent drains a child's parent-bound event buffer (gen handle.events()).
        from process_manager.sub_runs import sub_run_poll_events
        await self._send_ack(await asyncio.to_thread(sub_run_poll_events, self, data))

    async def _op_sub_run_emit(self, data: dict) -> None:
        # Child pushes a typed event to its parent's buffer (gen.emit_event).
        # Fire-and-forget — no ack. ``self`` is the child's run manager.
        from process_manager.sub_runs import record_sub_run_event
        record_sub_run_event(self, data)

    async def _op_stop_sub_run(self, data: dict) -> None:
        # Fire-and-forget (SDK uses emit, not emit_and_wait) — no ack.
        from process_manager.sub_runs import stop_sub_run
        await stop_sub_run(self, data)

    async def _op_surface_sub_run(self, data: dict) -> None:
        from process_manager.sub_runs import surface_sub_run
        await self._send_ack(await surface_sub_run(self, data))

    async def _op_start_modify_run(self, data: dict) -> None:
        """One-shot handoff: start an independent, top-level ``modify``
        run of another generator on a side cell THIS run just created
        via ``create_side_cell``.

        Deliberately narrow by design:

          * **modify only** — the invocation type is hardcoded;
            ``create_run`` rejects a target generator whose manifest
            doesn't declare ``modify``.
          * **only a cell this run just produced** — the id must be in
            ``modify_handoff_cells`` (populated by
            ``_record_side_cell_inner``), and a successful handoff
            consumes it, so each cell can be handed off at most once.
          * **no monitoring** — the child run is NOT parent-bound (it
            doesn't join ``_sub_runs`` and survives this run's
            teardown); the ack carries ok/error only, exposing no
            handle, status, or events for the spawned run.
        """
        ack_body: dict = {"op": "ack_start_modify_run", "ok": False}
        cell_id = str(data.get("cell_id") or "").strip()
        generator = str(data.get("generator") or "").strip()
        try:
            if not cell_id or not generator:
                raise RuntimeError(
                    "start_modify_run requires cell_id and generator"
                )
            if cell_id not in self.modify_handoff_cells:
                raise RuntimeError(
                    "start_modify_run only accepts a cell this run just "
                    "created via create_stack_cell (one handoff per cell); "
                    f"got {cell_id!r}"
                )
            # Chain guard — the child inherits parent depth + 1 so two
            # generators handing cells back and forth hit the same cap
            # as gen.spawn recursion. Trust the host-tracked depth, not
            # anything the generator echoes.
            from process_manager.sub_runs import _MAX_CALL_DEPTH
            child_depth = int(getattr(self, "call_depth", 0) or 0) + 1
            if child_depth > _MAX_CALL_DEPTH:
                raise RuntimeError(
                    f"max composition depth ({_MAX_CALL_DEPTH}) exceeded"
                )

            # Cell-exposure gate — the same one ``gen.call`` applies in
            # ``spawn_sub_run``: refuse to hand the cell to a generator whose
            # source cell is turned off "to generators" (exposed-by-default).
            # Without this, the modify-on-a-new-cell handoff would run
            # generators the channel has hidden from composition. An
            # unresolvable id (``_cid is None``) falls through un-blocked — the
            # fail-open posture that keeps shipped generators callable through a
            # flaky manifest read.
            from channel_config import cell_exposed, read_cell_exposure
            from routes.runs.helpers import _generator_cell_id
            _cid = _generator_cell_id(generator, self.channel)
            if _cid is not None and not cell_exposed(
                read_cell_exposure(self.channel), _cid
            ):
                raise RuntimeError(
                    f"generator {generator!r}'s cell is not exposed to generators"
                )

            from fastapi import HTTPException
            from fastapi.responses import JSONResponse
            from routes.runs.create import create_run
            from routes.runs.models import RunRequest

            # Same request shape the picker sends for a user-invoked
            # modify run: the target cell is both the single input and
            # the placeholder, so the child rewrites it in place.
            req = RunRequest(
                prompt=str(data.get("prompt") or ""),
                generator_name=generator,
                input_cell_ids=[cell_id],
                placeholder_cell_id=cell_id,
                invocation_type="modify",
                call_depth=child_depth,
            )
            try:
                result = await create_run(self.channel, req)
            except HTTPException as exc:
                raise RuntimeError(str(exc.detail)) from exc
            if isinstance(result, JSONResponse):
                # create_run's missing_required gate returns a structured
                # 400 body instead of raising.
                raise RuntimeError(
                    "target generator has required config this handoff "
                    "can't satisfy: "
                    + result.body.decode("utf-8", errors="replace")
                )
            # Handoff complete — the cell is out of this run's hands.
            self.modify_handoff_cells.discard(cell_id)
            self.log_buffer.append({
                "type": "stdout",
                "payload": (
                    f"[start_modify_run] handed cell {cell_id} to "
                    f"'{generator}' (run {result.get('run_id', '?')})"
                ),
            })
            ack_body["ok"] = True
        except Exception as exc:
            ack_body["error"] = str(exc)
            self.log_buffer.append({
                "type": "stderr",
                "payload": f"[start_modify_run error] {exc}",
            })
        await self._send_ack(ack_body)

    async def _op_check_renderer(self, data: dict) -> None:
        from process_manager.sub_runs import check_renderer_files
        ack = await check_renderer_files(
            data.get("files") or {}, data.get("entrypoint") or "main.tsx",
        )
        ack["op"] = "ack_check_renderer"
        await self._send_ack(ack)

    # ------------------------------------------------------------------
    # Cross-cell read / write — gated on cell exposure (cell_rw.py). A run may
    # introspect/read/edit only EXPOSED generator/renderer source cells; every
    # write commits an undoable 'generator_edit' version and syncs live state.
    # ------------------------------------------------------------------

    async def _op_list_exposed_cells(self, data: dict) -> None:
        from process_manager.cell_rw import list_exposed_cells
        cells = await asyncio.to_thread(list_exposed_cells, self.channel)
        await self._send_ack({"op": "ack_list_exposed_cells", "cells": cells})

    async def _op_read_cell(self, data: dict) -> None:
        from process_manager.cell_rw import CellNotExposed, CellNotFound, read_cell
        from process_manager.sub_runs import _encode_files
        ack_body: dict = {"op": "ack_read_cell"}
        try:
            files = await asyncio.to_thread(read_cell, self.channel, data.get("cell_id", ""))
            ack_body["ok"] = True
            ack_body["files"] = _encode_files(files)
        except CellNotExposed as exc:
            ack_body.update(ok=False, reason="not_exposed", error=str(exc))
        except CellNotFound as exc:
            ack_body.update(ok=False, reason="not_found", error=str(exc))
        except Exception as exc:
            ack_body.update(ok=False, reason="error", error=str(exc))
        await self._send_ack(ack_body)

    async def _op_write_cell(self, data: dict) -> None:
        from process_manager.cell_rw import CellNotExposed, CellNotFound, write_cell
        from process_manager.sub_runs import _decode_files
        cell_id = data.get("cell_id", "")
        ack_body: dict = {"op": "ack_write_cell"}
        try:
            files = _decode_files(data.get("files") or {})
            version_id = await asyncio.to_thread(
                write_cell, self.channel, cell_id, files, data.get("deleted"),
                summary=data.get("summary"),
                generator_name=self.generator_name,
            )
            ack_body.update(ok=True, version_id=version_id)
            # If the run edited its OWN cell, drop the stale tip cache so the
            # next gen.update() forks off the new version, not the old tip.
            if cell_id and cell_id == self.placeholder_cell_id:
                self._tip_cache.pop(cell_id, None)
            self._broadcast_dag_commit()
        except CellNotExposed as exc:
            ack_body.update(ok=False, reason="not_exposed", error=str(exc))
        except CellNotFound as exc:
            ack_body.update(ok=False, reason="not_found", error=str(exc))
        except ValueError as exc:
            ack_body.update(ok=False, reason="lint", error=str(exc))
        except Exception as exc:
            ack_body.update(ok=False, reason="error", error=str(exc))
        await self._send_ack(ack_body)

    async def _op_create_source_cell(self, data: dict) -> None:
        from process_manager.cell_rw import CellNotFound, create_source_cell
        from process_manager.sub_runs import _decode_files
        ack_body: dict = {"op": "ack_create_source_cell"}
        try:
            files = _decode_files(data.get("files") or {})
            cell_id = await asyncio.to_thread(
                create_source_cell, self.channel, data.get("stack", ""),
                data.get("name", ""), files,
                summary=data.get("summary"), pinned=data.get("pinned"),
            )
            ack_body.update(ok=True, cell_id=cell_id)
            # Surface the new nav-stack cell to the UI right away.
            self._last_cell_id = cell_id
            self._broadcast_dag_commit()
        except CellNotFound as exc:
            ack_body.update(ok=False, reason="not_found", error=str(exc))
        except ValueError as exc:
            ack_body.update(ok=False, reason="lint", error=str(exc))
        except Exception as exc:
            ack_body.update(ok=False, reason="error", error=str(exc))
        await self._send_ack(ack_body)

    # ------------------------------------------------------------------
    # Environments
    # ------------------------------------------------------------------

    async def _op_sub_run_capabilities(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_capabilities
        await self._send_ack(sub_run_capabilities(self, data))

    async def _op_sub_run_exec(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_route
        await self._send_ack(await sub_run_route(self, data, "exec", "ack_sub_run_exec"))

    async def _op_sub_run_exec_background(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_route
        await self._send_ack(await sub_run_route(self, data, "exec_background", "ack_sub_run_exec_background"))

    async def _op_sub_run_wait_process(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_route
        await self._send_ack(await sub_run_route(self, data, "wait_process", "ack_sub_run_wait_process"))

    async def _op_sub_run_stop_process(self, data: dict) -> None:
        # Fire-and-forget (SDK emits, no wait).
        from process_manager.sub_runs import sub_run_route_oneway
        await sub_run_route_oneway(self, data, "stop_process")

    async def _op_sub_run_expose_port(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_route
        await self._send_ack(await sub_run_route(self, data, "expose_port", "ack_sub_run_expose_port"))

    async def _op_sub_run_open_terminal(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_route
        await self._send_ack(await sub_run_route(self, data, "open_terminal", "ack_sub_run_open_terminal"))

    async def _op_sub_run_put_files(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_put_files
        await self._send_ack(await asyncio.to_thread(sub_run_put_files, self, data))

    async def _op_sub_run_read_file(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_read_file
        await self._send_ack(await asyncio.to_thread(sub_run_read_file, self, data))

    async def _op_sub_run_delete_file(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_delete_file
        await self._send_ack(await asyncio.to_thread(sub_run_delete_file, self, data))

    async def _op_sub_run_list_files(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_list_files
        await self._send_ack(await asyncio.to_thread(sub_run_list_files, self, data))

    async def _op_sub_run_snapshot(self, data: dict) -> None:
        from process_manager.sub_runs import sub_run_snapshot
        await self._send_ack(await asyncio.to_thread(sub_run_snapshot, self, data))

    async def _op_serve_environment_register(self, data: dict) -> None:
        from process_manager.sub_runs import serve_environment_register
        await self._send_ack(serve_environment_register(self, data))

    async def _op_serve_environment_poll(self, data: dict) -> None:
        from process_manager.sub_runs import serve_environment_poll
        await self._send_ack(await serve_environment_poll(self, data))

    async def _op_serve_environment_reply(self, data: dict) -> None:
        # Fire-and-forget (SDK emits the reply); resolves the parent's future.
        from process_manager.sub_runs import serve_environment_reply
        serve_environment_reply(self, data)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def _op_finish(self, data: dict) -> None:
        """Generator's clean shutdown signal. Marks the run row +
        broadcasts the terminal status. Run exit without finish (e.g.
        SIGKILL) is handled by _wait_and_cleanup → _finalize_run_status."""
        success = data.get("success", True)
        status = "completed" if success else "failed"
        error_msg = data.get("error_message", "")
        self.log_buffer.append({
            "type": "finish",
            "payload": json.dumps({"success": success, "error_message": error_msg}),
        })
        conn = get_db_connection(self.channel)
        conn.execute("UPDATE runs SET status=? WHERE id=?", (status, self.run_id))
        conn.commit()
        conn.close()
        self._broadcast_run_status(status)

    # ------------------------------------------------------------------
    # Fall-through (unknown ops)
    # ------------------------------------------------------------------

    async def _op_unknown(self, data: dict) -> None:
        """Handle ops without a dedicated handler.

        ``port_bound`` carries the snapshot_source block — capture it on the
        manager so the snapshot endpoint can pull files out of the running
        container later. Anything else is a genuinely unknown op (e.g. a newer
        SDK emitting something this backend doesn't model): surface it as an
        ipc_error so it's visible, and still persist the raw row for
        debugging.
        """
        op = data.get("op")
        if op == "port_bound":
            src = data.get("snapshot_source")
            if isinstance(src, dict):
                self.snapshot_source = src
            # Record the bound port so the reverse proxy can verify this
            # run actually owns it before forwarding (see manager.bound_ports).
            port_val = data.get("port")
            if port_val is not None:
                try:
                    self.bound_ports.add(int(port_val))
                except (TypeError, ValueError):
                    pass
        else:
            self.log_buffer.append({
                "type": "ipc_error",
                "payload": f"unknown IPC op: {op!r}",
            })
        self.log_buffer.append({"type": op or "unknown", "payload": json.dumps(data)})

    def _broadcast_dag_commit(self):
        """Broadcast DAG commit + state update to SSE subscribers.

        The ``dag_commit`` message is small and latency-sensitive (it drives
        FILES_CHANGED fan-out to mounted renderers), so it goes out
        immediately. The ``state_update`` ships a full serialized app state —
        coalesce it so a commit burst (a generator checkpointing several
        times in a second) doesn't serialize and push the whole state once
        per commit and drown the SSE queue / frontend."""
        from events import broadcast, broadcast_coalesced
        broadcast(self.channel, {
            "type": "dag_commit",
            "cell_id": self._last_cell_id,
            "run_id": self.run_id,
            "generator_name": self.generator_name,
        })

        def _build_state_update():
            from state import state, channel_db_name, strip_large_content
            for ch_obj in state.channels:
                if channel_db_name(ch_obj) == self.channel:
                    state_dict = state.model_dump(mode="json")
                    return {
                        "type": "state_update",
                        "state": strip_large_content(state_dict),
                    }
            return None

        broadcast_coalesced(self.channel, _build_state_update)

    async def _wait_and_cleanup(self):
        """Wait for the process to exit, then finalize status and clean up.

        Cleanup runs in a ``try/finally`` so the chat-session + terminal-
        session unregister + IPC server close + log flush always execute on
        the way out, even if ``_finalize_run_status`` or one of the upstream
        awaits raises. With the finally, every run-end path — clean exit,
        SIGTERM, SIGKILL, finalize crash — reaches the unregister, so a
        WebSocket (chat or terminal) can't outlive its generator.
        """
        await self.process.wait()

        try:
            # Wait for the output streams to fully drain — but bounded. The
            # pipes only hit EOF when every writer closes them; a background
            # process the generator left behind (inheriting stdout/stderr)
            # would otherwise wedge this gather forever, skipping the entire
            # finally block below (sub-run teardown, IPC close, log flush)
            # and never finalizing the run's status.
            if hasattr(self, '_stdout_task'):
                try:
                    await asyncio.wait_for(
                        asyncio.gather(
                            self._stdout_task, self._stderr_task,
                            return_exceptions=True,
                        ),
                        timeout=10.0,
                    )
                except asyncio.TimeoutError:
                    # A straggler in the generator's process group still
                    # holds the pipe. The run is over — kill the group
                    # (the generator was its own session leader, so its
                    # pgid == its pid even after the leader was reaped)
                    # and stop draining so teardown can proceed.
                    self.push_log(
                        "[cleanup] stdout/stderr never reached EOF — a "
                        "leftover background process is holding the pipe; "
                        "killing the run's process group"
                    )
                    if os.name != "nt":
                        import signal as _sig
                        try:
                            os.killpg(self.process.pid, _sig.SIGKILL)
                        except (ProcessLookupError, PermissionError, OSError):
                            pass
                    for _t in (self._stdout_task, self._stderr_task):
                        _t.cancel()

            # Give IPC a moment to drain any final messages
            await asyncio.sleep(0.2)

            # Wait for the microbatch writer to finish its final flush before
            # we touch the DB — otherwise _finalize_run_status races with the
            # writer's last INSERT and both hit "database is locked".
            if hasattr(self, '_writer_task'):
                await self._writer_task

            await asyncio.to_thread(self._finalize_run_status)
        finally:
            # ---------------------------------------------------------
            # Always-run cleanup. Each step independently wrapped in
            # try/except so one failure can't cascade and skip the
            # next.
            # ---------------------------------------------------------

            # Tear down any live chat session this run served. The
            # WebSocket closes, and the chat renderer falls back to the
            # read-only .chatlog transcript.
            if self.placeholder_cell_id:
                try:
                    from routes.chat_live import unregister_chat_sessions_for_cell
                    unregister_chat_sessions_for_cell(self.placeholder_cell_id)
                except Exception as exc:
                    print(f"[process_manager] unregister_chat_sessions_for_cell failed: {exc}")

                # Drop any terminal sessions attached to this cell.
                # Belt-and-suspenders: well-behaved generators call
                # stop_terminal() in their own try/finally, but this
                # catches leaks if they don't.
                try:
                    from routes.terminal import unregister_sessions_for_cell
                    unregister_sessions_for_cell(self.placeholder_cell_id)
                except Exception as exc:
                    print(f"[process_manager] unregister_sessions_for_cell failed: {exc}")

            # Parent-bound composition: stop every sub-run this run spawned,
            # so a forgotten child (esp. a daemon) can't leak past the parent.
            if getattr(self, "_sub_runs", None):
                try:
                    from process_manager.sub_runs import stop_all_sub_runs
                    await stop_all_sub_runs(self)
                except Exception as exc:
                    print(f"[process_manager] stop_all_sub_runs failed: {exc}")

            if self._ipc_server:
                try:
                    self._ipc_server.close()
                    await self._ipc_server.wait_closed()
                except Exception as exc:
                    print(f"[process_manager] _ipc_server.close failed: {exc}")

            # Ensure all remaining logs are flushed after IPC server shuts down
            try:
                await asyncio.to_thread(self._flush_log_buffer)
            except Exception as exc:
                print(f"[process_manager] _flush_log_buffer failed: {exc}")

            # The run is over — retire the timeout watchdog. Without this it
            # sleeps out the full wall-clock cap (up to 30 min) holding a
            # reference to the whole manager (log buffers, tip cache, …).
            tt = getattr(self, "_timeout_task", None)
            if tt is not None and not tt.done():
                tt.cancel()
