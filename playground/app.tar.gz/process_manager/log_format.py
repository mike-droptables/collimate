"""Canonical run-log line formatter.

The ONE format shared by the live drawer (frontend/src/lib/runLogFormat.ts)
and the persisted ``.colreserved/logs.txt`` (finalization). The two MUST stay
byte-identical — a reconnecting client rebuilds the drawer purely by replaying
run_events through this format, and the saved file is the same rows formatted
the same way, so live == saved.

Each run_events row → one line::

    [HH:MM:SS] TAG    text

``TAG`` is left-justified in a fixed width. The set of event types that render
is an explicit ALLOW-LIST — anything not below (sub_run_*, stream_event,
chat_*, port_bound, dag_commit, … internal plumbing) returns ``None`` and is
dropped on BOTH sides.

``gen.log()`` is NOT a distinct event type — it is ``[LEVEL]``-prefixed
**stderr** (the SDK wires the generator logger with
``logging.Formatter("[%(levelname)s] %(message)s")``). So stderr rows whose
payload opens with a known level frame are re-tagged (INFO/DEBUG→LOG,
WARNING→WARN, ERROR/CRITICAL→ERR) and the frame is stripped; bare stderr
(real subprocess noise) stays ``ERR``.
"""
import json

TAG_WIDTH = 6

# Python logging levelname frames emitted on stderr by gen.log()/the logger.
LEVEL_TAGS = {
    "INFO": "LOG",
    "DEBUG": "LOG",
    "WARNING": "WARN",
    "ERROR": "ERR",
    "CRITICAL": "ERR",
}

# The allow-list: event types that render, and their tag. ``stdout``/``stderr``
# are handled specially (raw text / level re-tag); the rest pull text out of a
# JSON payload. Keep this set identical to LOG_TAGS in runLogFormat.ts.
RENDERED_TYPES = frozenset({
    "stdout", "stderr", "log", "memory", "phase", "progress",
    "finish", "ipc_error", "timeout", "stop", "commit",
    "key_requested", "settings_update_requested",
})


def _hhmmss(created_at) -> str:
    """Slice ``HH:MM:SS`` out of a SQLite ``CURRENT_TIMESTAMP`` string
    (``YYYY-MM-DD HH:MM:SS``, UTC, no offset). String-slice — never
    ``datetime.parse`` / ``new Date`` — so Python and JS agree (JS would
    treat the offset-less string as local and skew the time)."""
    s = str(created_at or "")
    if len(s) >= 19 and s[10] in (" ", "T"):
        return s[11:19]
    return ""


def _as_dict(payload) -> dict:
    try:
        v = json.loads(payload)
        return v if isinstance(v, dict) else {}
    except Exception:
        return {}


def _strip_level(text: str):
    """If ``text`` opens with a ``[LEVEL] `` frame, return ``(tag, stripped)``;
    else ``(None, text)``."""
    if text.startswith("["):
        close = text.find("] ")
        if close != -1:
            tag = LEVEL_TAGS.get(text[1:close])
            if tag:
                return tag, text[close + 2:]
    return None, text


def _summarize(event_type: str, payload):
    """Return ``(tag, text)`` for a rendered event, or ``(None, "")`` to drop."""
    if event_type == "stdout":
        return "OUT", str(payload).rstrip("\n")
    if event_type == "stderr":
        tag, body = _strip_level(str(payload).rstrip("\n"))
        return (tag or "ERR"), body
    if event_type == "log":
        # gen.log() on the wasm path (native rides [INFO]-stderr → LOG above).
        return "LOG", str(payload).rstrip("\n")
    if event_type == "memory":
        return "MEM", str(payload).rstrip("\n")
    if event_type in ("ipc_error", "timeout"):
        return ("IPCERR" if event_type == "ipc_error" else "TIMOUT"), str(payload).rstrip("\n")

    d = _as_dict(payload)
    if event_type == "phase":
        p = str(d.get("phase", "") or "")
        m = str(d.get("message", "") or "")
        return "PHASE", (f"{p} — {m}" if m else p)
    if event_type == "progress":
        return "PROG", f"{d.get('current', '?')}/{d.get('total', '?')}"
    if event_type == "finish":
        err = str(d.get("error_message", "") or "")
        base = "ok" if d.get("success", True) else "failed"
        return "DONE", (f"{base}: {err}" if err else base)
    if event_type == "stop":
        return "STOP", str(d.get("stop_type", "stopped") or "stopped")
    if event_type == "commit":
        name = str(d.get("name", "") or "")
        summary = str(d.get("summary", "") or "")
        return "COMMIT", (f"{name} — {summary}" if summary else name)
    if event_type == "key_requested":
        # Name only — never the description (may carry sensitive context).
        return "KEY", str(d.get("key_name", "") or "")
    if event_type == "settings_update_requested":
        # Filename only — never settings_content (large / sensitive).
        return "SET", str(d.get("settings_file_path", "") or "")
    return None, ""


def format_log_line(event_type: str, payload, created_at=None):
    """Format one run_events row into the canonical line, or ``None`` if the
    event type is not part of the user-facing log (allow-list miss)."""
    tag, text = _summarize(event_type, payload if payload is not None else "")
    if tag is None:
        return None
    ts = _hhmmss(created_at)
    prefix = f"[{ts}] " if ts else ""
    return f"{prefix}{tag:<{TAG_WIDTH}} {text}"
