"""ProcessManager — owns a single generator run's lifecycle.

Key responsibilities:
  - Launch the generator via ``uv run <entrypoint>`` with directory isolation
  - Communicate over a localhost TCP socket for IPC (native path)
  - Forward stdout/stderr blindly to the run_events log table
  - Handle explicit artifact commits (no more os.walk snapshotting)
  - ACK commits via the TCP socket so generators can block until CAS write completes

The class body is small because the implementation is split across the
topical mixins mixed in below — see each for its own docstring.
"""

import asyncio
import json
import os
from collections import deque

from .artifacts import ArtifactsMixin
from .cells import CellsMixin
from .finalization import FinalizationMixin
from .ipc import IPCMixin
from .streams import StreamsMixin
from .wasm_runner import WasmRunnerMixin


class ProcessManager(
    StreamsMixin,
    IPCMixin,
    ArtifactsMixin,
    CellsMixin,
    FinalizationMixin,
    WasmRunnerMixin,
):
    def __init__(
        self,
        channel: str,
        run_id: str,
        app_dir: str,
        workspace_dir: str,
        entrypoint: str,
        generator_name: str = "default",
        params: dict | None = None,
        placeholder_cell_id: str | None = None,
        input_cell_ids: list[str] | None = None,
        initial_settings_content: str | None = None,
        initial_settings_filename: str | None = None,
    ):
        from database import _slug_channel
        self.channel = _slug_channel(channel)
        self.run_id = run_id
        self.app_dir = app_dir              # Generator code dir (CWD, read-only)
        self.workspace_dir = workspace_dir  # Hydrated input files (read/write)
        self.entrypoint = entrypoint
        self.generator_name = generator_name
        self.params = params or {}
        self.input_cell_ids = input_cell_ids or []

        # Settings content accumulated across the run. Flushed into the
        # first cell's version tip at finalization alongside logs.
        # Each tuple: (name_stem, extension, content).
        # The initial settings (from `POST /runs`) start the list; each
        # mid-run `request_settings_update` appends another entry.
        self.settings_history: list[tuple[str, str, str]] = []
        self._settings_update_count: int = 0
        if initial_settings_content is not None and initial_settings_filename:
            ext = os.path.splitext(initial_settings_filename)[1] or ""
            self.settings_history.append(
                ("initial_settings", ext, initial_settings_content)
            )
        # Every run auto-creates a placeholder cell. This is the visible
        # cell id on the canvas that update_cell() mutates.
        self.placeholder_cell_id = placeholder_cell_id

        # Per-run target stack tracking for the portal-recursion placement rule
        # (see api/cell_placement.py). Updated after every commit and snapshot
        # so subsequent placements know where the previous one landed.
        self.current_target_stack_id: str | None = None

        # Stack id used by create_side_cell — first call creates a new
        # stack, subsequent calls append to it.
        self.side_stack_id: str | None = None

        # 10MB ring buffer to prevent memory exhaustion
        self.log_buffer: deque = deque(maxlen=10000)
        self.process = None
        self._last_cell_id: str | None = None

        # Snapshot capability — populated when the generator emits a
        # `port_bound` message that includes a `snapshot_source` block.
        # When present, the backend can pull files out of a running docker
        # container on demand (used by the snapshot endpoint).
        self.snapshot_source: dict | None = None

        # Queue of user messages pushed by the frontend, consumed by the
        # generator subprocess via the poll_user_message IPC op.
        self._pending_user_messages: list[str] = []

        # Queue of renderer-emitted action ids (e.g. top-bar button clicks
        # from the .website renderer). Consumed via poll_renderer_action.
        self._pending_renderer_actions: list[str] = []

        # Blocking settings-update flow: generator calls
        # request_settings_update(), we broadcast an SSE event and wait
        # for the user to press Continue via the /settings_continue
        # endpoint which sets the values and signals the event.
        self._pending_settings_update: asyncio.Event | None = None
        self._settings_update_values: dict | None = None

        # Blocking key-request flow: generator calls gen.get_key(name);
        # if not satisfied from os.environ, the IPC handler broadcasts a
        # ``key_requested`` run event and blocks here until the user
        # submits via the /key_continue endpoint (which sets the value
        # + cancellation flag and signals the event).
        self._pending_key_request: asyncio.Event | None = None
        self._key_request_value: str | None = None
        self._key_request_cancelled: bool = False

        # IPC via localhost TCP socket
        self._ipc_server: asyncio.Server | None = None
        self._ipc_writer: asyncio.StreamWriter | None = None

        # Wasm run state. Native runs use the subprocess lifecycle + IPC
        # above; wasm runs are dispatched in-process by _run_wasm and
        # cooperate via these flags (see collimate.wasm_sdk.WasmHost).
        self._cancelled: bool = False
        # Counts emit_partial invocations (0 = never called). Treated as
        # a truthy "was called?" flag at termination logging; the count
        # itself surfaces in [wasm-timing] log lines.
        self._emit_partial_called: int = 0
        self._last_emit_cell_name: str | None = None
        self._last_emit_summary: str | None = None

        # Set by ``ctx.finish(success, error_message)`` — the wasm
        # dispatcher reads this at end-of-run to override its natural
        # status decision (None means "decide naturally"). Mirrors the
        # native ``finish`` IPC op which lets a generator surface a
        # specific failure with a custom message instead of letting
        # the default success/cancel/exception paths choose.
        self._explicit_finish: tuple[bool, str] | None = None

        # Populated in start() (native: by _wait_and_cleanup; wasm: by
        # _run_wasm_supervised). is_running() tolerates it being None.
        self._cleanup_task: asyncio.Task | None = None

        # Watchdog task that kills the subprocess if it exceeds the
        # manifest-declared timeout. Stored so cancellation (on normal
        # exit / explicit stop) can cancel it.
        self._timeout_task: asyncio.Task | None = None

        # Per-run cache for _find_version_tip. A single chat session
        # resolves the same tip many times (one per input per merge
        # pass; several merges per turn); without this cache the walk
        # is O(N) per call and re-opens a DB connection each time.
        # Invalidated in _record_dag_cell_inner when a new
        # 'previous_version' edge is written — entries whose value
        # equals the old tip are re-pointed to the new cell id.
        self._tip_cache: dict[str, str] = {}

        # Set by the timeout watchdog; surfaced in the final status so
        # the frontend can render "Timed out" rather than "Failed".
        self.timeout_reason: str | None = None

    def append_settings_update(self, content: str, filename: str) -> None:
        """Record a mid-run settings update. Called by the
        /settings_continue endpoint after the user presses Continue.
        The entry is included in the finalization overlay alongside the
        initial settings and the log file."""
        self._settings_update_count += 1
        ext = os.path.splitext(filename or "")[1] or ""
        name_stem = f"update_settings_{self._settings_update_count}"
        self.settings_history.append((name_stem, ext, content))

    async def start(self):
        """Launch the generator subprocess with TCP-based IPC, OR (under wasm)
        dispatch the generator in-process via the collimate.wasm_sdk path."""
        from runtime import IS_WASM, WasmNotSupportedError
        if IS_WASM:
            manifest = self._load_manifest_for_runtime()
            rt = (manifest.get("runtime") or "native").lower()
            if rt not in ("wasm", "both"):
                raise WasmNotSupportedError(
                    f"Generator {self.generator_name!r} declares runtime {rt!r}. "
                    "Only generators with `runtime: wasm` (or `both`) can run "
                    "in the pyodide playground. Try the native backend."
                )
            # Dispatch the wasm run as a background task so POST /runs
            # returns immediately with status=running. The UI observes
            # progress via emit_partial + polling /api/state; _reap_process
            # awaits this task and cleans up active_managers when the
            # generator returns.
            self._cleanup_task = asyncio.create_task(
                self._run_wasm_supervised(manifest)
            )
            # Drive the same log-flush + SSE-broadcast pipeline native
            # uses. Without this, log_buffer entries (push_log,
            # key_requested, settings_update_requested) are appended but
            # never persisted to run_events / broadcast to the frontend,
            # so modals never appear and the run wedges on
            # "Starting pipeline". The writer's loop predicate honours
            # _cleanup_task, so it exits cleanly when the wasm dispatch
            # finishes.
            self._writer_task = asyncio.create_task(self._microbatch_writer())
            return

        env = self._build_subprocess_env()
        env["COLLIMATE_CHANNEL"] = self.channel
        env["COLLIMATE_RUN_ID"] = self.run_id
        env["COLLIMATE_WORKSPACE"] = self.workspace_dir
        merged_params = self._load_params_from_manifest()
        merged_params.update(self.params)
        env["COLLIMATE_PARAMS"] = json.dumps(merged_params)
        # Every run auto-creates a placeholder cell. The generator sees
        # it as its "first cell" and mutates it via update_cell().
        if self.placeholder_cell_id:
            env["COLLIMATE_IN_PLACE_CELL_ID"] = self.placeholder_cell_id

        # Add the SDK to PYTHONPATH so the generator subprocess can
        # ``import gen`` and ``import collimate``. The subprocess runs
        # under ``uv run`` which builds a *fresh* ephemeral env from the
        # generator's PEP 723 deps — that env does not inherit our
        # site-packages, so we have to point PYTHONPATH at where our
        # ``collimate`` package lives.
        #
        # Derive the dir from the imported ``collimate`` package itself
        # so this works in every install layout we care about:
        #
        #   * editable install (local dev, ``[tool.uv.sources]`` redirect):
        #     ``collimate.__file__`` → ``<sdk-repo>/src/collimate/__init__.py``
        #     → sdk_src = ``<sdk-repo>/src/`` (contains collimate/ + gen/).
        #   * pip-installed wheel (published collimate-sdk):
        #     ``collimate.__file__`` → ``<venv>/lib/.../site-packages/collimate/__init__.py``
        #     → sdk_src = ``<venv>/lib/.../site-packages/`` (contains both).
        #   * vendored / zipped: same shape — the parent of the package
        #     directory is always the right path.
        #
        # The previous version computed a hard-coded relative walk from
        # ``__file__``, which only worked for the sibling-source dev layout
        # and silently failed under any wheel install (PYTHONPATH would
        # point at a non-existent dir, ``import gen`` would 'no module').
        import collimate
        sdk_src = os.path.dirname(os.path.dirname(os.path.abspath(collimate.__file__)))
        existing = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = sdk_src + os.pathsep + existing if existing else sdk_src

        # Where this generator's runtime copy lives — `gen.shared()` uses
        # this to resolve its own ``shared/`` directory. The generator's
        # cwd already equals this, but we set the env var explicitly so
        # gen.shared() does not depend on cwd remaining unchanged.
        env["COLLIMATE_APP_DIR"] = self.app_dir

        # Source root of all generators on disk — `gen.shared("other")`
        # resolves cross-generator references against this. Points at the
        # bundled api/templates/generators tree by default.
        from genesis import GENERATORS_DIR
        env["COLLIMATE_GENERATORS_DIR"] = GENERATORS_DIR

        # Start a TCP server on an ephemeral port for IPC
        self._ipc_server = await asyncio.start_server(
            self._handle_ipc_connection, "127.0.0.1", 0
        )
        port = self._ipc_server.sockets[0].getsockname()[1]
        env["COLLIMATE_IPC_PORT"] = str(port)

        # limit=1MB on the StreamReader so line-buffered drains preserve
        # lines up to 1 MB before triggering the oversized-line path in
        # streams.py. Default (64 KB) was too small for verbose tool
        # output and routinely crashed the drain with LimitOverrunError.
        manifest_for_limits: dict = {}
        try:
            manifest_for_limits = self._load_manifest_for_runtime() or {}
        except Exception:
            manifest_for_limits = {}
        preexec = self._build_preexec_fn(manifest_for_limits)

        self.process = await asyncio.create_subprocess_exec(
            "uv", "run", self.entrypoint,
            cwd=self.app_dir,
            env=env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            stdin=asyncio.subprocess.PIPE,
            start_new_session=(os.name != "nt"),
            limit=1_048_576,
            preexec_fn=preexec,
        )

        # Start async readers
        self._stdout_task = asyncio.create_task(self._drain_stdout())
        self._stderr_task = asyncio.create_task(self._drain_stderr())
        self._writer_task = asyncio.create_task(self._microbatch_writer())
        self._cleanup_task = asyncio.create_task(self._wait_and_cleanup())

        # Per-generator timeout. The watchdog task reuses the same
        # SIGTERM→15s→SIGKILL ladder /stop uses. Two layers:
        #
        #   * manifest ``timeout_seconds`` — the generator author's
        #     stated upper bound (default 0 = no manifest limit).
        #   * ``HARD_WALLCLOCK_CAP_SECONDS`` — an absolute ceiling that
        #     always fires regardless of the manifest, so a runaway
        #     generator can't stay alive forever.
        #
        # We pick the smaller of the two when the manifest sets a value.
        timeout_seconds = self._HARD_WALLCLOCK_CAP_SECONDS
        try:
            raw = manifest_for_limits.get("timeout_seconds")
            if isinstance(raw, (int, float)) and raw > 0:
                timeout_seconds = min(int(raw), self._HARD_WALLCLOCK_CAP_SECONDS)
        except Exception:
            pass
        self._timeout_task = asyncio.create_task(
            self._enforce_timeout(timeout_seconds)
        )

    async def _enforce_timeout(self, seconds: int):
        """Kill the subprocess if it outlives the manifest-declared budget.

        No-op for wasm (different code path). For native: SIGTERM, wait
        15 s (same budget the /stop endpoint grants cleanup), then
        SIGKILL. Records the reason so the frontend renders "Timed out"
        instead of a bare "Failed".
        """
        import signal as _sig
        try:
            await asyncio.sleep(seconds)
        except asyncio.CancelledError:
            return
        if self.process is None or self.process.returncode is not None:
            return
        self.timeout_reason = f"Exceeded {seconds}s timeout"
        self.log_buffer.append({
            "type": "stderr",
            "payload": f"[timeout] Generator exceeded {seconds}s limit — terminating.\n",
        })
        pid = self.process.pid
        def _kill(signum):
            if os.name == "nt":
                if signum == _sig.SIGKILL:
                    self.process.kill()
                else:
                    self.process.terminate()
                return
            try:
                os.killpg(os.getpgid(pid), signum)
            except (ProcessLookupError, PermissionError, OSError):
                try:
                    os.kill(pid, signum)
                except (ProcessLookupError, PermissionError, OSError):
                    pass
        _kill(_sig.SIGTERM)
        try:
            await asyncio.wait_for(self.process.wait(), timeout=15.0)
        except asyncio.TimeoutError:
            _kill(_sig.SIGKILL)

    def _load_params_from_manifest(self) -> dict:
        """Extract default parameter values from manifest.gen_yaml in the app_dir."""
        manifest_path = os.path.join(self.app_dir, "manifest.gen_yaml")
        if not os.path.isfile(manifest_path):
            return {}
        try:
            import yaml
            with open(manifest_path, "r") as f:
                manifest = yaml.safe_load(f)
            params = manifest.get("parameters") or {}
            return {k: v.get("default", "") for k, v in params.items() if isinstance(v, dict)}
        except Exception:
            return {}

    # Hard wall-clock ceiling — a runaway generator that ignores its
    # manifest budget gets killed at this point regardless. 30 minutes
    # is generous for legitimate long-running daemons (chat sessions,
    # docker containers) while still bounding a stuck process.
    # Override per-deployment with COLLIMATE_HARD_WALLCLOCK_SECONDS.
    _HARD_WALLCLOCK_CAP_SECONDS = int(
        os.environ.get("COLLIMATE_HARD_WALLCLOCK_SECONDS") or 30 * 60
    )

    # Default rlimit ceilings for the generator subprocess. Conservative
    # so a fork-bomb / OOM-bomb / fd-leak doesn't take the host down,
    # but generous enough that legitimate work fits. Each is overridable
    # per-generator via the ``rlimits`` block in manifest.gen_yaml::
    #
    #     rlimits:
    #       memory_bytes: 4294967296   # 4 GB
    #       cpu_seconds:  900          # 15 min
    #       open_files:   1024
    # 8 GB rather than 2 GB because the rlimit is applied via preexec
    # before exec, so it constrains ``uv`` (Rust) too. uv's tokio runtime
    # mmap-reserves large virtual arenas per worker; resolving heavier
    # dep trees (e.g. pydantic-ai) blew past 2 GB of virtual address
    # space and panicked with "memory allocation of N bytes failed".
    _DEFAULT_RLIMIT_MEMORY_BYTES = 8 * 1024 * 1024 * 1024  # 8 GB
    # CPU is real CPU time (not wallclock); long-running daemons
    # (live_chat, claude_cli) accumulate it across a session. The
    # wallclock watchdog (_HARD_WALLCLOCK_CAP_SECONDS) is the actual
    # bound on runaway processes — RLIMIT_CPU is redundant safety, so
    # match the wallclock cap rather than firing earlier on legitimate
    # work.
    _DEFAULT_RLIMIT_CPU_SECONDS  = 30 * 60                 # 30 minutes
    # 1024 is the conventional Linux soft default. 256 was tight for
    # daemons holding concurrent sockets (HTTP pools, docker SDK,
    # IPC, log files) plus mmap'd configs.
    _DEFAULT_RLIMIT_OPEN_FILES   = 1024

    # Static allowlist — host vars every generator legitimately needs.
    # Anything outside this set must come through the keystore (user-blessed
    # via the UI) or the manifest's optional ``env_passthrough`` list.
    _ENV_ALLOWLIST: tuple[str, ...] = (
        "HOME", "PATH", "USER", "LOGNAME", "TZ",
        "LANG", "LANGUAGE",
        "TMPDIR", "TMP", "TEMP",
        "SHELL", "PWD",
        "PYTHONUNBUFFERED", "PYTHONIOENCODING",
        "SSL_CERT_FILE", "SSL_CERT_DIR", "REQUESTS_CA_BUNDLE",
        # Docker-using generators (claude_cli, vscode_env) need these to
        # reach the daemon. They're not secrets and the trust model is
        # single-tenant.
        "DOCKER_HOST", "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH",
    )

    _ENV_PREFIX_ALLOWLIST: tuple[str, ...] = (
        "COLLIMATE_",  # We set these explicitly later; passthrough preserves anything caller set
        "LC_",         # locale family (LC_ALL, LC_CTYPE, …)
    )

    @classmethod
    def _build_preexec_fn(cls, manifest: dict):
        """Return a preexec_fn that applies rlimits in the child process,
        or ``None`` on platforms that don't support it (Windows).

        Reading manifest values here keeps the subprocess launch site
        focused on the asyncio plumbing — manifests can override any of
        the three caps via an ``rlimits`` block; missing keys fall back
        to the class defaults.

        Each setrlimit is wrapped in try/except OSError because some
        kernels reject lowering past a hard limit; in that case we
        leave the child unconstrained on that axis rather than failing
        the whole launch — degrading gracefully beats the alternative.
        """
        if os.name == "nt":
            return None
        try:
            import resource
        except ImportError:
            return None

        def _read_limit(key: str, default: int) -> int:
            block = manifest.get("rlimits") if isinstance(manifest.get("rlimits"), dict) else {}
            raw = block.get(key) if block else None
            if isinstance(raw, (int, float)) and raw > 0:
                return int(raw)
            return default

        memory_bytes = _read_limit("memory_bytes", cls._DEFAULT_RLIMIT_MEMORY_BYTES)
        cpu_seconds  = _read_limit("cpu_seconds",  cls._DEFAULT_RLIMIT_CPU_SECONDS)
        open_files   = _read_limit("open_files",   cls._DEFAULT_RLIMIT_OPEN_FILES)

        def _apply():
            for rlimit_name, value in (
                ("RLIMIT_AS",     memory_bytes),
                ("RLIMIT_CPU",    cpu_seconds),
                ("RLIMIT_NOFILE", open_files),
            ):
                rlimit = getattr(resource, rlimit_name, None)
                if rlimit is None:
                    continue
                try:
                    resource.setrlimit(rlimit, (value, value))
                except (OSError, ValueError):
                    # Kernel refused the cap (e.g. exceeds the hard
                    # limit on this user). Leaving uncapped is safer
                    # than failing exec.
                    pass

        return _apply

    def _build_subprocess_env(self) -> dict[str, str]:
        """Build the generator's environment from an allowlist.

        Replaces the previous ``os.environ.copy()`` which leaked every host
        secret (AWS keys, GITHUB_TOKEN, etc.) into every generator. Three
        sources contribute to the final env:

        1. The static allowlist above (HOME/PATH/locale/temp dirs/Docker).
        2. Names registered with the keystore. The user explicitly granted
           these via the secrets UI, so forwarding them is intentional.
           ``ANTHROPIC_API_KEY`` etc. typically live here.
        3. The generator manifest's optional ``env_passthrough: [VAR, …]``
           list, for vars a generator legitimately needs that don't fit
           the keystore model (e.g. ``SSH_AUTH_SOCK`` for git_clone).

        Anything else is dropped.
        """
        env: dict[str, str] = {}

        for name in ProcessManager._ENV_ALLOWLIST:
            if name in os.environ:
                env[name] = os.environ[name]

        for name, value in os.environ.items():
            if any(name.startswith(p) for p in ProcessManager._ENV_PREFIX_ALLOWLIST):
                env[name] = value

        try:
            import keystore
            for name in keystore.list_names():
                if name in os.environ:
                    env[name] = os.environ[name]
        except Exception:
            # Keystore is best-effort — a failure here just means the
            # generator runs without persisted secrets, which is fine
            # for any generator that doesn't need them.
            pass

        try:
            import yaml
            manifest_path = os.path.join(self.app_dir, "manifest.gen_yaml")
            if os.path.isfile(manifest_path):
                with open(manifest_path, "r") as f:
                    manifest = yaml.safe_load(f) or {}
                passthrough = manifest.get("env_passthrough") or []
                if isinstance(passthrough, list):
                    for name in passthrough:
                        if isinstance(name, str) and name in os.environ:
                            env[name] = os.environ[name]
        except Exception:
            pass

        return env

    # ------------------------------------------------------------------
    # Universal run-state predicates (native + wasm)
    # ------------------------------------------------------------------

    def is_running(self) -> bool:
        """True if this manager still has a live worker that could respond
        to queued operations (push_message, etc.).

        Covers both backends:
          * Native — ``process`` alive and hasn't exited.
          * Wasm   — ``_cleanup_task`` has been scheduled and hasn't finished.
        """
        if self._cleanup_task is not None and not self._cleanup_task.done():
            return True
        if self.process is not None and self.process.returncode is None:
            return True
        return False
