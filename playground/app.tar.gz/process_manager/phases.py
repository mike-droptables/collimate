"""Run lifecycle phase vocabulary — the sub-state *within* a 'running' run.

Distinct from ``runs.status`` (the terminal-truth column: running / completed
/ failed / stopped). ``runs.phase`` is what drives the cell's "loading /
spinning up" vs "actively running" indicator, and is mirrored to the terminal
status at run end so a reconnecting client can render the right state.

This module is the single source of truth for the string values. The SDK
re-declares the same literals (``collimate/native.py``, ``collimate/wasm.py``)
because it can't import api modules — keep the two in sync.
"""

# Non-terminal progression, in order. The auto-machine only *advances*:
# a backend-auto transition to RUNNING is suppressed once the run is already
# past spinning_up (see _apply_phase's caller guards).
QUEUED = "queued"            # row inserted, generator not yet dispatched
SPINNING_UP = "spinning_up"  # subprocess/wasm dispatched, booting (imports,
                             # container pull, clone, model warm-up)
RUNNING = "running"          # real work underway
FINISHING = "finishing"      # committing results (optional, generator-set)

# Terminal — mirror of runs.status.
COMPLETED = "completed"
FAILED = "failed"
STOPPED = "stopped"

ACTIVE_PHASES = (QUEUED, SPINNING_UP, RUNNING, FINISHING)
TERMINAL_PHASES = (COMPLETED, FAILED, STOPPED)
ALL_PHASES = ACTIVE_PHASES + TERMINAL_PHASES

# Phases that an auto "running" fallback is allowed to overwrite (i.e. the run
# hasn't visibly started real work yet). Once a generator or the machine has
# set RUNNING/FINISHING/terminal, the auto fallback no-ops.
PRE_RUNNING_PHASES = (None, QUEUED, SPINNING_UP)


def is_terminal(phase: str | None) -> bool:
    return phase in TERMINAL_PHASES


def valid_phase(phase: str | None) -> bool:
    return phase in ALL_PHASES
