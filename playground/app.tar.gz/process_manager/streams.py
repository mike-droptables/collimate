"""Stream draining, microbatch writer, and SSE broadcast helpers."""
# pyright: reportAttributeAccessIssue=false
# (mixin: attributes like log_buffer/workspace_dir live on the composed
# ProcessManager in manager.py, not on the mixin class itself)

import asyncio
import re

from database import get_db_connection

# Matches 7-bit C1 ANSI sequences.
ANSI_ESCAPE_REGEX = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')


class StreamsMixin:
    # ------------------------------------------------------------------
    # Worker-liveness predicate — covers native (subprocess) + wasm
    # (in-process coroutine) so the same writer task drives both.
    # ------------------------------------------------------------------

    def _writer_should_continue(self) -> bool:
        # Native: keep flushing while the subprocess is alive. Don't key
        # off ``_cleanup_task`` here — on the native path that task IS
        # ``_wait_and_cleanup``, which itself awaits the writer; using
        # cleanup_task.done() as a predicate would deadlock.
        if self.process is not None and self.process.returncode is None:
            return True
        # Wasm: a dedicated flag set by _run_wasm_supervised. The
        # cleanup task IS the wasm dispatch, so we can't read its
        # done() from the writer for the same reason.
        if getattr(self, "_wasm_running", False):
            return True
        return False

    # ------------------------------------------------------------------
    # Stream draining — stdout/stderr go straight to log buffer
    # ------------------------------------------------------------------

    async def _drain_stdout(self):
        """Forward stdout to the log buffer (human-readable logs only).

        Line-buffered: reads until each newline so long lines are never
        split across event rows (which used to corrupt indentation and
        break downstream grep-style log searches).
        """
        assert self.process and self.process.stdout
        await self._drain_stream(self.process.stdout, "stdout")

    async def _drain_stderr(self):
        """Forward stderr to the log buffer (line-buffered, like stdout)."""
        assert self.process and self.process.stderr
        await self._drain_stream(self.process.stderr, "stderr")

    async def _drain_stream(self, stream: asyncio.StreamReader, kind: str):
        # Line-buffered drain. The subprocess is created with a 1 MB
        # StreamReader limit (see manager.py) so individual lines up to
        # that size stay intact; anything longer is flushed as a single
        # oversized row with a truncation tag rather than splitting on a
        # byte boundary mid-utf8.
        while True:
            try:
                chunk = await stream.readline()
            except ValueError:
                # LimitOverrunError-path: a single line > 1 MB. Drain the
                # available buffer in chunks and tag as truncated.
                chunk = await stream.read(1_048_576)
                if chunk:
                    chunk = b"[log line > 1 MB; truncated] " + chunk
            if not chunk:
                break
            clean = ANSI_ESCAPE_REGEX.sub("", chunk.decode("utf-8", errors="replace"))
            if clean:
                self.log_buffer.append({"type": kind, "payload": clean})
                # First real output ⇒ the generator is doing work, not just
                # spinning up. Idempotent (no-ops once past spinning_up).
                self._maybe_auto_running()

    # ------------------------------------------------------------------
    # Microbatch SQLite writer
    # ------------------------------------------------------------------

    async def _microbatch_writer(self):
        """Writes logs to SQLite in batches every 500ms to prevent DB locks.

        Skips the thread-pool round-trip on idle ticks — when nothing has
        been appended since the last flush, there is nothing to write, so
        paying for a thread switch just to run an early-return is pure
        overhead (fires ~2x/sec per live run, multiplied by every run).

        After the worker exits we keep looping as long as the buffer is
        non-empty (e.g. the last _flush_log_buffer put items back because
        all three DB write attempts failed) so the retry eventually wins
        rather than silently dropping the tail.

        Runs for both backends — native (subprocess) and wasm (in-process
        coroutine). The "worker is alive" check covers both: a live
        subprocess (returncode is None) OR an unfinished wasm cleanup
        task. Without this, wasm runs would buffer key_requested /
        settings_update_requested / push_log entries forever and never
        surface them to the frontend, leaving the cell wedged on
        "Starting pipeline" with no modal ever appearing.
        """
        while self._writer_should_continue():
            await asyncio.sleep(0.5)
            if not self.log_buffer:
                continue
            await self._flush_inline_or_threaded()

        # Final flush after process exits. If the flush re-queues the batch
        # (write errors), back off and retry up to ~5s before giving up so
        # we don't spin forever when the DB is genuinely unreachable.
        await asyncio.sleep(0.1)
        for _ in range(10):
            if not self.log_buffer:
                break
            await self._flush_inline_or_threaded()
            if self.log_buffer:
                await asyncio.sleep(0.5)

    async def _flush_inline_or_threaded(self) -> None:
        # Pyodide 0.28 has no working pthread, so ``asyncio.to_thread``
        # parks forever waiting on a worker that never runs. Call the
        # flush inline under wasm — single-threaded already, so the
        # thread offload buys nothing anyway. Native keeps the offload
        # so a slow sqlite write doesn't stall the event loop.
        from runtime import IS_WASM
        if IS_WASM:
            self._flush_log_buffer()
        else:
            await asyncio.to_thread(self._flush_log_buffer)

    def _flush_log_buffer(self):
        if not self.log_buffer:
            return
        batch = []
        while True:
            try:
                batch.append(self.log_buffer.popleft())
            except IndexError:
                break
        if not batch:
            return
        import time as _time
        for attempt in range(3):
            try:
                conn = get_db_connection(self.channel)
                conn.executemany(
                    "INSERT INTO run_events (run_id, event_type, payload) VALUES (?, ?, ?)",
                    [(self.run_id, item["type"], item["payload"]) for item in batch],
                )
                conn.commit()
                # Read back the ids + created_at we just wrote so we can
                # broadcast each event through the per-channel SSE stream
                # (see _broadcast_run_events below — routed through the
                # channel's single SSE to avoid per-run EventSource cap).
                rows = conn.execute(
                    "SELECT id, event_type, payload, created_at "
                    "FROM run_events WHERE run_id=? ORDER BY id DESC LIMIT ?",
                    (self.run_id, len(batch)),
                ).fetchall()
                conn.close()
                self._broadcast_run_events(reversed(rows))
                return
            except Exception:
                if attempt < 2:
                    _time.sleep(0.3)
                # Last attempt failed — put items back so the next flush
                # picks them up rather than losing log lines, and tag a
                # single warning row so the user sees that the log stream
                # had trouble persisting.
                else:
                    self.log_buffer.extendleft(reversed(batch))
                    if not getattr(self, "_flush_warn_emitted", False):
                        self.log_buffer.append({
                            "type": "stderr",
                            "payload": "[logs] DB write failed 3x — retrying. Some log ordering may be delayed.\n",
                        })
                        self._flush_warn_emitted = True

    def _broadcast_run_status(self, status: str) -> None:
        """Announce a run's terminal status on the channel SSE.

        Emitted in two spots: the explicit ``finish`` IPC handler (clean
        shutdown initiated by the generator) and ``_finalize_run_status``
        (process exit without a finish message). The frontend uses this
        as the signal to close its in-memory run state and render the
        final status — a replacement for the old per-run SSE's synthetic
        ``stream_end`` event.
        """
        from events import broadcast
        broadcast(self.channel, {
            "type": "run_status",
            "run_id": self.run_id,
            "status": status,
        })

    def _broadcast_run_phase(self, phase: str, message: str = "") -> None:
        """Announce a run's lifecycle phase on the channel SSE.

        Parallels ``_broadcast_run_status`` but for the within-run phase
        (queued → spinning_up → running → terminal). The frontend drives the
        cell's loading/spinning-up vs actively-running indicator straight off
        this message — no log parsing — so it lands immediately, ahead of the
        eventual ``type=phase`` run_event (which carries the drawer log line).
        """
        from events import broadcast
        broadcast(self.channel, {
            "type": "run_phase",
            "run_id": self.run_id,
            "phase": phase,
            "message": message,
        })

    def _apply_phase(self, phase: str, message: str = "") -> None:
        """Transition the run to ``phase`` — the single apply point shared by
        the backend-auto machine and the generator-driven path (gen.phase).

        Three idempotent side-effects behind a no-op guard:
          1. Persist the authoritative ``runs.phase`` column (so reconnect can
             recover it in one read — see queries.fetch_run_events_since).
          2. Append a ``type="phase"`` row to ``log_buffer`` — rides the
             existing microbatch flush, so it persists to run_events AND
             reaches the drawer's canonical log like any other event.
          3. Broadcast ``run_phase`` on the channel SSE for the indicator.

        Synchronous on purpose: the DB write is a single tiny UPDATE (same
        shape as _op_finish's status write) so it runs inline under both
        native (async IPC handlers) and wasm (no asyncio.to_thread, which
        parks forever under pyodide). Phase is a *lifecycle* signal — fired a
        handful of times per run — not per-item progress (that's gen.progress),
        so the per-call connection open/close is well within budget.
        """
        from process_manager.phases import valid_phase
        if not valid_phase(phase):
            return
        # No-op guard: suppress duplicate rows when the auto-machine and a
        # generator converge on the same (phase, message). Load-bearing for
        # wasm, where every redundant call is a blocking sqlite write.
        if phase == self.current_phase and message == self.current_phase_message:
            return
        self.current_phase = phase
        self.current_phase_message = message

        from database import get_db_connection
        try:
            conn = get_db_connection(self.channel)
            conn.execute(
                "UPDATE runs SET phase=? WHERE id=?", (phase, self.run_id),
            )
            conn.commit()
            conn.close()
        except Exception:
            # A failed phase write is non-fatal — the run_event row (below)
            # still records the transition and drives the drawer; only the
            # single-read reconnect shortcut is degraded.
            pass

        import json
        self.log_buffer.append({
            "type": "phase",
            "payload": json.dumps({"phase": phase, "message": message}),
        })
        self._broadcast_run_phase(phase, message)

    def _maybe_auto_running(self) -> None:
        """Advance to ``running`` the first time the generator shows real
        activity (first update_cell or first stdout/stderr), unless it has
        already moved past spinning_up. Idempotent via _apply_phase's guard
        plus the PRE_RUNNING gate so an explicit gen.phase() isn't clobbered.
        """
        from process_manager.phases import RUNNING, PRE_RUNNING_PHASES
        if self.current_phase in PRE_RUNNING_PHASES:
            self._apply_phase(RUNNING)

    def _broadcast_run_events(self, rows) -> None:
        """Push freshly-persisted run_events rows through the channel SSE.

        Funnels every run's event stream through the single per-channel
        EventSource the frontend already maintains, so opening many chat
        cells doesn't exhaust the browser's per-host HTTP/1.1 connection
        cap (~6) with a persistent EventSource per run.
        """
        from events import broadcast
        for row in rows:
            broadcast(self.channel, {
                "type": "run_event",
                "run_id": self.run_id,
                "event": {
                    "id": row["id"],
                    "type": row["event_type"],
                    "payload": row["payload"],
                    "created_at": row["created_at"],
                },
            })
