"""Composition: parent-bound child generator runs + renderer compile.

Implements the host side of the SDK's `gen.spawn` / `gen.call` /
`gen.generators` / `gen.check_renderer` capabilities (see
collimate-sdk `_host.py` for the request/ack contract). A child run is an
ordinary `ProcessManager` run in a fresh isolated workspace with a
**detached** placeholder cell — its `update_cell` writes DB rows but
`_apply_update_to_state` no-ops because the cell isn't in any stack, so the
child is invisible on the canvas. Output is collected from the child's
workspace (matching the SDK's host-free `run_generator` semantics). Children
are parent-bound: every one is stopped when the parent run ends.

All file contents cross IPC in the SDK's `_encode_files` shape:
`{path: {"text": s} | {"b64": b64}}`.
"""
from __future__ import annotations

import asyncio
import base64
import os
import shutil
import tempfile
import threading
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional

import yaml

from database import get_db_connection

# Recursion cap (defence-in-depth alongside the SDK's client-side guard).
_MAX_CALL_DEPTH = 8

_COLRESERVED = ".colreserved"


# ---------------------------------------------------------------------------
# Parent←child event stream (the streaming twin of run→UI streaming).
#
# A child sub-run pushes typed events via the SDK's gen.emit_event (IPC op
# "sub_run_emit"); the host buffers them here keyed by the child's sub_run_id,
# and the parent drains them in order via "sub_run_poll_events"
# (gen handle.events()). Token deltas are best-effort live display — the
# authoritative output is still the child's result files. Buffer is registered
# at spawn (so a parentless top-level run's events are simply dropped) and
# popped on teardown. A safety cap bounds memory if a parent never drains.
# ---------------------------------------------------------------------------

_SUB_RUN_EVENTS: dict[str, dict] = {}     # sub_run_id -> {"events": list, "base": int}
_SUB_RUN_EVENTS_LOCK = threading.Lock()
_SUB_RUN_EVENTS_CAP = 8192


def record_sub_run_event(child_mgr, data: dict) -> None:
    """Append a child-emitted event to its parent-bound buffer. Called on the
    CHILD's IPC connection (``child_mgr`` is the child's ProcessManager, whose
    ``run_id`` is the sub_run_id). Drops the event for an unregistered run
    (a parentless top-level run)."""
    sid = getattr(child_mgr, "run_id", "") or ""
    ev = data.get("event")
    if not sid or not isinstance(ev, dict):
        return
    with _SUB_RUN_EVENTS_LOCK:
        rec = _SUB_RUN_EVENTS.get(sid)
        if rec is None:
            return
        rec["events"].append(ev)
        overflow = len(rec["events"]) - _SUB_RUN_EVENTS_CAP
        if overflow > 0:
            del rec["events"][:overflow]
            rec["base"] += overflow


def sub_run_poll_events(parent, data: dict) -> dict:
    """Drain events past ``cursor`` for one child + report its run state.
    Called on the PARENT's IPC connection. Single monotonic consumer, so the
    consumed prefix is compacted to bound memory."""
    sub_run_id = data.get("sub_run_id", "")
    cursor = int(data.get("cursor", 0) or 0)
    with _SUB_RUN_EVENTS_LOCK:
        rec = _SUB_RUN_EVENTS.get(sub_run_id)
        if rec is None:
            out, new_cursor = [], cursor
        else:
            start = cursor - rec["base"]
            if start < 0:
                start = 0
            out = rec["events"][start:]
            new_cursor = rec["base"] + len(rec["events"])
            if start > 0:
                rec["events"] = rec["events"][start:]
                rec["base"] = cursor
    # Read state AFTER draining so any just-emitted tail events are returned
    # alongside a terminal state (the parent does one more empty poll to exit).
    state = sub_run_status(parent, {"sub_run_id": sub_run_id}).get("state", "failed")
    return {
        "op": "ack_sub_run_poll_events",
        "events": out,
        "cursor": new_cursor,
        "state": state,
    }


# ---------------------------------------------------------------------------
# File (de)serialisation (mirror of collimate._results._encode_files)
# ---------------------------------------------------------------------------


def _decode_files(encoded: Optional[dict]) -> dict:
    out: dict = {}
    for path, payload in (encoded or {}).items():
        if not isinstance(payload, dict):
            out[path] = "" if payload is None else str(payload)
        elif "b64" in payload:
            try:
                out[path] = base64.b64decode(payload["b64"])
            except (ValueError, TypeError):
                out[path] = b""
        else:
            out[path] = payload.get("text", "")
    return out


def _encode_files(files: Optional[dict]) -> dict:
    out: dict = {}
    for path, content in (files or {}).items():
        if isinstance(content, bytes):
            out[path] = {"b64": base64.b64encode(content).decode("ascii")}
        else:
            out[path] = {"text": content if isinstance(content, str) else str(content)}
    return out


def _is_reserved(rel: str) -> bool:
    return rel == _COLRESERVED or rel.startswith(_COLRESERVED + "/") or rel.startswith(_COLRESERVED + os.sep)


def _normalize_env_spec(env) -> Optional[dict]:
    """Mirror of collimate._results._env_spec_from_dict — manifest
    ``environment`` (true / mapping) → normalized contract dict; None/False →
    not an environment."""
    if env is None or env is False:
        return None
    if env is True:
        env = {}
    if not isinstance(env, dict):
        return None
    return {
        "exec": bool(env.get("exec", True)),
        "exec_background": bool(env.get("exec_background", True)),
        "expose_port": bool(env.get("expose_port", True)),
        "files": str(env.get("files", "read-write")),
        "terminals": int(env.get("terminals", 0) or 0),
        "watch": bool(env.get("watch", False)),
        "concurrent_exec": bool(env.get("concurrent_exec", False)),
    }


def _read_env_spec(app_dir: str) -> Optional[dict]:
    """Read ``environment`` from a materialized source's manifest.gen_yaml."""
    for root, _dirs, files in os.walk(app_dir):
        if "manifest.gen_yaml" in files:
            try:
                with open(os.path.join(root, "manifest.gen_yaml"), encoding="utf-8") as fh:
                    m = yaml.safe_load(fh) or {}
                if isinstance(m, dict):
                    return _normalize_env_spec(m.get("environment"))
            except Exception:
                return None
    return None


# ---------------------------------------------------------------------------
# Child handle
# ---------------------------------------------------------------------------


@dataclass
class ChildSubRun:
    sub_run_id: str
    manager: Any
    workspace_dir: str
    app_dir: str
    surface: Optional[dict] = None
    env_spec: Optional[dict] = None  # manifest `environment` (the contract), if any
    _ack: Optional[dict] = field(default=None)  # cached terminal result


# ---------------------------------------------------------------------------
# Workspace / source materialisation
# ---------------------------------------------------------------------------


def _write_file(base: str, rel: str, content) -> None:
    # Containment: rel comes from LLM/IPC-controlled file maps (inline source,
    # inputs, config). Reject absolute / backslash / .. escapes before writing,
    # mirroring artifacts._hash_artifacts and runs.helpers._safe_dest_under.
    if not isinstance(rel, str) or not rel or os.path.isabs(rel) or "\\" in rel:
        raise ValueError(f"unsafe sub-run path: {rel!r}")
    base_real = os.path.realpath(base)
    full = os.path.realpath(os.path.join(base_real, rel))
    if full != base_real and not full.startswith(base_real + os.sep):
        raise ValueError(f"sub-run path escapes workspace: {rel!r}")
    os.makedirs(os.path.dirname(full) or base_real, exist_ok=True)
    if isinstance(content, bytes):
        with open(full, "wb") as fh:
            fh.write(content)
    else:
        with open(full, "w", encoding="utf-8") as fh:
            fh.write(content if isinstance(content, str) else str(content))


def _seed_workspace(workspace_dir: str, *, inputs: dict, input_groups: dict,
                    prompt: str, config: dict) -> None:
    os.makedirs(os.path.join(workspace_dir, _COLRESERVED), exist_ok=True)
    _write_file(workspace_dir, os.path.join(_COLRESERVED, "prompt.md"), prompt or "")
    for rel, content in (inputs or {}).items():
        _write_file(workspace_dir, rel, content)
    for label, files in (input_groups or {}).items():
        for rel, content in (files or {}).items():
            _write_file(workspace_dir, os.path.join("inputs", label, rel), content)
    cfg = config or {}
    if cfg:
        cfg_dir = os.path.join(workspace_dir, _COLRESERVED, "config", "files")
        os.makedirs(cfg_dir, exist_ok=True)
        for name, values in cfg.items():
            if name.lower().endswith(".json"):
                import json
                _write_file(cfg_dir, name, json.dumps(values))
            else:
                _write_file(cfg_dir, name, yaml.safe_dump(values if isinstance(values, dict) else {}))


def _materialize_source(source: dict, run_id: str, app_root: str, channel: str | None = None) -> tuple[str, str]:
    """Return (app_dir, entrypoint). For an inline source, write its files
    into ``app_root``; for an installed id, copy the generator's dir tree
    (incl. ``_*`` siblings) into ``app_root`` like routes/runs/create.py does.

    ``channel`` (a db-name slug) scopes installed-id resolution to the parent
    run's channel so a child run never materializes a generator from a
    different channel that the UI happens to have active.
    """
    if isinstance(source, dict) and "inline" in source:
        inline = source.get("inline") or {}
        files = _decode_files(inline.get("files"))
        entry = inline.get("entrypoint") or ""
        if not entry:
            raise ValueError("inline source missing 'entrypoint'")
        for rel, content in files.items():
            _write_file(app_root, rel, content)
        return app_root, entry

    # Installed id.
    gen_id = (source or {}).get("id") if isinstance(source, dict) else None
    if not gen_id:
        raise ValueError("source must be {'id': ...} or {'inline': {...}}")
    from routes.runs.helpers import _find_generator_dir, _read_manifest

    gen_dir = _find_generator_dir(gen_id, channel)
    if not gen_dir:
        raise ValueError(f"generator {gen_id!r} not found")
    manifest = _read_manifest(gen_dir)
    entry = manifest.get("entrypoint") or f"{gen_id}.py"
    # Copy the whole temp tree (gen dir + _* siblings) into app_root,
    # mirroring create_run so sibling imports resolve.
    gen_tmp_root = os.path.dirname(gen_dir)
    gen_subdir = os.path.basename(gen_dir)
    for item in os.listdir(gen_tmp_root):
        src = os.path.join(gen_tmp_root, item)
        dst = os.path.join(app_root, item)
        if os.path.isdir(src):
            shutil.copytree(src, dst, dirs_exist_ok=True)
        else:
            shutil.copy2(src, dst)
    return os.path.join(app_root, gen_subdir), entry


# ---------------------------------------------------------------------------
# Spawn / wait / stop
# ---------------------------------------------------------------------------


async def spawn_sub_run(parent, data: dict) -> dict:
    """Start a parent-bound child run. Returns the ack dict for
    ``ack_start_sub_run`` ({ok, sub_run_id, error?})."""
    from process_manager.manager import ProcessManager
    from routes.runs.registry import active_managers

    # Trust the host-assigned depth on the parent handle, NOT the client-echoed
    # data["call_depth"] (a generator can spoof that to reset the guard).
    parent_depth = int(parent.call_depth or 0)
    child_depth = parent_depth + 1
    if child_depth > _MAX_CALL_DEPTH:
        return {"op": "ack_start_sub_run", "ok": False,
                "error": f"max sub-run depth ({_MAX_CALL_DEPTH}) exceeded"}

    # Cell-exposure gate: refuse to run an installed generator whose source
    # cell is turned off "to generators" (exposed-by-default). Inline sources
    # (arbitrary code, no installed id) aren't gated — there's no cell to gate
    # them by. ``_cid is None`` (generator/cell not found) falls through
    # un-blocked, the same fail-open posture the old manifest default had — so
    # gen.call("agent") keeps working even on a flaky manifest read.
    _src = data.get("source") or {}
    _gid = _src.get("id") if isinstance(_src, dict) and "inline" not in _src else None
    if _gid:
        from channel_config import read_cell_exposure, cell_exposed
        from routes.runs.helpers import _generator_cell_id
        _cid = _generator_cell_id(_gid, parent.channel)
        if _cid is not None and not cell_exposed(read_cell_exposure(parent.channel), _cid):
            return {"op": "ack_start_sub_run", "ok": False,
                    "error": f"generator {_gid!r}'s cell is not exposed to generators"}

    sub_run_id = str(uuid.uuid4())
    runs_tmp_root = os.path.abspath(os.path.join(".collimate", "tmp"))
    os.makedirs(runs_tmp_root, exist_ok=True)
    app_dir = tempfile.mkdtemp(prefix=f"subapp_{sub_run_id[:8]}_", dir=runs_tmp_root)
    workspace_dir = tempfile.mkdtemp(prefix=f"subws_{sub_run_id[:8]}_", dir=runs_tmp_root)

    def _prepare():
        # Blocking fs + sqlite work — runs off the event loop via to_thread.
        gen_app_dir, entrypoint = _materialize_source(data.get("source") or {}, sub_run_id, app_dir, parent.channel)
        _seed_workspace(
            workspace_dir,
            inputs=_decode_files(data.get("inputs")),
            input_groups={k: _decode_files(v) for k, v in (data.get("input_groups") or {}).items()},
            prompt=data.get("prompt", "") or "",
            config=data.get("config") or {},
        )
        conn = get_db_connection(parent.channel)
        try:
            conn.execute(
                "INSERT INTO runs (id, prompt, status) VALUES (?, ?, 'running')",
                (sub_run_id, data.get("prompt", "") or ""),
            )
            conn.commit()
        finally:
            conn.close()
        return gen_app_dir, entrypoint

    child = None
    try:
        gen_app_dir, entrypoint = await asyncio.to_thread(_prepare)

        # A detached placeholder cell: never inserted into channel state, so
        # the child's update_cell writes DB rows but stays invisible.
        detached_cell = str(uuid.uuid4())

        child = ProcessManager(
            channel=parent.channel,
            run_id=sub_run_id,
            app_dir=gen_app_dir,
            workspace_dir=workspace_dir,
            entrypoint=entrypoint,
            generator_name=f"sub:{(data.get('source') or {}).get('id', 'inline')}",
            params={},
            placeholder_cell_id=detached_cell,
            input_cell_ids=[],
            invocation_type=(data.get("invocation_type") or "create"),
            call_depth=child_depth,
            secrets_allowlist=(data.get("secrets") or None),
        )
        active_managers[sub_run_id] = child
        parent._sub_runs[sub_run_id] = ChildSubRun(
            sub_run_id=sub_run_id, manager=child,
            workspace_dir=workspace_dir, app_dir=app_dir,
            surface=data.get("surface"),
            env_spec=_read_env_spec(gen_app_dir),
        )
        with _SUB_RUN_EVENTS_LOCK:
            _SUB_RUN_EVENTS[sub_run_id] = {"events": [], "base": 0}
        await child.start()
        return {"op": "ack_start_sub_run", "ok": True, "sub_run_id": sub_run_id}
    except BaseException as exc:
        # BaseException so a CancelledError mid-start() still unwinds the
        # registries and kills the process — otherwise an already-spawned
        # child would be deregistered (or half-registered) with nobody left
        # holding a handle to it.
        import signal
        child_proc = getattr(child, "process", None)
        if child_proc is not None and child_proc.returncode is None:
            if os.name == "nt":
                try:
                    child_proc.kill()
                except (ProcessLookupError, OSError):
                    pass
            else:
                _signal_child_pg(child_proc.pid, signal.SIGKILL)
        shutil.rmtree(app_dir, ignore_errors=True)
        shutil.rmtree(workspace_dir, ignore_errors=True)
        from routes.runs.registry import active_managers as _am
        _am.pop(sub_run_id, None)
        parent._sub_runs.pop(sub_run_id, None)
        with _SUB_RUN_EVENTS_LOCK:
            _SUB_RUN_EVENTS.pop(sub_run_id, None)
        # Don't leave the inserted row stuck 'running' (no reaper owns it).
        try:
            conn = get_db_connection(parent.channel)
            conn.execute("UPDATE runs SET status='failed' WHERE id=? AND status='running'", (sub_run_id,))
            conn.commit()
            conn.close()
        except Exception:
            pass
        if not isinstance(exc, Exception):
            raise  # CancelledError etc. — propagate after cleanup
        return {"op": "ack_start_sub_run", "ok": False, "error": str(exc)}


def _collect_workspace_files(workspace_dir: str) -> dict:
    """Every workspace file (str if utf-8 else bytes), excluding
    .colreserved — matches the SDK's fs_list / run_generator result.files.

    Containment: an environment's workspace is a read-write bind-mount running
    the env author's arbitrary code, so it can plant symlinks pointing outside
    the tree. Never follow a symlink (file or dir) out of the workspace — read
    only regular files whose real path stays under it — so a container can't
    exfiltrate host files (``/etc/shadow``, SSH keys, other runs) back to a
    parent via files()/snapshot()/list_files()."""
    out: dict = {}
    if not os.path.isdir(workspace_dir):
        return out
    base_real = os.path.realpath(workspace_dir)
    # followlinks=False (default) already refuses to descend symlinked dirs;
    # filtering them out of `dirs` makes that explicit alongside the reserved skip.
    for root, dirs, files in os.walk(workspace_dir):
        dirs[:] = [
            d for d in dirs
            if not _is_reserved(os.path.relpath(os.path.join(root, d), workspace_dir))
            and not os.path.islink(os.path.join(root, d))
        ]
        for fname in files:
            if fname.startswith(".collimate_messages"):
                continue
            abs_path = os.path.join(root, fname)
            rel = os.path.relpath(abs_path, workspace_dir).replace("\\", "/")
            if _is_reserved(rel):
                continue
            if os.path.islink(abs_path):
                continue
            real = os.path.realpath(abs_path)
            if real != base_real and not real.startswith(base_real + os.sep):
                continue
            try:
                with open(abs_path, "rb") as fh:
                    raw = fh.read()
                try:
                    out[rel] = raw.decode("utf-8")
                except UnicodeDecodeError:
                    out[rel] = raw
            except OSError:
                continue
    return out


def _child_status_row(parent, sub_run_id: str) -> Optional[str]:
    conn = get_db_connection(parent.channel)
    try:
        row = conn.execute("SELECT status FROM runs WHERE id=?", (sub_run_id,)).fetchone()
    finally:
        conn.close()
    return row["status"] if row else None


def _child_failure_detail(parent, sub_run_id: str, status: Optional[str]) -> tuple:
    """Pull (error, traceback) for a failed child from the persisted
    run_events — the in-memory log_buffer is flushed+cleared during the
    child's cleanup, so it's empty by the time we read it."""
    import json as _json

    conn = get_db_connection(parent.channel)
    try:
        rows = conn.execute(
            "SELECT event_type, payload FROM run_events WHERE run_id=? "
            "AND event_type IN ('finish','stderr','ipc_error') ORDER BY id",
            (sub_run_id,),
        ).fetchall()
    except Exception:
        rows = []
    finally:
        conn.close()
    finish_err = None
    tail: list = []
    for r in rows:
        et, payload = r["event_type"], (r["payload"] or "")
        if et == "finish":
            try:
                finish_err = (_json.loads(payload) or {}).get("error_message")
            except Exception:
                pass
        else:
            tail.append(payload)
    error = (finish_err or "").strip() or f"sub-run {status or 'failed'}"
    traceback = ("\n".join(tail[-40:]))[-4000:] or None
    return error, traceback


def _build_result_ack(parent, child: ChildSubRun) -> dict:
    status = _child_status_row(parent, child.sub_run_id)
    ok = status == "completed"
    files = _collect_workspace_files(child.workspace_dir)
    error = traceback = None
    if not ok:
        error, traceback = _child_failure_detail(parent, child.sub_run_id, status)
    return {
        "op": "ack_sub_run_wait",
        "ok": ok,
        "name": child.manager._last_emit_cell_name,
        "summary": child.manager._last_emit_summary,
        "pinned": None,
        "files": _encode_files(files),
        "endpoints": _endpoints_for(child),
        "logs": [],
        "statuses": [],
        "error": error,
        "traceback": traceback,
    }


def _endpoints_for(child: ChildSubRun) -> list:
    eps = []
    for port in sorted(child.manager.bound_ports or set()):
        eps.append({"kind": "http", "name": "preview", "url": None, "port": port,
                    "path": "", "session_id": None})
    return eps


async def wait_sub_run(parent, data: dict) -> dict:
    sub_run_id = data.get("sub_run_id", "")
    child = parent._sub_runs.get(sub_run_id)
    if child is None:
        return {"op": "ack_sub_run_wait", "ok": False, "error": "no such sub-run"}
    if child._ack is not None:
        return child._ack
    timeout = data.get("timeout")
    task = getattr(child.manager, "_cleanup_task", None)
    try:
        if task is not None:
            if timeout is None:
                await asyncio.shield(task)
            else:
                await asyncio.wait_for(asyncio.shield(task), float(timeout))
    except asyncio.TimeoutError:
        files = await asyncio.to_thread(_collect_workspace_files, child.workspace_dir)
        await _stop_child(parent, child)
        ack = {"op": "ack_sub_run_wait", "ok": False, "error": "timed out",
               "files": _encode_files(files)}
        child._ack = ack
        return ack
    except Exception as exc:
        return {"op": "ack_sub_run_wait", "ok": False, "error": f"sub-run wait failed: {exc}"}
    # _build_result_ack does sqlite + fs-walk — keep it off the event loop.
    ack = await asyncio.to_thread(_build_result_ack, parent, child)
    child._ack = ack
    return ack


def sub_run_endpoints(parent, data: dict) -> dict:
    child = parent._sub_runs.get(data.get("sub_run_id", ""))
    return {"op": "ack_sub_run_endpoints",
            "endpoints": _endpoints_for(child) if child else []}


def sub_run_status(parent, data: dict) -> dict:
    sub_run_id = data.get("sub_run_id", "")
    child = parent._sub_runs.get(sub_run_id)
    if child is None:
        return {"op": "ack_sub_run_status", "state": "failed"}
    proc = child.manager.process
    if proc is not None and proc.returncode is None:
        return {"op": "ack_sub_run_status", "state": "running"}
    status = _child_status_row(parent, sub_run_id)
    return {"op": "ack_sub_run_status", "state": "done" if status == "completed" else "failed"}


def sub_run_files(parent, data: dict) -> dict:
    child = parent._sub_runs.get(data.get("sub_run_id", ""))
    files = _collect_workspace_files(child.workspace_dir) if child else {}
    return {"op": "ack_sub_run_files", "files": _encode_files(files)}


# Grace a child sub-run gets to exit on SIGTERM before SIGKILL. Matches the
# spirit of the per-run /stop ladder (control.py) while staying inside the
# parent's own shutdown grace at stop-all time.
_STOP_CHILD_GRACE_SECONDS = 10.0


def _signal_child_pg(pid: int, sig) -> None:
    """Signal the child's whole process group (it was spawned with
    start_new_session=True), falling back to the bare pid."""
    if os.name == "nt":
        return
    try:
        os.killpg(os.getpgid(pid), sig)
    except (ProcessLookupError, PermissionError, OSError):
        try:
            os.kill(pid, sig)
        except (ProcessLookupError, PermissionError, OSError):
            pass


async def _stop_child(parent, child: ChildSubRun) -> None:
    """Stop the child with the standard SIGTERM → grace → SIGKILL ladder,
    reap any containers it left behind, then drop it from both registries
    and reclaim its temp dirs. Idempotent. Callers that need the workspace
    (wait-timeout) must read it BEFORE calling this."""
    from routes.runs.registry import active_managers
    import signal
    proc = child.manager.process
    if proc is not None and proc.returncode is None:
        if os.name == "nt":
            try:
                proc.terminate()
            except (ProcessLookupError, OSError):
                pass
        else:
            _signal_child_pg(proc.pid, signal.SIGTERM)
        # Wait for the group to actually die before deleting its workspace;
        # a SIGTERM-ignoring child would otherwise outlive every registry
        # reference and become unreachable by any later teardown.
        try:
            await asyncio.wait_for(proc.wait(), timeout=_STOP_CHILD_GRACE_SECONDS)
        except asyncio.TimeoutError:
            if os.name == "nt":
                try:
                    proc.kill()
                except (ProcessLookupError, OSError):
                    pass
            else:
                _signal_child_pg(proc.pid, signal.SIGKILL)
            try:
                await asyncio.wait_for(proc.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                pass
    # Backstop: force-remove any Docker container the child started (labeled
    # with its sub_run_id). Top-level runs get this from _reap_process; child
    # sub-runs are never routed through it, so without this a SIGKILLed child
    # leaks a live container until the next server boot's orphan sweep.
    try:
        from routes.runs.helpers import _reap_run_containers
        await asyncio.to_thread(_reap_run_containers, child.sub_run_id)
    except Exception:
        pass
    # Fail any in-flight routed requests so a parent awaiting an env reply
    # doesn't hang for the full budget after the child is gone.
    st = getattr(child.manager, "_col_env_state", None)
    if st:
        for fut in list(st.get("replies", {}).values()):
            if fut is not None and not fut.done():
                fut.set_result({"ok": False, "rc": -1, "error": "environment is gone"})
        st["replies"].clear()
    active_managers.pop(child.sub_run_id, None)
    if parent._sub_runs is not None:
        parent._sub_runs.pop(child.sub_run_id, None)
    with _SUB_RUN_EVENTS_LOCK:
        _SUB_RUN_EVENTS.pop(child.sub_run_id, None)
    shutil.rmtree(child.app_dir, ignore_errors=True)
    shutil.rmtree(child.workspace_dir, ignore_errors=True)


async def stop_sub_run(parent, data: dict) -> None:
    child = parent._sub_runs.get(data.get("sub_run_id", ""))
    if child is not None:
        await _stop_child(parent, child)


async def stop_all_sub_runs(parent) -> None:
    """Parent-bound teardown: stop every child this run spawned. Called from
    the parent's _wait_and_cleanup."""
    for child in list(parent._sub_runs.values()):
        try:
            await _stop_child(parent, child)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Environments — capability discovery, workspace plane, and parent↔child
# request routing (the host side of gen.serve_environment + handle.exec/...).
#
# The workspace plane (put/read/delete/list/snapshot) is host-serviced against
# the child's workspace dir — the env bind-mounts that dir read-write, so the
# container sees pushed files and their writes flow back. The execution plane
# (exec/exec_background/expose_port/open_terminal/wait/stop) is routed to the
# child's own process: the parent enqueues a request on the child manager's
# env queue, the child's serve_environment_poll delivers it, the child runs its
# handler and serve_environment_reply resolves the parent's future. Parent and
# child managers share the host's single event loop, so the queue + futures
# bridge them without locks.
# ---------------------------------------------------------------------------


def _env_state(mgr):
    st = getattr(mgr, "_col_env_state", None)
    if st is None:
        st = {"queue": asyncio.Queue(), "replies": {}, "spec": None}
        mgr._col_env_state = st
    return st


def sub_run_capabilities(parent, data: dict) -> dict:
    child = parent._sub_runs.get(data.get("sub_run_id", ""))
    spec = getattr(child, "env_spec", None) if child else None
    return {"op": "ack_sub_run_capabilities", "environment": spec}


async def sub_run_route(parent, data: dict, kind: str, ack_op: str) -> dict:
    """Route an execution-plane request to the child environment and await its
    reply. Fails closed with a typed error distinct from any rc."""
    child = parent._sub_runs.get(data.get("sub_run_id", ""))
    if child is None:
        return {"op": ack_op, "ok": False, "error": "no such sub-run"}
    mgr = child.manager
    proc = getattr(mgr, "process", None)
    if proc is not None and proc.returncode is not None:
        return {"op": ack_op, "ok": False, "error": "environment is gone"}
    st = _env_state(mgr)
    request_id = uuid.uuid4().hex
    req = {"request_id": request_id, "kind": kind}
    for k in ("command", "cwd", "env", "port", "process_id", "timeout"):
        if k in data and data[k] is not None:
            req[k] = data[k]
    loop = asyncio.get_event_loop()
    fut = loop.create_future()
    st["replies"][request_id] = fut
    await st["queue"].put(req)
    # Reply before the SDK's emit_and_wait gives up: exec waits timeout+30,
    # other routed ops wait the 60s default — stay just under each.
    budget = (float(data["timeout"]) + 20.0) if data.get("timeout") else 50.0
    try:
        result = await asyncio.wait_for(asyncio.shield(fut), budget)
    except asyncio.TimeoutError:
        st["replies"].pop(request_id, None)
        return {"op": ack_op, "ok": False, "error": "environment did not reply in time"}
    return {"op": ack_op, **(result if isinstance(result, dict) else {})}


async def sub_run_route_oneway(parent, data: dict, kind: str) -> None:
    """Route a fire-and-forget request (stop_process) — no reply awaited."""
    child = parent._sub_runs.get(data.get("sub_run_id", ""))
    if child is None:
        return
    st = _env_state(child.manager)
    req = {"request_id": uuid.uuid4().hex, "kind": kind}
    for k in ("process_id", "command", "cwd", "env", "port"):
        if k in data and data[k] is not None:
            req[k] = data[k]
    await st["queue"].put(req)


# --- environment side (the child serving its parent) ---


def serve_environment_register(mgr, data: dict) -> dict:
    st = _env_state(mgr)
    st["spec"] = data.get("spec") or {}
    return {"op": "ack_serve_environment_register", "ok": True}


async def serve_environment_poll(mgr, data: dict) -> dict:
    st = _env_state(mgr)
    timeout = float(data.get("timeout") or 30.0)
    try:
        req = await asyncio.wait_for(st["queue"].get(), timeout)
    except asyncio.TimeoutError:
        return {"op": "ack_serve_environment_poll", "request": None}
    return {"op": "ack_serve_environment_poll", "request": req}


def serve_environment_reply(mgr, data: dict) -> None:
    st = _env_state(mgr)
    fut = st["replies"].pop(data.get("request_id", ""), None)
    if fut is not None and not fut.done():
        fut.set_result(data.get("result") or {})


# --- workspace plane (host-serviced against the child's workspace dir) ---


def _safe_child_path(child: ChildSubRun, rel: str) -> Optional[str]:
    if not isinstance(rel, str) or not rel or os.path.isabs(rel) or "\\" in rel:
        return None
    # ``.colreserved/`` is the child's private SDK/host state (its prompt, config,
    # logs). The enumerating ops filter it via _collect_workspace_files; the
    # per-file ops must too, so a parent generator can't read/delete it through a
    # GeneratorHandle.
    if _is_reserved(rel):
        return None
    base_real = os.path.realpath(child.workspace_dir)
    full = os.path.realpath(os.path.join(base_real, rel))
    if full != base_real and not full.startswith(base_real + os.sep):
        return None
    return full


def sub_run_put_files(parent, data: dict) -> dict:
    child = parent._sub_runs.get(data.get("sub_run_id", ""))
    if child is None:
        return {"op": "ack_sub_run_put_files", "ok": False, "error": "no such sub-run"}
    try:
        for rel, content in _decode_files(data.get("files")).items():
            if _is_reserved(rel):
                continue  # never let a parent write/overwrite a child's .colreserved
            _write_file(child.workspace_dir, rel, content)
        return {"op": "ack_sub_run_put_files", "ok": True}
    except Exception as exc:
        return {"op": "ack_sub_run_put_files", "ok": False, "error": str(exc)}


def sub_run_read_file(parent, data: dict) -> dict:
    child = parent._sub_runs.get(data.get("sub_run_id", ""))
    if child is None:
        return {"op": "ack_sub_run_read_file", "ok": False}
    rel = data.get("path", "")
    full = _safe_child_path(child, rel) if child else None
    if not full or not os.path.isfile(full):
        return {"op": "ack_sub_run_read_file", "ok": False}
    try:
        with open(full, "rb") as fh:
            raw = fh.read()
        try:
            content = raw.decode("utf-8")
        except UnicodeDecodeError:
            content = raw
        return {"op": "ack_sub_run_read_file", "ok": True, "file": _encode_files({rel: content})}
    except OSError:
        return {"op": "ack_sub_run_read_file", "ok": False}


def sub_run_delete_file(parent, data: dict) -> dict:
    child = parent._sub_runs.get(data.get("sub_run_id", ""))
    full = _safe_child_path(child, data.get("path", "")) if child else None
    try:
        if full and os.path.isfile(full):
            os.remove(full)
        return {"op": "ack_sub_run_delete_file", "ok": True}
    except OSError:
        return {"op": "ack_sub_run_delete_file", "ok": False}


def sub_run_list_files(parent, data: dict) -> dict:
    child = parent._sub_runs.get(data.get("sub_run_id", ""))
    files = _collect_workspace_files(child.workspace_dir) if child else {}
    return {"op": "ack_sub_run_list_files", "files": sorted(files.keys())}


def sub_run_snapshot(parent, data: dict) -> dict:
    import hashlib

    child = parent._sub_runs.get(data.get("sub_run_id", ""))
    files = _collect_workspace_files(child.workspace_dir) if child else {}
    snap = {}
    for p, c in files.items():
        b = c.encode("utf-8") if isinstance(c, str) else c
        snap[p] = hashlib.sha256(b).hexdigest()
    return {"op": "ack_sub_run_snapshot", "snapshot": snap}


async def surface_sub_run(parent, data: dict) -> dict:
    """Promote the child's output to a visible side cell in the parent's
    stack. Returns {cell_id}."""
    sub_run_id = data.get("sub_run_id", "")
    child = parent._sub_runs.get(sub_run_id)
    if child is None:
        return {"op": "ack_surface_sub_run", "cell_id": ""}
    spec = data.get("spec") or {}
    name = spec.get("name") or "Sub-run"
    files = _collect_workspace_files(child.workspace_dir)
    artifacts = [
        {"type": "memory", "cell_path": rel,
         "content": content if isinstance(content, str) else base64.b64encode(content).decode("ascii"),
         "encoding": "utf-8" if isinstance(content, str) else "base64"}
        for rel, content in files.items()
    ]
    try:
        await asyncio.to_thread(parent._create_side_cell, {"artifacts": artifacts, "name": name})
        cell_id = parent._last_cell_id or ""
        parent._broadcast_dag_commit()
    except Exception:
        cell_id = ""
    return {"op": "ack_surface_sub_run", "cell_id": cell_id}


# ---------------------------------------------------------------------------
# list_generators
# ---------------------------------------------------------------------------


def _read_generator_introspection(m: dict, cell, manifest_prefix: str) -> dict:
    """The ``{description, draft_files, config_tags}`` introspection payload for
    one generator, read from its manifest + co-located ``.set_yaml`` draft files
    so an LLM caller can build a valid ``config=`` for gen.call/gen.spawn without
    guessing. ``manifest_prefix`` is the manifest path minus
    ``manifest.gen_yaml`` (the generator's dir within the cell), so draft files
    resolve relative to the manifest exactly like the run dispatcher does."""
    from config_tags import parse_set_yaml, resolve_config_tags

    by_rel = {f.name: f.content for f in cell.files}

    def read_rel(rel: str):
        return by_rel.get(manifest_prefix + rel)

    draft_files = []
    for rel in (m.get("draft_files") or []):
        if not isinstance(rel, str) or not rel.endswith(".set_yaml"):
            continue
        fields, _resolved = parse_set_yaml(read_rel(rel) or "")
        draft_files.append({
            "path": rel,
            "fields": [
                {
                    "key": fld.get("key"),
                    "type": fld.get("type", "text"),
                    "label": fld.get("label", ""),
                    "description": fld.get("description", ""),
                    "required": bool(fld.get("required", False)),
                    "default": fld.get("default", None),
                    "options": list(fld.get("options") or []),
                }
                for fld in fields
            ],
        })

    # resolve_config_tags → [{name, prompt, values:{rel:{k:v}}, missing_required}].
    # Forward only name/prompt/values (the ready-made config= overlay).
    config_tags = [
        {"name": t.get("name", ""), "prompt": t.get("prompt"), "values": t.get("values") or {}}
        for t in resolve_config_tags(m, read_rel)
    ]
    return {
        "description": m.get("description") or m.get("summary") or "",
        "draft_files": draft_files,
        "config_tags": config_tags,
    }


def list_installed_generators(channel: str) -> list:
    """GeneratorInfo dicts for every installed, EXPOSED generator (the SDK's
    gen.generators()). ``channel`` (a channel db_name) is REQUIRED and scopes
    both the cell list and the exposure gate to the run's own channel —
    discovery and the spawn_sub_run gate read the same per-cell exposure, so
    they can't disagree, and a run never sees another channel's generators.

    Gating is now CELL-level (``cell_exposure``, exposed-by-default): a cell the
    user turned off is invisible to discovery AND un-callable/un-readable (the
    spawn gate + cross-cell read/write enforce the same flag). Each entry also
    carries introspection — ``cell_id`` (for gen.read_cell/write_cell),
    ``config_tags`` and ``draft_files`` (the callee's config schema)."""
    try:
        from routes.runs.helpers import _get_all_generator_cells
    except Exception:
        return []
    from channel_config import read_cell_exposure, cell_exposed
    exposure = read_cell_exposure(channel)
    out: list = []
    seen: set = set()
    for cell in _get_all_generator_cells(channel) or []:
        # Cell-level exposure gate (default EXPOSED). A cell turned off hides
        # every generator it declares from programmatic discovery at once.
        if not cell_exposed(exposure, str(cell.id)):
            continue
        for f in cell.files:
            if not f.name.endswith("manifest.gen_yaml"):
                continue
            try:
                m = yaml.safe_load(f.content) or {}
            except Exception:
                continue
            if not isinstance(m, dict):
                continue
            gid = m.get("id")
            if not gid or gid in seen:
                continue
            seen.add(gid)
            manifest_prefix = f.name[:-len("manifest.gen_yaml")]
            intro = _read_generator_introspection(m, cell, manifest_prefix)
            cells = (m.get("inputs") or {}).get("cells") or {}
            types = m.get("type") if isinstance(m.get("type"), list) else []
            is_chat = bool(m.get("chat"))
            out.append({
                "id": gid,
                "name": m.get("name") or gid,
                "summary": m.get("summary") or "",
                "description": intro["description"],
                # Group = the generator-source cell's name (mirrors the
                # catalog's `group`); replaces the old free-form category.
                "group": cell.name or None,
                "cell_id": str(cell.id),
                "type": types,
                "daemon": bool(m.get("daemon")) or is_chat,
                "chat": is_chat,
                "ephemeral": bool(m.get("ephemeral")),
                "min_inputs": int(cells.get("min", 0) or 0),
                "max_inputs": int(cells.get("max", 0) or 0),
                "prompt_intent": m.get("prompt_intent"),
                "prompt_required": bool(m.get("prompt_required")),
                "environment": _normalize_env_spec(m.get("environment")),
                "draft_files": intro["draft_files"],
                "config_tags": intro["config_tags"],
            })
    out.sort(key=lambda d: d["name"].lower())
    return out


# ---------------------------------------------------------------------------
# check_renderer — esbuild compile via the SDK's offline checker
# ---------------------------------------------------------------------------


def _locate_check_renderer_script() -> Optional[str]:
    # collimate/__init__.py lives at <sdk_root>/src/collimate/__init__.py
    # (editable/source layout); scripts/ is a sibling of src/. Try a couple
    # of ancestors so both the src layout and a flat layout resolve.
    try:
        import collimate
        pkg_init = os.path.abspath(collimate.__file__)
        for up in (3, 2):
            root = pkg_init
            for _ in range(up):
                root = os.path.dirname(root)
            cand = os.path.join(root, "scripts", "check_renderer.mjs")
            if os.path.isfile(cand):
                return cand
    except Exception:
        pass
    return None


async def check_renderer_files(files: dict, entrypoint: str) -> dict:
    """Run the SDK's esbuild renderer checker over staged files. Degrades to
    ok=True (skipped) when node or the checker isn't available, so it never
    blocks a generator on hosts without a JS toolchain."""
    import json as _json

    if shutil.which("node") is None:
        return {"ok": True, "errors": [], "warnings": ["renderer compile check skipped: node unavailable"]}
    script = _locate_check_renderer_script()
    if script is None:
        return {"ok": True, "errors": [], "warnings": ["renderer compile check skipped: checker not found"]}

    decoded = _decode_files(files)
    tmp = tempfile.mkdtemp(prefix="colrendchk_")
    try:
        for rel, content in decoded.items():
            _write_file(tmp, rel, content)
        # Ensure a manifest entrypoint exists for the checker's resolver.
        if not any(r.endswith("manifest.rend_yaml") for r in decoded):
            _write_file(tmp, "manifest.rend_yaml",
                        f"id: chk\nname: Check\nversion: 0.0.0\nsummary: check\n"
                        f"entrypoint: {entrypoint}\nembed: native\nsupports_diff: false\n")
        proc = await asyncio.create_subprocess_exec(
            "node", script, tmp, "--json",
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=120.0)
        except asyncio.TimeoutError:
            try:
                proc.kill()
            except ProcessLookupError:
                pass
            # Reap so the killed checker doesn't linger as a zombie.
            try:
                await asyncio.wait_for(proc.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                pass
            return {"ok": False, "errors": ["renderer compile timed out"], "warnings": []}
        except asyncio.CancelledError:
            # Run teardown while a check is in flight — don't orphan node.
            try:
                proc.kill()
            except ProcessLookupError:
                pass
            raise
        try:
            data = _json.loads(stdout.decode("utf-8", "replace"))
            results = data.get("results") or []
            errors, warnings = [], []
            for r in results:
                errors.extend(r.get("errors") or [])
                warnings.extend(r.get("warnings") or [])
            return {"ok": all(r.get("ok") for r in results) if results else False,
                    "errors": errors, "warnings": warnings}
        except Exception:
            return {"ok": False, "errors": [f"compile check failed: {stderr.decode('utf-8','replace')[:2000]}"], "warnings": []}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
