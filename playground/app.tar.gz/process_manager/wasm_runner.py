"""WASM in-process dispatch (pyodide playground).

Wasm generators run in-process inside the same pyodide VM as the host.
No subprocess, no TCP IPC, no streaming stdout — the generator's
``async def run()`` is awaited directly in the host event loop, with
the ``gen`` singleton hydrated beforehand so the generator can read
inputs and stage outputs via plain ``gen.*`` calls.

The cell-write path goes through the host's ``emit_partial`` (called
from ``gen.update``) so each call lands as an ``update_cell_initial``
just like a native run's first commit.
"""

import asyncio
import base64
import json
import os
import time
import uuid

from database import get_db_connection


def _file_artifact(path: str, content: "str | bytes") -> dict:
    """Build the ``artifacts`` list entry the manager's
    ``_update_cell_initial`` / ``_create_side_cell`` expects.

    Text rides as utf-8; bytes ride as base64 with
    ``encoding: "base64"`` — the artifacts pipeline already handles the
    decode step (see ``api/process_manager/artifacts.py``).
    """
    if isinstance(content, bytes):
        return {
            "type": "memory",
            "cell_path": path,
            "content": base64.b64encode(content).decode("ascii"),
            "encoding": "base64",
        }
    return {
        "type": "memory",
        "cell_path": path,
        "content": content,
        "encoding": "utf-8",
    }


class WasmRunnerMixin:
    def _load_manifest_for_runtime(self) -> dict:
        """Load the generator's manifest.gen_yaml without running the full
        _load_params_from_manifest pipeline. Used to check the `runtime` field
        before deciding how to dispatch."""
        import yaml
        mp = os.path.join(self.app_dir, "manifest.gen_yaml")
        if not os.path.isfile(mp):
            return {}
        try:
            with open(mp, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        except (yaml.YAMLError, OSError):
            return {}

    async def _run_wasm(self, manifest: dict) -> None:
        """Drive a wasm-runtime generator in-process.

        1. Hydrate the WasmContext (config files, messages, prompt).
        2. Hydrate the ``gen`` singleton with that context.
        3. Import the generator module and ``await run()`` (zero-arg).
        4. Cell state is already persisted via ``gen.update`` calls
           routed through the host's ``emit_partial`` — no final
           translation step needed.
        5. Flip the run row to completed (or failed on exception).
        """
        import importlib.util
        import sys as _sys
        import traceback

        from collimate import wasm as _gen_module
        from collimate.wasm_sdk import KeyRequestCancelled, Message, WasmContext

        # ``_wasm_run_t0`` is the run start timestamp, used by the
        # exception-path traceback print below to report wall time at
        # failure. Other timing instrumentation was removed once the
        # sequence_num collision was fixed.
        self._wasm_run_t0 = time.perf_counter()

        try:
            # ── 1. Hydrate the context ──
            config_files: dict[str, str] = {}
            config_dir = os.path.join(self.workspace_dir, ".colreserved", "config", "files")
            if os.path.isdir(config_dir):
                for name in sorted(os.listdir(config_dir)):
                    p = os.path.join(config_dir, name)
                    if os.path.isfile(p):
                        try:
                            with open(p, "r", encoding="utf-8") as f:
                                config_files[name] = f.read()
                        except OSError:
                            pass

            messages: list[Message] = []
            msgs_path = os.path.join(
                self.workspace_dir, ".colreserved", ".collimate_messages.json"
            )
            if os.path.isfile(msgs_path):
                try:
                    with open(msgs_path, "r", encoding="utf-8") as f:
                        raw = json.load(f)
                    if isinstance(raw, list):
                        messages = [
                            Message(
                                role=m.get("role", "user"),
                                content=m.get("content", ""),
                                timestamp=m.get("timestamp", ""),
                            )
                            for m in raw if isinstance(m, dict)
                        ]
                except (json.JSONDecodeError, OSError):
                    pass

            merged_params = self._load_params_from_manifest()
            merged_params.update(self.params)

            # Load the primary prompt that runs.py wrote to
            # .colreserved/prompt.md. Same semantic as the native SDK's
            # gen.prompt: empty string when no prompt was provided.
            prompt_text = ""
            prompt_path = os.path.join(self.workspace_dir, ".colreserved", "prompt.md")
            if os.path.isfile(prompt_path):
                try:
                    with open(prompt_path, "r", encoding="utf-8") as pf:
                        prompt_text = pf.read()
                except OSError:
                    pass

            ctx = WasmContext(
                workspace=self.workspace_dir,
                params=merged_params,
                channel=self.channel,
                run_id=self.run_id,
                prompt=prompt_text,
                config_files=config_files,
                messages=messages,
                placeholder_cell_id=self.placeholder_cell_id,
                _host=self,  # satisfies wasm_sdk.WasmHost protocol
            )

            # ── 2. Load the generator module ──
            script_path = os.path.join(self.app_dir, self.entrypoint)
            if not os.path.isfile(script_path):
                raise FileNotFoundError(
                    f"Wasm generator entrypoint not found: {script_path}"
                )
            mod_name = f"_collimate_wasm_gen_{uuid.uuid4().hex}"
            spec = importlib.util.spec_from_file_location(mod_name, script_path)
            if spec is None or spec.loader is None:
                raise RuntimeError(f"Cannot build module spec for {script_path}")
            module = importlib.util.module_from_spec(spec)
            _sys.modules[mod_name] = module
            try:
                spec.loader.exec_module(module)
                if not hasattr(module, "run"):
                    raise RuntimeError(
                        f"Wasm generator {self.generator_name!r} must export "
                        f"`async def run()` (no arguments); found no "
                        f"`run` attribute."
                    )

                # ── 3. Hydrate the gen singleton, invoke run(), clear it.
                # ``gen.Cancelled`` is what ``gen.api_key`` / ``gen.secret``
                # raise on user cancel — translated from the underlying
                # ``KeyRequestCancelled``. Treat both as a clean stop.
                run_fn = module.run
                _gen_module._set_context(ctx)
                try:
                    try:
                        if asyncio.iscoroutinefunction(run_fn):
                            await run_fn()
                        else:
                            # Sync ``def run()`` is fine for trivial
                            # cases. Pyodide 0.28 has no working pthread,
                            # so ``asyncio.to_thread`` parks forever —
                            # call directly. The generator owns
                            # cooperative cancellation if it's long-running.
                            run_fn()
                    except (KeyRequestCancelled, _gen_module.Cancelled) as exc:
                        self._cancelled = True
                        self.push_log(f"[wasm_run] {exc}")
                finally:
                    _gen_module._clear_context()

            finally:
                _sys.modules.pop(mod_name, None)

            # ── 4. Cell state is already persisted via the host's
            # emit_partial handler on every gen.update() call. Generators
            # that never call gen.update() leave the placeholder empty —
            # explicit by design.
            cell_name = (
                self._last_emit_cell_name
                or self.generator_name
                or "Output"
            )

            # ── 5. Mark the run completed.
            # Stopped takes precedence over a natural completion when
            # the user hit Stop or cancelled a key prompt.
            status = "stopped" if self._cancelled else "completed"
            conn = get_db_connection(self.channel)
            try:
                conn.execute(
                    "UPDATE runs SET status=? WHERE id=?", (status, self.run_id)
                )
                conn.commit()
            finally:
                conn.close()

            self.log_buffer.append({
                "type": "stdout",
                "payload": f"[wasm_run] {status}: {cell_name}"
                           f"{' (after ' + str(self._emit_partial_called) + ' partial emits)' if self._emit_partial_called else ''}",
            })
            # Broadcast the terminal status — the frontend's
            # runStatusHandlers fires off this SSE message to flip the
            # cell out of "running". Native does it via
            # _finalize_run_status; wasm has no equivalent finalizer,
            # so emit it here.
            self._broadcast_run_status(status)

        except Exception:
            # Record the failure — don't re-raise. The supervised wrapper
            # will complete the _cleanup_task so _reap_process can pop us
            # from active_managers cleanly. ``print`` ensures the
            # traceback hits the pyodide console even when the
            # log_buffer drain races with shutdown — without it, the
            # exception path was silent in the WASM playground and a
            # crashed run looked indistinguishable from a hang.
            tb = traceback.format_exc()
            print(
                f"[wasm_run FAILED] run={self.run_id[:8]} "
                f"after {(time.perf_counter() - self._wasm_run_t0) * 1000.0:.1f}ms\n"
                f"{tb}",
                flush=True,
            )
            self.log_buffer.append({
                "type": "stderr",
                "payload": "[wasm_run] " + tb,
            })
            conn = get_db_connection(self.channel)
            try:
                conn.execute(
                    "UPDATE runs SET status=? WHERE id=?", ("failed", self.run_id)
                )
                conn.commit()
            finally:
                conn.close()
            self._broadcast_run_status("failed")

    async def _run_wasm_supervised(self, manifest: dict) -> None:
        """Wrapper for _run_wasm that always completes cleanly so the task
        (stored as _cleanup_task) can be awaited by _reap_process without
        leaking active_managers on generator exceptions.

        Owns the ``_wasm_running`` liveness flag the microbatch writer
        reads. Setting it True before the dispatch and False in
        ``finally`` lets the writer keep flushing through the run and
        exit cleanly once we're done — without needing to read
        ``_cleanup_task.done()`` (which is this very task and would
        deadlock the writer's await chain on the native path)."""
        self._wasm_running = True
        try:
            await self._run_wasm(manifest)
        except Exception:
            # _run_wasm already logged + recorded the failure.
            pass
        finally:
            self._wasm_running = False

    # ---- WasmHost protocol (used by wasm generators via WasmContext) ----

    async def emit_partial(
        self,
        *,
        files: dict[str, "str | bytes"] | None = None,
        cell_name: str | None = None,
        summary: str | None = None,
        summary_artifact: str | None = None,
        chat_messages: list | None = None,
    ) -> None:
        """Push a mid-run snapshot. Writes files via _update_cell_initial,
        refreshes the in-memory channel state, and yields so concurrent
        pollers can observe the new state. ``files`` values may be
        ``str`` (utf-8 text) or ``bytes`` — bytes go through
        ``encoding: base64`` so they round-trip into the CAS as raw."""
        # Counter (not boolean) so the run-end log line can show
        # "after N partial emits" instead of "after True partial emits".
        self._emit_partial_called = (self._emit_partial_called or 0) + 1
        if cell_name is not None:
            self._last_emit_cell_name = cell_name
        if summary is not None:
            self._last_emit_summary = summary
        if summary_artifact is not None:
            self._last_emit_summary_artifact = summary_artifact

        artifacts = [
            _file_artifact(path, content)
            for path, content in (files or {}).items()
        ]
        if chat_messages:
            artifacts.append({
                "type": "memory",
                "cell_path": ".colreserved/.collimate_messages.json",
                "content": json.dumps(
                    [m.to_dict() for m in chat_messages], indent=2
                ),
                "encoding": "utf-8",
            })

        data: dict = {"artifacts": artifacts}
        # Use last-known values if the caller didn't supply — keeps the UI
        # stable if a generator only wants to update one facet per emit.
        data["name"] = (
            cell_name
            if cell_name is not None
            else (self._last_emit_cell_name or self.generator_name or "Output")
        )
        data["summary"] = (
            summary
            if summary is not None
            else (self._last_emit_summary or "")
        )
        # ``summary_artifact`` only flows through when explicitly set —
        # otherwise the cell record's existing value (manifest default
        # or a previous override) stays in place.
        sa = (
            summary_artifact
            if summary_artifact is not None
            else getattr(self, "_last_emit_summary_artifact", None)
        )
        if sa is not None:
            data["summary_artifact"] = sa

        # Run the DB+state update synchronously but yield to the event
        # loop so concurrent /api/state pollers can see the new state.
        self._update_cell_initial(data)
        # Broadcast a dag_commit so the frontend's iframe pool fans out
        # FILES_CHANGED to any sandboxed renderer mounted on this cell
        # (milkdown summary pane, monaco file view, etc.). Without it,
        # ``persist_state`` already fires the SSE ``state_update`` so the
        # store cache updates, but the SSE handler only triggers the
        # iframe FILES_CHANGED fanout on ``dag_commit`` — leaving the
        # renderer stuck on whatever content it had at mount, even after
        # subsequent emits replace the file. The wasm-runtime polling
        # path catches updated_at changes itself, so this is a no-op
        # there; it only matters when a wasm generator runs under the
        # native (SSE) host.
        try:
            self._broadcast_dag_commit()
        except Exception as exc:
            self.log_buffer.append({
                "type": "stderr",
                "payload": f"[emit_partial broadcast error] {exc}",
            })
        await asyncio.sleep(0)

    def is_cancelled(self) -> bool:
        """True once the user has POSTed to the interrupt endpoint."""
        return self._cancelled

    def push_log(self, line: str) -> None:
        """Append a line to the run's log buffer."""
        self.log_buffer.append({"type": "stdout", "payload": line})

    def poll_user_message(self):
        """Pop and return the next queued user message, or None.

        The ``POST /api/channels/{c}/cells/{id}/chat/push_message``
        endpoint appends to ``_pending_user_messages``. Wasm generators
        reach this via ``gen.next_message()`` /
        ``async for ... in gen.chat_loop()``."""
        if not self._pending_user_messages:
            return None
        content = self._pending_user_messages.pop(0)
        from collimate.wasm_sdk import Message
        return Message(role="user", content=content)

    def set_status(self, message: str) -> None:
        """Surface a live status string to the UI. Reachable via
        ``gen.status(msg)``."""
        self.log_buffer.append({
            "type": "status",
            "payload": json.dumps({"status": "running", "message": message}),
        })

    async def create_side_cell(
        self,
        *,
        name: str | None = None,
        summary: str | None = None,
        summary_artifact: str | None = None,
        files: dict[str, "str | bytes"] | None = None,
    ) -> str:
        """Append a new sibling cell. Wraps the manager's existing
        ``_create_side_cell`` (which native runs reach via the
        ``create_side_cell`` IPC op). Returns the new cell's id.
        ``files`` values may be ``str`` or ``bytes``; bytes ride the
        ``encoding: base64`` path."""
        artifacts = [
            _file_artifact(path, content)
            for path, content in (files or {}).items()
        ]
        data: dict = {"artifacts": artifacts}
        if name is not None:
            data["name"] = name
        if summary is not None:
            data["summary"] = summary
        if summary_artifact is not None:
            data["summary_artifact"] = summary_artifact
        # Pyodide 0.28 has no working pthread, so ``asyncio.to_thread``
        # parks forever waiting on a worker that never runs. Call
        # ``_create_side_cell`` inline — it's sync DB I/O but wasm is
        # single-threaded anyway, so the thread offload bought nothing.
        self._create_side_cell(data)
        # _broadcast_dag_commit is sync (just publishes events), so
        # call directly. Mirrors what the native ipc.py path does
        # right after _create_side_cell returns.
        try:
            self._broadcast_dag_commit()
        except Exception as exc:
            self.log_buffer.append({
                "type": "stderr",
                "payload": f"[create_side_cell broadcast error] {exc}",
            })
        await asyncio.sleep(0)
        return self._last_cell_id or ""

    async def request_key(
        self,
        key_name: str,
        description: str = "",
        force: bool = False,
    ) -> str:
        """WasmHost.request_key — wraps :meth:`await_key_value`.

        Native generators reach the same flow via the ``request_key``
        IPC op; wasm generators reach it via
        ``await ctx.get_key(name, description)``. Both routes share the
        same broadcast / wait / clear plumbing on the manager so the
        ``KeyRequestOverlay`` and ``/key_continue`` endpoint work
        unchanged.

        Re-raises :class:`collimate.wasm_sdk.KeyRequestCancelled` on
        user cancel — translating from the manager-internal
        ``ipc.KeyRequestCancelled`` to the SDK-public type so wasm
        generators can catch it without crossing module boundaries.
        """
        from collimate.wasm_sdk import KeyRequestCancelled as _SDKCancelled
        from .ipc import KeyRequestCancelled as _MgrCancelled
        try:
            return await self.await_key_value(
                key_name=key_name,
                description=description,
                force=force,
            )
        except _MgrCancelled as exc:
            raise _SDKCancelled(exc.key_name) from None
