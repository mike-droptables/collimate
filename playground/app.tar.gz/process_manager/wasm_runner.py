"""WASM in-process dispatch (pyodide playground).

Wasm generators run in-process inside the same pyodide VM as the host.
No subprocess, no TCP IPC, no streaming stdout — the generator's
``async def run()`` is awaited directly in the host event loop, with
the ``gen`` singleton hydrated beforehand so the generator can read
inputs and stage outputs via plain ``gen.*`` calls.

The cell-write path goes through ``HostMixin.emit_partial`` (shared
with the native IPC dispatch) so each call lands as an
``update_cell_initial`` just like a native run's first commit. The
7 host-protocol methods (emit_partial, is_cancelled, push_log,
set_status, poll_user_message, create_side_cell, request_key) live
in ``host.py``; this mixin only owns the wasm-specific dispatch
glue (``_run_wasm`` / ``_run_wasm_supervised`` /
``_load_manifest_for_runtime``).
"""
# pyright: reportAttributeAccessIssue=false
# (mixin: attributes like log_buffer/workspace_dir live on the composed
# ProcessManager in manager.py, not on the mixin class itself)

import asyncio
import json
import os
import time
import uuid

from database import get_db_connection


class WasmRunnerMixin:
    def _load_manifest_for_runtime(self) -> dict:
        """Load the generator's manifest.gen_yaml without running the full
        _load_params_from_manifest pipeline. Used to check the `runtime` field
        before deciding how to dispatch."""
        import yaml
        mp = os.path.join(self.app_dir, "manifest.gen_yaml")
        if not os.path.isfile(mp):
            return {}
        try:
            with open(mp, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        except (yaml.YAMLError, OSError):
            return {}

    async def _run_wasm(self, manifest: dict) -> None:
        """Drive a wasm-runtime generator in-process.

        1. Hydrate the WasmContext (config files, messages, prompt).
        2. Hydrate the ``gen`` singleton with that context.
        3. Import the generator module and ``await run()`` (zero-arg).
        4. Cell state is already persisted via ``gen.update`` calls
           routed through the host's ``emit_partial`` — no final
           translation step needed.
        5. Flip the run row to completed (or failed on exception).
        """
        import importlib.util
        import sys as _sys
        import traceback

        from collimate import wasm as _gen_module
        from collimate.wasm_sdk import KeyRequestCancelled, Message, WasmContext

        # ``_wasm_run_t0`` is the run start timestamp, used by the
        # exception-path traceback print below to report wall time at
        # failure. Other timing instrumentation was removed once the
        # sequence_num collision was fixed.
        self._wasm_run_t0 = time.perf_counter()

        try:
            # ── 1. Hydrate the context ──
            config_files: dict[str, str] = {}
            config_dir = os.path.join(self.workspace_dir, ".colreserved", "config", "files")
            if os.path.isdir(config_dir):
                for name in sorted(os.listdir(config_dir)):
                    p = os.path.join(config_dir, name)
                    if os.path.isfile(p):
                        try:
                            with open(p, "r", encoding="utf-8") as f:
                                config_files[name] = f.read()
                        except OSError:
                            pass

            messages: list[Message] = []
            msgs_path = os.path.join(
                self.workspace_dir, ".colreserved", ".collimate_messages.json"
            )
            if os.path.isfile(msgs_path):
                try:
                    with open(msgs_path, "r", encoding="utf-8") as f:
                        raw = json.load(f)
                    if isinstance(raw, list):
                        messages = [
                            Message(
                                role=m.get("role", "user"),
                                content=m.get("content", ""),
                                timestamp=m.get("timestamp", ""),
                            )
                            for m in raw if isinstance(m, dict)
                        ]
                except (json.JSONDecodeError, OSError):
                    pass

            merged_params = self._load_params_from_manifest()
            merged_params.update(self.params)

            # Load the primary prompt that runs.py wrote to
            # .colreserved/prompt.md. Same semantic as the native SDK's
            # gen.prompt: empty string when no prompt was provided.
            prompt_text = ""
            prompt_path = os.path.join(self.workspace_dir, ".colreserved", "prompt.md")
            if os.path.isfile(prompt_path):
                try:
                    with open(prompt_path, "r", encoding="utf-8") as pf:
                        prompt_text = pf.read()
                except OSError:
                    pass

            ctx = WasmContext(
                workspace=self.workspace_dir,
                params=merged_params,
                channel=self.channel,
                run_id=self.run_id,
                prompt=prompt_text,
                config_files=config_files,
                messages=messages,
                placeholder_cell_id=self.placeholder_cell_id,
                invocation_type=self.invocation_type or "",
                _host=self,  # satisfies wasm_sdk.WasmHost protocol
            )

            # ── 2. Load the generator module ──
            script_path = os.path.join(self.app_dir, self.entrypoint)
            if not os.path.isfile(script_path):
                raise FileNotFoundError(
                    f"Wasm generator entrypoint not found: {script_path}"
                )
            mod_name = f"_collimate_wasm_gen_{uuid.uuid4().hex}"
            spec = importlib.util.spec_from_file_location(mod_name, script_path)
            if spec is None or spec.loader is None:
                raise RuntimeError(f"Cannot build module spec for {script_path}")
            module = importlib.util.module_from_spec(spec)
            _sys.modules[mod_name] = module
            try:
                spec.loader.exec_module(module)
                if not hasattr(module, "run"):
                    raise RuntimeError(
                        f"Wasm generator {self.generator_name!r} must export "
                        f"`async def run()` (no arguments); found no "
                        f"`run` attribute."
                    )

                # ── 3. Hydrate the gen singleton, invoke run(), clear it.
                # ``gen.Cancelled`` is what ``gen.api_key`` / ``gen.secret``
                # raise on user cancel — translated from the underlying
                # ``KeyRequestCancelled``. Treat both as a clean stop.
                run_fn = module.run
                _gen_module._set_context(ctx)
                try:
                    try:
                        if asyncio.iscoroutinefunction(run_fn):
                            await run_fn()
                        else:
                            # Sync ``def run()`` is fine for trivial
                            # cases. Pyodide 0.28 has no working pthread,
                            # so ``asyncio.to_thread`` parks forever —
                            # call directly. The generator owns
                            # cooperative cancellation if it's long-running.
                            run_fn()
                    except (KeyRequestCancelled, _gen_module.Cancelled) as exc:
                        self._cancelled = True
                        self.push_log(f"[wasm_run] {exc}")
                finally:
                    _gen_module._clear_context()

            finally:
                _sys.modules.pop(mod_name, None)

            # ── 4. Cell state is already persisted via the host's
            # emit_partial handler on every gen.update() call. Generators
            # that never call gen.update() leave the placeholder empty —
            # explicit by design.
            cell_name = (
                self._last_emit_cell_name
                or self.generator_name
                or "Output"
            )

            # ── 5. Mark the run completed.
            # Stopped takes precedence over a natural completion when
            # the user hit Stop or cancelled a key prompt.
            status = "stopped" if self._cancelled else "completed"
            conn = get_db_connection(self.channel)
            try:
                conn.execute(
                    "UPDATE runs SET status=? WHERE id=?", (status, self.run_id)
                )
                conn.commit()
            finally:
                conn.close()

            self.log_buffer.append({
                "type": "stdout",
                "payload": f"[wasm_run] {status}: {cell_name}"
                           f"{' (after ' + str(self._emit_partial_called) + ' partial emits)' if self._emit_partial_called else ''}",
            })
            # Broadcast the terminal status — the frontend's
            # runStatusHandlers fires off this SSE message to flip the
            # cell out of "running". Native does it via
            # _finalize_run_status; wasm has no equivalent finalizer,
            # so emit it here.
            self._broadcast_run_status(status)

        except Exception:
            # Record the failure — don't re-raise. The supervised wrapper
            # will complete the _cleanup_task so _reap_process can pop us
            # from active_managers cleanly. ``print`` ensures the
            # traceback hits the pyodide console even when the
            # log_buffer drain races with shutdown — without it, the
            # exception path was silent in the WASM playground and a
            # crashed run looked indistinguishable from a hang.
            tb = traceback.format_exc()
            print(
                f"[wasm_run FAILED] run={self.run_id[:8]} "
                f"after {(time.perf_counter() - self._wasm_run_t0) * 1000.0:.1f}ms\n"
                f"{tb}",
                flush=True,
            )
            self.log_buffer.append({
                "type": "stderr",
                "payload": "[wasm_run] " + tb,
            })
            conn = get_db_connection(self.channel)
            try:
                conn.execute(
                    "UPDATE runs SET status=? WHERE id=?", ("failed", self.run_id)
                )
                conn.commit()
            finally:
                conn.close()
            self._broadcast_run_status("failed")

    async def _run_wasm_supervised(self, manifest: dict) -> None:
        """Wrapper for _run_wasm that always completes cleanly so the task
        (stored as _cleanup_task) can be awaited by _reap_process without
        leaking active_managers on generator exceptions.

        Owns the ``_wasm_running`` liveness flag the microbatch writer
        reads. Setting it True before the dispatch and False in
        ``finally`` lets the writer keep flushing through the run and
        exit cleanly once we're done — without needing to read
        ``_cleanup_task.done()`` (which is this very task and would
        deadlock the writer's await chain on the native path)."""
        self._wasm_running = True
        try:
            await self._run_wasm(manifest)
        except Exception:
            # _run_wasm already logged + recorded the failure.
            pass
        finally:
            self._wasm_running = False

    # The 7-method Host protocol implementation (emit_partial,
    # is_cancelled, push_log, set_status, poll_user_message,
    # create_side_cell, request_key) lives in
    # ``process_manager.host.HostMixin``, composed into ProcessManager
    # alongside this mixin. Wasm dispatch hits those methods directly
    # via the ``WasmContext._host`` slot the dispatcher fills below.
