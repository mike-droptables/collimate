"""The ``.colreserved/`` private namespace — single source of truth.

The SDK stages run-private artifacts (settings forms, config snapshots,
chat history) under ``.colreserved/``; those paths must never flow in or
out of a cell as user files. The one exception is the chat history file,
which has to cross the boundary so it can be hydrated into workspaces
and committed with turns.

Three call sites used to carry their own copy of this predicate
(artifact hashing, in-memory cell collection, hydration filtering);
behavior drift between them shows up as files leaking or chat history
flickering, so keep the rule here.
"""

RESERVED_PREFIX = ".colreserved"
MESSAGES_FILE = ".colreserved/.collimate_messages.json"


def is_reserved_path(cell_path: str, allow_messages: bool = True) -> bool:
    """True if ``cell_path`` falls in the reserved namespace.

    ``allow_messages=True`` (the default) treats the chat-history file as
    NOT reserved, letting it cross the cell boundary.
    """
    norm = (cell_path or "").replace("\\", "/").lstrip("/")
    if allow_messages and norm == MESSAGES_FILE:
        return False
    return norm == RESERVED_PREFIX or norm.startswith(RESERVED_PREFIX + "/")
