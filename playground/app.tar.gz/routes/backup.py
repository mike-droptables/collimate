"""Backup-library endpoints — the ``.collimatebackup`` bundle store.

Native-only (the playground has no local disk): every handler calls
``_guard_wasm()`` → ``WasmNotSupportedError`` → 503 (handled in main.py).
Folder I/O lives in ``backup.py``; archive (de)serialization is reused from
``routes.packages`` (.colgen/.colrend) and ``routes.system`` (.colchan) so the
on-disk formats can't drift from the HTTP export/import routes.
"""
from __future__ import annotations

import asyncio
import os

from fastapi import APIRouter, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel

from runtime import IS_WASM, WasmNotSupportedError

router = APIRouter()

_SCOPE_EXT = {
    "generators": ".colgen",
    "renderers": ".colrend",
    "channel": ".colchan",
    "current_cell": ".colchan",
}


def _guard_wasm() -> None:
    if IS_WASM:
        raise WasmNotSupportedError("the backup library is not available in the playground")


def _normalize_filename(name: str, required_ext: str) -> str:
    """Coerce a user-typed name into ``<base><required_ext>``: basename only,
    drop any (possibly wrong) known extension the user typed, append the one
    the scope requires. ``backup.save_bytes`` re-validates."""
    base = os.path.basename((name or "").strip())
    root, ext = os.path.splitext(base)
    if ext.lower() in (".colgen", ".colrend", ".colchan"):
        base = root
    if not base:
        raise HTTPException(400, "filename required")
    return base + required_ext


# ---------------------------------------------------------------------------
# GET /api/backup/list
# ---------------------------------------------------------------------------

@router.get("/api/backup/list")
async def backup_list(kind: str | None = None):
    """List bundle files in the library (newest first), each with its cell
    metadata. ``kind`` filters by generator|renderer|channel. Serves BOTH the
    channel-create picker and the file-sync Backup browser."""
    _guard_wasm()
    if kind is not None and kind not in ("generator", "renderer", "channel"):
        raise HTTPException(400, "kind must be generator|renderer|channel")
    import backup
    bundles = await asyncio.to_thread(backup.list_bundles, kind)
    return {"bundles": bundles}


# ---------------------------------------------------------------------------
# GET /api/backup/file/{filename}
# ---------------------------------------------------------------------------

@router.get("/api/backup/file/{filename}")
async def backup_file(filename: str):
    """Raw bytes of a library bundle (for the 'Copy file' sync action — the
    frontend stores them in the CAS and drops the file into the open cell)."""
    _guard_wasm()
    import backup
    try:
        data = await asyncio.to_thread(backup.read_bundle_bytes, filename)
    except FileNotFoundError:
        raise HTTPException(404, f"No such backup file: {filename}")
    except ValueError as e:
        raise HTTPException(400, str(e))
    return Response(
        content=data,
        media_type="application/gzip",
        headers={"Content-Disposition": f"attachment; filename={os.path.basename(filename)}"},
    )


# ---------------------------------------------------------------------------
# POST /api/backup/save
# ---------------------------------------------------------------------------

class _BackupSaveBody(BaseModel):
    scope: str            # current_cell | channel | generators | renderers
    filename: str         # destination name (extension coerced to the scope's)
    cell_id: str | None = None   # required iff scope == current_cell


def _has_dropped_blobs(cells) -> bool:
    """True if any cell holds a binary CAS file (blob_hash set) — the text-only
    archive format drops it, so the caller warns."""
    return any(f.blob_hash for c in cells for f in c.files)


def build_scope_bytes(scope: str, cell_id: str | None) -> tuple[bytes, str | None]:
    """Serialize an app scope to bundle bytes, reusing the same serializers the
    HTTP export routes use. Returns ``(content, warning)`` — ``warning`` is set
    when binary CAS files were dropped (the archive format is text-only). Raises
    HTTPException(400/404). Shared by the .collimatebackup save and the Google
    Drive save so both surfaces emit byte-identical bundles."""
    from state import get_active_channel

    warning: str | None = None
    if scope in ("generators", "renderers"):
        from routes.packages import _serialize_active_packages
        type_ = "generator" if scope == "generators" else "renderer"
        content, dropped = _serialize_active_packages(type_)
        if dropped:
            warning = "Binary files were dropped (the bundle format is text-only)."
    elif scope == "channel":
        from routes.system import _build_colchan_bytes
        ch = get_active_channel()
        content = _build_colchan_bytes(ch)
        standard_cells = [c for s in ch.main_stacks for c in s.cells if s.stack_type == "standard"]
        if _has_dropped_blobs(standard_cells):
            warning = "Binary files were dropped (the bundle format is text-only)."
    else:  # current_cell
        if not cell_id:
            raise HTTPException(400, "cell_id is required for scope=current_cell")
        from routes.system import _colchan_from_cells
        ch = get_active_channel()
        cell = next(
            (c for s in ch.main_stacks + ch.nav_stacks for c in s.cells if str(c.id) == cell_id),
            None,
        )
        if cell is None:
            raise HTTPException(404, "Cell not found in the active channel")
        content = _colchan_from_cells(ch.name, [cell])
        if _has_dropped_blobs([cell]):
            warning = "Binary files were dropped (the bundle format is text-only)."
    return content, warning


@router.post("/api/backup/save")
async def backup_save(body: _BackupSaveBody):
    """Serialize an app scope INTO the library as a bundle file (overwriting a
    same-named file). Reuses the same serializers the HTTP export routes use."""
    _guard_wasm()
    if body.scope not in _SCOPE_EXT:
        raise HTTPException(400, f"unknown scope: {body.scope!r}")
    filename = _normalize_filename(body.filename, _SCOPE_EXT[body.scope])

    import backup
    content, warning = build_scope_bytes(body.scope, body.cell_id)

    try:
        result = await asyncio.to_thread(backup.save_bytes, filename, content)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {**result, "warning": warning}


# ---------------------------------------------------------------------------
# POST /api/backup/load
# ---------------------------------------------------------------------------

class _BackupLoadBody(BaseModel):
    filename: str
    cell_ids: list[str] | None = None   # None = all cells in the bundle


def load_bundle_bytes(raw: bytes, filename: str, cell_ids: list[str] | None):
    """Import a bundle's cells into the active channel and persist: .colgen →
    generator nav-stack, .colrend → renderer nav-stack, .colchan → main view.
    ``cell_ids`` (None = all) restricts which of the bundle's cells load.
    Returns ``(loaded_count, channel)``; raises HTTPException(400) on a bad
    bundle. Shared by the .collimatebackup loader and the Google Drive loader
    so the import behaviour can't drift between the two surfaces."""
    import backup
    from state import get_active_channel, persist_state
    from models import Stack, Cell, VirtualFile

    kind = backup.kind_for_extension(filename)
    ch = get_active_channel()
    want = set(cell_ids) if cell_ids else None
    loaded = 0

    if kind in ("generator", "renderer"):
        from collimate.packaging import read_archive, PackageError
        try:
            manifest = read_archive(raw)
        except PackageError as e:
            raise HTTPException(400, str(e))
        cells = [c for c in manifest.cells if want is None or str(c.id) in want]
        stack = next((s for s in ch.nav_stacks if s.stack_type == kind), None)
        if stack is None:
            stack = Stack(name=f"{kind.capitalize()}s", stack_type=kind)
            ch.nav_stacks.append(stack)
        for cspec in cells:
            stack.cells.append(Cell(
                name=cspec.name,
                summary=cspec.summary,
                files=[VirtualFile(name=f.name, language=f.language, content=f.content)
                       for f in cspec.files],
            ))
            loaded += 1
    elif kind == "channel":
        from routes.system import _merge_colchan_into_channel
        try:
            _, loaded = _merge_colchan_into_channel(ch, raw, want)
        except ValueError as e:
            raise HTTPException(400, str(e))
    else:
        raise HTTPException(400, f"Unsupported backup file: {filename}")

    persist_state()
    return loaded, ch


@router.post("/api/backup/load")
async def backup_load(body: _BackupLoadBody):
    """Import a bundle's cells into the active channel: .colgen → generator
    nav-stack, .colrend → renderer nav-stack, .colchan → main view. ``cell_ids``
    (None = all) restricts which of the bundle's cells are loaded."""
    _guard_wasm()
    import backup

    try:
        raw = await asyncio.to_thread(backup.read_bundle_bytes, body.filename)
    except FileNotFoundError:
        raise HTTPException(404, f"No such backup file: {body.filename}")
    except ValueError as e:
        raise HTTPException(400, str(e))

    loaded, ch = load_bundle_bytes(raw, body.filename, body.cell_ids)
    return {"loaded_cells": loaded, "channel": ch}
