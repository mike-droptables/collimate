"""Blob and renderer serving routes."""
import hashlib
import os
import mimetypes
import yaml
from fastapi import APIRouter, HTTPException
from fastapi.responses import Response

router = APIRouter()

# Locate directories:
_API_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

@router.get("/api/sdk/react.js")
async def get_react_sdk():
    """Virtual SDK for React-based renderers."""
    js_code = """
import React, { createContext, useContext, useState, useEffect } from 'https://esm.sh/react@18';
import { createRoot } from 'https://esm.sh/react-dom@18/client';

const CollimateContext = createContext(null);

export function useCollimateFile() {
    return useContext(CollimateContext);
}

export function useSiblingFile(path) {
    const ctx = useContext(CollimateContext);
    const [url, setUrl] = useState(null);
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        ctx.api.getSiblingFile(path).then(content => {
            const blob = new Blob([content]);
            setUrl(URL.createObjectURL(blob));
            setLoading(false);
        }).catch(() => setLoading(false));
    }, [path, ctx.api]);
    return { url, loading };
}

export function defineRenderer(config) {
    // Renderers that need to await async work before revealing (crepe/monaco
    // loading CSS + external editor engines) opt in with deferReady: true and
    // call api.ready() themselves when fully painted. Everything else gets a
    // free auto-ready from the useEffect below — fires right after the first
    // React commit, i.e. at the moment the DOM is actually there.
    const deferReady = !!config.deferReady;
    const renderer = {
        mount: async (container, api) => {
            const content = await api.getContent();
            const root = createRoot(container);
            const App = () => {
                const [localContent, setLocalContent] = useState(content || '');
                useEffect(() => {
                    const unsub = api.onFilesChanged(async () => {
                        try {
                            const fresh = await api.getSiblingFile(api.getFilename());
                            if (fresh !== null && fresh !== localContent) setLocalContent(fresh);
                        } catch(e) {}
                    });
                    return unsub;
                }, [api, localContent]);
                useEffect(() => {
                    if (!deferReady && api.ready) api.ready();
                }, []);
                const saveContent = (newContent) => {
                    setLocalContent(newContent);
                    api.onChange(newContent);
                };
                const ctxValue = {
                    initialContent: content || '',
                    content: localContent,
                    saveContent,
                    isReadOnly: api.isReadOnly(),
                    api,
                    fileName: api.getFilename()
                };
                return React.createElement(CollimateContext.Provider, { value: ctxValue }, React.createElement(config.component));
            };
            root.render(React.createElement(App));
            return () => root.unmount();
        },
        mountDiff: async (container, api) => {
            if (!config.diffComponent) {
                const dummyApi = { ...api, getContent: api.getDiffContent };
                return renderer.mount(container, dummyApi);
            }
            const after = await api.getContent();
            const before = await api.getDiffContent();
            const root = createRoot(container);
            const App = () => {
                useEffect(() => {
                    if (!deferReady && api.ready) api.ready();
                }, []);
                const ctxValue = {
                    initialContent: after || '',
                    diffContent: before || '',
                    content: after || '',
                    saveContent: () => {},
                    isReadOnly: true,
                    api,
                    fileName: api.getFilename()
                };
                return React.createElement(CollimateContext.Provider, { value: ctxValue }, React.createElement(config.diffComponent));
            };
            root.render(React.createElement(App));
            return () => root.unmount();
        }
    };
    return renderer;
}
"""
    return Response(content=js_code, media_type="application/javascript")


@router.get("/api/sdk/vanilla.js")
async def get_vanilla_sdk():
    """Virtual SDK for vanilla JS renderers."""
    js_code = """
export function defineRenderer(config) {
    const deferReady = !!config.deferReady;
    const _autoReady = (api) => {
        if (!deferReady && api && typeof api.ready === 'function') {
            // Defer a microtask so the mount function has a chance to paint
            // before the overlay lifts. Vanilla renderers don't have a React
            // useEffect boundary; this is the closest equivalent.
            Promise.resolve().then(() => api.ready());
        }
    };
    const renderer = {
        mount: async (container, api) => {
            const out = config.mount ? await config.mount(container, api) : undefined;
            _autoReady(api);
            return out;
        },
        mountDiff: async (container, api) => {
            const fn = config.mountDiff || config.mount;
            const out = fn ? await fn(container, api) : undefined;
            _autoReady(api);
            return out;
        }
    };
    return renderer;
}
"""
    return Response(content=js_code, media_type="application/javascript")


@router.get("/api/blob/{blob_hash}")
async def get_blob(blob_hash: str):
    """Serve a file from the CAS by its SHA-256 hex digest."""
    if len(blob_hash) != 64 or not all(c in "0123456789abcdef" for c in blob_hash):
        raise HTTPException(400, "Invalid hash format — must be 64 hex chars")

    cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
    if not os.path.exists(cas_path):
        raise HTTPException(404, "Blob not found in CAS")

    with open(cas_path, "rb") as f:
        content = f.read()

    mime_type, _ = mimetypes.guess_type(cas_path)
    return Response(content=content, media_type=mime_type or "application/octet-stream",
                    headers={"Cache-Control": "public, max-age=31536000, immutable"})


@router.get("/api/channels/{channel}/cells/{cell_id}/files/{filepath:path}")
async def get_cell_file(channel: str, cell_id: str, filepath: str):
    """Serve a single file from a DAG cell's snapshot (CAS-backed)."""
    from database import get_db_connection
    conn = get_db_connection(channel)
    row = conn.execute(
        "SELECT blob_hash FROM cell_files WHERE cell_id=? AND filepath=?",
        (cell_id, filepath),
    ).fetchone()
    conn.close()

    if not row:
        raise HTTPException(404, f"File '{filepath}' not found in cell {cell_id}")

    blob_hash = row["blob_hash"]
    cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
    if not os.path.exists(cas_path):
        raise HTTPException(404, "Blob not found in CAS")

    with open(cas_path, "rb") as f:
        content = f.read()

    mime_type, _ = mimetypes.guess_type(filepath)
    return Response(
        content=content,
        media_type=mime_type or "application/octet-stream",
        headers={"Cache-Control": "public, max-age=31536000, immutable"},
    )


def _iter_renderer_manifests(ch):
    """
    Walk every renderer-source cell in the active channel and yield
    (cell, manifest_file, manifest_dict, prefix, rid) for every parseable manifest.

    `prefix` is the directory portion of the manifest filepath (with trailing slash);
    sibling files belong to this renderer iff their name starts with `prefix`.
    `rid` is the manifest's `id` field, falling back to the deepest folder name.
    """
    for s in ch.main_stacks + ch.nav_stacks:
        if s.stack_type != 'renderer':
            continue
        for c in s.cells:
            if not c.enabled:
                continue
            for f in c.files:
                if not f.name.endswith("/manifest.rend_yaml") and f.name != "manifest.rend_yaml":
                    continue
                try:
                    manifest = yaml.safe_load(f.content) or {}
                except Exception:
                    continue
                prefix = f.name[: -len("manifest.rend_yaml")]  # ends with "/" or ""
                folder = prefix.rstrip("/").rsplit("/", 1)[-1] if prefix else ""
                rid = manifest.get("id") or folder
                yield c, f, manifest, prefix, rid


@router.get("/api/renderers/{renderer_id}/source")
async def get_renderer_source(renderer_id: str):
    """Serve a bundled renderer ES module from the active channel's renderer source cells."""
    if ".." in renderer_id or "/" in renderer_id or "\\" in renderer_id:
        raise HTTPException(400, "Invalid renderer ID")

    from state import state
    ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
    if ch:
        for cell, _mf, manifest, prefix, rid in _iter_renderer_manifests(ch):
            if rid != renderer_id:
                continue
            entrypoint = manifest.get("entrypoint", "main.js")
            target_name = f"{prefix}{entrypoint}"
            for f in cell.files:
                if f.name == target_name:
                    return Response(
                        content=f.content,
                        media_type="application/javascript",
                        headers={
                            "Cache-Control": "no-cache",
                            "X-Entrypoint": entrypoint,
                        },
                    )

    raise HTTPException(404, f"Renderer '{renderer_id}' not found in active renderer source cells")


@router.get("/api/renderers/{renderer_id}/manifest")
async def get_renderer_manifest(renderer_id: str):
    """Return the parsed manifest.rend_yaml for a specific renderer from the active channel's renderer source cells."""
    if ".." in renderer_id or "/" in renderer_id or "\\" in renderer_id:
        raise HTTPException(400, "Invalid renderer ID")

    from state import state
    ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
    if ch:
        for _cell, _mf, manifest, _prefix, rid in _iter_renderer_manifests(ch):
            if rid == renderer_id:
                return manifest

    raise HTTPException(404, f"Manifest not found for renderer '{renderer_id}'")


@router.get("/api/renderers")
async def list_renderers():
    """List all available renderers, deduplicated by id, across every renderer source cell."""
    renderers = []
    seen_ids = set()
    from state import state
    ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
    if not ch:
        return renderers

    for cell, _mf, manifest, prefix, rid in _iter_renderer_manifests(ch):
        if rid in seen_ids:
            continue
        seen_ids.add(rid)

        h = hashlib.sha256()
        for rf in sorted(
            (f for f in cell.files if f.name.startswith(prefix)),
            key=lambda x: x.name,
        ):
            h.update(rf.content.encode())

        renderers.append({
            "id": rid,
            "name": manifest.get("name") or rid,
            "version": manifest.get("version", "0.0.0"),
            "summary": manifest.get("summary", ""),
            "extensions": manifest.get("extensions", []),
            "supports_diff": manifest.get("supports_diff", False),
            "embed": manifest.get("embed", "iframe"),
            "content_hash": h.hexdigest()[:12],
        })
    return renderers
