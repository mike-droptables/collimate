"""Cell version and history endpoints.

Cell versions are stored as linked rows in ``cell_edges`` via
``parent_key='previous_version'``. Each visible cell on the canvas is
the start of a version list — walking forward from it yields the full
sequence of versions produced by ``update_cell`` commits, user-edit
checkpoints, and other mutations. Restore creates a new DAG cell with
a provenance edge; fork creates a new independent cell.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import uuid
from collections import deque
from typing import Any, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from cas import hash_and_store_bytes
from database import get_db_connection, _slug_channel

_logger = logging.getLogger("cells")

router = APIRouter()


# ---------------------------------------------------------------------------
# Chain walking helpers
# ---------------------------------------------------------------------------

def _walk_versions(conn, start_cell_id: str) -> list[str]:
    """Walk cell_edges forward from start_cell_id via
    parent_key='previous_version'. Returns the ordered list of version
    cell ids, including start_cell_id at index 0.
    """
    versions = [start_cell_id]
    current = start_cell_id
    for _ in range(10_000):
        row = conn.execute(
            "SELECT child_cell_id FROM cell_edges "
            "WHERE parent_cell_id=? AND parent_key='previous_version' "
            "LIMIT 1",
            (current,),
        ).fetchone()
        if not row:
            break
        current = row[0]
        versions.append(current)
    return versions


def _read_version_metadata(conn, cell_id: str) -> tuple[Optional[str], Optional[str]]:
    """Return (name, summary) for a cell from the cell row. O(1)."""
    row = conn.execute(
        "SELECT version_name, version_summary FROM cells WHERE id=?",
        (cell_id,),
    ).fetchone()
    if row:
        return row["version_name"], row["version_summary"]
    return None, None


def _read_cell_created_at(conn, cell_id: str) -> Optional[str]:
    row = conn.execute(
        "SELECT created_at FROM cells WHERE id=?", (cell_id,),
    ).fetchone()
    return row["created_at"] if row else None


def _read_cell_files(conn, cell_id: str) -> list[dict]:
    rows = conn.execute(
        "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=? ORDER BY filepath",
        (cell_id,),
    ).fetchall()
    return [{"filepath": r["filepath"], "blob_hash": r["blob_hash"]} for r in rows]


def _read_blob(blob_hash: str) -> Optional[str]:
    cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
    if not os.path.exists(cas_path):
        return None
    try:
        with open(cas_path, "r", encoding="utf-8", errors="replace") as fh:
            return fh.read()
    except OSError:
        return None


def _language_for(path: str) -> str:
    ext = os.path.splitext(path)[1]
    lang_map = {
        ".py": "python", ".js": "javascript", ".ts": "typescript",
        ".tsx": "typescript", ".jsx": "javascript", ".json": "json",
        ".md": "markdown", ".yaml": "yaml", ".yml": "yaml",
        ".html": "html", ".css": "css", ".sh": "shell",
    }
    return lang_map.get(ext, "plaintext")


# ---------------------------------------------------------------------------
# GET /versions — list the internal-version chain
# ---------------------------------------------------------------------------

@router.get("/api/channels/{channel}/cells/{visible_cell_id}/versions")
def list_versions(channel: str, visible_cell_id: str) -> dict:
    """Return the ordered chain of internal versions for a visible cell,
    annotated with name/summary pulled from the most recent matching
    commit event.
    """
    conn = get_db_connection(channel)
    try:
        version_ids = _walk_versions(conn, visible_cell_id)
        versions = []
        for idx, cell_id in enumerate(version_ids):
            row = conn.execute(
                "SELECT version_name, version_summary, source_type, created_at "
                "FROM cells WHERE id=?",
                (cell_id,),
            ).fetchone()
            file_count = conn.execute(
                "SELECT COUNT(*) AS n FROM cell_files WHERE cell_id=?",
                (cell_id,),
            ).fetchone()
            versions.append({
                "cell_id": cell_id,
                "index": idx,
                "created_at": row["created_at"] if row else None,
                "name": row["version_name"] if row else None,
                "summary": row["version_summary"] if row else None,
                "source_type": row["source_type"] if row else None,
                "file_count": file_count["n"] if file_count else 0,
            })
        return {
            "versions": versions,
            "current_index": len(versions) - 1,
        }
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# GET /timeline — version chain + DAG provenance edges for timeline view
# ---------------------------------------------------------------------------

@router.get("/api/channels/{channel}/cells/{visible_cell_id}/timeline")
def get_cell_timeline(channel: str, visible_cell_id: str) -> dict:
    """Return the full version chain with O(1) metadata per entry, plus
    any DAG provenance edges (branched_from) pointing into
    this cell's version chain from other visible cells.

    Designed for the timeline view where both the cell's internal history
    and its cross-cell relationships need to be rendered together.
    """
    conn = get_db_connection(channel)
    try:
        version_ids = _walk_versions(conn, visible_cell_id)
        version_set = set(version_ids)

        versions = []
        for idx, cell_id in enumerate(version_ids):
            row = conn.execute(
                "SELECT version_name, version_summary, source_type, created_at "
                "FROM cells WHERE id=?",
                (cell_id,),
            ).fetchone()
            file_count = conn.execute(
                "SELECT COUNT(*) AS n FROM cell_files WHERE cell_id=?",
                (cell_id,),
            ).fetchone()
            versions.append({
                "cell_id": cell_id,
                "index": idx,
                "created_at": row["created_at"] if row else None,
                "name": row["version_name"] if row else None,
                "summary": row["version_summary"] if row else None,
                "source_type": row["source_type"] if row else None,
                "file_count": file_count["n"] if file_count else 0,
            })

        # Find DAG edges pointing INTO any version in this cell's history
        # (e.g., other cells branched from a version here).
        dag_edges = []
        placeholders = ",".join("?" for _ in version_ids)
        if version_ids:
            rows = conn.execute(
                f"SELECT child_cell_id, parent_cell_id, parent_key "
                f"FROM cell_edges "
                f"WHERE parent_cell_id IN ({placeholders}) "
                f"AND parent_key IN ('branched_from', 'forked_from') ",
                version_ids,
            ).fetchall()
            for r in rows:
                parent_idx = version_ids.index(r["parent_cell_id"]) if r["parent_cell_id"] in version_set else None
                dag_edges.append({
                    "type": r["parent_key"],
                    "target_cell_id": r["child_cell_id"],
                    "source_version_index": parent_idx,
                })

        return {
            "versions": versions,
            "current_index": len(versions) - 1,
            "dag_edges": dag_edges,
        }
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# GET /files-tree — full file tree for a specific internal-version cell
# ---------------------------------------------------------------------------

@router.get("/api/channels/{channel}/cells/{internal_cell_id}/files-tree")
def get_cell_files_tree(channel: str, internal_cell_id: str) -> dict:
    """Read every cell_files row for an internal-version cell id and
    return a list of ``{name, language, content}`` objects the scrubber
    can hand straight to a read-only CellEditor.
    """
    conn = get_db_connection(channel)
    try:
        rows = _read_cell_files(conn, internal_cell_id)
    finally:
        conn.close()

    out = []
    for r in rows:
        content = _read_blob(r["blob_hash"]) or ""
        out.append({
            "name": r["filepath"],
            "language": _language_for(r["filepath"]),
            "content": content,
        })
    return {"cell_id": internal_cell_id, "files": out}


# ---------------------------------------------------------------------------
# POST /checkpoint — promote pending drafts into a version chain entry
# ---------------------------------------------------------------------------

def checkpoint_cell_internal(channel: str, cell_id: str) -> str | None:
    """Promote pending drafts into a cell version. Callable without HTTP context.

    Returns the new version cell_id, or None if no drafts were pending.
    """
    from routes.runs import _promote_drafts_to_version

    run_id = str(uuid.uuid4())
    conn = get_db_connection(channel)
    conn.execute(
        "INSERT INTO runs (id, prompt, status) VALUES (?, ?, 'completed')",
        (run_id, "checkpoint"),
    )
    version_id = _promote_drafts_to_version(conn, cell_id, run_id)
    conn.commit()
    conn.close()
    return version_id


@router.post("/api/channels/{channel}/cells/{cell_id}/checkpoint")
def checkpoint_cell(channel: str, cell_id: str) -> dict:
    """Promote pending drafts for a cell into a permanent cell version.

    Called by the frontend on idle timeout (~60s), editor close, or other
    save triggers. If there are no pending drafts, returns
    ``{"created": false}``. Otherwise creates a new version at the tip
    with ``source_type='human_edit'``.
    """
    version_id = checkpoint_cell_internal(channel, cell_id)

    if version_id:
        # Update in-memory state with the new files so the next
        # state_update reflects the checkpoint.
        from state import state, channel_db_name, persist_state
        from cell_placement import find_stack_containing_cell
        from routes.runs import _find_version_tip

        for ch in state.channels:
            if channel_db_name(ch) == _slug_channel(channel):
                stack = find_stack_containing_cell(ch, cell_id)
                if stack:
                    tip_conn = get_db_connection(channel)
                    tip_id = _find_version_tip(tip_conn, cell_id)
                    rows = tip_conn.execute(
                        "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?",
                        (tip_id,),
                    ).fetchall()
                    tip_conn.close()
                    from models import VirtualFile
                    vfiles = []
                    for r in rows:
                        content = _read_blob(r["blob_hash"]) or ""
                        vfiles.append(VirtualFile(
                            name=r["filepath"],
                            content=content,
                            language=_language_for(r["filepath"]),
                        ))
                    for c in stack.cells:
                        if str(c.id) == cell_id:
                            c.files = vfiles
                            from datetime import datetime
                            c.updated_at = datetime.now()
                            break
                    persist_state()
                break

    return {"created": bool(version_id), "version_id": version_id}


# ---------------------------------------------------------------------------
# POST /fork — create a new cell in a new stack right of the source
# ---------------------------------------------------------------------------

class ForkRequest(BaseModel):
    target_cell_id: str  # the internal-version cell id to fork from


@router.post("/api/channels/{channel}/cells/{visible_cell_id}/fork")
def fork_version(channel: str, visible_cell_id: str, body: ForkRequest) -> dict:
    """Create a brand-new visible cell in a new stack immediately right
    of the source stack, populated with the target version's files.
    The branch has its own id — it's a separate chain from the source.
    """
    from cell_placement import find_stack_containing_cell, insert_new_stack_right_of
    from state import state, channel_db_name, persist_state
    from models import Cell as CellModel, VirtualFile

    conn = get_db_connection(channel)
    try:
        version_ids = _walk_versions(conn, visible_cell_id)
        if body.target_cell_id not in version_ids:
            raise HTTPException(404, "target_cell_id is not in this cell's versions")
        target_files = _read_cell_files(conn, body.target_cell_id)

        run_id = str(uuid.uuid4())
        conn.execute(
            "INSERT INTO runs (id, prompt, status) VALUES (?, ?, 'completed')",
            (run_id, f"branch {body.target_cell_id[:8]}"),
        )

        branch_name, _ = _read_version_metadata(conn, body.target_cell_id)
        new_cell_id = str(uuid.uuid4())
        conn.execute(
            "INSERT INTO cells (id, run_id, generator_name, sequence_num, "
            "version_name, version_summary, source_type) "
            "VALUES (?, ?, 'history_scrubber_branch', 1, ?, ?, 'branch')",
            (new_cell_id, run_id,
             (branch_name or "Cell") + " (branch)",
             f"Branched from {body.target_cell_id[:8]}"),
        )
        # Provenance edge
        conn.execute(
            "INSERT OR IGNORE INTO cell_edges "
            "(parent_cell_id, child_cell_id, parent_key) VALUES (?, ?, 'branched_from')",
            (body.target_cell_id, new_cell_id),
        )
        for f in target_files:
            cas_path = os.path.join(".collimate", "objects", f["blob_hash"][:2], f["blob_hash"][2:])
            size = os.path.getsize(cas_path) if os.path.exists(cas_path) else 0
            conn.execute(
                "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                (f["blob_hash"], size),
            )
            conn.execute(
                "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                "VALUES (?, ?, ?)",
                (new_cell_id, f["filepath"], f["blob_hash"]),
            )
        conn.execute(
            "INSERT INTO run_events (run_id, event_type, payload) VALUES (?, 'commit', ?)",
            (
                run_id,
                json.dumps({
                    "cell_id": new_cell_id,
                    "name": (branch_name or "Cell") + " (branch)",
                    "summary": f"Branched from {body.target_cell_id[:8]}",
                    "sequence_num": 1,
                    "file_count": len(target_files),
                }),
            ),
        )
        conn.commit()
    finally:
        conn.close()

    # In-memory state update: new stack right of the source.
    target_channel = None
    for ch in state.channels:
        if channel_db_name(ch) == _slug_channel(channel):
            target_channel = ch
            break
    if target_channel is None:
        raise HTTPException(404, "channel not found in state")
    source_stack = find_stack_containing_cell(target_channel, visible_cell_id)
    if source_stack is None:
        raise HTTPException(404, "source stack not found in state")

    new_stack = insert_new_stack_right_of(target_channel, source_stack.id)
    vfiles = []
    for f in target_files:
        content = _read_blob(f["blob_hash"]) or ""
        vfiles.append(VirtualFile(
            name=f["filepath"],
            content=content,
            language=_language_for(f["filepath"]),
        ))
    new_cell = CellModel(
        id=new_cell_id,
        name=(branch_name or "Cell") + " (branch)",
        summary=f"Branched from {body.target_cell_id[:8]}",
        files=vfiles,
        run_id=run_id,
        channel=channel,
    )
    new_stack.cells.insert(0, new_cell)
    persist_state()

    return {
        "ok": True,
        "new_cell_id": new_cell_id,
        "new_stack_id": str(new_stack.id),
        "forked_from": body.target_cell_id,
    }


# ---------------------------------------------------------------------------
# POST /chat/interrupt and /chat/redirect — mid-turn user corrections
# ---------------------------------------------------------------------------

class RedirectRequest(BaseModel):
    content: str


@router.post("/api/channels/{channel}/cells/{cell_id}/chat/interrupt")
async def chat_interrupt(channel: str, cell_id: str) -> dict:
    """Stop the in-flight chat turn bound to this cell. The active
    ``chat_session.send_turn`` call will observe the cancellation via
    its drain loop and return with ``cancelled=True`` — the generator
    subprocess then proceeds to commit via update_cell as usual,
    preserving whatever partial output was already collected.
    """
    from chat_session import interrupt_turn, ChatSessionError
    try:
        return await interrupt_turn(cell_id)
    except ChatSessionError as exc:
        raise HTTPException(404, str(exc))


@router.post("/api/channels/{channel}/cells/{cell_id}/chat/redirect")
async def chat_redirect(channel: str, cell_id: str, body: RedirectRequest) -> dict:
    """Cancel the in-flight chat turn and queue a new one with the
    supplied content. The whole redirect is handled inside the active
    ``send_turn`` call — the generator never sees its first turn
    return; instead it gets back the second turn's result once the
    daemon completes it.
    """
    from chat_session import redirect_turn, ChatSessionError
    try:
        return await redirect_turn(cell_id, body.content)
    except ChatSessionError as exc:
        raise HTTPException(404, str(exc))


# ---------------------------------------------------------------------------
# POST /chat/push_message — deliver a user message to a waiting generator
# ---------------------------------------------------------------------------

class PushMessageRequest(BaseModel):
    content: str


@router.post("/api/channels/{channel}/cells/{cell_id}/chat/push_message")
async def chat_push_message(channel: str, cell_id: str, body: PushMessageRequest) -> dict:
    """Queue a user message for the generator subprocess that is waiting
    on this cell.  The subprocess polls via the ``poll_user_message`` IPC
    op and picks it up on the next cycle (<200ms).

    Before queuing the message, any pending drafts for this cell are
    flushed: written into the generator's workspace (so the model sees
    them) and promoted into a "Human Edit" version row (so the scrubber
    captures user edits between turns).
    """
    from routes.runs import active_managers, _promote_drafts_to_version
    from process_manager import ProcessManager

    channel = _slug_channel(channel)
    for manager in active_managers.values():
        if (
            isinstance(manager, ProcessManager)
            and manager.placeholder_cell_id == cell_id
            and manager.is_running()
        ):
            # Flush pending drafts into the workspace and version chain.
            # Retry on DB lock — the process_manager may be mid-commit
            # in its background thread.
            import time as _time
            for _attempt in range(3):
                try:
                    conn = get_db_connection(channel)
                    drafts = conn.execute(
                        "SELECT filepath, content_text FROM cell_drafts WHERE cell_id=?",
                        (cell_id,),
                    ).fetchall()
                    if drafts:
                        for draft in drafts:
                            dst = os.path.join(manager.workspace_dir, draft["filepath"])
                            os.makedirs(os.path.dirname(dst), exist_ok=True)
                            with open(dst, "w", encoding="utf-8") as f:
                                f.write(draft["content_text"] or "")
                        _promote_drafts_to_version(conn, cell_id, manager.run_id)
                        conn.commit()
                    conn.close()
                    break
                except Exception:
                    try:
                        conn.close()
                    except Exception:
                        pass
                    if _attempt < 2:
                        _time.sleep(0.3)
                    # On final failure, skip draft promotion — the message
                    # still gets queued and the generator will read the
                    # workspace files directly.

            manager._pending_user_messages.append(body.content)
            return {"ok": True, "cell_id": cell_id}

    raise HTTPException(404, f"No active generator run for cell {cell_id}")


# ---------------------------------------------------------------------------
# POST /chat/turn — inline chat turn, no generator subprocess
# ---------------------------------------------------------------------------

class ChatTurnRequest(BaseModel):
    content: str
    model: str = "sonnet"
    system_prompt: str = ""


class _InlineChatRun:
    """Minimal stand-in registered in ``active_managers`` so that
    ``_forward_bash_output_to_log`` can find us by
    ``placeholder_cell_id`` and append to our ``log_buffer``.
    Periodically flushed to the ``run_events`` table.
    """

    def __init__(self, channel: str, run_id: str, cell_id: str) -> None:
        self.channel = channel
        self.run_id = run_id
        self.placeholder_cell_id = cell_id
        self.log_buffer: deque[dict[str, str]] = deque()

    def flush_to_db(self) -> None:
        batch: list[dict[str, str]] = []
        while self.log_buffer:
            try:
                batch.append(self.log_buffer.popleft())
            except IndexError:
                break
        if not batch:
            return
        conn = get_db_connection(self.channel)
        conn.executemany(
            "INSERT INTO run_events (run_id, event_type, payload) "
            "VALUES (?, ?, ?)",
            [(self.run_id, item["type"], item["payload"]) for item in batch],
        )
        conn.commit()
        conn.close()


@router.post("/api/channels/{channel}/cells/{cell_id}/chat/turn")
async def chat_turn(channel: str, cell_id: str, body: ChatTurnRequest) -> dict:
    """Run one chat turn inline — no generator subprocess, no workspace
    hydration, no JIT flush. The endpoint creates a run row for
    lifecycle tracking, kicks off the turn in a background task, and
    returns the ``run_id`` immediately so the frontend can bind it to
    the cell for spinner/stop-button UI. Completion (or failure) is
    surfaced through the standard ``/runs/{run_id}/events`` SSE stream.
    """
    from routes.runs import active_managers

    # Normalize channel (URL path may use display casing, ``Starting``;
    # everything downstream — state-match, SSE broadcast, DB, session
    # lookup — uses the slug).
    channel = _slug_channel(channel)
    run_id = str(uuid.uuid4())

    # Create run row so the SSE events endpoint can track us.
    conn = get_db_connection(channel)
    conn.execute(
        "INSERT INTO runs (id, prompt, status) VALUES (?, ?, 'running')",
        (run_id, body.content[:200]),
    )
    conn.commit()
    conn.close()

    # Register a log-sink stub so _forward_bash_output_to_log works.
    stub = _InlineChatRun(channel, run_id, cell_id)
    active_managers[run_id] = stub

    asyncio.create_task(
        _run_inline_chat_turn(
            channel, cell_id, run_id, body.content,
            body.model, body.system_prompt, stub,
        )
    )

    return {"run_id": run_id, "cell_id": cell_id}


async def _run_inline_chat_turn(
    channel: str,
    cell_id: str,
    run_id: str,
    content: str,
    model: str,
    system_prompt: str,
    stub: _InlineChatRun,
) -> None:
    """Background task that drives one chat turn and commits the result."""
    from routes.runs import active_managers
    from chat_session import (
        start_session, send_turn, ChatSessionError,
        commit_chat_version, apply_chat_version_to_state,
        consume_pending_files, _sessions,
    )
    from genesis import GENERATORS_DIR
    from events import broadcast

    def _log(line: str) -> None:
        stub.log_buffer.append({"type": "stdout", "payload": line + "\n"})

    # The inline route bypasses the generator subprocess so there's no
    # gen.shared() to call — declare the image and dockerfile path here
    # against the bundled chat generator's shared/ directory.
    inline_image = "collimate-chat-worker"
    inline_dockerfile_dir = os.path.join(
        GENERATORS_DIR, "chat", "claude_code_chat", "shared",
    )

    try:
        # 1. Start or reuse the session.
        await start_session(
            channel_db_name=channel,
            cell_id=cell_id,
            model=model,
            system_prompt=system_prompt,
            backend="claude_code_session",
            image=inline_image,
            dockerfile_dir=inline_dockerfile_dir,
            shared=True,
        )
        stub.flush_to_db()

        # 2. Run the turn — streams chat_stream SSE events to the
        #    frontend via broadcast(), appends user+assistant messages
        #    to the in-memory cell, and stages file changes in the
        #    session's pending_file_hashes.
        result = await send_turn(
            channel_db_name=channel,
            cell_id=cell_id,
            content=content,
        )
        stub.flush_to_db()

        # 3. Consume pending file hashes from the session.
        pending = consume_pending_files(cell_id)

        # 4. Commit a new internal-version row.
        _new_cell_id, merged = commit_chat_version(
            channel, cell_id, run_id, pending,
        )
        apply_chat_version_to_state(channel, cell_id, merged, run_id)
        stub.flush_to_db()

        # 5. Mark run completed.
        conn = get_db_connection(channel)
        conn.execute(
            "UPDATE runs SET status='completed' WHERE id=?", (run_id,)
        )
        conn.commit()
        conn.close()

        # Broadcast a state_update so the frontend refreshes the cell.
        from state import state, channel_db_name as _chan_db
        for ch in state.channels:
            if _chan_db(ch) == _slug_channel(channel):
                broadcast(channel, {
                    "type": "state_update",
                    "channel": ch.model_dump(mode="json"),
                })
                break

    except Exception as exc:
        _logger.exception("[chat_turn] inline turn failed for cell %s", cell_id)
        conn = get_db_connection(channel)
        conn.execute(
            "UPDATE runs SET status='failed' WHERE id=?", (run_id,)
        )
        conn.execute(
            "INSERT INTO run_events (run_id, event_type, payload) "
            "VALUES (?, 'stderr', ?)",
            (run_id, f"Chat turn failed: {exc}"),
        )
        conn.commit()
        conn.close()
    finally:
        stub.flush_to_db()
        active_managers.pop(run_id, None)


# ---------------------------------------------------------------------------
# GET /all_cells — all cells in the channel for the history view
# ---------------------------------------------------------------------------

@router.get("/api/channels/{channel}/all_cells")
def get_all_cells(channel: str) -> dict:
    """Return every cell that has ever existed in this channel, plus the
    set of cell IDs currently on the canvas (in main_stacks).

    The frontend uses this to render the history grid in zoom-out mode,
    distinguishing active cells (normal opacity) from historical cells
    (dimmed, with a Restore action).
    """
    from state import state, channel_db_name

    conn = get_db_connection(channel)
    rows = conn.execute(
        "SELECT c.id AS cell_id, c.created_at, c.source_type, "
        "c.version_name, c.version_summary, c.generator_name, "
        "(SELECT COUNT(*) FROM cell_files WHERE cell_id=c.id) AS file_count "
        "FROM cells c ORDER BY c.created_at DESC",
    ).fetchall()
    conn.close()

    active_ids: set[str] = set()
    for ch in state.channels:
        if channel_db_name(ch) == _slug_channel(channel):
            for stack in ch.main_stacks:
                for cell in stack.cells:
                    active_ids.add(str(cell.id))
            break

    return {
        "cells": [dict(r) for r in rows],
        "active_cell_ids": list(active_ids),
    }


# ---------------------------------------------------------------------------
# POST /main/add_cell — add an existing cell (from history) back onto the canvas
# ---------------------------------------------------------------------------

class AddCellRequest(BaseModel):
    cell_id: str


@router.post("/api/channels/{channel}/main/add_cell")
def add_cell_to_main(channel: str, body: AddCellRequest) -> dict:
    """Add a cell from DB history back onto the canvas.

    Uses the original cell ID (no clone). Reads files from the version
    tip (latest version) so the added cell reflects the most recent
    state. Creates a new stack in main_stacks containing the cell.
    """
    from state import state, channel_db_name, persist_state
    from models import Stack, Cell as CellModel, VirtualFile
    from routes.runs import _find_version_tip

    # Refuse if the cell is already on the canvas.
    target_ch = None
    for ch in state.channels:
        if channel_db_name(ch) == _slug_channel(channel):
            target_ch = ch
            for stack in ch.main_stacks:
                for cell in stack.cells:
                    if str(cell.id) == body.cell_id:
                        raise HTTPException(400, "Cell is already on the canvas")
            break
    if target_ch is None:
        raise HTTPException(404, "Channel not found")

    conn = get_db_connection(channel)

    # Get cell metadata
    cell_row = conn.execute(
        "SELECT id, version_name, generator_name, created_at FROM cells WHERE id=?",
        (body.cell_id,),
    ).fetchone()
    if not cell_row:
        conn.close()
        raise HTTPException(404, "Cell not found in DB")

    # Resolve the version tip to get the latest files
    tip_id = _find_version_tip(conn, body.cell_id)
    files = conn.execute(
        "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?",
        (tip_id,),
    ).fetchall()
    conn.close()

    lang_map = {
        ".py": "python", ".js": "javascript", ".ts": "typescript",
        ".tsx": "typescript", ".jsx": "javascript", ".json": "json",
        ".md": "markdown", ".yaml": "yaml", ".yml": "yaml",
        ".html": "html", ".css": "css", ".sh": "shell",
    }

    vfiles = []
    for f in files:
        cas_path = os.path.join(
            ".collimate", "objects", f["blob_hash"][:2], f["blob_hash"][2:]
        )
        content = ""
        if os.path.exists(cas_path):
            try:
                with open(cas_path, "r", encoding="utf-8", errors="replace") as fh:
                    content = fh.read()
            except Exception:
                pass
        ext = os.path.splitext(f["filepath"])[1]
        vfiles.append(VirtualFile(
            name=f["filepath"],
            content=content,
            language=lang_map.get(ext, "plaintext"),
        ))

    cell_name = cell_row["version_name"] or cell_row["generator_name"] or "Restored"
    restored_cell = CellModel(
        id=body.cell_id,
        name=cell_name,
        summary=f"Restored from history",
        files=vfiles,
        channel=channel,
    )
    new_stack = Stack(name="", cells=[restored_cell])
    target_ch.main_stacks.append(new_stack)
    target_ch.main_selection_id = new_stack.id
    persist_state()

    return {"ok": True, "cell_id": body.cell_id, "stack_id": str(new_stack.id)}
