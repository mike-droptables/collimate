"""Cell version and history endpoints.

Cell versions are stored as linked rows in ``cell_edges`` via
``parent_key='previous_version'``. Each visible cell on the canvas is
the start of a version list — walking forward from it yields the full
sequence of versions produced by ``update_cell`` commits, user-edit
checkpoints, and other mutations. Restore creates a new DAG cell with
a provenance edge; fork creates a new independent cell.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import uuid
from collections import deque
from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from database import get_db_connection, _slug_channel
from runtime import IS_WASM, WasmNotSupportedError

_logger = logging.getLogger("cells")

router = APIRouter()


# ---------------------------------------------------------------------------
# Chain walking helpers
# ---------------------------------------------------------------------------

def _walk_versions(conn, start_cell_id: str) -> list[str]:
    """Walk cell_edges forward from start_cell_id via
    parent_key='previous_version'. Returns the ordered list of version
    cell ids, including start_cell_id at index 0.

    A single recursive CTE instead of one round-trip per edge. Matches
    the old loop's semantics: one arbitrary-but-stable child per parent
    (min rowid), a 10,000-step depth cap, and cycle tolerance — the cap
    bounds the query, and the visited-set dedupe below drops repeats.
    """
    rows = conn.execute(
        """
        WITH RECURSIVE chain(id, depth) AS (
            SELECT ?, 0
            UNION ALL
            SELECT (
                SELECT child_cell_id FROM cell_edges
                WHERE parent_cell_id = chain.id
                  AND parent_key = 'previous_version'
                ORDER BY rowid LIMIT 1
            ), chain.depth + 1
            FROM chain
            WHERE chain.depth < 10000
              AND (
                SELECT child_cell_id FROM cell_edges
                WHERE parent_cell_id = chain.id
                  AND parent_key = 'previous_version'
                ORDER BY rowid LIMIT 1
              ) IS NOT NULL
        )
        SELECT id FROM chain ORDER BY depth
        """,
        (start_cell_id,),
    ).fetchall()
    versions: list[str] = []
    seen: set[str] = set()
    for row in rows:
        cell_id = row[0]
        if cell_id in seen:
            break
        seen.add(cell_id)
        versions.append(cell_id)
    return versions


def _read_version_metadata(conn, cell_id: str) -> tuple[Optional[str], Optional[str]]:
    """Return (name, summary) for a cell from the cell row. O(1)."""
    row = conn.execute(
        "SELECT version_name, version_summary FROM cells WHERE id=?",
        (cell_id,),
    ).fetchone()
    if row:
        return row["version_name"], row["version_summary"]
    return None, None


def _read_cell_created_at(conn, cell_id: str) -> Optional[str]:
    row = conn.execute(
        "SELECT created_at FROM cells WHERE id=?", (cell_id,),
    ).fetchone()
    return row["created_at"] if row else None


def _read_cell_files(conn, cell_id: str) -> list[dict]:
    rows = conn.execute(
        "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=? ORDER BY filepath",
        (cell_id,),
    ).fetchall()
    return [{"filepath": r["filepath"], "blob_hash": r["blob_hash"]} for r in rows]


def _bulk_version_rows(conn, version_ids: list[str]) -> list[dict]:
    """Fetch cell metadata + file count for every id in a single pass.

    One query on ``cells`` and one GROUP BY on ``cell_files`` instead of
    2N round-trips, then zip back to the chain order. Rows missing from
    ``cells`` still appear (with all metadata None) so the return shape
    matches the old per-id loop exactly.
    """
    if not version_ids:
        return []
    placeholders = ",".join("?" for _ in version_ids)
    meta_rows = conn.execute(
        f"SELECT id, version_name, version_summary, source_type, created_at "
        f"FROM cells WHERE id IN ({placeholders})",
        version_ids,
    ).fetchall()
    meta_by_id = {r["id"]: r for r in meta_rows}
    count_rows = conn.execute(
        f"SELECT cell_id, COUNT(*) AS n FROM cell_files "
        f"WHERE cell_id IN ({placeholders}) GROUP BY cell_id",
        version_ids,
    ).fetchall()
    count_by_id = {r["cell_id"]: r["n"] for r in count_rows}
    out: list[dict] = []
    for idx, cell_id in enumerate(version_ids):
        meta = meta_by_id.get(cell_id)
        out.append({
            "cell_id": cell_id,
            "index": idx,
            "created_at": meta["created_at"] if meta else None,
            "name": meta["version_name"] if meta else None,
            "summary": meta["version_summary"] if meta else None,
            "source_type": meta["source_type"] if meta else None,
            "file_count": count_by_id.get(cell_id, 0),
        })
    return out


def _read_blob(blob_hash: str) -> Optional[str]:
    cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
    if not os.path.exists(cas_path):
        return None
    try:
        with open(cas_path, "r", encoding="utf-8", errors="replace") as fh:
            return fh.read()
    except OSError:
        return None


def _read_blob_text_or_ref(blob_hash: str) -> tuple[str, Optional[str]]:
    """Resolve a CAS blob to ``(content, blob_hash)`` without corrupting
    binary. A blob that decodes as UTF-8 returns ``(text, None)``; one
    that doesn't (an image, etc.) returns ``("", blob_hash)`` so the
    caller can build a binary ``VirtualFile`` that references CAS rather
    than handing back replacement-character garbage. A missing blob
    returns ``("", None)``."""
    cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
    if not os.path.exists(cas_path):
        return ("", None)
    try:
        with open(cas_path, "rb") as fh:
            raw = fh.read()
    except OSError:
        return ("", None)
    try:
        return (raw.decode("utf-8"), None)
    except UnicodeDecodeError:
        return ("", blob_hash)


def _language_for(path: str) -> str:
    ext = os.path.splitext(path)[1]
    lang_map = {
        ".py": "python", ".js": "javascript", ".ts": "typescript",
        ".tsx": "typescript", ".jsx": "javascript", ".json": "json",
        ".md": "markdown", ".yaml": "yaml", ".yml": "yaml",
        ".html": "html", ".css": "css", ".sh": "shell",
    }
    return lang_map.get(ext, "plaintext")


# ---------------------------------------------------------------------------
# GET /versions — list the internal-version chain
# ---------------------------------------------------------------------------

@router.get("/api/channels/{channel}/cells/{visible_cell_id}/versions")
def list_versions(channel: str, visible_cell_id: str) -> dict:
    """Return the ordered chain of internal versions for a visible cell,
    annotated with name/summary pulled from the most recent matching
    commit event.
    """
    # Version history needs the full version-chain schema (cell_edges with
    # parent_key='previous_version') that the wasm bootstrap doesn't
    # populate. Raising WasmNotSupportedError → 503 lets the frontend
    # show a clean "not available in playground" message instead of
    # surfacing the underlying schema error as a generic 500.
    if IS_WASM:
        raise WasmNotSupportedError("Version history is not available in the playground.")
    conn = get_db_connection(channel)
    try:
        version_ids = _walk_versions(conn, visible_cell_id)
        versions = _bulk_version_rows(conn, version_ids)
        return {
            "versions": versions,
            "current_index": len(versions) - 1,
        }
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# GET /timeline — version chain + DAG provenance edges for timeline view
# ---------------------------------------------------------------------------

@router.get("/api/channels/{channel}/cells/{visible_cell_id}/timeline")
def get_cell_timeline(channel: str, visible_cell_id: str) -> dict:
    """Return the full version chain with O(1) metadata per entry, plus
    any DAG provenance edges (branched_from) pointing into
    this cell's version chain from other visible cells.

    Designed for the timeline view where both the cell's internal history
    and its cross-cell relationships need to be rendered together.
    """
    conn = get_db_connection(channel)
    try:
        version_ids = _walk_versions(conn, visible_cell_id)
        version_set = set(version_ids)
        versions = _bulk_version_rows(conn, version_ids)

        # Find DAG edges pointing INTO any version in this cell's history
        # (e.g., other cells branched from a version here).
        dag_edges = []
        if version_ids:
            # parent_cell_id → index in the chain, so we can resolve
            # each edge's source_version_index without an O(n) list.index
            # inside the edge loop.
            parent_index = {cid: i for i, cid in enumerate(version_ids)}
            placeholders = ",".join("?" for _ in version_ids)
            rows = conn.execute(
                f"SELECT child_cell_id, parent_cell_id, parent_key "
                f"FROM cell_edges "
                f"WHERE parent_cell_id IN ({placeholders}) "
                f"AND parent_key IN ('branched_from', 'forked_from') ",
                version_ids,
            ).fetchall()
            for r in rows:
                parent_idx = parent_index.get(r["parent_cell_id"]) if r["parent_cell_id"] in version_set else None
                dag_edges.append({
                    "type": r["parent_key"],
                    "target_cell_id": r["child_cell_id"],
                    "source_version_index": parent_idx,
                })

        return {
            "versions": versions,
            "current_index": len(versions) - 1,
            "dag_edges": dag_edges,
        }
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# GET /files-tree — full file tree for a specific internal-version cell
# ---------------------------------------------------------------------------

@router.get("/api/channels/{channel}/cells/{internal_cell_id}/files-tree")
def get_cell_files_tree(channel: str, internal_cell_id: str) -> dict:
    """Read every cell_files row for an internal-version cell id and
    return a list of ``{name, language, content}`` objects the scrubber
    can hand straight to a read-only CellEditor.
    """
    conn = get_db_connection(channel)
    try:
        rows = _read_cell_files(conn, internal_cell_id)
    finally:
        conn.close()

    out = []
    for r in rows:
        content, bh = _read_blob_text_or_ref(r["blob_hash"])
        out.append({
            "name": r["filepath"],
            "language": "binary" if bh else _language_for(r["filepath"]),
            "content": content,
            "blob_hash": bh,
        })
    return {"cell_id": internal_cell_id, "files": out}


# ---------------------------------------------------------------------------
# POST /checkpoint — promote pending drafts into a version chain entry
# ---------------------------------------------------------------------------

def checkpoint_cell_internal(channel: str, cell_id: str) -> str | None:
    """Promote pending drafts into a cell version. Callable without HTTP context.

    Returns the new version cell_id, or None if no drafts were pending.
    """
    from routes.runs import _promote_drafts_to_version
    from state import state, channel_db_name

    # Resolve the cell's current in-memory files from state.json so a
    # never-versioned cell's synthesized genesis can be seeded with
    # the right content. Falls back to None if the cell can't be
    # located (the genesis will be empty — same as the pre-fix
    # behavior, never worse).
    current_files: list[dict] | None = None
    try:
        slug = _slug_channel(channel)
        for ch in state.channels:
            if channel_db_name(ch) != slug:
                continue
            for stk in [*ch.main_stacks, *ch.nav_stacks]:
                for c in stk.cells:
                    if str(c.id) == cell_id:
                        current_files = [
                            {"filepath": f.name, "content": f.content, "blob_hash": f.blob_hash}
                            for f in c.files
                        ]
                        break
                if current_files is not None:
                    break
            break
    except Exception:
        current_files = None

    run_id = str(uuid.uuid4())
    conn = get_db_connection(channel)
    conn.execute(
        "INSERT INTO runs (id, prompt, status) VALUES (?, ?, 'completed')",
        (run_id, "checkpoint"),
    )
    version_id = _promote_drafts_to_version(
        conn, cell_id, run_id, current_files=current_files,
    )
    conn.commit()
    conn.close()
    return version_id


@router.post("/api/channels/{channel}/cells/{cell_id}/checkpoint")
async def checkpoint_cell(channel: str, cell_id: str) -> dict:
    """Promote pending drafts for a cell into a permanent cell version.

    Called by the frontend on idle timeout (~60s), editor close, or other
    save triggers. If there are no pending drafts, returns
    ``{"created": false}``. Otherwise creates a new version at the tip
    with ``source_type='human_edit'``.

    The whole checkpoint pipeline (DB-write of the version row +
    DB-read of the new tip's cell_files + CAS reads + state mutation
    + persist_state) is sync; offload to a worker thread so a
    concurrent generator-subprocess writer can't stall the loop on
    the channel's WAL busy_timeout while we read the tip back.
    """
    def _do_checkpoint():
        version_id = checkpoint_cell_internal(channel, cell_id)
        if not version_id:
            return None

        from state import state, channel_db_name, persist_state, state_lock
        from cell_placement import find_stack_containing_cell
        from routes.runs import _find_version_tip

        for ch in state.channels:
            if channel_db_name(ch) == _slug_channel(channel):
                stack = find_stack_containing_cell(ch, cell_id)
                if stack:
                    tip_conn = get_db_connection(channel)
                    try:
                        tip_id = _find_version_tip(tip_conn, cell_id)
                        rows = tip_conn.execute(
                            "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?",
                            (tip_id,),
                        ).fetchall()
                    finally:
                        tip_conn.close()
                    from models import VirtualFile
                    vfiles = []
                    for r in rows:
                        content, bh = _read_blob_text_or_ref(r["blob_hash"])
                        vfiles.append(VirtualFile(
                            name=r["filepath"],
                            content=content,
                            language="binary" if bh else _language_for(r["filepath"]),
                            blob_hash=bh,
                        ))
                    # state_lock around the in-memory mutation so a
                    # concurrent worker-thread persist can't see a
                    # half-mutated cell.
                    with state_lock:
                        for c in stack.cells:
                            if str(c.id) == cell_id:
                                c.files = vfiles
                                from datetime import datetime
                                c.updated_at = datetime.now()
                                break
                    persist_state()
                break
        return version_id

    version_id = await asyncio.to_thread(_do_checkpoint)
    return {"created": bool(version_id), "version_id": version_id}


# ---------------------------------------------------------------------------
# POST /fork — create a new cell in a new stack right of the source
# ---------------------------------------------------------------------------

class ForkRequest(BaseModel):
    target_cell_id: str  # the internal-version cell id to fork from


@router.post("/api/channels/{channel}/cells/{visible_cell_id}/fork")
def fork_version(channel: str, visible_cell_id: str, body: ForkRequest) -> dict:
    """Create a brand-new visible cell in a new stack immediately right
    of the source stack, populated with the target version's files.
    The branch has its own id — it's a separate chain from the source.
    """
    from cell_placement import find_stack_containing_cell, insert_new_stack_right_of
    from state import state, channel_db_name, persist_state
    from models import Cell as CellModel, VirtualFile

    conn = get_db_connection(channel)
    try:
        version_ids = _walk_versions(conn, visible_cell_id)
        if body.target_cell_id not in version_ids:
            raise HTTPException(404, "target_cell_id is not in this cell's versions")
        target_files = _read_cell_files(conn, body.target_cell_id)

        run_id = str(uuid.uuid4())
        conn.execute(
            "INSERT INTO runs (id, prompt, status) VALUES (?, ?, 'completed')",
            (run_id, f"branch {body.target_cell_id[:8]}"),
        )

        branch_name, _ = _read_version_metadata(conn, body.target_cell_id)
        new_cell_id = str(uuid.uuid4())
        conn.execute(
            "INSERT INTO cells (id, run_id, generator_name, sequence_num, "
            "version_name, version_summary, source_type) "
            "VALUES (?, ?, 'history_scrubber_branch', 1, ?, ?, 'branch')",
            (new_cell_id, run_id,
             (branch_name or "Cell") + " (branch)",
             f"Branched from {body.target_cell_id[:8]}"),
        )
        # Provenance edge
        conn.execute(
            "INSERT OR IGNORE INTO cell_edges "
            "(parent_cell_id, child_cell_id, parent_key) VALUES (?, ?, 'branched_from')",
            (body.target_cell_id, new_cell_id),
        )
        for f in target_files:
            cas_path = os.path.join(".collimate", "objects", f["blob_hash"][:2], f["blob_hash"][2:])
            size = os.path.getsize(cas_path) if os.path.exists(cas_path) else 0
            conn.execute(
                "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                (f["blob_hash"], size),
            )
            conn.execute(
                "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                "VALUES (?, ?, ?)",
                (new_cell_id, f["filepath"], f["blob_hash"]),
            )
        conn.execute(
            "INSERT INTO run_events (run_id, event_type, payload) VALUES (?, 'commit', ?)",
            (
                run_id,
                json.dumps({
                    "cell_id": new_cell_id,
                    "name": (branch_name or "Cell") + " (branch)",
                    "summary": f"Branched from {body.target_cell_id[:8]}",
                    "sequence_num": 1,
                    "file_count": len(target_files),
                }),
            ),
        )
        conn.commit()
    finally:
        conn.close()

    # In-memory state update: new stack right of the source.
    target_channel = None
    for ch in state.channels:
        if channel_db_name(ch) == _slug_channel(channel):
            target_channel = ch
            break
    if target_channel is None:
        raise HTTPException(404, "channel not found in state")
    source_stack = find_stack_containing_cell(target_channel, visible_cell_id)
    if source_stack is None:
        raise HTTPException(404, "source stack not found in state")

    new_stack = insert_new_stack_right_of(target_channel, source_stack.id)
    vfiles = []
    for f in target_files:
        content, bh = _read_blob_text_or_ref(f["blob_hash"])
        vfiles.append(VirtualFile(
            name=f["filepath"],
            content=content,
            language="binary" if bh else _language_for(f["filepath"]),
            blob_hash=bh,
        ))
    new_cell = CellModel(
        id=new_cell_id,  # pyright: ignore[reportArgumentType] — pydantic coerces str→UUID
        name=(branch_name or "Cell") + " (branch)",
        summary=f"Branched from {body.target_cell_id[:8]}",
        files=vfiles,
        run_id=run_id,
        channel=_slug_channel(channel),  # canonical slug, not the raw URL param
    )
    new_stack.cells.insert(0, new_cell)
    persist_state()

    return {
        "ok": True,
        "new_cell_id": new_cell_id,
        "new_stack_id": str(new_stack.id),
        "forked_from": body.target_cell_id,
    }


# ---------------------------------------------------------------------------
# GET /all_cells — all cells in the channel for the history view
# ---------------------------------------------------------------------------

@router.get("/api/channels/{channel}/all_cells")
def get_all_cells(channel: str) -> dict:
    """Return every cell that has ever existed in this channel, plus the
    set of cell IDs currently on the canvas (in main_stacks).

    The frontend uses this to render the history grid in zoom-out mode,
    distinguishing active cells (normal opacity) from historical cells
    (dimmed, with a Restore action).
    """
    # The history view walks every row the cells table has ever held
    # (including non-current versions). The pyodide shim doesn't
    # populate that trail, so raise → 503 and let the frontend render
    # a clean "not in playground" message instead of a 500.
    if IS_WASM:
        raise WasmNotSupportedError("History view is not available in the playground.")
    from state import state, channel_db_name

    conn = get_db_connection(channel)
    # Exclude the throwaway live cells of ephemeral runs (source_type
    # 'ephemeral') for parity with the DAG view; legacy NULL rows are kept.
    rows = conn.execute(
        "SELECT c.id AS cell_id, c.created_at, c.source_type, "
        "c.version_name, c.version_summary, c.generator_name, "
        "(SELECT COUNT(*) FROM cell_files WHERE cell_id=c.id) AS file_count "
        "FROM cells c WHERE c.deleted_at IS NULL "
        "AND (c.source_type IS NULL OR c.source_type != 'ephemeral') "
        "ORDER BY c.created_at DESC",
    ).fetchall()
    conn.close()

    active_ids: set[str] = set()
    for ch in state.channels:
        if channel_db_name(ch) == _slug_channel(channel):
            for stack in ch.main_stacks:
                for cell in stack.cells:
                    active_ids.add(str(cell.id))
            break

    return {
        "cells": [dict(r) for r in rows],
        "active_cell_ids": list(active_ids),
    }


# ---------------------------------------------------------------------------
# GET /dag — full lineage DAG (cells + edges + runs) for the history view
# ---------------------------------------------------------------------------

@router.get("/api/channels/{channel}/dag")
def get_channel_dag(channel: str) -> dict:
    """Return the full cell lineage DAG for the channel: every non-deleted
    cell, every edge between non-deleted cells, the runs that produced
    them, and the set of cell IDs currently mounted in main_stacks.

    The frontend renders this as a vertical "subway map" where cells are
    nodes (oldest at top, latest at bottom) and edges connect parents to
    children. The shape mirrors the channel DB schema so a single GET
    is enough to draw the whole view client-side.
    """
    if IS_WASM:
        raise WasmNotSupportedError("History view is not available in the playground.")
    from state import state, channel_db_name

    conn = get_db_connection(channel)

    cell_rows = conn.execute(
        "SELECT c.id AS cell_id, c.created_at, c.source_type, "
        "c.version_name, c.version_summary, c.generator_name, c.run_id "
        "FROM cells c WHERE c.deleted_at IS NULL "
        "ORDER BY c.created_at ASC, c.id ASC",
    ).fetchall()

    edge_rows = conn.execute(
        "SELECT e.parent_cell_id, e.child_cell_id, e.parent_key "
        "FROM cell_edges e "
        "JOIN cells cp ON cp.id = e.parent_cell_id "
        "JOIN cells cc ON cc.id = e.child_cell_id "
        "WHERE cp.deleted_at IS NULL AND cc.deleted_at IS NULL",
    ).fetchall()

    # File names per cell — the DAG node body shows them as a short list,
    # the way the zoom-out grid view does. Single query, grouped client-
    # side; blob_hash is captured so we can pull message JSON below
    # without a second pass.
    file_rows = conn.execute(
        "SELECT cf.cell_id, cf.filepath, cf.blob_hash "
        "FROM cell_files cf "
        "JOIN cells c ON c.id = cf.cell_id "
        "WHERE c.deleted_at IS NULL "
        "ORDER BY cf.cell_id, cf.filepath",
    ).fetchall()

    # Drop the throwaway live cells of ephemeral runs (browser sessions and
    # the like): they carry source_type='ephemeral' and never belong in the
    # history DAG. Their persistent capture side-cells keep source_type
    # 'generator' and survive. Edges/files for dropped cells go with them.
    cell_rows = [r for r in cell_rows if r["source_type"] != "ephemeral"]
    keep = {r["cell_id"] for r in cell_rows}
    edge_rows = [r for r in edge_rows
                 if r["parent_cell_id"] in keep and r["child_cell_id"] in keep]
    file_rows = [r for r in file_rows if r["cell_id"] in keep]

    files_by_cell: dict[str, list[str]] = {}
    message_blobs: dict[str, str] = {}
    MESSAGE_FILE_NAMES = (
        ".colreserved/.collimate_messages.json",
        ".collimate_messages.json",
    )
    for r in file_rows:
        cid = r["cell_id"]
        files_by_cell.setdefault(cid, []).append(r["filepath"])
        if r["filepath"] in MESSAGE_FILE_NAMES and cid not in message_blobs:
            message_blobs[cid] = r["blob_hash"]

    # Parse message JSON for any cell that ships a messages file. Bad
    # JSON or unreadable blobs are silently skipped — the cell body
    # falls back to the markdown summary on the client.
    messages_by_cell: dict[str, list[dict]] = {}
    for cid, blob_hash in message_blobs.items():
        content = _read_blob(blob_hash)
        if not content:
            continue
        try:
            parsed = json.loads(content)
        except (json.JSONDecodeError, ValueError):
            continue
        if isinstance(parsed, list):
            messages_by_cell[cid] = parsed

    # Pick one representative generator_name per run so the filter UI can
    # group "all cells from this run" without scanning the full cell list
    # client-side.
    run_rows = conn.execute(
        "SELECT r.id AS run_id, r.prompt, r.status, r.created_at, "
        "(SELECT generator_name FROM cells WHERE run_id=r.id "
        " AND generator_name IS NOT NULL LIMIT 1) AS generator_name "
        "FROM runs r",
    ).fetchall()
    conn.close()

    active_ids: set[str] = set()
    for ch in state.channels:
        if channel_db_name(ch) == _slug_channel(channel):
            for stack in ch.main_stacks:
                for cell in stack.cells:
                    active_ids.add(str(cell.id))
            break

    enriched_cells = []
    for r in cell_rows:
        cid = r["cell_id"]
        names = files_by_cell.get(cid, [])
        enriched_cells.append({
            **dict(r),
            "file_count": len(names),
            "file_names": names,
            "messages": messages_by_cell.get(cid, []),
        })

    return {
        "cells": enriched_cells,
        "edges": [dict(r) for r in edge_rows],
        "runs": [dict(r) for r in run_rows],
        "active_cell_ids": list(active_ids),
    }


# ---------------------------------------------------------------------------
# POST /main/add_cell — add an existing cell (from history) back onto the canvas
# ---------------------------------------------------------------------------

class AddCellRequest(BaseModel):
    cell_id: str


@router.post("/api/channels/{channel}/main/add_cell")
def add_cell_to_main(channel: str, body: AddCellRequest) -> dict:
    """Add a cell from DB history back onto the canvas.

    Uses the original cell ID (no clone). Reads files from the version
    tip (latest version) so the added cell reflects the most recent
    state. Creates a new stack in main_stacks containing the cell.
    """
    from state import state, channel_db_name, persist_state
    from models import Stack, Cell as CellModel, VirtualFile
    from routes.runs import _find_version_tip

    # Refuse if the cell is already on the canvas.
    target_ch = None
    for ch in state.channels:
        if channel_db_name(ch) == _slug_channel(channel):
            target_ch = ch
            for stack in ch.main_stacks:
                for cell in stack.cells:
                    if str(cell.id) == body.cell_id:
                        raise HTTPException(400, "Cell is already on the canvas")
            break
    if target_ch is None:
        raise HTTPException(404, "Channel not found")

    conn = get_db_connection(channel)

    # Get cell metadata
    cell_row = conn.execute(
        "SELECT id, version_name, generator_name, created_at FROM cells WHERE id=?",
        (body.cell_id,),
    ).fetchone()
    if not cell_row:
        conn.close()
        raise HTTPException(404, "Cell not found in DB")

    # Resolve the version tip to get the latest files
    tip_id = _find_version_tip(conn, body.cell_id)
    files = conn.execute(
        "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?",
        (tip_id,),
    ).fetchall()
    conn.close()

    lang_map = {
        ".py": "python", ".js": "javascript", ".ts": "typescript",
        ".tsx": "typescript", ".jsx": "javascript", ".json": "json",
        ".md": "markdown", ".yaml": "yaml", ".yml": "yaml",
        ".html": "html", ".css": "css", ".sh": "shell",
    }

    vfiles = []
    for f in files:
        cas_path = os.path.join(
            ".collimate", "objects", f["blob_hash"][:2], f["blob_hash"][2:]
        )
        content = ""
        if os.path.exists(cas_path):
            try:
                with open(cas_path, "r", encoding="utf-8", errors="replace") as fh:
                    content = fh.read()
            except Exception:
                pass
        ext = os.path.splitext(f["filepath"])[1]
        vfiles.append(VirtualFile(
            name=f["filepath"],
            content=content,
            language=lang_map.get(ext, "plaintext"),
        ))

    cell_name = cell_row["version_name"] or cell_row["generator_name"] or "Restored"
    restored_cell = CellModel(
        id=body.cell_id,  # pyright: ignore[reportArgumentType] — pydantic coerces str→UUID
        name=cell_name,
        summary="Restored from history",
        files=vfiles,
        channel=_slug_channel(channel),  # canonical slug, not the raw URL param
    )
    new_stack = Stack(name="", cells=[restored_cell])
    target_ch.main_stacks.append(new_stack)
    target_ch.main_selection_id = new_stack.id
    persist_state()

    return {"ok": True, "cell_id": body.cell_id, "stack_id": str(new_stack.id)}
