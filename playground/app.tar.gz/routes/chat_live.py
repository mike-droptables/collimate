"""Live chat session bridge.

A WebSocket endpoint bridging a browser-side chat renderer to the running
generator that serves the chat. Mirrors :mod:`routes.terminal`: a generator
calls ``gen.serve_chat(...)``, which registers a session here (via the
``chat_register`` IPC op handled in ``process_manager/ipc.py``) and writes &
pins a ``.chat`` session pointer (``conversation.chat`` — see
collimate/pointers.py ``chat_session_pointer``) ``{session_id, ws_path,
token, label, threads_dir, active_thread, threads, integration}``; the
``assistant`` renderer opens a WebSocket against ``ws_path``.

Unlike the terminal (which relays raw PTY bytes), the chat channel relays
JSON turns:

  * renderer → core: ``{"t": "user_msg"|"interrupt"|"redirect", "content"?,
    "thread_id"?}``, thread control ``{"t": "thread_new"|"thread_switch",
    "thread_id"?}``, or transcript curation ``{"t": "edit"|"delete"|"insert"
    |"move"|"regenerate", "index", "content"?, "role"?, "to"?}``
  * core → renderer: ``{"t": "turn_start"|"delta"|"thinking_delta"|"tool"
    |"turn_end"|"error"|"history"|"busy", ...}`` — turn-scoped frames carry
    the turn's bound ``thread_id`` (a turn keeps generating in the background
    when the renderer switches threads, so frames must be thread-scoped)

The generator produces the core→renderer events: it emits them over IPC
(``stream_event`` op) and the host routes them onto this session's outbox via
:func:`push_event`. Inbound renderer commands land on the session's inbox via
:func:`pop_command`, which the generator drains through the ``chat_poll`` op.

Sessions are **detach-tolerant**: a renderer disconnect (reload, navigate
away) leaves the session alive so the generator keeps running. The same token
may re-attach, and on (re)attach the current turn's accumulated text is
replayed so a reload mid-turn re-materializes the partial reply. A session is
torn down from the run-cleanup path (:func:`unregister_chat_sessions_for_cell`)
when the generator exits; a dead session makes the renderer fall back to the
read-only per-thread transcripts (``chats/<id>.json``).
"""

from __future__ import annotations

import asyncio
import json
import secrets
import uuid
from dataclasses import dataclass, field
from typing import Optional

from fastapi import APIRouter, Query, WebSocket, WebSocketDisconnect
from starlette.websockets import WebSocketState

router = APIRouter()

# Cap the per-session outbox so a generator that streams into a detached
# renderer can't grow memory without bound. The canonical reply always lands
# in the thread's transcript file, so dropping the oldest buffered deltas
# is cosmetic.
_OUTBOX_MAX = 2048


@dataclass
class ChatSession:
    session_id: str
    cell_id: str
    run_id: str
    token: str
    inbox: asyncio.Queue = field(default_factory=asyncio.Queue)
    outbox: asyncio.Queue = field(default_factory=lambda: asyncio.Queue(maxsize=_OUTBOX_MAX))
    # Accumulated assistant text/thinking of the in-flight turn, replayed to a
    # (re)attaching renderer so a reload mid-turn re-materializes. Single slot
    # — serve_chat is single-flight; N>1 turns would need a per-turn dict.
    in_progress_text: str = ""
    in_progress_thinking: str = ""
    in_progress_turn_id: str = ""
    in_progress_thread_id: str = ""
    attached: bool = False
    closed: bool = False


_sessions: dict[str, ChatSession] = {}


# ---------------------------------------------------------------------------
# Registry API — called from process_manager/ipc.py via IPC ops + run cleanup
# ---------------------------------------------------------------------------

def register_chat_session(cell_id: str, run_id: str) -> dict:
    """Allocate a session id + auth token for a cell's live chat.

    Returns ``{session_id, ws_path, token}`` for the generator's ``.chat``
    pointer (and the token the IPC ack passes back to the SDK).
    """
    # One live chat per cell — drop any stale session first.
    unregister_chat_sessions_for_cell(cell_id)
    session_id = f"chat_{uuid.uuid4().hex[:16]}"
    token = secrets.token_urlsafe(24)
    _sessions[session_id] = ChatSession(
        session_id=session_id,
        cell_id=cell_id,
        run_id=run_id,
        token=token,
    )
    return {
        "session_id": session_id,
        "ws_path": f"/api/chats/{session_id}",
        "token": token,
    }


def get_session_for_cell(cell_id: str) -> Optional[ChatSession]:
    for s in _sessions.values():
        if s.cell_id == cell_id and not s.closed:
            return s
    return None


def push_event(cell_id: str, turn_id: str, event: dict) -> None:
    """Route a generator-emitted stream event to the cell's session.

    Tracks the in-flight turn's accumulated text (for reconnect replay) and
    enqueues the event for the WebSocket pump when a renderer is attached.
    Called from the ``stream_event`` IPC op.
    """
    session = get_session_for_cell(cell_id)
    if session is None or session.closed:
        return
    etype = event.get("type")
    if etype == "turn_start":
        session.in_progress_text = ""
        session.in_progress_thinking = ""
        session.in_progress_turn_id = turn_id
        session.in_progress_thread_id = event.get("thread_id", "") or ""
    elif etype == "text_delta":
        session.in_progress_text += event.get("text", "") or ""
    elif etype == "thinking_delta":
        session.in_progress_thinking += event.get("text", "") or ""
    elif etype == "turn_end":
        session.in_progress_text = ""
        session.in_progress_thinking = ""
        session.in_progress_turn_id = ""
        session.in_progress_thread_id = ""
    # Only buffer for the wire when someone is listening — otherwise the live
    # deltas are stale on reattach (the partial is replayed from
    # ``in_progress_text`` instead, and completed turns from the transcript).
    if session.attached:
        _outbox_put(session, {"turn_id": turn_id, "event": event})


def _outbox_put(session: ChatSession, item) -> None:
    try:
        session.outbox.put_nowait(item)
    except asyncio.QueueFull:
        try:
            session.outbox.get_nowait()  # drop oldest
            session.outbox.put_nowait(item)
        except (asyncio.QueueEmpty, asyncio.QueueFull):
            pass


def pop_command(cell_id: str) -> Optional[dict]:
    """Non-blocking pop of the next inbound renderer command for the cell's
    session (``{kind, content?}``). Called from the ``chat_poll`` IPC op."""
    session = get_session_for_cell(cell_id)
    if session is None:
        return None
    try:
        return session.inbox.get_nowait()
    except asyncio.QueueEmpty:
        return None


def unregister_chat_session(session_id: str) -> None:
    session = _sessions.pop(session_id, None)
    if session is None:
        return
    session.closed = True
    # Wake a blocked pump so the socket closes promptly.
    _outbox_put(session, None)


def unregister_chat_sessions_for_cell(cell_id: str) -> None:
    """Drop every session for a cell. Called from run-cleanup so stale
    sessions don't leak when a generator exits."""
    for sid, s in list(_sessions.items()):
        if s.cell_id == cell_id:
            unregister_chat_session(sid)


# ---------------------------------------------------------------------------
# WebSocket route
# ---------------------------------------------------------------------------

def _to_frame(turn_id: str, event: dict) -> dict:
    """Translate a generator stream event to a renderer wire frame. Turn-scoped
    frames carry the turn's bound ``thread_id`` when the generator provides it
    (``thinking_delta`` / ``busy`` ride the generic passthrough)."""
    etype = event.get("type", "")
    if etype == "text_delta":
        frame = {"t": "delta", "turn_id": turn_id, "text": event.get("text", "")}
    elif etype == "turn_start":
        frame = {"t": "turn_start", "turn_id": turn_id}
    elif etype == "turn_end":
        frame = {"t": "turn_end", "turn_id": turn_id}
    elif etype == "tool":
        return {"t": "tool", "turn_id": turn_id,
                **{k: v for k, v in event.items() if k != "type"}}
    elif etype == "error":
        frame = {"t": "error", "turn_id": turn_id, "message": event.get("message", "")}
    else:
        # Pass anything else through under its own type name.
        return {"t": etype or "event", "turn_id": turn_id,
                **{k: v for k, v in event.items() if k != "type"}}
    tid = event.get("thread_id")
    if tid:
        frame["thread_id"] = tid
    return frame


async def _reject(websocket: WebSocket, code: int, reason: str) -> None:
    """Accept the upgrade, then close with an app close code. Closing
    pre-accept sends a plain HTTP 403 handshake rejection, which strips the
    code — the renderer then can't tell "session gone, stop" (4404/4401)
    from "someone else holds it" (4409) or a transient failure, and retries
    a dead session forever."""
    await websocket.accept()
    await websocket.close(code=code, reason=reason)


@router.websocket("/api/chats/{session_id}")
async def chat_ws(
    websocket: WebSocket,
    session_id: str,
    token: str = Query(default=""),
):
    session = _sessions.get(session_id)
    if session is None or session.closed:
        await _reject(websocket, 4404, "no such session")
        return
    if not token or not secrets.compare_digest(token, session.token):
        await _reject(websocket, 4401, "bad token")
        return
    if session.attached:
        await _reject(websocket, 4409, "session already attached")
        return

    await websocket.accept()

    # Drop any leftover buffered events from a prior attach, then replay the
    # current turn's partial so a reload re-materializes it before going live.
    # Replayed whenever a turn is IN FLIGHT, even with no text yet (a
    # tool-phase turn) — otherwise the renderer shows an idle composer while
    # the generator is mid-turn.
    _drain(session.outbox)
    if session.in_progress_turn_id:
        try:
            await websocket.send_text(json.dumps({
                "t": "history",
                "turn_id": session.in_progress_turn_id,
                "thread_id": session.in_progress_thread_id,
                "text": session.in_progress_text,
                "thinking": session.in_progress_thinking,
            }))
        except Exception:
            await websocket.close()
            return
    session.attached = True

    async def _pump_to_ws() -> None:
        while True:
            item = await session.outbox.get()
            if item is None:  # session closed
                return
            try:
                await websocket.send_text(json.dumps(
                    _to_frame(item.get("turn_id", ""), item.get("event", {}))
                ))
            except Exception:
                return

    async def _pump_from_ws() -> None:
        while True:
            try:
                msg = await websocket.receive()
            except WebSocketDisconnect:
                return
            except Exception:
                return
            if msg.get("type") == "websocket.disconnect":
                return
            text = msg.get("text")
            if text is None:
                continue
            try:
                payload = json.loads(text)
            except json.JSONDecodeError:
                continue
            t = payload.get("t")
            if t == "user_msg":
                # thread_id names the thread the user typed in — serve_chat
                # treats it as authoritative (heals a lost thread_switch).
                cmd = {"kind": "user_msg", "content": payload.get("content", ""),
                       "thread_id": payload.get("thread_id", "")}
            elif t == "interrupt":
                # thread_id scopes the cancel to the visible thread's turn;
                # absent (legacy renderer) → cancel whatever is in flight.
                cmd = {"kind": "interrupt", "thread_id": payload.get("thread_id", "")}
            elif t == "redirect":
                cmd = {"kind": "redirect", "content": payload.get("content", ""),
                       "thread_id": payload.get("thread_id", "")}
            elif t == "thread_new":
                cmd = {"kind": "thread_new", "thread_id": payload.get("thread_id", "")}
            elif t == "thread_switch":
                cmd = {"kind": "thread_switch", "thread_id": payload.get("thread_id", "")}
            elif t == "edit":
                cmd = {"kind": "edit", "index": payload.get("index"),
                       "content": payload.get("content", "")}
            elif t == "delete":
                cmd = {"kind": "delete", "index": payload.get("index")}
            elif t == "insert":
                cmd = {"kind": "insert", "index": payload.get("index"),
                       "role": payload.get("role", "user"),
                       "content": payload.get("content", "")}
            elif t == "move":
                cmd = {"kind": "move", "index": payload.get("index"),
                       "to": payload.get("to")}
            elif t == "regenerate":
                cmd = {"kind": "regenerate", "index": payload.get("index")}
            else:
                continue
            session.inbox.put_nowait(cmd)

    to_task = asyncio.create_task(_pump_to_ws())
    from_task = asyncio.create_task(_pump_from_ws())
    try:
        _done, pending = await asyncio.wait(
            {to_task, from_task}, return_when=asyncio.FIRST_COMPLETED,
        )
        for t in pending:
            t.cancel()
    finally:
        session.attached = False
        _drain(session.outbox)
        if websocket.client_state != WebSocketState.DISCONNECTED:
            try:
                await websocket.close()
            except Exception:
                pass


def _drain(q: asyncio.Queue) -> None:
    try:
        while True:
            q.get_nowait()
    except asyncio.QueueEmpty:
        pass
