"""Draft cell endpoints.

A Draft cell is a pre-run config cell persisted in the `cells` table with
`state='Draft'`. Its files live in the `draft_cell_files` table (full
inline content, not CAS). Draft cells have parent edges pinned to
specific Standard versions but do not themselves become DAG producers —
they cannot have children until promoted to Standard via a run.

Endpoints:
  POST /api/cells/draft                   — create Draft from picker output
  GET  /api/cells/{id}/draft-files        — list / read Draft files
  PUT  /api/cells/{id}/draft-files/{path} — upsert one Draft file's content
  DELETE /api/cells/{id}/draft-files/{path} — remove one Draft file
  DELETE /api/cells/{id}                   — delete Draft (state-aware)
  POST /api/cells/{id}/promote            — flip Draft → Standard and run
"""
from __future__ import annotations

import json
import uuid
from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from database import get_db_connection
from models import Cell, CellState, Stack, VirtualFile

router = APIRouter()


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------

class CreateDraftRequest(BaseModel):
    # Optional client-provided cell id. When the Draft comes from a
    # Picking cell, the Picking's client UUID is passed through so the
    # cell id is stable across Picking → Draft → Standard. If omitted,
    # the backend generates one.
    cell_id: str | None = None
    # Optional client-provided stack id. Matching the Picking's stack
    # id gives the UI a seamless visual transition — the synthetic
    # Picking stack animates out and the real Draft stack takes its
    # exact slot using the same key. If omitted, a fresh stack id is
    # minted.
    stack_id: str | None = None
    parent_cell_ids: list[str] = []
    # Optional — a Draft without a generator is a plain content-authoring
    # Draft that becomes a Standard cell on Run with no execution.
    generator_id: str | None = None
    settings: dict | None = None
    initial_files: dict[str, str] = {}  # filepath -> content
    # Insert the Draft's new stack right of this stack in the active
    # channel's main_stacks. If null, append to the end.
    insert_after_stack_id: str | None = None
    # Optional display name for the Draft's generator (used in the banner).
    generator_display_name: str | None = None
    # Optional file path (within initial_files) that the Draft editor
    # should open as the first/summary tab. Maps to cell.summary_artifact.
    summary_file: str | None = None


class DraftFileUpsert(BaseModel):
    content: str


class PromoteDraftRequest(BaseModel):
    prompt: str = ""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_channel():
    from state import state
    if not state.active_channel_id:
        raise HTTPException(400, "No active channel")
    ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
    if not ch:
        raise HTTPException(400, "Active channel not found")
    return ch


def _require_draft_row(conn, cell_id: str):
    row = conn.execute(
        "SELECT id, state FROM cells WHERE id=?", (cell_id,)
    ).fetchone()
    if not row:
        raise HTTPException(404, f"Cell '{cell_id}' not found")
    if row["state"] != "Draft":
        raise HTTPException(409, f"Cell '{cell_id}' is not in Draft state (state={row['state']})")
    return row


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.post("/api/cells/draft")
async def create_draft(req: CreateDraftRequest):
    """Create a Draft cell. Persists the row + draft files to the DB and
    inserts a visible Cell into the active channel's state so the Draft
    appears on the canvas (new stack right of insert_after_stack_id).
    """
    from state import persist_state
    import uuid as _uuid
    ch = _get_channel()
    channel_name = getattr(ch, "name", "starting") or "starting"

    # ID continuity: prefer the client-provided id (the Picking cell's
    # UUID) so the id stays stable across Picking → Draft → Standard.
    cell_id_str = req.cell_id or str(_uuid.uuid4())
    # Validate client-provided id is a uuid — we don't want arbitrary
    # strings becoming cell ids.
    try:
        _uuid.UUID(cell_id_str)
    except ValueError:
        raise HTTPException(400, f"cell_id must be a valid UUID (got {cell_id_str!r})")

    # Build the visible Cell for state.channels first so DB and state
    # agree on the same id.
    files = [
        VirtualFile(name=path, content=content)
        for path, content in (req.initial_files or {}).items()
    ]
    gen_label = req.generator_display_name or req.generator_id or "(blank)"
    cell = Cell(
        id=_uuid.UUID(cell_id_str),
        name=f"Draft: {gen_label}",
        summary="",
        files=files,
        state=CellState.DRAFT,
        draft_generator_id=req.generator_id,
        settings=req.settings,
        channel=channel_name,
        # summary_file flows into the existing summary_artifact field
        # so the Draft editor opens the right tab first via the same
        # logic that drives Standard cells' summary tabs.
        summary_artifact=req.summary_file,
    )

    # Insert a new single-cell stack at the requested position, reusing
    # the Picking's stack id when provided so the UI renders the
    # transition as a single continuous slot.
    stack_id_val = None
    if req.stack_id:
        try:
            stack_id_val = _uuid.UUID(req.stack_id)
        except ValueError:
            raise HTTPException(400, "stack_id must be a valid UUID")
    new_stack = (
        Stack(id=stack_id_val, name="", cells=[cell])
        if stack_id_val is not None
        else Stack(name="", cells=[cell])
    )
    insert_idx = len(ch.main_stacks)
    if req.insert_after_stack_id:
        for i, s in enumerate(ch.main_stacks):
            if str(s.id) == req.insert_after_stack_id:
                insert_idx = i + 1
                break
    ch.main_stacks.insert(insert_idx, new_stack)
    ch.main_selection_id = new_stack.id

    cell_id = str(cell.id)
    conn = get_db_connection(channel_name)
    try:
        settings_json = (
            json.dumps(req.settings) if req.settings is not None else None
        )
        conn.execute(
            "INSERT INTO cells (id, generator_name, state, pickoptions_json, source_type) "
            "VALUES (?, ?, 'Draft', ?, 'draft')",
            (cell_id, req.generator_id, settings_json),
        )
        # Version pinning: every parent edge points at the parent's
        # current version tip, not the raw visible cell id. That way
        # future commits on the parent don't silently change what this
        # Draft depends on.
        from routes.runs import _find_version_tip
        for idx, parent_id in enumerate(req.parent_cell_ids):
            try:
                pinned = _find_version_tip(conn, parent_id)
            except Exception:
                pinned = parent_id
            conn.execute(
                "INSERT OR IGNORE INTO cell_edges (parent_cell_id, child_cell_id, parent_key) "
                "VALUES (?, ?, ?)",
                (pinned, cell_id, f"input_{idx}"),
            )
        for path, content in (req.initial_files or {}).items():
            conn.execute(
                "INSERT OR REPLACE INTO draft_cell_files (cell_id, filepath, content_text) "
                "VALUES (?, ?, ?)",
                (cell_id, path, content),
            )
        conn.commit()
    finally:
        conn.close()

    persist_state()
    return {
        "id": cell_id,
        "state": "Draft",
        "generator_id": req.generator_id,
        "parent_cell_ids": req.parent_cell_ids,
        "settings": req.settings,
        "files": list((req.initial_files or {}).keys()),
        "channel": ch,
    }


@router.get("/api/cells/{cell_id}/draft-files")
async def list_draft_files(cell_id: str):
    ch = _get_channel()
    conn = get_db_connection(getattr(ch, "name", "starting") or "starting")
    try:
        _require_draft_row(conn, cell_id)
        rows = conn.execute(
            "SELECT filepath, content_text, updated_at FROM draft_cell_files "
            "WHERE cell_id=? ORDER BY filepath",
            (cell_id,),
        ).fetchall()
        return [
            {
                "filepath": r["filepath"],
                "content": r["content_text"],
                "updated_at": r["updated_at"],
            }
            for r in rows
        ]
    finally:
        conn.close()


@router.put("/api/cells/{cell_id}/draft-files/{filepath:path}")
async def upsert_draft_file(cell_id: str, filepath: str, body: DraftFileUpsert):
    ch = _get_channel()
    conn = get_db_connection(getattr(ch, "name", "starting") or "starting")
    try:
        _require_draft_row(conn, cell_id)
        conn.execute(
            "INSERT INTO draft_cell_files (cell_id, filepath, content_text) "
            "VALUES (?, ?, ?) "
            "ON CONFLICT(cell_id, filepath) DO UPDATE SET "
            "  content_text=excluded.content_text, "
            "  updated_at=CURRENT_TIMESTAMP",
            (cell_id, filepath, body.content),
        )
        conn.commit()
        return {"ok": True}
    finally:
        conn.close()


@router.delete("/api/cells/{cell_id}/draft-files/{filepath:path}")
async def delete_draft_file(cell_id: str, filepath: str):
    ch = _get_channel()
    conn = get_db_connection(getattr(ch, "name", "starting") or "starting")
    try:
        _require_draft_row(conn, cell_id)
        conn.execute(
            "DELETE FROM draft_cell_files WHERE cell_id=? AND filepath=?",
            (cell_id, filepath),
        )
        conn.commit()
        return {"ok": True}
    finally:
        conn.close()


@router.delete("/api/cells/{cell_id}")
async def delete_cell(cell_id: str, confirmed: bool = False):
    """State-aware cell deletion (unified per the plan).

    - Picking: not applicable here — Picking is client-only and never
      hits this endpoint.
    - Draft: requires `confirmed=true`. Removes the cells row,
      draft_cell_files rows, edges, and the in-memory Cell + Stack.
    - Standard: soft-deletes the cell and its version chain via
      deleted_at, purges cell_files rows, and drops any CAS blobs
      whose refcount reaches zero. Refuses if the cell currently
      has an active run. Child cells that captured this as an
      input_N parent keep their edges — the input was captured at
      their creation time and that fact is preserved even after
      deletion.
    """
    from state import persist_state, state as _state
    from cell_cleanup import soft_delete_cell
    ch = _get_channel()
    channel_name = getattr(ch, "name", "starting") or "starting"
    conn = get_db_connection(channel_name)
    try:
        row = conn.execute("SELECT state FROM cells WHERE id=?", (cell_id,)).fetchone()
    finally:
        conn.close()

    cell_state = row["state"] if row else None
    if cell_state == "Draft":
        if not confirmed:
            raise HTTPException(409, "Draft deletion requires confirmed=true")
        return await delete_draft(cell_id)

    # Standard (or unknown row, treated as Standard).
    # Refuse to delete a Standard cell that's currently running.
    from routes.runs import active_managers
    is_running = any(
        getattr(m, "placeholder_cell_id", None) == cell_id
        and (m.process and m.process.returncode is None)
        for m in active_managers.values()
    )
    if is_running:
        raise HTTPException(409, "Cannot delete a Standard cell with an active run")

    # Soft-delete the version chain and clean up unreferenced blobs.
    conn = get_db_connection(channel_name)
    try:
        stats = soft_delete_cell(conn, cell_id)
        conn.commit()
    finally:
        conn.close()

    # Remove from in-memory state (drop from whatever stack contains it)
    for s in list(ch.main_stacks):
        for j, c in enumerate(list(s.cells)):
            if str(c.id) == cell_id:
                s.cells.pop(j)
                if not s.cells:
                    ch.main_stacks.remove(s)
                break
        else:
            continue
        break
    persist_state()
    return {"ok": True, "channel": ch, "stats": stats}


async def delete_draft(cell_id: str):
    """Internal helper for the unified DELETE /api/cells/{id} endpoint.
    Removes a Draft cell's row, draft_cell_files, edges, and the
    in-memory Cell + Stack. Not exposed as its own HTTP route — the
    unified DELETE picks this code path when state='Draft'."""
    from state import persist_state
    ch = _get_channel()
    channel_name = getattr(ch, "name", "starting") or "starting"
    conn = get_db_connection(channel_name)
    try:
        _require_draft_row(conn, cell_id)
        conn.execute("DELETE FROM draft_cell_files WHERE cell_id=?", (cell_id,))
        conn.execute("DELETE FROM cell_edges WHERE child_cell_id=? OR parent_cell_id=?", (cell_id, cell_id))
        conn.execute("DELETE FROM cells WHERE id=?", (cell_id,))
        conn.commit()
    finally:
        conn.close()

    # Remove from the in-memory state too. If the Draft was the sole cell
    # of its stack, drop the stack entirely.
    for i, s in enumerate(list(ch.main_stacks)):
        for j, c in enumerate(list(s.cells)):
            if str(c.id) == cell_id:
                s.cells.pop(j)
                if not s.cells:
                    ch.main_stacks.pop(i)
                break
    persist_state()
    return {"ok": True, "channel": ch}


@router.post("/api/cells/{cell_id}/promote")
async def promote_draft(cell_id: str, req: PromoteDraftRequest):
    """Promote a Draft to Standard.

    Two paths:
      - generator-bound Draft → flip to Standard + launch the generator
        run (delegates to /api/runs with draft_source_cell_id so the
        run pipeline copies draft_cell_files + settings into
        .colreserved/config/).
      - generator-less Draft (a "blank" Draft from the 0-input picker)
        → just flip to Standard. The Draft's files become the cell's
        files; no execution happens.
    """
    ch = _get_channel()
    conn = get_db_connection(getattr(ch, "name", "starting") or "starting")
    try:
        _require_draft_row(conn, cell_id)
        cell = conn.execute(
            "SELECT id, generator_name, pickoptions_json FROM cells WHERE id=?",
            (cell_id,),
        ).fetchone()
        generator_id = cell["generator_name"]
        # The pickoptions_json column stores settings JSON now — the column
        # name is kept to avoid a DB migration; its contents are the
        # generator's flat {key:value} settings dict.
        settings_dict = json.loads(cell["pickoptions_json"]) if cell["pickoptions_json"] else None

        # Collect parent cell ids in their original input order
        parent_rows = conn.execute(
            "SELECT parent_cell_id, parent_key FROM cell_edges "
            "WHERE child_cell_id=? AND parent_key LIKE 'input_%' "
            "ORDER BY parent_key",
            (cell_id,),
        ).fetchall()
        parent_ids = [r["parent_cell_id"] for r in parent_rows]
    finally:
        conn.close()

    from state import persist_state
    channel_name = getattr(ch, "name", "starting") or "starting"

    # Helper to flip in-memory state.channels + DB to Standard. Called
    # only once we know the promotion will succeed so a failed run
    # doesn't leave the user with a banner-less dangling cell that
    # pretends to be Standard.
    def _flip_to_standard():
        # Blank Draft (no generator) → files authored in the Draft
        # are the Standard cell's content, kept at their original
        # paths (no run, no .colreserved/config/ redirection).
        for s in ch.main_stacks:
            for c in s.cells:
                if str(c.id) == cell_id:
                    c.state = CellState.STANDARD
                    c.draft_generator_id = None
                    if c.name.startswith("Draft: "):
                        c.name = c.name[len("Draft: "):]
                    break
        flip_conn = get_db_connection(channel_name)
        try:
            flip_conn.execute(
                "UPDATE cells SET state='Standard' WHERE id=? AND state='Draft'",
                (cell_id,),
            )
            flip_conn.commit()
        finally:
            flip_conn.close()
        persist_state()

    # Generator-less Draft: no run, just a state flip. Draft files stay
    # in draft_cell_files for the editor to read.
    if not generator_id:
        _flip_to_standard()
        return {"ok": True, "channel": ch, "ran": False}

    # Dispatch through the existing run endpoint so we inherit all its
    # behavior (active_managers registration, SSE events, version chain
    # wiring). The draft cell id becomes the placeholder_cell_id so the
    # run output lands on the same row id — seamless transition.
    # Note: create_run itself also flips cells.state Draft→Standard on
    # its own (see runs.py's handling of draft_source_cell_id). We
    # additionally update the in-memory Cell here on success for the
    # banner to clear instantly.
    from routes.runs import RunRequest, create_run
    run_req = RunRequest(
        prompt=req.prompt,
        generator_name=generator_id,
        input_cell_ids=parent_ids,
        placeholder_cell_id=cell_id,
        settings=settings_dict,
        draft_source_cell_id=cell_id,
    )
    result = await create_run(channel_name, run_req)
    # Reaching here means create_run returned 200 (HTTPException would
    # have propagated). Clear the in-memory Draft state so the banner
    # unmounts.
    for s in ch.main_stacks:
        for c in s.cells:
            if str(c.id) == cell_id:
                c.state = CellState.STANDARD
                c.draft_generator_id = None
                if c.name.startswith("Draft: "):
                    c.name = c.name[len("Draft: "):]
                break
    persist_state()
    return result
