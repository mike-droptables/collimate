"""Local-filesystem browse / collect / write routes for "file sync" mode.

The sync pane in the cell editor browses the user's *local disk* (not the
cell's CAS-backed files) and moves files between the two. These endpoints
back that pane:

  * ``GET  /api/fs/list``    — list a local directory (free browsing).
  * ``POST /api/fs/collect`` — read selected local files/dirs into
    VirtualFile-shaped entries (text inline; binary → CAS blob_hash) so
    the frontend can drop them into a cell ("send to cell ↑").
  * ``POST /api/fs/write``   — write cell files/folders out to a local
    directory ("send to local ↓"), with an overwrite pre-check.

These are native-only: under the pyodide playground there is no local
disk, so every handler raises ``WasmNotSupportedError`` → HTTP 503. The
server binds to loopback only, which is the single-user trust boundary;
within that, browsing is unconfined (the user explicitly navigates), but
``collect``/``write`` refuse symlink escapes out of their ``base`` so a
stray symlink in a selected tree can't exfiltrate or clobber unrelated
files.
"""

import asyncio
import os

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from cas import hash_and_store_bytes
from runtime import IS_WASM, WasmNotSupportedError

router = APIRouter()

# Mirror the frontend's folder-keep marker (fileTree.ts FOLDER_KEEP_FILE):
# an empty cell folder is represented by a hidden ``<folder>/.colkeep``.
COLKEEP = ".colkeep"

# Caps — keep a single listing / collect from pulling unbounded work.
_MAX_ENTRIES = 5000
_MAX_FILE_BYTES = 50 * 1024 * 1024  # matches hash_and_store_bytes
_MAX_COLLECT_FILES = 2000

_EXT_LANGUAGE = {
    "py": "python", "js": "javascript", "jsx": "javascript",
    "ts": "typescript", "tsx": "typescript", "json": "json",
    "html": "html", "css": "css", "scss": "scss", "less": "less",
    "sh": "shell", "bash": "shell", "yaml": "yaml", "yml": "yaml",
    "toml": "toml", "xml": "xml", "sql": "sql", "rs": "rust",
    "go": "go", "java": "java", "c": "c", "cpp": "cpp", "cs": "csharp",
    "rb": "ruby", "php": "php", "swift": "swift", "kt": "kotlin",
    "md": "markdown", "markdown": "markdown", "txt": "plaintext",
}


def _guard_wasm() -> None:
    if IS_WASM:
        raise WasmNotSupportedError("local filesystem access is not available in the playground")


def _language_for(name: str) -> str:
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    return _EXT_LANGUAGE.get(ext, "plaintext")


def _resolve(path: str) -> str:
    """Expand ``~`` / env vars and return an absolute, symlink-resolved path."""
    expanded = os.path.expanduser(os.path.expandvars(path))
    if not os.path.isabs(expanded):
        expanded = os.path.abspath(expanded)
    return os.path.realpath(expanded)


def _under(child_real: str, base_real: str) -> bool:
    """True if ``child_real`` is ``base_real`` or nested beneath it."""
    if child_real == base_real:
        return True
    return child_real.startswith(base_real.rstrip(os.sep) + os.sep)


# ---------------------------------------------------------------------------
# GET /api/fs/list
# ---------------------------------------------------------------------------

@router.get("/api/fs/list")
async def fs_list(path: str = Query(default="~")):
    """List a local directory. Free browsing — the path may be anywhere the
    server process can read; the editable path bar in the UI relies on this.
    """
    _guard_wasm()

    def _do() -> dict:
        resolved = _resolve(path or "~")
        if not os.path.exists(resolved):
            raise HTTPException(404, f"Path not found: {resolved}")
        if not os.path.isdir(resolved):
            raise HTTPException(400, f"Not a directory: {resolved}")
        try:
            names = os.listdir(resolved)
        except PermissionError:
            raise HTTPException(403, f"Permission denied: {resolved}")
        except OSError as exc:
            raise HTTPException(400, f"Cannot list {resolved}: {exc}")

        entries: list[dict] = []
        truncated = False
        for name in sorted(names):
            if len(entries) >= _MAX_ENTRIES:
                truncated = True
                break
            full = os.path.join(resolved, name)
            try:
                is_dir = os.path.isdir(full)
                size = os.path.getsize(full) if not is_dir else None
            except OSError:
                # Broken symlink / vanished mid-list — surface as a file
                # with unknown size rather than failing the whole listing.
                is_dir, size = False, None
            entries.append({"name": name, "kind": "dir" if is_dir else "file", "size": size})

        # Folders first, then files — both already name-sorted.
        entries.sort(key=lambda e: (e["kind"] != "dir", e["name"].lower()))
        parent = os.path.dirname(resolved)
        return {
            "path": resolved,
            "parent": None if parent == resolved else parent,
            "entries": entries,
            "truncated": truncated,
        }

    return await asyncio.to_thread(_do)


# ---------------------------------------------------------------------------
# POST /api/fs/collect
# ---------------------------------------------------------------------------

class CollectRequest(BaseModel):
    base: str
    paths: list[str]


@router.post("/api/fs/collect")
async def fs_collect(req: CollectRequest):
    """Read the selected local files/dirs (``paths`` relative to ``base``)
    into VirtualFile-shaped entries. Text files inline their content; binary
    files are stored in CAS and referenced by ``blob_hash``. Directory
    selections recurse; empty leaf dirs synthesize a ``.colkeep`` marker so
    the folder survives in the cell.
    """
    _guard_wasm()

    def _do() -> dict:
        base_real = _resolve(req.base)
        if not os.path.isdir(base_real):
            raise HTTPException(400, f"Base is not a directory: {base_real}")

        files: list[dict] = []
        skipped: list[dict] = []

        def add_file(abs_path: str, rel_name: str) -> None:
            if len(files) >= _MAX_COLLECT_FILES:
                raise HTTPException(413, f"Too many files (cap {_MAX_COLLECT_FILES})")
            if os.path.basename(rel_name) == COLKEEP:
                return  # internal marker — don't ingest as a real file
            real = os.path.realpath(abs_path)
            if not _under(real, base_real):
                skipped.append({"name": rel_name, "reason": "symlink escapes base"})
                return
            try:
                if os.path.getsize(real) > _MAX_FILE_BYTES:
                    skipped.append({"name": rel_name, "reason": "exceeds size limit"})
                    return
                with open(real, "rb") as fh:
                    raw = fh.read()
            except OSError as exc:
                skipped.append({"name": rel_name, "reason": str(exc)})
                return
            try:
                content = raw.decode("utf-8")
                files.append({
                    "name": rel_name, "content": content,
                    "language": _language_for(rel_name), "blob_hash": None,
                })
            except UnicodeDecodeError:
                blob_hash = hash_and_store_bytes(raw)
                if not blob_hash:
                    skipped.append({"name": rel_name, "reason": "could not store binary"})
                    return
                files.append({
                    "name": rel_name, "content": "", "language": "binary", "blob_hash": blob_hash,
                })

        for sel in req.paths:
            sel = sel.strip().lstrip("/")
            if not sel or ".." in sel.split("/"):
                skipped.append({"name": sel, "reason": "invalid path"})
                continue
            abs_sel = os.path.join(base_real, sel)
            if not os.path.exists(abs_sel):
                skipped.append({"name": sel, "reason": "not found"})
                continue
            if os.path.isfile(abs_sel):
                add_file(abs_sel, sel)
                continue
            # Directory. A symlinked START that resolves outside base would let
            # os.walk traverse (and leak the structure of) an unrelated tree —
            # refuse it. Symlinked SUBdirs are pruned in the walk below.
            if not _under(os.path.realpath(abs_sel), base_real):
                skipped.append({"name": sel, "reason": "symlink escapes base"})
                continue
            for dirpath, dirnames, filenames in os.walk(abs_sel):
                dirnames[:] = [d for d in dirnames if not os.path.islink(os.path.join(dirpath, d))]
                rel_dir = os.path.relpath(dirpath, base_real)
                if not filenames and not dirnames:
                    # Empty leaf dir → keep it via a marker.
                    marker = os.path.join(rel_dir, COLKEEP).replace(os.sep, "/")
                    files.append({"name": marker, "content": "", "language": "plaintext", "blob_hash": None})
                    continue
                for fn in sorted(filenames):
                    rel_name = os.path.join(rel_dir, fn).replace(os.sep, "/")
                    add_file(os.path.join(dirpath, fn), rel_name)

        return {"files": files, "skipped": skipped}

    return await asyncio.to_thread(_do)


# ---------------------------------------------------------------------------
# POST /api/fs/write
# ---------------------------------------------------------------------------

class WriteFile(BaseModel):
    name: str
    content: str | None = None
    blob_hash: str | None = None


class WriteRequest(BaseModel):
    base: str
    files: list[WriteFile]
    overwrite: bool = False


@router.post("/api/fs/write")
async def fs_write(req: WriteRequest):
    """Write cell files into the local directory ``base``. Each file's
    ``name`` is a path relative to ``base``. With ``overwrite=False`` the
    call is a dry pre-check: if any target already exists it returns the
    ``conflicts`` list and writes nothing. With ``overwrite=True`` it
    creates parent dirs and writes every file (text content, or CAS bytes
    resolved from ``blob_hash``). ``.colkeep`` markers create their parent
    directory but no file.
    """
    _guard_wasm()

    def _do() -> dict:
        base_real = _resolve(req.base)
        try:
            os.makedirs(base_real, exist_ok=True)
        except OSError as exc:
            raise HTTPException(400, f"Cannot create base directory: {exc}")

        # Resolve + validate every target first; never write outside base.
        targets: list[tuple[WriteFile, str, bool]] = []  # (file, abs_target, is_marker)
        for f in req.files:
            name = (f.name or "").strip().lstrip("/")
            if not name or ".." in name.split("/"):
                raise HTTPException(400, f"Invalid file name: {f.name!r}")
            abs_target = os.path.normpath(os.path.join(base_real, name))
            if not _under(os.path.realpath(os.path.dirname(abs_target)) if os.path.dirname(abs_target) else base_real, base_real):
                raise HTTPException(400, f"Path escapes base: {f.name!r}")
            targets.append((f, abs_target, os.path.basename(name) == COLKEEP))

        if not req.overwrite:
            conflicts = [
                os.path.relpath(t, base_real).replace(os.sep, "/")
                for f, t, is_marker in targets
                if not is_marker and os.path.exists(t)
            ]
            if conflicts:
                return {"written": 0, "conflicts": conflicts}

        # Refuse to write THROUGH a symlink at the final path component, and
        # never overwrite a directory with a file. O_NOFOLLOW is a no-op on
        # platforms that lack it (e.g. Windows).
        nofollow = getattr(os, "O_NOFOLLOW", 0)

        def _write_bytes(target: str, data: bytes) -> None:
            fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | nofollow, 0o644)
            with os.fdopen(fd, "wb") as dst:
                dst.write(data)

        written = 0
        for f, abs_target, is_marker in targets:
            parent = os.path.dirname(abs_target)
            try:
                if parent:
                    os.makedirs(parent, exist_ok=True)
            except OSError as exc:
                raise HTTPException(400, f"Cannot create directory for {f.name!r}: {exc}")
            # Re-validate AFTER makedirs: a directory component swapped for a
            # symlink between the up-front check and now would resolve outside
            # base — TOCTOU guard.
            real_parent = os.path.realpath(parent) if parent else base_real
            if not _under(real_parent, base_real):
                raise HTTPException(400, f"Path escapes base: {f.name!r}")
            if is_marker:
                continue  # folder materialized above; skip the marker file
            try:
                if f.blob_hash:
                    cas_path = os.path.join(".collimate", "objects", f.blob_hash[:2], f.blob_hash[2:])
                    if not os.path.exists(cas_path):
                        raise HTTPException(404, f"Blob missing for {f.name}: {f.blob_hash}")
                    with open(cas_path, "rb") as src:
                        _write_bytes(abs_target, src.read())
                else:
                    _write_bytes(abs_target, (f.content or "").encode("utf-8"))
            except HTTPException:
                raise
            except OSError as exc:
                raise HTTPException(400, f"Cannot write {f.name!r}: {exc}")
            written += 1

        return {"written": written, "conflicts": []}

    return await asyncio.to_thread(_do)
