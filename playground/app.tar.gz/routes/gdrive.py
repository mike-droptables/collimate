"""Google Drive sync routes — the native-only "gdrive" file system.

Parallels ``routes/fs.py`` (browse / collect / write) and ``routes/backup.py``
(bundle list / file / save / load), but against Google Drive instead of the
local disk + ``.collimatebackup`` folder. The actual Drive + OAuth work lives in
``gdrive.py``; this module wraps it in HTTP, shapes VirtualFile / CAS payloads
(reusing ``routes.fs`` helpers), and reuses the bundle (de)serializers from
``routes.backup`` so the on-disk formats and import behaviour can't drift from
the local Backup surface.

Native-only: every handler calls ``_guard_wasm()`` (the Sync surface is gated
``!isWasm`` in the UI too). Auth failures map to 401, other Drive errors to 502.
"""
from __future__ import annotations

import asyncio
import os

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import Response
from pydantic import BaseModel

import gdrive
from cas import hash_and_store_bytes
from gdrive import GdriveAuthError, GdriveError
from runtime import IS_WASM, WasmNotSupportedError
from routes.fs import COLKEEP, _language_for

router = APIRouter()

_MAX_FILE_BYTES = 50 * 1024 * 1024
_MAX_COLLECT_FILES = 2000
# Backup browsing downloads + parses each bundle to show its kind/cell count;
# cap how many we parse per listing so a folder full of bundles stays responsive.
_MAX_PARSE = 100
_BUNDLE_EXTS = (".colgen", ".colrend", ".colchan")


def _guard_wasm() -> None:
    if IS_WASM:
        raise WasmNotSupportedError("Google Drive is not available in the playground")


async def _drive(do):
    """Run a blocking Drive op in a thread, mapping our errors to HTTP. A
    HTTPException raised inside ``do`` (e.g. a missing CAS blob) propagates
    unchanged."""
    try:
        return await asyncio.to_thread(do)
    except GdriveAuthError as e:
        raise HTTPException(401, str(e))
    except GdriveError as e:
        raise HTTPException(502, str(e))


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

class _CredsBody(BaseModel):
    client_id: str
    client_secret: str


@router.get("/api/gdrive/auth/status")
async def gdrive_auth_status():
    _guard_wasm()
    return gdrive.auth_status()


@router.post("/api/gdrive/auth/credentials")
async def gdrive_set_credentials(body: _CredsBody):
    _guard_wasm()
    try:
        gdrive.set_credentials(body.client_id, body.client_secret)
    except GdriveError as e:
        raise HTTPException(400, str(e))
    return gdrive.auth_status()


@router.post("/api/gdrive/auth/login")
async def gdrive_login():
    """Run the installed-app loopback flow (opens a browser). Blocking — bounded
    by the flow's own timeout — so it runs in a thread."""
    _guard_wasm()
    try:
        await asyncio.to_thread(gdrive.start_login)
    except GdriveError as e:
        raise HTTPException(400, str(e))
    return gdrive.auth_status()


@router.post("/api/gdrive/auth/logout")
async def gdrive_logout():
    _guard_wasm()
    gdrive.logout()
    return gdrive.auth_status()


# ---------------------------------------------------------------------------
# Browse (mirrors /api/fs/list)
# ---------------------------------------------------------------------------

@router.get("/api/gdrive/list")
async def gdrive_list(folder_id: str = Query(default=gdrive.ROOT_ID)):
    _guard_wasm()
    return await _drive(lambda: gdrive.list_folder(folder_id or gdrive.ROOT_ID))


# ---------------------------------------------------------------------------
# Collect (Drive → cell; mirrors /api/fs/collect)
# ---------------------------------------------------------------------------

class _CollectBody(BaseModel):
    folder_id: str
    ids: list[str]


@router.post("/api/gdrive/collect")
async def gdrive_collect(body: _CollectBody):
    """Read the selected Drive files/folders into VirtualFile-shaped entries.
    Text files inline; binary files land in the CAS and ride as ``blob_hash``.
    Folder selections recurse; empty folders synthesize a ``.colkeep`` marker."""
    _guard_wasm()

    def _do() -> dict:
        svc = gdrive.service()
        files: list[dict] = []
        skipped: list[dict] = []

        def add_file(file_id: str, rel_name: str) -> None:
            if len(files) >= _MAX_COLLECT_FILES:
                raise HTTPException(413, f"Too many files (cap {_MAX_COLLECT_FILES})")
            if os.path.basename(rel_name) == COLKEEP:
                return
            try:
                raw = gdrive.download_bytes(file_id, svc=svc)
            except GdriveError as e:
                skipped.append({"name": rel_name, "reason": str(e)})
                return
            if len(raw) > _MAX_FILE_BYTES:
                skipped.append({"name": rel_name, "reason": "exceeds size limit"})
                return
            try:
                content = raw.decode("utf-8")
                files.append({"name": rel_name, "content": content,
                              "language": _language_for(rel_name), "blob_hash": None})
            except UnicodeDecodeError:
                blob_hash = hash_and_store_bytes(raw)
                if not blob_hash:
                    skipped.append({"name": rel_name, "reason": "could not store binary"})
                    return
                files.append({"name": rel_name, "content": "",
                              "language": "binary", "blob_hash": blob_hash})

        def walk(folder: str, prefix: str) -> None:
            listing = gdrive.list_folder(folder, svc=svc, with_breadcrumb=False)
            entries = listing["entries"]
            if not entries:
                files.append({"name": prefix + COLKEEP, "content": "",
                              "language": "plaintext", "blob_hash": None})
                return
            for e in entries:
                rel = prefix + e["name"]
                if e["kind"] == "dir":
                    walk(e["id"], rel + "/")
                else:
                    add_file(e["id"], rel)

        for sel in body.ids:
            try:
                meta = gdrive.get_meta(sel, svc=svc)
            except GdriveError as e:
                skipped.append({"name": sel, "reason": str(e)})
                continue
            if meta["kind"] == "dir":
                walk(meta["id"], meta["name"] + "/")
            else:
                add_file(meta["id"], meta["name"])

        return {"files": files, "skipped": skipped}

    return await _drive(_do)


# ---------------------------------------------------------------------------
# Write (cell → Drive; mirrors /api/fs/write)
# ---------------------------------------------------------------------------

class _WriteFile(BaseModel):
    name: str
    content: str | None = None
    blob_hash: str | None = None


class _WriteBody(BaseModel):
    folder_id: str
    files: list[_WriteFile]
    overwrite: bool = False


def _split_name(name: str) -> tuple[list[str], str]:
    """Validate a relative name; return (dir_segments, leaf)."""
    name = (name or "").strip().lstrip("/")
    parts = [p for p in name.split("/") if p]
    if not parts or any(p == ".." for p in parts):
        raise HTTPException(400, f"Invalid file name: {name!r}")
    return parts[:-1], parts[-1]


def _read_cas(blob_hash: str, name: str) -> bytes:
    # Validate the hash is a 64-char hex digest before building a path with it,
    # so a crafted blob_hash can't traverse out of the CAS (mirrors blobs.py).
    if not (len(blob_hash or "") == 64 and all(c in "0123456789abcdef" for c in blob_hash)):
        raise HTTPException(400, f"Invalid blob hash for {name}")
    cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
    if not os.path.exists(cas_path):
        raise HTTPException(404, f"Blob missing for {name}: {blob_hash}")
    with open(cas_path, "rb") as fh:
        return fh.read()


@router.post("/api/gdrive/write")
async def gdrive_write(body: _WriteBody):
    """Upload cell files into the Drive folder ``folder_id``. Each file's
    ``name`` is a path relative to that folder (intermediate Drive folders are
    created as needed). With ``overwrite=False`` it is a dry pre-check returning
    the ``conflicts`` list and writing nothing; with ``overwrite=True`` it writes
    every file, updating any same-named file in place."""
    _guard_wasm()

    parsed = [(_split_name(f.name), f) for f in body.files]

    def _do() -> dict:
        svc = gdrive.service()
        # find-only folder resolver (no creation) for the conflict pre-check.
        find_cache: dict[tuple[str, str], str | None] = {}

        def resolve_find(segments: list[str]) -> str | None:
            parent = body.folder_id
            for seg in segments:
                key = (parent, seg)
                if key not in find_cache:
                    find_cache[key] = gdrive.find_child(parent, seg, folder=True, svc=svc)
                parent = find_cache[key]
                if parent is None:
                    return None
            return parent

        conflicts: list[str] = []
        for (dirs, leaf), f in parsed:
            if leaf == COLKEEP:
                continue
            parent = resolve_find(dirs)
            if parent and gdrive.find_child(parent, leaf, folder=False, svc=svc):
                conflicts.append(f.name.strip().lstrip("/"))
        # Like /api/fs/write: a non-overwrite call returns the conflict report and
        # writes nothing ONLY when there are conflicts; a clean call falls through
        # and writes (the "clean write on the dry pre-check" path the UI relies on).
        if not body.overwrite and conflicts:
            return {"written": 0, "conflicts": conflicts}

        # create-as-needed folder resolver for the actual write.
        make_cache: dict[tuple[str, str], str] = {}

        def resolve_make(segments: list[str]) -> str:
            parent = body.folder_id
            for seg in segments:
                key = (parent, seg)
                if key not in make_cache:
                    make_cache[key] = gdrive.ensure_subfolder(parent, seg, svc=svc)
                parent = make_cache[key]
            return parent

        written = 0
        for (dirs, leaf), f in parsed:
            parent = resolve_make(dirs)
            if leaf == COLKEEP:
                continue  # folder materialized above; the marker itself isn't written
            if f.blob_hash:
                data, mime = _read_cas(f.blob_hash, f.name), "application/octet-stream"
            else:
                data, mime = (f.content or "").encode("utf-8"), "text/plain"
            existing = gdrive.find_child(parent, leaf, folder=False, svc=svc)
            gdrive.upload_file(parent, leaf, data, mime, existing_id=existing, svc=svc)
            written += 1
        return {"written": written, "conflicts": []}

    return await _drive(_do)


# ---------------------------------------------------------------------------
# Backup surface — a normal folder browse filtered to bundle filetypes
# ---------------------------------------------------------------------------

@router.get("/api/gdrive/backup/list")
async def gdrive_backup_list(folder_id: str = Query(default=gdrive.ROOT_ID)):
    """Browse a Drive folder, returning navigable subfolders plus the bundle
    files (.colgen/.colrend/.colchan) in it, each parsed into the same shape the
    local Backup browser uses (kind + cell metadata)."""
    _guard_wasm()

    def _do() -> dict:
        import backup
        svc = gdrive.service()
        listing = gdrive.list_folder(folder_id or gdrive.ROOT_ID, svc=svc)
        folders = [e for e in listing["entries"] if e["kind"] == "dir"]
        candidates = [e for e in listing["entries"]
                      if e["kind"] == "file"
                      and os.path.splitext(e["name"])[1].lower() in _BUNDLE_EXTS]
        bundles: list[dict] = []
        for i, e in enumerate(candidates):
            kind = backup.kind_for_extension(e["name"])
            entry = {"file_id": e["id"], "filename": e["name"], "kind": kind,
                     "size": e.get("size"), "is_default": False, "cells": [],
                     "error": None}
            if i < _MAX_PARSE:
                try:
                    raw = gdrive.download_bytes(e["id"], svc=svc)
                    entry["cells"] = backup._read_cells(e["name"], raw)
                except Exception as ex:  # noqa: BLE001 — one bad file mustn't break the list
                    entry["error"] = gdrive._describe(ex) if isinstance(ex, GdriveError) else str(ex)
            else:
                entry["error"] = "not parsed (too many bundles in this folder)"
            bundles.append(entry)
        return {
            "folder_id": listing["folder_id"], "name": listing["name"],
            "parent_id": listing["parent_id"], "path": listing["path"],
            "folders": folders, "bundles": bundles, "truncated": listing["truncated"],
        }

    return await _drive(_do)


@router.get("/api/gdrive/file/{file_id}")
async def gdrive_file(file_id: str):
    """Raw bytes of a Drive file — the backup 'Copy file' action stores these in
    the CAS and drops the file into the open cell."""
    _guard_wasm()
    data = await _drive(lambda: gdrive.download_bytes(file_id))
    return Response(content=data, media_type="application/gzip")


class _GdriveSaveBody(BaseModel):
    folder_id: str
    scope: str            # current_cell | channel | generators | renderers
    filename: str
    cell_id: str | None = None


@router.post("/api/gdrive/backup/save")
async def gdrive_backup_save(body: _GdriveSaveBody):
    """Serialize an app scope to bundle bytes (same serializers as the local
    Backup save) and upload it into the Drive folder ``folder_id`` (overwriting a
    same-named file there)."""
    _guard_wasm()
    from routes.backup import _SCOPE_EXT, _normalize_filename, build_scope_bytes

    if body.scope not in _SCOPE_EXT:
        raise HTTPException(400, f"unknown scope: {body.scope!r}")
    filename = _normalize_filename(body.filename, _SCOPE_EXT[body.scope])
    content, warning = build_scope_bytes(body.scope, body.cell_id)

    def _do() -> dict:
        svc = gdrive.service()
        existing = gdrive.find_child(body.folder_id, filename, folder=False, svc=svc)
        file_id = gdrive.upload_file(body.folder_id, filename, content,
                                     "application/gzip", existing_id=existing, svc=svc)
        return {"filename": filename, "file_id": file_id}

    result = await _drive(_do)
    return {**result, "warning": warning}


class _GdriveLoadBody(BaseModel):
    file_id: str
    filename: str          # needed to pick the importer by extension
    cell_ids: list[str] | None = None


@router.post("/api/gdrive/backup/load")
async def gdrive_backup_load(body: _GdriveLoadBody):
    """Download a bundle from Drive and import its cells into the active channel
    via the shared loader (same behaviour as the local Backup 'Load')."""
    _guard_wasm()
    from routes.backup import load_bundle_bytes

    raw = await _drive(lambda: gdrive.download_bytes(body.file_id))
    # The merge mutates the active channel + persists — run it in the request
    # coroutine (not a thread), like backup_load.
    loaded, ch = load_bundle_bytes(raw, body.filename, body.cell_ids)
    return {"loaded_cells": loaded, "channel": ch}
