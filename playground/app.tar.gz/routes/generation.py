import logging
import os
import json
import yaml
from datetime import datetime
from uuid import UUID
from fastapi import APIRouter, HTTPException
from models import Cell, Stack, VirtualFile
from state import state, get_active_channel, current_dir, persist_state

_logger = logging.getLogger("generation")

# Generators must declare which of the five fixed categories they belong
# to. These drive the picker's top-level grouping (chat, iterate, widen,
# narrow, tools) and the icons rendered in the palette / modal. Manifests
# missing `category` fall back to "tools" with a warning so nothing
# disappears from the UI, but the author should fix the manifest.
_ALLOWED_CATEGORIES = {"chat", "iterate", "widen", "narrow", "tools"}

router = APIRouter()

_API_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _scan_keys_used_for_entrypoint(source_cell, prefix: str, manifest: dict) -> list[str]:
    """Static-scan a generator's entrypoint .py for ``gen.get_key("…")``
    calls so the catalog can show authors which keys their generator
    will ask for.

    Falls back to scanning every .py file under the generator's prefix
    when ``manifest.entrypoint`` is missing or doesn't resolve — better
    to overcount than miss the keys entirely.
    """
    import key_scan
    entry_rel = manifest.get("entrypoint") or ""
    out: set[str] = set()
    if entry_rel:
        candidate = prefix + entry_rel
        for f in source_cell.files:
            if f.name == candidate and f.name.endswith(".py"):
                out.update(key_scan.scan_keys_used_in_source(f.content or ""))
                return sorted(out)
    # Fallback: walk every .py under the generator's prefix.
    for f in source_cell.files:
        if f.name.startswith(prefix) and f.name.endswith(".py"):
            out.update(key_scan.scan_keys_used_in_source(f.content or ""))
    return sorted(out)


def _get_generator_cells(ch):
    """Return enabled cells from all generator stacks. `stack_type` is
    the sole source of truth for what counts as a generator stack."""
    cells = []
    for s in ch.main_stacks + ch.nav_stacks:
        if s.stack_type == 'generator':
            cells.extend(c for c in s.cells if c.enabled)
    return cells


def _get_renderer_cells(ch):
    """Return enabled cells from all renderer stacks. `stack_type` is
    the sole source of truth for what counts as a renderer stack."""
    cells = []
    for s in ch.main_stacks + ch.nav_stacks:
        if s.stack_type == 'renderer':
            cells.extend(c for c in s.cells if c.enabled)
    return cells


@router.get("/api/generators")
async def list_generators():
    if state.active_channel_id:
        ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
        if ch:
            source_cells = _get_generator_cells(ch)
            generators = []
            for source_cell in source_cells:
                # The cell name is the group name (e.g. "Basic", "Problem Space")
                group_name = source_cell.name or "Generators"
                manifests = [f for f in source_cell.files if f.name.endswith("manifest.gen_yaml")]
                for mf in manifests:
                    try:
                        manifest = yaml.safe_load(mf.content)
                        gen_id = manifest.get("id", mf.name)
                        prefix = mf.name[:-len("manifest.gen_yaml")]

                        def _resolve(rel):
                            if not rel:
                                return None
                            candidate = prefix + rel
                            return candidate if any(f.name == candidate for f in source_cell.files) else None

                        settings_schema_file_path = _resolve(manifest.get("settings_file"))
                        # summary_file is the relative filepath (within a
                        # Draft cell's files) that the Draft renders as
                        # its first "summary" tab. It may not exist in
                        # the generator source — it's a contract about
                        # which file to highlight — so pass it through
                        # verbatim rather than resolving it.
                        summary_file_path = manifest.get("summary_file")

                        # draft_files: relative paths (rooted at the
                        # generator's own dir) that get seeded into
                        # .colreserved/config/files/ on every run, and
                        # become the Draft's initial files when the
                        # cell routes to Draft.
                        draft_files = list(manifest.get("draft_files") or [])

                        # Resolve each draft_files entry to a prefixed
                        # path inside the generator-source cell so the
                        # frontend can fetch contents without knowing
                        # the internal layout.
                        draft_files_entries = []
                        for rel in draft_files:
                            candidate = prefix + rel
                            if any(f.name == candidate for f in source_cell.files):
                                draft_files_entries.append({
                                    "path": rel,
                                    "source_path": candidate,
                                })

                        inputs_spec = (manifest.get("inputs") or {}).get("cells") or {}

                        # Default routing: if a generator has draft_files
                        # but no settings schema, Draft is the natural home
                        # for pre-run editing. Manifest can override to
                        # "run" to keep the direct-run behaviour.
                        implicit_route = "draft" if draft_files_entries and not settings_schema_file_path else "run"
                        default_route = manifest.get("default_route", implicit_route)

                        raw_category = manifest.get("category")
                        if raw_category not in _ALLOWED_CATEGORIES:
                            _logger.warning(
                                "manifest %s missing or invalid 'category' (got %r); defaulting to 'tools'",
                                mf.name, raw_category,
                            )
                            category = "tools"
                        else:
                            category = raw_category

                        _chat_on = bool(manifest.get("chat", False))
                        generators.append({
                            "name": gen_id,
                            "display_name": manifest.get("name", manifest.get("id", "?")),
                            "version": manifest.get("version", "0.0.0"),
                            "summary": manifest.get("summary", ""),
                            # ``execution_mode`` is no longer a manifest
                            # field; derive from ``chat``. Daemon-shaped
                            # runs are always chat-shaped today.
                            "execution_mode": "daemon" if _chat_on else "oneshot",
                            "cell_id": str(source_cell.id),
                            "group": group_name,
                            "category": category,
                            "draft_files": draft_files_entries,
                            "settings_schema_file": settings_schema_file_path,
                            "summary_file": summary_file_path,
                            "default_route": default_route,
                            "summary_artifact": manifest.get("summary_artifact"),
                            # Keys this generator will request via
                            # gen.api_key, derived by static AST scan
                            # of the entrypoint source. Informational
                            # only; the in-cell modal handles actual
                            # prompting at the moment of need.
                            "keys_used": _scan_keys_used_for_entrypoint(
                                source_cell, prefix, manifest,
                            ),
                            "inputs_cells_min": inputs_spec.get("min"),
                            "inputs_cells_max": inputs_spec.get("max"),
                            "live_chat_mode": "locked_history" if _chat_on else "none",
                            # chat:true implies live_files unless the
                            # manifest opts back out — see the matching
                            # default in routes/runs/create.py.
                            "live_files_mode": (
                                manifest.get("live_files_mode")
                                if manifest.get("live_files_mode") is not None
                                else ("live_files" if _chat_on else "none")
                            ),
                            # Short hint shown above the picker's prompt
                            # textarea telling the user what the generator
                            # will do with the text they type (e.g.
                            # "Used as the user's message to Claude"). Null
                            # when the generator doesn't declare one.
                            "prompt_intent": manifest.get("prompt_intent"),
                            # When true, the run log drawer is auto-dismissed
                            # on successful completion. Used by mechanical
                            # generators whose output is the cell appearing.
                            "auto_dismiss_log": bool(manifest.get("auto_dismiss_log", False)),
                        })
                    except Exception:
                        continue

            if generators:
                return generators

            # Fallback: old-style .py file listing from first source cell
            if source_cells:
                files = [f for f in source_cells[0].files if f.name.endswith(".py")]
                return [{"name": f.name[:-3], "filename": f.name, "cell_id": str(source_cells[0].id)} for f in files]

    return []


@router.get("/api/generators/{generator_name}/draft_files")
async def get_generator_draft_files(generator_name: str):
    """Return the initial content of every file declared under a
    generator's ``draft_files``. Used by the frontend to seed a Draft
    cell's ``initial_files`` when the modal's Edit-as-Draft action
    creates one.
    """
    if state.active_channel_id:
        ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
        if ch:
            for source_cell in _get_generator_cells(ch):
                for mf in source_cell.files:
                    if not mf.name.endswith("manifest.gen_yaml"):
                        continue
                    try:
                        manifest = yaml.safe_load(mf.content)
                    except Exception:
                        continue
                    if manifest.get("id") != generator_name:
                        continue
                    prefix = mf.name[:-len("manifest.gen_yaml")]
                    draft_files = list(manifest.get("draft_files") or [])
                    out = []
                    for rel in draft_files:
                        candidate = prefix + rel
                        src = next((f for f in source_cell.files if f.name == candidate), None)
                        if src is not None:
                            out.append({"path": rel, "content": src.content})
                    return {"files": out, "summary_file": manifest.get("summary_file")}
    raise HTTPException(404, f"Generator '{generator_name}' not found")


_ALLOWED_FIELD_TYPES = {"enum", "string", "number", "bool", "file"}
_ALLOWED_FIELD_KEYS = {
    "key", "label", "description", "type", "default", "advanced", "show_when",
    "options", "multiline", "placeholder",
    "min", "max", "step", "widget",
}
_ALLOWED_OPTION_KEYS = {"value", "label", "description"}


def _validate_show_when(show_when, prior_keys, loc):
    """`show_when` is a flat map {field_key: field_value} — the field is
    visible iff every referenced field currently equals that value. To
    keep evaluation acyclic we require every referenced key to belong to
    a field declared *earlier* in the list."""
    if show_when is None:
        return
    if not isinstance(show_when, dict):
        raise HTTPException(400, f"field at {loc} `show_when` must be a mapping")
    for k in show_when.keys():
        if not isinstance(k, str) or not k:
            raise HTTPException(400, f"field at {loc} `show_when` key must be a non-empty string")
        if k not in prior_keys:
            raise HTTPException(
                400,
                f"field at {loc} `show_when` references unknown or later field '{k}'. "
                f"Only earlier-declared field keys are allowed."
            )


def _validate_route_spec(route, field_keys):
    """`route` is either a literal 'run'|'draft' or a list of conditional
    clauses each with optional `when: {key: value}` plus required
    `value: run|draft`. The final clause should have no `when` (fallback);
    we don't enforce that strictly but warn via 400 on empty lists."""
    if route is None:
        return "run"
    if isinstance(route, str):
        if route not in ("run", "draft"):
            raise HTTPException(400, f"route string must be 'run' or 'draft' (got {route!r})")
        return route
    if isinstance(route, list):
        if not route:
            raise HTTPException(400, "route list must have at least one clause")
        for i, clause in enumerate(route):
            if not isinstance(clause, dict):
                raise HTTPException(400, f"route[{i}] must be a mapping")
            when = clause.get("when")
            if when is not None and not isinstance(when, dict):
                raise HTTPException(400, f"route[{i}].when must be a mapping if present")
            if when:
                for k in when.keys():
                    if k not in field_keys:
                        raise HTTPException(
                            400,
                            f"route[{i}].when references unknown field key '{k}'"
                        )
            v = clause.get("value")
            if v not in ("run", "draft"):
                raise HTTPException(
                    400,
                    f"route[{i}].value must be 'run' or 'draft' (got {v!r})"
                )
        return route
    raise HTTPException(400, "route must be a string or a list of clauses")


def _validate_settings_schema(parsed):
    """Validate the new flat settings schema:

      prompt:                 # optional block describing the markdown editor
        enabled: bool
        label: str?
        placeholder: str?
        required: bool?

      fields: [ ... ]         # ordered list of form fields

      route: 'run'|'draft' | [ { when?: {k:v}, value: 'run'|'draft' }, ... ]

    Each field has a `key`, `type`, optional `label`, `default`, `advanced`,
    `show_when`, plus type-specific props. Enum fields carry `options[]`
    where each option can have per-value `required_keys`.
    """
    if parsed is None:
        raise HTTPException(400, "settings schema is empty")
    if not isinstance(parsed, dict):
        raise HTTPException(400, "settings schema must be a mapping at the top level")

    prompt = parsed.get("prompt")
    if prompt is not None:
        if not isinstance(prompt, dict):
            raise HTTPException(400, "`prompt` must be a mapping")
        allowed_prompt = {"enabled", "label", "placeholder", "required"}
        extra = set(prompt.keys()) - allowed_prompt
        if extra:
            raise HTTPException(
                400, f"`prompt` has unsupported keys: {sorted(extra)}"
            )

    fields = parsed.get("fields") or []
    if not isinstance(fields, list):
        raise HTTPException(400, "`fields` must be a list")

    prior_keys: set = set()
    for i, f in enumerate(fields):
        loc = f"fields[{i}]"
        if not isinstance(f, dict):
            raise HTTPException(400, f"{loc} must be a mapping")
        extra = set(f.keys()) - _ALLOWED_FIELD_KEYS
        if extra:
            raise HTTPException(
                400,
                f"{loc} has unsupported keys: {sorted(extra)}. "
                f"Only {sorted(_ALLOWED_FIELD_KEYS)} are allowed."
            )
        key = f.get("key")
        if not isinstance(key, str) or not key:
            raise HTTPException(400, f"{loc} requires a non-empty `key`")
        if key in prior_keys:
            raise HTTPException(400, f"{loc} duplicate key '{key}'")
        ftype = f.get("type")
        if ftype not in _ALLOWED_FIELD_TYPES:
            raise HTTPException(
                400,
                f"{loc} `type` must be one of {sorted(_ALLOWED_FIELD_TYPES)} (got {ftype!r})"
            )
        # show_when can reference prior field keys only (acyclic)
        _validate_show_when(f.get("show_when"), prior_keys, loc)

        if ftype == "enum":
            options = f.get("options")
            if not isinstance(options, list) or not options:
                raise HTTPException(400, f"{loc} enum field requires a non-empty `options` list")
            seen_values = set()
            for j, opt in enumerate(options):
                oloc = f"{loc}.options[{j}]"
                if not isinstance(opt, dict):
                    raise HTTPException(400, f"{oloc} must be a mapping")
                oextra = set(opt.keys()) - _ALLOWED_OPTION_KEYS
                if oextra:
                    raise HTTPException(
                        400,
                        f"{oloc} has unsupported keys: {sorted(oextra)}. "
                        f"Only {sorted(_ALLOWED_OPTION_KEYS)} are allowed."
                    )
                if "value" not in opt:
                    raise HTTPException(400, f"{oloc} requires `value`")
                v = opt["value"]
                # values must be primitive + unique within this field
                if isinstance(v, (dict, list)):
                    raise HTTPException(400, f"{oloc} `value` must be a primitive")
                # Hash for uniqueness; use repr to normalise int/str/bool
                key_repr = repr(v)
                if key_repr in seen_values:
                    raise HTTPException(400, f"{oloc} duplicate value {v!r}")
                seen_values.add(key_repr)
        prior_keys.add(key)

    _validate_route_spec(parsed.get("route"), prior_keys)


@router.get("/api/generators/{generator_name}/settings")
async def get_generator_settings(generator_name: str):
    """Return the parsed settings schema for a generator, if declared."""
    if state.active_channel_id:
        ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
        if ch:
            for source_cell in _get_generator_cells(ch):
                for mf in source_cell.files:
                    if mf.name.endswith("manifest.gen_yaml"):
                        try:
                            manifest = yaml.safe_load(mf.content)
                            if manifest.get("id") != generator_name:
                                continue
                            schema_file = manifest.get("settings_file")
                            if not schema_file:
                                raise HTTPException(404, "No settings_file declared")
                            prefix = mf.name[:-len("manifest.gen_yaml")]
                            candidate = prefix + schema_file
                            sf = next((f for f in source_cell.files if f.name == candidate), None)
                            if not sf:
                                raise HTTPException(404, f"settings file '{candidate}' not found")
                            parsed = yaml.safe_load(sf.content)
                            _validate_settings_schema(parsed)
                            return {"filename": schema_file, "content": sf.content, "parsed": parsed}
                        except HTTPException:
                            raise
                        except Exception:
                            continue
    raise HTTPException(404, f"Generator '{generator_name}' not found or no settings_file.")


@router.get("/api/generators/{generator_name}/manifest")
async def get_generator_manifest(generator_name: str):
    """Return the parsed manifest.gen_yaml for a specific generator."""
    if state.active_channel_id:
        ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
        if ch:
            for source_cell in _get_generator_cells(ch):
                for mf in source_cell.files:
                    if mf.name.endswith("manifest.gen_yaml"):
                        try:
                            manifest = yaml.safe_load(mf.content)
                            if (manifest.get("id") == generator_name
                                    or mf.name == f"{generator_name}/manifest.gen_yaml"
                                    or mf.name == f"generators/{generator_name}/manifest.gen_yaml"):
                                return manifest
                        except Exception:
                            continue

    raise HTTPException(404, f"Generator '{generator_name}' not found or no generator stack active.")


@router.post("/api/windows/{stack_id}/set_type")
async def set_stack_type(stack_id: UUID, stack_type: str = "standard"):
    """Set the stack_type for a stack ('standard', 'generator', or 'renderer')."""
    ch = get_active_channel()
    target_stack = None
    for s in ch.main_stacks + ch.nav_stacks:
        if s.id == stack_id:
            target_stack = s
            break

    if not target_stack:
        raise HTTPException(404, "Stack not found")

    # Ensure uniqueness: clear other stacks of the same type
    if stack_type in ('generator', 'renderer'):
        for s in ch.main_stacks + ch.nav_stacks:
            if s.stack_type == stack_type and s.id != stack_id:
                s.stack_type = 'standard'

    target_stack.stack_type = stack_type
    persist_state()
    return ch


@router.post("/api/windows/{stack_id}/add_generator")
async def add_generator_cell(stack_id: UUID):
    ch = get_active_channel()
    try:
        src_idx = next(i for i, s in enumerate(ch.main_stacks) if s.id == stack_id)
        source_stack = ch.main_stacks[src_idx]
        files = [VirtualFile(name=f.name, language=f.language, content=f.content) for f in source_stack.cells[0].files] if source_stack.cells else []
        gen_name = source_stack.name or (source_stack.cells[0].name if source_stack.cells else "Unknown")
        gen_cell = Cell(name=f"Generate: {gen_name}", summary="Generator Execution Context", files=files)
        new_stack = Stack(name="", cells=[gen_cell])
        ch.main_stacks.insert(src_idx + 1, new_stack)
        ch.main_selection_id = new_stack.id
        persist_state()
        return ch
    except StopIteration:
        raise HTTPException(404, "Stack not found")

