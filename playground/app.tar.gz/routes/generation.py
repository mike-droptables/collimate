import os
import json
import yaml
from datetime import datetime
from uuid import UUID
from fastapi import APIRouter, HTTPException
from models import Cell, Stack, VirtualFile
from state import state, get_active_channel, current_dir, persist_state

router = APIRouter()

_API_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _get_generator_cells(ch):
    """Return enabled cells from all generator stacks. `stack_type` is
    the sole source of truth for what counts as a generator stack."""
    cells = []
    for s in ch.main_stacks + ch.nav_stacks:
        if s.stack_type == 'generator':
            cells.extend(c for c in s.cells if c.enabled)
    return cells


def _get_renderer_cells(ch):
    """Return enabled cells from all renderer stacks. `stack_type` is
    the sole source of truth for what counts as a renderer stack."""
    cells = []
    for s in ch.main_stacks + ch.nav_stacks:
        if s.stack_type == 'renderer':
            cells.extend(c for c in s.cells if c.enabled)
    return cells


@router.get("/api/generators")
async def list_generators():
    if state.active_channel_id:
        ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
        if ch:
            source_cells = _get_generator_cells(ch)
            generators = []
            for source_cell in source_cells:
                # The cell name is the group name (e.g. "Basic", "Problem Space")
                group_name = source_cell.name or "Generators"
                manifests = [f for f in source_cell.files if f.name.endswith("manifest.gen_yaml")]
                for mf in manifests:
                    try:
                        manifest = yaml.safe_load(mf.content)
                        gen_id = manifest.get("id", mf.name)
                        prefix = mf.name[:-len("manifest.gen_yaml")]

                        def _resolve(rel):
                            if not rel:
                                return None
                            candidate = prefix + rel
                            return candidate if any(f.name == candidate for f in source_cell.files) else None

                        pickoptions_file_path = _resolve(manifest.get("pickoptions_file"))
                        # summary_file is the relative filepath (within a
                        # Draft cell's files) that the Draft renders as
                        # its first "summary" tab. It may not exist in
                        # the generator source — it's a contract about
                        # which file to highlight — so pass it through
                        # verbatim rather than resolving it.
                        summary_file_path = manifest.get("summary_file")

                        # draft_files: relative paths (rooted at the
                        # generator's own dir) that get seeded into
                        # .colreserved/config/files/ on every run, and
                        # become the Draft's initial files when the
                        # cell routes to Draft.
                        draft_files = list(manifest.get("draft_files") or [])

                        # Resolve each draft_files entry to a prefixed
                        # path inside the generator-source cell so the
                        # frontend can fetch contents without knowing
                        # the internal layout.
                        draft_files_entries = []
                        for rel in draft_files:
                            candidate = prefix + rel
                            if any(f.name == candidate for f in source_cell.files):
                                draft_files_entries.append({
                                    "path": rel,
                                    "source_path": candidate,
                                })

                        inputs_spec = (manifest.get("inputs") or {}).get("cells") or {}

                        # Default routing: if a generator has draft_files
                        # but no pickoptions, Draft is the natural home
                        # for pre-run editing. Manifest can override to
                        # "run" to keep the direct-run behaviour.
                        implicit_route = "draft" if draft_files_entries and not pickoptions_file_path else "run"
                        default_route = manifest.get("default_route", implicit_route)

                        generators.append({
                            "name": gen_id,
                            "display_name": manifest.get("name", manifest.get("id", "?")),
                            "version": manifest.get("version", "0.0.0"),
                            "summary": manifest.get("summary", ""),
                            "execution_mode": manifest.get("execution_mode", "oneshot"),
                            "cell_id": str(source_cell.id),
                            "group": group_name,
                            "draft_files": draft_files_entries,
                            "pickoptions_file": pickoptions_file_path,
                            "summary_file": summary_file_path,
                            "default_route": default_route,
                            "summary_artifact": manifest.get("summary_artifact"),
                            "keys": manifest.get("keys", []),
                            "inputs_cells_min": inputs_spec.get("min"),
                            "inputs_cells_max": inputs_spec.get("max"),
                            "live_chat_mode": manifest.get("live_chat_mode", "none"),
                            "live_files_mode": manifest.get("live_files_mode", "none"),
                        })
                    except Exception:
                        continue

            if generators:
                return generators

            # Fallback: old-style .py file listing from first source cell
            if source_cells:
                files = [f for f in source_cells[0].files if f.name.endswith(".py")]
                return [{"name": f.name[:-3], "filename": f.name, "cell_id": str(source_cells[0].id)} for f in files]

    return []


@router.get("/api/generators/{generator_name}/settings_file")
async def get_generator_settings_file(generator_name: str):
    """Return the content and filename of the settings file for a generator, if declared."""
    if state.active_channel_id:
        ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
        if ch:
            for source_cell in _get_generator_cells(ch):
                for mf in source_cell.files:
                    if mf.name.endswith("manifest.gen_yaml"):
                        try:
                            manifest = yaml.safe_load(mf.content)
                            if manifest.get("id") == generator_name:
                                settings_file = manifest.get("settings_file")
                                if not settings_file:
                                    raise HTTPException(404, "No settings_file declared for this generator")
                                prefix = mf.name[:-len("manifest.gen_yaml")]
                                candidate = prefix + settings_file
                                sf = next((f for f in source_cell.files if f.name == candidate), None)
                                if not sf:
                                    raise HTTPException(404, f"Settings file '{candidate}' not found in generator source")
                                return {"filename": settings_file, "content": sf.content}
                        except HTTPException:
                            raise
                        except Exception:
                            continue

    raise HTTPException(404, f"Generator '{generator_name}' not found or no settings_file.")


@router.get("/api/generators/{generator_name}/draft_files")
async def get_generator_draft_files(generator_name: str):
    """Return the initial content of every file declared under a
    generator's ``draft_files`` (or legacy ``settings_file``). Used by
    the frontend to seed a Draft cell's ``initial_files`` when the
    picker routes to Draft.
    """
    if state.active_channel_id:
        ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
        if ch:
            for source_cell in _get_generator_cells(ch):
                for mf in source_cell.files:
                    if not mf.name.endswith("manifest.gen_yaml"):
                        continue
                    try:
                        manifest = yaml.safe_load(mf.content)
                    except Exception:
                        continue
                    if manifest.get("id") != generator_name:
                        continue
                    prefix = mf.name[:-len("manifest.gen_yaml")]
                    draft_files = list(manifest.get("draft_files") or [])
                    out = []
                    for rel in draft_files:
                        candidate = prefix + rel
                        src = next((f for f in source_cell.files if f.name == candidate), None)
                        if src is not None:
                            out.append({"path": rel, "content": src.content})
                    return {"files": out, "summary_file": manifest.get("summary_file")}
    raise HTTPException(404, f"Generator '{generator_name}' not found")


def _validate_pickoptions(options, path=()):
    """Strict validator for pickoptions trees. Enforces the contract:
      - No free-form `tags` field (removed from schema).
      - Terminal options (no `children`) must declare `route: run|draft`.
      - Non-terminal options must have at least one child.
    Any violation raises HTTPException(400) with a path-scoped message so
    the error points at the offending option.
    """
    if not isinstance(options, list):
        raise HTTPException(400, f"pickoptions at {'/'.join(path) or 'root'} must be a list")
    allowed = {"name", "description", "value", "route", "children", "required_keys"}
    for i, opt in enumerate(options):
        loc = "/".join(path + (f"[{i}]",))
        if not isinstance(opt, dict):
            raise HTTPException(400, f"pickoption at {loc} must be a mapping")
        extra = set(opt.keys()) - allowed
        if extra:
            raise HTTPException(
                400,
                f"pickoption at {loc} has unsupported keys: {sorted(extra)}. "
                f"Only {sorted(allowed)} are allowed (tags were removed)."
            )
        if "name" not in opt or not isinstance(opt["name"], str) or not opt["name"]:
            raise HTTPException(400, f"pickoption at {loc} requires a non-empty `name`")
        if "value" not in opt:
            raise HTTPException(400, f"pickoption at {loc} requires a `value`")
        rk = opt.get("required_keys")
        if rk is not None:
            if not isinstance(rk, list) or not all(isinstance(k, str) and k for k in rk):
                raise HTTPException(
                    400,
                    f"pickoption at {loc} `required_keys` must be a list of non-empty strings"
                )
        children = opt.get("children")
        is_terminal = not children
        if is_terminal:
            route = opt.get("route")
            if route not in ("run", "draft"):
                raise HTTPException(
                    400,
                    f"terminal pickoption at {loc} ('{opt['name']}') must declare "
                    f"route: run | draft (got {route!r})"
                )
        else:
            if "route" in opt:
                raise HTTPException(
                    400,
                    f"non-terminal pickoption at {loc} must not declare `route` "
                    f"(route lives on terminal options only)"
                )
            _validate_pickoptions(children, path + (f"[{i}].children",))


@router.get("/api/generators/{generator_name}/pickoptions")
async def get_generator_pickoptions(generator_name: str):
    """Return the parsed .pickoptions content for a generator, if declared."""
    if state.active_channel_id:
        ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
        if ch:
            for source_cell in _get_generator_cells(ch):
                for mf in source_cell.files:
                    if mf.name.endswith("manifest.gen_yaml"):
                        try:
                            manifest = yaml.safe_load(mf.content)
                            if manifest.get("id") != generator_name:
                                continue
                            po_file = manifest.get("pickoptions_file")
                            if not po_file:
                                raise HTTPException(404, "No pickoptions_file declared")
                            prefix = mf.name[:-len("manifest.gen_yaml")]
                            candidate = prefix + po_file
                            po = next((f for f in source_cell.files if f.name == candidate), None)
                            if not po:
                                raise HTTPException(404, f"pickoptions file '{candidate}' not found")
                            parsed = yaml.safe_load(po.content)
                            options = parsed.get("options") if isinstance(parsed, dict) else parsed
                            _validate_pickoptions(options or [])
                            return {"filename": po_file, "content": po.content, "parsed": parsed}
                        except HTTPException:
                            raise
                        except Exception:
                            continue
    raise HTTPException(404, f"Generator '{generator_name}' not found or no pickoptions_file.")


@router.get("/api/generators/{generator_name}/manifest")
async def get_generator_manifest(generator_name: str):
    """Return the parsed manifest.gen_yaml for a specific generator."""
    if state.active_channel_id:
        ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
        if ch:
            for source_cell in _get_generator_cells(ch):
                for mf in source_cell.files:
                    if mf.name.endswith("manifest.gen_yaml"):
                        try:
                            manifest = yaml.safe_load(mf.content)
                            if (manifest.get("id") == generator_name
                                    or mf.name == f"{generator_name}/manifest.gen_yaml"
                                    or mf.name == f"generators/{generator_name}/manifest.gen_yaml"):
                                return manifest
                        except Exception:
                            continue

    raise HTTPException(404, f"Generator '{generator_name}' not found or no generator stack active.")


@router.post("/api/windows/{stack_id}/set_type")
async def set_stack_type(stack_id: UUID, stack_type: str = "standard"):
    """Set the stack_type for a stack ('standard', 'generator', or 'renderer')."""
    ch = get_active_channel()
    target_stack = None
    for s in ch.main_stacks + ch.nav_stacks:
        if s.id == stack_id:
            target_stack = s
            break

    if not target_stack:
        raise HTTPException(404, "Stack not found")

    # Ensure uniqueness: clear other stacks of the same type
    if stack_type in ('generator', 'renderer'):
        for s in ch.main_stacks + ch.nav_stacks:
            if s.stack_type == stack_type and s.id != stack_id:
                s.stack_type = 'standard'

    target_stack.stack_type = stack_type
    persist_state()
    return ch


@router.post("/api/windows/{stack_id}/add_generator")
async def add_generator_cell(stack_id: UUID):
    ch = get_active_channel()
    try:
        src_idx = next(i for i, s in enumerate(ch.main_stacks) if s.id == stack_id)
        source_stack = ch.main_stacks[src_idx]
        files = [VirtualFile(name=f.name, language=f.language, content=f.content) for f in source_stack.cells[0].files] if source_stack.cells else []
        gen_name = source_stack.name or (source_stack.cells[0].name if source_stack.cells else "Unknown")
        gen_cell = Cell(name=f"Generate: {gen_name}", summary="Generator Execution Context", files=files)
        new_stack = Stack(name="", cells=[gen_cell])
        ch.main_stacks.insert(src_idx + 1, new_stack)
        ch.main_selection_id = new_stack.id
        persist_state()
        return ch
    except StopIteration:
        raise HTTPException(404, "Stack not found")

