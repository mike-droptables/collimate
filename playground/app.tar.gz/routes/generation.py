import logging
import os
import yaml
from uuid import UUID
from fastapi import APIRouter, HTTPException
from config_tags import resolve_config_tags
from models import Cell, Stack, VirtualFile
from state import state, get_active_channel, persist_state

_logger = logging.getLogger("generation")

# Allowed invocation modes declared by a generator's manifest ``type``
# field. The host validates the user-picked mode against the manifest's
# array before launching a run.
#   - ``modify`` rewrites the single current cell in place.
#   - ``create`` produces fresh cells; its input shape (no input / single
#     cell / stack) is read from ``inputs.cells`` and exposed as input_kind.
_ALLOWED_TYPES = {"modify", "create"}

router = APIRouter()

_API_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _scan_keys_used_for_entrypoint(source_cell, prefix: str, manifest: dict) -> list[str]:
    """Static-scan a generator's entrypoint .py for ``gen.get_key("…")``
    calls so the catalog can show authors which keys their generator
    will ask for.

    Falls back to scanning every .py file under the generator's prefix
    when ``manifest.entrypoint`` is missing or doesn't resolve — better
    to overcount than miss the keys entirely.
    """
    import key_scan
    entry_rel = manifest.get("entrypoint") or ""
    out: set[str] = set()
    if entry_rel:
        candidate = prefix + entry_rel
        for f in source_cell.files:
            if f.name == candidate and f.name.endswith(".py"):
                out.update(key_scan.scan_keys_used_in_source(f.content or ""))
                return sorted(out)
    # Fallback: walk every .py under the generator's prefix.
    for f in source_cell.files:
        if f.name.startswith(prefix) and f.name.endswith(".py"):
            out.update(key_scan.scan_keys_used_in_source(f.content or ""))
    return sorted(out)


def _get_generator_cells(ch):
    """Return all cells from all generator stacks. `stack_type` is the
    sole source of truth for what counts as a generator stack."""
    cells = []
    for s in ch.main_stacks + ch.nav_stacks:
        if s.stack_type == 'generator':
            cells.extend(s.cells)
    return cells


@router.get("/api/generators")
async def list_generators():
    if state.active_channel_id:
        ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
        if ch:
            from channel_config import (
                read_generator_availability,
                generator_ui_enabled,
            )
            from state import channel_db_name
            _availability = read_generator_availability(channel_db_name(ch))
            source_cells = _get_generator_cells(ch)
            generators = []
            seen_ids: set = set()
            for source_cell in source_cells:
                # The cell name is the group name (e.g. "Basic", "Problem Space")
                group_name = source_cell.name or "Generators"
                manifests = [f for f in source_cell.files if f.name.endswith("manifest.gen_yaml")]
                for mf in manifests:
                    try:
                        manifest = yaml.safe_load(mf.content)
                        gen_id = manifest.get("id", mf.name)
                        # Dedup by id (like /api/renderers + the SDK catalog):
                        # the per-cell management cards key availability + play
                        # by id, so two same-id manifests must not both appear.
                        if gen_id in seen_ids:
                            _logger.warning(
                                "duplicate generator id %r (cell %r) — keeping the first",
                                gen_id, source_cell.name,
                            )
                            continue
                        seen_ids.add(gen_id)
                        prefix = mf.name[:-len("manifest.gen_yaml")]

                        def _read_rel(rel):
                            candidate = prefix + rel
                            src = next((f for f in source_cell.files if f.name == candidate), None)
                            return src.content if src is not None else None

                        # draft_files: relative paths (rooted at the
                        # generator's own dir) that get seeded into
                        # .colreserved/config/files/ on every run, and
                        # become the Draft's initial files when the
                        # cell routes to Draft.
                        draft_files = list(manifest.get("draft_files") or [])

                        # Resolve each draft_files entry to a prefixed
                        # path inside the generator-source cell so the
                        # frontend can fetch contents without knowing
                        # the internal layout.
                        draft_files_entries = []
                        for rel in draft_files:
                            candidate = prefix + rel
                            if any(f.name == candidate for f in source_cell.files):
                                draft_files_entries.append({
                                    "path": rel,
                                    "source_path": candidate,
                                })

                        inputs_spec = (manifest.get("inputs") or {}).get("cells") or {}
                        _cells_min = inputs_spec.get("min")
                        _cells_max = inputs_spec.get("max")

                        # Derive the create-mode input shape from the
                        # declared cell bounds so the picker can filter by it.
                        # Mirrors the frontend's effectiveBounds contract:
                        #   no_input    → max 0
                        #   single_cell → min 1 and max 1
                        #   stack       → anything else (min may be 0)
                        if _cells_max == 0:
                            input_kind = "no_input"
                        elif _cells_min == 1 and _cells_max == 1:
                            input_kind = "single_cell"
                        else:
                            input_kind = "stack"
                        # ``type`` is a list of 1-2 modes drawn from
                        # _ALLOWED_TYPES. Skip the generator with a
                        # loud warning if it's missing or malformed —
                        # silently defaulting hides bugs in
                        # half-migrated manifests.
                        raw_type = manifest.get("type")
                        if not isinstance(raw_type, list) or not raw_type or len(raw_type) > 2:
                            _logger.error(
                                "manifest %s missing or malformed 'type' "
                                "(got %r) — skipping. Declare a list of "
                                "1-2 entries from %s.",
                                mf.name, raw_type, sorted(_ALLOWED_TYPES),
                            )
                            continue
                        if any(t not in _ALLOWED_TYPES for t in raw_type):
                            _logger.error(
                                "manifest %s declares unknown type entry "
                                "(got %r) — skipping. Valid entries: %s.",
                                mf.name, raw_type, sorted(_ALLOWED_TYPES),
                            )
                            continue
                        if len(set(raw_type)) != len(raw_type):
                            _logger.error(
                                "manifest %s 'type' has duplicate entries "
                                "(got %r) — skipping.",
                                mf.name, raw_type,
                            )
                            continue
                        gen_type = list(raw_type)

                        _daemon_on = bool(manifest.get("daemon", False))
                        _env_on = bool(manifest.get("environment"))
                        generators.append({
                            "name": gen_id,
                            "display_name": manifest.get("name", manifest.get("id", "?")),
                            "version": manifest.get("version", "0.0.0"),
                            "summary": manifest.get("summary", ""),
                            # ``execution_mode`` is no longer a manifest
                            # field; derive from ``daemon`` (long-lived run).
                            # A chat generator is just a daemon that serves a
                            # ``.chat`` session — no special chat flag.
                            "execution_mode": "daemon" if _daemon_on else "oneshot",
                            "cell_id": str(source_cell.id),
                            # ``available_ui`` is the per-generator on/off switch
                            # (picker visibility): manifest baseline
                            # (``available_ui``, default true) overridden by an
                            # explicit per-channel toggle. So a composition-only
                            # generator ships hidden (``available_ui: false``).
                            # Callability by other generators is NOT a per-
                            # generator flag — it's the source cell's exposure
                            # (see /api/cell_exposure), surfaced as a cell-level
                            # switch in the management view.
                            "available_ui": generator_ui_enabled(
                                _availability, gen_id,
                                default=bool(manifest.get("available_ui", True)),
                            ),
                            # Group = the generator-source cell's name; group
                            # icon = that cell's picked icon (shown left of
                            # every generator from this group in the picker).
                            "group": group_name,
                            "group_icon": source_cell.icon or None,
                            "type": gen_type,
                            # Create-mode input shape, derived from inputs.cells.
                            # input_kind describes create-mode input shape; it's
                            # meaningless for a modify-only generator, so emit null.
                            "input_kind": input_kind if "create" in gen_type else None,
                            # Capability flags for the picker's filter tags.
                            "ephemeral": bool(manifest.get("ephemeral", False)),
                            "daemon": _daemon_on,
                            "environment": _env_on,
                            "draft_files": draft_files_entries,
                            # Whether the run gate demands a non-blank
                            # prompt (manifest ``prompt_required``; only
                            # legal alongside ``prompt_intent``).
                            "prompt_required": bool(manifest.get("prompt_required", False)),
                            # Named default-value sets resolved against
                            # the generator's .set_yaml draft files —
                            # manifest order; malformed tags collapse to
                            # a synthesized pure-defaults entry instead
                            # of hiding the generator.
                            "config_tags": resolve_config_tags(manifest, _read_rel),
                            # Keys this generator will request via
                            # gen.api_key, derived by static AST scan
                            # of the entrypoint source. Informational
                            # only; the in-cell modal handles actual
                            # prompting at the moment of need.
                            "keys_used": _scan_keys_used_for_entrypoint(
                                source_cell, prefix, manifest,
                            ),
                            "inputs_cells_min": inputs_spec.get("min"),
                            "inputs_cells_max": inputs_spec.get("max"),
                            # Generic mid-run file-editing capability; defaults
                            # to "none" (files locked during the run).
                            "live_files_mode": manifest.get("live_files_mode") or "none",
                            # Short hint shown above the picker's prompt
                            # textarea telling the user what the generator
                            # will do with the text they type (e.g.
                            # "Used as the user's message to Claude"). Null
                            # when the generator doesn't declare one.
                            "prompt_intent": manifest.get("prompt_intent"),
                            # When true, the run log drawer is auto-dismissed
                            # on successful completion. Used by mechanical
                            # generators whose output is the cell appearing.
                            "auto_dismiss_log": bool(manifest.get("auto_dismiss_log", False)),
                        })
                    except Exception:
                        continue

            return generators

    return []


@router.get("/api/generators/{generator_name}/draft_files")
async def get_generator_draft_files(generator_name: str):
    """Return the initial content of every file declared under a
    generator's ``draft_files``. Used by the frontend to seed a Draft
    cell's ``initial_files`` when the modal's Edit-as-Draft action
    creates one.
    """
    if state.active_channel_id:
        ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
        if ch:
            for source_cell in _get_generator_cells(ch):
                for mf in source_cell.files:
                    if not mf.name.endswith("manifest.gen_yaml"):
                        continue
                    try:
                        manifest = yaml.safe_load(mf.content)
                    except Exception:
                        continue
                    if manifest.get("id") != generator_name:
                        continue
                    prefix = mf.name[:-len("manifest.gen_yaml")]
                    draft_files = list(manifest.get("draft_files") or [])
                    out = []
                    for rel in draft_files:
                        candidate = prefix + rel
                        src = next((f for f in source_cell.files if f.name == candidate), None)
                        if src is not None:
                            out.append({"path": rel, "content": src.content})
                    return {"files": out}
    raise HTTPException(404, f"Generator '{generator_name}' not found")


@router.get("/api/generators/{generator_name}/manifest")
async def get_generator_manifest(generator_name: str):
    """Return the parsed manifest.gen_yaml for a specific generator."""
    if state.active_channel_id:
        ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
        if ch:
            for source_cell in _get_generator_cells(ch):
                for mf in source_cell.files:
                    if mf.name.endswith("manifest.gen_yaml"):
                        try:
                            manifest = yaml.safe_load(mf.content)
                            if (manifest.get("id") == generator_name
                                    or mf.name == f"{generator_name}/manifest.gen_yaml"
                                    or mf.name == f"generators/{generator_name}/manifest.gen_yaml"):
                                return manifest
                        except Exception:
                            continue

    raise HTTPException(404, f"Generator '{generator_name}' not found or no generator stack active.")


@router.post("/api/windows/{stack_id}/set_type")
async def set_stack_type(stack_id: UUID, stack_type: str = "standard"):
    """Set the stack_type for a stack ('standard', 'generator', or 'renderer')."""
    ch = get_active_channel()
    target_stack = None
    for s in ch.main_stacks + ch.nav_stacks:
        if s.id == stack_id:
            target_stack = s
            break

    if not target_stack:
        raise HTTPException(404, "Stack not found")

    # Ensure uniqueness: clear other stacks of the same type
    if stack_type in ('generator', 'renderer'):
        for s in ch.main_stacks + ch.nav_stacks:
            if s.stack_type == stack_type and s.id != stack_id:
                s.stack_type = 'standard'

    target_stack.stack_type = stack_type
    persist_state()
    return ch


@router.post("/api/windows/{stack_id}/add_generator")
async def add_generator_cell(stack_id: UUID):
    ch = get_active_channel()
    try:
        src_idx = next(i for i, s in enumerate(ch.main_stacks) if s.id == stack_id)
        source_stack = ch.main_stacks[src_idx]
        files = [VirtualFile(name=f.name, language=f.language, content=f.content) for f in source_stack.cells[0].files] if source_stack.cells else []
        gen_name = source_stack.name or (source_stack.cells[0].name if source_stack.cells else "Unknown")
        gen_cell = Cell(name=f"Generate: {gen_name}", summary="Generator Execution Context", files=files)
        new_stack = Stack(name="", cells=[gen_cell])
        ch.main_stacks.insert(src_idx + 1, new_stack)
        ch.main_selection_id = new_stack.id
        persist_state()
        return ch
    except StopIteration:
        raise HTTPException(404, "Stack not found")

