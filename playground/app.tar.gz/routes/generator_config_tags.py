"""PUT/DELETE /api/generators/{name}/config_tags/{tag}.

Persists named default-value sets into the generator's
``manifest.gen_yaml`` inside the per-channel generator-source cell —
the runtime source of truth. The frontend sends FULL effective values;
we sparsify against the base resolution (field defaults ⊕ the file's
``values:`` block) before storing, then splice the ``config_tags``
block back into the manifest text so comments elsewhere survive.
"""

from datetime import datetime
from typing import Any

import yaml
from fastapi import APIRouter, HTTPException, Response
from pydantic import BaseModel, ConfigDict

from config_tags import (
    TAG_NAME_RE,
    is_empty,
    parse_set_yaml,
    splice_top_level_yaml_block,
)
from routes.generation import _get_generator_cells
from state import persist_state, state, state_lock

router = APIRouter()


class ConfigTagPayload(BaseModel):
    """Full effective values from the modal. ``prompt`` is null when the
    tag doesn't seed the prompt box (and MUST be null when the manifest
    has no ``prompt_intent``)."""
    model_config = ConfigDict(extra="forbid")

    prompt: str | None
    values: dict[str, dict[str, Any]]


def _locate_manifest(generator_name: str):
    """Return (source_cell, manifest_vfile, manifest_dict, prefix) for
    the generator, or None. Same walk as the catalog endpoints."""
    if not state.active_channel_id:
        return None
    ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
    if not ch:
        return None
    for source_cell in _get_generator_cells(ch):
        for mf in source_cell.files:
            if not mf.name.endswith("manifest.gen_yaml"):
                continue
            try:
                manifest = yaml.safe_load(mf.content) or {}
            except Exception:
                continue
            if manifest.get("id") == generator_name:
                prefix = mf.name[:-len("manifest.gen_yaml")]
                return source_cell, mf, manifest, prefix
    return None


def _splice_and_persist(source_cell, mf, tags: dict) -> None:
    """Write the new ``config_tags`` mapping into the manifest text and
    persist. Caller holds ``state_lock``. Raises 500 (persisting
    nothing) when the splice safety-reparse fails."""
    try:
        new_text = splice_top_level_yaml_block(mf.content, "config_tags", tags)
    except ValueError as exc:
        raise HTTPException(500, f"config_tags splice failed: {exc}")
    mf.content = new_text
    # Bump updated_at — drives the frontend's generatorSourceFingerprint
    # invalidation so the catalog refetch sees the new tag values.
    source_cell.updated_at = datetime.now()
    persist_state()


@router.put("/api/generators/{generator_name}/config_tags/{tag}", status_code=204)
async def put_config_tag(
    generator_name: str,
    tag: str,
    payload: ConfigTagPayload,
    rename_from: str | None = None,
):
    """Upsert ``tag`` with the payload values. When ``rename_from`` names an
    existing (non-default) tag, this is an atomic rename: ``tag`` takes
    ``rename_from``'s slot (preserving manifest order) and the old key is
    dropped in the same write — no separate DELETE, so there's no window
    where both names exist."""
    if not TAG_NAME_RE.match(tag):
        raise HTTPException(
            400,
            f"Invalid tag name {tag!r} — must match {TAG_NAME_RE.pattern}",
        )
    with state_lock:
        found = _locate_manifest(generator_name)
        if found is None:
            raise HTTPException(404, f"Generator '{generator_name}' not found")
        source_cell, mf, manifest, prefix = found

        if payload.prompt is not None and not manifest.get("prompt_intent"):
            raise HTTPException(
                400,
                "prompt must be null — this generator declares no prompt_intent",
            )

        set_files = {
            rel for rel in (manifest.get("draft_files") or [])
            if isinstance(rel, str) and rel.endswith(".set_yaml")
        }

        # Sparsify the full payload values against each file's base
        # resolution; only deltas are stored on the tag.
        files_entry: dict[str, dict] = {}
        for rel, kv in payload.values.items():
            if rel not in set_files:
                raise HTTPException(
                    400,
                    f"{rel!r} is not a .set_yaml draft file of '{generator_name}'",
                )
            src = next((f for f in source_cell.files if f.name == prefix + rel), None)
            fields, base = parse_set_yaml(src.content if src is not None else "")
            field_types = {f["key"]: f.get("type") for f in fields}
            sparse: dict = {}
            for key, value in kv.items():
                if key not in field_types:
                    raise HTTPException(400, f"Unknown field {key!r} in {rel}")
                ftype = field_types[key]
                base_value = base.get(key)
                if value == base_value:
                    continue
                if is_empty(value, ftype) and is_empty(base_value, ftype):
                    continue
                sparse[key] = value
            if sparse:
                files_entry[rel] = sparse

        entry: dict = {}
        if payload.prompt is not None and payload.prompt.strip():
            entry["prompt"] = payload.prompt
        if files_entry:
            entry["files"] = files_entry

        raw_tags = manifest.get("config_tags")
        tags = dict(raw_tags) if isinstance(raw_tags, dict) else {}
        if "default" not in tags:
            # Keep the lint invariant (default exists, listed first)
            # even when saving onto a manifest that predates tags.
            tags = {"default": {}, **tags}

        if rename_from and rename_from != tag:
            # Atomic rename: swap the old key for the new one in place.
            if rename_from == "default":
                raise HTTPException(400, "The 'default' config tag cannot be renamed")
            if rename_from not in tags:
                raise HTTPException(
                    404, f"Generator '{generator_name}' has no config tag {rename_from!r}",
                )
            if tag in tags:
                raise HTTPException(400, f"A config tag named {tag!r} already exists")
            tags = {
                (tag if k == rename_from else k): (entry if k == rename_from else v)
                for k, v in tags.items()
            }
        else:
            tags[tag] = entry

        _splice_and_persist(source_cell, mf, tags)
    return Response(status_code=204)


@router.delete("/api/generators/{generator_name}/config_tags/{tag}", status_code=204)
async def delete_config_tag(generator_name: str, tag: str):
    if tag == "default":
        raise HTTPException(400, "The 'default' config tag cannot be deleted")
    with state_lock:
        found = _locate_manifest(generator_name)
        if found is None:
            raise HTTPException(404, f"Generator '{generator_name}' not found")
        source_cell, mf, manifest, _prefix = found

        raw_tags = manifest.get("config_tags")
        if not isinstance(raw_tags, dict) or tag not in raw_tags:
            raise HTTPException(
                404, f"Generator '{generator_name}' has no config tag {tag!r}",
            )
        tags = dict(raw_tags)
        tags.pop(tag)

        _splice_and_persist(source_cell, mf, tags)
    return Response(status_code=204)
