"""PUT /api/generators/{name}/display and /api/renderers/{id}/display.

Edits the human-facing ``name`` / ``summary`` fields of a generator or
renderer manifest in place. The management-view cards write back here. We
line-splice each field into the manifest text (via
``splice_top_level_yaml_block``) so comments and unrelated keys survive
byte-for-byte, then bump the source cell's ``updated_at`` to invalidate the
frontend catalog caches.
"""

from datetime import datetime

from fastapi import APIRouter, HTTPException, Response
from pydantic import BaseModel, ConfigDict

from config_tags import splice_top_level_yaml_block
from routes.generator_config_tags import _locate_manifest
from state import persist_state, state, state_lock

router = APIRouter()


class DisplayPayload(BaseModel):
    """At least one of name/summary must be present; null = leave unchanged."""
    model_config = ConfigDict(extra="forbid")
    name: str | None = None
    summary: str | None = None


def _apply_display(mf, payload: DisplayPayload) -> None:
    """Splice the provided name/summary fields into ``mf.content``. Caller
    holds ``state_lock``. Raises 500 (persisting nothing) on splice failure."""
    text = mf.content
    try:
        if payload.name is not None:
            text = splice_top_level_yaml_block(text, "name", payload.name)
        if payload.summary is not None:
            text = splice_top_level_yaml_block(text, "summary", payload.summary)
    except ValueError as exc:
        raise HTTPException(500, f"manifest splice failed: {exc}")
    mf.content = text


@router.put("/api/generators/{generator_name}/display", status_code=204)
async def put_generator_display(generator_name: str, payload: DisplayPayload):
    if payload.name is None and payload.summary is None:
        raise HTTPException(400, "Provide at least one of name/summary")
    with state_lock:
        found = _locate_manifest(generator_name)
        if found is None:
            raise HTTPException(404, f"Generator '{generator_name}' not found")
        source_cell, mf, _manifest, _prefix = found
        _apply_display(mf, payload)
        source_cell.updated_at = datetime.now()
        persist_state()
    return Response(status_code=204)


def _locate_renderer_manifest(renderer_id: str):
    """Return (source_cell, manifest_vfile) for the renderer, or None. Walks
    every renderer cell incl. disabled ones so an off renderer is still
    editable."""
    if not state.active_channel_id:
        return None
    ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
    if not ch:
        return None
    from routes.blobs import _iter_renderer_manifests
    for cell, mf, _manifest, _prefix, rid in _iter_renderer_manifests(
        ch, include_disabled=True,
    ):
        if rid == renderer_id:
            return cell, mf
    return None


@router.put("/api/renderers/{renderer_id}/display", status_code=204)
async def put_renderer_display(renderer_id: str, payload: DisplayPayload):
    if payload.name is None and payload.summary is None:
        raise HTTPException(400, "Provide at least one of name/summary")
    if ".." in renderer_id or "/" in renderer_id or "\\" in renderer_id:
        raise HTTPException(400, "Invalid renderer ID")
    with state_lock:
        found = _locate_renderer_manifest(renderer_id)
        if found is None:
            raise HTTPException(404, f"Renderer '{renderer_id}' not found")
        source_cell, mf = found
        _apply_display(mf, payload)
        source_cell.updated_at = datetime.now()
        persist_state()
    return Response(status_code=204)
