""".colgen / .colrend import / export endpoints.

Archive parsing / building itself lives in the SDK (``collimate.packaging``);
these handlers are thin HTTP wrappers. Extracted from routes/runs.py because
package I/O is orthogonal to run lifecycle — the runs module was carrying
them only for historical reasons."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, UploadFile, File
from fastapi.responses import Response

from collimate.packaging import (
    CellSpec,
    FileSpec,
    PackageError,
    inspect as _pkg_inspect,
    read_archive as _pkg_read,
    write_archive as _pkg_write,
)

router = APIRouter()


@router.post("/api/packages/import/inspect")
async def inspect_package(file: UploadFile = File(...)):
    """Return the cell list inside a .colgen / .colrend archive without applying it."""
    try:
        manifest = _pkg_inspect(await file.read())
    except PackageError as e:
        raise HTTPException(400, str(e))
    return manifest.to_dict(include_content=False)


@router.post("/api/packages/import")
async def import_package(file: UploadFile = File(...)):
    """
    Parse a .colgen / .colrend archive and return its cells (with file
    contents) for the frontend to merge onto the appropriate stack.
    """
    try:
        manifest = _pkg_read(await file.read())
    except PackageError as e:
        raise HTTPException(400, str(e))
    return manifest.to_dict(include_content=True)


@router.get("/api/packages/export")
async def export_package(type: str = "generator"):
    """
    Export every cell from the active channel's generator / renderer stacks
    as a multi-cell .colgen / .colrend tar.gz archive (format v2).
    """
    if type not in ("generator", "renderer"):
        raise HTTPException(400, "type must be 'generator' or 'renderer'")

    from state import state
    ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
    matching_cells = [
        cell
        for s in (ch.main_stacks + ch.nav_stacks if ch else [])
        if s.stack_type == type
        for cell in s.cells
    ]
    if not matching_cells:
        raise HTTPException(404, f"No active {type} cells found to export")

    specs = [
        CellSpec(
            id=str(c.id),
            name=c.name,
            summary=c.summary,
            files=[FileSpec(name=f.name, language=f.language, content=f.content) for f in c.files],
        )
        for c in matching_cells
    ]

    try:
        content = _pkg_write(specs, type=type)
    except PackageError as e:
        raise HTTPException(400, str(e))

    ext = "colgen" if type == "generator" else "colrend"
    plural = "generators" if type == "generator" else "renderers"
    return Response(
        content=content,
        media_type="application/gzip",
        headers={"Content-Disposition": f"attachment; filename={plural}.{ext}"},
    )
