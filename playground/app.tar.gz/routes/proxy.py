"""Reverse proxy routes — forwards HTTP and WebSocket traffic to generator
live-preview ports."""
import asyncio
import httpx
import websockets
from fastapi import APIRouter, Request, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import Response

router = APIRouter()

# Headers that must not be forwarded
_HOP_BY_HOP = {"host", "content-length", "transfer-encoding", "connection",
               "keep-alive", "proxy-authenticate", "proxy-authorization",
               "te", "trailer", "upgrade"}


@router.api_route(
    "/proxy/{channel}/{run_id}/{port}/{path:path}",
    methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"],
)
async def proxy_to_generator(
    channel: str, run_id: str, port: int, path: str, request: Request
):
    """Transparently forward requests to a generator's bound port."""
    target_url = f"http://127.0.0.1:{port}/{path}"
    if request.url.query:
        target_url += f"?{request.url.query}"

    forward_headers = {
        k: v for k, v in request.headers.items()
        if k.lower() not in _HOP_BY_HOP
    }
    # Force identity encoding upstream. httpx only ships gzip/deflate
    # decoders, so if upstream picks brotli or zstd we'd get raw compressed
    # bytes back and have no way to decompress them. Asking for identity
    # sidesteps the whole problem at the cost of not compressing the
    # localhost-to-localhost hop (negligible).
    forward_headers["accept-encoding"] = "identity"

    try:
        # follow_redirects=False so 3xx responses pass through to the browser
        # unchanged. A reverse proxy that follows redirects server-side breaks
        # apps like code-server that use a 302 to push query params (e.g.
        # ?folder=/home/coder/project) into the URL — the browser would never
        # see the redirect, so window.location.search would stay empty and
        # the workbench JS would think no folder was requested.
        async with httpx.AsyncClient(follow_redirects=False, timeout=30.0) as client:
            proxy_resp = await client.request(
                method=request.method,
                url=target_url,
                headers=forward_headers,
                content=await request.body(),
            )
    except httpx.ConnectError:
        raise HTTPException(502, f"Generator on port {port} is not reachable")
    except httpx.TimeoutException:
        raise HTTPException(504, "Gateway timeout proxying to generator")

    # Forward bytes verbatim. Upstream returned identity-encoded content
    # because we forced Accept-Encoding above, so there is no
    # content-encoding to strip. Strip transfer-encoding/content-length
    # because Starlette will set its own from the bytes we return.
    response_headers = {
        k: v for k, v in proxy_resp.headers.items()
        if k.lower() not in {"transfer-encoding", "connection", "content-length", "content-encoding"}
    }

    return Response(
        content=proxy_resp.content,
        status_code=proxy_resp.status_code,
        headers=response_headers,
    )


@router.websocket("/proxy/{channel}/{run_id}/{port}/{path:path}")
async def proxy_ws_to_generator(
    websocket: WebSocket, channel: str, run_id: str, port: int, path: str
):
    """Transparently forward WebSocket traffic to a generator's bound port.

    Required for code-server, Jupyter, and any other generator that uses a
    workbench-to-server WebSocket for live state.
    """
    requested_subprotocols = list(websocket.scope.get("subprotocols") or [])
    chosen = requested_subprotocols[0] if requested_subprotocols else None
    await websocket.accept(subprotocol=chosen)

    target = f"ws://127.0.0.1:{port}/{path}"
    qs = websocket.scope.get("query_string") or b""
    if qs:
        target += "?" + qs.decode("latin-1")

    try:
        async with websockets.connect(
            target,
            subprotocols=requested_subprotocols or None,
            open_timeout=10,
            max_size=None,  # code-server sends large frames; don't cap
            ping_interval=None,  # let the upstream drive keepalives
        ) as upstream:
            async def client_to_upstream():
                try:
                    while True:
                        msg = await websocket.receive()
                        if msg["type"] == "websocket.disconnect":
                            return
                        data_b = msg.get("bytes")
                        data_t = msg.get("text")
                        if data_b is not None:
                            await upstream.send(data_b)
                        elif data_t is not None:
                            await upstream.send(data_t)
                except WebSocketDisconnect:
                    pass

            async def upstream_to_client():
                try:
                    async for msg in upstream:
                        if isinstance(msg, bytes):
                            await websocket.send_bytes(msg)
                        else:
                            await websocket.send_text(msg)
                except Exception:
                    pass

            done, pending = await asyncio.wait(
                {
                    asyncio.create_task(client_to_upstream()),
                    asyncio.create_task(upstream_to_client()),
                },
                return_when=asyncio.FIRST_COMPLETED,
            )
            for task in pending:
                task.cancel()
    except (OSError, websockets.exceptions.WebSocketException):
        pass
    finally:
        try:
            await websocket.close()
        except Exception:
            pass
