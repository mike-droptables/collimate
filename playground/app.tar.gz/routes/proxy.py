"""Reverse proxy routes — forwards HTTP and WebSocket traffic to generator
live-preview ports."""
import asyncio
import httpx
import websockets
from fastapi import APIRouter, Request, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import StreamingResponse

router = APIRouter()

# Headers that must not be forwarded
_HOP_BY_HOP = {"host", "content-length", "transfer-encoding", "connection",
               "keep-alive", "proxy-authenticate", "proxy-authorization",
               "te", "trailer", "upgrade"}


def _run_owns_port(run_id: str, port: int) -> bool:
    """Whether ``run_id`` is a currently-active run that bound ``port``.

    The proxy path carries both ``run_id`` and ``port``, but ports are
    recycled the instant a process exits (``_find_free_port`` always
    rescans from the same base), so forwarding by port alone lets a
    stopped cell's renderer — which reconnects forever to its baked-in
    proxy URL — reach whatever new run reused that port. Gating on the
    run being live AND owning the port severs that: a dead run_id is
    rejected, and a reused port only answers for the run that now holds
    it (its run_id differs, so the stale URL still misses)."""
    # Imported lazily — routes.runs pulls in a chunk of the app and this
    # module is imported early during route registration.
    from routes.runs import active_managers
    manager = active_managers.get(run_id)
    if manager is None:
        return False
    return port in getattr(manager, "bound_ports", set())


@router.api_route(
    "/proxy/{channel}/{run_id}/{port}/{path:path}",
    methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"],
)
async def proxy_to_generator(
    channel: str, run_id: str, port: int, path: str, request: Request
):
    """Transparently forward requests to a generator's bound port."""
    if not _run_owns_port(run_id, port):
        # Run stopped (or never owned this port). 410 rather than 502 so
        # the client can tell "this run is gone" from "upstream hiccup".
        raise HTTPException(410, "This generator run is no longer active")
    target_url = f"http://127.0.0.1:{port}/{path}"
    if request.url.query:
        target_url += f"?{request.url.query}"

    forward_headers = {
        k: v for k, v in request.headers.items()
        if k.lower() not in _HOP_BY_HOP
    }
    # Force identity encoding upstream. httpx only ships gzip/deflate
    # decoders, so if upstream picks brotli or zstd we'd get raw compressed
    # bytes back and have no way to decompress them. Asking for identity
    # sidesteps the whole problem at the cost of not compressing the
    # localhost-to-localhost hop (negligible).
    forward_headers["accept-encoding"] = "identity"

    # Stream the response instead of buffering it. The live webview's Bare v3
    # proxy carries Server-Sent-Events and other long-lived bodies (a claude.ai
    # generation can run well past a minute), which the old buffered read with a
    # 30s cap truncated. read=None lifts the per-read timeout so a slow stream
    # isn't cut off, while a connect timeout still fails fast on a dead port.
    # follow_redirects=False so 3xx responses pass through to the browser
    # unchanged — code-server uses a 302 to push query params (e.g.
    # ?folder=/home/coder/project) into the URL, which a server-side redirect
    # would swallow.
    client = httpx.AsyncClient(
        follow_redirects=False,
        timeout=httpx.Timeout(connect=30.0, read=None, write=30.0, pool=30.0),
    )
    try:
        upstream_req = client.build_request(
            method=request.method,
            url=target_url,
            headers=forward_headers,
            content=await request.body(),
        )
        upstream = await client.send(upstream_req, stream=True)
    except httpx.ConnectError:
        await client.aclose()
        raise HTTPException(502, f"Generator on port {port} is not reachable")
    except httpx.TimeoutException:
        await client.aclose()
        raise HTTPException(504, "Gateway timeout proxying to generator")

    # aiter_bytes() decodes any content-encoding, so dropping that header keeps
    # the bytes and the metadata consistent; strip transfer-encoding/
    # content-length too because Starlette frames the streamed body itself.
    response_headers = {
        k: v for k, v in upstream.headers.items()
        if k.lower() not in {"transfer-encoding", "connection", "content-length", "content-encoding"}
    }

    async def _body():
        try:
            async for chunk in upstream.aiter_bytes():
                yield chunk
        finally:
            await upstream.aclose()
            await client.aclose()

    return StreamingResponse(
        _body(),
        status_code=upstream.status_code,
        headers=response_headers,
    )


@router.websocket("/proxy/{channel}/{run_id}/{port}/{path:path}")
async def proxy_ws_to_generator(
    websocket: WebSocket, channel: str, run_id: str, port: int, path: str
):
    """Transparently forward WebSocket traffic to a generator's bound port.

    Required for code-server, Jupyter, and any other generator that uses a
    workbench-to-server WebSocket for live state.
    """
    if not _run_owns_port(run_id, port):
        # Stale connection to a stopped run (or a port it no longer owns).
        # Close before the handshake so the renderer's reconnect loop sees
        # a hard failure and stops painting a live stream from a dead cell.
        await websocket.close(code=4410)
        return
    requested_subprotocols = list(websocket.scope.get("subprotocols") or [])
    chosen = requested_subprotocols[0] if requested_subprotocols else None
    await websocket.accept(subprotocol=chosen)

    target = f"ws://127.0.0.1:{port}/{path}"
    qs = websocket.scope.get("query_string") or b""
    if qs:
        target += "?" + qs.decode("latin-1")

    try:
        async with websockets.connect(
            target,
            subprotocols=requested_subprotocols or None,
            open_timeout=10,
            max_size=None,  # code-server sends large frames; don't cap
            ping_interval=None,  # let the upstream drive keepalives
        ) as upstream:
            async def client_to_upstream():
                try:
                    while True:
                        msg = await websocket.receive()
                        if msg["type"] == "websocket.disconnect":
                            return
                        data_b = msg.get("bytes")
                        data_t = msg.get("text")
                        if data_b is not None:
                            await upstream.send(data_b)
                        elif data_t is not None:
                            await upstream.send(data_t)
                except WebSocketDisconnect:
                    pass

            async def upstream_to_client():
                try:
                    async for msg in upstream:
                        if isinstance(msg, bytes):
                            await websocket.send_bytes(msg)
                        else:
                            await websocket.send_text(msg)
                except Exception:
                    pass

            done, pending = await asyncio.wait(
                {
                    asyncio.create_task(client_to_upstream()),
                    asyncio.create_task(upstream_to_client()),
                },
                return_when=asyncio.FIRST_COMPLETED,
            )
            for task in pending:
                task.cancel()
    except (OSError, websockets.exceptions.WebSocketException):
        pass
    finally:
        try:
            await websocket.close()
        except Exception:
            pass
