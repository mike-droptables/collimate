"""Run lifecycle routes — create, stop, list runs; stream SSE events; inspect cells.

Changes from previous version:
  - Zombie process reaper task cleans up active_managers on process exit
  - Workspace hydration into a separate temp directory (COLLIMATE_WORKSPACE)
  - Generator code copied to its own app directory (CWD)
  - Manifest-based generator discovery (entrypoint from manifest.yaml)
  - .colgen import/export endpoints
"""
import asyncio
import io
import json
import os
import re
import shutil
import signal as sig_module
import tarfile
import tempfile
import uuid

import yaml
from fastapi import APIRouter, HTTPException, UploadFile, File, Request
from fastapi.responses import StreamingResponse, Response
from pydantic import BaseModel

from database import get_db_connection
from cas import hash_and_store_bytes
from process_manager import ProcessManager
from state import current_dir

router = APIRouter()

# Registry of currently-running ProcessManagers, keyed by run_id
active_managers: dict[str, ProcessManager] = {}

# Resolve paths
_API_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------

class RunRequest(BaseModel):
    prompt: str = ""
    generator_name: str = "default"
    input_cell_ids: list[str] = []
    params: dict = {}
    # Target cell id being promoted to Standard. When this id doesn't
    # yet exist in state.channels (e.g. it came directly from a client-
    # only Picking cell), the run endpoint creates the cell itself at
    # `insert_after_stack_id`. That preserves the Picking → Standard id
    # continuity without needing a separate createPlaceholderCell call.
    placeholder_cell_id: str | None = None
    # Where to drop the new placeholder stack if it has to be created.
    # Only consulted when placeholder_cell_id is new.
    insert_after_stack_id: str | None = None
    # Chosen pickoption value path (from generator's pickoptions.yaml).
    pickoptions_path: list | None = None
    # If the run came from a Draft cell (Run button), the Draft cell id
    # whose files + pickoptions should seed .colreserved/config/.
    draft_source_cell_id: str | None = None


class SnapshotRequest(BaseModel):
    mode: str  # "new" | "update_and_stop"
    stack_id: str
    cell_id: str


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _audit_filename(
    channel: str,
    draft_source_cell_id: str | None,
    manifest_draft_files: list[tuple[str, str]],
) -> tuple[str | None, str | None]:
    """Return (filename, content) to persist under
    `.colreserved/initial_settings<ext>` on the final committed cell.

    On the Draft-Run path the Draft's edited content wins — it's the
    real source of truth. On the direct-Run path we fall back to the
    manifest defaults. First entry only; if there are no config files
    declared at all, both fields are None and no audit file is written.
    """
    if draft_source_cell_id and manifest_draft_files:
        target = manifest_draft_files[0][0]
        conn = get_db_connection(channel)
        try:
            row = conn.execute(
                "SELECT filepath, content_text FROM draft_cell_files "
                "WHERE cell_id=? AND filepath=? LIMIT 1",
                (draft_source_cell_id, target),
            ).fetchone()
            if row:
                return row[0], row[1] or ""
            # Fallback: any draft_cell_files row for the cell
            row = conn.execute(
                "SELECT filepath, content_text FROM draft_cell_files "
                "WHERE cell_id=? ORDER BY filepath LIMIT 1",
                (draft_source_cell_id,),
            ).fetchone()
            if row:
                return row[0], row[1] or ""
        finally:
            conn.close()
    if manifest_draft_files:
        return manifest_draft_files[0][0], manifest_draft_files[0][1]
    return None, None


def _get_all_generator_cells():
    """Return all cells from all generator stacks. `stack_type` is the
    sole source of truth for what counts as a generator stack."""
    from state import state
    if not state.active_channel_id:
        return []
    ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
    if not ch:
        return []
    cells = []
    for s in ch.main_stacks + ch.nav_stacks:
        if s.stack_type == 'generator':
            cells.extend(s.cells)
    return cells


def _find_generator_source_cell():
    """Return the first cell from a generator stack, or None."""
    cells = _get_all_generator_cells()
    return cells[0] if cells else None


def _find_generator_dir(generator_name: str) -> str | None:
    """
    Locate a generator by name across all cells in all generator stacks.
    Returns a temp directory with the generator code extracted, or None.
    """
    source_cells = _get_all_generator_cells()
    if not source_cells:
        return None

    for source_cell in source_cells:
        target_prefix = None
        for f in source_cell.files:
            if f.name.endswith("manifest.gen_yaml"):
                try:
                    manifest = yaml.safe_load(f.content)
                    if manifest and manifest.get("id", "") == generator_name:
                        target_prefix = f.name[:-len("manifest.gen_yaml")]
                        break
                except Exception:
                    pass

        tmp = tempfile.mkdtemp(prefix=f"collimate_gen_{generator_name}_")
        has_files = False

        if target_prefix is not None:
            for f in source_cell.files:
                if f.name.startswith(target_prefix):
                    rel = f.name[len(target_prefix):]
                    dest = os.path.join(tmp, rel)
                    os.makedirs(os.path.dirname(dest), exist_ok=True)
                    with open(dest, "w", encoding="utf-8") as fh:
                        fh.write(f.content)
                    has_files = True
        else:
            # Fallback: find files whose path contains the generator name as a
            # directory segment (works at any nesting depth: flat, group, etc.)
            for f in source_cell.files:
                rel = _strip_to_segment(f.name, generator_name)
                if rel is None and f.name == f"{generator_name}.py":
                    rel = f"{generator_name}.py"
                if rel is not None:
                    dest = os.path.join(tmp, rel)
                    os.makedirs(os.path.dirname(dest), exist_ok=True)
                    with open(dest, "w", encoding="utf-8") as fh:
                        fh.write(f.content)
                    has_files = True

        if has_files:
            return tmp

        shutil.rmtree(tmp, ignore_errors=True)

    return None


def _read_manifest(gen_dir: str) -> dict:
    """Read manifest.gen_yaml from a generator directory, returning {} if absent."""
    manifest_path = os.path.join(gen_dir, "manifest.gen_yaml")
    if os.path.isfile(manifest_path):
        with open(manifest_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    return {}


def _strip_to_segment(filepath: str, name: str) -> str | None:
    """
    If `name` appears as a path segment in `filepath`, return everything after it.
    Examples:
      ("generators/basic/echo/main.py", "echo")          -> "main.py"
      ("generators/problem_space/judge/m.py", "judge")   -> "m.py"
      ("echo/main.py", "echo")                           -> "main.py"
      ("nope/main.py", "echo")                           -> None
    """
    parts = filepath.replace("\\", "/").split("/")
    if name in parts:
        idx = parts.index(name)
        return "/".join(parts[idx + 1:]) or None
    return None


def _hydrate_generator_code_from_cell(channel: str, cell_id: str, gen_name: str, dest_dir: str):
    """
    Extract generator files from a cell's CAS snapshot and copy them into dest_dir.
    Files whose path contains `gen_name` as a directory segment are scoped to that
    generator (everything after the segment becomes the rel path). If no file matches,
    every file in the cell is treated as belonging to the generator (legacy behaviour).
    """
    conn = get_db_connection(channel)
    rows = conn.execute(
        "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?",
        (cell_id,),
    ).fetchall()
    conn.close()

    has_segment_match = any(
        _strip_to_segment(r["filepath"], gen_name) is not None for r in rows
    )

    for row in rows:
        filepath = row["filepath"]
        blob_hash = row["blob_hash"]

        if has_segment_match:
            rel_path = _strip_to_segment(filepath, gen_name)
        else:
            rel_path = filepath
                
        if rel_path:
            cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
            if os.path.exists(cas_path):
                dest = os.path.join(dest_dir, rel_path)
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                shutil.copy2(cas_path, dest)


def _is_colreserved(cell_path: str) -> bool:
    """`.colreserved/` is a private namespace — never flows in or out of a cell.

    Exception: `.colreserved/.collimate_messages.json` is allowed through
    because it must be hydrated into the workspace for chat history.
    """
    norm = cell_path.replace("\\", "/").lstrip("/")
    if norm == ".colreserved/.collimate_messages.json":
        return False
    return norm == ".colreserved" or norm.startswith(".colreserved/")


_SLUG_RE = re.compile(r"[^a-z0-9]+")


def _slugify_cell_label(name: str | None, fallback_id: str) -> str:
    """Make a short, filesystem-safe label for an input cell directory."""
    base = (name or "").strip().lower()
    slug = _SLUG_RE.sub("_", base).strip("_")[:32]
    if not slug:
        slug = fallback_id[:8]
    return slug


def _lookup_cell_name(channel: str, cell_id: str) -> str | None:
    """Best-effort: find the human-readable name of a cell from in-memory state."""
    try:
        from state import state
        for ch in state.channels:
            if ch.name and ch.name.lower() != channel.lower():
                continue
            for s in ch.main_stacks + ch.nav_stacks:
                for c in s.cells:
                    if str(c.id) == cell_id:
                        return c.name
    except Exception:
        pass
    return None


def _hydrate_workspace(channel: str, cell_ids: list[str], dest_dir: str):
    """
    Copy the last snapshot of each listed cell from the CAS into dest_dir.

    Single input: files land at the workspace root (legacy behaviour, unchanged).
    Multiple inputs: each cell is namespaced into inputs/<NN>_<slug>/ so files
    from different cells cannot collide. Generators that opt into multi-cell
    semantics (judge, synthesize, brainstorm context, etc.) read from inputs/*.

    `.colreserved/*` is filtered out — that namespace is reserved for the SDK.
    """
    if not cell_ids:
        print(f"[hydrate] no input cells for run; workspace will be empty")
        return

    namespace = len(cell_ids) > 1
    conn = get_db_connection(channel)
    for idx, cell_id in enumerate(cell_ids):
        # Resolve the version tip — for in_place cells the latest files
        # live at the tip, not on the visible cell itself. For cells
        # without versions the tip is the cell itself (no-op).
        tip_id = _find_version_tip(conn, cell_id)
        rows = conn.execute(
            "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?",
            (tip_id,),
        ).fetchall()

        if namespace:
            label = _slugify_cell_label(_lookup_cell_name(channel, cell_id), cell_id)
            cell_prefix = os.path.join("inputs", f"{idx:02d}_{label}")
        else:
            cell_prefix = ""

        copied = 0
        skipped_reserved = 0
        skipped_missing = 0
        for row in rows:
            if _is_colreserved(row["filepath"]):
                skipped_reserved += 1
                continue
            blob_hash = row["blob_hash"]
            cas_path = os.path.join(
                ".collimate", "objects", blob_hash[:2], blob_hash[2:]
            )
            if not os.path.exists(cas_path):
                skipped_missing += 1
                continue
            rel = os.path.join(cell_prefix, row["filepath"]) if cell_prefix else row["filepath"]
            dest = os.path.join(dest_dir, rel)
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(cas_path, dest)
            copied += 1
        print(
            f"[hydrate] cell {cell_id[:8]} -> {cell_prefix or '(root)'}: "
            f"{copied} files copied, "
            f"{skipped_reserved} .colreserved skipped, "
            f"{skipped_missing} missing from CAS, "
            f"{len(rows)} total in cell_files"
        )
    conn.close()


def _find_version_tip(conn, start_cell_id: str) -> str:
    """Walk cell_edges forward via parent_key='previous_version' to the tip."""
    current = start_cell_id
    for _ in range(10_000):
        row = conn.execute(
            "SELECT child_cell_id FROM cell_edges "
            "WHERE parent_cell_id=? AND parent_key='previous_version' LIMIT 1",
            (current,),
        ).fetchone()
        if not row:
            break
        current = row[0]
    return current


def _promote_drafts_to_version(
    conn, cell_id: str, run_id: str,
) -> str | None:
    """Promote pending drafts for a cell into a new cell version.

    Checks cell_drafts for pending edits. If any exist, creates a new
    version at the tip with parent_key='previous_version', merges the
    draft content with existing files, and clears the drafts.

    Returns the new version cell_id, or None if no drafts were pending.
    Used by both _jit_flush_drafts (before generator runs) and the
    checkpoint endpoint (idle/close saves).
    """
    drafts = conn.execute(
        "SELECT filepath, content_text FROM cell_drafts WHERE cell_id=?",
        (cell_id,),
    ).fetchall()
    if not drafts:
        return None

    # Walk to the version tip — files live there, not on the visible cell.
    tip_id = _find_version_tip(conn, cell_id)

    new_cell_id = str(uuid.uuid4())

    row = conn.execute(
        "SELECT COALESCE(MAX(sequence_num), 0) FROM cells WHERE run_id=?",
        (run_id,),
    ).fetchone()
    seq = row[0] + 1

    draft_summary = f"Edited {len(drafts)} file(s)"
    conn.execute(
        "INSERT INTO cells (id, run_id, generator_name, sequence_num, "
        "version_name, version_summary, source_type) "
        "VALUES (?, ?, 'human_edit', ?, 'Human Edit', ?, 'human_edit')",
        (new_cell_id, run_id, seq, draft_summary),
    )

    # Wire into the version list — link from the tip, not the visible cell.
    conn.execute(
        "INSERT OR IGNORE INTO cell_edges "
        "(parent_cell_id, child_cell_id, parent_key) VALUES (?, ?, 'previous_version')",
        (tip_id, new_cell_id),
    )

    # Read existing files from the version tip and overlay drafts.
    existing_files = conn.execute(
        "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?",
        (tip_id,),
    ).fetchall()
    file_hashes: dict[str, str] = {r["filepath"]: r["blob_hash"] for r in existing_files}

    for draft in drafts:
        filepath = draft["filepath"]
        content = draft["content_text"] or ""
        raw = content.encode("utf-8")
        blob_hash = hash_and_store_bytes(raw)
        if blob_hash:
            file_hashes[filepath] = blob_hash

    for filepath, blob_hash in file_hashes.items():
        cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
        size = 0
        if os.path.exists(cas_path):
            try:
                size = os.path.getsize(cas_path)
            except OSError:
                pass
        conn.execute(
            "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
            (blob_hash, size),
        )
        conn.execute(
            "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
            "VALUES (?, ?, ?)",
            (new_cell_id, filepath, blob_hash),
        )

    conn.execute("DELETE FROM cell_drafts WHERE cell_id=?", (cell_id,))

    # Audit trail
    conn.execute(
        "INSERT INTO run_events (run_id, event_type, payload) VALUES (?, 'commit', ?)",
        (
            run_id,
            json.dumps({
                "cell_id": new_cell_id,
                "name": "Human Edit",
                "summary": draft_summary,
                "sequence_num": seq,
                "file_count": len(file_hashes),
            }),
        ),
    )
    return new_cell_id


def _jit_flush_drafts(channel: str, run_id: str, input_cell_ids: list[str]) -> list[str]:
    """
    JIT Draft Flush — promotes pending drafts into cell versions.

    For each input cell with pending drafts, creates a new version at the
    tip (parent_key='previous_version') so the edit appears in the cell
    versions panel alongside generator turns.

    Returns the original visible cell IDs (unchanged). The workspace
    hydration code resolves the version tip to get the latest files.
    """
    if not input_cell_ids:
        return input_cell_ids

    conn = get_db_connection(channel)
    for cell_id in input_cell_ids:
        _promote_drafts_to_version(conn, cell_id, run_id)
    conn.commit()
    conn.close()
    return input_cell_ids


# ---------------------------------------------------------------------------
# Zombie process reaper
# ---------------------------------------------------------------------------

async def _reap_process(run_id: str, manager: ProcessManager):
    """Wait for the process to exit, then clean up active_managers."""
    if hasattr(manager, '_cleanup_task'):
        await manager._cleanup_task
    elif manager.process:
        await manager.process.wait()
    active_managers.pop(run_id, None)


# ---------------------------------------------------------------------------
# Run endpoints
# ---------------------------------------------------------------------------

@router.post("/api/channels/{channel}/runs")
async def create_run(channel: str, req: RunRequest):
    """Spawn a new generator subprocess and begin a run.

    Implements the Phase 4 hard execution gate (2-node sequence):
      1. JIT Write: Flush pending drafts, mint a "Human Edit" DAG node
      2. Run Job: Hydrate workspace from the pristine CAS snapshot, spawn generator
    """
    run_id = str(uuid.uuid4())

    # ID-continuity path: if placeholder_cell_id was provided by a
    # client-only Picking but doesn't exist in state.channels yet,
    # create the cell + its stack here using that id. This replaces
    # the former client-side createPlaceholderCell round-trip with a
    # single run call, so the Picking's UUID flows through unchanged
    # into the eventual Standard cell.
    if req.placeholder_cell_id:
        from state import state, persist_state
        from models import Cell as _Cell, Stack as _Stack
        import uuid as _uuid
        # Channel param in the URL is the slugified DB name; the
        # active channel is the one currently selected. Mutating state
        # always targets the active channel by id.
        ch_obj = next(
            (c for c in state.channels if c.id == state.active_channel_id),
            None,
        )
        if ch_obj is not None:
            exists = any(
                str(c.id) == req.placeholder_cell_id
                for s in (ch_obj.main_stacks + ch_obj.nav_stacks)
                for c in s.cells
            )
            if not exists:
                try:
                    new_id = _uuid.UUID(req.placeholder_cell_id)
                except ValueError:
                    raise HTTPException(400, "placeholder_cell_id must be a valid UUID")
                new_cell = _Cell(id=new_id, name="Generating...", summary="", files=[])
                new_stack = _Stack(name="", cells=[new_cell])
                # Drop right of insert_after_stack_id; append if unknown.
                insert_idx = len(ch_obj.main_stacks)
                if req.insert_after_stack_id:
                    for i, s in enumerate(ch_obj.main_stacks):
                        if str(s.id) == req.insert_after_stack_id:
                            insert_idx = i + 1
                            break
                ch_obj.main_stacks.insert(insert_idx, new_stack)
                ch_obj.main_selection_id = new_stack.id
                persist_state()

    # Locate the generator source
    gen_dir = _find_generator_dir(req.generator_name)
    if not gen_dir:
        raise HTTPException(404, f"Generator '{req.generator_name}' not found")

    manifest = _read_manifest(gen_dir)
    entrypoint = manifest.get("entrypoint", f"{req.generator_name}.py")

    # Enforce manifest input bounds (inputs.cells.min / inputs.cells.max)
    inputs_spec = (manifest.get("inputs") or {}).get("cells") or {}
    n_inputs = len(req.input_cell_ids)
    min_in = inputs_spec.get("min")
    max_in = inputs_spec.get("max")
    if min_in is not None and n_inputs < int(min_in):
        raise HTTPException(
            400,
            f"Generator '{req.generator_name}' requires at least {min_in} input cell(s); got {n_inputs}.",
        )
    if max_in is not None and n_inputs > int(max_in):
        raise HTTPException(
            400,
            f"Generator '{req.generator_name}' accepts at most {max_in} input cell(s); got {n_inputs}.",
        )

    # Read manifest capabilities for the frontend
    live_chat_mode = manifest.get("live_chat_mode", "none")
    live_files_mode = manifest.get("live_files_mode", "none")

    # Record the run in the database early so JIT flush can reference the run_id
    conn = get_db_connection(channel)
    conn.execute(
        "INSERT INTO runs (id, prompt, status) VALUES (?, ?, 'running')",
        (run_id, req.prompt),
    )
    conn.commit()
    conn.close()

    # --- Phase 4: JIT Draft Flush ---
    # Flush any pending drafts into formal "Human Edit" DAG nodes.
    # The returned cell IDs may differ from the originals if drafts existed.
    effective_cell_ids = _jit_flush_drafts(channel, run_id, req.input_cell_ids)

    # Create isolated directories:
    #   app_dir   = copy of the generator code (CWD for the process, read-only intent)
    #   workspace = separate temp dir for hydrated input files (read/write)
    # These live under .collimate/tmp/ instead of the system tempdir so that
    # Docker-based generators can bind-mount them. Snap-confined Docker on
    # Ubuntu can't access /tmp/* but can access any path under the user's
    # home directory, and the collimate CWD is typically there.
    runs_tmp_root = os.path.abspath(os.path.join(".collimate", "tmp"))
    os.makedirs(runs_tmp_root, exist_ok=True)
    app_dir = tempfile.mkdtemp(prefix=f"app_{run_id[:8]}_", dir=runs_tmp_root)
    workspace_dir = tempfile.mkdtemp(prefix=f"ws_{run_id[:8]}_", dir=runs_tmp_root)

    # Copy generator code into the app dir
    for item in os.listdir(gen_dir):
        src = os.path.join(gen_dir, item)
        dst = os.path.join(app_dir, item)
        if os.path.isdir(src):
            shutil.copytree(src, dst)
        else:
            shutil.copy2(src, dst)

    # Hydrate workspace from the (possibly updated) input cells
    _hydrate_workspace(channel, effective_cell_ids, workspace_dir)

    # If promoting a Draft cell, flip its state to Standard now so
    # subsequent operations treat it as a first-class cell. The row id
    # stays the same — this is the seamless Draft→Standard transition.
    if req.draft_source_cell_id:
        conn = get_db_connection(channel)
        try:
            conn.execute(
                "UPDATE cells SET state='Standard' WHERE id=? AND state='Draft'",
                (req.draft_source_cell_id,),
            )
            conn.commit()
        finally:
            conn.close()
        # Mirror the DB flip into state.channels so the next SSE
        # state_update (or /api/state fetch) reflects the promoted
        # cell immediately — otherwise the client briefly sees the
        # cell as still Draft and routes message-edits through the
        # draft-files endpoint (which 409s because DB is Standard).
        from state import state as _state
        ch_obj = next((c for c in _state.channels if c.id == _state.active_channel_id), None)
        if ch_obj is not None:
            for s in ch_obj.main_stacks:
                for c in s.cells:
                    if str(c.id) == req.draft_source_cell_id:
                        from models import CellState as _CellState
                        c.state = _CellState.STANDARD
                        c.draft_generator_id = None
                        # Clear draft-authored visible files and the
                        # draft-picked summary_artifact NOW — before
                        # manager.start() triggers the generator's
                        # initial update_cell, which walks the
                        # in-memory cell files. Draft files are
                        # re-routed to .colreserved/config/files/ in
                        # the workspace and persisted privately at
                        # run end; they must not leak onto the
                        # Standard cell at their original visible
                        # paths.
                        c.files = []
                        c.summary_artifact = None
                        if c.name.startswith("Draft: "):
                            c.name = c.name[len("Draft: "):]
                        # Bump updated_at so the frontend's
                        # applyServerState (which gates on timestamp
                        # newness) accepts this state_update — without
                        # the bump, the client's cached Draft cell
                        # (with files + summary_artifact still set)
                        # is never replaced, so the Settings tab and
                        # original-path setting file appear to stick
                        # around even though server-side they're gone.
                        from datetime import datetime as _dt
                        c.updated_at = _dt.now()
                        break

    # Write the Draft cell's pre-run config into .colreserved/config/.
    # This is the unified location for everything the user authored
    # before the run started:
    #   - pickoptions.json: ordered picks from the multi-stage picker
    #   - files/: every config file — whether seeded from the
    #     generator's manifest.draft_files (direct-Run path) or copied
    #     from the Draft cell's edited files (Draft-Run path). Read via
    #     `gen.config.get_file()` / `gen.config.list_files()` /
    #     `gen.config.read_schema_values()`.
    #
    # Walk the generator source for draft_files declarations — those
    # get seeded even when there's no pickoptions and no Draft, so a
    # bare direct-Run still has sensible defaults to read.
    manifest_draft_files: list[tuple[str, str]] = []  # (rel_path, content)
    try:
        found = False
        for src_cell in _get_all_generator_cells():
            if found:
                break
            # A single generator-source cell bundles many manifests (one
            # per generator in the group), so iterate all manifests and
            # filter by id.
            for manifest_file in src_cell.files:
                if not manifest_file.name.endswith("manifest.gen_yaml"):
                    continue
                try:
                    mf = yaml.safe_load(manifest_file.content) or {}
                except Exception:
                    continue
                if mf.get("id") != req.generator_name:
                    continue
                prefix = manifest_file.name[:-len("manifest.gen_yaml")]
                rels = list(mf.get("draft_files") or [])
                for rel in rels:
                    candidate = prefix + rel
                    src = next((f for f in src_cell.files if f.name == candidate), None)
                    if src is not None:
                        manifest_draft_files.append((rel, src.content))
                found = True
                break
    except Exception:
        manifest_draft_files = []

    need_config = (
        req.pickoptions_path is not None
        or req.draft_source_cell_id
        or bool(manifest_draft_files)
    )
    if need_config:
        cfg_dir = os.path.join(workspace_dir, ".colreserved", "config")
        os.makedirs(cfg_dir, exist_ok=True)
        files_dir = os.path.join(cfg_dir, "files")
        os.makedirs(files_dir, exist_ok=True)

        if req.pickoptions_path is not None:
            with open(os.path.join(cfg_dir, "pickoptions.json"), "w", encoding="utf-8") as f:
                json.dump(req.pickoptions_path, f)

        if req.draft_source_cell_id:
            # Draft-Run path: the Draft's edited files are authoritative.
            conn = get_db_connection(channel)
            try:
                rows = conn.execute(
                    "SELECT filepath, content_text FROM draft_cell_files WHERE cell_id=?",
                    (req.draft_source_cell_id,),
                ).fetchall()
            finally:
                conn.close()
            # The Draft's authored chat history is just a draft file
            # at .collimate_messages.json (or .colreserved/...). Route
            # it to the workspace's canonical chat path so the
            # generator's gen.chat.history sees it as the starting
            # point. Drafts have no live state — only static authored
            # messages, same as any other draft file.
            CHAT_PATHS = {".collimate_messages.json", ".colreserved/.collimate_messages.json"}
            for r in rows:
                rel = r["filepath"]
                content = r["content_text"] or ""
                if rel in CHAT_PATHS:
                    msgs_dst = os.path.join(workspace_dir, ".colreserved", ".collimate_messages.json")
                    os.makedirs(os.path.dirname(msgs_dst), exist_ok=True)
                    with open(msgs_dst, "w", encoding="utf-8") as f:
                        f.write(content)
                    continue
                dst = os.path.join(files_dir, rel)
                os.makedirs(os.path.dirname(dst) or files_dir, exist_ok=True)
                with open(dst, "w", encoding="utf-8") as f:
                    f.write(content)
        else:
            # Direct-Run path: seed from the manifest's draft_files
            # declarations (unedited defaults from generator source).
            for rel, content in manifest_draft_files:
                dst = os.path.join(files_dir, rel)
                os.makedirs(os.path.dirname(dst) or files_dir, exist_ok=True)
                with open(dst, "w", encoding="utf-8") as f:
                    f.write(content)

    # Write the prompt into the workspace as a message if provided
    if req.prompt:
        msgs_dir = os.path.join(workspace_dir, ".colreserved")
        os.makedirs(msgs_dir, exist_ok=True)
        msgs_path = os.path.join(msgs_dir, ".collimate_messages.json")
        existing = []
        if os.path.isfile(msgs_path):
            try:
                with open(msgs_path, "r") as f:
                    existing = json.load(f)
            except Exception:
                pass
        existing.append({"role": "user", "content": req.prompt})
        with open(msgs_path, "w") as f:
            json.dump(existing, f, indent=2)

    # Every run auto-creates a placeholder cell (handled by the frontend).
    # The ProcessManager uses it as the "first cell" for update_cell().
    manager = ProcessManager(
        channel=channel,
        run_id=run_id,
        app_dir=app_dir,
        workspace_dir=workspace_dir,
        entrypoint=entrypoint,
        generator_name=req.generator_name,
        params=req.params,
        placeholder_cell_id=req.placeholder_cell_id,
        input_cell_ids=effective_cell_ids,
        initial_settings_content=_audit_filename(
            channel, req.draft_source_cell_id, manifest_draft_files,
        )[1],
        initial_settings_filename=_audit_filename(
            channel, req.draft_source_cell_id, manifest_draft_files,
        )[0],
    )
    active_managers[run_id] = manager

    try:
        await manager.start()
    except Exception as exc:
        shutil.rmtree(app_dir, ignore_errors=True)
        shutil.rmtree(workspace_dir, ignore_errors=True)
        active_managers.pop(run_id, None)
        conn = get_db_connection(channel)
        conn.execute("UPDATE runs SET status='failed' WHERE id=?", (run_id,))
        conn.commit()
        conn.close()
        raise HTTPException(500, f"Failed to start generator process: {exc}")

    # Spawn the zombie reaper task
    asyncio.create_task(_reap_process(run_id, manager))

    # Persist run_id + channel on the in-memory placeholder cell so
    # /api/state reflects "running" before the generator's first
    # update_cell commits. Without this, any fetchState in the gap
    # wipes the client's optimistically-patched run_id and the cell
    # stops looking like it's running (chat daemons can sit idle for
    # minutes waiting for input before their first commit).
    if req.placeholder_cell_id:
        from state import state as _state, persist_state as _persist_state
        ch_obj = next((c for c in _state.channels if c.id == _state.active_channel_id), None)
        if ch_obj is not None:
            for s in ch_obj.main_stacks:
                for c in s.cells:
                    if str(c.id) == req.placeholder_cell_id:
                        c.run_id = run_id
                        c.channel = channel
                        break
            _persist_state()

    return {
        "run_id": run_id,
        "status": "running",
        "live_chat_mode": live_chat_mode,
        "live_files_mode": live_files_mode,
    }


class RendererActionRequest(BaseModel):
    action_id: str


@router.post("/api/channels/{channel}/cells/{cell_id}/actions")
async def emit_renderer_action(channel: str, cell_id: str, body: RendererActionRequest):
    """Enqueue a renderer-emitted action (e.g. top-bar button click) for
    whichever active generator owns this cell as its placeholder.

    The generator consumes via gen.wait_for_action() in its SDK.
    """
    manager = next(
        (m for m in active_managers.values()
         if m.channel == channel and m.placeholder_cell_id == cell_id),
        None,
    )
    if not manager:
        raise HTTPException(404, f"No active run for cell {cell_id}")
    if not body.action_id:
        raise HTTPException(400, "action_id is required")
    manager._pending_renderer_actions.append(body.action_id)
    return {"ok": True}


class SettingsContinueRequest(BaseModel):
    settings_content: str
    settings_filename: str


@router.post("/api/channels/{channel}/runs/{run_id}/settings_continue")
async def settings_continue(channel: str, run_id: str, body: SettingsContinueRequest):
    """Resume a generator that called request_settings_update().

    The frontend POSTs the edited settings content here after the user
    clicks Continue. We write it back to the workspace, parse the values,
    and unblock the generator.
    """
    manager = active_managers.get(run_id)
    if not manager or not isinstance(manager, ProcessManager):
        raise HTTPException(404, f"No active run {run_id}")
    if manager._pending_settings_update is None:
        raise HTTPException(400, "Run is not waiting for a settings update")

    # Write the updated settings back to the workspace
    abs_path = os.path.join(manager.workspace_dir, body.settings_filename)
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    with open(abs_path, "w", encoding="utf-8") as f:
        f.write(body.settings_content)

    # Parse values from the settings content
    values = {}
    try:
        parsed = yaml.safe_load(body.settings_content) or {}
        if isinstance(parsed, dict):
            values = parsed.get("values", {})
            if not isinstance(values, dict):
                values = {}
    except Exception:
        pass

    manager._settings_update_values = values
    # Record this settings snapshot so it lands in .colreserved/ on the
    # final version tip at finalization (alongside logs.txt and the
    # initial settings). Named update_settings_1, update_settings_2, …
    manager.append_settings_update(body.settings_content, body.settings_filename)
    manager._pending_settings_update.set()

    return {"ok": True}


@router.delete("/api/channels/{channel}/runs/{run_id}")
async def stop_run(channel: str, run_id: str, force: bool = False):
    """Send SIGTERM (or SIGKILL if force=true) to the run's process and mark it stopped."""
    manager = active_managers.get(run_id)

    # Wasm runs have no subprocess — cancellation is a cooperative flag
    # the generator polls via ctx.cancelled. Flip it and leave cleanup to
    # _reap_process when the task completes.
    from runtime import IS_WASM
    if manager is not None and IS_WASM:
        manager._cancelled = True
        manager.push_log("[stop] cancellation requested by user")
        return {"status": "stopping", "stop_type": "wasm_cooperative"}

    if not manager or not manager.process or manager.process.returncode is not None:
        # Process already finished — just ensure DB status is updated
        active_managers.pop(run_id, None)
        conn = get_db_connection(channel)
        conn.execute("UPDATE runs SET status='stopped' WHERE id=?", (run_id,))
        conn.commit()
        conn.close()
        return {"status": "stopped", "stop_type": "already_finished"}

    pid = manager.process.pid

    def _kill_pg(sig):
        """Send signal to the process group, falling back to direct kill."""
        if os.name == "nt":
            if sig == sig_module.SIGKILL:
                manager.process.kill()
            else:
                manager.process.terminate()
            return
        try:
            os.killpg(os.getpgid(pid), sig)
        except (ProcessLookupError, PermissionError, OSError):
            try:
                os.kill(pid, sig)
            except (ProcessLookupError, PermissionError, OSError):
                pass

    stop_type = "force_stopped" if force else "gracefully_stopped"

    if force:
        _kill_pg(sig_module.SIGKILL)
        active_managers.pop(run_id, None)
    else:
        _kill_pg(sig_module.SIGTERM)

        # Escalate to SIGKILL if the process doesn't exit within 15 seconds.
        # 15s is generous enough to let generator cleanup finish — e.g.
        # vscode_docker needs to call docker stop on its container, which
        # itself can take a few seconds. The previous 5s budget was too
        # short and routinely killed cleanup mid-flight, leaking containers.
        async def _escalate_kill():
            try:
                await asyncio.wait_for(manager.process.wait(), timeout=15.0)
            except asyncio.TimeoutError:
                _kill_pg(sig_module.SIGKILL)
            except Exception:
                pass
            finally:
                active_managers.pop(run_id, None)

        asyncio.create_task(_escalate_kill())

    conn = get_db_connection(channel)
    conn.execute("UPDATE runs SET status='stopped' WHERE id=?", (run_id,))
    conn.execute(
        "INSERT INTO run_events (run_id, event_type, payload) VALUES (?, 'stop', ?)",
        (run_id, json.dumps({"stop_type": stop_type})),
    )
    conn.commit()
    conn.close()

    return {"status": "stopped", "stop_type": stop_type}


# ---------------------------------------------------------------------------
# Snapshot endpoint — pulls files out of a running container into a cell
# ---------------------------------------------------------------------------

_LANG_BY_EXT = {
    "py": "python", "js": "javascript", "ts": "typescript", "tsx": "typescript",
    "jsx": "javascript", "json": "json", "md": "markdown", "yaml": "yaml",
    "yml": "yaml", "html": "html", "css": "css", "sh": "bash", "rs": "rust",
    "go": "go", "java": "java", "rb": "ruby", "php": "php", "sql": "sql",
    "toml": "toml", "xml": "xml",
}


def _guess_language(filename: str) -> str:
    ext = os.path.splitext(filename)[1].lstrip(".").lower()
    return _LANG_BY_EXT.get(ext, "plaintext")


# Bash that finds the latest Claude transcript .jsonl in the container's
# ~/.claude and prints the most recent assistant text. The script is fed to
# `bash -c` via container.exec_run, so jq must be installed in the image.
_CLAUDE_TRANSCRIPT_BASH = r"""
latest=$(ls -t /home/coder/.claude/projects/*/*.jsonl 2>/dev/null | head -1)
if [ -n "$latest" ]; then
  tac "$latest" | while IFS= read -r line; do
    type=$(echo "$line" | jq -r '.type' 2>/dev/null)
    if [ "$type" = "assistant" ]; then
      text=$(echo "$line" | jq -r '.message.content[]? | select(.type=="text") | .text' 2>/dev/null)
      if [ -n "$text" ]; then
        echo "$text"
        break
      fi
    fi
  done
fi
"""

# Hard cap on individual file content size in a snapshot. Files above this
# bound are skipped — the cell view inlines content into the state JSON, so
# enormous files would balloon persisted state and SSE broadcasts.
_SNAPSHOT_MAX_FILE_BYTES = 1_000_000


def _pull_snapshot_from_container(container_name: str, project_dir: str):
    """Pull text files (filtered by .gitignore via git ls-files when available)
    plus the latest Claude assistant message from a running container.

    Runs synchronously — call from `asyncio.to_thread` to avoid blocking the
    event loop on the docker round trips.

    Returns a tuple `(files, summary_text)`:
      files       — list of dicts shaped like {name, language, content}
      summary_text — the latest Claude assistant message (or "" if none)
    """
    import docker

    client = docker.from_env()
    container = client.containers.get(container_name)

    # Step 1 — figure out which files to keep. If the project is a git
    # checkout, ask git directly so we honour `.gitignore`, the global
    # excludes file, and `.git/info/exclude` all at once. Otherwise we walk
    # everything and rely on the explicit `.git/` filter below.
    allowed_paths: set[str] | None = None
    git_check = container.exec_run(["test", "-d", os.path.join(project_dir, ".git")])
    if git_check.exit_code == 0:
        ls = container.exec_run(
            ["git", "-C", project_dir, "ls-files", "--cached", "--others", "--exclude-standard"]
        )
        if ls.exit_code == 0:
            raw = ls.output.decode("utf-8", errors="replace")
            allowed_paths = {line for line in raw.splitlines() if line.strip()}

    # Step 2 — pull the project tree as a tarball stream and extract in memory.
    bits, _ = container.get_archive(project_dir)
    buf = io.BytesIO()
    for chunk in bits:
        buf.write(chunk)
    buf.seek(0)

    files: list[dict] = []
    with tarfile.open(fileobj=buf, mode="r") as tar:
        for member in tar.getmembers():
            if not member.isfile():
                continue
            # docker get_archive prefixes paths with the basename of the source.
            parts = member.name.split("/", 1)
            if len(parts) < 2:
                continue
            relpath = parts[1]
            # Always drop the .git directory — even when we're not using git
            # ls-files, we don't want VCS internals in a cell snapshot.
            if relpath == ".git" or relpath.startswith(".git/"):
                continue
            if allowed_paths is not None and relpath not in allowed_paths:
                continue
            if member.size > _SNAPSHOT_MAX_FILE_BYTES:
                continue
            extracted = tar.extractfile(member)
            if extracted is None:
                continue
            data = extracted.read()
            try:
                content = data.decode("utf-8")
            except UnicodeDecodeError:
                # Binary files don't fit the inline-content cell model — skip.
                continue
            files.append({
                "name": relpath,
                "language": _guess_language(relpath),
                "content": content,
            })

    # Step 3 — pull the latest Claude assistant text via the transcript bash.
    transcript_text = ""
    try:
        result = container.exec_run(["bash", "-c", _CLAUDE_TRANSCRIPT_BASH])
        if result.exit_code == 0:
            transcript_text = result.output.decode("utf-8", errors="replace").strip()
    except Exception:
        pass  # transcript is best-effort; absence isn't an error

    return files, transcript_text


def _signal_stop_for_run(channel: str, run_id: str):
    """Inline copy of the SIGTERM-with-15s-escalation logic from stop_run.

    Used by snapshot(mode=update_and_stop) to shut down the generator after
    the snapshot has been written. We can't call `stop_run` directly because
    its body assumes it's the route handler, but we need exactly the same
    behaviour: SIGTERM the process group, escalate to SIGKILL after 15s,
    update the runs row, and write a `stop` run_event.
    """
    manager = active_managers.get(run_id)
    if not manager or not manager.process or manager.process.returncode is not None:
        active_managers.pop(run_id, None)
        conn = get_db_connection(channel)
        conn.execute("UPDATE runs SET status='stopped' WHERE id=?", (run_id,))
        conn.commit()
        conn.close()
        return

    pid = manager.process.pid

    def _kill_pg(sig):
        if os.name == "nt":
            manager.process.terminate()
            return
        try:
            os.killpg(os.getpgid(pid), sig)
        except (ProcessLookupError, PermissionError, OSError):
            try:
                os.kill(pid, sig)
            except (ProcessLookupError, PermissionError, OSError):
                pass

    _kill_pg(sig_module.SIGTERM)

    async def _escalate_kill():
        try:
            await asyncio.wait_for(manager.process.wait(), timeout=15.0)
        except asyncio.TimeoutError:
            _kill_pg(sig_module.SIGKILL)
        except Exception:
            pass
        finally:
            active_managers.pop(run_id, None)

    asyncio.create_task(_escalate_kill())

    conn = get_db_connection(channel)
    conn.execute("UPDATE runs SET status='stopped' WHERE id=?", (run_id,))
    conn.execute(
        "INSERT INTO run_events (run_id, event_type, payload) VALUES (?, 'stop', ?)",
        (run_id, json.dumps({"stop_type": "gracefully_stopped"})),
    )
    conn.commit()
    conn.close()


@router.post("/api/channels/{channel}/runs/{run_id}/snapshot")
async def snapshot_run(channel: str, run_id: str, body: SnapshotRequest):
    """Pull the current file tree out of a snapshot-capable run's container,
    write it to a cell in the active channel, and (optionally) stop the run.

    The generator must have called `gen.serve_port(..., snapshot_source=...)`
    so the backend knows which container to read from.
    """
    from state import get_active_channel, persist_state
    from models import Cell, VirtualFile

    if body.mode not in ("new", "update_and_stop"):
        raise HTTPException(400, "mode must be 'new' or 'update_and_stop'")

    manager = active_managers.get(run_id)
    if not manager:
        raise HTTPException(404, "Run not found or already finished")
    if not manager.snapshot_source:
        raise HTTPException(
            400,
            "This run does not declare a snapshot_source — only generators that "
            "pass snapshot_source to gen.serve_port() can be snapshotted.",
        )

    src = manager.snapshot_source
    container_name = src.get("container_name")
    project_dir = src.get("project_dir") or "/home/coder/project"
    if not container_name:
        raise HTTPException(500, "snapshot_source is missing container_name")

    try:
        files, transcript_text = await asyncio.to_thread(
            _pull_snapshot_from_container, container_name, project_dir
        )
    except Exception as exc:
        raise HTTPException(500, f"Snapshot failed: {exc}")

    # If a Claude transcript was found, attach it as summary.md and mark it
    # as the cell's summary_artifact so the SummaryPane shows it.
    summary_artifact: str | None = None
    if transcript_text:
        files.append({
            "name": "summary.md",
            "language": "markdown",
            "content": transcript_text,
        })
        summary_artifact = "summary.md"

    vfiles = [
        VirtualFile(name=f["name"], language=f["language"], content=f["content"])
        for f in files
    ]
    short_summary = (
        transcript_text.strip().splitlines()[0][:200]
        if transcript_text else "Workspace snapshot from VS Code"
    )

    ch = get_active_channel()
    target_stack = next(
        (s for s in ch.main_stacks + ch.nav_stacks if str(s.id) == body.stack_id),
        None,
    )
    if not target_stack:
        raise HTTPException(404, "Stack not found")

    if body.mode == "update_and_stop":
        # Replace the running cell's files entirely. The .website pointer goes
        # away — once we shut down, the iframe is dead anyway, and the user
        # explicitly chose to convert the cell into a pure source snapshot.
        idx = next(
            (i for i, c in enumerate(target_stack.cells) if str(c.id) == body.cell_id),
            None,
        )
        if idx is None:
            raise HTTPException(404, "Cell not found in stack")
        existing = target_stack.cells[idx]
        target_stack.cells[idx] = Cell(
            id=existing.id,
            name="VS Code Snapshot",
            summary=short_summary,
            files=vfiles,
            summary_artifact=summary_artifact,
            run_id=existing.run_id,
            channel=existing.channel,
        )
    else:
        # mode == "new": apply the portal-recursion placement rule. The
        # snapshot button is on a portal cell whose stack is target_stack;
        # since target_stack's top is a portal, the rule will insert a new
        # stack right of it and place the snapshot cell there.
        from cell_placement import reserve_landing_stack
        manager = active_managers.get(run_id)
        current_target = manager.current_target_stack_id if manager else None
        landing = reserve_landing_stack(ch, body.stack_id, current_target)
        new_cell = Cell(
            name="VS Code Snapshot",
            summary=short_summary,
            files=vfiles,
            summary_artifact=summary_artifact,
            run_id=run_id,
            channel=channel,
        )
        landing.cells.insert(0, new_cell)
        if manager is not None:
            manager.current_target_stack_id = str(landing.id)

    persist_state()

    if body.mode == "update_and_stop":
        _signal_stop_for_run(channel, run_id)

    return ch


@router.get("/api/channels/{channel}/runs")
async def list_runs(channel: str, limit: int = 100):
    """List the most recent runs for a channel."""
    conn = get_db_connection(channel)
    rows = conn.execute(
        "SELECT id, prompt, status, created_at FROM runs "
        "ORDER BY created_at DESC LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@router.get("/api/channels/{channel}/runs/active")
async def list_active_runs(channel: str):
    """List currently-running runs on this channel with the metadata the
    frontend needs to reattach (open a replay SSE, wire live mode).

    Declared before the ``/runs/{run_id}`` route so ``active`` isn't captured
    as a run_id path parameter.
    """
    result = []
    for run_id, manager in list(active_managers.items()):
        if getattr(manager, "channel", None) != channel:
            continue
        gen_dir = _find_generator_dir(manager.generator_name)
        manifest = _read_manifest(gen_dir) if gen_dir else {}
        result.append({
            "run_id": run_id,
            "placeholder_cell_id": manager.placeholder_cell_id or "",
            "generator_name": manager.generator_name,
            "live_chat_mode": manifest.get("live_chat_mode", "none"),
            "live_files_mode": manifest.get("live_files_mode", "none"),
        })
    return result


@router.get("/api/channels/{channel}/runs/{run_id}")
async def get_run(channel: str, run_id: str):
    """Return a run record plus its committed DAG cells."""
    conn = get_db_connection(channel)
    run_row = conn.execute("SELECT * FROM runs WHERE id=?", (run_id,)).fetchone()
    if not run_row:
        conn.close()
        raise HTTPException(404, "Run not found")
    cells = conn.execute(
        "SELECT id, generator_name, generator_cell_id, sequence_num, created_at "
        "FROM cells WHERE run_id=? ORDER BY sequence_num",
        (run_id,),
    ).fetchall()
    conn.close()
    return {"run": dict(run_row), "cells": [dict(c) for c in cells]}


@router.get("/api/channels/{channel}/runs/{run_id}/events_since")
async def fetch_run_events_since(channel: str, run_id: str, since_id: int = 0):
    """One-shot backfill of a run's persisted events.

    Replaces the long-lived per-run SSE stream for live delivery: live
    events now flow through the per-channel state SSE as ``run_event``
    messages (see process_manager._broadcast_run_events). This endpoint
    exists only to backfill history on ``attachToRun`` / reload so the
    frontend can reconstruct the log before it starts consuming live
    broadcasts.

    Also returns the run's current status so the caller can render the
    final label if the run has already terminated.
    """
    conn = get_db_connection(channel)
    try:
        rows = conn.execute(
            "SELECT id, event_type, payload, created_at "
            "FROM run_events WHERE run_id=? AND id>? ORDER BY id",
            (run_id, since_id),
        ).fetchall()
        run_row = conn.execute(
            "SELECT status FROM runs WHERE id=?", (run_id,)
        ).fetchone()
    finally:
        conn.close()

    return {
        "events": [
            {
                "id": r["id"],
                "type": r["event_type"],
                "payload": r["payload"],
                "created_at": r["created_at"],
            }
            for r in rows
        ],
        "status": run_row["status"] if run_row else None,
        "is_active": run_id in active_managers,
    }


@router.get("/api/channels/{channel}/runs/{run_id}/events")
async def stream_run_events(channel: str, run_id: str, since_id: int = 0):
    """
    Server-Sent Events stream for a run.  Polls the run_events table every
    100 ms and emits new rows.  Closes when the run reaches a terminal state
    and all events have been delivered.
    """
    async def event_gen():
        last_id = since_id
        conn = get_db_connection(channel)
        try:
            while True:
                rows = conn.execute(
                    "SELECT id, event_type, payload, created_at "
                    "FROM run_events WHERE run_id=? AND id>? ORDER BY id LIMIT 200",
                    (run_id, last_id),
                ).fetchall()
                run_row = conn.execute(
                    "SELECT status FROM runs WHERE id=?", (run_id,)
                ).fetchone()

                for row in rows:
                    last_id = row["id"]
                    yield (
                        "data: "
                        + json.dumps({
                            "id": row["id"],
                            "type": row["event_type"],
                            "payload": row["payload"],
                            "created_at": row["created_at"],
                        })
                        + "\n\n"
                    )

                is_terminal = run_row and run_row["status"] in (
                    "completed", "stopped", "failed"
                )
                is_active = run_id in active_managers

                if is_terminal and not rows and not is_active:
                    yield (
                        "data: "
                        + json.dumps({"type": "stream_end", "status": run_row["status"]})
                        + "\n\n"
                    )
                    break

                # Release any implicit read-transaction so concurrent
                # writers aren't blocked between polling cycles.
                conn.rollback()
                await asyncio.sleep(0.1)
        finally:
            conn.close()

    return StreamingResponse(
        event_gen(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ---------------------------------------------------------------------------
# Draft endpoints (JIT working-tree persistence)
# ---------------------------------------------------------------------------

@router.put("/api/channels/{channel}/cells/{cell_id}/drafts/{filepath:path}")
async def upsert_draft(channel: str, cell_id: str, filepath: str, request: Request):
    """Debounce target — upsert a single file draft."""
    content = (await request.body()).decode("utf-8")
    conn = get_db_connection(channel)
    conn.execute(
        "INSERT INTO cell_drafts (cell_id, filepath, content_text, updated_at) "
        "VALUES (?, ?, ?, CURRENT_TIMESTAMP) "
        "ON CONFLICT(cell_id, filepath) DO UPDATE SET content_text=excluded.content_text, updated_at=CURRENT_TIMESTAMP",
        (cell_id, filepath, content),
    )
    conn.commit()
    conn.close()
    return {"status": "ok"}


@router.get("/api/channels/{channel}/cells/{cell_id}/drafts")
async def list_drafts(channel: str, cell_id: str):
    """List all pending drafts for a cell."""
    conn = get_db_connection(channel)
    rows = conn.execute(
        "SELECT filepath, length(content_text) as size, updated_at FROM cell_drafts WHERE cell_id=?",
        (cell_id,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@router.delete("/api/channels/{channel}/cells/{cell_id}/drafts")
async def clear_drafts(channel: str, cell_id: str):
    """Clear all drafts for a cell (called after JIT flush)."""
    conn = get_db_connection(channel)
    conn.execute("DELETE FROM cell_drafts WHERE cell_id=?", (cell_id,))
    conn.commit()
    conn.close()
    return {"status": "cleared"}


# ---------------------------------------------------------------------------
# Cell / file inspection endpoints
# ---------------------------------------------------------------------------


@router.get("/api/channels/{channel}/cells/{cell_id}/files")
async def list_cell_files(channel: str, cell_id: str):
    """List all files snapshotted in a DAG cell."""
    conn = get_db_connection(channel)
    rows = conn.execute(
        "SELECT cf.filepath, cf.blob_hash, b.size, b.mime_type "
        "FROM cell_files cf JOIN blobs b ON cf.blob_hash = b.hash "
        "WHERE cf.cell_id=?",
        (cell_id,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@router.get("/api/channels/{channel}/cells/{cell_id}/dag")
async def get_cell_dag(channel: str, cell_id: str):
    """Return a cell's parents and children in the DAG."""
    conn = get_db_connection(channel)
    parents = conn.execute(
        "SELECT parent_cell_id, parent_key FROM cell_edges WHERE child_cell_id=?",
        (cell_id,),
    ).fetchall()
    children = conn.execute(
        "SELECT child_cell_id, parent_key FROM cell_edges WHERE parent_cell_id=?",
        (cell_id,),
    ).fetchall()
    conn.close()
    return {
        "parents": [dict(r) for r in parents],
        "children": [dict(r) for r in children],
    }


# ---------------------------------------------------------------------------
# .colgen / .colrend import / export
#
# Archive parsing / building lives in the SDK: `collimate.packaging`. These
# handlers are thin HTTP wrappers around it.
# ---------------------------------------------------------------------------

from collimate.packaging import (
    CellSpec,
    FileSpec,
    PackageError,
    inspect as _pkg_inspect,
    read_archive as _pkg_read,
    write_archive as _pkg_write,
)


@router.post("/api/packages/import/inspect")
async def inspect_package(file: UploadFile = File(...)):
    """Return the cell list inside a .colgen / .colrend archive without applying it."""
    try:
        manifest = _pkg_inspect(await file.read())
    except PackageError as e:
        raise HTTPException(400, str(e))
    return manifest.to_dict(include_content=False)


@router.post("/api/packages/import")
async def import_package(file: UploadFile = File(...)):
    """
    Parse a .colgen / .colrend archive and return its cells (with file
    contents) for the frontend to merge onto the appropriate stack.
    """
    try:
        manifest = _pkg_read(await file.read())
    except PackageError as e:
        raise HTTPException(400, str(e))
    return manifest.to_dict(include_content=True)


@router.get("/api/packages/export")
async def export_package(type: str = "generator"):
    """
    Export every cell from the active channel's generator / renderer stacks
    as a multi-cell .colgen / .colrend tar.gz archive (format v2).
    """
    if type not in ("generator", "renderer"):
        raise HTTPException(400, "type must be 'generator' or 'renderer'")

    from state import state
    ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
    matching_cells = [
        cell
        for s in (ch.main_stacks + ch.nav_stacks if ch else [])
        if s.stack_type == type
        for cell in s.cells
    ]
    if not matching_cells:
        raise HTTPException(404, f"No active {type} cells found to export")

    specs = [
        CellSpec(
            id=str(c.id),
            name=c.name,
            summary=c.summary,
            files=[FileSpec(name=f.name, language=f.language, content=f.content) for f in c.files],
        )
        for c in matching_cells
    ]

    try:
        content = _pkg_write(specs, type=type)
    except PackageError as e:
        raise HTTPException(400, str(e))

    ext = "colgen" if type == "generator" else "colrend"
    plural = "generators" if type == "generator" else "renderers"
    return Response(
        content=content,
        media_type="application/gzip",
        headers={"Content-Disposition": f"attachment; filename={plural}.{ext}"},
    )
