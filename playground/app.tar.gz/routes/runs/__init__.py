"""Run lifecycle routes — create, stop, list runs; stream SSE events; inspect cells.

Composed from topical submodules:

  * create.py      — POST /runs
  * control.py     — stop, settings_continue, emit_renderer_action
  * queries.py     — list / get / events_since / stream_run_events
  * drafts.py      — per-file autosave endpoints
  * inspection.py  — list_cell_files / get_cell_dag

Each submodule owns its own ``APIRouter``; this __init__ builds a single
combined router that preserves the existing ``from routes.runs import router``
import path. Helpers and the ``active_managers`` singleton are re-exported
for external callers.
"""

from fastapi import APIRouter

from . import control, create, drafts, inspection, queries
from .helpers import (
    _find_version_tip,
    _promote_drafts_to_version,
    _reap_process,
)
from .models import (
    RendererActionRequest,
    RunRequest,
    SettingsContinueRequest,
)
from .registry import ActiveManagersRegistry, active_managers

# Expose create_run at package level so ``from routes.runs import create_run``
# keeps working (drafts.py route re-dispatches into it).
from .create import create_run  # noqa: E402


router = APIRouter()
router.include_router(create.router)
router.include_router(control.router)
router.include_router(queries.router)
router.include_router(drafts.router)
router.include_router(inspection.router)


__all__ = [
    "router",
    "active_managers",
    "ActiveManagersRegistry",
    "_find_version_tip",
    "_promote_drafts_to_version",
    "_reap_process",
    "RunRequest",
    "RendererActionRequest",
    "SettingsContinueRequest",
    "create_run",
]
