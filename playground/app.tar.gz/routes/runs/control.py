"""Control endpoints — stop, settings_continue, emit_renderer_action."""

import asyncio
import json
import logging
import os
import signal as sig_module

import yaml
from fastapi import APIRouter, HTTPException

from database import get_db_connection
from process_manager import ProcessManager

from .models import KeyContinueRequest, RendererActionRequest, SettingsContinueRequest
from .registry import active_managers

_logger = logging.getLogger("runs.control")

router = APIRouter()


@router.post("/api/channels/{channel}/cells/{cell_id}/actions")
async def emit_renderer_action(channel: str, cell_id: str, body: RendererActionRequest):
    """Enqueue a renderer-emitted action (e.g. top-bar button click) for
    whichever active generator owns this cell as its placeholder.

    The generator consumes via gen.wait_for_action() in its SDK.
    """
    manager = next(
        (m for m in active_managers.values()
         if m.channel == channel and m.placeholder_cell_id == cell_id),
        None,
    )
    if not manager:
        raise HTTPException(404, f"No active run for cell {cell_id}")
    if not body.action_id:
        raise HTTPException(400, "action_id is required")
    manager._pending_renderer_actions.append(body.action_id)
    return {"ok": True}


@router.post("/api/channels/{channel}/runs/{run_id}/settings_continue")
async def settings_continue(channel: str, run_id: str, body: SettingsContinueRequest):
    """Resume a generator that called request_settings_update().

    The frontend POSTs the edited settings content here after the user
    clicks Continue. We write it back to the workspace, parse the values,
    and unblock the generator.
    """
    manager = active_managers.get(run_id)
    if not manager or not isinstance(manager, ProcessManager):
        raise HTTPException(404, f"No active run {run_id}")
    if manager._pending_settings_update is None:
        raise HTTPException(400, "Run is not waiting for a settings update")

    # Write the updated settings back to the workspace. The settings
    # content can be tens of KB on a Draft cell with many generator
    # config files; offload so the disk write doesn't block the loop.
    def _write_settings():
        abs_path = os.path.join(manager.workspace_dir, body.settings_filename)
        os.makedirs(os.path.dirname(abs_path), exist_ok=True)
        with open(abs_path, "w", encoding="utf-8") as f:
            f.write(body.settings_content)
    await asyncio.to_thread(_write_settings)

    # Parse values from the settings content
    values = {}
    try:
        parsed = yaml.safe_load(body.settings_content) or {}
        if isinstance(parsed, dict):
            values = parsed.get("values", {})
            if not isinstance(values, dict):
                values = {}
    except Exception:
        _logger.warning(
            "settings_continue: failed to parse settings content for run %s; "
            "resuming generator with empty values", run_id, exc_info=True,
        )

    manager._settings_update_values = values
    # Record this settings snapshot so it lands in .colreserved/ on the
    # final version tip at finalization (alongside logs.txt and the
    # initial settings). Named update_settings_1, update_settings_2, …
    manager.append_settings_update(body.settings_content, body.settings_filename)
    manager._pending_settings_update.set()

    return {"ok": True}


@router.post("/api/channels/{channel}/runs/{run_id}/key_continue")
async def key_continue(channel: str, run_id: str, body: KeyContinueRequest):
    """Resume a generator that called ``gen.get_key()``.

    The frontend POSTs here when the user submits the in-cell key
    modal. Two paths:

      * ``cancel=True`` → record the cancellation and unblock the IPC
        handler; the generator raises ``StopSignal`` and the run stops
        cleanly.
      * Otherwise ``value`` must be a non-empty string. We persist it
        via the keystore (so it survives across runs / restarts), put
        it into ``os.environ`` (so the in-process generator and any
        future ``gen.get_key()`` fast-paths see it), and unblock the
        IPC handler with the value.
    """
    manager = active_managers.get(run_id)
    if not manager or not isinstance(manager, ProcessManager):
        raise HTTPException(404, f"No active run {run_id}")
    if manager._pending_key_request is None:
        raise HTTPException(400, "Run is not waiting for a key request")
    if not body.key_name:
        raise HTTPException(400, "key_name is required")

    if body.cancel:
        manager._key_request_cancelled = True
        manager._key_request_value = None
        manager._pending_key_request.set()
        return {"ok": True, "cancelled": True}

    value = (body.value or "").strip()
    if not value:
        raise HTTPException(400, "value must be non-empty (or use cancel=true)")

    # Persist via the keystore so the secret survives a server restart
    # AND becomes visible to other runs / channels (the keystore is
    # user-scoped — see api/keystore.py). os.environ is the in-process
    # mirror — gen.get_key's fast path reads from there.
    try:
        from keystore import set_key, available
        if available():
            set_key(body.key_name, value)
    except Exception:
        # Persistence failure (e.g. macOS keychain locked) shouldn't
        # block the in-flight run — the os.environ mirror still
        # satisfies this run; the user can re-enter on restart.
        pass

    os.environ[body.key_name] = value
    manager._key_request_value = value
    manager._key_request_cancelled = False
    manager._pending_key_request.set()
    return {"ok": True}


@router.delete("/api/channels/{channel}/runs/{run_id}")
async def stop_run(channel: str, run_id: str, force: bool = False):
    """Send SIGTERM (or SIGKILL if force=true) to the run's process and mark it stopped."""
    manager = active_managers.get(run_id)

    # Wasm runs have no subprocess — cancellation is a cooperative flag
    # the generator polls via ctx.cancelled. Flip it and leave cleanup to
    # _reap_process when the task completes.
    from runtime import IS_WASM
    if manager is not None and IS_WASM:
        manager._cancelled = True
        manager.push_log("[stop] cancellation requested by user")
        # If the generator is currently blocked in ctx.get_key /
        # ctx.request_settings_update waiting on a modal, the
        # cooperative _cancelled flag isn't enough — the helper is
        # parked on the relevant asyncio.Event and won't observe the
        # flag. Signal each pending event so the helpers unwind cleanly
        # (key request -> KeyRequestCancelled, settings update ->
        # empty values dict). Native has no equivalent because SIGTERM
        # tears the IPC handler down at the OS level.
        if manager._pending_key_request is not None:
            manager._key_request_cancelled = True
            manager._key_request_value = None
            manager._pending_key_request.set()
        if manager._pending_settings_update is not None:
            manager._settings_update_values = {}
            manager._pending_settings_update.set()
        # Force-stop is the user's escape hatch when cooperative cancel
        # can't reach the dispatch — e.g. wedged inside a non-cooperative
        # await like ``micropip.install`` during ``build_agent``. Cancel
        # the dispatch task, mark the run stopped in the DB, and
        # broadcast the terminal status so the frontend flips the cell
        # out of "running" without waiting for the wedged coroutine to
        # notice. The cooperative flags above stay set so a generator
        # that *does* unwind cleanly still sees ``ctx.cancelled``.
        if force:
            ct = getattr(manager, "_cleanup_task", None)
            if ct is not None and not ct.done():
                ct.cancel()

            # Stopped-row write + stop event INSERT offloaded so a
            # concurrent generator-subprocess writer can't stall the
            # loop on busy_timeout while we mark the run dead.
            def _mark_force_stopped():
                conn = get_db_connection(channel)
                try:
                    conn.execute(
                        "UPDATE runs SET status='stopped' WHERE id=?", (run_id,)
                    )
                    conn.execute(
                        "INSERT INTO run_events (run_id, event_type, payload) "
                        "VALUES (?, 'stop', ?)",
                        (run_id, json.dumps({"stop_type": "force_stopped"})),
                    )
                    conn.commit()
                finally:
                    conn.close()
            await asyncio.to_thread(_mark_force_stopped)

            try:
                manager._broadcast_run_status("stopped")
            except Exception:
                _logger.debug(
                    "stop_run: run_status broadcast failed for run %s",
                    run_id, exc_info=True,
                )
            return {"status": "stopped", "stop_type": "force_stopped"}
        return {"status": "stopping", "stop_type": "wasm_cooperative"}

    if not manager or not manager.process or manager.process.returncode is not None:
        # Process already finished — just ensure DB status is updated.
        # Also re-broadcast run_status: a prior stop's _wait_and_cleanup
        # already broadcast on the way out, but if that event got
        # dropped (SSE backpressure / overflow / brief disconnect)
        # the frontend's run_id stays in stoppingRunIds forever and
        # the cell appears wedged on "Force Stop". Re-firing the
        # broadcast is idempotent (endRun keys off run_id) and
        # cheap enough to do unconditionally as a defensive belt-
        # and-suspenders.
        active_managers.pop(run_id, None)

        def _mark_stopped():
            conn = get_db_connection(channel)
            try:
                conn.execute("UPDATE runs SET status='stopped' WHERE id=?", (run_id,))
                conn.commit()
            finally:
                conn.close()
        await asyncio.to_thread(_mark_stopped)

        try:
            from events import broadcast
            from database import _slug_channel
            broadcast(_slug_channel(channel), {
                "type": "run_status",
                "run_id": run_id,
                "status": "stopped",
            })
        except Exception:
            _logger.debug(
                "stop_run: run_status broadcast failed for already-finished run %s",
                run_id, exc_info=True,
            )
        return {"status": "stopped", "stop_type": "already_finished"}

    pid = manager.process.pid

    def _kill_pg(sig):
        """Send signal to the process group, falling back to direct kill."""
        if os.name == "nt":
            if sig == sig_module.SIGKILL:
                manager.process.kill()
            else:
                manager.process.terminate()
            return
        try:
            os.killpg(os.getpgid(pid), sig)
        except (ProcessLookupError, PermissionError, OSError):
            try:
                os.kill(pid, sig)
            except (ProcessLookupError, PermissionError, OSError):
                pass

    stop_type = "force_stopped" if force else "gracefully_stopped"

    def _close_ipc_if_open():
        # On SIGKILL the _wait_and_cleanup task may never run, so the
        # IPC TCP server is only torn down when the manager object is
        # GC'd. Close it explicitly here so the port + socket fd are
        # released immediately.
        srv = getattr(manager, "_ipc_server", None)
        if srv is not None:
            try:
                srv.close()
            except Exception:
                _logger.debug(
                    "stop_run: IPC server close failed for run %s (already closed?)",
                    run_id, exc_info=True,
                )

    if force:
        _kill_pg(sig_module.SIGKILL)
        _close_ipc_if_open()
        active_managers.pop(run_id, None)
        # Eager broadcast so the frontend flips out of "Stopping…" /
        # "Force Stop" the instant SIGKILL lands. _wait_and_cleanup
        # broadcasts run_status too, but it has to await the
        # microbatch writer's final flush first — when the log
        # buffer is large that finalization can take 5-10s, and the
        # cell's Force Stop button is wedged for that whole window.
        # Mirrors the wasm branch above. Safe to fire twice — the
        # frontend's endRun is idempotent on the run_id key.
        try:
            manager._broadcast_run_status("stopped")
        except Exception:
            _logger.debug(
                "stop_run: run_status broadcast failed for force-stopped run %s",
                run_id, exc_info=True,
            )
    else:
        _kill_pg(sig_module.SIGTERM)

        # Escalate to SIGKILL if the process doesn't exit within 15 seconds.
        # 15s is generous enough to let generator cleanup finish — e.g.
        # vscode_docker needs to call docker stop on its container, which
        # itself can take a few seconds. The previous 5s budget was too
        # short and routinely killed cleanup mid-flight, leaking containers.
        async def _escalate_kill():
            try:
                await asyncio.wait_for(manager.process.wait(), timeout=15.0)
            except asyncio.TimeoutError:
                _kill_pg(sig_module.SIGKILL)
            except Exception:
                _logger.warning(
                    "stop_run: escalate-kill wait failed for run %s (pid %s)",
                    run_id, pid, exc_info=True,
                )
            finally:
                active_managers.pop(run_id, None)

        from task_utils import track_task
        track_task(_escalate_kill(), name=f"escalate_kill:{run_id}")

    # Drain whatever the microbatch writer has in flight before returning.
    # Without this, a client that POSTs /stop and immediately calls
    # /events_since can see a truncated log tail (last ~500 ms of stdout
    # still sitting in the in-memory buffer).
    try:
        await asyncio.to_thread(manager._flush_log_buffer)
    except Exception:
        _logger.warning(
            "stop_run: final log-buffer flush failed for run %s; "
            "log tail may be truncated", run_id, exc_info=True,
        )

    # Stopped status + stop event INSERT offloaded — mirrors the wasm
    # / already-finished branches above.
    def _mark_stopped_native():
        conn = get_db_connection(channel)
        try:
            conn.execute("UPDATE runs SET status='stopped' WHERE id=?", (run_id,))
            conn.execute(
                "INSERT INTO run_events (run_id, event_type, payload) VALUES (?, 'stop', ?)",
                (run_id, json.dumps({"stop_type": stop_type})),
            )
            conn.commit()
        finally:
            conn.close()
    await asyncio.to_thread(_mark_stopped_native)

    return {"status": "stopped", "stop_type": stop_type}
