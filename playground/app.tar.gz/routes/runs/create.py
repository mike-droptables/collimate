"""The POST /api/channels/{channel}/runs endpoint — create_run.

Implements the 2-node sequence: JIT draft flush, then spawn the
generator subprocess with the hydrated workspace.
"""

import asyncio
import json
import os
import shutil
import tempfile
import uuid

import yaml
from fastapi import APIRouter, HTTPException

from database import get_db_connection
from process_manager import ProcessManager

from .helpers import (
    _audit_filename,
    _find_generator_dir,
    _get_all_generator_cells,
    _hydrate_workspace,
    _jit_flush_drafts,
    _read_manifest,
    _reap_process,
)
from .models import RunRequest
from .registry import active_managers

router = APIRouter()


@router.post("/api/channels/{channel}/runs")
async def create_run(channel: str, req: RunRequest):
    """Spawn a new generator subprocess and begin a run.

    Implements the Phase 4 hard execution gate (2-node sequence):
      1. JIT Write: Flush pending drafts, mint a "Human Edit" DAG node
      2. Run Job: Hydrate workspace from the pristine CAS snapshot, spawn generator
    """
    run_id = str(uuid.uuid4())

    # ID-continuity path: if placeholder_cell_id was provided by a
    # client-only Picking but doesn't exist in state.channels yet,
    # create the cell + its stack here using that id. This replaces
    # the former client-side createPlaceholderCell round-trip with a
    # single run call, so the Picking's UUID flows through unchanged
    # into the eventual Standard cell.
    if req.placeholder_cell_id:
        from state import state, persist_state
        from models import Cell as _Cell, Stack as _Stack
        # Channel param in the URL is the slugified DB name; the
        # active channel is the one currently selected. Mutating state
        # always targets the active channel by id.
        ch_obj = next(
            (c for c in state.channels if c.id == state.active_channel_id),
            None,
        )
        if ch_obj is None:
            # No active channel to place the placeholder on — fail loudly
            # so the frontend can surface the error instead of waiting
            # forever for a run whose output has nowhere to land.
            raise HTTPException(409, "No active channel to attach the placeholder cell to")
        exists = any(
            str(c.id) == req.placeholder_cell_id
            for s in (ch_obj.main_stacks + ch_obj.nav_stacks)
            for c in s.cells
        )
        if not exists:
            try:
                new_id = uuid.UUID(req.placeholder_cell_id)
            except ValueError:
                raise HTTPException(400, "placeholder_cell_id must be a valid UUID")
            new_cell = _Cell(id=new_id, name="Generating...", summary="", files=[])
            new_stack = _Stack(name="", cells=[new_cell])
            # Drop right of insert_after_stack_id; append if unknown.
            insert_idx = len(ch_obj.main_stacks)
            if req.insert_after_stack_id:
                for i, s in enumerate(ch_obj.main_stacks):
                    if str(s.id) == req.insert_after_stack_id:
                        insert_idx = i + 1
                        break
            ch_obj.main_stacks.insert(insert_idx, new_stack)
            ch_obj.main_selection_id = new_stack.id
            persist_state()

    # Locate the generator source
    gen_dir = _find_generator_dir(req.generator_name)
    if not gen_dir:
        raise HTTPException(404, f"Generator '{req.generator_name}' not found")

    manifest = _read_manifest(gen_dir)
    entrypoint = manifest.get("entrypoint", f"{req.generator_name}.py")

    # Enforce manifest input bounds (inputs.cells.min / inputs.cells.max)
    inputs_spec = (manifest.get("inputs") or {}).get("cells") or {}
    n_inputs = len(req.input_cell_ids)
    min_in = inputs_spec.get("min")
    max_in = inputs_spec.get("max")
    if min_in is not None and n_inputs < int(min_in):
        raise HTTPException(
            400,
            f"Generator '{req.generator_name}' requires at least {min_in} input cell(s); got {n_inputs}.",
        )
    if max_in is not None and n_inputs > int(max_in):
        raise HTTPException(
            400,
            f"Generator '{req.generator_name}' accepts at most {max_in} input cell(s); got {n_inputs}.",
        )

    # ``chat: true|false`` is the canonical declaration for whether the
    # cell should render chat affordances. Native-only manifests may
    # set ``live_files_mode`` to opt into mid-run file editing — WASM
    # generators never do. Both surface to the frontend as the existing
    # capability strings so the picker / cell UX doesn't change shape.
    #
    # Chat generators implicitly support live files: the
    # /chat/push_message endpoint flushes pending cell_drafts into the
    # generator's workspace before each turn, so the agent reads
    # whatever the user typed between turns even when the manifest
    # doesn't declare live_files_mode. Default chat:true to live_files
    # so the frontend doesn't paint the "Files locked during run"
    # banner over a Files tab that's actually editable. Manifests can
    # still opt back out by declaring live_files_mode: none explicitly.
    is_chat = bool(manifest.get("chat", False))
    live_chat_mode = "locked_history" if is_chat else "none"
    declared_files_mode = manifest.get("live_files_mode")
    if declared_files_mode is None:
        live_files_mode = "live_files" if is_chat else "none"
    else:
        live_files_mode = declared_files_mode

    # Record the run in the database early so JIT flush can reference the run_id
    conn = get_db_connection(channel)
    conn.execute(
        "INSERT INTO runs (id, prompt, status) VALUES (?, ?, 'running')",
        (run_id, req.prompt),
    )
    conn.commit()
    conn.close()

    # --- Phase 4: JIT Draft Flush ---
    # Flush any pending drafts into formal "Human Edit" DAG nodes.
    # Returns a {input_cell_id -> effective_tip_id} dict — the tip captured
    # atomically during the flush. Workspace hydration below reads from this
    # dict instead of re-walking the version chain, so a concurrent in-place
    # update can't split the run across two different versions of the same
    # input.
    resolved_tips = _jit_flush_drafts(channel, run_id, req.input_cell_ids)

    # Create isolated directories:
    #   app_dir   = copy of the generator code (CWD for the process, read-only intent)
    #   workspace = separate temp dir for hydrated input files (read/write)
    # These live under .collimate/tmp/ instead of the system tempdir so that
    # Docker-based generators can bind-mount them. Snap-confined Docker on
    # Ubuntu can't access /tmp/* but can access any path under the user's
    # home directory, and the collimate CWD is typically there.
    runs_tmp_root = os.path.abspath(os.path.join(".collimate", "tmp"))
    os.makedirs(runs_tmp_root, exist_ok=True)
    app_dir = tempfile.mkdtemp(prefix=f"app_{run_id[:8]}_", dir=runs_tmp_root)
    workspace_dir = tempfile.mkdtemp(prefix=f"ws_{run_id[:8]}_", dir=runs_tmp_root)

    # Any failure between this point and manager.start() must unwind the
    # temp dirs and mark the run failed — otherwise hydration exceptions
    # leak multi-MB workspaces and leave a dangling "running" run row.
    def _cleanup_tmp(exc_msg: str):
        shutil.rmtree(app_dir, ignore_errors=True)
        shutil.rmtree(workspace_dir, ignore_errors=True)
        active_managers.pop(run_id, None)
        conn = get_db_connection(channel)
        conn.execute("UPDATE runs SET status='failed' WHERE id=?", (run_id,))
        conn.commit()
        conn.close()

    try:
        # Copy generator code into the app dir
        for item in os.listdir(gen_dir):
            src = os.path.join(gen_dir, item)
            dst = os.path.join(app_dir, item)
            if os.path.isdir(src):
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)

        # Hydrate workspace from the input cells. resolved_tips was
        # captured atomically during the JIT flush so hydration reads
        # exactly the version each input was flushed against.
        _hydrate_workspace(
            channel, req.input_cell_ids, workspace_dir,
            resolved_tips=resolved_tips,
        )
    except Exception as exc:
        _cleanup_tmp(str(exc))
        raise HTTPException(500, f"Failed to prepare run workspace: {exc}")

    # If promoting a Draft cell, flip its state to Standard now so
    # subsequent operations treat it as a first-class cell. The row id
    # stays the same — this is the seamless Draft→Standard transition.
    if req.draft_source_cell_id:
        conn = get_db_connection(channel)
        try:
            conn.execute(
                "UPDATE cells SET state='Standard' WHERE id=? AND state='Draft'",
                (req.draft_source_cell_id,),
            )
            conn.commit()
        finally:
            conn.close()
        # Mirror the DB flip into state.channels so the next SSE
        # state_update (or /api/state fetch) reflects the promoted
        # cell immediately — otherwise the client briefly sees the
        # cell as still Draft and routes message-edits through the
        # draft-files endpoint (which 409s because DB is Standard).
        from state import state as _state
        ch_obj = next((c for c in _state.channels if c.id == _state.active_channel_id), None)
        if ch_obj is not None:
            for s in ch_obj.main_stacks:
                for c in s.cells:
                    if str(c.id) == req.draft_source_cell_id:
                        from models import CellState as _CellState
                        c.state = _CellState.STANDARD
                        c.draft_generator_id = None
                        # Clear draft-authored visible files and the
                        # draft-picked summary_artifact NOW — before
                        # manager.start() triggers the generator's
                        # initial update_cell, which walks the
                        # in-memory cell files. Draft files are
                        # re-routed to .colreserved/config/files/ in
                        # the workspace and persisted privately at
                        # run end; they must not leak onto the
                        # Standard cell at their original visible
                        # paths.
                        c.files = []
                        c.summary_artifact = None
                        if c.name.startswith("Draft: "):
                            c.name = c.name[len("Draft: "):]
                        # Bump updated_at so the frontend's
                        # applyServerState (which gates on timestamp
                        # newness) accepts this state_update — without
                        # the bump, the client's cached Draft cell
                        # (with files + summary_artifact still set)
                        # is never replaced, so the Settings tab and
                        # original-path setting file appear to stick
                        # around even though server-side they're gone.
                        from datetime import datetime as _dt
                        c.updated_at = _dt.now()
                        break

    # Write the Draft cell's pre-run config into .colreserved/config/.
    # This is the unified location for everything the user authored
    # before the run started:
    #   - settings.json: flat {key: value} dict from the generator's
    #     settings-schema form (selected enum values, numbers, etc.)
    #   - files/: every config file — whether seeded from the
    #     generator's manifest.draft_files (direct-Run path) or copied
    #     from the Draft cell's edited files (Draft-Run path). Read via
    #     `gen.config.get_file()` / `gen.config.list_files()` /
    #     `gen.config.read_schema_values()`.
    #
    # Walk the generator source for draft_files declarations — those
    # get seeded even when there's no settings and no Draft, so a
    # bare direct-Run still has sensible defaults to read.
    manifest_draft_files: list[tuple[str, str]] = []  # (rel_path, content)
    try:
        found = False
        for src_cell in _get_all_generator_cells():
            if found:
                break
            # A single generator-source cell bundles many manifests (one
            # per generator in the group), so iterate all manifests and
            # filter by id.
            for manifest_file in src_cell.files:
                if not manifest_file.name.endswith("manifest.gen_yaml"):
                    continue
                try:
                    mf = yaml.safe_load(manifest_file.content) or {}
                except Exception:
                    continue
                if mf.get("id") != req.generator_name:
                    continue
                prefix = manifest_file.name[:-len("manifest.gen_yaml")]
                rels = list(mf.get("draft_files") or [])
                for rel in rels:
                    candidate = prefix + rel
                    src = next((f for f in src_cell.files if f.name == candidate), None)
                    if src is not None:
                        manifest_draft_files.append((rel, src.content))
                found = True
                break
    except Exception:
        manifest_draft_files = []

    need_config = (
        req.settings is not None
        or req.draft_source_cell_id
        or bool(manifest_draft_files)
    )
    if need_config:
        cfg_dir = os.path.join(workspace_dir, ".colreserved", "config")
        os.makedirs(cfg_dir, exist_ok=True)
        files_dir = os.path.join(cfg_dir, "files")
        os.makedirs(files_dir, exist_ok=True)

        if req.settings is not None:
            with open(os.path.join(cfg_dir, "settings.json"), "w", encoding="utf-8") as f:
                json.dump(req.settings, f)

        if req.draft_source_cell_id:
            # Draft-Run path: the Draft's edited files are authoritative.
            conn = get_db_connection(channel)
            try:
                rows = conn.execute(
                    "SELECT filepath, content_text FROM draft_cell_files WHERE cell_id=?",
                    (req.draft_source_cell_id,),
                ).fetchall()
            finally:
                conn.close()
            # Two special-case destinations that bypass the normal
            # .colreserved/config/files/ landing zone:
            #   - chat history goes to .colreserved/.collimate_messages.json
            #     so gen.chat.history sees it as the turn starting point.
            #   - the Draft's prompt.md is promoted to the canonical
            #     .colreserved/prompt.md location that gen.prompt reads,
            #     mirroring the direct-run path below.
            CHAT_PATHS = {".collimate_messages.json", ".colreserved/.collimate_messages.json"}
            for r in rows:
                rel = r["filepath"]
                content = r["content_text"] or ""
                if rel in CHAT_PATHS:
                    msgs_dst = os.path.join(workspace_dir, ".colreserved", ".collimate_messages.json")
                    os.makedirs(os.path.dirname(msgs_dst), exist_ok=True)
                    with open(msgs_dst, "w", encoding="utf-8") as f:
                        f.write(content)
                    continue
                if rel == "prompt.md":
                    prompt_dst = os.path.join(workspace_dir, ".colreserved", "prompt.md")
                    os.makedirs(os.path.dirname(prompt_dst), exist_ok=True)
                    with open(prompt_dst, "w", encoding="utf-8") as f:
                        f.write(content)
                    continue
                dst = os.path.join(files_dir, rel)
                os.makedirs(os.path.dirname(dst) or files_dir, exist_ok=True)
                with open(dst, "w", encoding="utf-8") as f:
                    f.write(content)
        else:
            # Direct-Run path: seed from the manifest's draft_files
            # declarations (unedited defaults from generator source),
            # then overlay any per-file overrides the client sent via
            # req.initial_files. The overlay keeps the "Run with my
            # picker-modal edits" path working without a Draft round
            # trip: the modal renders each draft_file with its
            # renderer, the user edits, those edits land here.
            # prompt.md is reserved — routed to the canonical
            # .colreserved/prompt.md instead of config/files/. The
            # overlay honors the same rule.
            seeded_files: dict[str, str] = {rel: content for rel, content in manifest_draft_files}
            if req.initial_files:
                for rel, content in req.initial_files.items():
                    seeded_files[rel] = content
            for rel, content in seeded_files.items():
                if rel == "prompt.md":
                    prompt_dst = os.path.join(workspace_dir, ".colreserved", "prompt.md")
                    os.makedirs(os.path.dirname(prompt_dst), exist_ok=True)
                    with open(prompt_dst, "w", encoding="utf-8") as f:
                        f.write(content)
                    continue
                dst = os.path.join(files_dir, rel)
                os.makedirs(os.path.dirname(dst) or files_dir, exist_ok=True)
                with open(dst, "w", encoding="utf-8") as f:
                    f.write(content)

    # Primary prompt — the single free-text input from the picker modal
    # / quick palette / pinned-prompt button. Overwrites any manifest
    # default that may have landed at .colreserved/prompt.md above —
    # the user-typed prompt always wins over the default. If req.prompt
    # is empty we leave the manifest default (or nothing) in place.
    if req.prompt:
        res_dir = os.path.join(workspace_dir, ".colreserved")
        os.makedirs(res_dir, exist_ok=True)
        with open(os.path.join(res_dir, "prompt.md"), "w", encoding="utf-8") as pf:
            pf.write(req.prompt)

    # Every run auto-creates a placeholder cell (handled by the frontend).
    # The ProcessManager uses it as the "first cell" for update_cell().
    audit_filename, audit_content = _audit_filename(
        channel, req.draft_source_cell_id, manifest_draft_files,
    )
    manager = ProcessManager(
        channel=channel,
        run_id=run_id,
        app_dir=app_dir,
        workspace_dir=workspace_dir,
        entrypoint=entrypoint,
        generator_name=req.generator_name,
        params=req.params,
        placeholder_cell_id=req.placeholder_cell_id,
        input_cell_ids=req.input_cell_ids,
        initial_settings_content=audit_content,
        initial_settings_filename=audit_filename,
    )
    active_managers[run_id] = manager

    try:
        await manager.start()
    except Exception as exc:
        _cleanup_tmp(str(exc))
        raise HTTPException(500, f"Failed to start generator process: {exc}")

    # Spawn the zombie reaper task
    from task_utils import track_task
    track_task(_reap_process(run_id, manager), name=f"reap_process:{run_id}")

    # Persist run_id + channel on the in-memory placeholder cell so
    # /api/state reflects "running" before the generator's first
    # update_cell commits. Without this, any fetchState in the gap
    # wipes the client's optimistically-patched run_id and the cell
    # stops looking like it's running (chat daemons can sit idle for
    # minutes waiting for input before their first commit).
    if req.placeholder_cell_id:
        from state import state as _state, persist_state as _persist_state
        ch_obj = next((c for c in _state.channels if c.id == _state.active_channel_id), None)
        if ch_obj is not None:
            for s in ch_obj.main_stacks:
                for c in s.cells:
                    if str(c.id) == req.placeholder_cell_id:
                        c.run_id = run_id
                        c.channel = channel
                        break
            _persist_state()

    return {
        "run_id": run_id,
        "status": "running",
        "live_chat_mode": live_chat_mode,
        "live_files_mode": live_files_mode,
    }
