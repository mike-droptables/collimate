"""The POST /api/channels/{channel}/runs endpoint — create_run.

Implements the 2-node sequence: JIT draft flush, then spawn the
generator subprocess with the hydrated workspace.
"""

import asyncio
import logging
import os
import shutil
import tempfile
import uuid
from datetime import datetime

import yaml
from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse

from config_tags import missing_required_fields, overlay_set_yaml_values, parse_set_yaml
from database import get_db_connection
from process_manager import ProcessManager

from .helpers import (
    _audit_filename,
    _find_generator_dir,
    _get_all_generator_cells,
    _hydrate_workspace,
    _jit_flush_drafts,
    _read_manifest,
    _reap_process,
)
from .models import RunRequest
from .registry import active_managers, is_shutting_down

logger = logging.getLogger(__name__)

router = APIRouter()


@router.post("/api/channels/{channel}/runs")
async def create_run(channel: str, req: RunRequest):
    """Spawn a new generator subprocess and begin a run.

    Implements the Phase 4 hard execution gate (2-node sequence):
      1. JIT Write: Flush pending drafts, mint a "Manual Edit" DAG node
      2. Run Job: Hydrate workspace from the pristine CAS snapshot, spawn generator
    """
    # A run created while the lifespan teardown is sweeping would spawn a
    # generator (its own session — detached from the server's process
    # group) after stop_all_runs already ran, leaving it orphaned past
    # server exit. Refuse instead.
    if is_shutting_down():
        raise HTTPException(503, "Server is shutting down; not accepting new runs")

    run_id = str(uuid.uuid4())

    # Locate the generator source — scoped to THIS run's channel, never the
    # globally-active UI channel.
    gen_dir = _find_generator_dir(req.generator_name, channel)
    if not gen_dir:
        raise HTTPException(404, f"Generator '{req.generator_name}' not found")

    manifest = _read_manifest(gen_dir)
    entrypoint = manifest.get("entrypoint", f"{req.generator_name}.py")

    # Validate / resolve the invocation type. Manifests declare a
    # ``type`` array of every mode they support (post-cleanup); the
    # frontend tells us which one the user picked. If absent, fall
    # back to the first declared mode. If the caller asks for a mode
    # the manifest doesn't declare, reject.
    declared = manifest.get("type")
    declared_types = [t for t in declared if isinstance(t, str)] \
        if isinstance(declared, list) else []
    if req.invocation_type is not None:
        if req.invocation_type not in declared_types:
            raise HTTPException(
                400,
                f"Generator '{req.generator_name}' does not declare invocation_type "
                f"{req.invocation_type!r}; declared={declared_types}.",
            )
        resolved_invocation_type: str | None = req.invocation_type
    else:
        resolved_invocation_type = declared_types[0] if declared_types else None

    # Enforce manifest input bounds (inputs.cells.min / inputs.cells.max)
    inputs_spec = (manifest.get("inputs") or {}).get("cells") or {}
    n_inputs = len(req.input_cell_ids)
    min_in = inputs_spec.get("min")
    max_in = inputs_spec.get("max")
    if min_in is not None and n_inputs < int(min_in):
        raise HTTPException(
            400,
            f"Generator '{req.generator_name}' requires at least {min_in} input cell(s); got {n_inputs}.",
        )
    if max_in is not None and n_inputs > int(max_in):
        raise HTTPException(
            400,
            f"Generator '{req.generator_name}' accepts at most {max_in} input cell(s); got {n_inputs}.",
        )

    # --- Pre-run config: manifest defaults ⊕ config tag ⊕ initial_files ---
    # Computed (and gated) before the run row exists so a rejected run
    # leaves nothing behind.
    #
    # Walk the generator source for draft_files declarations — those
    # get seeded even with no overrides, so a bare direct-Run still has
    # sensible defaults to read.
    manifest_draft_files: list[tuple[str, str]] = []  # (rel_path, content)
    try:
        found = False
        for src_cell in _get_all_generator_cells(channel):
            if found:
                break
            # A single generator-source cell bundles many manifests (one
            # per generator in the group), so iterate all manifests and
            # filter by id.
            for manifest_file in src_cell.files:
                if not manifest_file.name.endswith("manifest.gen_yaml"):
                    continue
                try:
                    mf = yaml.safe_load(manifest_file.content) or {}
                except Exception:
                    continue
                if mf.get("id") != req.generator_name:
                    continue
                prefix = manifest_file.name[:-len("manifest.gen_yaml")]
                rels = list(mf.get("draft_files") or [])
                for rel in rels:
                    candidate = prefix + rel
                    src = next((f for f in src_cell.files if f.name == candidate), None)
                    if src is not None:
                        manifest_draft_files.append((rel, src.content))
                found = True
                break
    except Exception:
        manifest_draft_files = []

    # Resolve the requested config tag. None and "default" are no-op
    # safe for any generator (incl. no-config ones); only an unknown
    # non-default tag is rejected.
    tag_name = req.config_tag or "default"
    config_tags = manifest.get("config_tags")
    if isinstance(config_tags, dict) and tag_name in config_tags:
        tag_body = config_tags[tag_name] or {}
    elif tag_name != "default":
        raise HTTPException(
            400,
            f"Generator '{req.generator_name}' has no config tag {tag_name!r}.",
        )
    else:
        tag_body = {}
    tag_files = tag_body.get("files") if isinstance(tag_body, dict) and isinstance(tag_body.get("files"), dict) else {}
    tag_prompt = tag_body.get("prompt") if isinstance(tag_body, dict) and isinstance(tag_body.get("prompt"), str) else None

    # Tag values overlay the manifest-default .set_yaml contents via a
    # comment-preserving `values:` splice — this is the bottom layer,
    # so stored resume config and initial_files below still win.
    if tag_files:
        overlaid: list[tuple[str, str]] = []
        for rel, content in manifest_draft_files:
            overlay = tag_files.get(rel)
            if rel.endswith(".set_yaml") and isinstance(overlay, dict) and overlay:
                try:
                    content = overlay_set_yaml_values(content, overlay)
                except ValueError:
                    logger.warning(
                        "config tag %r: cannot overlay %s for generator %s — seeding unmodified",
                        tag_name, rel, req.generator_name, exc_info=True,
                    )
            overlaid.append((rel, content))
        manifest_draft_files = overlaid

    # Final seeding layers. The config tag is the starting point for
    # every run: manifest defaults ⊕ tag overlay form the base, and
    # picker-modal initial_files (the explicit "edit this run's config"
    # intent) win on top. A re-run does NOT inherit the prior run's
    # committed config — the selected tag, not the cell's history, is
    # authoritative. prompt.md is reserved — routed to
    # .colreserved/prompt.md, not config/files/.
    seeded_files: dict[str, str] = {rel: content for rel, content in manifest_draft_files}
    if tag_prompt is not None and tag_prompt.strip():
        # The tag's prompt seeds the prompt slot at the manifest layer;
        # req.prompt (the user-typed text) still wins below.
        seeded_files["prompt.md"] = tag_prompt
    if req.initial_files:
        for rel, content in req.initial_files.items():
            seeded_files[rel] = content

    # Required gate — unconditional, even with zero draft files: any
    # required+empty field in the final seeded .set_yamls blocks the
    # run, as does a blank prompt when the manifest demands one.
    missing_required: list[dict] = []
    for rel, content in seeded_files.items():
        if not rel.endswith(".set_yaml"):
            continue
        fields, resolved = parse_set_yaml(content)
        missing_required.extend(missing_required_fields(rel, fields, resolved))
    if manifest.get("prompt_required"):
        seeded_prompt = seeded_files.get("prompt.md")
        if not (req.prompt or "").strip() and not (seeded_prompt or "").strip():
            missing_required.append(
                {"file": "prompt.md", "key": "prompt", "label": "Prompt"}
            )
    if missing_required:
        return JSONResponse(
            status_code=400,
            content={"code": "missing_required", "fields": missing_required},
        )

    # --- End of rejection gates. Invariant: no 4xx rejection may fire
    # after a state mutation — a rejected run must never leave a
    # placeholder cell/stack or run row behind. Keep new validation
    # gates (unknown generator, invocation type, input bounds, unknown
    # tag, missing_required) above this line; the placeholder block
    # below checks its own preconditions (active channel, UUID shape)
    # before it inserts anything.

    # ID-continuity path: if placeholder_cell_id was provided by a
    # client-only Picking but doesn't exist in state.channels yet,
    # create the cell + its stack here using that id. This replaces
    # the former client-side createPlaceholderCell round-trip with a
    # single run call, so the Picking's UUID flows through unchanged
    # into the eventual Standard cell.
    if req.placeholder_cell_id:
        from state import persist_state, get_channel_by_db_name
        from models import Cell as _Cell, Stack as _Stack
        # Place the placeholder on the RUN's channel (the URL param), NOT the
        # globally-active one — the generator's output lands in the run's
        # channel (cells._find_channel → manager.channel), so the placeholder
        # must too, or the output has no stack to attach to.
        ch_obj = get_channel_by_db_name(channel)
        if ch_obj is None:
            # No such channel to place the placeholder on — fail loudly so the
            # frontend can surface the error instead of waiting forever for a
            # run whose output has nowhere to land.
            raise HTTPException(404, f"Channel '{channel}' not found")
        exists = any(
            str(c.id) == req.placeholder_cell_id
            for s in (ch_obj.main_stacks + ch_obj.nav_stacks)
            for c in s.cells
        )
        if not exists:
            try:
                new_id = uuid.UUID(req.placeholder_cell_id)
            except ValueError:
                raise HTTPException(400, "placeholder_cell_id must be a valid UUID")
            # Initialize the running cell's transient `placement` from
            # the channel's default — the user can flip it from the
            # log slot's toggle while the run is in flight (Phase 10).
            new_cell = _Cell(
                id=new_id, name="Generating...", summary="", files=[],
                placement=ch_obj.placement_default,
            )
            new_stack = _Stack(name="", cells=[new_cell])
            # Drop right of insert_after_stack_id; append if unknown.
            insert_idx = len(ch_obj.main_stacks)
            if req.insert_after_stack_id:
                for i, s in enumerate(ch_obj.main_stacks):
                    if str(s.id) == req.insert_after_stack_id:
                        insert_idx = i + 1
                        break
            ch_obj.main_stacks.insert(insert_idx, new_stack)
            ch_obj.main_selection_id = new_stack.id
            persist_state()
        else:
            # Existing cell becoming the running cell — seed its
            # transient placement from the channel default. Bump
            # updated_at so the frontend's (id, updated_at)
            # reconciliation accepts the change.
            for s in ch_obj.main_stacks + ch_obj.nav_stacks:
                for c in s.cells:
                    if str(c.id) == req.placeholder_cell_id:
                        c.placement = ch_obj.placement_default
                        c.updated_at = datetime.now()
                        break

    # ``live_files_mode`` is a generic capability: a generator may declare
    # ``live_files`` to let the user edit files mid-run. Defaults to ``none``
    # (files locked during the run) when unspecified. Chat is no longer a
    # special manifest flag — a chat generator is just a daemon that serves
    # a chat session and pins a ``.chat`` file rendered by the chat
    # renderer; it opts into live files like any other generator.
    live_files_mode = manifest.get("live_files_mode") or "none"

    # Record the run in the database early so JIT flush can reference the run_id.
    # Offloaded so concurrent live runs holding the channel DB's WAL write
    # lock can't stall this call (and the event loop) on busy_timeout.
    def _insert_run_row():
        conn = get_db_connection(channel)
        try:
            conn.execute(
                "INSERT INTO runs (id, prompt, status, phase) "
                "VALUES (?, ?, 'running', 'queued')",
                (run_id, req.prompt),
            )
            conn.commit()
        finally:
            conn.close()

    await asyncio.to_thread(_insert_run_row)

    # --- Phase 4: JIT Draft Flush ---
    # Flush any pending drafts into formal "Manual Edit" DAG nodes.
    # Returns a {input_cell_id -> effective_tip_id} dict — the tip captured
    # atomically during the flush. Workspace hydration below reads from this
    # dict instead of re-walking the version chain, so a concurrent in-place
    # update can't split the run across two different versions of the same
    # input.
    #
    # Offloaded to a worker thread because _jit_flush_drafts opens a sync
    # SQLite connection on the channel DB; if another live run's worker is
    # mid-flush holding the WAL write lock, this call would block on
    # busy_timeout=5000 *on the event loop*, freezing every other route
    # handler. With to_thread the wait stays on a worker.
    resolved_tips = await asyncio.to_thread(
        _jit_flush_drafts, channel, run_id, req.input_cell_ids,
    )

    # Create isolated directories:
    #   app_dir   = copy of the generator code (CWD for the process, read-only intent)
    #   workspace = separate temp dir for hydrated input files (read/write)
    # These live under .collimate/tmp/ instead of the system tempdir so that
    # Docker-based generators can bind-mount them. Snap-confined Docker on
    # Ubuntu can't access /tmp/* but can access any path under the user's
    # home directory, and the collimate CWD is typically there.
    runs_tmp_root = os.path.abspath(os.path.join(".collimate", "tmp"))
    os.makedirs(runs_tmp_root, exist_ok=True)
    app_dir = tempfile.mkdtemp(prefix=f"app_{run_id[:8]}_", dir=runs_tmp_root)
    workspace_dir = tempfile.mkdtemp(prefix=f"ws_{run_id[:8]}_", dir=runs_tmp_root)

    # Any failure between this point and manager.start() must unwind the
    # temp dirs and mark the run failed — otherwise hydration exceptions
    # leak multi-MB workspaces and leave a dangling "running" run row.
    def _cleanup_tmp(exc_msg: str):
        shutil.rmtree(app_dir, ignore_errors=True)
        shutil.rmtree(workspace_dir, ignore_errors=True)
        active_managers.pop(run_id, None)
        conn = get_db_connection(channel)
        conn.execute("UPDATE runs SET status='failed' WHERE id=?", (run_id,))
        conn.commit()
        conn.close()

    # ``gen_dir`` is the generator's own subdir within a tmp tree that
    # also contains any ``_*`` sibling packages (see _find_generator_dir).
    # Copy the WHOLE tree into ``app_dir`` so the sibling shared modules
    # land at ``app_dir/_*`` — that's where the generator's sys.path shim
    # ``parent-of-parent of __file__`` resolves them at runtime.
    gen_tmp_root = os.path.dirname(gen_dir)
    gen_subdir = os.path.basename(gen_dir)
    gen_app_dir = os.path.join(app_dir, gen_subdir)

    def _copy_app_and_hydrate():
        """Sync workspace prep — generator code copy + CAS-to-disk
        hydrate of input cells. Both are filesystem-bound and can take
        tens of milliseconds on a chat with many files; running on the
        event loop blocks every concurrent route handler for that
        window. to_thread keeps the loop free."""
        for item in os.listdir(gen_tmp_root):
            src = os.path.join(gen_tmp_root, item)
            dst = os.path.join(app_dir, item)
            if os.path.isdir(src):
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)

        _hydrate_workspace(
            channel, req.input_cell_ids, workspace_dir,
            resolved_tips=resolved_tips,
        )

    try:
        await asyncio.to_thread(_copy_app_and_hydrate)
    except Exception as exc:
        _cleanup_tmp(str(exc))
        raise HTTPException(500, f"Failed to prepare run workspace: {exc}")

    # Write the run's pre-run config into .colreserved/config/files/ —
    # the unified location for everything the user authored before the
    # run started (computed + gated above, before the run row existed).
    # Read via `gen.config.get_file()` / `gen.config.list_files()` /
    # `gen.config.read_schema_values()`.
    if seeded_files:
        files_dir = os.path.join(workspace_dir, ".colreserved", "config", "files")
        os.makedirs(files_dir, exist_ok=True)
        for rel, content in seeded_files.items():
            if rel == "prompt.md":
                prompt_dst = os.path.join(workspace_dir, ".colreserved", "prompt.md")
                os.makedirs(os.path.dirname(prompt_dst), exist_ok=True)
                with open(prompt_dst, "w", encoding="utf-8") as f:
                    f.write(content)
                continue
            dst = os.path.join(files_dir, rel)
            os.makedirs(os.path.dirname(dst) or files_dir, exist_ok=True)
            with open(dst, "w", encoding="utf-8") as f:
                f.write(content)

    # Primary prompt — the single free-text input from the picker modal
    # / quick palette / pinned-prompt button. Overwrites any manifest
    # default that may have landed at .colreserved/prompt.md above —
    # the user-typed prompt always wins over the default. If req.prompt
    # is empty we leave the manifest default (or nothing) in place.
    if req.prompt:
        res_dir = os.path.join(workspace_dir, ".colreserved")
        os.makedirs(res_dir, exist_ok=True)
        with open(os.path.join(res_dir, "prompt.md"), "w", encoding="utf-8") as pf:
            pf.write(req.prompt)

    # Every run auto-creates a placeholder cell (handled by the frontend).
    # The ProcessManager uses it as the "first cell" for update_cell().
    audit_filename, audit_content = _audit_filename(
        channel, manifest_draft_files,
    )
    manager = ProcessManager(
        channel=channel,
        run_id=run_id,
        app_dir=gen_app_dir,
        workspace_dir=workspace_dir,
        entrypoint=entrypoint,
        generator_name=req.generator_name,
        params=req.params,
        placeholder_cell_id=req.placeholder_cell_id,
        input_cell_ids=req.input_cell_ids,
        initial_settings_content=audit_content,
        initial_settings_filename=audit_filename,
        invocation_type=resolved_invocation_type,
        call_depth=req.call_depth,
    )
    active_managers[run_id] = manager

    try:
        await manager.start()
    except BaseException as exc:
        # start() can fail (or be cancelled) AFTER the subprocess was
        # spawned — e.g. in _apply_phase or task wiring. _cleanup_tmp pops
        # the registry and deletes the dirs, so without an explicit kill
        # the live process would be orphaned with nothing tracking it.
        proc = getattr(manager, "process", None)
        if proc is not None and proc.returncode is None:
            import signal as _sig
            try:
                if os.name == "nt":
                    proc.kill()
                else:
                    os.killpg(os.getpgid(proc.pid), _sig.SIGKILL)
            except (ProcessLookupError, PermissionError, OSError):
                pass
        _cleanup_tmp(str(exc))
        if not isinstance(exc, Exception):
            raise  # CancelledError etc. — propagate after cleanup
        raise HTTPException(500, f"Failed to start generator process: {exc}")

    # Spawn the zombie reaper task
    from task_utils import track_task
    track_task(_reap_process(run_id, manager), name=f"reap_process:{run_id}")

    # Persist run_id + channel on the in-memory placeholder cell so
    # /api/state reflects "running" before the generator's first
    # update_cell commits. Without this, any fetchState in the gap
    # wipes the client's optimistically-patched run_id and the cell
    # stops looking like it's running (chat daemons can sit idle for
    # minutes waiting for input before their first commit).
    if req.placeholder_cell_id:
        from state import (
            persist_state as _persist_state,
            get_channel_by_db_name as _get_channel_by_db_name,
            channel_db_name as _channel_db_name,
        )
        ch_obj = _get_channel_by_db_name(channel)
        if ch_obj is not None:
            for s in ch_obj.main_stacks:
                for c in s.cells:
                    if str(c.id) == req.placeholder_cell_id:
                        c.run_id = run_id
                        # Canonical slug (matches process_manager cell writes),
                        # not the raw URL display name.
                        c.channel = _channel_db_name(ch_obj)
                        # Bump so the frontend's (id, updated_at)
                        # reconciliation accepts the run attach — other
                        # windows have no optimistic patchCell for it.
                        c.updated_at = datetime.now()
                        break
            _persist_state()

    return {
        "run_id": run_id,
        "status": "running",
        "live_files_mode": live_files_mode,
    }
