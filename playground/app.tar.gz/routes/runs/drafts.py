"""JIT working-tree persistence — per-file draft autosave endpoints.

These operate on the cell_drafts table (file-level autosave scratch),
separate from the Draft *cell* lifecycle in routes/drafts.py.
"""

from fastapi import APIRouter, Request

from database import get_db_connection

router = APIRouter()


@router.put("/api/channels/{channel}/cells/{cell_id}/drafts/{filepath:path}")
async def upsert_draft(channel: str, cell_id: str, filepath: str, request: Request):
    """Debounce target — upsert a single file draft."""
    content = (await request.body()).decode("utf-8")
    conn = get_db_connection(channel)
    conn.execute(
        "INSERT INTO cell_drafts (cell_id, filepath, content_text, updated_at) "
        "VALUES (?, ?, ?, CURRENT_TIMESTAMP) "
        "ON CONFLICT(cell_id, filepath) DO UPDATE SET content_text=excluded.content_text, updated_at=CURRENT_TIMESTAMP",
        (cell_id, filepath, content),
    )
    conn.commit()
    conn.close()
    return {"status": "ok"}


@router.get("/api/channels/{channel}/cells/{cell_id}/drafts")
async def list_drafts(channel: str, cell_id: str):
    """List all pending drafts for a cell."""
    conn = get_db_connection(channel)
    rows = conn.execute(
        "SELECT filepath, length(content_text) as size, updated_at FROM cell_drafts WHERE cell_id=?",
        (cell_id,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@router.delete("/api/channels/{channel}/cells/{cell_id}/drafts")
async def clear_drafts(channel: str, cell_id: str):
    """Clear all drafts for a cell (called after JIT flush)."""
    conn = get_db_connection(channel)
    conn.execute("DELETE FROM cell_drafts WHERE cell_id=?", (cell_id,))
    conn.commit()
    conn.close()
    return {"status": "cleared"}


@router.delete("/api/channels/{channel}/cells/{cell_id}/drafts/{filepath:path}")
async def tombstone_draft(channel: str, cell_id: str, filepath: str):
    """Mark a single path as tombstoned in cell_drafts.

    Used by structural edits (rename-source, delete) to tell the JIT
    flush "the next promoted version should NOT contain this path",
    even though the path still exists at the version tip. Stored as a
    row with ``content_text=NULL`` — distinct from an upsert with empty
    body, which writes ``""`` (a legitimately-empty file).
    ``_promote_drafts_to_version`` reads NULL as tombstone and drops
    the path from the new version.
    """
    conn = get_db_connection(channel)
    conn.execute(
        "INSERT INTO cell_drafts (cell_id, filepath, content_text, updated_at) "
        "VALUES (?, ?, NULL, CURRENT_TIMESTAMP) "
        "ON CONFLICT(cell_id, filepath) DO UPDATE SET content_text=NULL, updated_at=CURRENT_TIMESTAMP",
        (cell_id, filepath),
    )
    conn.commit()
    conn.close()
    return {"status": "tombstoned"}
