"""Helpers shared across the run-route modules.

Workspace hydration, generator discovery, manifest reading, audit-
filename resolution, JIT draft promotion, zombie-process reaping.
"""

import asyncio
import json
import logging
import os
import re
import shutil
import tempfile
import uuid

import yaml

from cas import hash_and_store_bytes
from database import get_db_connection
from process_manager import ProcessManager
from reserved_paths import is_reserved_path

from .registry import active_managers

logger = logging.getLogger(__name__)


def _audit_filename(
    channel: str,
    draft_source_cell_id: str | None,
    manifest_draft_files: list[tuple[str, str]],
) -> tuple[str | None, str | None]:
    """Return (filename, content) to persist under
    `.colreserved/initial_settings<ext>` on the final committed cell.

    First manifest-declared draft file's name and default content. If
    there are no config files declared at all, both fields are None
    and no audit file is written. ``draft_source_cell_id`` is kept on
    the signature for call-site compatibility but is no longer
    consulted (Draft cells no longer exist as a runtime concept).
    """
    del draft_source_cell_id  # retained for caller compatibility
    if manifest_draft_files:
        return manifest_draft_files[0][0], manifest_draft_files[0][1]
    return None, None


def _get_all_generator_cells(channel: str):
    """Return all cells from all generator stacks in ``channel`` (a db-name
    slug). `stack_type` is the sole source of truth for what counts as a
    generator stack.

    ``channel`` is REQUIRED — there is no active-channel fallback, so
    run-context code cannot accidentally resolve a different channel's
    generators (the channel-isolation boundary is enforced by the type, not
    by convention)."""
    from state import get_channel_by_db_name
    ch = get_channel_by_db_name(channel)
    if not ch:
        return []
    cells = []
    for s in ch.main_stacks + ch.nav_stacks:
        if s.stack_type == 'generator':
            cells.extend(s.cells)
    return cells


def _find_generator_dir(generator_name: str, channel: str) -> str | None:
    """
    Locate a generator by name across all cells in all generator stacks.
    Returns the path to the generator's own subdirectory inside a fresh
    temp tree, or None.

    Layout under the temp tree mirrors the SDK source so the sys.path
    shim sibling generators use (``parent-of-parent of __file__``)
    resolves shared dirs at runtime exactly as it does at source::

        <tmp_root>/<gen_dir_basename>/<gen files>
        <tmp_root>/_*/<shared sibling files>

    The returned path is ``<tmp_root>/<gen_dir_basename>``; callers that
    need the outer tree (to copy ``_*`` siblings into the run's app_dir)
    walk up via ``os.path.dirname``.

    ``channel`` (a db-name slug) scopes resolution to the run's own channel;
    see ``_get_all_generator_cells``.
    """
    source_cells = _get_all_generator_cells(channel)
    if not source_cells:
        return None

    for source_cell in source_cells:
        target_prefix = None
        for f in source_cell.files:
            if f.name.endswith("manifest.gen_yaml"):
                try:
                    manifest = yaml.safe_load(f.content)
                    if manifest and manifest.get("id", "") == generator_name:
                        target_prefix = f.name[:-len("manifest.gen_yaml")]
                        break
                except Exception:
                    pass

        tmp = tempfile.mkdtemp(prefix=f"collimate_gen_{generator_name}_")
        has_files = False
        gen_subdir: str | None = None

        if target_prefix is not None:
            # ``group_prefix`` is the path up to (but excluding) the
            # generator's own dir — empty when the generator sits at the
            # root of the source tree.
            tp = target_prefix.rstrip("/")
            slash = tp.rfind("/")
            group_prefix = tp[:slash + 1] if slash >= 0 else ""
            gen_subdir = tp[slash + 1:] if slash >= 0 else tp

            for f in source_cell.files:
                if f.name.startswith(target_prefix):
                    rel = f"{gen_subdir}/{f.name[len(target_prefix):]}"
                elif f.name.startswith(group_prefix):
                    # Shared sibling: a ``_*`` folder beside the generator
                    # under the same group parent. ``group_prefix`` is ""
                    # when the generator sits at the cell root (flat,
                    # basename-only cells), where startswith("") matches
                    # every file and the ``_`` check selects the siblings.
                    sibling = f.name[len(group_prefix):]
                    first_seg, _, _ = sibling.partition("/")
                    if not first_seg.startswith("_") or first_seg == gen_subdir:
                        continue
                    rel = sibling
                else:
                    continue
                dest = os.path.join(tmp, rel)
                os.makedirs(os.path.dirname(dest) or tmp, exist_ok=True)
                with open(dest, "w", encoding="utf-8") as fh:
                    fh.write(f.content)
                has_files = True
        else:
            # Fallback: find files whose path contains the generator name as a
            # directory segment (works at any nesting depth: flat, group, etc.)
            gen_subdir = generator_name
            for f in source_cell.files:
                rel_inside = _strip_to_segment(f.name, generator_name)
                if rel_inside is None and f.name == f"{generator_name}.py":
                    rel_inside = f"{generator_name}.py"
                if rel_inside is not None:
                    dest = os.path.join(tmp, gen_subdir, rel_inside)
                    os.makedirs(os.path.dirname(dest), exist_ok=True)
                    with open(dest, "w", encoding="utf-8") as fh:
                        fh.write(f.content)
                    has_files = True

        if has_files and gen_subdir is not None:
            _ensure_shared_siblings(tmp)
            return os.path.join(tmp, gen_subdir)

        shutil.rmtree(tmp, ignore_errors=True)

    return None


def _ensure_shared_siblings(tmp_root: str) -> None:
    """Make sure the ``_*`` shared helper packages (``_env_shared``,
    ``_cdp_shared``, …) are present as siblings in the materialised tree.

    A generator imports them via the ``parent-of-parent of __file__`` sys.path
    shim, so they must sit beside the generator's dir. Cells *can* bundle them
    (the ``_cdp_shared`` + ``browser_live`` cell does), but that's fragile — a
    generator whose cell forgot to bundle its helper would ``ModuleNotFoundError``
    at runtime. Backfill any missing ``_*`` package from the generator templates
    so it can't drift per-cell. Cell-bundled copies already in the tree win."""
    from genesis import _resolve_assets_dir

    try:
        assets = _resolve_assets_dir("generators")
    except Exception:
        return
    if not assets or not os.path.isdir(assets):
        return
    for name in os.listdir(assets):
        if not name.startswith("_"):
            continue
        src = os.path.join(assets, name)
        dst = os.path.join(tmp_root, name)
        if os.path.isdir(src) and not os.path.exists(dst):
            try:
                shutil.copytree(src, dst, ignore=shutil.ignore_patterns("__pycache__"))
            except OSError:
                pass


def _read_manifest(gen_dir: str) -> dict:
    """Read manifest.gen_yaml from a generator directory, returning {} if absent."""
    manifest_path = os.path.join(gen_dir, "manifest.gen_yaml")
    if os.path.isfile(manifest_path):
        with open(manifest_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    return {}


def _strip_to_segment(filepath: str, name: str) -> str | None:
    """
    If `name` appears as a path segment in `filepath`, return everything after it.
    Examples:
      ("generators/basic/echo/main.py", "echo")          -> "main.py"
      ("generators/problem_space/judge/m.py", "judge")   -> "m.py"
      ("echo/main.py", "echo")                           -> "main.py"
      ("nope/main.py", "echo")                           -> None
    """
    parts = filepath.replace("\\", "/").split("/")
    if name in parts:
        idx = parts.index(name)
        return "/".join(parts[idx + 1:]) or None
    return None


def _hydrate_generator_code_from_cell(channel: str, cell_id: str, gen_name: str, dest_dir: str):
    """
    Extract generator files from a cell's CAS snapshot and copy them into dest_dir.
    Files whose path contains `gen_name` as a directory segment are scoped to that
    generator (everything after the segment becomes the rel path). If no file matches,
    every file in the cell is treated as belonging to the generator (legacy behaviour).
    """
    conn = get_db_connection(channel)
    rows = conn.execute(
        "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?",
        (cell_id,),
    ).fetchall()
    conn.close()

    has_segment_match = any(
        _strip_to_segment(r["filepath"], gen_name) is not None for r in rows
    )

    for row in rows:
        filepath = row["filepath"]
        blob_hash = row["blob_hash"]

        if has_segment_match:
            rel_path = _strip_to_segment(filepath, gen_name)
        else:
            rel_path = filepath

        if rel_path:
            cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
            if os.path.exists(cas_path):
                dest = os.path.join(dest_dir, rel_path)
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                shutil.copy2(cas_path, dest)


def _safe_dest_under(dest_dir: str, rel: str) -> str | None:
    """Resolve ``rel`` under ``dest_dir`` and return the absolute dest path,
    or None if the result would escape the workspace.

    Defends against three things stored cell_files.filepath rows could carry:
      * Absolute paths — ``os.path.join`` ignores its left operand when the
        right one is absolute, so ``/etc/passwd`` would land at /etc/passwd.
      * Parent-traversal segments — ``a/../../etc/passwd`` resolves outside
        the workspace after normalization.
      * Backslash-encoded variants on POSIX — ``..\\..\\foo`` looks safe to
        normpath but not after replacing separators. Reject as a precaution.
    """
    if os.path.isabs(rel) or "\\" in rel:
        return None
    abs_dest_dir = os.path.realpath(dest_dir)
    abs_dest = os.path.normpath(os.path.join(abs_dest_dir, rel))
    if abs_dest != abs_dest_dir and not abs_dest.startswith(abs_dest_dir + os.sep):
        return None
    return abs_dest


def _is_colreserved(cell_path: str) -> bool:
    """`.colreserved/` is a private namespace — never flows in or out of a cell.

    Exception: `.colreserved/.collimate_messages.json` is allowed through
    because it must be hydrated into the workspace for chat history.
    """
    return is_reserved_path(cell_path)


_SLUG_RE = re.compile(r"[^a-z0-9]+")


def _slugify_cell_label(name: str | None, fallback_id: str) -> str:
    """Make a short, filesystem-safe label for an input cell directory."""
    base = (name or "").strip().lower()
    slug = _SLUG_RE.sub("_", base).strip("_")[:32]
    if not slug:
        slug = fallback_id[:8]
    return slug


def _lookup_cell_name(channel: str, cell_id: str) -> str | None:
    """Best-effort: find the human-readable name of a cell from in-memory state."""
    try:
        from state import state
        for ch in state.channels:
            if ch.name and ch.name.lower() != channel.lower():
                continue
            for s in ch.main_stacks + ch.nav_stacks:
                for c in s.cells:
                    if str(c.id) == cell_id:
                        return c.name
    except Exception:
        pass
    return None


def _hydrate_workspace(
    channel: str,
    cell_ids: list[str],
    dest_dir: str,
    resolved_tips: dict[str, str] | None = None,
):
    """
    Copy the last snapshot of each listed cell from the CAS into dest_dir.

    Single input: files land at the workspace root (legacy behaviour, unchanged).
    Multiple inputs: each cell is namespaced into inputs/<NN>_<slug>/ so files
    from different cells cannot collide. Generators that opt into multi-cell
    semantics (judge, synthesize, brainstorm context, etc.) read from inputs/*.

    `.colreserved/*` is filtered out — that namespace is reserved for the SDK.

    ``resolved_tips`` — optional dict mapping cell_id → tip_id captured earlier
    in the same run (by _jit_flush_drafts). When supplied, we trust it as the
    authoritative tip for this run rather than re-walking the version chain.
    Passing the pre-resolved tip forward closes the internal JIT-flush /
    hydrate race where a concurrent in-place update (e.g. a chat turn landing)
    could extend the chain between flush and hydrate and leave hydration
    reading a different version than the one flushed against.
    """
    if not cell_ids:
        logger.info("no input cells for run; workspace will be empty")
        return

    namespace = len(cell_ids) > 1
    conn = get_db_connection(channel)
    for idx, cell_id in enumerate(cell_ids):
        # Use the caller's pre-resolved tip when available; otherwise walk
        # the version chain now. For cells without versions the tip is the
        # cell itself (no-op walk).
        if resolved_tips is not None and cell_id in resolved_tips:
            tip_id = resolved_tips[cell_id]
        else:
            tip_id = _find_version_tip(conn, cell_id)
        rows = conn.execute(
            "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?",
            (tip_id,),
        ).fetchall()

        if namespace:
            label = _slugify_cell_label(_lookup_cell_name(channel, cell_id), cell_id)
            cell_prefix = os.path.join("inputs", f"{idx:02d}_{label}")
        else:
            cell_prefix = ""

        copied = 0
        skipped_reserved = 0
        skipped_missing = 0
        skipped_unsafe = 0
        for row in rows:
            if _is_colreserved(row["filepath"]):
                skipped_reserved += 1
                continue
            blob_hash = row["blob_hash"]
            cas_path = os.path.join(
                ".collimate", "objects", blob_hash[:2], blob_hash[2:]
            )
            if not os.path.exists(cas_path):
                skipped_missing += 1
                continue
            rel = os.path.join(cell_prefix, row["filepath"]) if cell_prefix else row["filepath"]
            dest = _safe_dest_under(dest_dir, rel)
            if dest is None:
                logger.warning(
                    "hydration: refusing unsafe filepath %r for cell %s (escapes workspace)",
                    row["filepath"], cell_id[:8],
                )
                skipped_unsafe += 1
                continue
            # Refuse to write through an existing symlink at dest. workspace_dir
            # is freshly mkdtemp'd so this can only fire if a previous row
            # planted one — defense in depth.
            if os.path.islink(dest):
                logger.warning(
                    "hydration: refusing to overwrite symlink at %r for cell %s",
                    dest, cell_id[:8],
                )
                skipped_unsafe += 1
                continue
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(cas_path, dest)
            copied += 1
        logger.info(
            "cell %s -> %s: %d files copied, %d .colreserved skipped, "
            "%d missing from CAS, %d unsafe-path refused, %d total in cell_files",
            cell_id[:8], cell_prefix or "(root)",
            copied, skipped_reserved, skipped_missing, skipped_unsafe, len(rows),
        )
    conn.close()


def _find_version_tip(conn, start_cell_id: str) -> str:
    """Walk cell_edges forward via parent_key='previous_version' to the tip."""
    current = start_cell_id
    for _ in range(10_000):
        row = conn.execute(
            "SELECT child_cell_id FROM cell_edges "
            "WHERE parent_cell_id=? AND parent_key='previous_version' LIMIT 1",
            (current,),
        ).fetchone()
        if not row:
            break
        current = row[0]
    return current


def _promote_drafts_to_version(
    conn, cell_id: str, run_id: str,
    tip_id: str | None = None,
    current_files: list[dict] | None = None,
) -> str | None:
    """Promote pending drafts for a cell into a new cell version.

    Checks cell_drafts for pending edits. If any exist, creates a new
    version at the tip with parent_key='previous_version', merges the
    draft content with existing files, and clears the drafts.

    Returns the new version cell_id, or None if no drafts were pending.
    Used by both _jit_flush_drafts (before generator runs) and the
    checkpoint endpoint (idle/close saves).

    ``tip_id`` — optional pre-resolved tip id. When provided, the caller
    has already walked the version chain for this cell (atomically with
    respect to the rest of the run) and we use that result. When omitted,
    we walk the chain here ourselves (checkpoint endpoint path).

    ``current_files`` — the cell's CURRENT in-memory files (filepath +
    content) from state.json. Used only when synthesizing a genesis
    row for a never-versioned cell: we seed the genesis's cell_files
    with state.json's content MINUS the paths in cell_drafts (those
    are being edited and we don't have their pre-edit content). This
    makes v1 a faithful snapshot of "what the cell had before drafts"
    for the common case of adding new files. Without this, the
    synthesized genesis is empty and v2 has only the drafted files —
    the 5 unchanged files would disappear.
    """
    drafts = conn.execute(
        "SELECT filepath, content_text, blob_hash FROM cell_drafts WHERE cell_id=?",
        (cell_id,),
    ).fetchall()
    if not drafts:
        return None

    # Walk to the version tip — files live there, not on the visible cell.
    if tip_id is None:
        tip_id = _find_version_tip(conn, cell_id)

    new_cell_id = str(uuid.uuid4())

    row = conn.execute(
        "SELECT COALESCE(MAX(sequence_num), 0) FROM cells WHERE run_id=?",
        (run_id,),
    ).fetchone()
    seq = row[0] + 1

    # Cells created outside the generator pipeline (Empty Cell pseudo-gen,
    # Duplicate, manual API inserts, legacy state.json rows) don't have a
    # row in the SQLite `cells` table — only generator-produced cells do.
    # The first human-edit checkpoint of such a cell would fail with a
    # FOREIGN KEY error on cell_edges.parent_cell_id, since the tip we'd
    # link from doesn't exist yet. Synthesize a genesis row so the FK is
    # satisfied; subsequent checkpoints reuse this row as the previous-
    # version chain head.
    has_tip = conn.execute("SELECT 1 FROM cells WHERE id=?", (tip_id,)).fetchone()
    if not has_tip:
        conn.execute(
            "INSERT INTO cells (id, run_id, generator_name, sequence_num, "
            "version_name, version_summary, source_type) "
            "VALUES (?, ?, 'genesis', ?, 'Initial', 'Initial snapshot', 'human_edit')",
            (tip_id, run_id, seq),
        )
        seq += 1
        # Seed genesis's cell_files from state.json content, MINUS the
        # paths that appear in cell_drafts. The dropped paths are the
        # ones being edited or newly added — they belong to v2, not v1.
        if current_files:
            draft_paths = {d["filepath"] for d in drafts}
            for f in current_files:
                fp = f["filepath"]
                if fp in draft_paths:
                    continue
                # Binary files reference CAS bytes by hash — record the row
                # directly without re-encoding (UTF-8 would corrupt them).
                existing_hash = f.get("blob_hash")
                if existing_hash:
                    conn.execute(
                        "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                        "VALUES (?, ?, ?)",
                        (tip_id, fp, existing_hash),
                    )
                    continue
                content = f.get("content") or ""
                raw = content.encode("utf-8")
                blob_hash = hash_and_store_bytes(raw)
                if not blob_hash:
                    continue
                conn.execute(
                    "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                    (blob_hash, len(raw)),
                )
                conn.execute(
                    "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
                    "VALUES (?, ?, ?)",
                    (tip_id, fp, blob_hash),
                )

    draft_summary = f"Edited {len(drafts)} file(s)"
    conn.execute(
        "INSERT INTO cells (id, run_id, generator_name, sequence_num, "
        "version_name, version_summary, source_type) "
        "VALUES (?, ?, 'human_edit', ?, 'Human Edit', ?, 'human_edit')",
        (new_cell_id, run_id, seq, draft_summary),
    )

    # Wire into the version list — link from the tip, not the visible cell.
    conn.execute(
        "INSERT OR IGNORE INTO cell_edges "
        "(parent_cell_id, child_cell_id, parent_key) VALUES (?, ?, 'previous_version')",
        (tip_id, new_cell_id),
    )

    # Read existing files from the version tip and overlay drafts.
    existing_files = conn.execute(
        "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?",
        (tip_id,),
    ).fetchall()
    file_hashes: dict[str, str] = {r["filepath"]: r["blob_hash"] for r in existing_files}

    for draft in drafts:
        filepath = draft["filepath"]
        content = draft["content_text"]
        draft_blob = draft["blob_hash"]
        # A binary draft references CAS bytes by hash (content_text NULL,
        # blob_hash set) — record the row directly without UTF-8 encoding.
        if draft_blob is not None:
            file_hashes[filepath] = draft_blob
            continue
        # ``content_text IS NULL`` *and* ``blob_hash IS NULL`` is the
        # tombstone sentinel emitted by the per-path DELETE drafts route —
        # used by structural edits (rename-source, delete) to tell the JIT
        # flush this path should not appear in the new version even though
        # it still exists at the tip. Distinct from an empty-body upsert
        # (``""``), which writes a legitimately-empty file.
        if content is None:
            file_hashes.pop(filepath, None)
            continue
        raw = content.encode("utf-8")
        blob_hash = hash_and_store_bytes(raw)
        if blob_hash:
            file_hashes[filepath] = blob_hash

    for filepath, blob_hash in file_hashes.items():
        cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
        size = 0
        if os.path.exists(cas_path):
            try:
                size = os.path.getsize(cas_path)
            except OSError:
                pass
        conn.execute(
            "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
            (blob_hash, size),
        )
        conn.execute(
            "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
            "VALUES (?, ?, ?)",
            (new_cell_id, filepath, blob_hash),
        )

    conn.execute("DELETE FROM cell_drafts WHERE cell_id=?", (cell_id,))

    # Audit trail
    conn.execute(
        "INSERT INTO run_events (run_id, event_type, payload) VALUES (?, 'commit', ?)",
        (
            run_id,
            json.dumps({
                "cell_id": new_cell_id,
                "name": "Human Edit",
                "summary": draft_summary,
                "sequence_num": seq,
                "file_count": len(file_hashes),
            }),
        ),
    )
    return new_cell_id


def _jit_flush_drafts(
    channel: str, run_id: str, input_cell_ids: list[str],
) -> dict[str, str]:
    """
    JIT Draft Flush — promotes pending drafts into cell versions.

    For each input cell with pending drafts, creates a new version at the
    tip (parent_key='previous_version') so the edit appears in the cell
    versions panel alongside generator turns.

    Returns a ``dict[cell_id -> effective_tip_id]`` capturing the exact
    version each input resolves to for this run. When drafts were flushed,
    the effective tip is the newly-minted 'Human Edit' version id; when
    no drafts existed, it is the current chain tip. The version chain is
    walked exactly once per input here, inside the same transaction as
    the flush — callers (workspace hydration) read this dict instead of
    re-walking, so a concurrent in-place update landing between phases
    cannot split the run across two different versions of the same input.
    """
    if not input_cell_ids:
        return {}

    # Resolve each cell's current in-memory files from state.json so the
    # synthesized genesis (for never-versioned input cells) is seeded
    # with the right snapshot. Best-effort — missing entries fall back
    # to None and the genesis will be empty for that cell.
    current_files_by_id: dict[str, list[dict]] = {}
    try:
        from state import state, channel_db_name
        from database import _slug_channel
        slug = _slug_channel(channel)
        for ch in state.channels:
            if channel_db_name(ch) != slug:
                continue
            for stk in [*ch.main_stacks, *ch.nav_stacks]:
                for c in stk.cells:
                    cid = str(c.id)
                    if cid in input_cell_ids and cid not in current_files_by_id:
                        current_files_by_id[cid] = [
                            {"filepath": f.name, "content": f.content, "blob_hash": f.blob_hash}
                            for f in c.files
                        ]
            break
    except Exception:
        current_files_by_id = {}

    resolved: dict[str, str] = {}
    conn = get_db_connection(channel)
    try:
        for cell_id in input_cell_ids:
            tip_id = _find_version_tip(conn, cell_id)
            new_version = _promote_drafts_to_version(
                conn, cell_id, run_id, tip_id=tip_id,
                current_files=current_files_by_id.get(cell_id),
            )
            resolved[cell_id] = new_version if new_version is not None else tip_id
        conn.commit()
    finally:
        conn.close()
    return resolved


async def _reap_process(run_id: str, manager: ProcessManager):
    """Wait for the process to exit, then clean up active_managers."""
    if hasattr(manager, '_cleanup_task') and manager._cleanup_task is not None:
        # Tolerate cancellation — wasm force-stop cancels the dispatch
        # task directly, so awaiting it here re-raises CancelledError.
        # That's expected (not an error), so swallow it; we still want
        # to drain the writer + pop active_managers below.
        try:
            await manager._cleanup_task
        except asyncio.CancelledError:
            pass
    elif manager.process:
        await manager.process.wait()
    # Drain the log writer's final flush before removing the manager so
    # tail log lines (final push_log, key-cancel notice, etc.) actually
    # land in run_events. On native this is also awaited inside
    # _wait_and_cleanup (no-op here, already done); on wasm this is the
    # only spot that awaits it.
    writer = getattr(manager, '_writer_task', None)
    if writer is not None:
        try:
            await writer
        except (Exception, asyncio.CancelledError):
            pass
    active_managers.pop(run_id, None)

    # Clear the running cell's transient `placement` field once the
    # run ends — the toggle in the log slot is for in-flight cells
    # only, and persisting a stale value on an idle cell would leak
    # mid-run state into the channel snapshot.
    try:
        from state import persist_state as _persist_state, get_channel_by_db_name
        placeholder_id = getattr(manager, 'placeholder_cell_id', None)
        if placeholder_id is None:
            return
        # The run's OWN channel — never the globally-active one, or teardown of
        # a run in a background channel would clear placement on whatever the
        # user is currently viewing.
        ch = get_channel_by_db_name(getattr(manager, 'channel', '') or '')
        if ch is None:
            return
        for s in ch.main_stacks + ch.nav_stacks:
            for c in s.cells:
                if str(c.id) == str(placeholder_id) and c.placement is not None:
                    c.placement = None
                    _persist_state()
                    return
    except Exception:
        # Best-effort cleanup; failure here shouldn't fail run teardown.
        pass
