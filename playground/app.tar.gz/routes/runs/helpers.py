"""Helpers shared across the run-route modules.

Workspace hydration, generator discovery, manifest reading, audit-
filename resolution, JIT draft promotion, zombie-process reaping.
"""

import asyncio
import json
import logging
import os
import re
import shutil
import tempfile
import uuid

import yaml

from cas import hash_and_store_bytes
from database import get_db_connection
from process_manager import ProcessManager

from .registry import active_managers

logger = logging.getLogger(__name__)


def _audit_filename(
    channel: str,
    draft_source_cell_id: str | None,
    manifest_draft_files: list[tuple[str, str]],
) -> tuple[str | None, str | None]:
    """Return (filename, content) to persist under
    `.colreserved/initial_settings<ext>` on the final committed cell.

    On the Draft-Run path the Draft's edited content wins — it's the
    real source of truth. On the direct-Run path we fall back to the
    manifest defaults. First entry only; if there are no config files
    declared at all, both fields are None and no audit file is written.
    """
    if draft_source_cell_id and manifest_draft_files:
        target = manifest_draft_files[0][0]
        conn = get_db_connection(channel)
        try:
            row = conn.execute(
                "SELECT filepath, content_text FROM draft_cell_files "
                "WHERE cell_id=? AND filepath=? LIMIT 1",
                (draft_source_cell_id, target),
            ).fetchone()
            if row:
                return row[0], row[1] or ""
            # Fallback: any draft_cell_files row for the cell
            row = conn.execute(
                "SELECT filepath, content_text FROM draft_cell_files "
                "WHERE cell_id=? ORDER BY filepath LIMIT 1",
                (draft_source_cell_id,),
            ).fetchone()
            if row:
                return row[0], row[1] or ""
        finally:
            conn.close()
    if manifest_draft_files:
        return manifest_draft_files[0][0], manifest_draft_files[0][1]
    return None, None


def _get_all_generator_cells():
    """Return all cells from all generator stacks. `stack_type` is the
    sole source of truth for what counts as a generator stack."""
    from state import state
    if not state.active_channel_id:
        return []
    ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
    if not ch:
        return []
    cells = []
    for s in ch.main_stacks + ch.nav_stacks:
        if s.stack_type == 'generator':
            cells.extend(s.cells)
    return cells


def _find_generator_source_cell():
    """Return the first cell from a generator stack, or None."""
    cells = _get_all_generator_cells()
    return cells[0] if cells else None


def _find_generator_dir(generator_name: str) -> str | None:
    """
    Locate a generator by name across all cells in all generator stacks.
    Returns a temp directory with the generator code extracted, or None.
    """
    source_cells = _get_all_generator_cells()
    if not source_cells:
        return None

    for source_cell in source_cells:
        target_prefix = None
        for f in source_cell.files:
            if f.name.endswith("manifest.gen_yaml"):
                try:
                    manifest = yaml.safe_load(f.content)
                    if manifest and manifest.get("id", "") == generator_name:
                        target_prefix = f.name[:-len("manifest.gen_yaml")]
                        break
                except Exception:
                    pass

        tmp = tempfile.mkdtemp(prefix=f"collimate_gen_{generator_name}_")
        has_files = False

        if target_prefix is not None:
            for f in source_cell.files:
                if f.name.startswith(target_prefix):
                    rel = f.name[len(target_prefix):]
                    dest = os.path.join(tmp, rel)
                    os.makedirs(os.path.dirname(dest), exist_ok=True)
                    with open(dest, "w", encoding="utf-8") as fh:
                        fh.write(f.content)
                    has_files = True
        else:
            # Fallback: find files whose path contains the generator name as a
            # directory segment (works at any nesting depth: flat, group, etc.)
            for f in source_cell.files:
                rel = _strip_to_segment(f.name, generator_name)
                if rel is None and f.name == f"{generator_name}.py":
                    rel = f"{generator_name}.py"
                if rel is not None:
                    dest = os.path.join(tmp, rel)
                    os.makedirs(os.path.dirname(dest), exist_ok=True)
                    with open(dest, "w", encoding="utf-8") as fh:
                        fh.write(f.content)
                    has_files = True

        if has_files:
            return tmp

        shutil.rmtree(tmp, ignore_errors=True)

    return None


def _read_manifest(gen_dir: str) -> dict:
    """Read manifest.gen_yaml from a generator directory, returning {} if absent."""
    manifest_path = os.path.join(gen_dir, "manifest.gen_yaml")
    if os.path.isfile(manifest_path):
        with open(manifest_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    return {}


def _strip_to_segment(filepath: str, name: str) -> str | None:
    """
    If `name` appears as a path segment in `filepath`, return everything after it.
    Examples:
      ("generators/basic/echo/main.py", "echo")          -> "main.py"
      ("generators/problem_space/judge/m.py", "judge")   -> "m.py"
      ("echo/main.py", "echo")                           -> "main.py"
      ("nope/main.py", "echo")                           -> None
    """
    parts = filepath.replace("\\", "/").split("/")
    if name in parts:
        idx = parts.index(name)
        return "/".join(parts[idx + 1:]) or None
    return None


def _hydrate_generator_code_from_cell(channel: str, cell_id: str, gen_name: str, dest_dir: str):
    """
    Extract generator files from a cell's CAS snapshot and copy them into dest_dir.
    Files whose path contains `gen_name` as a directory segment are scoped to that
    generator (everything after the segment becomes the rel path). If no file matches,
    every file in the cell is treated as belonging to the generator (legacy behaviour).
    """
    conn = get_db_connection(channel)
    rows = conn.execute(
        "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?",
        (cell_id,),
    ).fetchall()
    conn.close()

    has_segment_match = any(
        _strip_to_segment(r["filepath"], gen_name) is not None for r in rows
    )

    for row in rows:
        filepath = row["filepath"]
        blob_hash = row["blob_hash"]

        if has_segment_match:
            rel_path = _strip_to_segment(filepath, gen_name)
        else:
            rel_path = filepath

        if rel_path:
            cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
            if os.path.exists(cas_path):
                dest = os.path.join(dest_dir, rel_path)
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                shutil.copy2(cas_path, dest)


def _safe_dest_under(dest_dir: str, rel: str) -> str | None:
    """Resolve ``rel`` under ``dest_dir`` and return the absolute dest path,
    or None if the result would escape the workspace.

    Defends against three things stored cell_files.filepath rows could carry:
      * Absolute paths — ``os.path.join`` ignores its left operand when the
        right one is absolute, so ``/etc/passwd`` would land at /etc/passwd.
      * Parent-traversal segments — ``a/../../etc/passwd`` resolves outside
        the workspace after normalization.
      * Backslash-encoded variants on POSIX — ``..\\..\\foo`` looks safe to
        normpath but not after replacing separators. Reject as a precaution.
    """
    if os.path.isabs(rel) or "\\" in rel:
        return None
    abs_dest_dir = os.path.realpath(dest_dir)
    abs_dest = os.path.normpath(os.path.join(abs_dest_dir, rel))
    if abs_dest != abs_dest_dir and not abs_dest.startswith(abs_dest_dir + os.sep):
        return None
    return abs_dest


def _is_colreserved(cell_path: str) -> bool:
    """`.colreserved/` is a private namespace — never flows in or out of a cell.

    Exception: `.colreserved/.collimate_messages.json` is allowed through
    because it must be hydrated into the workspace for chat history.
    """
    norm = cell_path.replace("\\", "/").lstrip("/")
    if norm == ".colreserved/.collimate_messages.json":
        return False
    return norm == ".colreserved" or norm.startswith(".colreserved/")


_SLUG_RE = re.compile(r"[^a-z0-9]+")


def _slugify_cell_label(name: str | None, fallback_id: str) -> str:
    """Make a short, filesystem-safe label for an input cell directory."""
    base = (name or "").strip().lower()
    slug = _SLUG_RE.sub("_", base).strip("_")[:32]
    if not slug:
        slug = fallback_id[:8]
    return slug


def _lookup_cell_name(channel: str, cell_id: str) -> str | None:
    """Best-effort: find the human-readable name of a cell from in-memory state."""
    try:
        from state import state
        for ch in state.channels:
            if ch.name and ch.name.lower() != channel.lower():
                continue
            for s in ch.main_stacks + ch.nav_stacks:
                for c in s.cells:
                    if str(c.id) == cell_id:
                        return c.name
    except Exception:
        pass
    return None


def _hydrate_workspace(
    channel: str,
    cell_ids: list[str],
    dest_dir: str,
    resolved_tips: dict[str, str] | None = None,
):
    """
    Copy the last snapshot of each listed cell from the CAS into dest_dir.

    Single input: files land at the workspace root (legacy behaviour, unchanged).
    Multiple inputs: each cell is namespaced into inputs/<NN>_<slug>/ so files
    from different cells cannot collide. Generators that opt into multi-cell
    semantics (judge, synthesize, brainstorm context, etc.) read from inputs/*.

    `.colreserved/*` is filtered out — that namespace is reserved for the SDK.

    ``resolved_tips`` — optional dict mapping cell_id → tip_id captured earlier
    in the same run (by _jit_flush_drafts). When supplied, we trust it as the
    authoritative tip for this run rather than re-walking the version chain.
    Passing the pre-resolved tip forward closes the internal JIT-flush /
    hydrate race where a concurrent in-place update (e.g. a chat turn landing)
    could extend the chain between flush and hydrate and leave hydration
    reading a different version than the one flushed against.
    """
    if not cell_ids:
        logger.info("no input cells for run; workspace will be empty")
        return

    namespace = len(cell_ids) > 1
    conn = get_db_connection(channel)
    for idx, cell_id in enumerate(cell_ids):
        # Use the caller's pre-resolved tip when available; otherwise walk
        # the version chain now. For cells without versions the tip is the
        # cell itself (no-op walk).
        if resolved_tips is not None and cell_id in resolved_tips:
            tip_id = resolved_tips[cell_id]
        else:
            tip_id = _find_version_tip(conn, cell_id)
        rows = conn.execute(
            "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?",
            (tip_id,),
        ).fetchall()

        if namespace:
            label = _slugify_cell_label(_lookup_cell_name(channel, cell_id), cell_id)
            cell_prefix = os.path.join("inputs", f"{idx:02d}_{label}")
        else:
            cell_prefix = ""

        copied = 0
        skipped_reserved = 0
        skipped_missing = 0
        skipped_unsafe = 0
        for row in rows:
            if _is_colreserved(row["filepath"]):
                skipped_reserved += 1
                continue
            blob_hash = row["blob_hash"]
            cas_path = os.path.join(
                ".collimate", "objects", blob_hash[:2], blob_hash[2:]
            )
            if not os.path.exists(cas_path):
                skipped_missing += 1
                continue
            rel = os.path.join(cell_prefix, row["filepath"]) if cell_prefix else row["filepath"]
            dest = _safe_dest_under(dest_dir, rel)
            if dest is None:
                logger.warning(
                    "hydration: refusing unsafe filepath %r for cell %s (escapes workspace)",
                    row["filepath"], cell_id[:8],
                )
                skipped_unsafe += 1
                continue
            # Refuse to write through an existing symlink at dest. workspace_dir
            # is freshly mkdtemp'd so this can only fire if a previous row
            # planted one — defense in depth.
            if os.path.islink(dest):
                logger.warning(
                    "hydration: refusing to overwrite symlink at %r for cell %s",
                    dest, cell_id[:8],
                )
                skipped_unsafe += 1
                continue
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(cas_path, dest)
            copied += 1
        logger.info(
            "cell %s -> %s: %d files copied, %d .colreserved skipped, "
            "%d missing from CAS, %d unsafe-path refused, %d total in cell_files",
            cell_id[:8], cell_prefix or "(root)",
            copied, skipped_reserved, skipped_missing, skipped_unsafe, len(rows),
        )
    conn.close()


def _find_version_tip(conn, start_cell_id: str) -> str:
    """Walk cell_edges forward via parent_key='previous_version' to the tip."""
    current = start_cell_id
    for _ in range(10_000):
        row = conn.execute(
            "SELECT child_cell_id FROM cell_edges "
            "WHERE parent_cell_id=? AND parent_key='previous_version' LIMIT 1",
            (current,),
        ).fetchone()
        if not row:
            break
        current = row[0]
    return current


def _promote_drafts_to_version(
    conn, cell_id: str, run_id: str,
    tip_id: str | None = None,
) -> str | None:
    """Promote pending drafts for a cell into a new cell version.

    Checks cell_drafts for pending edits. If any exist, creates a new
    version at the tip with parent_key='previous_version', merges the
    draft content with existing files, and clears the drafts.

    Returns the new version cell_id, or None if no drafts were pending.
    Used by both _jit_flush_drafts (before generator runs) and the
    checkpoint endpoint (idle/close saves).

    ``tip_id`` — optional pre-resolved tip id. When provided, the caller
    has already walked the version chain for this cell (atomically with
    respect to the rest of the run) and we use that result. When omitted,
    we walk the chain here ourselves (checkpoint endpoint path).
    """
    drafts = conn.execute(
        "SELECT filepath, content_text FROM cell_drafts WHERE cell_id=?",
        (cell_id,),
    ).fetchall()
    if not drafts:
        return None

    # Walk to the version tip — files live there, not on the visible cell.
    if tip_id is None:
        tip_id = _find_version_tip(conn, cell_id)

    new_cell_id = str(uuid.uuid4())

    row = conn.execute(
        "SELECT COALESCE(MAX(sequence_num), 0) FROM cells WHERE run_id=?",
        (run_id,),
    ).fetchone()
    seq = row[0] + 1

    draft_summary = f"Edited {len(drafts)} file(s)"
    conn.execute(
        "INSERT INTO cells (id, run_id, generator_name, sequence_num, "
        "version_name, version_summary, source_type) "
        "VALUES (?, ?, 'human_edit', ?, 'Human Edit', ?, 'human_edit')",
        (new_cell_id, run_id, seq, draft_summary),
    )

    # Wire into the version list — link from the tip, not the visible cell.
    conn.execute(
        "INSERT OR IGNORE INTO cell_edges "
        "(parent_cell_id, child_cell_id, parent_key) VALUES (?, ?, 'previous_version')",
        (tip_id, new_cell_id),
    )

    # Read existing files from the version tip and overlay drafts.
    existing_files = conn.execute(
        "SELECT filepath, blob_hash FROM cell_files WHERE cell_id=?",
        (tip_id,),
    ).fetchall()
    file_hashes: dict[str, str] = {r["filepath"]: r["blob_hash"] for r in existing_files}

    for draft in drafts:
        filepath = draft["filepath"]
        content = draft["content_text"]
        # ``content_text IS NULL`` is the tombstone sentinel emitted by
        # the per-path DELETE drafts route — used by structural edits
        # (rename-source, delete) to tell the JIT flush this path
        # should not appear in the new version even though it still
        # exists at the tip. Distinct from an empty-body upsert (``""``),
        # which writes a legitimately-empty file.
        if content is None:
            file_hashes.pop(filepath, None)
            continue
        raw = content.encode("utf-8")
        blob_hash = hash_and_store_bytes(raw)
        if blob_hash:
            file_hashes[filepath] = blob_hash

    for filepath, blob_hash in file_hashes.items():
        cas_path = os.path.join(".collimate", "objects", blob_hash[:2], blob_hash[2:])
        size = 0
        if os.path.exists(cas_path):
            try:
                size = os.path.getsize(cas_path)
            except OSError:
                pass
        conn.execute(
            "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
            (blob_hash, size),
        )
        conn.execute(
            "INSERT OR REPLACE INTO cell_files (cell_id, filepath, blob_hash) "
            "VALUES (?, ?, ?)",
            (new_cell_id, filepath, blob_hash),
        )

    conn.execute("DELETE FROM cell_drafts WHERE cell_id=?", (cell_id,))

    # Audit trail
    conn.execute(
        "INSERT INTO run_events (run_id, event_type, payload) VALUES (?, 'commit', ?)",
        (
            run_id,
            json.dumps({
                "cell_id": new_cell_id,
                "name": "Human Edit",
                "summary": draft_summary,
                "sequence_num": seq,
                "file_count": len(file_hashes),
            }),
        ),
    )
    return new_cell_id


def _jit_flush_drafts(
    channel: str, run_id: str, input_cell_ids: list[str],
) -> dict[str, str]:
    """
    JIT Draft Flush — promotes pending drafts into cell versions.

    For each input cell with pending drafts, creates a new version at the
    tip (parent_key='previous_version') so the edit appears in the cell
    versions panel alongside generator turns.

    Returns a ``dict[cell_id -> effective_tip_id]`` capturing the exact
    version each input resolves to for this run. When drafts were flushed,
    the effective tip is the newly-minted 'Human Edit' version id; when
    no drafts existed, it is the current chain tip. The version chain is
    walked exactly once per input here, inside the same transaction as
    the flush — callers (workspace hydration) read this dict instead of
    re-walking, so a concurrent in-place update landing between phases
    cannot split the run across two different versions of the same input.
    """
    if not input_cell_ids:
        return {}

    resolved: dict[str, str] = {}
    conn = get_db_connection(channel)
    try:
        for cell_id in input_cell_ids:
            tip_id = _find_version_tip(conn, cell_id)
            new_version = _promote_drafts_to_version(
                conn, cell_id, run_id, tip_id=tip_id,
            )
            resolved[cell_id] = new_version if new_version is not None else tip_id
        conn.commit()
    finally:
        conn.close()
    return resolved


async def _reap_process(run_id: str, manager: ProcessManager):
    """Wait for the process to exit, then clean up active_managers."""
    if hasattr(manager, '_cleanup_task') and manager._cleanup_task is not None:
        # Tolerate cancellation — wasm force-stop cancels the dispatch
        # task directly, so awaiting it here re-raises CancelledError.
        # That's expected (not an error), so swallow it; we still want
        # to drain the writer + pop active_managers below.
        try:
            await manager._cleanup_task
        except asyncio.CancelledError:
            pass
    elif manager.process:
        await manager.process.wait()
    # Drain the log writer's final flush before removing the manager so
    # tail log lines (final push_log, key-cancel notice, etc.) actually
    # land in run_events. On native this is also awaited inside
    # _wait_and_cleanup (no-op here, already done); on wasm this is the
    # only spot that awaits it.
    writer = getattr(manager, '_writer_task', None)
    if writer is not None:
        try:
            await writer
        except (Exception, asyncio.CancelledError):
            pass
    active_managers.pop(run_id, None)
