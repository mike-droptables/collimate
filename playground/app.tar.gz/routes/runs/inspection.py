"""Cell / file inspection endpoints."""

from fastapi import APIRouter

from database import get_db_connection

router = APIRouter()


@router.get("/api/channels/{channel}/cells/{cell_id}/files")
async def list_cell_files(channel: str, cell_id: str):
    """List all files snapshotted in a DAG cell."""
    conn = get_db_connection(channel)
    rows = conn.execute(
        "SELECT cf.filepath, cf.blob_hash, b.size, b.mime_type "
        "FROM cell_files cf JOIN blobs b ON cf.blob_hash = b.hash "
        "WHERE cf.cell_id=?",
        (cell_id,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@router.get("/api/channels/{channel}/cells/{cell_id}/dag")
async def get_cell_dag(channel: str, cell_id: str):
    """Return a cell's parents and children in the DAG."""
    conn = get_db_connection(channel)
    parents = conn.execute(
        "SELECT parent_cell_id, parent_key FROM cell_edges WHERE child_cell_id=?",
        (cell_id,),
    ).fetchall()
    children = conn.execute(
        "SELECT child_cell_id, parent_key FROM cell_edges WHERE parent_cell_id=?",
        (cell_id,),
    ).fetchall()
    conn.close()
    return {
        "parents": [dict(r) for r in parents],
        "children": [dict(r) for r in children],
    }
