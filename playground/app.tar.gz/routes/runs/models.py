"""Pydantic request models for run endpoints."""

from pydantic import BaseModel, Field


class RunRequest(BaseModel):
    prompt: str = ""
    generator_name: str = "default"
    input_cell_ids: list[str] = []
    params: dict = {}
    # Target cell id being promoted to Standard. When this id doesn't
    # yet exist in state.channels (e.g. it came directly from a client-
    # only Picking cell), the run endpoint creates the cell itself at
    # `insert_after_stack_id`. That preserves the Picking → Standard id
    # continuity without needing a separate createPlaceholderCell call.
    placeholder_cell_id: str | None = None
    # Where to drop the new placeholder stack if it has to be created.
    # Only consulted when placeholder_cell_id is new.
    insert_after_stack_id: str | None = None
    # Named config tag whose stored prompt/values overlay this run's
    # manifest-default `.set_yaml` seeds. None and "default" are no-op
    # safe for ANY generator (they resolve to the manifest's default
    # tag, or to pure field defaults when no config_tags exist); only
    # an unknown non-default tag is a 400.
    config_tag: str | None = None
    # Optional {path: content} overrides for the generator's manifest-
    # declared draft_files. Used when the picker modal renders those
    # files inline and wants the user's edits to flow through on Run.
    # Paths map 1-to-1 onto `.colreserved/config/files/<path>`;
    # prompt.md is routed to `.colreserved/prompt.md`. `req.prompt`
    # still takes precedence for the prompt slot when non-empty so the
    # modal's top-level prompt textarea wins over a stale
    # initial_files['prompt.md'].
    initial_files: dict[str, str] | None = None
    # Which invocation mode the user picked when invoking this generator.
    # One of "modify" | "create", validated against the manifest's ``type``
    # array. If absent, the host falls back to ``type[0]``. Surfaces in the
    # generator as ``gen.invocation_type``.
    invocation_type: str | None = None
    # Composition chain depth. 0 for user-initiated runs; host-initiated
    # runs (the start_modify_run handoff) pass the parent run's depth + 1
    # so generator→generator chains hit the same recursion cap as
    # gen.spawn (see process_manager.sub_runs._MAX_CALL_DEPTH). Raising
    # it only shortens the chain budget, so exposing the field over HTTP
    # is harmless; negative values are rejected.
    call_depth: int = Field(0, ge=0)


class RendererActionRequest(BaseModel):
    action_id: str


class SettingsContinueRequest(BaseModel):
    settings_content: str
    settings_filename: str


class KeyContinueRequest(BaseModel):
    """Frontend submission for a pending ``request_key`` modal.

    Either ``value`` is provided (user typed a key, hit Save) — the
    runtime stores it via the keystore + os.environ and the generator
    receives it. Or ``cancel=True`` is sent (user dismissed) — the
    generator receives ``cancelled=True`` and raises StopSignal so
    the run stops cleanly.
    """
    key_name: str
    value: str | None = None
    cancel: bool = False
