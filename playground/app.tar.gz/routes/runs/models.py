"""Pydantic request models for run endpoints."""

from pydantic import BaseModel


class RunRequest(BaseModel):
    prompt: str = ""
    generator_name: str = "default"
    input_cell_ids: list[str] = []
    params: dict = {}
    # Target cell id being promoted to Standard. When this id doesn't
    # yet exist in state.channels (e.g. it came directly from a client-
    # only Picking cell), the run endpoint creates the cell itself at
    # `insert_after_stack_id`. That preserves the Picking → Standard id
    # continuity without needing a separate createPlaceholderCell call.
    placeholder_cell_id: str | None = None
    # Where to drop the new placeholder stack if it has to be created.
    # Only consulted when placeholder_cell_id is new.
    insert_after_stack_id: str | None = None
    # Flat settings dict produced by the generator's settings schema
    # form (see /api/generators/{name}/settings). Written to the run's
    # workspace as `.colreserved/config/settings.json` for the generator
    # to consume.
    settings: dict | None = None
    # If the run came from a Draft cell (Run button), the Draft cell id
    # whose files + pickoptions should seed .colreserved/config/.
    draft_source_cell_id: str | None = None
    # Optional {path: content} overrides for the generator's manifest-
    # declared draft_files. Used when the picker modal renders those
    # files inline and wants the user's edits to flow through on Run
    # without going via the Draft → Promote path. Paths map 1-to-1
    # onto `.colreserved/config/files/<path>`; prompt.md is routed to
    # `.colreserved/prompt.md` (same rule as manifest_draft_files).
    # `req.prompt` still takes precedence for the prompt slot when
    # non-empty so the modal's top-level prompt textarea wins over a
    # stale initial_files['prompt.md'].
    initial_files: dict[str, str] | None = None


class RendererActionRequest(BaseModel):
    action_id: str


class SettingsContinueRequest(BaseModel):
    settings_content: str
    settings_filename: str


class KeyContinueRequest(BaseModel):
    """Frontend submission for a pending ``request_key`` modal.

    Either ``value`` is provided (user typed a key, hit Save) — the
    runtime stores it via the keystore + os.environ and the generator
    receives it. Or ``cancel=True`` is sent (user dismissed) — the
    generator receives ``cancelled=True`` and raises StopSignal so
    the run stops cleanly.
    """
    key_name: str
    value: str | None = None
    cancel: bool = False
