"""Read-only run lookup endpoints + per-run event stream."""

import asyncio
import json

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

from database import get_db_connection

from .helpers import _find_generator_dir, _read_manifest
from .registry import active_managers

router = APIRouter()


@router.get("/api/channels/{channel}/runs")
async def list_runs(channel: str, limit: int = 100):
    """List the most recent runs for a channel."""
    conn = get_db_connection(channel)
    rows = conn.execute(
        "SELECT id, prompt, status, created_at FROM runs "
        "ORDER BY created_at DESC LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@router.get("/api/channels/{channel}/runs/active")
async def list_active_runs(channel: str):
    """List currently-running runs on this channel with the metadata the
    frontend needs to reattach (open a replay SSE, wire live mode).

    Declared before the ``/runs/{run_id}`` route so ``active`` isn't captured
    as a run_id path parameter.
    """
    result = []
    for run_id, manager in active_managers.items():
        if getattr(manager, "channel", None) != channel:
            continue
        gen_dir = _find_generator_dir(manager.generator_name)
        manifest = _read_manifest(gen_dir) if gen_dir else {}
        result.append({
            "run_id": run_id,
            "placeholder_cell_id": manager.placeholder_cell_id or "",
            "generator_name": manager.generator_name,
            # Mirror routes/runs/create.py: chat:true implies live_files
            # unless the manifest opts back out explicitly. Reattach
            # paths must agree with the dispatch path or the frontend
            # will see a different capability set on reconnect than at
            # run start.
            "live_chat_mode": "locked_history" if bool(manifest.get("chat", False)) else "none",
            "live_files_mode": (
                manifest.get("live_files_mode")
                if manifest.get("live_files_mode") is not None
                else ("live_files" if bool(manifest.get("chat", False)) else "none")
            ),
        })
    return result


@router.get("/api/channels/{channel}/runs/{run_id}")
async def get_run(channel: str, run_id: str):
    """Return a run record plus its committed DAG cells."""
    conn = get_db_connection(channel)
    run_row = conn.execute("SELECT * FROM runs WHERE id=?", (run_id,)).fetchone()
    if not run_row:
        conn.close()
        raise HTTPException(404, "Run not found")
    cells = conn.execute(
        "SELECT id, generator_name, generator_cell_id, sequence_num, created_at "
        "FROM cells WHERE run_id=? AND deleted_at IS NULL "
        "ORDER BY sequence_num",
        (run_id,),
    ).fetchall()
    conn.close()
    return {"run": dict(run_row), "cells": [dict(c) for c in cells]}


@router.get("/api/channels/{channel}/runs/{run_id}/events_since")
async def fetch_run_events_since(channel: str, run_id: str, since_id: int = 0):
    """One-shot backfill of a run's persisted events.

    Replaces the long-lived per-run SSE stream for live delivery: live
    events now flow through the per-channel state SSE as ``run_event``
    messages (see process_manager._broadcast_run_events). This endpoint
    exists only to backfill history on ``attachToRun`` / reload so the
    frontend can reconstruct the log before it starts consuming live
    broadcasts.

    Also returns the run's current status so the caller can render the
    final label if the run has already terminated.
    """
    conn = get_db_connection(channel)
    try:
        rows = conn.execute(
            "SELECT id, event_type, payload, created_at "
            "FROM run_events WHERE run_id=? AND id>? ORDER BY id",
            (run_id, since_id),
        ).fetchall()
        run_row = conn.execute(
            "SELECT status FROM runs WHERE id=?", (run_id,)
        ).fetchone()
    finally:
        conn.close()

    status = run_row["status"] if run_row else None
    is_active = run_id in active_managers
    # Authoritative terminal flag — the frontend used to re-derive this
    # from !is_active && status!='running', which disagreed with the SSE
    # path's definition (status in completed/stopped/failed). Emit it
    # here so both consumers read from the same source.
    is_terminal = status in ("completed", "stopped", "failed") and not is_active
    return {
        "events": [
            {
                "id": r["id"],
                "type": r["event_type"],
                "payload": r["payload"],
                "created_at": r["created_at"],
            }
            for r in rows
        ],
        "status": status,
        "is_active": is_active,
        "is_terminal": is_terminal,
    }


@router.get("/api/channels/{channel}/runs/{run_id}/events")
async def stream_run_events(channel: str, run_id: str, since_id: int = 0):
    """
    Server-Sent Events stream for a run.  Polls the run_events table every
    100 ms and emits new rows.  Closes when the run reaches a terminal state
    and all events have been delivered.
    """
    async def event_gen():
        last_id = since_id
        conn = get_db_connection(channel)
        try:
            while True:
                rows = conn.execute(
                    "SELECT id, event_type, payload, created_at "
                    "FROM run_events WHERE run_id=? AND id>? ORDER BY id LIMIT 200",
                    (run_id, last_id),
                ).fetchall()
                run_row = conn.execute(
                    "SELECT status FROM runs WHERE id=?", (run_id,)
                ).fetchone()

                for row in rows:
                    last_id = row["id"]
                    yield (
                        "data: "
                        + json.dumps({
                            "id": row["id"],
                            "type": row["event_type"],
                            "payload": row["payload"],
                            "created_at": row["created_at"],
                        })
                        + "\n\n"
                    )

                is_terminal = run_row and run_row["status"] in (
                    "completed", "stopped", "failed"
                )
                is_active = run_id in active_managers

                if is_terminal and not rows and not is_active:
                    yield (
                        "data: "
                        + json.dumps({"type": "stream_end", "status": run_row["status"]})
                        + "\n\n"
                    )
                    break

                # Release any implicit read-transaction so concurrent
                # writers aren't blocked between polling cycles.
                conn.rollback()
                await asyncio.sleep(0.1)
        finally:
            conn.close()

    return StreamingResponse(
        event_gen(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
