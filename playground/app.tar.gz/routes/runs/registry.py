"""Async-safe registry of currently-running ProcessManagers, keyed by run_id.

Kept in its own module so every route + helper imports from a single
definition — there is exactly one global ``active_managers`` instance
process-wide.
"""

import asyncio
from contextlib import asynccontextmanager
from typing import Any


class ActiveManagersRegistry:
    """Async-safe registry of running ProcessManagers, keyed by run_id.

    Why this exists: individual dict ops (``get`` / ``pop`` /
    ``__setitem__``) are already atomic under CPython's GIL and
    asyncio's cooperative scheduler — those don't need guarding. The
    real hazard is **iterating while another coroutine mutates**: a
    ``for m in active_managers.values()`` that awaits inside the loop
    races with a concurrent ``pop`` (e.g. the SIGTERM escalator, the
    zombie reaper, a chat interrupt) and either raises
    ``RuntimeError: dictionary changed size during iteration`` or
    silently skips entries.

    This wrapper preserves the dict-like surface that existing
    callers (subscript, ``get``, ``pop``, ``in``) expect and adds
    three safety properties:

      1. ``values()`` and ``items()`` always return a snapshot list,
         never a live view — so iteration is free of concurrent-
         modification hazards.
      2. ``locked()`` exposes an ``asyncio.Lock`` for rare compound
         operations (set-if-absent, conditional pop) where the caller
         genuinely needs a critical section spanning an ``await``.

    Callers that don't await between a single get/pop/set don't need
    to do anything special — the methods pass straight through.
    """

    def __init__(self) -> None:
        self._d: dict[str, Any] = {}
        self._lock = asyncio.Lock()

    def __contains__(self, run_id: str) -> bool:
        return run_id in self._d

    def __setitem__(self, run_id: str, manager: Any) -> None:
        self._d[run_id] = manager

    def __getitem__(self, run_id: str) -> Any:
        return self._d[run_id]

    def __len__(self) -> int:
        return len(self._d)

    def get(self, run_id: str, default: Any = None) -> Any:
        return self._d.get(run_id, default)

    def pop(self, run_id: str, default: Any = None) -> Any:
        return self._d.pop(run_id, default)

    def clear(self) -> None:
        """Drop all entries. Used by main.py's shutdown hook after it
        has already SIGTERM'd everything — the dict is wiped without
        individual ``pop`` calls because nothing else should be
        running at this point."""
        self._d.clear()

    def values(self) -> list[Any]:
        # Returns a list snapshot — safe to iterate even if another
        # coroutine pops between awaits. The copy is O(n) in the
        # number of active runs (typically < 10), so cheap.
        return list(self._d.values())

    def items(self) -> list[tuple[str, Any]]:
        return list(self._d.items())

    @asynccontextmanager
    async def locked(self):
        """Acquire the registry's lock for a compound operation.
        Use only for true critical sections (set-if-absent, conditional
        pop). Bare single-step ops don't need this — the GIL plus
        cooperative scheduling already protects them."""
        async with self._lock:
            yield self._d


# The single process-wide registry — imported everywhere.
active_managers: ActiveManagersRegistry = ActiveManagersRegistry()

# Set once by the lifespan shutdown hook (main.py) just before it tears
# everything down. create_run checks it so a POST /runs racing shutdown
# can't spawn a generator after stop_all_runs has swept the registry —
# such a process (its own session, detached from the server's group)
# would survive server exit with nothing left to kill it. Deliberately
# NOT set by the in-app "Stop all" button: the server keeps serving and
# new runs stay legal there.
_shutting_down: bool = False


def mark_shutting_down(value: bool = True) -> None:
    """Flip the shutdown gate. The lifespan startup hook resets it to
    False so a process that runs several startup/shutdown cycles (tests,
    embedded servers) doesn't stay gated after the first shutdown."""
    global _shutting_down
    _shutting_down = value


def is_shutting_down() -> bool:
    return _shutting_down


def running_placeholder_cell_ids() -> set[str]:
    """Cell ids currently acting as the placeholder (running) cell of an
    active run. Side cells emitted by a run are NOT included — only the
    placeholder counts as "running" for UI/removal purposes."""
    return {
        str(m.placeholder_cell_id)
        for m in active_managers.values()
        if getattr(m, "placeholder_cell_id", None)
    }
