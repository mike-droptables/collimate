"""Shared full-stop teardown.

Stops every running generator + sandbox container, gracefully first
(SIGTERM, and let Docker-using generators run their own ``docker stop``),
then forcibly (SIGKILL) for anything that ignores the grace window.

Two callers share this single ladder so "stop everything" semantics can't
drift between them:

  * the in-app **Stop all** button  (``POST /api/system/stop_all``) — the
    server keeps running, the UI just empties of live work.
  * **server shutdown**             (``main.py`` lifespan teardown, reached
    when collimateapp's launcher SIGTERMs the server on window close).

``stop_all_runs`` blocks until every native generator has actually exited
(or been SIGKILLed) and sandbox teardown has finished, so a caller about to
let the process exit can rely on nothing being left behind, and the
endpoint can honestly report "done".
"""

import asyncio
import json
import logging
import os
import signal as sig_module

from database import get_db_connection

from .registry import active_managers

_logger = logging.getLogger("runs.teardown")


# Grace each generator gets to exit on SIGTERM before we SIGKILL it.
# Generous because a Docker-using generator (vscode_docker, claude_cli)
# spends this window calling ``docker stop`` on its own container, which
# itself waits ~10s for the container's PID 1 to exit. Matches the per-run
# /stop ladder in control.py. Override per-deployment.
DEFAULT_GRACE_SECONDS = float(
    os.environ.get("COLLIMATE_STOP_ALL_GRACE_SECONDS") or 12.0
)


def _signal_pg(pid: int, sig) -> None:
    """Signal the whole process group, falling back to the bare pid.

    Generators are spawned with ``start_new_session=True`` (manager.py),
    so each is its own process-group leader and ``killpg`` reaches every
    grandchild it forked (uv, the python child, helper procs) — none of
    which the server's own process-group signal would otherwise touch.
    """
    if os.name == "nt":
        return  # No POSIX process groups; Windows teardown is elsewhere.
    try:
        os.killpg(os.getpgid(pid), sig)
    except (ProcessLookupError, PermissionError, OSError):
        try:
            os.kill(pid, sig)
        except (ProcessLookupError, PermissionError, OSError):
            pass


def _request_cooperative_cancel(manager) -> None:
    """Wasm runs have no subprocess — cancellation is a flag the generator
    polls via ``ctx.cancelled``. Flip it and wake any modal the generator
    is parked on so its ``await`` unwinds. Mirrors the wasm branch of
    control.stop_run."""
    manager._cancelled = True
    try:
        manager.push_log("[stop-all] cancellation requested")
    except Exception:
        _logger.debug(
            "stop_all: push_log failed for run %s",
            getattr(manager, "run_id", "?"), exc_info=True,
        )
    if getattr(manager, "_pending_key_request", None) is not None:
        manager._key_request_cancelled = True
        manager._key_request_value = None
        manager._pending_key_request.set()
    if getattr(manager, "_pending_settings_update", None) is not None:
        manager._settings_update_values = {}
        manager._pending_settings_update.set()
    ct = getattr(manager, "_cleanup_task", None)
    if ct is not None and not ct.done():
        ct.cancel()


def _mark_stopped(channel: str, run_id: str) -> None:
    conn = get_db_connection(channel)
    try:
        conn.execute("UPDATE runs SET status='stopped' WHERE id=?", (run_id,))
        conn.execute(
            "INSERT INTO run_events (run_id, event_type, payload) "
            "VALUES (?, 'stop', ?)",
            (run_id, json.dumps({"stop_type": "stopped_all"})),
        )
        conn.commit()
    finally:
        conn.close()


async def stop_all_runs(grace_seconds: float = DEFAULT_GRACE_SECONDS) -> dict:
    """Stop every active run and tear down shared sandbox containers.

    Returns ``{"requested", "killed", "sandboxes"}``. Blocks until every
    native generator has exited (or been force-killed) and sandbox teardown
    has completed.
    """
    snapshot = active_managers.items()  # list snapshot — safe to iterate
    requested = len(snapshot)

    # Phase 1: signal everything at once so the per-generator Docker stops
    # run in parallel, not serially within the grace window.
    natives = []  # (run_id, manager, pid)
    for run_id, manager in snapshot:
        proc = getattr(manager, "process", None)
        if proc is not None and proc.returncode is None:
            _signal_pg(proc.pid, sig_module.SIGTERM)
            natives.append((run_id, manager, proc.pid))
        elif proc is None:
            _request_cooperative_cancel(manager)  # wasm cooperative run

    # Phase 2: mark each run stopped in its DB and tell the UI, so cells
    # flip out of "running" immediately rather than only once the process
    # finally dies. Best-effort and off the loop.
    for run_id, manager in snapshot:
        channel = getattr(manager, "channel", None)
        if channel:
            try:
                await asyncio.to_thread(_mark_stopped, channel, run_id)
            except Exception:
                _logger.warning(
                    "stop_all: failed to mark run %s stopped in channel %s",
                    run_id, channel, exc_info=True,
                )
        try:
            manager._broadcast_run_status("stopped")
        except Exception:
            _logger.debug(
                "stop_all: run_status broadcast failed for run %s",
                run_id, exc_info=True,
            )

    # Phase 3: give the grace window for graceful exit; early-out when all
    # native processes have gone.
    loop = asyncio.get_event_loop()
    deadline = loop.time() + grace_seconds
    while natives and loop.time() < deadline:
        if all(m.process.returncode is not None for _, m, _ in natives):
            break
        await asyncio.sleep(0.2)

    # Phase 4: SIGKILL stragglers and release their IPC sockets (on a clean
    # exit the manager's own teardown closes these; on SIGKILL it never
    # runs, so do it here to free the port + fd immediately).
    killed = 0
    for run_id, manager, pid in natives:
        if manager.process.returncode is None:
            _signal_pg(pid, sig_module.SIGKILL)
            killed += 1
        srv = getattr(manager, "_ipc_server", None)
        if srv is not None:
            try:
                srv.close()
            except Exception:
                _logger.debug(
                    "stop_all: IPC server close failed for run %s (already closed?)",
                    run_id, exc_info=True,
                )

    # Phase 5: retire shared sandbox containers (docker stop/rm) — these are
    # shared across runs rather than owned by one generator, so nothing
    # above reaches them.
    sandboxes = 0
    try:
        from sandbox import shutdown_all, _shared_containers
        sandboxes = len(_shared_containers)
        await shutdown_all()
    except Exception:
        _logger.warning(
            "stop_all: sandbox teardown failed; containers may be left running",
            exc_info=True,
        )

    # Registry is now empty of live work. _reap_process tolerates a missing
    # entry, so racing reapers are harmless.
    active_managers.clear()

    return {"requested": requested, "killed": killed, "sandboxes": sandboxes}
