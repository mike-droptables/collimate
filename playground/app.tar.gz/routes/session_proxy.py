"""Per-session browser origins for the live webview.

A "live" webview session runs the real target page through a native reverse
proxy (no in-browser rewriting): the daemon injects the logged-in session's
cookies, strips anti-framing headers, and serves the page so it executes
natively in the iframe. For that to work the proxied page needs a clean origin
of its own (so its relative URLs and same-origin API calls resolve back through
the proxy), so each session gets a subdomain: ``<token>.<apphost>``.

A per-session SDK daemon (see ``_cdp_shared``) serves that session's reverse
proxy on a loopback port. This module routes any request whose Host's first
label is a known session token straight to that daemon — so the whole subdomain
is one clean origin with no ``/proxy/<run>/<port>/`` prefix. Same-session cells
share the subdomain + the browser profile (shared login); different sessions get
different subdomains (isolated logins).

Locally ``*.localhost`` resolves to 127.0.0.1 for free, so no DNS setup is
needed; a hosted deployment needs wildcard DNS + the front proxy forwarding the
Host header (standard multi-tenant setup).

Discovery is a shared directory of marker files rather than an HTTP handshake,
so the daemon needn't know the host's API address. The daemon writes
``<REGISTRY_DIR>/<token>`` = ``{"port", "pid"}`` and refreshes its mtime as a
heartbeat; this module reads it and routes only while the daemon's PID is alive
and the marker is fresh, so a stopped or crashed session never routes. NOTE:
``REGISTRY_DIR`` is duplicated in the SDK daemon — keep the two in sync.
"""
from __future__ import annotations

import asyncio
import json
import os
import time
from typing import Optional

import httpx
import websockets
from starlette.types import Receive, Scope, Send

# Shared with the SDK session daemon (collimate-sdk _cdp_shared). Same-user,
# same-machine; the daemon is an ordinary (unsandboxed) Python subprocess, so a
# home-dir path is writable by it and readable here regardless of the browser's
# packaging.
REGISTRY_DIR = os.path.expanduser("~/.collimate-session-daemons")

# A marker older than this (no heartbeat) is treated as dead even if its PID
# still resolves (guards against PID reuse).
_TTL_SECONDS = 30.0

_HOP_BY_HOP = {
    "host", "content-length", "transfer-encoding", "connection", "keep-alive",
    "proxy-authenticate", "proxy-authorization", "te", "trailer", "upgrade",
}
_DROP_RESPONSE = {"content-length", "transfer-encoding", "connection", "content-encoding"}


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
            if handle:
                ctypes.windll.kernel32.CloseHandle(handle)
                return True
            return False
        except Exception:
            return True
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except OSError:
        return True
    return True


def _port_for(token: str) -> Optional[int]:
    """The loopback port of the live session daemon for ``token`` — only while
    its marker exists, its PID is alive, and its heartbeat is fresh. Cleans up a
    stale marker it finds."""
    if not token or "/" in token or "\\" in token or token in (".", ".."):
        return None
    path = os.path.join(REGISTRY_DIR, token)
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        port = int(data.get("port") or 0)
        pid = int(data.get("pid") or 0)
        fresh = (time.time() - os.path.getmtime(path)) < _TTL_SECONDS
    except (OSError, ValueError, json.JSONDecodeError):
        return None
    if port and pid and fresh and _pid_alive(pid):
        return port
    try:
        os.unlink(path)
    except OSError:
        pass
    return None


def _host_tokens(scope: Scope) -> list[str]:
    """Candidate session tokens from the Host's subdomain labels, in order.

    The session token is the label just before the app domain. A live
    cross-origin sub-resource (e.g. claude's ``a.claude.ai`` artifact sandbox)
    is served on a *frame* subdomain that belongs to the same session daemon, in
    one of two shapes: ``<extra>.<token>.<app>`` (a subdomain of the primary) or
    ``<token>--<encoded-origin>.<app>``. So try each subdomain label (and the
    part before any ``--``); the first with a live marker wins, and the daemon
    reconstructs the real origin from the forwarded Host. Empty for bare hosts."""
    for key, value in scope.get("headers") or []:
        if key == b"host":
            host = value.decode("latin-1").split(":")[0]
            labels = host.split(".")
            if len(labels) < 2:
                return []
            out: list[str] = []
            for label in labels[:-1]:
                base = label.split("--", 1)[0]
                if base and base not in out:
                    out.append(base)
            return out
    return []


async def _read_body(receive: Receive) -> Optional[bytes]:
    """Drain the ASGI request body; None if the client disconnected first."""
    chunks: list[bytes] = []
    while True:
        message = await receive()
        if message["type"] == "http.disconnect":
            return None
        if message["type"] == "http.request":
            chunks.append(message.get("body", b""))
            if not message.get("more_body", False):
                return b"".join(chunks)


async def _send_status(send: Send, status: int, text: bytes) -> None:
    await send({"type": "http.response.start", "status": status,
                "headers": [(b"content-type", b"text/plain; charset=utf-8")]})
    await send({"type": "http.response.body", "body": text})


async def _proxy_http(scope: Scope, receive: Receive, send: Send, port: int) -> None:
    path = scope["path"]
    query = scope["query_string"].decode("latin-1")
    target = f"http://127.0.0.1:{port}{path}" + (f"?{query}" if query else "")
    orig_host = ""
    for k, v in scope.get("headers") or []:
        if k == b"host":
            orig_host = v.decode("latin-1")
            break
    headers = [(k.decode("latin-1"), v.decode("latin-1"))
               for k, v in scope["headers"] if k.decode("latin-1").lower() not in _HOP_BY_HOP]
    # Identity end to end — the daemon already serves identity bodies, and
    # aiter_bytes() decodes anything else, so we don't carry a stale encoding.
    headers.append(("accept-encoding", "identity"))
    # The daemon's native reverse proxy serves the real page on THIS subdomain,
    # so it needs to know its own public origin to rewrite the target site's
    # self-referential URLs onto the subdomain and stamp the nav bridge. The Host
    # header is hop-by-hop (dropped above), so pass it on explicitly.
    if orig_host:
        headers.append(("x-forwarded-host", orig_host))
    headers.append(("x-forwarded-proto", "https" if scope.get("scheme") == "https" else "http"))

    body = await _read_body(receive)
    if body is None:
        return

    client = httpx.AsyncClient(
        follow_redirects=False,
        timeout=httpx.Timeout(connect=30.0, read=None, write=30.0, pool=30.0),
    )
    try:
        request = client.build_request(scope["method"], target, headers=headers, content=body)
        upstream = await client.send(request, stream=True)
    except Exception:
        await client.aclose()
        await _send_status(send, 502, b"session daemon unreachable")
        return

    resp_headers = [(k.encode("latin-1"), v.encode("latin-1"))
                    for k, v in upstream.headers.items() if k.lower() not in _DROP_RESPONSE]
    await send({"type": "http.response.start", "status": upstream.status_code,
                "headers": resp_headers})
    try:
        async for chunk in upstream.aiter_bytes():
            await send({"type": "http.response.body", "body": chunk, "more_body": True})
    except Exception:
        pass
    finally:
        await upstream.aclose()
        await client.aclose()
    await send({"type": "http.response.body", "body": b"", "more_body": False})


async def _proxy_ws(scope: Scope, receive: Receive, send: Send, port: int) -> None:
    connect = await receive()
    if connect["type"] != "websocket.connect":
        return
    path = scope["path"]
    query = scope["query_string"].decode("latin-1")
    target = f"ws://127.0.0.1:{port}{path}" + (f"?{query}" if query else "")
    subprotocols = list(scope.get("subprotocols") or [])
    try:
        upstream = await websockets.connect(
            target, subprotocols=subprotocols or None,
            open_timeout=10, max_size=None, ping_interval=None,
        )
    except Exception:
        await send({"type": "websocket.close", "code": 1011})
        return
    await send({"type": "websocket.accept"})

    async def _client_to_upstream() -> None:
        while True:
            message = await receive()
            if message["type"] == "websocket.disconnect":
                return
            data = message.get("bytes")
            text = message.get("text")
            if data is not None:
                await upstream.send(data)
            elif text is not None:
                await upstream.send(text)

    async def _upstream_to_client() -> None:
        async for message in upstream:
            if isinstance(message, bytes):
                await send({"type": "websocket.send", "bytes": message})
            else:
                await send({"type": "websocket.send", "text": message})

    _done, pending = await asyncio.wait(
        {asyncio.create_task(_client_to_upstream()),
         asyncio.create_task(_upstream_to_client())},
        return_when=asyncio.FIRST_COMPLETED,
    )
    for task in pending:
        task.cancel()
    try:
        await upstream.close()
    except Exception:
        pass
    try:
        await send({"type": "websocket.close"})
    except Exception:
        pass


class SessionSubdomainProxy:
    """ASGI middleware: if a request's Host subdomain is a live session token,
    proxy the whole request (HTTP or WebSocket) to that session's daemon;
    otherwise pass through to the app unchanged."""

    def __init__(self, app) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] in ("http", "websocket"):
            for token in _host_tokens(scope):
                port = _port_for(token)
                if port is not None:
                    if scope["type"] == "http":
                        await _proxy_http(scope, receive, send, port)
                    else:
                        await _proxy_ws(scope, receive, send, port)
                    return
        await self.app(scope, receive, send)
