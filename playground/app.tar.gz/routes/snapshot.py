"""Snapshot endpoint — pulls the current file tree out of a snapshot-capable
generator's container into a cell in the active channel.

Extracted from routes/runs.py to keep the run-lifecycle file focused on
run create/stop/list. The snapshot flow has its own docker interop,
Claude transcript scraper, and .colreserved serialization rules; bundling
it back with run lifecycle produced a 1,700-line god file.

The module depends on ``routes.runs.active_managers`` for the registry
of live ProcessManagers — the only cross-module coupling. Nothing else
imports back into this file."""

import asyncio
import io
import json
import os
import signal as sig_module
import tarfile

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from database import get_db_connection

router = APIRouter()


class SnapshotRequest(BaseModel):
    mode: str  # "new" | "update_and_stop"
    stack_id: str
    cell_id: str


_LANG_BY_EXT = {
    "py": "python", "js": "javascript", "ts": "typescript", "tsx": "typescript",
    "jsx": "javascript", "json": "json", "md": "markdown", "yaml": "yaml",
    "yml": "yaml", "html": "html", "css": "css", "sh": "bash", "rs": "rust",
    "go": "go", "java": "java", "rb": "ruby", "php": "php", "sql": "sql",
    "toml": "toml", "xml": "xml",
}


def _guess_language(filename: str) -> str:
    ext = os.path.splitext(filename)[1].lstrip(".").lower()
    return _LANG_BY_EXT.get(ext, "plaintext")


# Bash that finds the latest Claude transcript .jsonl in the container's
# ~/.claude and prints the most recent assistant text. The script is fed to
# `bash -c` via container.exec_run, so jq must be installed in the image.
_CLAUDE_TRANSCRIPT_BASH = r"""
latest=$(ls -t /home/coder/.claude/projects/*/*.jsonl 2>/dev/null | head -1)
if [ -n "$latest" ]; then
  tac "$latest" | while IFS= read -r line; do
    type=$(echo "$line" | jq -r '.type' 2>/dev/null)
    if [ "$type" = "assistant" ]; then
      text=$(echo "$line" | jq -r '.message.content[]? | select(.type=="text") | .text' 2>/dev/null)
      if [ -n "$text" ]; then
        echo "$text"
        break
      fi
    fi
  done
fi
"""

# Hard cap on individual file content size in a snapshot. Files above this
# bound are skipped — the cell view inlines content into the state JSON, so
# enormous files would balloon persisted state and SSE broadcasts.
_SNAPSHOT_MAX_FILE_BYTES = 1_000_000


def _pull_snapshot_from_container(container_name: str, project_dir: str):
    """Pull text files (filtered by .gitignore via git ls-files when available)
    plus the latest Claude assistant message from a running container.

    Runs synchronously — call from `asyncio.to_thread` to avoid blocking the
    event loop on the docker round trips.

    Returns a tuple `(files, summary_text)`:
      files       — list of dicts shaped like {name, language, content}
      summary_text — the latest Claude assistant message (or "" if none)
    """
    import docker

    client = docker.from_env()
    container = client.containers.get(container_name)

    # Step 1 — figure out which files to keep. If the project is a git
    # checkout, ask git directly so we honour `.gitignore`, the global
    # excludes file, and `.git/info/exclude` all at once. Otherwise we walk
    # everything and rely on the explicit `.git/` filter below.
    allowed_paths: set[str] | None = None
    git_check = container.exec_run(["test", "-d", os.path.join(project_dir, ".git")])
    if git_check.exit_code == 0:
        ls = container.exec_run(
            ["git", "-C", project_dir, "ls-files", "--cached", "--others", "--exclude-standard"]
        )
        if ls.exit_code == 0:
            raw = ls.output.decode("utf-8", errors="replace")
            allowed_paths = {line for line in raw.splitlines() if line.strip()}

    # Step 2 — pull the project tree as a tarball stream and extract in memory.
    bits, _ = container.get_archive(project_dir)
    buf = io.BytesIO()
    for chunk in bits:
        buf.write(chunk)
    buf.seek(0)

    files: list[dict] = []
    with tarfile.open(fileobj=buf, mode="r") as tar:
        for member in tar.getmembers():
            if not member.isfile():
                continue
            # docker get_archive prefixes paths with the basename of the source.
            parts = member.name.split("/", 1)
            if len(parts) < 2:
                continue
            relpath = parts[1]
            # Always drop the .git directory — even when we're not using git
            # ls-files, we don't want VCS internals in a cell snapshot.
            if relpath == ".git" or relpath.startswith(".git/"):
                continue
            if allowed_paths is not None and relpath not in allowed_paths:
                continue
            if member.size > _SNAPSHOT_MAX_FILE_BYTES:
                continue
            extracted = tar.extractfile(member)
            if extracted is None:
                continue
            data = extracted.read()
            try:
                content = data.decode("utf-8")
            except UnicodeDecodeError:
                # Binary files don't fit the inline-content cell model — skip.
                continue
            files.append({
                "name": relpath,
                "language": _guess_language(relpath),
                "content": content,
            })

    # Step 3 — pull the latest Claude assistant text via the transcript bash.
    transcript_text = ""
    try:
        result = container.exec_run(["bash", "-c", _CLAUDE_TRANSCRIPT_BASH])
        if result.exit_code == 0:
            transcript_text = result.output.decode("utf-8", errors="replace").strip()
    except Exception:
        pass  # transcript is best-effort; absence isn't an error

    return files, transcript_text


def _signal_stop_for_run(channel: str, run_id: str):
    """Inline copy of the SIGTERM-with-15s-escalation logic from stop_run.

    Used by snapshot(mode=update_and_stop) to shut down the generator after
    the snapshot has been written. We can't call `stop_run` directly because
    its body assumes it's the route handler, but we need exactly the same
    behaviour: SIGTERM the process group, escalate to SIGKILL after 15s,
    update the runs row, and write a `stop` run_event.
    """
    # Deferred import — routes.runs imports us back via the router mount
    # in main.py, so a top-level import would create a cycle at interpreter
    # start. The lookup is cheap on subsequent calls.
    from routes.runs import active_managers

    manager = active_managers.get(run_id)
    if not manager or not manager.process or manager.process.returncode is not None:
        active_managers.pop(run_id, None)
        conn = get_db_connection(channel)
        conn.execute("UPDATE runs SET status='stopped' WHERE id=?", (run_id,))
        conn.commit()
        conn.close()
        return

    pid = manager.process.pid

    def _kill_pg(sig):
        if os.name == "nt":
            manager.process.terminate()
            return
        try:
            os.killpg(os.getpgid(pid), sig)
        except (ProcessLookupError, PermissionError, OSError):
            try:
                os.kill(pid, sig)
            except (ProcessLookupError, PermissionError, OSError):
                pass

    _kill_pg(sig_module.SIGTERM)

    async def _escalate_kill():
        try:
            await asyncio.wait_for(manager.process.wait(), timeout=15.0)
        except asyncio.TimeoutError:
            _kill_pg(sig_module.SIGKILL)
        except Exception:
            pass
        finally:
            active_managers.pop(run_id, None)

    from task_utils import track_task
    track_task(_escalate_kill(), name=f"snapshot_escalate_kill:{run_id}")

    conn = get_db_connection(channel)
    conn.execute("UPDATE runs SET status='stopped' WHERE id=?", (run_id,))
    conn.execute(
        "INSERT INTO run_events (run_id, event_type, payload) VALUES (?, 'stop', ?)",
        (run_id, json.dumps({"stop_type": "gracefully_stopped"})),
    )
    conn.commit()
    conn.close()


@router.post("/api/channels/{channel}/runs/{run_id}/snapshot")
async def snapshot_run(channel: str, run_id: str, body: SnapshotRequest):
    """Pull the current file tree out of a snapshot-capable run's container,
    write it to a cell in the active channel, and (optionally) stop the run.

    The generator must have called `gen.serve_port(..., snapshot_source=...)`
    so the backend knows which container to read from.
    """
    from routes.runs import active_managers
    from state import get_active_channel, persist_state
    from models import Cell, VirtualFile

    if body.mode not in ("new", "update_and_stop"):
        raise HTTPException(400, "mode must be 'new' or 'update_and_stop'")

    manager = active_managers.get(run_id)
    if not manager:
        raise HTTPException(404, "Run not found or already finished")
    if not manager.snapshot_source:
        raise HTTPException(
            400,
            "This run does not declare a snapshot_source — only generators that "
            "pass snapshot_source to gen.serve_port() can be snapshotted.",
        )

    src = manager.snapshot_source
    container_name = src.get("container_name")
    project_dir = src.get("project_dir") or "/home/coder/project"
    if not container_name:
        raise HTTPException(500, "snapshot_source is missing container_name")

    try:
        files, transcript_text = await asyncio.to_thread(
            _pull_snapshot_from_container, container_name, project_dir
        )
    except Exception as exc:
        raise HTTPException(500, f"Snapshot failed: {exc}")

    # If a Claude transcript was found, attach it as summary.md and mark it
    # as the cell's summary_artifact so the SummaryPane shows it.
    summary_artifact: str | None = None
    if transcript_text:
        files.append({
            "name": "summary.md",
            "language": "markdown",
            "content": transcript_text,
        })
        summary_artifact = "summary.md"

    vfiles = [
        VirtualFile(name=f["name"], language=f["language"], content=f["content"])
        for f in files
    ]
    short_summary = (
        transcript_text.strip().splitlines()[0][:200]
        if transcript_text else "Workspace snapshot from VS Code"
    )

    ch = get_active_channel()
    target_stack = next(
        (s for s in ch.main_stacks + ch.nav_stacks if str(s.id) == body.stack_id),
        None,
    )
    if not target_stack:
        raise HTTPException(404, "Stack not found")

    if body.mode == "update_and_stop":
        # Replace the running cell's files entirely. The .website pointer goes
        # away — once we shut down, the iframe is dead anyway, and the user
        # explicitly chose to convert the cell into a pure source snapshot.
        idx = next(
            (i for i, c in enumerate(target_stack.cells) if str(c.id) == body.cell_id),
            None,
        )
        if idx is None:
            raise HTTPException(404, "Cell not found in stack")
        existing = target_stack.cells[idx]
        target_stack.cells[idx] = Cell(
            id=existing.id,
            name="VS Code Snapshot",
            summary=short_summary,
            files=vfiles,
            summary_artifact=summary_artifact,
            run_id=existing.run_id,
            channel=existing.channel,
        )
    else:
        # mode == "new": apply the portal-recursion placement rule. The
        # snapshot button is on a portal cell whose stack is target_stack;
        # since target_stack's top is a portal, the rule will insert a new
        # stack right of it and place the snapshot cell there.
        from cell_placement import reserve_landing_stack
        manager = active_managers.get(run_id)
        current_target = manager.current_target_stack_id if manager else None
        landing = reserve_landing_stack(ch, body.stack_id, current_target)
        new_cell = Cell(
            name="VS Code Snapshot",
            summary=short_summary,
            files=vfiles,
            summary_artifact=summary_artifact,
            run_id=run_id,
            channel=channel,
        )
        landing.cells.insert(0, new_cell)
        if manager is not None:
            manager.current_target_stack_id = str(landing.id)

    persist_state()

    if body.mode == "update_and_stop":
        _signal_stop_for_run(channel, run_id)

    return ch
