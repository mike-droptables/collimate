import asyncio
import io
import json
import os
import tarfile
from datetime import datetime
from uuid import UUID, uuid4
from fastapi import APIRouter, HTTPException, UploadFile, File, Body
from fastapi.responses import Response
from models import Channel, Stack, Cell, VirtualFile, DivergenceRequest, Placement
from pydantic import BaseModel, ConfigDict
from channel_archive_policy import is_archive_exportable, is_archive_importable
from state import (
    state, get_active_channel, persist_state, channel_db_name,
    strip_large_content, validate_channel_name, channel_name_slug,
)

router = APIRouter()


# ---------------------------------------------------------------------------
# System endpoints
# ---------------------------------------------------------------------------

@router.get("/api/status")
async def status_check():
    return {"status": "ok", "time": datetime.now()}


@router.post("/api/system/stop_all")
async def stop_all() -> dict:
    """Stop every running cell + sandbox container **without** shutting the
    server (or the app window) down. Generators get a grace window to exit
    cleanly — Docker-using ones use it to ``docker stop`` their container —
    then anything still alive is force-killed. The UI is left intact and
    empty of live work. Blocks until teardown finishes, then reports it."""
    from routes.runs import stop_all_runs
    summary = await stop_all_runs()
    return {"status": "stopped", **summary}


@router.post("/api/system/shutdown")
async def shutdown_server() -> dict:
    """Fully shut the server down: broadcast a ``shutdown`` event to every
    SSE subscriber, then (in the background) stop all running cells +
    sandboxes and signal uvicorn to exit. The HTTP response returns
    immediately so the client can show a progress UI while teardown runs.

    This is the full-quit path; the in-app top-bar button is wired to
    /stop_all instead, which leaves the server running."""
    import events as _events
    _events.broadcast_all({"type": "shutdown"})
    # The actual teardown runs as a background task so this handler can
    # return a response before uvicorn starts refusing new connections.
    asyncio.create_task(_run_shutdown_sequence())
    return {"status": "shutting_down"}


async def _run_shutdown_sequence() -> None:
    """Stop all running cells + sandboxes (graceful → force) then send
    SIGINT to ourselves so uvicorn runs its lifespan teardown and exits
    cleanly. The stop ladder lives in routes/runs/teardown so this path
    and the lifespan path can't diverge."""
    import signal
    # Give the SSE broadcast + HTTP response a moment to flush before
    # uvicorn starts refusing new connections.
    await asyncio.sleep(0.3)

    try:
        from routes.runs import stop_all_runs
        await stop_all_runs()
    except Exception:
        # Best-effort: a failure to stop a manager shouldn't prevent
        # the server itself from exiting.
        pass

    # Tell uvicorn to shut down. SIGINT triggers the same lifespan
    # teardown path as Ctrl-C; uvicorn waits for in-flight requests
    # (briefly) then exits.
    os.kill(os.getpid(), signal.SIGINT)


@router.post("/api/maintenance/gc")
async def maintenance_gc(grace_seconds: int | None = None):
    """Run one CAS mark-and-sweep cycle on demand.

    Use cases: an operator wants to reclaim disk before a large import,
    or to verify the GC works without waiting for the idle trigger.
    Pass ``grace_seconds`` to override the 24h trash retention for
    testing — production use should leave it at the default.
    """
    import cas_gc
    grace = float(grace_seconds) if grace_seconds is not None else cas_gc.DEFAULT_GRACE_SECONDS
    if grace < 0:
        raise HTTPException(status_code=400, detail="grace_seconds must be >= 0")
    # Run in a thread — sweeps and unlinks can stall on slow disks and
    # we don't want to block the event loop.
    result = await asyncio.to_thread(cas_gc.run_gc, grace_seconds=grace)
    return result


@router.get("/api/maintenance/disk_usage")
async def maintenance_disk_usage():
    """Report current CAS + trash byte counts. Useful for dashboards
    or for an operator sanity-checking before triggering a GC."""
    import cas_gc
    return await asyncio.to_thread(cas_gc.disk_usage)


@router.get("/api/state")
async def get_app_state():
    # Pydantic model_dump on the event loop is CPU-bound and scales
    # with channel/cell/file count — for a busy workspace it's tens of
    # ms per call, blocking every other handler for that duration.
    # Offload so the loop stays responsive even when the frontend
    # polls /api/state at the same time generators are mutating state.
    def _dump():
        state_dict = state.model_dump(mode="json")
        return strip_large_content(state_dict)
    return await asyncio.to_thread(_dump)


class _SeedSelection(BaseModel):
    """Which seed cells a new channel should materialise. Items are loosely
    typed so one schema serves both runtimes; ``create_channel`` normalizes per
    ``IS_WASM``.

    NATIVE: per-section backup picks ``[{file, cellId, name}]`` (from the
    ``.collimatebackup`` library; ``starting`` carries .colchan picks).
    WASM: legacy releases.yaml names ``[str]`` (``starting`` unused). A field
    left None (whole body omitted) seeds the curated defaults in full."""
    generators: list | None = None
    renderers: list | None = None
    starting: list | None = None


def _normalize_seed_selection(selection: "_SeedSelection | None", is_wasm: bool) -> dict | None:
    """Coerce the request body into the shape ``seed_channel`` expects for the
    active runtime. None (body omitted) → None (seed defaults in full)."""
    if selection is None:
        return None
    if is_wasm:
        def _names(items):
            if items is None:
                return None
            out = []
            for it in items:
                if isinstance(it, str):
                    out.append(it)
                elif isinstance(it, dict) and it.get("name"):
                    out.append(it["name"])
            return out
        return {"generators": _names(selection.generators), "renderers": _names(selection.renderers)}
    # NATIVE: group the flat per-cell SeedPick[] into per-bundle refs. file +
    # cellId together are load-bearing (a cell id can recur across bundles).
    def _group(items):
        if items is None:
            return None
        by_file: dict[str, list[str]] = {}
        order: list[str] = []
        for it in items:
            if not isinstance(it, dict):
                continue
            f = it.get("file") or it.get("filename")
            cid = it.get("cellId") or it.get("cell_id")
            if not f or not cid:
                continue
            if f not in by_file:
                by_file[f] = []
                order.append(f)
            by_file[f].append(str(cid))
        return [{"filename": f, "cell_ids": by_file[f]} for f in order]
    return {
        "generators": _group(selection.generators),
        "renderers": _group(selection.renderers),
        "starting": _group(selection.starting),
    }


@router.get("/api/channels/seed_cells")
async def get_seed_cells(runtime: str | None = None):
    """List the generator + renderer seed cells the WASM channel-creation view
    offers, per kind. (Native reads the .collimatebackup library directly via
    ``GET /api/backup/list``.)"""
    from genesis import list_seed_cells
    return list_seed_cells(runtime)


@router.post("/api/channels")
async def create_channel(name: str, selection: _SeedSelection | None = Body(None)):
    ch = Channel(name=validate_channel_name(name))
    from genesis import seed_channel
    from runtime import IS_WASM
    db_name = channel_db_name(ch)
    # Refuse a name that maps to an existing channel's db slug (e.g. "Foo!" vs
    # "Foo?") — two channels sharing one DB file is a cross-channel hazard.
    # rename_channel already guards this; create must too.
    if any(channel_db_name(c) == db_name for c in state.channels):
        raise HTTPException(409, f"Another channel already maps to slug '{db_name}'")
    selected_cells = _normalize_seed_selection(selection, IS_WASM)
    seed_channel(db_name, ch, selected_cells=selected_cells)
    state.channels.append(ch)
    state.active_channel_id = ch.id
    persist_state()
    return ch


@router.post("/api/channels/{channel_id}/select")
async def select_channel(channel_id: UUID):
    ch = next((c for c in state.channels if c.id == channel_id), None)
    if not ch:
        raise HTTPException(404, "Channel not found")
    state.active_channel_id = channel_id
    persist_state()
    return {"status": "selected"}


class _PlacementBody(BaseModel):
    placement: Placement
    # When set (the log-slot toggle on a running cell), the change also
    # writes through to that cell's transient `placement` so the next
    # cell the in-flight run emits honors it immediately.
    cell_id: UUID | None = None


@router.put("/api/channels/{channel_id}/placement_default")
async def set_placement_default(channel_id: UUID, body: _PlacementBody):
    """Update the channel's placement_default, and optionally the live
    transient `placement` of one cell.

    The channel default becomes the initial placement for any
    subsequent running cell. When `cell_id` names a running cell, its
    transient `placement` is updated too — `reserve_landing_stack_for_placement`
    reads it at emit time, so the flip takes effect from the run's next
    emitted cell onward. (A stray write to an idle cell is inert: the
    field is re-seeded from the channel default at every run start and
    cleared at run end.)
    """
    ch = next((c for c in state.channels if c.id == channel_id), None)
    if not ch:
        raise HTTPException(404, "Channel not found")
    ch.placement_default = body.placement
    if body.cell_id is not None:
        cid = str(body.cell_id)
        for s in ch.main_stacks + ch.nav_stacks:
            for c in s.cells:
                if str(c.id) == cid:
                    c.placement = body.placement
                    # Every observable cell mutation must bump updated_at:
                    # the frontend reconciles broadcasts by (id, updated_at)
                    # and keeps its existing cell object on an equal
                    # timestamp — an unbumped write would never paint.
                    c.updated_at = datetime.now()
                    break
    persist_state()
    return {"placement_default": ch.placement_default.value}


def _checkpoint_and_release(slug: str) -> None:
    """Flush WAL into the main db and close the connection.

    This is mandatory before renaming or deleting a channel's SQLite files on
    Windows, where any held file handle blocks the operation. Calling
    wal_checkpoint(TRUNCATE) shrinks the -wal file to zero, and closing the
    connection releases the -shm mapping.
    """
    try:
        from database import get_db_connection
        conn = get_db_connection(slug)
        try:
            conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        finally:
            conn.close()
    except Exception:
        pass


def _safe_rename(src: str, dst: str, retries: int = 8) -> None:
    """Cross-platform os.rename that retries on PermissionError (Windows)."""
    import time
    if not os.path.exists(src):
        return
    last_exc: Exception | None = None
    for attempt in range(retries):
        try:
            os.rename(src, dst)
            return
        except PermissionError as e:
            last_exc = e
            time.sleep(0.05 * (2 ** attempt))
        except FileNotFoundError:
            return
    if last_exc:
        raise last_exc


def _safe_remove(path: str, retries: int = 8) -> None:
    """Cross-platform os.remove that retries on PermissionError (Windows)."""
    import time
    for attempt in range(retries):
        try:
            os.remove(path)
            return
        except FileNotFoundError:
            return
        except PermissionError:
            if attempt < retries - 1:
                time.sleep(0.05 * (2 ** attempt))


@router.put("/api/channels/{channel_id}/rename")
async def rename_channel(channel_id: UUID, name: str):
    ch = next((c for c in state.channels if c.id == channel_id), None)
    if not ch:
        raise HTTPException(404, "Channel not found")
    new_name = validate_channel_name(name)
    if new_name == ch.name:
        return ch

    old_slug = channel_db_name(ch)
    # Compute the slug for the new name without mutating ch yet
    tmp = Channel(name=new_name)
    new_slug = channel_db_name(tmp)

    if new_slug != old_slug:
        # Refuse if another channel already maps to that slug
        for other in state.channels:
            if other.id != ch.id and channel_db_name(other) == new_slug:
                raise HTTPException(409, f"Another channel already maps to slug '{new_slug}'")

        channels_dir = os.path.join(".collimate", "channels")
        old_db = os.path.join(channels_dir, f"{old_slug}.db")
        new_db = os.path.join(channels_dir, f"{new_slug}.db")
        if os.path.exists(new_db):
            raise HTTPException(409, f"Database file {new_slug}.db already exists on disk")

        # Flush WAL and release file handles before renaming so Windows
        # doesn't refuse the operation with PermissionError.
        _checkpoint_and_release(old_slug)

        try:
            _safe_rename(old_db, new_db)
            for suffix in ("-wal", "-shm"):
                _safe_rename(
                    os.path.join(channels_dir, f"{old_slug}.db{suffix}"),
                    os.path.join(channels_dir, f"{new_slug}.db{suffix}"),
                )
        except PermissionError as e:
            raise HTTPException(409, f"Could not rename channel db (file in use): {e}")

        # The old slug's db file no longer exists — drop its schema-init cache
        # entry so a channel later recreated under that name re-runs DDL.
        from database import forget_db
        forget_db(old_slug)

    ch.name = new_name
    persist_state()
    return ch


@router.delete("/api/channels/{channel_id}")
async def delete_channel(channel_id: UUID):
    ch = next((c for c in state.channels if c.id == channel_id), None)
    if not ch:
        raise HTTPException(404, "Channel not found")
    # On native, deleting the last channel is allowed: state falls back to zero
    # channels and the frontend shows the channel-creation view. The
    # wasm/playground demo has no create view (it keeps an auto-seeded channel),
    # so it must always retain at least one channel.
    from runtime import IS_WASM
    if IS_WASM and len(state.channels) <= 1:
        raise HTTPException(400, "Cannot delete the only remaining channel")

    slug = channel_db_name(ch)
    channels_dir = os.path.join(".collimate", "channels")
    db_path = os.path.join(channels_dir, f"{slug}.db")

    # Collect every blob hash referenced by this channel (current cells + DAG history)
    doomed_hashes: set[str] = set()
    if os.path.exists(db_path):
        from database import get_db_connection
        try:
            conn = get_db_connection(slug)
            for row in conn.execute("SELECT DISTINCT blob_hash FROM cell_files WHERE blob_hash IS NOT NULL"):
                doomed_hashes.add(row["blob_hash"])
            conn.close()
        except Exception:
            pass

    # Subtract any hash still referenced by some other channel's cell_files
    if doomed_hashes:
        from database import get_db_connection
        for other in state.channels:
            if other.id == ch.id:
                continue
            other_slug = channel_db_name(other)
            other_db = os.path.join(channels_dir, f"{other_slug}.db")
            if not os.path.exists(other_db):
                continue
            try:
                conn = get_db_connection(other_slug)
                for row in conn.execute("SELECT DISTINCT blob_hash FROM cell_files WHERE blob_hash IS NOT NULL"):
                    doomed_hashes.discard(row["blob_hash"])
                    if not doomed_hashes:
                        break
                conn.close()
            except Exception:
                pass
            if not doomed_hashes:
                break

    # Delete orphaned CAS blobs from .collimate/objects/
    objects_dir = os.path.join(".collimate", "objects")
    for h in doomed_hashes:
        if len(h) < 3:
            continue
        _safe_remove(os.path.join(objects_dir, h[:2], h[2:]))

    # Flush WAL and release any held handles before unlinking the db files
    # so Windows doesn't refuse the operation with PermissionError.
    _checkpoint_and_release(slug)

    for suffix in ("", "-wal", "-shm"):
        _safe_remove(os.path.join(channels_dir, f"{slug}.db{suffix}"))

    # Evict the schema-init cache for the unlinked db so a channel recreated
    # under the same name re-runs DDL instead of reusing a tableless file.
    from database import forget_db
    forget_db(slug)

    # Drop from in-memory state and pick a new active channel if needed.
    # When the deleted channel was the last one, active_channel_id becomes
    # None and the frontend falls back to the channel-creation view.
    state.channels = [c for c in state.channels if c.id != channel_id]
    if state.active_channel_id == channel_id:
        state.active_channel_id = state.channels[0].id if state.channels else None

    persist_state()
    return {
        "status": "deleted",
        "active_channel_id": (
            str(state.active_channel_id) if state.active_channel_id else None
        ),
    }


# ---------------------------------------------------------------------------
# Channel export / import (.colchan)
# ---------------------------------------------------------------------------

CHANNEL_FORMAT_VERSION = 1


def _serialize_cell_for_manifest(cell: Cell) -> dict:
    # pinned is the cell-card preview path; useful for the
    # cell's renderer (e.g. response.md for a gemini output), so it
    # ships in the archive.
    return {
        "id": str(cell.id),
        "name": cell.name,
        "summary": cell.summary,
        "pinned": cell.pinned,
        "files": [{"name": f.name, "language": f.language} for f in cell.files],
    }


def _running_cell_ids() -> set[str]:
    """Cell ids that currently have an active generator subprocess
    attached. Running cells are mid-flight state, not stable
    artifacts, so we skip them on export — a partial snapshot would
    ship inconsistent state to whoever imports it.

    Guarded against the manager-pool race: a subprocess that has
    already exited but whose manager hasn't been popped yet doesn't
    count as running — peek proc.poll() (non-None = exited) before
    considering the cell live.
    """
    from routes.runs import active_managers
    out: set[str] = set()
    for m in active_managers.values():
        proc = getattr(m, "proc", None)
        if proc is not None and proc.poll() is not None:
            # Subprocess has exited; manager is a zombie waiting for
            # cleanup. Not really "running" anymore.
            continue
        pcid = getattr(m, "placeholder_cell_id", None)
        if pcid:
            out.add(str(pcid))
    return out


def _stamp_imported_cells(
    channel_db_name: str,
    imported_cell_rows: list[tuple[str, str]],
) -> None:
    """Insert one cells row per imported cell so the version-history UI
    has provenance metadata to render — without these rows, the
    scrubber falls back to "unknown version" placeholders.

    Each pair is (cell_id, summary). Rows land with source_type='import',
    version_name='Imported from archive', state='Standard', and the
    cells.created_at default. INSERT OR IGNORE so a re-import never
    stomps an existing row — imports mint fresh UUIDs, but the cost is
    nothing and the footgun is real if id-minting ever changes.

    Both /api/channels/merge (in-place merge into the active channel) and
    /api/channels/import (new channel from archive) call this. Previously
    only merge populated cells rows, leaving import-into-new-channel
    cells with no DB metadata and an "unknown version" UI fallback.
    Note: the previous in-merge_channel block referenced an updated_at
    column that doesn't exist on the cells table — every merge raised
    sqlite3.OperationalError silently. The helper drops that column.
    """
    if not imported_cell_rows:
        return
    from database import get_db_connection
    conn = get_db_connection(channel_db_name)
    try:
        for cell_id, summary in imported_cell_rows:
            try:
                UUID(cell_id)
            except ValueError:
                continue
            conn.execute(
                "INSERT OR IGNORE INTO cells "
                "(id, generator_name, state, source_type, "
                "version_name, version_summary) "
                "VALUES (?, NULL, 'Standard', 'import', "
                "'Imported from archive', ?)",
                (cell_id, summary),
            )
        conn.commit()
    finally:
        conn.close()


def _serialize_stack_for_manifest(
    stack: Stack,
    include_gen_ren: bool,
    running_ids: set[str],
) -> dict | None:
    # Generator / renderer stacks are whole-stack omitted on standard
    # channel export; the user's per-channel generator/renderer content
    # is separately packaged. Per-cell filtering is delegated to the
    # shared policy module so export + import can't drift on the rules
    # (see channel_archive_policy.py).
    if not include_gen_ren and stack.stack_type in ('generator', 'renderer'):
        return None
    cells = [c for c in stack.cells if is_archive_exportable(c, running_ids)]
    if not cells:
        return None
    return {
        "id": str(stack.id),
        "name": stack.name,
        "width": stack.width,
        "stack_type": stack.stack_type,
        "cells": [_serialize_cell_for_manifest(c) for c in cells],
    }


def _pack_colchan(manifest: dict, cells: list[Cell]) -> bytes:
    """Tar.gz a colchan ``manifest`` + each cell's file contents under
    ``cells/<cell_id>/<path>``. ``cells`` are the source Cell objects whose
    ids the manifest references. Shared by the channel export, the
    single-cell save, and any other colchan writer so the on-disk layout
    can't drift."""
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        manifest_bytes = json.dumps(manifest, indent=2).encode("utf-8")
        info = tarfile.TarInfo(name="manifest.json")
        info.size = len(manifest_bytes)
        tar.addfile(info, io.BytesIO(manifest_bytes))
        for cell in cells:
            for f in cell.files:
                safe_name = f.name.lstrip("/").replace("..", "_")
                arc_path = f"cells/{cell.id}/{safe_name}"
                file_bytes = f.content.encode("utf-8")
                finfo = tarfile.TarInfo(name=arc_path)
                finfo.size = len(file_bytes)
                tar.addfile(finfo, io.BytesIO(file_bytes))
    buf.seek(0)
    return buf.getvalue()


def _build_colchan_bytes(ch: Channel, include_gen_ren: bool = False) -> bytes:
    """Serialize ``ch`` as a .colchan archive. Only main-view standard stacks
    are packaged by default; generator/renderer stacks ship separately as
    .colgen / .colrend. Shared by the HTTP export route and the backup-library
    save path."""
    running_ids = _running_cell_ids()
    main_stacks = [s for s in (_serialize_stack_for_manifest(s, include_gen_ren, running_ids) for s in ch.main_stacks) if s]
    nav_stacks = [s for s in (_serialize_stack_for_manifest(s, include_gen_ren, running_ids) for s in ch.nav_stacks) if s]
    manifest = {
        "version": CHANNEL_FORMAT_VERSION,
        "name": ch.name,
        "main_stacks": main_stacks,
        "nav_stacks": nav_stacks,
        "main_selection_id": str(ch.main_selection_id) if ch.main_selection_id else None,
        "nav_selection_id": str(ch.nav_selection_id) if ch.nav_selection_id else None,
    }
    kept_cell_ids = {c["id"] for s in main_stacks + nav_stacks for c in s["cells"]}
    cells = [
        cell
        for src_stack in ch.main_stacks + ch.nav_stacks
        for cell in src_stack.cells
        if str(cell.id) in kept_cell_ids
    ]
    return _pack_colchan(manifest, cells)


def _colchan_from_cells(name: str, cells: list[Cell]) -> bytes:
    """Wrap an explicit list of cells into a single standard-stack .colchan
    (used by the backup 'current cell' / arbitrary-cell save). Cells are taken
    verbatim — no running/draft filtering."""
    stack_id = str(uuid4())
    stack_dict = {
        "id": stack_id,
        "name": "",
        "width": 33,
        "stack_type": "standard",
        "cells": [_serialize_cell_for_manifest(c) for c in cells],
    }
    manifest = {
        "version": CHANNEL_FORMAT_VERSION,
        "name": name,
        "main_stacks": [stack_dict],
        "nav_stacks": [],
        "main_selection_id": stack_id,
        "nav_selection_id": None,
    }
    return _pack_colchan(manifest, cells)


@router.get("/api/channels/export")
async def export_channel(include_gen_ren: bool = False):
    """
    Export the active channel as a .colchan tar.gz archive. Only main-view
    standard stacks are packaged; generator/renderer stacks ship as separate
    .colgen / .colrend archives.

    Layout:
        manifest.json                        — channel name + stack/cell tree
        cells/<cell_id>/<file paths...>      — file contents
    """
    ch = get_active_channel()
    content = _build_colchan_bytes(ch, include_gen_ren)
    safe_name = "".join(c for c in ch.name.lower().replace(" ", "_") if c.isalnum() or c in "_-") or "channel"
    return Response(
        content=content,
        media_type="application/gzip",
        headers={"Content-Disposition": f"attachment; filename={safe_name}.colchan"},
    )


def _parse_colchan(content: bytes) -> tuple[dict, dict[str, bytes]]:
    """Parse a .colchan tar.gz → ``(manifest, file_blobs)``. Raises
    ``ValueError`` on any structural problem so non-HTTP callers (the backup
    library listing, which must not 500 the whole list when ONE user file is
    malformed) can catch it per-file. The HTTP routes wrap this via
    ``_read_colchan_archive`` to surface a 400."""
    buf = io.BytesIO(content)
    manifest = None
    file_blobs: dict[str, bytes] = {}
    try:
        with tarfile.open(fileobj=buf, mode="r:gz") as tar:
            for member in tar.getmembers():
                if member.name.startswith("/") or ".." in member.name:
                    raise ValueError(f"Unsafe path in archive: {member.name}")
                if not member.isfile():
                    continue
                f = tar.extractfile(member)
                if not f:
                    continue
                data = f.read()
                if member.name == "manifest.json":
                    manifest = json.loads(data.decode("utf-8"))
                else:
                    file_blobs[member.name] = data
    except tarfile.TarError:
        raise ValueError("File is not a valid .colchan archive (expected tar.gz)")
    except json.JSONDecodeError:
        raise ValueError("manifest.json is not valid JSON")

    if not manifest:
        raise ValueError("Archive missing manifest.json")
    if manifest.get("version") != CHANNEL_FORMAT_VERSION:
        raise ValueError(f"Unsupported .colchan version {manifest.get('version')}")
    return manifest, file_blobs


def _read_colchan_archive(content: bytes) -> tuple[dict, dict[str, bytes]]:
    """HTTP wrapper around ``_parse_colchan``: ValueError → HTTPException(400)."""
    try:
        return _parse_colchan(content)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/api/channels/import/inspect")
async def inspect_channel_archive(file: UploadFile = File(...)):
    """Read a .colchan archive and return its manifest without applying it.
    Used by the import preview."""
    content = await file.read()
    manifest, _ = _read_colchan_archive(content)
    return manifest


def _merge_colchan_into_channel(
    ch: Channel, content: bytes, cell_ids: set[str] | None = None,
) -> tuple[int, int]:
    """Merge a .colchan's standard main-view stacks into ``ch.main_stacks``
    with fresh ids. Never edits or removes existing content; generator /
    renderer stacks in the archive are ignored (they import via .colgen /
    .colrend). When ``cell_ids`` is given, only manifest cells whose id is in
    the set are imported (the backup 'Load' picker). Imported cells enter as
    Standard DAG roots, tagged ``source_type='import'`` in the cells table.

    Returns ``(added_stacks, added_cells)``. The caller persists state. Raises
    ``ValueError`` on a malformed archive (via ``_parse_colchan``)."""
    manifest, file_blobs = _parse_colchan(content)
    added_stacks = 0
    added_cells = 0
    # (new_cell_id, cell.summary) pairs so we can fill version_summary on the
    # DB row; having it populated makes the history-scrubber render the cell
    # without falling back to "unknown version" labels.
    imported_cell_rows: list[tuple[str, str]] = []

    for stack_dict in manifest.get("main_stacks", []):
        if stack_dict.get("stack_type") in ("generator", "renderer"):
            continue
        new_stack = Stack(
            name=stack_dict.get("name", ""),
            width=stack_dict.get("width", 33),
            stack_type=stack_dict.get("stack_type", "standard"),
        )
        for cell_dict in stack_dict.get("cells", []):
            if cell_ids is not None and str(cell_dict.get("id")) not in cell_ids:
                continue
            # Defensive: let the shared policy decide what crosses the archive
            # boundary on the way in, matching what it decided on the way out.
            if not is_archive_importable(cell_dict):
                continue
            new_cell = Cell(
                name=cell_dict.get("name", "Imported Cell"),
                summary=cell_dict.get("summary", ""),
                pinned=cell_dict.get("pinned"),
            )
            for file_meta in cell_dict.get("files", []):
                arc_key = f"cells/{cell_dict['id']}/{file_meta['name'].lstrip('/').replace('..', '_')}"
                raw = file_blobs.get(arc_key, b"")
                new_cell.files.append(VirtualFile(
                    name=file_meta["name"],
                    language=file_meta.get("language", "text"),
                    content=raw.decode("utf-8", errors="replace"),
                ))
            new_stack.cells.append(new_cell)
            imported_cell_rows.append((
                str(new_cell.id),
                (new_cell.summary or "")[:200],
            ))
        if not new_stack.cells:
            continue
        ch.main_stacks.append(new_stack)
        added_stacks += 1
        added_cells += len(new_stack.cells)

    # Stamp DAG-side provenance. get_db_connection slugs the name internally,
    # so the channel's display name resolves to the same db file. (Channel.name
    # is always set; no "starting" fallback — that would stamp a ghost channel.)
    _stamp_imported_cells(ch.name, imported_cell_rows)
    return added_stacks, added_cells


@router.post("/api/channels/merge")
async def merge_channel_archive(file: UploadFile = File(...)):
    """Merge a .colchan into the active channel: add new stacks (with fresh
    ids) to main_stacks. Never edits or removes existing content. Generator /
    renderer stacks in the archive are ignored — they must be imported via
    .colgen / .colrend.

    Imported cells enter as Standard with no parent edges — they're
    DAG roots in the destination channel. The cells table row is
    tagged ``source_type='import'`` so the version-history UI can
    show the provenance as "arrived via import" instead of "run by
    generator X" (which would be wrong — the destination channel
    never ran that generator).
    """
    content = await file.read()
    ch = get_active_channel()
    try:
        added_stacks, _ = _merge_colchan_into_channel(ch, content)
    except ValueError as e:
        raise HTTPException(400, str(e))
    persist_state()
    return {"added_stacks": added_stacks, "channel": ch}


@router.post("/api/channels/import")
async def import_channel(file: UploadFile = File(...), include_gen_ren: bool = True):
    """
    Import a .colchan archive as a new channel. Always creates a fresh channel
    with new ids; never replaces an existing one. When include_gen_ren is False,
    any generator/renderer stacks in the archive are dropped and the new
    channel is seeded with the default G/R templates instead.
    """
    content = await file.read()
    manifest, file_blobs = _read_colchan_archive(content)

    # Build a new channel with fresh ids. Sanitize rather than reject: a bad
    # archive name shouldn't block the import, but it must not produce an
    # empty-slug (un-addressable) channel — fall back to a safe default.
    base_name = manifest.get("name") or "Imported Channel"
    if not channel_name_slug(base_name):
        base_name = "Imported Channel"
    # Dedupe by db SLUG, not display name — two names that differ only in
    # stripped punctuation would otherwise collide on one DB file.
    existing_slugs = {channel_db_name(c) for c in state.channels}
    new_name = base_name
    n = 2
    while channel_name_slug(new_name) in existing_slugs:
        new_name = f"{base_name} ({n})"
        n += 1

    new_channel = Channel(name=new_name)

    # Stack/cell id remap so manifest selection ids can be translated
    stack_id_map: dict[str, UUID] = {}
    # (new_cell_id, summary) pairs to stamp as 'import' provenance in
    # the cells table once the channel DB exists. Generator/renderer
    # stack cells are excluded — those are code, not user content, and
    # the merge_channel path makes the same exclusion.
    imported_cell_rows: list[tuple[str, str]] = []

    def materialize_stack(stack_dict: dict) -> Stack | None:
        stack_type = stack_dict.get("stack_type", "standard")
        # On standard channel import, skip generator/renderer stacks —
        # they're packaged separately. (include_gen_ren is only true
        # when the caller explicitly wants to pull them in.)
        if not include_gen_ren and stack_type in ("generator", "renderer"):
            return None
        new_stack = Stack(
            name=stack_dict.get("name", ""),
            width=stack_dict.get("width", 33),
            stack_type=stack_type,
        )
        is_user_content = stack_type not in ("generator", "renderer")
        for cell_dict in stack_dict.get("cells", []):
            new_cell = Cell(
                name=cell_dict.get("name", "Imported Cell"),
                summary=cell_dict.get("summary", ""),
            )
            for file_meta in cell_dict.get("files", []):
                arc_key = f"cells/{cell_dict['id']}/{file_meta['name'].lstrip('/').replace('..', '_')}"
                raw = file_blobs.get(arc_key, b"")
                new_cell.files.append(VirtualFile(
                    name=file_meta["name"],
                    language=file_meta.get("language", "text"),
                    content=raw.decode("utf-8", errors="replace"),
                ))
            new_stack.cells.append(new_cell)
            if is_user_content:
                imported_cell_rows.append((
                    str(new_cell.id),
                    (new_cell.summary or "")[:200],
                ))
        if not new_stack.cells:
            return None
        stack_id_map[stack_dict["id"]] = new_stack.id
        return new_stack

    for s in manifest.get("main_stacks", []):
        ms = materialize_stack(s)
        if ms:
            new_channel.main_stacks.append(ms)
    for s in manifest.get("nav_stacks", []):
        ns = materialize_stack(s)
        if ns:
            new_channel.nav_stacks.append(ns)

    # Translate selection ids; fall back to first stack
    msel = manifest.get("main_selection_id")
    if msel and msel in stack_id_map:
        new_channel.main_selection_id = stack_id_map[msel]
    elif new_channel.main_stacks:
        new_channel.main_selection_id = new_channel.main_stacks[0].id

    nsel = manifest.get("nav_selection_id")
    if nsel and nsel in stack_id_map:
        new_channel.nav_selection_id = stack_id_map[nsel]

    # Seed default generators / renderers if requested. seed_channel adds a
    # Welcome stack we don't want, so call it on a throwaway channel and steal
    # just the G/R nav stacks from it.
    from genesis import seed_channel
    new_db_name = channel_db_name(new_channel)
    if not include_gen_ren:
        scratch = Channel(name=new_channel.name)
        seed_channel(new_db_name, scratch)
        for s in scratch.nav_stacks:
            if s.stack_type in ("generator", "renderer"):
                new_channel.nav_stacks.append(s)
    else:
        # Still need to create the SQLite db file for this channel
        from database import get_db_connection
        conn = get_db_connection(new_db_name)
        conn.close()

    # Stamp DAG-side provenance now that the channel DB exists. Same
    # helper as /api/channels/merge so the version-history UI renders
    # imported cells with "Imported from archive" instead of an
    # "unknown version" fallback regardless of which import path the
    # user took.
    _stamp_imported_cells(new_db_name, imported_cell_rows)

    state.channels.append(new_channel)
    state.active_channel_id = new_channel.id
    persist_state()
    return new_channel


@router.post("/api/save")
async def save_state():
    """Explicitly persist the current UI state to SQLite."""
    persist_state()
    ch = get_active_channel()
    return ch


@router.get("/api/channels/{channel}/state/stream")
async def stream_channel_state(channel: str):
    """SSE stream for real-time channel state updates (DAG commits, status changes).

    On overflow (slow client, suspended tab, etc.) the broadcaster
    enqueues an overflow sentinel; this handler emits a final
    ``{"type": "overflow"}`` event and closes the stream. The
    EventSource client auto-reconnects and SHOULD re-fetch the
    canonical state from ``/api/state`` rather than relying on the
    interrupted incremental stream — see frontend/useChannelSSE.ts.
    """
    from events import subscribe, unsubscribe, OVERFLOW_SENTINEL

    q = subscribe(channel)

    async def event_gen():
        try:
            # Send initial keepalive
            yield "data: {\"type\": \"connected\"}\n\n"
            while True:
                try:
                    event = await asyncio.wait_for(q.get(), timeout=30.0)
                except asyncio.TimeoutError:
                    # Send keepalive to prevent connection timeout
                    yield ": keepalive\n\n"
                    continue
                if event is OVERFLOW_SENTINEL:
                    # Tell the client why the stream is closing so it
                    # can refetch /api/state instead of replaying. The
                    # leading newline + retry: hint nudges the browser
                    # to reconnect quickly.
                    yield "data: {\"type\": \"overflow\"}\n\n"
                    yield "retry: 100\n\n"
                    return
                yield f"data: {json.dumps(event)}\n\n"
        except asyncio.CancelledError:
            pass
        finally:
            unsubscribe(channel, q)

    from fastapi.responses import StreamingResponse
    return StreamingResponse(
        event_gen(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


def _read_renderer_prefs_sync(db_name: str) -> dict:
    from database import get_db_connection
    conn = get_db_connection(db_name)
    try:
        row = conn.execute(
            "SELECT value FROM ui_state WHERE key='renderer_preferences'"
        ).fetchone()
        return json.loads(row["value"]) if row else {}
    finally:
        conn.close()


def _write_renderer_prefs_sync(db_name: str, prefs_json: str) -> None:
    from database import get_db_connection
    conn = get_db_connection(db_name)
    try:
        conn.execute(
            "INSERT INTO ui_state (key, value) VALUES ('renderer_preferences', ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (prefs_json,),
        )
        conn.commit()
    finally:
        conn.close()


@router.get("/api/renderer_preferences")
async def get_renderer_preferences():
    """Get renderer preferences for the active channel (extension -> renderer name)."""
    ch = get_active_channel()
    db_name = channel_db_name(ch)
    return await asyncio.to_thread(_read_renderer_prefs_sync, db_name)


@router.put("/api/renderer_preferences")
async def set_renderer_preferences(prefs: dict[str, str]):
    """Set renderer preferences for the active channel (extension -> renderer name)."""
    ch = get_active_channel()
    db_name = channel_db_name(ch)
    await asyncio.to_thread(_write_renderer_prefs_sync, db_name, json.dumps(prefs))
    return {"status": "ok"}


# --- Generator / renderer availability (file-manager "management" view) -----
# Channel-scoped per-item flags managed by the generator/renderer cards.
# Storage + flag-resolution semantics live in channel_config.py.

class EnabledPatch(BaseModel):
    """On/off patch for a per-id availability flag (generators + renderers)."""
    model_config = ConfigDict(extra="forbid")
    enabled: bool


class CellExposurePatch(BaseModel):
    """On/off patch for a source cell's "expose to generators" flag."""
    model_config = ConfigDict(extra="forbid")
    exposed: bool


@router.get("/api/generator_availability")
async def get_generator_availability():
    """Picker-visibility (on/off) flag per generator id for the active channel.
    Absent entry = visible."""
    from channel_config import read_generator_availability
    ch = get_active_channel()
    db_name = channel_db_name(ch)
    return await asyncio.to_thread(read_generator_availability, db_name)


@router.put("/api/generator_availability/{generator_id}")
async def set_generator_availability_endpoint(
    generator_id: str, patch: EnabledPatch,
):
    """Set one generator's picker-visibility flag (per-id upsert)."""
    from channel_config import set_generator_availability
    ch = get_active_channel()
    db_name = channel_db_name(ch)
    data = await asyncio.to_thread(
        set_generator_availability, db_name, generator_id, patch.enabled,
    )
    return {"id": generator_id, "enabled": data.get(generator_id, True)}


@router.get("/api/renderer_availability")
async def get_renderer_availability():
    """On/off flag per renderer id for the active channel.
    Absent entry = enabled."""
    from channel_config import read_renderer_availability
    ch = get_active_channel()
    db_name = channel_db_name(ch)
    return await asyncio.to_thread(read_renderer_availability, db_name)


@router.put("/api/renderer_availability/{renderer_id}")
async def set_renderer_availability_endpoint(
    renderer_id: str, patch: EnabledPatch,
):
    """Set one renderer's enabled flag (per-id upsert)."""
    from channel_config import set_renderer_availability
    ch = get_active_channel()
    db_name = channel_db_name(ch)
    data = await asyncio.to_thread(
        set_renderer_availability, db_name, renderer_id, patch.enabled,
    )
    return {"id": renderer_id, "enabled": data.get(renderer_id, True)}


@router.get("/api/cell_exposure")
async def get_cell_exposure():
    """"Expose to generators" flag per source-cell id for the active channel.
    Absent entry = exposed."""
    from channel_config import read_cell_exposure
    ch = get_active_channel()
    db_name = channel_db_name(ch)
    return await asyncio.to_thread(read_cell_exposure, db_name)


@router.put("/api/cell_exposure/{cell_id}")
async def set_cell_exposure_endpoint(cell_id: str, patch: CellExposurePatch):
    """Set one source cell's expose-to-generators flag (per-id upsert). Exposing
    a cell lets other generators run its generators and read + edit its code."""
    from channel_config import set_cell_exposure
    ch = get_active_channel()
    db_name = channel_db_name(ch)
    data = await asyncio.to_thread(
        set_cell_exposure, db_name, cell_id, patch.exposed,
    )
    return {"cell_id": cell_id, "exposed": data.get(cell_id, True)}


@router.post("/api/main/create_stack")
async def create_main_stack():
    ch = get_active_channel()
    s = Stack(name="", width=33)
    c = Cell(name="New Cell", summary="Enter a summary...")
    s.cells.append(c)
    ch.main_stacks.append(s)
    ch.main_selection_id = s.id
    persist_state()
    return ch


@router.post("/api/spark/divergence/{source_stack_id}")
async def create_divergence(source_stack_id: UUID, req: DivergenceRequest):
    ch = get_active_channel()
    await asyncio.sleep(0.1)

    result_stack = Stack(name=f"Divergence: {req.prompt[:10]}...")
    import json
    cell_a = Cell(name="Draft A: Quick Fix", summary="A pragmatic hotfix with technical debt.")
    msgs = [
        {"role": "system", "content": "Mode: Pragmata-8B [Optimized for Speed]"},
        {"role": "assistant", "content": "## The Quick Fix\n\nI've patched the specific error."}
    ]
    cell_a.files.append(VirtualFile(
        name=".colreserved/.collimate_messages.json",
        language="json",
        content=json.dumps(msgs, indent=2)
    ))
    cell_a.files.append(VirtualFile(name="patch.ts", language="typescript", content="// HOTFIX\n"))
    result_stack.cells = [cell_a]

    try:
        src_idx = next(i for i, s in enumerate(ch.main_stacks) if s.id == source_stack_id)
        insert_idx = src_idx + 1
        ch.main_stacks.insert(insert_idx, result_stack)
        ch.main_selection_id = result_stack.id
    except StopIteration:
        ch.main_stacks.append(result_stack)
        ch.main_selection_id = result_stack.id

    persist_state()
    return ch


@router.get("/api/env/keys")
async def get_env_keys():
    import os
    return list(os.environ.keys())

@router.get("/api/env/check/{key}")
async def check_env_key(key: str):
    import os
    return {"value": os.environ.get(key)}


def _collect_generator_keys_in_use() -> list[str]:
    """Aggregate every key referenced by the active channel's
    generators by static-analyzing each generator entrypoint for
    ``gen.get_key("…")`` calls with literal-string args.

    Replaces the old manifest+schema-derived list. Now that
    ``gen.get_key`` is the single way generator code reads a secret,
    walking the source is the most accurate signal — and it stays in
    sync automatically without authors maintaining a separate
    declaration.
    """
    import key_scan
    from routes.generation import _get_generator_cells
    names: set[str] = set()
    if not state.active_channel_id:
        return []
    ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
    if ch is None:
        return []
    for source_cell in _get_generator_cells(ch):
        for mf in source_cell.files:
            if not mf.name.endswith(".py"):
                continue
            names.update(key_scan.scan_keys_used_in_source(mf.content or ""))
    return sorted(names)


@router.get("/api/env/keys_status")
async def env_keys_status():
    """Report the user's stored keys + the keys this channel's
    generators would ask for.

    The two lists serve different purposes:

      * ``stored`` — every key the user has set, channel-agnostic.
        The keystore is per-OS-user, so this list spans everything
        the user has ever stored across all their channels.
      * ``in_use_active_channel`` — keys this channel's generators
        will request via ``gen.get_key``. Derived by static AST scan;
        dynamic key names won't appear here but will still trigger
        the modal at runtime.

    The Settings → Keys tab renders both lists side-by-side. Note that
    a key may legitimately appear in only one list (a stored key not
    used by this channel; an in-use key the user hasn't filled yet).
    """
    in_use = _collect_generator_keys_in_use()
    try:
        from keystore import list_names
        stored = sorted(list_names())
    except Exception:
        stored = []
    return {
        "stored": stored,
        "in_use_active_channel": in_use,
    }

@router.get("/api/env/status")
async def env_status():
    """Report the runtime environment + persistent key-store state.

    ``runtime`` is ``"wasm"`` in the pyodide playground and ``"native"``
    on the desktop server; the frontend uses it to hide features that
    don't work in pyodide (e.g. generator execution).

    ``persistent`` is True whenever ``keystore.set_key`` will survive
    restart: OS keychain on native, IDBFS-backed sqlite on wasm.
    """
    from runtime import IS_WASM
    from keystore import available, list_names
    return {
        "persistent": available(),
        "stored_names": list_names(),
        "runtime": "wasm" if IS_WASM else "native",
        "playground": IS_WASM,
    }


# ---------------------------------------------------------------------------
# User settings (.colsettings.json) — user-chosen defaults for new channels
# ---------------------------------------------------------------------------

@router.get("/api/user_settings")
async def get_user_settings():
    """Return the current user_settings document (or an empty default)."""
    from user_settings import load_settings
    return load_settings()


@router.put("/api/user_settings")
async def put_user_settings(settings: dict):
    """Upsert the user_settings document. Returns the normalized form stored."""
    from user_settings import save_settings
    try:
        return save_settings(settings)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.get("/api/user_settings/export")
async def export_user_settings():
    """Download the current user_settings as a `.colsettings.json` attachment."""
    from user_settings import load_settings
    body = json.dumps(load_settings(), indent=2).encode("utf-8")
    return Response(
        content=body,
        media_type="application/json",
        headers={"Content-Disposition": "attachment; filename=user.colsettings.json"},
    )


@router.post("/api/user_settings/import")
async def import_user_settings(file: UploadFile = File(...)):
    """Upload a `.colsettings.json` and replace current settings with it."""
    from user_settings import save_settings
    try:
        payload = json.loads(await file.read())
    except json.JSONDecodeError as e:
        raise HTTPException(400, f"Not valid JSON: {e}")
    try:
        return save_settings(payload)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.get("/api/user_settings/bundles")
async def list_user_settings_bundles(runtime: str = "native"):
    """List bundle names shipped with the SDK for the active runtime. The UI
    uses these to populate the 'Use bundled' picker in the Defaults tab."""
    if runtime not in ("native", "wasm"):
        raise HTTPException(400, "runtime must be 'native' or 'wasm'")
    from user_settings import list_available_bundles
    return list_available_bundles(runtime)


@router.post("/api/user_settings/encode_upload")
async def encode_user_settings_upload(file: UploadFile = File(...)):
    """Accept a .colgen / .colrend / .colchan file and return a
    ``{source, sha256, name}`` entry the UI can drop into its defaults list
    without the frontend having to know how to base64-encode."""
    content = await file.read()
    from user_settings import encode_data_uri, sha256_hex
    ext = (file.filename or "").rsplit(".", 1)[-1].lower()
    mime = {
        "colgen": "application/gzip",
        "colrend": "application/gzip",
        "colchan": "application/gzip",
    }.get(ext, "application/octet-stream")
    base = (file.filename or "uploaded").rsplit(".", 1)[0]
    return {
        "name": base,
        "source": encode_data_uri(content, mime),
        "sha256": sha256_hex(content),
    }

from pydantic import BaseModel
class EnvSetRequest(BaseModel):
    value: str

@router.post("/api/env/set/{key}")
async def set_env_key(key: str, req: EnvSetRequest):
    import os
    from keystore import set_key, available
    os.environ[key] = req.value
    persisted = set_key(key, req.value) if available() else False
    return {"status": "ok", "persisted": persisted}

@router.delete("/api/env/delete/{key}")
async def delete_env_key(key: str):
    import os
    from keystore import delete_key
    os.environ.pop(key, None)
    delete_key(key)
    return {"status": "ok"}
