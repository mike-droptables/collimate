"""Live interactive terminal bridge.

Exposes a generic WebSocket endpoint that bridges a browser-side xterm.js
instance to a PTY running `docker exec -ti <container> <command>`. Any
generator can attach any command to the `.terminal` renderer by calling
`gen.start_terminal(container_id, command)`, which posts a session into
this module's in-memory registry via the IPC ops handled in
`process_manager.py`. The `.terminal` file the generator writes carries
the `{session_id, ws_path, token}` pointer the renderer opens.

Design:
  - One PTY per session. Host-allocated via `pty.openpty()`, then
    `docker exec -ti` is launched with the slave fd wired to stdio. This
    gives us a real TTY inside the container without needing aiodocker
    or docker-py socket plumbing.
  - WebSocket protocol:
      * client → server: binary frames carry stdin bytes.
      * client → server: text frames are control JSON, e.g.
        {"t":"resize","cols":N,"rows":M}.
      * server → client: binary frames carry stdout+stderr bytes (the
        PTY merges them).
  - Auth: a 128-bit random token is generated at session creation time,
    stored in the registry, and required on the WS query string. Sessions
    are single-attach — after the first successful upgrade the token is
    consumed (still stored so reconnect works, but only one socket may
    be live at a time).
"""

from __future__ import annotations

import asyncio
import errno
import json
import os
import secrets
import struct
import uuid

from runtime import IS_WASM

# PTY plumbing is unix-only — pyodide has no fcntl/pty/termios. The browser
# playground never actually reaches the WebSocket path (no docker, no
# generators that call start_terminal), so leaving these unbound under wasm
# is safe: register_session() still works for any caller that wants it,
# and the PTY helpers below would only fail if they were somehow invoked.
if not IS_WASM:
    import fcntl
    import pty
    import termios
from dataclasses import dataclass
from typing import Optional

from fastapi import APIRouter, Query, WebSocket, WebSocketDisconnect
from starlette.websockets import WebSocketState

router = APIRouter()


@dataclass
class TerminalSession:
    session_id: str
    cell_id: str
    container_id: str
    command: list[str]
    cwd: Optional[str]
    env: dict
    token: str
    proc: Optional[asyncio.subprocess.Process] = None
    master_fd: Optional[int] = None
    # True from the moment a WS upgrade is accepted. Prevents a second
    # concurrent client from attaching to the same session even before
    # the PTY has actually spawned.
    attached: bool = False


_sessions: dict[str, TerminalSession] = {}


# ---------------------------------------------------------------------------
# Registry API — called from process_manager.py via IPC ops
# ---------------------------------------------------------------------------

def register_session(
    cell_id: str,
    container_id: str,
    command: list[str],
    cwd: Optional[str] = None,
    env: Optional[dict] = None,
) -> dict:
    """Allocate a session id + auth token and stash the spawn parameters.

    Returns a dict suitable for writing straight into the generator's
    `.terminal` file plus the token the IPC ack passes back to the SDK.
    """
    if not container_id:
        raise ValueError("container_id is required")
    if not command:
        raise ValueError("command must be a non-empty list")

    session_id = f"tmnl_{uuid.uuid4().hex[:16]}"
    token = secrets.token_urlsafe(24)
    session = TerminalSession(
        session_id=session_id,
        cell_id=cell_id,
        container_id=container_id,
        command=list(command),
        cwd=cwd,
        env=dict(env or {}),
        token=token,
    )
    _sessions[session_id] = session
    return {
        "session_id": session_id,
        "ws_path": f"/api/terminals/{session_id}",
        "token": token,
    }


def unregister_session(session_id: str) -> None:
    """Drop a session from the registry and tear down its PTY if live."""
    session = _sessions.pop(session_id, None)
    if session is None:
        return
    _kill_session(session)


def unregister_sessions_for_cell(cell_id: str) -> None:
    """Drop every session attached to the given cell. Called from the
    run-cleanup path in process_manager so stale sessions don't leak when
    a generator exits without calling stop_terminal."""
    for sid, sess in list(_sessions.items()):
        if sess.cell_id == cell_id:
            unregister_session(sid)


def _kill_session(session: TerminalSession) -> None:
    if session.proc is not None:
        try:
            session.proc.terminate()
        except (ProcessLookupError, OSError):
            pass
    if session.master_fd is not None:
        try:
            os.close(session.master_fd)
        except OSError:
            pass
    session.proc = None
    session.master_fd = None
    session.attached = False


# ---------------------------------------------------------------------------
# PTY helpers
# ---------------------------------------------------------------------------

def _set_winsize(fd: int, rows: int, cols: int) -> None:
    try:
        fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
    except OSError:
        pass


async def _spawn_pty(session: TerminalSession) -> None:
    """Fork off `docker exec -ti <container> <command>` wired to a fresh
    host PTY. Stores master_fd + proc on the session for the pump loops.
    """
    master_fd, slave_fd = pty.openpty()
    _set_winsize(master_fd, 24, 80)

    argv = ["docker", "exec", "-i", "-t"]
    if session.cwd:
        argv += ["-w", session.cwd]
    for k, v in session.env.items():
        argv += ["-e", f"{k}={v}"]
    argv += [session.container_id, *session.command]

    try:
        proc = await asyncio.create_subprocess_exec(
            *argv,
            stdin=slave_fd,
            stdout=slave_fd,
            stderr=slave_fd,
            start_new_session=True,
        )
    finally:
        try:
            os.close(slave_fd)
        except OSError:
            pass

    session.master_fd = master_fd
    session.proc = proc


# ---------------------------------------------------------------------------
# WebSocket route
# ---------------------------------------------------------------------------

@router.websocket("/api/terminals/{session_id}")
async def terminal_ws(
    websocket: WebSocket,
    session_id: str,
    token: str = Query(default=""),
):
    session = _sessions.get(session_id)
    if session is None:
        await websocket.close(code=4404, reason="no such session")
        return
    if not token or not secrets.compare_digest(token, session.token):
        await websocket.close(code=4401, reason="bad token")
        return
    if session.attached:
        await websocket.close(code=4409, reason="session already attached")
        return

    await websocket.accept()
    session.attached = True

    try:
        await _spawn_pty(session)
    except FileNotFoundError:
        await websocket.send_text(json.dumps({
            "t": "error",
            "msg": "`docker` not found on PATH on the host",
        }))
        await websocket.close()
        session.attached = False
        return
    except Exception as exc:
        await websocket.send_text(json.dumps({"t": "error", "msg": str(exc)}))
        await websocket.close()
        session.attached = False
        return

    assert session.master_fd is not None
    assert session.proc is not None
    master_fd = session.master_fd
    proc = session.proc

    loop = asyncio.get_running_loop()

    # Bounded queue bridges the sync fd reader to the async WS sender.
    # When the client stalls we pause the reader rather than letting the
    # queue grow without limit — otherwise a slow browser could OOM the
    # host on a chatty program.
    ws_send_queue: asyncio.Queue[bytes | None] = asyncio.Queue(maxsize=256)
    reader_paused = False

    def _stop_reader() -> None:
        try:
            loop.remove_reader(master_fd)
        except (ValueError, OSError):
            pass

    def _on_readable() -> None:
        nonlocal reader_paused
        if ws_send_queue.qsize() >= ws_send_queue.maxsize - 1:
            _stop_reader()
            reader_paused = True
            return
        try:
            chunk = os.read(master_fd, 65536)
        except OSError as exc:
            if exc.errno in (errno.EIO, errno.EBADF):
                _stop_reader()
                ws_send_queue.put_nowait(None)
            return
        if not chunk:
            _stop_reader()
            ws_send_queue.put_nowait(None)
            return
        ws_send_queue.put_nowait(chunk)

    try:
        loop.add_reader(master_fd, _on_readable)
    except Exception as exc:
        await websocket.send_text(json.dumps({"t": "error", "msg": f"add_reader failed: {exc}"}))
        await websocket.close()
        _kill_session(session)
        return

    async def _pump_to_ws() -> None:
        nonlocal reader_paused
        while True:
            item = await ws_send_queue.get()
            if item is None:
                return
            try:
                await websocket.send_bytes(item)
            except Exception:
                return
            if reader_paused and ws_send_queue.qsize() < ws_send_queue.maxsize // 2:
                reader_paused = False
                try:
                    loop.add_reader(master_fd, _on_readable)
                except Exception:
                    return

    # --- writer: WS → PTY ---
    async def _pump_from_ws() -> None:
        while True:
            try:
                msg = await websocket.receive()
            except WebSocketDisconnect:
                return
            except Exception:
                return
            if msg.get("type") == "websocket.disconnect":
                return
            text = msg.get("text")
            binary = msg.get("bytes")
            if text is not None:
                try:
                    payload = json.loads(text)
                except json.JSONDecodeError:
                    continue
                if payload.get("t") == "resize":
                    rows = int(payload.get("rows") or 24)
                    cols = int(payload.get("cols") or 80)
                    _set_winsize(master_fd, rows, cols)
            elif binary is not None:
                try:
                    os.write(master_fd, binary)
                except OSError:
                    return

    to_ws_task = asyncio.create_task(_pump_to_ws())
    from_ws_task = asyncio.create_task(_pump_from_ws())

    try:
        done, pending = await asyncio.wait(
            {to_ws_task, from_ws_task, asyncio.create_task(proc.wait())},
            return_when=asyncio.FIRST_COMPLETED,
        )
        for t in pending:
            t.cancel()
    finally:
        try:
            loop.remove_reader(master_fd)
        except (ValueError, OSError):
            pass
        _kill_session(session)
        if websocket.client_state != WebSocketState.DISCONNECTED:
            try:
                await websocket.close()
            except Exception:
                pass
