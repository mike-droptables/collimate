from datetime import datetime
from typing import Optional
from uuid import UUID
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from models import Cell, Stack, VirtualFile, Message
from state import get_active_channel, persist_state

router = APIRouter()


class InsertBlankCellRequest(BaseModel):
    # Client-minted id (the Picking cell's UUID) so the id flows
    # through Picking → Standard cleanly. Generated if omitted.
    id: str | None = None
    name: str = "New cell"
    summary: str = ""


@router.post("/api/windows/{stack_id}/insert_blank_cell")
async def insert_blank_cell(stack_id: UUID, body: InsertBlankCellRequest):
    """Create a blank Standard cell in its own new stack, placed right
    of the given anchor stack. Used by the "Create blank cell" picker
    affordance (0-input mode). No generator, no Draft state — just an
    empty canvas the user can author into."""
    import uuid as _uuid
    ch = get_active_channel()
    try:
        src_idx = next(i for i, s in enumerate(ch.main_stacks) if s.id == stack_id)
    except StopIteration:
        raise HTTPException(404, "Stack not found")
    try:
        cell_id = _uuid.UUID(body.id) if body.id else _uuid.uuid4()
    except ValueError:
        raise HTTPException(400, "id must be a valid UUID")
    new_cell = Cell(id=cell_id, name=body.name, summary=body.summary, files=[])
    new_stack = Stack(name="", cells=[new_cell])
    ch.main_stacks.insert(src_idx + 1, new_stack)
    ch.main_selection_id = new_stack.id
    persist_state()
    return ch


# --- MAIN WINDOW OPS ---

@router.post("/api/windows/{stack_id}/remove")
async def remove_stack(stack_id: UUID):
    """Remove a stack from the canvas. Cells stay in the DB — recoverable
    from the history view. Pending edits are checkpointed first so no
    user work is lost. Generator/renderer stacks are refused.
    """
    from state import channel_db_name
    from routes.cells import checkpoint_cell_internal

    ch = get_active_channel()
    idx = next((i for i, s in enumerate(ch.main_stacks) if s.id == stack_id), None)
    if idx is None:
        return ch
    stack = ch.main_stacks[idx]
    if stack.stack_type in ('generator', 'renderer'):
        raise HTTPException(400, "Cannot remove generator/renderer stacks")

    # JIT checkpoint each cell so pending edits land as a version.
    db_name = channel_db_name(ch)
    for cell in stack.cells:
        try:
            checkpoint_cell_internal(db_name, str(cell.id))
        except Exception:
            pass  # Best-effort — don't block removal

    ch.main_stacks.pop(idx)
    if ch.main_selection_id == stack_id:
        if idx < len(ch.main_stacks):
            ch.main_selection_id = ch.main_stacks[idx].id
        elif ch.main_stacks:
            ch.main_selection_id = ch.main_stacks[-1].id
        else:
            ch.main_selection_id = None
    persist_state()
    return ch


@router.post("/api/windows/{stack_id}/remove_cell")
async def remove_cell(stack_id: UUID, cell_index: int = 0):
    """Remove a single cell from a stack. Checkpoints it first.

    If the stack becomes empty after removal, the stack is also removed.
    Generator/renderer stacks refuse removal of their last cell.
    """
    from state import channel_db_name
    from routes.cells import checkpoint_cell_internal

    ch = get_active_channel()
    stack = next((s for s in ch.main_stacks if s.id == stack_id), None)
    if stack is None:
        return ch
    if cell_index < 0 or cell_index >= len(stack.cells):
        return ch
    if stack.stack_type in ('generator', 'renderer') and len(stack.cells) == 1:
        raise HTTPException(400, "Cannot remove the last cell from a generator/renderer stack")

    cell = stack.cells[cell_index]
    db_name = channel_db_name(ch)
    try:
        checkpoint_cell_internal(db_name, str(cell.id))
    except Exception:
        pass

    stack.cells.pop(cell_index)

    # If stack is now empty, remove it
    if not stack.cells:
        idx = next(i for i, s in enumerate(ch.main_stacks) if s.id == stack_id)
        ch.main_stacks.pop(idx)
        if ch.main_selection_id == stack_id:
            if idx < len(ch.main_stacks):
                ch.main_selection_id = ch.main_stacks[idx].id
            elif ch.main_stacks:
                ch.main_selection_id = ch.main_stacks[-1].id
            else:
                ch.main_selection_id = None

    persist_state()
    return ch


@router.post("/api/windows/{stack_id}/minimize")
async def minimize_stack(stack_id: UUID):
    """Minimize a generator/renderer stack to its top bar icon.

    Moves the stack from main_stacks to nav_stacks. Only allowed for
    special stacks (generator/renderer). Regular stacks use /remove.
    """
    ch = get_active_channel()
    idx = next((i for i, s in enumerate(ch.main_stacks) if s.id == stack_id), None)
    if idx is None:
        return ch
    stack = ch.main_stacks[idx]
    if stack.stack_type not in ('generator', 'renderer'):
        raise HTTPException(400, "Only generator/renderer stacks can be minimized")
    ch.main_stacks.pop(idx)
    ch.nav_stacks.append(stack)
    if ch.main_selection_id == stack_id:
        if idx < len(ch.main_stacks):
            ch.main_selection_id = ch.main_stacks[idx].id
        elif ch.main_stacks:
            ch.main_selection_id = ch.main_stacks[-1].id
        else:
            ch.main_selection_id = None
    persist_state()
    return ch


@router.post("/api/windows/{stack_id}/restore_minimized")
async def restore_minimized_stack(stack_id: UUID, after: Optional[UUID] = None):
    """Restore a minimized generator/renderer stack from nav to main.

    `after` is the stack the client considers currently selected; the restored
    stack is placed immediately to its right. The server's `main_selection_id`
    can lag the client (selection changes don't always round-trip), so clients
    should pass their live selection to guarantee correct placement.
    """
    ch = get_active_channel()
    idx = next((i for i, s in enumerate(ch.nav_stacks) if s.id == stack_id), None)
    if idx is None:
        return ch
    stack = ch.nav_stacks.pop(idx)
    # Prefer client-provided anchor; fall back to server's main_selection_id.
    anchor = after if after else ch.main_selection_id
    insert_idx = len(ch.main_stacks)
    if anchor:
        sel_idx = next((i for i, s in enumerate(ch.main_stacks) if s.id == anchor), None)
        if sel_idx is not None:
            insert_idx = sel_idx + 1
    ch.main_stacks.insert(insert_idx, stack)
    ch.main_selection_id = stack.id
    persist_state()
    return ch


@router.post("/api/windows/{stack_id}/move_to/{target_index}")
async def move_window(stack_id: UUID, target_index: int):
    ch = get_active_channel()
    try:
        idx = next(i for i, s in enumerate(ch.main_stacks) if s.id == stack_id)
        stack = ch.main_stacks.pop(idx)
        insert_idx = target_index
        if insert_idx > idx:
            insert_idx -= 1
        insert_idx = max(0, min(insert_idx, len(ch.main_stacks)))
        ch.main_stacks.insert(insert_idx, stack)
        persist_state()
    except StopIteration:
        pass
    return ch


@router.post("/api/windows/{stack_id}/swap/{direction}")
async def win_swap(stack_id: UUID, direction: int):
    ch = get_active_channel()
    try:
        idx = next(i for i, s in enumerate(ch.main_stacks) if s.id == stack_id)
        new_idx = idx + direction
        if 0 <= new_idx < len(ch.main_stacks):
            ch.main_stacks[idx], ch.main_stacks[new_idx] = ch.main_stacks[new_idx], ch.main_stacks[idx]
            persist_state()
    except StopIteration:
        pass
    return ch


@router.put("/api/windows/{stack_id}/rename")
async def rename_stack(stack_id: UUID, name: str):
    ch = get_active_channel()
    s = next((s for s in ch.main_stacks if s.id == stack_id), None)
    if not s:
        s = next((s for s in ch.nav_stacks if s.id == stack_id), None)
    if s:
        s.name = name
        persist_state()
    return ch


@router.post("/api/windows/{stack_id}/rotate/{direction}")
async def rotate_window(stack_id: UUID, direction: int):
    ch = get_active_channel()
    try:
        stack = next(s for s in ch.main_stacks if s.id == stack_id)
        if len(stack.cells) > 1:
            if direction > 0:
                stack.cells.insert(0, stack.cells.pop())
            else:
                stack.cells.append(stack.cells.pop(0))
            persist_state()
        return ch
    except StopIteration:
        raise HTTPException(status_code=404, detail="Stack not found")


@router.post("/api/windows/{stack_id}/move_cell/{direction}")
async def move_cell(stack_id: UUID, direction: int, force_new: bool = False):
    ch = get_active_channel()
    try:
        s_idx = next(i for i, stk in enumerate(ch.main_stacks) if stk.id == stack_id)
    except StopIteration:
        return ch

    s = ch.main_stacks[s_idx]
    if not s.cells:
        return ch

    # Prevent moving the last cell out of a generator or renderer stack
    if s.stack_type in ('generator', 'renderer') and len(s.cells) == 1:
        return ch

    cell = s.cells.pop(0)
    target_idx = s_idx + direction

    if 0 <= target_idx < len(ch.main_stacks) and not force_new:
        dest_stack = ch.main_stacks[target_idx]
        dest_stack.cells.insert(0, cell)
        ch.main_selection_id = dest_stack.id
    else:
        new_stack = Stack(name="")
        new_stack.cells.append(cell)
        ins_idx = s_idx + 1 if direction > 0 else s_idx
        ch.main_stacks.insert(ins_idx, new_stack)
        ch.main_selection_id = new_stack.id

    if not s.cells:
        ch.main_stacks.pop(s_idx)
        if ch.main_selection_id == s.id:
            if s_idx < len(ch.main_stacks):
                ch.main_selection_id = ch.main_stacks[s_idx].id
            elif len(ch.main_stacks) > 0:
                ch.main_selection_id = ch.main_stacks[-1].id
            else:
                ch.main_selection_id = None
    
    persist_state()
    return ch


@router.post("/api/windows/{stack_id}/move_cell_to/{target_stack_index}/{mode}")
async def move_cell_to(stack_id: UUID, target_stack_index: int, mode: str, src_cell_index: int = 0, tgt_cell_index: int = 0):
    ch = get_active_channel()
    try:
        src_idx = next(i for i, s in enumerate(ch.main_stacks) if s.id == stack_id)
    except StopIteration:
        return ch

    src_stack = ch.main_stacks[src_idx]
    if not src_stack.cells or src_cell_index < 0 or src_cell_index >= len(src_stack.cells):
        return ch

    # Prevent moving the last cell out of a generator or renderer stack
    if src_stack.stack_type in ('generator', 'renderer') and len(src_stack.cells) == 1:
        return ch

    # Generator and renderer stacks only accept Standard cells —
    # Drafts have no entrypoint/manifest and would break discovery.
    # Picking cells never hit this endpoint (they're client-only).
    from models import CellState as _CellState
    cell_state = getattr(src_stack.cells[src_cell_index], "state", None)
    if mode == 'stack' and 0 <= target_stack_index < len(ch.main_stacks):
        tgt_stack = ch.main_stacks[target_stack_index]
        if tgt_stack.stack_type in ('generator', 'renderer') and cell_state == _CellState.DRAFT:
            return ch  # silently no-op

    cell = src_stack.cells.pop(src_cell_index)

    if not src_stack.cells:
        ch.main_stacks.pop(src_idx)
        if target_stack_index > src_idx:
            target_stack_index -= 1

    if mode == 'stack':
        if 0 <= target_stack_index < len(ch.main_stacks):
            target_stack = ch.main_stacks[target_stack_index]
            safe_tgt_idx = max(0, min(tgt_cell_index, len(target_stack.cells)))
            target_stack.cells.insert(safe_tgt_idx, cell)
            ch.main_selection_id = target_stack.id
        else:
            new_stack = Stack(name="", cells=[cell])
            ch.main_stacks.append(new_stack)
            ch.main_selection_id = new_stack.id
    else:  # mode == 'insert'
        new_stack = Stack(name="", cells=[cell])
        safe_idx = max(0, min(target_stack_index, len(ch.main_stacks)))
        ch.main_stacks.insert(safe_idx, new_stack)
        ch.main_selection_id = new_stack.id

    persist_state()
    return ch


@router.post("/api/windows/{stack_id}/move_stack_to/{target_index}/{mode}")
async def move_stack_to(stack_id: UUID, target_index: int, mode: str):
    """Reposition a stack. `mode='insert'` drops it as a new column at
    target_index; `mode='stack'` merges its cells into the target stack
    (source's cells appended to the end of target's existing cells)
    and removes the source column.

    Merge refuses generator/renderer stacks on either side — those are
    singleton tool columns, not regular containers — with the existing
    Draft-to-generator guard covered as a subset.
    """
    ch = get_active_channel()
    try:
        src_idx = next(i for i, s in enumerate(ch.main_stacks) if s.id == stack_id)
    except StopIteration:
        return ch

    src_stack = ch.main_stacks[src_idx]

    if mode == 'stack':
        if 0 <= target_index < len(ch.main_stacks) and target_index != src_idx:
            target_stack = ch.main_stacks[target_index]
            # Generator / renderer stacks can't be merged into, and
            # they can't be merged out of either — they're tied to a
            # specific source cell on the canvas and losing that cell
            # would break discovery.
            if src_stack.stack_type in ('generator', 'renderer'):
                return ch
            if target_stack.stack_type in ('generator', 'renderer'):
                return ch
            # Append semantics: the dragged column lands *under* the
            # target, so its cells come after the target's existing
            # cells. Changed from the historical prepend behavior
            # because the only caller is the new zoom-out drag-merge,
            # which is "drop under" by gesture.
            target_stack.cells = target_stack.cells + src_stack.cells
            ch.main_stacks.pop(src_idx)
            ch.main_selection_id = target_stack.id
    else:  # mode == 'insert'
        ch.main_stacks.pop(src_idx)
        if target_index > src_idx:
            target_index -= 1
        safe_idx = max(0, min(target_index, len(ch.main_stacks)))
        ch.main_stacks.insert(safe_idx, src_stack)
        ch.main_selection_id = src_stack.id

    persist_state()
    return ch


@router.post("/api/windows/{stack_id}/duplicate_cell")
async def duplicate_cell(stack_id: UUID):
    ch = get_active_channel()
    s_idx = next((i for i, stk in enumerate(ch.main_stacks) if stk.id == stack_id), None)
    s = ch.main_stacks[s_idx] if s_idx is not None else None
    if s and s.cells:
        original = s.cells[0]
        from models import CellState
        is_draft = getattr(original, "state", None) == CellState.DRAFT
        new_cell = Cell(
            name=f"{original.name} (Copy)",
            summary=original.summary,
            files=[VirtualFile(name=f.name, content=f.content, language=f.language) for f in original.files],
        )
        # Draft duplication: preserve Draft state + generator + settings,
        # and mirror parent edges + draft_cell_files into the new cell id.
        # Per the plan, the duplicate references the same parents with
        # independent files — no link back to the original Draft.
        if is_draft:
            new_cell.state = CellState.DRAFT
            new_cell.draft_generator_id = original.draft_generator_id
            new_cell.settings = (
                dict(original.settings)
                if original.settings is not None else None
            )
            channel_name = getattr(ch, "name", "starting") or "starting"
            from database import get_db_connection
            import json as _json
            conn = get_db_connection(channel_name)
            try:
                settings_json = (
                    _json.dumps(original.settings)
                    if original.settings is not None else None
                )
                conn.execute(
                    "INSERT INTO cells (id, generator_name, state, pickoptions_json, source_type) "
                    "VALUES (?, ?, 'Draft', ?, 'draft')",
                    (str(new_cell.id), original.draft_generator_id, settings_json),
                )
                # Copy parent edges from the original's DB row
                parents = conn.execute(
                    "SELECT parent_cell_id, parent_key FROM cell_edges "
                    "WHERE child_cell_id=? ORDER BY parent_key",
                    (str(original.id),),
                ).fetchall()
                for p in parents:
                    conn.execute(
                        "INSERT OR IGNORE INTO cell_edges (parent_cell_id, child_cell_id, parent_key) "
                        "VALUES (?, ?, ?)",
                        (p["parent_cell_id"], str(new_cell.id), p["parent_key"]),
                    )
                # Copy draft_cell_files
                for f in original.files:
                    conn.execute(
                        "INSERT OR REPLACE INTO draft_cell_files (cell_id, filepath, content_text) "
                        "VALUES (?, ?, ?)",
                        (str(new_cell.id), f.name, f.content),
                    )
                conn.commit()
            finally:
                conn.close()
        # Drop the duplicate into a fresh stack one slot to the right of the
        # source. Mirrors the placement generators use via insert_after_stack_id
        # (see routes/runs/create.py) — original stays put, dup is alone.
        new_stack = Stack(name="", cells=[new_cell])
        ch.main_stacks.insert(s_idx + 1, new_stack)
        ch.main_selection_id = new_stack.id
        persist_state()
    return ch


@router.post("/api/windows/{stack_id}/resize")
async def resize_stack(stack_id: UUID):
    ch = get_active_channel()
    s = next((s for s in ch.main_stacks if s.id == stack_id), None)
    if s:
        if s.width == 33: s.width = 50
        elif s.width == 50: s.width = 66
        elif s.width == 66: s.width = 33
        else: s.width = 33
        persist_state()
    return ch


@router.post("/api/cells/{cell_id}/toggle_enabled")
async def toggle_cell_enabled(cell_id: UUID):
    """Flip a cell's enabled flag. Refuses to disable the last enabled cell
    of a generator/renderer stack — we need at least one to run/load."""
    ch = get_active_channel()
    for s in [*ch.main_stacks, *ch.nav_stacks]:
        for c in s.cells:
            if c.id == cell_id:
                if c.enabled and s.stack_type in ('generator', 'renderer'):
                    enabled_count = sum(1 for x in s.cells if x.enabled)
                    if enabled_count <= 1:
                        raise HTTPException(
                            400,
                            f"Cannot disable the last enabled cell of a {s.stack_type} stack",
                        )
                c.enabled = not c.enabled
                c.updated_at = datetime.now()
                persist_state()
                return ch
    raise HTTPException(404, "Cell not found")


@router.put("/api/cells/{stack_id}/update_top")
async def update_top_cell(stack_id: UUID, cell_data: Cell):
    ch = get_active_channel()
    # Search all stacks (main + nav) so that placeholder cells in
    # newly-created stacks can still be updated even when the frontend
    # passes the original cell's stack id.
    for s in [*ch.main_stacks, *ch.nav_stacks]:
        idx = next((i for i, c in enumerate(s.cells) if c.id == cell_data.id), None)
        if idx is not None:
            cell_data.updated_at = datetime.now()
            s.cells[idx] = cell_data
            persist_state()
            break
    return ch


@router.post("/api/windows/{stack_id}/append_cell")
async def append_cell(stack_id: UUID, cell: Cell):
    ch = get_active_channel()
    s = next((s for s in ch.main_stacks if s.id == stack_id), None)
    if not s:
        s = next((s for s in ch.nav_stacks if s.id == stack_id), None)
    if s:
        s.cells.insert(0, cell)
        persist_state()
    return ch


