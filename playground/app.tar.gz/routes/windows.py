"""Stack/cell layout endpoints — every handler mutates state.channels in
memory then calls persist_state(). The mutations themselves are
constant-time attribute writes, but persist_state() and any sync DB
writes a handler does need to run on a worker thread so the event
loop never waits on the channel WAL busy_timeout when a generator-
subprocess is mid-flush. Every handler body is wrapped in
``asyncio.to_thread`` defensively even when the visible work today
is just a mutation + persist_state — the wrap enforces the rule by
structure so a future contributor adding a sync DB query next to
the mutation can't accidentally re-introduce loop blocking.

``persist_state()`` called from inside ``asyncio.to_thread`` is the
fast path: it detects it's already off-loop and runs ``_persist_state_sync``
inline rather than re-scheduling onto the executor.
"""
import asyncio
from datetime import datetime
from typing import Optional
from uuid import UUID
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from models import Cell, Stack, VirtualFile
from state import get_active_channel, persist_state

router = APIRouter()


class InsertBlankCellRequest(BaseModel):
    # Client-minted id (the Picking cell's UUID) so the id flows
    # through Picking → Standard cleanly. Generated if omitted.
    id: str | None = None
    name: str = "New cell"
    summary: str = ""


@router.post("/api/windows/{stack_id}/insert_blank_cell")
async def insert_blank_cell(stack_id: UUID, body: InsertBlankCellRequest):
    """Create a blank Standard cell in its own new stack, placed right
    of the given anchor stack. Used by the "Create blank cell" picker
    affordance (0-input mode). No generator, no Draft state — just an
    empty canvas the user can author into."""
    def _body():
        import uuid as _uuid
        ch = get_active_channel()
        try:
            src_idx = next(i for i, s in enumerate(ch.main_stacks) if s.id == stack_id)
        except StopIteration:
            raise HTTPException(404, "Stack not found")
        try:
            cell_id = _uuid.UUID(body.id) if body.id else _uuid.uuid4()
        except ValueError:
            raise HTTPException(400, "id must be a valid UUID")
        new_cell = Cell(id=cell_id, name=body.name, summary=body.summary, files=[])
        new_stack = Stack(name="", cells=[new_cell])
        ch.main_stacks.insert(src_idx + 1, new_stack)
        ch.main_selection_id = new_stack.id
        persist_state()
        return ch
    return await asyncio.to_thread(_body)


# --- MAIN WINDOW OPS ---

@router.post("/api/windows/{stack_id}/remove")
async def remove_stack(stack_id: UUID):
    """Remove a stack from the canvas. Cells stay in the DB — recoverable
    from the history view. Pending edits are checkpointed first so no
    user work is lost. Generator/renderer stacks are refused.
    """
    def _body():
        from state import channel_db_name
        from routes.cells import checkpoint_cell_internal
        from routes.runs.registry import running_placeholder_cell_ids

        ch = get_active_channel()
        idx = next((i for i, s in enumerate(ch.main_stacks) if s.id == stack_id), None)
        if idx is None:
            return ch
        stack = ch.main_stacks[idx]
        if stack.stack_type in ('generator', 'renderer'):
            raise HTTPException(400, "Cannot remove generator/renderer stacks")
        running = running_placeholder_cell_ids()
        if any(str(c.id) in running for c in stack.cells):
            raise HTTPException(409, "Stack contains a running cell — stop the run first")

        # JIT checkpoint each cell so pending edits land as a version.
        db_name = channel_db_name(ch)
        for cell in stack.cells:
            try:
                checkpoint_cell_internal(db_name, str(cell.id))
            except Exception:
                pass  # Best-effort — don't block removal

        ch.main_stacks.pop(idx)
        if ch.main_selection_id == stack_id:
            # Selection follows the stack to the left; if the removed stack
            # was leftmost, the old right neighbor now sits at index 0.
            if ch.main_stacks:
                ch.main_selection_id = ch.main_stacks[max(0, idx - 1)].id
            else:
                ch.main_selection_id = None
        persist_state()
        return ch
    return await asyncio.to_thread(_body)


@router.post("/api/windows/{stack_id}/remove_cell")
async def remove_cell(stack_id: UUID, cell_index: int = 0):
    """Remove a single cell from a stack. Checkpoints it first.

    If the stack becomes empty after removal, the stack is also removed.
    Generator/renderer stacks refuse removal of their last cell.
    """
    def _body():
        from state import channel_db_name
        from routes.cells import checkpoint_cell_internal

        ch = get_active_channel()
        stack = next((s for s in ch.main_stacks if s.id == stack_id), None)
        if stack is None:
            return ch
        if cell_index < 0 or cell_index >= len(stack.cells):
            return ch
        if stack.stack_type in ('generator', 'renderer') and len(stack.cells) == 1:
            raise HTTPException(400, "Cannot remove the last cell from a generator/renderer stack")

        cell = stack.cells[cell_index]
        from routes.runs.registry import running_placeholder_cell_ids
        if str(cell.id) in running_placeholder_cell_ids():
            raise HTTPException(409, "Cell is running — stop the run first")
        db_name = channel_db_name(ch)
        try:
            checkpoint_cell_internal(db_name, str(cell.id))
        except Exception:
            pass

        stack.cells.pop(cell_index)

        # If stack is now empty, remove it
        if not stack.cells:
            idx = next(i for i, s in enumerate(ch.main_stacks) if s.id == stack_id)
            ch.main_stacks.pop(idx)
            if ch.main_selection_id == stack_id:
                # Selection follows the stack to the left; if the removed
                # stack was leftmost, the old right neighbor now sits at 0.
                if ch.main_stacks:
                    ch.main_selection_id = ch.main_stacks[max(0, idx - 1)].id
                else:
                    ch.main_selection_id = None

        persist_state()
        return ch
    return await asyncio.to_thread(_body)


@router.post("/api/windows/{stack_id}/minimize")
async def minimize_stack(stack_id: UUID):
    """Minimize a generator/renderer stack to its top bar icon.

    Moves the stack from main_stacks to nav_stacks. Only allowed for
    special stacks (generator/renderer). Regular stacks use /remove.
    """
    def _body():
        ch = get_active_channel()
        idx = next((i for i, s in enumerate(ch.main_stacks) if s.id == stack_id), None)
        if idx is None:
            return ch
        stack = ch.main_stacks[idx]
        if stack.stack_type not in ('generator', 'renderer'):
            raise HTTPException(400, "Only generator/renderer stacks can be minimized")
        ch.main_stacks.pop(idx)
        ch.nav_stacks.append(stack)
        if ch.main_selection_id == stack_id:
            # Selection follows the stack to the left; if the removed stack
            # was leftmost, the old right neighbor now sits at index 0.
            if ch.main_stacks:
                ch.main_selection_id = ch.main_stacks[max(0, idx - 1)].id
            else:
                ch.main_selection_id = None
        persist_state()
        return ch
    return await asyncio.to_thread(_body)


@router.post("/api/windows/{stack_id}/restore_minimized")
async def restore_minimized_stack(stack_id: UUID, after: Optional[UUID] = None):
    """Restore a minimized generator/renderer stack from nav to main.

    `after` is the stack the client considers currently selected; the restored
    stack is placed immediately to its right. The server's `main_selection_id`
    can lag the client (selection changes don't always round-trip), so clients
    should pass their live selection to guarantee correct placement.
    """
    def _body():
        ch = get_active_channel()
        idx = next((i for i, s in enumerate(ch.nav_stacks) if s.id == stack_id), None)
        if idx is None:
            return ch
        stack = ch.nav_stacks.pop(idx)
        # Prefer client-provided anchor; fall back to server's main_selection_id.
        anchor = after if after else ch.main_selection_id
        insert_idx = len(ch.main_stacks)
        if anchor:
            sel_idx = next((i for i, s in enumerate(ch.main_stacks) if s.id == anchor), None)
            if sel_idx is not None:
                insert_idx = sel_idx + 1
        ch.main_stacks.insert(insert_idx, stack)
        ch.main_selection_id = stack.id
        persist_state()
        return ch
    return await asyncio.to_thread(_body)


@router.post("/api/windows/{stack_id}/move_to/{target_index}")
async def move_window(stack_id: UUID, target_index: int):
    def _body():
        ch = get_active_channel()
        try:
            idx = next(i for i, s in enumerate(ch.main_stacks) if s.id == stack_id)
            stack = ch.main_stacks.pop(idx)
            insert_idx = target_index
            if insert_idx > idx:
                insert_idx -= 1
            insert_idx = max(0, min(insert_idx, len(ch.main_stacks)))
            ch.main_stacks.insert(insert_idx, stack)
            persist_state()
        except StopIteration:
            pass
        return ch
    return await asyncio.to_thread(_body)


@router.post("/api/windows/{stack_id}/swap/{direction}")
async def win_swap(stack_id: UUID, direction: int):
    def _body():
        ch = get_active_channel()
        try:
            idx = next(i for i, s in enumerate(ch.main_stacks) if s.id == stack_id)
            new_idx = idx + direction
            if 0 <= new_idx < len(ch.main_stacks):
                ch.main_stacks[idx], ch.main_stacks[new_idx] = ch.main_stacks[new_idx], ch.main_stacks[idx]
                persist_state()
        except StopIteration:
            pass
        return ch
    return await asyncio.to_thread(_body)


@router.put("/api/windows/{stack_id}/rename")
async def rename_stack(stack_id: UUID, name: str):
    def _body():
        ch = get_active_channel()
        s = next((s for s in ch.main_stacks if s.id == stack_id), None)
        if not s:
            s = next((s for s in ch.nav_stacks if s.id == stack_id), None)
        if s:
            s.name = name
            persist_state()
        return ch
    return await asyncio.to_thread(_body)


@router.post("/api/windows/{stack_id}/rotate/{direction}")
async def rotate_window(stack_id: UUID, direction: int):
    def _body():
        ch = get_active_channel()
        try:
            stack = next(s for s in ch.main_stacks if s.id == stack_id)
            if len(stack.cells) > 1:
                if direction > 0:
                    stack.cells.insert(0, stack.cells.pop())
                else:
                    stack.cells.append(stack.cells.pop(0))
                persist_state()
            return ch
        except StopIteration:
            raise HTTPException(status_code=404, detail="Stack not found")
    return await asyncio.to_thread(_body)


@router.post("/api/windows/{stack_id}/move_cell/{direction}")
async def move_cell(stack_id: UUID, direction: int, force_new: bool = False):
    def _body():
        ch = get_active_channel()
        try:
            s_idx = next(i for i, stk in enumerate(ch.main_stacks) if stk.id == stack_id)
        except StopIteration:
            return ch

        s = ch.main_stacks[s_idx]
        if not s.cells:
            return ch

        # Prevent moving the last cell out of a generator or renderer stack
        if s.stack_type in ('generator', 'renderer') and len(s.cells) == 1:
            return ch

        cell = s.cells.pop(0)
        target_idx = s_idx + direction

        if 0 <= target_idx < len(ch.main_stacks) and not force_new:
            dest_stack = ch.main_stacks[target_idx]
            dest_stack.cells.insert(0, cell)
            ch.main_selection_id = dest_stack.id
        else:
            new_stack = Stack(name="")
            new_stack.cells.append(cell)
            ins_idx = s_idx + 1 if direction > 0 else s_idx
            ch.main_stacks.insert(ins_idx, new_stack)
            ch.main_selection_id = new_stack.id

        if not s.cells:
            ch.main_stacks.pop(s_idx)
            if ch.main_selection_id == s.id:
                if s_idx < len(ch.main_stacks):
                    ch.main_selection_id = ch.main_stacks[s_idx].id
                elif len(ch.main_stacks) > 0:
                    ch.main_selection_id = ch.main_stacks[-1].id
                else:
                    ch.main_selection_id = None

        persist_state()
        return ch
    return await asyncio.to_thread(_body)


@router.post("/api/windows/{stack_id}/move_cell_to/{target_stack_index}/{mode}")
async def move_cell_to(stack_id: UUID, target_stack_index: int, mode: str, src_cell_index: int = 0, tgt_cell_index: int = 0):
    def _body():
        ch = get_active_channel()
        try:
            src_idx = next(i for i, s in enumerate(ch.main_stacks) if s.id == stack_id)
        except StopIteration:
            return ch

        src_stack = ch.main_stacks[src_idx]
        if not src_stack.cells or src_cell_index < 0 or src_cell_index >= len(src_stack.cells):
            return ch

        # Prevent moving the last cell out of a generator or renderer stack
        if src_stack.stack_type in ('generator', 'renderer') and len(src_stack.cells) == 1:
            return ch

        nonlocal_target = target_stack_index
        cell = src_stack.cells.pop(src_cell_index)

        if not src_stack.cells:
            ch.main_stacks.pop(src_idx)
            if nonlocal_target > src_idx:
                nonlocal_target -= 1

        if mode == 'stack':
            if 0 <= nonlocal_target < len(ch.main_stacks):
                target_stack = ch.main_stacks[nonlocal_target]
                safe_tgt_idx = max(0, min(tgt_cell_index, len(target_stack.cells)))
                target_stack.cells.insert(safe_tgt_idx, cell)
                ch.main_selection_id = target_stack.id
            else:
                new_stack = Stack(name="", cells=[cell])
                ch.main_stacks.append(new_stack)
                ch.main_selection_id = new_stack.id
        else:  # mode == 'insert'
            new_stack = Stack(name="", cells=[cell])
            safe_idx = max(0, min(nonlocal_target, len(ch.main_stacks)))
            ch.main_stacks.insert(safe_idx, new_stack)
            ch.main_selection_id = new_stack.id

        persist_state()
        return ch
    return await asyncio.to_thread(_body)


@router.post("/api/windows/{stack_id}/move_stack_to/{target_index}/{mode}")
async def move_stack_to(stack_id: UUID, target_index: int, mode: str):
    """Reposition a stack. `mode='insert'` drops it as a new column at
    target_index; `mode='stack'` merges its cells into the target stack
    (source's cells appended to the end of target's existing cells)
    and removes the source column.

    Merge refuses generator/renderer stacks on either side — those are
    singleton tool columns, not regular containers.
    """
    def _body():
        ch = get_active_channel()
        try:
            src_idx = next(i for i, s in enumerate(ch.main_stacks) if s.id == stack_id)
        except StopIteration:
            return ch

        src_stack = ch.main_stacks[src_idx]
        nonlocal_target = target_index

        if mode == 'stack':
            if 0 <= nonlocal_target < len(ch.main_stacks) and nonlocal_target != src_idx:
                target_stack = ch.main_stacks[nonlocal_target]
                # Generator / renderer stacks can't be merged into, and
                # they can't be merged out of either — they're tied to a
                # specific source cell on the canvas and losing that cell
                # would break discovery.
                if src_stack.stack_type in ('generator', 'renderer'):
                    return ch
                if target_stack.stack_type in ('generator', 'renderer'):
                    return ch
                # Append semantics: the dragged column lands *under* the
                # target, so its cells come after the target's existing
                # cells. Changed from the historical prepend behavior
                # because the only caller is the new zoom-out drag-merge,
                # which is "drop under" by gesture.
                target_stack.cells = target_stack.cells + src_stack.cells
                ch.main_stacks.pop(src_idx)
                ch.main_selection_id = target_stack.id
        else:  # mode == 'insert'
            ch.main_stacks.pop(src_idx)
            if nonlocal_target > src_idx:
                nonlocal_target -= 1
            safe_idx = max(0, min(nonlocal_target, len(ch.main_stacks)))
            ch.main_stacks.insert(safe_idx, src_stack)
            ch.main_selection_id = src_stack.id

        persist_state()
        return ch
    return await asyncio.to_thread(_body)


@router.post("/api/windows/{stack_id}/duplicate_cell")
async def duplicate_cell(stack_id: UUID):
    def _body():
        ch = get_active_channel()
        s_idx = next((i for i, stk in enumerate(ch.main_stacks) if stk.id == stack_id), None)
        if s_idx is not None and ch.main_stacks[s_idx].cells:
            s = ch.main_stacks[s_idx]
            original = s.cells[0]
            # Duplicate is a "consumer reads the cell as input" boundary —
            # promote any pending drafts on the source into a version so
            # the version chain captures the snapshot that was duplicated
            # from. Imports are lazy to keep this module's import graph
            # tight (windows.py is loaded by the FastAPI app at boot;
            # routes/runs and database are heavier).
            try:
                from state import channel_db_name
                from database import get_db_connection
                from routes.runs import _promote_drafts_to_version
                import uuid as _uuid

                channel_slug = channel_db_name(ch)
                conn = get_db_connection(channel_slug)
                try:
                    run_id = str(_uuid.uuid4())
                    conn.execute(
                        "INSERT INTO runs (id, prompt, status) VALUES (?, ?, 'completed')",
                        (run_id, "duplicate"),
                    )
                    # state.json's current files seed the genesis row
                    # when this is the first time we version this cell.
                    current_files = [
                        {"filepath": f.name, "content": f.content}
                        for f in original.files
                    ]
                    _promote_drafts_to_version(
                        conn, str(original.id), run_id,
                        current_files=current_files,
                    )
                    conn.commit()
                finally:
                    conn.close()
            except Exception:
                # Best-effort — a failed promotion shouldn't block the
                # duplicate itself, which the user explicitly asked for.
                pass

            new_cell = Cell(
                name=f"{original.name} (Copy)",
                summary=original.summary,
                files=[VirtualFile(name=f.name, content=f.content, language=f.language) for f in original.files],
            )
            # Drop the duplicate into a fresh stack one slot to the right of the
            # source. Mirrors the placement generators use via insert_after_stack_id
            # (see routes/runs/create.py) — original stays put, dup is alone.
            new_stack = Stack(name="", cells=[new_cell])
            ch.main_stacks.insert(s_idx + 1, new_stack)
            ch.main_selection_id = new_stack.id
            persist_state()
        return ch
    return await asyncio.to_thread(_body)


@router.post("/api/windows/{stack_id}/duplicate_cell_in_stack/{cell_index}")
async def duplicate_cell_in_stack(stack_id: UUID, cell_index: int):
    """Duplicate the cell at ``cell_index`` INTO THE SAME stack, inserting the
    copy immediately after it. Powers the dive-deep "duplicate" button, where
    each cell is its own column: the copy lands in the adjacent column (same
    underlying stack) rather than in a brand-new stack like duplicate_cell."""
    def _body():
        ch = get_active_channel()
        s_idx = next((i for i, stk in enumerate(ch.main_stacks) if stk.id == stack_id), None)
        if s_idx is None:
            raise HTTPException(404, "Stack not found")
        s = ch.main_stacks[s_idx]
        if not (0 <= cell_index < len(s.cells)):
            raise HTTPException(400, "cell_index out of range")
        original = s.cells[cell_index]
        # Same "consumer reads the cell as input" boundary as duplicate_cell:
        # promote pending drafts into a version so the chain captures the
        # snapshot the copy was taken from. Best-effort; see duplicate_cell.
        try:
            from state import channel_db_name
            from database import get_db_connection
            from routes.runs import _promote_drafts_to_version
            import uuid as _uuid

            channel_slug = channel_db_name(ch)
            conn = get_db_connection(channel_slug)
            try:
                run_id = str(_uuid.uuid4())
                conn.execute(
                    "INSERT INTO runs (id, prompt, status) VALUES (?, ?, 'completed')",
                    (run_id, "duplicate"),
                )
                current_files = [
                    {"filepath": f.name, "content": f.content}
                    for f in original.files
                ]
                _promote_drafts_to_version(
                    conn, str(original.id), run_id,
                    current_files=current_files,
                )
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass

        new_cell = Cell(
            name=f"{original.name} (Copy)",
            summary=original.summary,
            icon=original.icon,
            files=[VirtualFile(name=f.name, content=f.content, language=f.language) for f in original.files],
        )
        s.cells.insert(cell_index + 1, new_cell)
        ch.main_selection_id = s.id
        persist_state()
        return ch
    return await asyncio.to_thread(_body)


@router.post("/api/windows/{stack_id}/duplicate_stack")
async def duplicate_stack(stack_id: UUID):
    """Copy every cell of the given stack into a fresh stack placed one slot
    to the right. Mirrors duplicate_cell, but for the whole column — used by
    the stack-footer "Duplicate stack" button. New cells get fresh ids so the
    copy is independent of the original. Generator/renderer stacks (singletons
    per channel) duplicate into a STANDARD stack — an editable fork of their
    source cells rather than a forbidden second special stack."""
    def _body():
        ch = get_active_channel()
        s_idx = next((i for i, stk in enumerate(ch.main_stacks) if stk.id == stack_id), None)
        if s_idx is None:
            raise HTTPException(404, "Stack not found")
        src = ch.main_stacks[s_idx]
        new_cells = [
            Cell(
                name=c.name,
                summary=c.summary,
                icon=c.icon,
                files=[VirtualFile(name=f.name, content=f.content, language=f.language) for f in c.files],
            )
            for c in src.cells
        ]
        # A channel allows at most one generator and one renderer stack, so the
        # copy can't keep that type — duplicate a special stack into a STANDARD
        # stack instead (an editable fork of its source cells). Standard stacks
        # carry their type through unchanged.
        copy_type = "standard" if src.stack_type in ('generator', 'renderer') else src.stack_type
        new_stack = Stack(name=src.name, cells=new_cells, stack_type=copy_type)
        ch.main_stacks.insert(s_idx + 1, new_stack)
        ch.main_selection_id = new_stack.id
        persist_state()
        return ch
    return await asyncio.to_thread(_body)


@router.post("/api/windows/{stack_id}/resize")
async def resize_stack(stack_id: UUID):
    def _body():
        ch = get_active_channel()
        s = next((s for s in ch.main_stacks if s.id == stack_id), None)
        if s:
            if s.width == 33: s.width = 50
            elif s.width == 50: s.width = 66
            elif s.width == 66: s.width = 33
            else: s.width = 33
            persist_state()
        return ch
    return await asyncio.to_thread(_body)


def _ensure_genesis_snapshot(ch, old_cell, new_cell) -> None:
    """First-touch snapshot for a never-versioned cell.

    Writes a genesis row + cell_files entries capturing the cell's
    CURRENT file contents (i.e. the PRE-update state) before
    update_top overwrites them. This preserves the only moment we can
    still see what files were there before the user's edit: state.json
    is mutated in-place on every keystroke, so by the time a later
    checkpoint runs the original content is gone. Without this, the
    first checkpoint that synthesizes a v1 has to leave out every
    edited file's pre-edit content, and "revert to v1" loses data.

    Skipped when:
    - old_cell has no files (empty / picker-placeholder cells —
      nothing to snapshot, and creating a row would collide with a
      future _record_dag_cell INSERT that reuses the cell id).
    - The cell already has a row in `cells` (already versioned by a
      generator run, a previous snapshot, or a chat turn).
    - The file set is unchanged by this update (cursor moves, no-op
      writes from update_top retries) — skip the SQLite touch.

    Best-effort: catches and prints any exception. The caller proceeds
    to write state.json regardless.
    """
    if not old_cell.files:
        return
    old_by_name = {f.name: f.content for f in old_cell.files}
    new_by_name = {f.name: f.content for f in new_cell.files}
    if old_by_name == new_by_name:
        return

    from database import get_db_connection
    from state import channel_db_name
    from cas import hash_and_store_bytes
    import uuid as _uuid

    channel = channel_db_name(ch)
    conn = get_db_connection(channel)
    try:
        cell_id = str(old_cell.id)
        if conn.execute("SELECT 1 FROM cells WHERE id=?", (cell_id,)).fetchone():
            return

        genesis_run_id = str(_uuid.uuid4())
        conn.execute(
            "INSERT INTO runs (id, prompt, status) VALUES (?, ?, 'completed')",
            (genesis_run_id, "genesis-snapshot"),
        )
        conn.execute(
            "INSERT INTO cells (id, run_id, generator_name, sequence_num, "
            "version_name, version_summary, source_type) "
            "VALUES (?, ?, 'genesis', 1, 'Initial', 'Initial snapshot', 'manual_edit')",
            (cell_id, genesis_run_id),
        )
        for f in old_cell.files:
            raw = (f.content or "").encode("utf-8")
            blob_hash = hash_and_store_bytes(raw)
            if not blob_hash:
                continue
            conn.execute(
                "INSERT OR IGNORE INTO blobs (hash, size) VALUES (?, ?)",
                (blob_hash, len(raw)),
            )
            conn.execute(
                "INSERT OR IGNORE INTO cell_files (cell_id, filepath, blob_hash) "
                "VALUES (?, ?, ?)",
                (cell_id, f.name, blob_hash),
            )
        conn.commit()
    finally:
        conn.close()


@router.put("/api/cells/{stack_id}/update_top")
async def update_top_cell(stack_id: UUID, cell_data: Cell):
    def _body():
        ch = get_active_channel()
        # Search all stacks (main + nav) so that placeholder cells in
        # newly-created stacks can still be updated even when the frontend
        # passes the original cell's stack id.
        for s in [*ch.main_stacks, *ch.nav_stacks]:
            idx = next((i for i, c in enumerate(s.cells) if c.id == cell_data.id), None)
            if idx is not None:
                # Snapshot the cell's PRE-update files into a genesis row
                # before overwriting state.json. Captures the only moment
                # we still have the original content, so a later
                # checkpoint can produce a faithful v1.
                try:
                    _ensure_genesis_snapshot(ch, s.cells[idx], cell_data)
                except Exception as e:
                    print(f"genesis snapshot failed: {e}")

                cell_data.updated_at = datetime.now()
                s.cells[idx] = cell_data
                persist_state()
                break
        return ch
    return await asyncio.to_thread(_body)


@router.post("/api/windows/{stack_id}/append_cell")
async def append_cell(stack_id: UUID, cell: Cell):
    def _body():
        ch = get_active_channel()
        s = next((s for s in ch.main_stacks if s.id == stack_id), None)
        if not s:
            s = next((s for s in ch.nav_stacks if s.id == stack_id), None)
        if s:
            s.cells.insert(0, cell)
            persist_state()
        return ch
    return await asyncio.to_thread(_body)
