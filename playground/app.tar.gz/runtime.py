"""Runtime detection — native vs. pyodide/wasm.

Code paths that depend on native OS facilities (Docker, subprocess, OS
keyring, file watchers) branch on IS_WASM so the same codebase runs in
both the native server and the in-browser pyodide playground.

The playground sets COLLIMATE_RUNTIME=wasm explicitly in its boot script;
we also sniff sys.platform as a backstop so this works even if the env
var goes missing.
"""
import os
import sys

IS_WASM: bool = (
    os.environ.get("COLLIMATE_RUNTIME") == "wasm"
    or sys.platform == "emscripten"
)


class WasmNotSupportedError(RuntimeError):
    """Raised when a native-only capability (Docker, subprocess, OS keyring)
    is requested while running under pyodide. api/main.py registers an
    exception handler that maps this to HTTP 503 with a clean JSON body
    so the frontend can show 'not supported in playground' instead of a
    generic 500."""
