"""Sandbox registry — per-image multiplexed daemon containers, lazy spawn,
reference-counted teardown.

A "sandbox" is a docker container running a daemon process that accepts
JSON ops on stdin and emits JSON events on stdout. Generators declare the
image and Dockerfile path via ``gen.chat.start_session(image=...,
dockerfile_dir=..., shared=...)``; the host builds the image lazily on
first use, spawns one daemon per image when the first session asks for
it, and shuts the container down when the last session closes.

Two key design properties:

1. **No system default image.** Every generator that uses this primitive
   declares its own image and dockerfile_dir. The host has no opinion
   about what to spawn — it just runs whatever the generator names.

2. **No warm pool.** Daemons are born when a session needs them and die
   when refcount drops to zero. There is no pre-spawning at app
   startup. Visible cost: every new session pays the per-session
   ClaudeSDKClient init (~3-15s); the shared daemon only saves the
   one-time docker run + Python boot.

The daemon protocol is defined by the image. The host treats the
container as a black box that speaks newline-delimited JSON.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import subprocess
import sys
import uuid
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Optional

_logger = logging.getLogger("sandbox")

LogSink = Callable[[str], None]


def _noop_log(_line: str) -> None:
    pass


# ---------------------------------------------------------------------------
# Image build / probe — one-per-image, lazy, idempotent.
# ---------------------------------------------------------------------------

_known_images: dict[str, bool] = {}
_image_locks: dict[str, asyncio.Lock] = {}


def _image_lock(image: str) -> asyncio.Lock:
    lock = _image_locks.get(image)
    if lock is None:
        lock = asyncio.Lock()
        _image_locks[image] = lock
    return lock


async def _probe_docker_image(image: str) -> tuple[str, str]:
    """Return (status, detail). status ∈ {present, missing, daemon_down,
    no_docker}."""
    try:
        proc = await asyncio.create_subprocess_exec(
            "docker", "image", "inspect", image,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
    except FileNotFoundError:
        return "no_docker", ""
    assert proc.stdout is not None
    output = (await proc.stdout.read()).decode("utf-8", errors="replace")
    rc = await proc.wait()
    if rc == 0:
        return "present", ""
    if "Cannot connect to the Docker daemon" in output:
        return "daemon_down", output.strip()
    return "missing", output.strip()


async def _build_image(image: str, dockerfile_dir: str, log: LogSink) -> None:
    if not os.path.isdir(dockerfile_dir):
        raise RuntimeError(
            f"cannot build {image}: dockerfile_dir {dockerfile_dir!r} does "
            f"not exist."
        )
    if not os.path.isfile(os.path.join(dockerfile_dir, "Dockerfile")):
        raise RuntimeError(
            f"cannot build {image}: no Dockerfile at "
            f"{os.path.join(dockerfile_dir, 'Dockerfile')!r}."
        )

    intro = (
        f"[sandbox] building image {image} from {dockerfile_dir} — first "
        f"run only, takes 2-5 minutes depending on network speed. "
        f"Subsequent runs reuse the cached image."
    )
    log(intro)
    print(intro, file=sys.stderr, flush=True)

    try:
        proc = await asyncio.create_subprocess_exec(
            "docker", "build", "-t", image, dockerfile_dir,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
    except FileNotFoundError:
        raise RuntimeError(
            f"`docker` not found on PATH while trying to build {image}. "
            "Install Docker Desktop or docker-ce."
        )
    assert proc.stdout is not None

    while True:
        raw = await proc.stdout.readline()
        if not raw:
            break
        line = raw.decode("utf-8", errors="replace").rstrip()
        log(f"[sandbox build {image}] {line}")
        print(f"[sandbox build {image}] {line}", file=sys.stderr, flush=True)

    rc = await proc.wait()
    if rc != 0:
        raise RuntimeError(
            f"`docker build` failed (exit {rc}) for {image}. See "
            f"[sandbox build {image}] lines above."
        )

    done = f"[sandbox] image {image} built"
    log(done)
    print(done, file=sys.stderr, flush=True)


async def _ensure_image(image: str, dockerfile_dir: str, log: LogSink) -> None:
    """Guarantee ``image`` exists on the local Docker daemon. Idempotent
    once an image has been verified within this process."""
    if _known_images.get(image):
        return
    lock = _image_lock(image)
    if lock.locked():
        log(f"[sandbox] waiting for in-progress {image} build...")
    async with lock:
        if _known_images.get(image):
            return
        status, detail = await _probe_docker_image(image)
        if status == "present":
            _known_images[image] = True
            return
        if status == "no_docker":
            raise RuntimeError(
                "`docker` not found on PATH. Install Docker Desktop or "
                "docker-ce."
            )
        if status == "daemon_down":
            raise RuntimeError(
                "Docker is installed but the daemon is not reachable. Start "
                "Docker Desktop (or `sudo systemctl start docker` on Linux)."
                f"\nRaw error:\n{detail}"
            )
        await _build_image(image, dockerfile_dir, log)
        _known_images[image] = True


# ---------------------------------------------------------------------------
# Daemon container — one running docker subprocess hosting the image's
# daemon process. The host owns lifecycle.
# ---------------------------------------------------------------------------

EventDispatcher = Callable[[dict], Awaitable[None]]


@dataclass
class DaemonContainer:
    image: str
    container_id: str
    process: asyncio.subprocess.Process
    stdin: asyncio.StreamWriter
    stdout: asyncio.StreamReader
    stderr: asyncio.StreamReader
    # session_id -> dispatcher coroutine called for each event tagged
    # with that session_id. The session owner registers itself on
    # open_session and unregisters on close.
    dispatchers: dict[str, EventDispatcher] = field(default_factory=dict)
    # Per-session ready signals — set when session_opened arrives.
    session_opened: dict[str, asyncio.Event] = field(default_factory=dict)
    session_closed: dict[str, asyncio.Event] = field(default_factory=dict)
    _stdin_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    _drain_task: Optional[asyncio.Task] = None
    _stderr_task: Optional[asyncio.Task] = None
    _shutting_down: bool = False
    # Reference count — number of open sessions. Daemon dies when this
    # hits zero.
    refcount: int = 0

    async def send_op(self, op: dict[str, Any]) -> None:
        line = (json.dumps(op, ensure_ascii=False) + "\n").encode("utf-8")
        async with self._stdin_lock:
            self.stdin.write(line)
            await self.stdin.drain()

    async def shutdown(self) -> None:
        self._shutting_down = True
        try:
            await self.send_op({"op": "shutdown"})
        except Exception:
            # Routine when the daemon already died — stdin pipe is gone.
            _logger.debug(
                "[sandbox %s] shutdown op not delivered (daemon likely already exited)",
                self.container_id, exc_info=True,
            )
        try:
            self.stdin.close()
        except Exception:
            _logger.debug(
                "[sandbox %s] stdin close failed (already closed?)",
                self.container_id, exc_info=True,
            )
        if self._drain_task is not None:
            self._drain_task.cancel()
        if self._stderr_task is not None:
            self._stderr_task.cancel()
        try:
            await asyncio.wait_for(self.process.wait(), timeout=5)
        except (asyncio.TimeoutError, ProcessLookupError):
            try:
                self.process.kill()
            except ProcessLookupError:
                pass


async def _spawn_container(
    image: str,
    dockerfile_dir: str,
    log: LogSink,
) -> DaemonContainer:
    """Run ``docker run`` for ``image``, wait for the daemon's ``ready``
    event, return the live container handle. The caller is responsible
    for opening sessions on it."""
    await _ensure_image(image, dockerfile_dir, log)

    container_id = f"collimate-sandbox-{uuid.uuid4().hex[:8]}"
    claude_home = os.path.expanduser("~/.claude")
    claude_json = os.path.expanduser("~/.claude.json")

    volume_mounts: list[str] = []
    if os.path.isdir(claude_home):
        volume_mounts += ["-v", f"{claude_home}:/home/coder/.claude:rw"]
    if os.path.isfile(claude_json):
        volume_mounts += ["-v", f"{claude_json}:/home/coder/.claude.json:rw"]

    try:
        proc = await asyncio.create_subprocess_exec(
            "docker", "run", "--rm", "-i",
            "--name", container_id,
            *volume_mounts,
            image,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except FileNotFoundError:
        raise RuntimeError(
            f"`docker` not found on PATH when spawning {image}. "
            "Install Docker Desktop or docker-ce."
        )

    if proc.stdin is None or proc.stdout is None or proc.stderr is None:
        raise RuntimeError("docker run did not expose stdio pipes")

    stderr_tail: deque[str] = deque(maxlen=50)
    assert proc.stdin is not None and proc.stdout is not None \
        and proc.stderr is not None  # all PIPEd above
    container = DaemonContainer(
        image=image,
        container_id=container_id,
        process=proc,
        stdin=proc.stdin,
        stdout=proc.stdout,
        stderr=proc.stderr,
    )

    stderr_reader = proc.stderr

    async def _drain_stderr() -> None:
        while True:
            line = await stderr_reader.readline()
            if not line:
                break
            text = line.decode("utf-8", errors="replace").rstrip()
            stderr_tail.append(text)
            _logger.info("[sandbox %s] %s", container_id, text)
            log(f"[sandbox {container_id}] {text}")

    container._stderr_task = asyncio.create_task(_drain_stderr())

    # Force-kill the just-spawned container if anything below this
    # point raises before we hand it to the caller. Without this, a
    # JSON-decode error on the daemon's first line, or an asyncio
    # error scheduling the drain task, would leak a running
    # `--rm`-flagged container that nobody owns and that
    # ``reap_orphan_containers`` only sweeps on the next API restart.
    async def _kill_orphan(reason: str) -> None:
        try:
            log(f"[sandbox {container_id}] aborting spawn ({reason}); killing container")
        except Exception:
            _logger.debug(
                "[sandbox %s] log sink raised during spawn abort",
                container_id, exc_info=True,
            )
        try:
            await asyncio.create_subprocess_exec(
                "docker", "kill", container_id,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
        except Exception:
            # If docker kill can't even be spawned the container may leak
            # until reap_orphan_containers runs — worth surfacing.
            _logger.warning(
                "[sandbox %s] docker kill during spawn abort failed",
                container_id, exc_info=True,
            )
        try:
            proc.kill()
        except Exception:
            _logger.debug(
                "[sandbox %s] proc.kill during spawn abort failed (already gone?)",
                container_id, exc_info=True,
            )
        if container._stderr_task is not None:
            try:
                container._stderr_task.cancel()
            except Exception:
                _logger.debug(
                    "[sandbox %s] stderr task cancel failed during spawn abort",
                    container_id, exc_info=True,
                )

    try:
        # Wait for the daemon-level "ready" event before returning.
        first_raw = await proc.stdout.readline()
        if not first_raw:
            try:
                await asyncio.wait_for(proc.wait(), timeout=2)
            except asyncio.TimeoutError:
                pass
            if container._stderr_task is not None:
                try:
                    await asyncio.wait_for(
                        asyncio.shield(container._stderr_task), timeout=1,
                    )
                except (asyncio.TimeoutError, Exception):
                    pass
            tail = "\n".join(stderr_tail) if stderr_tail else "(no stderr captured)"
            # Process already exited (--rm self-cleans), so skip
            # _kill_orphan; just raise the diagnostic error.
            raise RuntimeError(
                f"sandbox {container_id} ({image}) exited (rc={proc.returncode}) "
                f"before emitting `ready`. Last stderr:\n{tail}"
            )

        try:
            first = json.loads(first_raw.decode("utf-8", errors="replace"))
        except json.JSONDecodeError as exc:
            await _kill_orphan(f"non-JSON first line: {first_raw!r}")
            raise RuntimeError(
                f"sandbox {container_id} ({image}) emitted non-JSON on first "
                f"line: {first_raw!r} ({exc})"
            )
        if first.get("type") != "ready":
            _logger.warning(
                "sandbox %s first event was %r, not 'ready'",
                container_id, first,
            )

        # Start the multiplexing event drain — events get routed to the
        # right session's dispatcher by ``session_id`` field.
        container._drain_task = asyncio.create_task(_drain_events(container))
    except Exception:
        # Any other path reaching here (asyncio CancelledError mid-
        # await, OOM creating the drain task, etc.) — still kill the
        # container before re-raising so it doesn't outlive the caller.
        if proc.returncode is None:
            await _kill_orphan("spawn raised after docker run started")
        raise

    return container


async def _drain_events(container: DaemonContainer) -> None:
    """Read every line off the daemon's stdout, parse JSON, route to the
    matching session's dispatcher. session-less events are logged."""
    while True:
        try:
            raw = await container.stdout.readline()
        except Exception as exc:
            _logger.warning(
                "[sandbox %s] stdout read failed: %s",
                container.container_id, exc,
            )
            break
        if not raw:
            if not container._shutting_down:
                _logger.info(
                    "[sandbox %s] daemon stdout closed; tearing down "
                    "container", container.container_id,
                )
            break
        try:
            event = json.loads(raw.decode("utf-8", errors="replace"))
        except json.JSONDecodeError:
            _logger.warning(
                "[sandbox %s] non-JSON on stdout: %r",
                container.container_id, raw[:200],
            )
            continue

        evt_type = event.get("type")
        sid = event.get("session_id") or ""

        if evt_type == "session_opened":
            ev = container.session_opened.get(sid)
            if ev is not None:
                ev.set()
            continue
        if evt_type == "session_closed":
            ev = container.session_closed.get(sid)
            if ev is not None:
                ev.set()
            continue

        dispatcher = container.dispatchers.get(sid)
        if dispatcher is None:
            _logger.debug(
                "[sandbox %s] event for unknown session %r: %r",
                container.container_id, sid, evt_type,
            )
            continue
        try:
            await dispatcher(event)
        except Exception as exc:
            _logger.exception(
                "[sandbox %s] dispatcher for session %s raised: %s",
                container.container_id, sid, exc,
            )

    # Daemon died. Notify any still-attached dispatchers with a synthetic
    # error so blocked send_turn calls unblock instead of hanging.
    for sid, dispatcher in list(container.dispatchers.items()):
        try:
            await dispatcher({
                "type": "error",
                "session_id": sid,
                "turn_id": "",
                "message": "sandbox daemon exited unexpectedly",
            })
            await dispatcher({
                "type": "turn_end",
                "session_id": sid,
                "turn_id": "",
                "usage": {},
            })
        except Exception:
            # Best-effort wake-up of sessions on a daemon that just died;
            # the dispatcher itself may already be torn down.
            _logger.debug(
                "[sandbox %s] post-mortem dispatch to session %s failed",
                container.container_id, sid, exc_info=True,
            )


# ---------------------------------------------------------------------------
# Registry — one entry per image (for shared=True). Refcounted by sessions.
# ---------------------------------------------------------------------------

_shared_containers: dict[str, DaemonContainer] = {}
_registry_lock = asyncio.Lock()


@dataclass
class SandboxSession:
    """Handle returned to the host-side session owner."""
    container: DaemonContainer
    session_id: str
    image: str
    shared: bool

    async def send_op(self, op: dict[str, Any]) -> None:
        op = dict(op)
        op["session_id"] = self.session_id
        await self.container.send_op(op)


async def open_session(
    image: str,
    dockerfile_dir: str,
    session_id: str,
    model: str,
    system_prompt: str,
    dispatcher: EventDispatcher,
    shared: bool = True,
    log: LogSink = _noop_log,
) -> SandboxSession:
    """Open a session inside a daemon for ``image``.

    If ``shared`` and a daemon for the image is already running, a new
    session is multiplexed into it. Otherwise a fresh container is
    spawned. ``dispatcher`` is invoked for every event the daemon emits
    tagged with ``session_id``.
    """
    if shared:
        async with _registry_lock:
            container = _shared_containers.get(image)
            if container is not None and container._shutting_down:
                # A concurrent close_session decided to retire this
                # container but hasn't pulled it from the registry yet.
                # Don't multiplex into a dying daemon — replace it.
                container = None
            if container is None:
                log(f"[sandbox] starting shared daemon for image {image}")
                container = await _spawn_container(image, dockerfile_dir, log)
                _shared_containers[image] = container
                log(
                    f"[sandbox] shared daemon for {image} ready "
                    f"(container {container.container_id})"
                )
    else:
        log(f"[sandbox] starting fresh daemon for image {image}")
        container = await _spawn_container(image, dockerfile_dir, log)
        log(
            f"[sandbox] daemon for {image} ready "
            f"(container {container.container_id})"
        )

    if session_id in container.dispatchers:
        # Already open inside this container — reuse without re-issuing
        # open_session. The caller is responsible for treating this as
        # idempotent (refcount is NOT incremented on a re-open).
        return SandboxSession(
            container=container, session_id=session_id,
            image=image, shared=shared,
        )

    container.dispatchers[session_id] = dispatcher
    container.session_opened[session_id] = asyncio.Event()
    container.session_closed[session_id] = asyncio.Event()
    container.refcount += 1
    log(
        f"[sandbox] opening session {session_id} on {container.container_id} "
        f"(model={model!r})"
    )
    try:
        await container.send_op({
            "op": "open_session",
            "session_id": session_id,
            "model": model,
            "system_prompt": system_prompt,
        })
        try:
            await asyncio.wait_for(
                container.session_opened[session_id].wait(), timeout=60,
            )
        except asyncio.TimeoutError:
            raise RuntimeError(
                f"sandbox session {session_id} did not open within 60s"
            )
    except Exception:
        # Roll back the bookkeeping and tear down if needed. The flag is
        # set synchronously with the refcount decision so a concurrent
        # open_session can't multiplex into the container while retire
        # is still in flight.
        container.dispatchers.pop(session_id, None)
        container.session_opened.pop(session_id, None)
        container.session_closed.pop(session_id, None)
        container.refcount = max(0, container.refcount - 1)
        if container.refcount == 0:
            container._shutting_down = True
            await _retire_container(image, container, shared, log)
        raise

    return SandboxSession(
        container=container, session_id=session_id,
        image=image, shared=shared,
    )


async def close_session(
    session: SandboxSession,
    log: LogSink = _noop_log,
) -> None:
    """Close a session inside its daemon. Decrements refcount; if it
    drops to zero the container is shut down."""
    container = session.container
    sid = session.session_id

    if sid not in container.dispatchers:
        return  # already closed / never opened

    log(
        f"[sandbox] closing session {sid} on {container.container_id} "
        f"(image {session.image})"
    )
    try:
        await container.send_op({"op": "close_session", "session_id": sid})
        try:
            ev = container.session_closed.get(sid)
            if ev is not None:
                await asyncio.wait_for(ev.wait(), timeout=10)
        except asyncio.TimeoutError:
            _logger.warning(
                "[sandbox %s] close_session ack for %s timed out",
                container.container_id, sid,
            )
    except Exception as exc:
        _logger.warning(
            "[sandbox %s] close_session for %s failed: %s",
            container.container_id, sid, exc,
        )

    container.dispatchers.pop(sid, None)
    container.session_opened.pop(sid, None)
    container.session_closed.pop(sid, None)
    container.refcount = max(0, container.refcount - 1)

    if container.refcount == 0:
        # Mark the container dying in the same synchronous block as the
        # refcount decision: _retire_container awaits the registry lock
        # before pulling the entry, and a concurrent open_session must
        # not multiplex into the container during that window.
        container._shutting_down = True
        await _retire_container(session.image, container, session.shared, log)


async def _retire_container(
    image: str,
    container: DaemonContainer,
    shared: bool,
    log: LogSink,
) -> None:
    """Tear down a container that has no open sessions. Removes it from
    the shared registry first so a concurrent open_session for the same
    image spawns a fresh one rather than reusing a dying container."""
    if shared:
        async with _registry_lock:
            if _shared_containers.get(image) is container:
                _shared_containers.pop(image, None)
    log(
        f"[sandbox] tearing down daemon for image {image} "
        f"(container {container.container_id}, refcount=0)"
    )
    try:
        await container.shutdown()
    except Exception as exc:
        _logger.warning(
            "[sandbox %s] shutdown failed: %s", container.container_id, exc,
        )


# ---------------------------------------------------------------------------
# Process-exit hooks — used from FastAPI lifespan to make sure no
# containers are left behind when the API shuts down.
# ---------------------------------------------------------------------------

async def shutdown_all(log: LogSink = _noop_log) -> None:
    """Tear down every shared container the registry knows about."""
    async with _registry_lock:
        items = list(_shared_containers.items())
        _shared_containers.clear()
    for image, container in items:
        log(f"[sandbox] shutdown_all: retiring {image}")
        try:
            await container.shutdown()
        except Exception as exc:
            _logger.warning(
                "[sandbox %s] shutdown_all failed: %s",
                container.container_id, exc,
            )


def reap_orphan_containers() -> None:
    """Remove any collimate-sandbox-* containers left behind by a previous
    API process that crashed. Best-effort; failures are swallowed."""
    try:
        result = subprocess.run(
            ["docker", "ps", "-aq", "--filter", "name=^collimate-sandbox-"],
            capture_output=True, text=True, timeout=5,
        )
        ids = [x for x in result.stdout.strip().splitlines() if x]
        if ids:
            _logger.info(
                "[sandbox] removing %d orphaned collimate-sandbox container(s)",
                len(ids),
            )
            subprocess.run(
                ["docker", "rm", "-f", *ids],
                capture_output=True, timeout=30,
            )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    except Exception as exc:
        _logger.warning("[sandbox] orphan reaper failed: %s", exc)
