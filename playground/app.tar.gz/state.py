import os
from fastapi import HTTPException
from models import AppState, Channel, Stack, Cell, Message, VirtualFile, Role

state = AppState()

current_dir = os.path.dirname(os.path.abspath(__file__))


def get_active_channel() -> Channel:
    if not state.active_channel_id:
        raise HTTPException(status_code=404, detail="No active channel")
    ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
    if not ch:
        raise HTTPException(status_code=404, detail="Channel not found")
    return ch

def channel_db_name(channel: Channel) -> str:
    """Derive a safe SQLite filename from the channel name."""
    slug = channel.name.lower().replace(" ", "_")
    safe = "".join(c for c in slug if c.isalnum() or c in "_-")
    return safe or str(channel.id).replace("-", "")

def persist_state():
    """Save the full AppState JSON blob to every channel's SQLite db and broadcast via SSE."""
    try:
        from genesis import save_channel_ui_state
        state_dict = state.model_dump(mode="json")
        for ch in state.channels:
            db_name = channel_db_name(ch)
            save_channel_ui_state(db_name, state_dict)
        # Broadcast state update to all SSE subscribers
        _broadcast_state_update(state_dict)
    except Exception:
        pass  # Persistence is best-effort; never crash the API


_ALWAYS_INLINE_NAMES = frozenset((
    ".collimate_messages.json",
    ".colreserved/.collimate_messages.json",
))


def strip_large_content(state_dict: dict, max_inline_bytes: int = 50_000) -> dict:
    """Strip file content from the state for files larger than the threshold.

    Files named .collimate_messages.json are always inlined (needed for chat display).
    Files smaller than max_inline_bytes are inlined.
    Larger files get content="" and is_loaded=False.

    Callers pass a freshly-serialized dict from ``state.model_dump(mode="json")``
    that no one else holds a reference to, so we mutate it in place rather than
    paying for a full ``copy.deepcopy`` on every broadcast. Cells whose files
    all fit under the threshold are left untouched — no list rebuild.
    """
    for ch in state_dict.get("channels", []):
        for stack_list_key in ("main_stacks", "nav_stacks"):
            for stack in ch.get(stack_list_key, []):
                for cell in stack.get("cells", []):
                    files = cell.get("files")
                    if not files:
                        continue
                    needs_strip = False
                    for f in files:
                        if f.get("name") in _ALWAYS_INLINE_NAMES:
                            continue
                        if len(f.get("content", "")) > max_inline_bytes:
                            needs_strip = True
                            break
                    if not needs_strip:
                        continue
                    for i, f in enumerate(files):
                        if f.get("name") in _ALWAYS_INLINE_NAMES:
                            continue
                        if len(f.get("content", "")) > max_inline_bytes:
                            files[i] = {**f, "content": "", "is_loaded": False}
    return state_dict


def _broadcast_state_update(state_dict: dict):
    """Push a state_update event to SSE subscribers for all channels."""
    try:
        from events import broadcast
        stripped = strip_large_content(state_dict)
        for ch in state.channels:
            db_name = channel_db_name(ch)
            broadcast(db_name, {"type": "state_update", "state": stripped})
    except Exception:
        pass

