import asyncio
import os
import threading
from fastapi import HTTPException
from models import AppState, Channel

state = AppState()

current_dir = os.path.dirname(os.path.abspath(__file__))


# Serializes any mutate-then-broadcast sequence against concurrent
# writers. Two ProcessManagers running cell updates in parallel worker
# threads (e.g. two live-chat cells active at once) both call
# _apply_update_to_state → persist_state. Without a lock, manager B's
# mutation of state.channels can interleave with manager A's
# model_dump and capture a half-A / half-B state, which then gets
# persisted and broadcast — surfacing as cells flickering or
# reverting in the UI when chats run side by side.
#
# Reentrant because the call sites that hold the lock for the mutation
# block (e.g. _apply_update_to_state) call persist_state() inside —
# the inner acquire would deadlock a plain Lock.
state_lock = threading.RLock()


def get_active_channel() -> Channel:
    if not state.active_channel_id:
        raise HTTPException(status_code=404, detail="No active channel")
    ch = next((c for c in state.channels if c.id == state.active_channel_id), None)
    if not ch:
        raise HTTPException(status_code=404, detail="Channel not found")
    return ch

def channel_name_slug(name: str) -> str:
    """The name-derived db slug (no channel-id fallback). When this is empty
    the name has no DB-addressable form — ``channel_db_name`` then falls back
    to the channel id, which is the slug-divergence hazard validation guards
    against. Mirrors ``database._slug_channel``'s character rule."""
    slug = (name or "").lower().replace(" ", "_")
    return "".join(c for c in slug if c.isalnum() or c in "_-")


def channel_db_name(channel: Channel) -> str:
    """Derive a safe SQLite filename from the channel name."""
    return channel_name_slug(channel.name) or str(channel.id).replace("-", "")


def validate_channel_name(name: str) -> str:
    """Return the trimmed name, or raise 400 if it's blank or has no
    DB-addressable slug. A name of only symbols/punctuation collapses to an
    empty slug, which would split the channel's DB across two filenames (the
    writer keys by channel id, a raw-name reader by the name) — a channel
    isolation hazard. Reject it at the user-facing boundary instead."""
    cleaned = (name or "").strip()
    if not cleaned:
        raise HTTPException(400, "Channel name cannot be empty")
    if not channel_name_slug(cleaned):
        raise HTTPException(
            400,
            "Channel name must contain at least one letter, number, '_' or '-'",
        )
    return cleaned


def get_channel_by_db_name(db_name: str) -> Channel | None:
    """Return the channel whose ``channel_db_name`` matches ``db_name``, or
    None. ``db_name`` is a channel db-name slug (e.g. a run's
    ``ProcessManager.channel`` or a request's URL ``channel`` param, raw or
    pre-slugged). Run-context code uses this to recover its OWN Channel object
    instead of falling back to the globally-active channel — the channel
    isolation boundary. Slugging the input here mirrors ``channel_db_name``'s
    rule so a raw name and its slug both resolve to the same channel."""
    if not db_name:
        return None
    slug = channel_name_slug(db_name)
    return next((c for c in state.channels if channel_db_name(c) == slug), None)

def persist_state():
    """Save the full AppState JSON blob to every channel's SQLite db and broadcast via SSE.

    Auto-offloading: when called from the event loop (sync code
    inside an async route handler), the actual DB writes + broadcast
    are scheduled to a worker thread so the loop doesn't block. When
    called from a worker thread (cells.py / finalization.py mutate-
    then-persist sites) we run inline since we're already off-loop.

    Why offload: ``save_channel_ui_state`` is sync sqlite I/O and
    each channel's DB has WAL ``busy_timeout=5000``. If a generator-
    subprocess worker is mid-flush holding the SQLite write lock,
    the event loop's persist_state would wait up to 5s — and with
    two live chats each firing persist_state several times per
    second from worker threads, that lock contention turns into
    multi-second event-loop stalls. Offloading keeps the loop free
    while the broadcast still fires, just from a worker.

    Deliberately **lock-free** at the top level: call sites that
    need to coordinate against concurrent worker-thread mutations
    (cells.py _apply_update_to_state / _apply_commit_to_state,
    finalization mutators) hold ``state_lock`` themselves around
    the mutate-then-persist block. Pydantic v2's ``model_dump``
    reads attributes one at a time under the GIL — concurrent reads
    from a worker thread's mutation on a different cell don't tear
    (each .files reference flip is atomic). The dump may capture a
    one-step-stale snapshot, but the next persist_state call (which
    always pairs with a mutation) broadcasts the corrected state —
    eventual consistency, no half-state on the wire.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None
    if loop is not None:
        # On the event loop — fire-and-forget into a worker. The
        # SSE broadcast is asynchronous to begin with (clients
        # subscribe via SSE), so deferring by one thread hop is
        # invisible to consumers.
        loop.run_in_executor(None, _persist_state_sync)
        return
    _persist_state_sync()


def _persist_state_sync():
    """Sync body — runs DB writes + broadcast. Safe to call from any
    thread; deliberately no internal lock so concurrent persisters
    serialize only at the SQLite layer."""
    try:
        from genesis import save_channel_ui_state
        state_dict = state.model_dump(mode="json")
        for ch in state.channels:
            db_name = channel_db_name(ch)
            save_channel_ui_state(db_name, state_dict)
        # Broadcast state update to all SSE subscribers
        _broadcast_state_update(state_dict)
    except Exception:
        pass  # Persistence is best-effort; never crash the API


_ALWAYS_INLINE_NAMES = frozenset((
    ".colreserved/.collimate_messages.json",
))


def strip_large_content(state_dict: dict, max_inline_bytes: int = 50_000) -> dict:
    """Strip file content from the state for files larger than the threshold.

    Files named .collimate_messages.json are always inlined (needed for chat display).
    Files smaller than max_inline_bytes are inlined.
    Larger files get content="" and is_loaded=False.

    Callers pass a freshly-serialized dict from ``state.model_dump(mode="json")``
    that no one else holds a reference to, so we mutate it in place rather than
    paying for a full ``copy.deepcopy`` on every broadcast. Cells whose files
    all fit under the threshold are left untouched — no list rebuild.
    """
    for ch in state_dict.get("channels", []):
        for stack_list_key in ("main_stacks", "nav_stacks"):
            for stack in ch.get(stack_list_key, []):
                for cell in stack.get("cells", []):
                    files = cell.get("files")
                    if not files:
                        continue
                    needs_strip = False
                    for f in files:
                        if f.get("name") in _ALWAYS_INLINE_NAMES:
                            continue
                        if len(f.get("content", "")) > max_inline_bytes:
                            needs_strip = True
                            break
                    if not needs_strip:
                        continue
                    for i, f in enumerate(files):
                        if f.get("name") in _ALWAYS_INLINE_NAMES:
                            continue
                        if len(f.get("content", "")) > max_inline_bytes:
                            files[i] = {**f, "content": "", "is_loaded": False}
    return state_dict


def _broadcast_state_update(state_dict: dict):
    """Push a state_update event to SSE subscribers for all channels."""
    try:
        from events import broadcast
        stripped = strip_large_content(state_dict)
        for ch in state.channels:
            db_name = channel_db_name(ch)
            broadcast(db_name, {"type": "state_update", "state": stripped})
    except Exception:
        pass

