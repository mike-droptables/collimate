"""Live Chat — multi-turn pydantic-ai chat with read/write/edit tools.

Daemon-shaped (`chat: true` in manifest): one ``run()`` invocation
handles many turns. The first turn comes from ``gen.prompt`` (the
picker textarea); each subsequent user message arrives via
``gen.chat_loop``'s polling.

Tools scoped to this cell:

  * ``list_files``  — list workspace + staged output files
  * ``read_file``   — read any of them
  * ``write_file``  — create or overwrite a file in the output cell
  * ``edit_file``   — first-match string replace on a file
  * ``run_python``  — execute Python (matplotlib, pandas, …) against
    the cell's files. Helpers in scope read/write text and bytes, so
    the agent can answer compute-shaped queries and emit binary
    artifacts (PNG / SVG plots, archives) into the same cell.

Workspace files (from the input cell, if any) are carried forward into
the output automatically and re-synced from disk before each turn so
mid-flight user edits survive.

We use ``agent.run`` (non-streaming) rather than ``agent.run_stream``:
SSE streaming through pyodide's httpx-on-Fetch transport hangs in
practice, and once it hangs the cooperative ``gen.cancelled`` check
never runs, so Stop never fires. The non-streaming path returns the
full answer in one response and the per-turn driver polls
``gen.cancelled`` while the ``agent.run`` task is in flight — Stop
cancels the underlying httpx request directly.
"""
from __future__ import annotations

import asyncio

import gen
from collimate.llm import looks_like_auth_error


# Cancellation polling cadence. Short enough that Stop feels instant,
# long enough that an idle chat doesn't burn the event loop.
_POLL_INTERVAL_S = 0.2


class _Cancelled(Exception):
    """Internal signal: user pressed Stop while ``agent.run`` was in
    flight. The httpx task was cancelled; the daemon loop should
    finalise this turn cleanly."""


async def run() -> None:
    cfg = gen.config("pydantic-config.set_yaml")
    system_prompt = (cfg.get("system_prompt") or "").strip()
    provider = (cfg.get("provider") or "cerebras").strip().lower()

    cell_name = f"live-chat · {provider}"
    gen.log(f"[live-chat] preparing {provider}…")
    await gen.update(name=cell_name)

    try:
        agent_obj = await _make_agent(system_prompt)
    except Exception as e:
        gen.log(f"[live-chat] setup error: {e}")
        gen.history.append("assistant", f"_(setup failed: {e})_")
        await gen.update(name=f"{provider} · setup failed")
        return

    gen.log(f"[live-chat] {provider} ready")

    async for user_msg in gen.chat_loop():
        # Sync the output stage with the workspace before the agent
        # runs. The host flushes the user's pending cell drafts to the
        # workspace right before queueing this turn, so a fresh read
        # captures any mid-flight edits the user made. Without this,
        # the agent would read stale content and the end-of-turn
        # ``gen.update()`` would overwrite the user's edits with the
        # carried-over values — the "I edited but it reverted" bug.
        _resync_stage_from_workspace()

        gen.history.append("user", user_msg)
        await gen.update(name=cell_name)

        try:
            answer = await _run_turn(agent_obj, user_msg)
        except _Cancelled:
            gen.history.append("assistant", "_(stopped by user)_")
            await gen.update(name=cell_name)
            break
        except Exception as e:
            if looks_like_auth_error(e):
                gen.log(f"[live-chat] auth error: {e} — re-prompting for key")
                try:
                    await gen.api_key(
                        provider, force=True,
                        description=(
                            f"Previous {provider} key was rejected "
                            f"({type(e).__name__}). Enter a fresh API key."
                        ),
                    )
                except gen.Cancelled:
                    gen.history.append("assistant", "_(auth re-prompt cancelled)_")
                    await gen.update(name=cell_name)
                    break
                try:
                    agent_obj = await _make_agent(system_prompt)
                    answer = await _run_turn(agent_obj, user_msg)
                except _Cancelled:
                    gen.history.append("assistant", "_(stopped by user)_")
                    await gen.update(name=cell_name)
                    break
                except Exception as e2:
                    gen.log(f"[live-chat] retry failed: {e2}")
                    answer = f"**Error:** `{e2}`"
            else:
                gen.log(f"[live-chat] turn error: {e}")
                answer = f"**Error:** `{e}`"

        if not answer:
            answer = "_(empty response)_"
        gen.history.append("assistant", answer)
        await gen.update(name=cell_name)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _make_agent(system_prompt: str):
    """Build a fresh pydantic-ai Agent with the canonical file tools.
    Called at startup and again on auth-error retry."""
    # ``gen.file_tools()`` does ``from pydantic_ai import Tool`` at call
    # time, and Python evaluates the ``tools=`` argument before the
    # surrounding ``gen.agent()`` runs — so without an explicit bootstrap
    # here the first turn raises ``ModuleNotFoundError: No module named
    # 'pydantic_ai'`` before ensure_pydantic_ai ever fires.
    await gen.bootstrap()
    return await gen.agent(
        system_prompt=system_prompt,
        tools=gen.file_tools() + [gen.python_tool()],
    )


def _resync_stage_from_workspace() -> None:
    """Replace the staged output with the current workspace state.
    Mid-flight user edits to cell files land in the workspace via the
    host's chat_push_message flush; this pulls them back into the
    stage so the agent sees fresh content and the next ``gen.update``
    doesn't overwrite the user's edits."""
    fresh = gen.input_files()
    for path in gen.list_files():
        if path not in fresh:
            gen.delete_file(path)
    for path, content in fresh.items():
        gen.update_file(path, content)


async def _run_turn(agent_obj, user_msg: str) -> str:
    """Drive one ``agent.run`` while concurrently polling
    ``gen.cancelled``. Cancels the underlying httpx request promptly
    on Stop instead of blocking until the LLM finishes."""
    task = asyncio.create_task(
        agent_obj.run(user_msg, message_history=gen.history.as_pai())
    )
    while not task.done():
        if gen.cancelled:
            task.cancel()
            try:
                await task
            except BaseException:
                pass
            raise _Cancelled()
        await asyncio.sleep(_POLL_INTERVAL_S)
    result = task.result()
    for attr in ("output", "data"):
        val = getattr(result, attr, None)
        if val:
            return str(val)
    return str(result)
