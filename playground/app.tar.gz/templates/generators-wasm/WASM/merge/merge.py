"""Merge — flatten the files of 2+ input cells into a single output cell.

Multi-input runs hydrate as ``inputs/NN_slug/`` subfolders where the
``NN`` prefix is the input order (top = smallest number). We walk each
group in order and copy each file onto its rel-within-cell path; the
topmost cell wins on filename collisions.

No LLM. Deterministic.
"""
from __future__ import annotations

import gen


async def run() -> None:
    groups = gen.input_groups()
    if len(groups) < 2:
        gen.update_file(
            "_merge.md",
            "# Need 2+ inputs\n\nAttach at least two input cells.\n",
        )
        await gen.update(name="merge · too few inputs", summary="Need 2+ inputs",
                         summary_artifact="_merge.md")
        return

    origin: dict[str, str] = {}
    overwritten: list[tuple[str, str, str]] = []
    for label, files in groups.items():
        for path, content in files.items():
            if gen.has_file(path):
                if gen.read_file(path) != content:
                    overwritten.append((path, origin[path], label))
                continue
            gen.update_file(path, content)
            origin[path] = label

    lines = [f"# Merge — {len(groups)} cells, {len(origin)} file(s)", "", "## Origins", ""]
    for path in sorted(origin):
        lines.append(f"- `{path}` ← `{origin[path]}`")
    if overwritten:
        lines.append("")
        lines.append("## Shadowed by topmost input")
        lines.append("")
        for path, winner, loser in overwritten:
            lines.append(f"- `{path}` — `{winner}` won over `{loser}`")
    gen.update_file("_merge.md", "\n".join(lines) + "\n")

    await gen.update(
        name=f"Merge × {len(groups)}",
        summary=f"{len(origin)} files from {len(groups)} cells",
        summary_artifact="_merge.md",
    )
