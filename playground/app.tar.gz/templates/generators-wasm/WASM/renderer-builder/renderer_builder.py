"""Renderer Builder — scaffold a new renderer from a description.

Same shape as ``generator-builder`` but loads
``how-to-write-a-renderer.md`` as the reference and emits renderer
files (``manifest.rend_yaml`` + ``main.tsx``).

After the agent finishes, the staged ``manifest.rend_yaml`` is linted via
``collimate.lint.lint_renderer_manifest_data``. If lint errors are
found, the agent gets one retry with the errors fed back; if errors
persist, the run fails loudly rather than committing a broken renderer.
"""
from __future__ import annotations

import gen
import yaml
from collimate.lint import Level, lint_renderer_manifest_data
from collimate.shared import shared_path


GUIDE_FILENAME = "how-to-write-a-renderer.md"


async def run() -> None:
    prompt = (gen.prompt or "").strip()
    if not prompt:
        gen.update_file(
            "README.md",
            "# Empty prompt\n\nDescribe the renderer you want to build "
            "in the picker prompt.\n",
        )
        await gen.update(name="renderer-builder · no prompt",
                         summary="Empty prompt", summary_artifact="README.md")
        return

    # Input files are guidance only — clear the auto-carried stage.
    for p in list(gen.list_files()):
        gen.delete_file(p)

    try:
        guide = shared_path("docs", GUIDE_FILENAME).read_text(encoding="utf-8")
    except FileNotFoundError as e:
        gen.update_file("README.md", f"# Missing guide\n\n```\n{e}\n```\n")
        await gen.update(name="renderer-builder · guide missing",
                         summary="Guide missing", summary_artifact="README.md")
        return

    await gen.bootstrap()
    from pydantic_ai import Tool

    async def list_guidance() -> list[str]:
        """List any guidance files attached via the input cell. Reference
        only — do NOT copy them into the output."""
        return sorted(gen.input_files().keys())

    async def read_guidance(path: str) -> str:
        """Read a guidance file by relative path."""
        try:
            return gen.read_input(path)
        except OSError as e:
            return f"ERROR: {e}"

    async def write_file_t(path: str, content: str) -> str:
        """Write a file into the new renderer scaffold. Path is relative
        to the cell root (e.g. ``manifest.rend_yaml``, ``main.tsx``)."""
        gen.update_file(path, content)
        return f"wrote {len(content)} bytes to {path}"

    async def list_written() -> list[str]:
        """List the files written so far in this run."""
        return gen.list_files()

    tools = [
        Tool(list_guidance, name="list_guidance"),
        Tool(read_guidance, name="read_guidance"),
        Tool(write_file_t, name="write_file"),
        Tool(list_written, name="list_written"),
    ]

    system_prompt = (
        "You are scaffolding a complete, working Collimate renderer from "
        "a user description. Follow the reference guide below exactly — "
        "it is the authoritative spec for manifest.rend_yaml, the "
        "entrypoint module, and the runtime contract.\n\n"
        "Required files:\n"
        "  - manifest.rend_yaml\n"
        "  - main.tsx (or whatever the manifest declares as entrypoint)\n\n"
        "Use the write_file tool to emit every file in full. Do not "
        "abbreviate, do not use placeholders. When you're done, stop — do "
        "not describe the files in prose.\n\n"
        f"--- BEGIN REFERENCE GUIDE ---\n{guide}\n--- END REFERENCE GUIDE ---\n"
    )

    gen.update_file("README.md", "_(building renderer…)_\n")
    await gen.update(name="renderer-builder · building", summary="building renderer")
    gen.log(f"[renderer-builder] guide={len(guide)} chars, prompt={prompt[:80]!r}")

    try:
        agent_obj = await gen.agent(system_prompt=system_prompt, tools=tools)
        await agent_obj.run(
            f"Build a renderer that does the following:\n\n{prompt}\n\n"
            "Write every required file via write_file. Do not write README.md "
            "or any extra files — only the files the renderer needs to run."
        )
    except Exception as e:
        gen.log(f"[renderer-builder] error: {e}")
        gen.update_file("README.md", f"# Build error\n\n```\n{e}\n```\n")
        await gen.update(name="renderer-builder · error",
                         summary=str(e)[:120], summary_artifact="README.md")
        return

    if gen.has_file("README.md") and gen.read_file("README.md").startswith("_(building "):
        gen.delete_file("README.md")
    if not gen.list_files():
        gen.update_file(
            "README.md",
            "# No files produced\n\nThe agent returned without writing anything.\n",
        )
        await gen.update(name="renderer-builder · empty",
                         summary="No files produced", summary_artifact="README.md")
        return

    # Validate + one retry. See generator-builder for the same shape.
    errors = _lint_stage()
    if errors:
        gen.log(f"[renderer-builder] lint errors after first agent run: {len(errors)}")
        try:
            await agent_obj.run(_fix_prompt(errors))
        except Exception as e:
            gen.update_file("README.md", _build_error_md(errors, retry_exc=str(e)))
            await gen.update(name="renderer-builder · invalid",
                             summary="Manifest invalid; retry failed",
                             summary_artifact="README.md")
            return
        errors = _lint_stage()

    if errors:
        gen.update_file("README.md", _build_error_md(errors, retry_exc=None))
        await gen.update(name="renderer-builder · invalid",
                         summary="Manifest still invalid after retry",
                         summary_artifact="README.md")
        return

    sa = "manifest.rend_yaml" if gen.has_file("manifest.rend_yaml") else gen.list_files()[0]
    await gen.update(
        name="renderer scaffold",
        summary=f"{len(gen.list_files())} file(s) · entry: `{sa}`",
        summary_artifact=sa,
    )


def _lint_stage() -> list[str]:
    """Lint the staged ``manifest.rend_yaml``. Returns a list of error
    strings (empty when valid)."""
    if not gen.has_file("manifest.rend_yaml"):
        return ["manifest.rend_yaml was not written"]
    raw = gen.read_file("manifest.rend_yaml")
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8", errors="replace")
    try:
        data = yaml.safe_load(raw)
    except yaml.YAMLError as e:
        return [f"manifest.rend_yaml is not valid YAML: {e}"]
    files_present = {p for p in gen.list_files() if isinstance(p, str)}
    issues = lint_renderer_manifest_data(
        data if isinstance(data, dict) else {},
        files_present=files_present,
    )
    return [
        f"{i.field or '<root>'}: {i.message}"
        for i in issues
        if i.level == Level.ERROR
    ]


def _fix_prompt(errors: list[str]) -> str:
    bullets = "\n".join(f"  - {e}" for e in errors)
    return (
        "Your previous output has the following manifest problems. "
        "Fix EVERY one of them by re-emitting the corrected files via "
        "write_file. Do not write README.md or any explanation files — "
        "just the corrected manifest and any other files that need "
        f"updating.\n\n{bullets}\n"
    )


def _build_error_md(errors: list[str], *, retry_exc: str | None) -> str:
    bullets = "\n".join(f"- {e}" for e in errors)
    suffix = (
        f"\n\nThe retry attempt also failed: `{retry_exc}`."
        if retry_exc
        else "\n\nThe agent re-emitted files but the manifest is still invalid."
    )
    return (
        "# Renderer scaffold rejected\n\n"
        "The generated `manifest.rend_yaml` doesn't satisfy the contract. "
        "Common causes: missing required fields, `entrypoint:` "
        "referencing a file the agent didn't write, or unknown manifest "
        f"fields.\n\n{bullets}{suffix}\n"
    )
