"""Generator Builder — scaffold a new WASM generator from a description.

The system prompt is the full ``how-to-write-a-wasm-generator.md`` guide,
read from the cell-local ``_shared_docs/`` sibling (seeded into the Builder
cell from the SDK's ``shared/docs/``) via ``collimate.shared.shared_doc``.
The agent emits
files into the output stage via ``write_file``; at minimum a
``manifest.gen_yaml`` and the entrypoint ``.py`` should land.

Input files (if any) are exposed as read-only guidance via
``list_guidance``/``read_guidance`` — they do **not** carry through to
the output. Only files the agent writes land in the new cell.

After the agent finishes, the staged ``manifest.gen_yaml`` is linted via
``collimate.lint.lint_generator_manifest_data`` with
wasm generators. If lint errors are found, the agent gets one
retry with the errors fed back as a fix prompt; if errors persist after
the retry, the run fails loudly rather than committing a broken
generator that "doesn't show up" or fails at run time.
"""
from __future__ import annotations

import gen
import yaml
from collimate.lint import Level, lint_generator_manifest_data
from collimate.shared import shared_doc


GUIDE_FILENAME = "how-to-write-a-wasm-generator.md"


async def run() -> None:
    prompt = (gen.prompt or "").strip()
    if not prompt:
        gen.update_file(
            "README.md",
            "# Empty prompt\n\nDescribe the generator you want to build "
            "in the picker prompt.\n",
        )
        await gen.update(name="generator-builder · no prompt",
                         summary="Empty prompt", pinned="README.md")
        return

    # Input files are guidance only — clear the auto-carried stage so
    # only files the agent writes land in the output.
    for p in list(gen.list_files()):
        gen.delete_file(p)

    try:
        guide = shared_doc(GUIDE_FILENAME, near=__file__).read_text(encoding="utf-8")
    except FileNotFoundError as e:
        gen.update_file("README.md", f"# Missing guide\n\n```\n{e}\n```\n")
        await gen.update(name="generator-builder · guide missing",
                         summary="Guide missing", pinned="README.md")
        return

    await gen.bootstrap()
    from pydantic_ai import Tool

    async def list_guidance() -> list[str]:
        """List any guidance files attached via the input cell. Reference
        only — do NOT copy them into the output."""
        return sorted(gen.input_files().keys())

    async def read_guidance(path: str) -> str:
        """Read a guidance file by relative path."""
        try:
            return gen.read_input(path)
        except OSError as e:
            return f"ERROR: {e}"

    async def write_file_t(path: str, content: str) -> str:
        """Write a file into the new scaffold. Path is relative to the
        new cell root (e.g. ``manifest.gen_yaml``, ``my_gen.py``)."""
        gen.update_file(path, content)
        return f"wrote {len(content)} bytes to {path}"

    async def list_written() -> list[str]:
        """List the files written so far in this run."""
        return gen.list_files()

    tools = [
        Tool(list_guidance, name="list_guidance"),
        Tool(read_guidance, name="read_guidance"),
        Tool(write_file_t, name="write_file"),
        Tool(list_written, name="list_written"),
    ]

    system_prompt = _system_prompt(guide)

    gen.update_file("README.md", "_(building generator…)_\n")
    await gen.update(name="generator-builder · building",
                     summary="building generator")
    gen.log(f"[generator-builder] guide={len(guide)} chars, prompt={prompt[:80]!r}")

    try:
        agent_obj = await gen.agent(system_prompt=system_prompt, tools=tools)
        await agent_obj.run(
            f"Build a generator that does the following:\n\n{prompt}\n\n"
            "Write every required file via write_file. Do not write "
            "README.md, notes.md, or any extra files — only the files "
            "the generator needs to run."
        )
    except Exception as e:
        gen.log(f"[generator-builder] error: {e}")
        gen.update_file("README.md", f"# Build error\n\n```\n{e}\n```\n")
        await gen.update(name="generator-builder · error",
                         summary=str(e)[:120], pinned="README.md")
        return

    # Drop the placeholder README the build emitted at run-start; the
    # agent's actual files supersede it. If the agent never wrote
    # anything, surface that explicitly.
    if gen.has_file("README.md") and gen.read_file("README.md").startswith("_(building "):
        gen.delete_file("README.md")
    if not gen.list_files():
        gen.update_file(
            "README.md",
            "# No files produced\n\nThe agent returned without writing anything.\n",
        )
        await gen.update(name="generator-builder · empty",
                         summary="No files produced", pinned="README.md")
        return

    # Validate the agent's output. One retry if invalid — feed the
    # errors back as a fix-it message and let the agent re-emit the
    # bad files. Hard-fail if the second attempt is also invalid: a
    # broken scaffold that "looks right" but won't show up in the
    # picker (or worse, shows up but fails at run-time) is a worse UX
    # than a failed build with a specific error list.
    errors = _lint_stage()
    if errors:
        gen.log(f"[generator-builder] lint errors after first agent run: {len(errors)}")
        try:
            await agent_obj.run(_fix_prompt(errors))
        except Exception as e:
            gen.update_file(
                "README.md",
                _build_error_md(errors, retry_exc=str(e)),
            )
            await gen.update(name="generator-builder · invalid",
                             summary="Manifest invalid; retry failed",
                             pinned="README.md")
            return
        errors = _lint_stage()

    if errors:
        gen.update_file("README.md", _build_error_md(errors, retry_exc=None))
        await gen.update(name="generator-builder · invalid",
                         summary="Manifest still invalid after retry",
                         pinned="README.md")
        return

    sa = "manifest.gen_yaml" if gen.has_file("manifest.gen_yaml") else (
        gen.list_files()[0] if gen.list_files() else ""
    )
    await gen.update(
        name="generator scaffold",
        summary=f"{len(gen.list_files())} file(s) · entry: `{sa}`",
        pinned=sa,
    )


def _system_prompt(guide: str) -> str:
    required = (
        "Required files:\n"
        "  - manifest.gen_yaml (MUST declare a `type` — a list of 1-2 of "
        "{\"modify\", \"create\"}; do NOT add a "
        "`runtime:` field — runtime is determined by the folder the "
        "generator lives in, and `runtime` is an unknown manifest field "
        "that lints as a warning)\n"
        "  - <id>.py entrypoint matching the manifest's 'entrypoint' field\n"
        "  - pydantic-config.set_yaml or any declared draft files "
        "(only if the manifest lists them under `draft_files`)\n"
    )
    return (
        "You are scaffolding a complete, working Collimate generator "
        "from a user description. Follow the reference guide below "
        "exactly — it is the authoritative spec for manifest schema, "
        "SDK API, and file layout.\n\n"
        f"{required}\n"
        "Use the write_file tool to emit every file in full. Do not "
        "abbreviate, do not use placeholders. When you're done, stop — do "
        "not describe the files in prose.\n\n"
        f"--- BEGIN REFERENCE GUIDE ---\n{guide}\n--- END REFERENCE GUIDE ---\n"
    )


def _lint_stage() -> list[str]:
    """Lint the staged ``manifest.gen_yaml`` against the wasm runtime
    contract. Returns a list of human-readable error strings (empty when
    valid). Warnings are not surfaced — only hard errors block commit.
    """
    if not gen.has_file("manifest.gen_yaml"):
        return ["manifest.gen_yaml was not written"]
    raw = gen.read_file("manifest.gen_yaml")
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8", errors="replace")
    try:
        data = yaml.safe_load(raw)
    except yaml.YAMLError as e:
        return [f"manifest.gen_yaml is not valid YAML: {e}"]
    files_present = {p for p in gen.list_files() if isinstance(p, str)}
    # Content-level checks (config-tag fields, required-on-checkbox)
    # only read .set_yaml bodies — feed just those.
    file_contents: dict[str, str] = {}
    for p in files_present:
        if not p.endswith(".set_yaml"):
            continue
        raw_set = gen.read_file(p)
        if isinstance(raw_set, bytes):
            raw_set = raw_set.decode("utf-8", errors="replace")
        if isinstance(raw_set, str):
            file_contents[p] = raw_set
    issues = lint_generator_manifest_data(
        data if isinstance(data, dict) else {},
        files_present=files_present,
        file_contents=file_contents,
    )
    return [
        f"{i.field or '<root>'}: {i.message}"
        for i in issues
        if i.level == Level.ERROR
    ]


def _fix_prompt(errors: list[str]) -> str:
    bullets = "\n".join(f"  - {e}" for e in errors)
    return (
        "Your previous output has the following manifest problems. "
        "Fix EVERY one of them by re-emitting the corrected files via "
        "write_file. Do not write README.md or any explanation files — "
        "just the corrected manifest and any other files that need "
        f"updating.\n\n{bullets}\n"
    )


def _build_error_md(errors: list[str], *, retry_exc: str | None) -> str:
    bullets = "\n".join(f"- {e}" for e in errors)
    suffix = (
        f"\n\nThe retry attempt also failed: `{retry_exc}`."
        if retry_exc
        else "\n\nThe agent re-emitted files but the manifest is still invalid."
    )
    return (
        "# Generator scaffold rejected\n\n"
        "The generated `manifest.gen_yaml` doesn't satisfy the runtime "
        "contract. Common causes: missing "
        "`type`, or `entrypoint:` referencing a file the agent "
        f"didn't write.\n\n{bullets}{suffix}\n"
    )
