"""Modify Files — agent edits the cell's files to carry out the task.

Two shapes, dispatched on input count:

  * 1 input cell: agent runs once against the auto-staged files,
    edits in place via ``gen.file_tools()``, nominates a summary file.
    Files it never touches carry through verbatim.
  * 2+ input cells: the modify action fans out — one parallel branch
    per input cell, each running over a per-branch local file dict
    (so the N agents don't trample each other's writes). Each branch
    lands as its own sibling stack cell via ``gen.create_stack_cell``;
    the primary cell becomes an index of what got built.

The manifest enforces min=1, so an empty groups dict is unreachable.
"""
from __future__ import annotations

import asyncio
import re

import gen


# Strip the ``NN_`` ordering prefix that the host adds to multi-input
# cell labels (e.g. ``02_my_story`` → ``my_story``) so the side-cell
# names read cleanly.
_LABEL_PREFIX = re.compile(r"^\d+_")


async def run() -> None:
    cfg = gen.config("pydantic-config.set_yaml")
    prompt = (gen.prompt or "").strip()
    if not prompt:
        gen.update_file(
            "_error.md",
            "# No prompt\n\nProvide a task in the picker prompt.\n",
        )
        await gen.update(name="modify-files · no prompt",
                         summary="Provide a task in the picker prompt.",
                         pinned="_error.md")
        return

    groups = gen.input_groups()
    if len(groups) >= 2:
        await _run_multi(groups, prompt, cfg)
    else:
        await _run_single(prompt, cfg)


# ---------------------------------------------------------------------------
# 1 input — run once against the auto-staged files.
# ---------------------------------------------------------------------------


async def _run_single(prompt: str, cfg) -> None:
    initial = dict(gen.input_files())

    picked = {"path": ""}
    await gen.bootstrap()
    from pydantic_ai import Tool

    async def pick_summary_file(path: str) -> str:
        """Record which file best answers the user's ask. The host
        surfaces it in the cell's summary view. Call this exactly once
        at the end of your work."""
        if not gen.has_file(path):
            return f"ERROR: {path} is not a staged file — call write_file first."
        picked["path"] = path
        return f"summary file set to {path}"

    tools = (
        gen.file_tools()
        + [gen.python_tool_inline()]
        + [Tool(pick_summary_file, name="pick_summary_file")]
    )

    try:
        agent_obj = await gen.agent(
            system_prompt=cfg.get("system_prompt", ""),
            tools=tools,
        )
    except Exception as e:
        gen.log(f"[modify-files] setup error: {e}")
        gen.update_file("_error.md", f"# Setup error\n\n```\n{e}\n```\n")
        await gen.update(name="setup failed", summary=str(e)[:120],
                         pinned="_error.md")
        return

    await gen.update(
        name=f"modify-files · {len(initial)} input file(s)",
        summary=f"working on {len(initial)} file(s)…",
    )
    gen.log(f"[modify-files] {len(initial)} input files, prompt={prompt[:80]!r}")

    try:
        result = await agent_obj.run(prompt)
    except Exception as e:
        gen.log(f"[modify-files] agent error: {e}")
        gen.update_file("_error.md", f"# Agent error\n\n```\n{e}\n```\n")
        await gen.update(name="error", summary=str(e)[:120],
                         pinned="_error.md")
        return

    # Recover prose-only runs. Small open-weight models on
    # Cerebras/Groq frequently respond with a direct answer instead of
    # calling tools — especially with no input files to "modify". This
    # generator doesn't surface chat, so without this fallback the cell
    # would commit empty. Drop the model's text into output.md.
    changed = [p for p in gen.list_files() if initial.get(p) != gen.read_file(p)]
    if not changed:
        text = (str(getattr(result, "output", "") or getattr(result, "data", "")) or "").strip()
        if text:
            gen.update_file("output.md", text)
            if not picked["path"]:
                picked["path"] = "output.md"
            changed = ["output.md"]

    sa = picked["path"] if picked["path"] and gen.has_file(picked["path"]) else ""
    if not sa and changed:
        md = [p for p in changed if p.lower().endswith(".md")]
        sa = md[0] if md else changed[0]

    summary = f"→ `{sa}`" if sa else f"Modified {len(changed)} file(s)"
    await gen.update(
        name="modify-files",
        summary=summary,
        pinned=sa or None,
    )


# ---------------------------------------------------------------------------
# 2+ inputs — fan out, one parallel branch per input cell.
# ---------------------------------------------------------------------------


async def _run_multi(
    groups: dict[str, dict[str, str]],
    prompt: str,
    cfg,
) -> None:
    system_prompt = cfg.get("system_prompt", "")

    # Multi-input runs land with an empty primary stage already, but
    # clear defensively so only ``index.md`` shows up in the placeholder.
    for p in list(gen.list_files()):
        gen.delete_file(p)

    labels = list(groups.keys())
    gen.update_file("index.md", _pending_index(labels))
    await gen.update(
        name=f"modify-files · {len(labels)} cells",
        summary=f"modifying {len(labels)} cells…",
        pinned="index.md",
    )
    gen.log(f"[modify-files] fan-out across {len(labels)} cells, prompt={prompt[:80]!r}")

    # Settle pydantic_ai install once before the parallel fan-out so N
    # branches don't race on micropip/bootstrap.
    await gen.bootstrap()

    # ``None`` → still running; ``BaseException`` → failed; ``(name, sa)`` → done.
    outcomes: list[tuple[str, str | None] | BaseException | None] = [None] * len(labels)

    async def _branch(idx: int, label: str, files: dict[str, str]) -> None:
        cell_name = _LABEL_PREFIX.sub("", label) or label
        try:
            local, sa = await _modify_branch(prompt, system_prompt, files)
        except Exception as e:
            outcomes[idx] = e
            gen.log(f"[modify-files] branch {label!r} failed: {e}")
            await _refresh_index(labels, outcomes)
            return

        try:
            await gen.create_stack_cell(
                name=cell_name[:80],
                summary=(f"→ `{sa}`" if sa else "no changes"),
                pinned=sa or None,
                files=local,
            )
        except Exception as e:
            outcomes[idx] = e
            gen.log(f"[modify-files] create_stack_cell({label!r}) failed: {e}")
            await _refresh_index(labels, outcomes)
            return

        outcomes[idx] = (cell_name, sa)
        await _refresh_index(labels, outcomes)

    await asyncio.gather(
        *[_branch(i, label, groups[label]) for i, label in enumerate(labels)],
        return_exceptions=True,
    )

    gen.update_file("index.md", _final_index(labels, outcomes))
    done = sum(
        1 for o in outcomes
        if o is not None and not isinstance(o, BaseException)
    )
    await gen.update(
        name=f"modify-files · {len(labels)} cells",
        summary=f"{done}/{len(labels)} done",
        pinned="index.md",
    )


async def _modify_branch(
    prompt: str,
    system_prompt: str,
    files: dict[str, str],
) -> tuple[dict[str, str], str]:
    """Run one fan-out branch over ``files`` (one input cell's content).

    Builds tools that close over a *local* dict so concurrent branches
    don't trample each other's writes through the singleton stage.
    Returns the resulting file dict + the picked (or fallback) summary
    artifact path.
    """
    from pydantic_ai import Tool

    local: dict[str, str] = dict(files)
    initial = dict(files)
    picked = {"path": ""}

    async def list_files_t() -> list[str]:
        """List every file currently visible to the agent."""
        return sorted(local.keys())

    async def read_file_t(path: str) -> str:
        """Read the full text of a file."""
        if path not in local:
            return f"ERROR: file not found: {path}"
        return local[path]

    async def write_file_t(path: str, content: str) -> str:
        """Create or overwrite ``path`` with ``content``."""
        local[path] = content
        return f"wrote {len(content)} bytes to {path}"

    async def edit_file_t(path: str, old: str, new: str) -> str:
        """First-match string replace inside ``path``."""
        cur = local.get(path)
        if cur is None:
            return f"ERROR: file not found: {path}"
        if old not in cur:
            return f"ERROR: old text not found in {path}"
        local[path] = cur.replace(old, new, 1)
        return f"edited {path}"

    async def pick_summary_file(path: str) -> str:
        """Record which file best answers the user's ask. Call this
        exactly once at the end of your work."""
        if path not in local:
            return f"ERROR: {path} is not a staged file — call write_file first."
        picked["path"] = path
        return f"summary file set to {path}"

    tools = [
        Tool(list_files_t, name="list_files"),
        Tool(read_file_t, name="read_file"),
        Tool(write_file_t, name="write_file"),
        Tool(edit_file_t, name="edit_file"),
        gen.python_tool_inline(files=local),
        Tool(pick_summary_file, name="pick_summary_file"),
    ]

    agent_obj = await gen.agent(system_prompt=system_prompt, tools=tools)
    result = await agent_obj.run(prompt)

    # Same prose-fallback as the single-input path — see _run_single.
    changed = [p for p in local if initial.get(p) != local.get(p)]
    if not changed:
        text = (str(getattr(result, "output", "") or getattr(result, "data", "")) or "").strip()
        if text:
            local["output.md"] = text
            if not picked["path"]:
                picked["path"] = "output.md"
            changed = ["output.md"]

    sa = picked["path"] if picked["path"] and picked["path"] in local else ""
    if not sa and changed:
        md = [p for p in changed if p.lower().endswith(".md")]
        sa = md[0] if md else changed[0]

    return local, sa


# ---------------------------------------------------------------------------
# Index rendering
# ---------------------------------------------------------------------------


async def _refresh_index(
    labels: list[str],
    outcomes: list[tuple[str, str | None] | BaseException | None],
) -> None:
    gen.update_file("index.md", _final_index(labels, outcomes))
    done = sum(
        1 for o in outcomes
        if o is not None and not isinstance(o, BaseException)
    )
    await gen.update(
        name=f"modify-files · {len(labels)} cells",
        summary=f"{done}/{len(labels)} done",
        pinned="index.md",
    )


def _pending_index(labels: list[str]) -> str:
    lines = [f"# modify-files · {len(labels)} cells", "", "## Cells", ""]
    for label in labels:
        display = _LABEL_PREFIX.sub("", label) or label
        lines.append(f"- ⏳ **{display}** — _running…_")
    lines.append("")
    lines.append("_(running each cell in parallel — stack cells will appear as they finish.)_")
    return "\n".join(lines) + "\n"


def _final_index(
    labels: list[str],
    outcomes: list[tuple[str, str | None] | BaseException | None],
) -> str:
    lines = [f"# modify-files · {len(labels)} cells", "", "## Cells", ""]
    for label, outcome in zip(labels, outcomes):
        display = _LABEL_PREFIX.sub("", label) or label
        if outcome is None:
            lines.append(f"- ⏳ **{display}** — _running…_")
        elif isinstance(outcome, BaseException):
            lines.append(f"- ⚠️ **{display}** — _failed: {outcome}_")
        else:
            _, sa = outcome
            if sa:
                lines.append(f"- ✅ **{display}** — `{sa}`")
            else:
                lines.append(f"- ✅ **{display}** — _no changes_")
    lines.append("")
    lines.append("_Each cell above is its own stack cell below this one._")
    return "\n".join(lines) + "\n"
