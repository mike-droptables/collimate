import React, { useEffect, useCallback } from "https://esm.sh/react@18";
import * as ExcalidrawMod from "https://esm.sh/@excalidraw/excalidraw@0.17.6?deps=react@18,react-dom@18";
import {
  defineRenderer,
  useCollimateFile,
  useDebouncedSaveContent,
  useTheme
} from "/api/sdk/react.js";
const Excalidraw = ExcalidrawMod.Excalidraw || ExcalidrawMod.default?.Excalidraw || ExcalidrawMod.default;
function ExcalidrawWrapper() {
  const { content, saveContent, isReadOnly, api } = useCollimateFile();
  const { scheme } = useTheme(api);
  const debouncedSave = useDebouncedSaveContent(saveContent, 500);
  useEffect(() => {
    let cancelled = false;
    api.injectStyle(`
            html, body, #mount { width: 100%; height: 100%; margin: 0; padding: 0; overflow: hidden; background: var(--void-main); }
        `);
    api.loadCSS("https://cdn.jsdelivr.net/npm/@excalidraw/excalidraw@0.17.6/index.css").then(() => {
      if (cancelled) return;
      requestAnimationFrame(() => {
        if (!cancelled && api.ready) api.ready();
      });
    });
    return () => {
      cancelled = true;
    };
  }, [api]);
  let initialData = { elements: [], appState: { theme: scheme }, files: {} };
  try {
    if (content) {
      const parsed = JSON.parse(content);
      initialData = {
        ...parsed,
        appState: { ...parsed.appState || {}, theme: scheme }
      };
    }
  } catch (e) {
  }
  const handleChange = useCallback((els, state, files) => {
    if (isReadOnly) return;
    const payload = {
      type: "excalidraw",
      version: 2,
      source: "collimate",
      elements: els,
      appState: {
        theme: state.theme,
        viewBackgroundColor: state.viewBackgroundColor
      },
      files
    };
    debouncedSave(JSON.stringify(payload, null, 2));
  }, [isReadOnly, debouncedSave]);
  return /* @__PURE__ */ React.createElement("div", { style: { width: "100%", height: "100%" } }, /* @__PURE__ */ React.createElement(
    Excalidraw,
    {
      key: scheme,
      initialData,
      onChange: !isReadOnly ? handleChange : void 0,
      viewModeEnabled: isReadOnly
    }
  ));
}
var main_default = defineRenderer({ component: ExcalidrawWrapper, deferReady: true });
export {
  main_default as default
};
