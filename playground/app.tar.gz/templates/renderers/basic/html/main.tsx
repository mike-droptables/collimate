import React, { useEffect, useRef, useState } from 'https://esm.sh/react@18';
import {
    defineRenderer,
    useCollimateFile,
    useRemoteScript,
    useTheme,
} from '/api/sdk/react.js';

const MONACO_VERSION = '0.44.0';
const MONACO_BASE = `https://cdn.jsdelivr.net/npm/monaco-editor@${MONACO_VERSION}/min/vs`;

let _monacoPromise: Promise<any> | null = null;
function ensureMonaco(): Promise<any> {
    if (_monacoPromise) return _monacoPromise;
    _monacoPromise = new Promise((resolve) => {
        (window as any).require.config({ paths: { vs: MONACO_BASE } });
        (window as any).require(['vs/editor/editor.main'], () => resolve((window as any).monaco));
    });
    return _monacoPromise;
}

function HtmlEditor() {
    const { content, saveContent, isReadOnly, api } = useCollimateFile();
    const { scheme, onChange: onThemeChange } = useTheme(api);
    const { loading: loaderLoading } = useRemoteScript(`${MONACO_BASE}/loader.js`);
    const containerRef = useRef<HTMLDivElement | null>(null);
    const editorRef = useRef<any>(null);
    const [previewHtml, setPreviewHtml] = useState('');

    useEffect(() => {
        const process = async () => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(content, 'text/html');
            const elements = [...doc.querySelectorAll('[src], [href]')];
            for (const el of elements) {
                const url = el.getAttribute('src') || el.getAttribute('href');
                if (url && !url.startsWith('http') && !url.startsWith('data:') && !url.startsWith('blob:') && !url.startsWith('#')) {
                    try {
                        const cleanPath = url.replace(/^\.\//, '');
                        const siblingContent = await api.getSiblingFile(cleanPath);
                        let mime = 'text/plain';
                        if (cleanPath.endsWith('.js')) mime = 'application/javascript';
                        else if (cleanPath.endsWith('.css')) mime = 'text/css';
                        else if (cleanPath.endsWith('.svg')) mime = 'image/svg+xml';
                        const blob = new Blob([siblingContent], { type: mime });
                        const blobUrl = URL.createObjectURL(blob);
                        if (el.hasAttribute('src')) el.setAttribute('src', blobUrl);
                        if (el.hasAttribute('href')) el.setAttribute('href', blobUrl);
                    } catch(e) {}
                }
            }
            setPreviewHtml(doc.documentElement.outerHTML);
        };
        process();
    }, [content, api]);

    useEffect(() => {
        if (isReadOnly || loaderLoading || !containerRef.current) return;
        let editor: any;
        ensureMonaco().then((monaco) => {
            editor = monaco.editor.create(containerRef.current!, {
                value: content,
                language: 'html',
                theme: scheme === 'light' ? 'vs' : 'vs-dark',
                automaticLayout: true,
                minimap: { enabled: false },
            });
            editor.onDidChangeModelContent(() => saveContent(editor.getValue()));
            editorRef.current = editor;
            editor._unsubTheme = onThemeChange((s) => {
                try { monaco.editor.setTheme(s === 'light' ? 'vs' : 'vs-dark'); } catch {}
            });
        });
        return () => {
            if (editor) {
                if (editor._unsubTheme) editor._unsubTheme();
                editor.dispose();
            }
        };
    }, [isReadOnly, loaderLoading]);

    return (
        <div style={{ display: 'flex', width: '100%', height: '100%', backgroundColor: 'var(--void-main)' }}>
            {!isReadOnly && <div ref={containerRef} style={{ flex: 1, borderRight: '1px solid var(--tungsten-dim)' }} />}
            {/* Rendered HTML owns its page styles; this wrapper's
                bg only shows when the page is blank / transparent /
                still loading. Pulls --renderer-surface so it tracks
                the theme scheme (off-dark dark, off-light light). */}
            <div style={{ flex: 1, backgroundColor: 'var(--renderer-surface, #1a1a1a)', position: 'relative' }}>
                <iframe
                    srcDoc={previewHtml}
                    style={{ width: '100%', height: '100%', border: 'none' }}
                    sandbox="allow-scripts allow-forms allow-same-origin allow-popups"
                />
            </div>
        </div>
    );
}

export default defineRenderer({ component: HtmlEditor });
