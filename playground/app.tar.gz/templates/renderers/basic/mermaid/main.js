import React, { useState, useEffect, useRef } from "https://esm.sh/react@18";
import mermaid from "https://esm.sh/mermaid@10.9.0";
import {
  defineRenderer,
  useCollimateFile,
  useDebouncedSaveContent,
  useTheme
} from "/api/sdk/react.js";
function initMermaid(scheme) {
  mermaid.initialize({
    startOnLoad: false,
    theme: scheme === "light" ? "default" : "dark",
    securityLevel: "strict",
    fontFamily: "var(--font-sans, system-ui, -apple-system, Helvetica, Arial, sans-serif)"
  });
}
function MermaidView() {
  const { content, saveContent, isReadOnly, api } = useCollimateFile();
  const { scheme, onChange } = useTheme(api);
  const debouncedSave = useDebouncedSaveContent(saveContent);
  const [local, setLocal] = useState(content);
  const [svg, setSvg] = useState("");
  const [error, setError] = useState("");
  const idRef = useRef(`mmd-${Math.random().toString(36).slice(2, 10)}`);
  const renderNonce = useRef(0);
  useEffect(() => {
    setLocal(content);
  }, [content]);
  useEffect(() => {
    initMermaid(scheme);
    renderNonce.current++;
    const unsub = onChange((s) => {
      initMermaid(s);
      renderNonce.current++;
      setLocal((l) => l);
    });
    return unsub;
  }, [scheme, onChange]);
  useEffect(() => {
    let cancelled = false;
    const src = (local || "").trim();
    if (!src) {
      setSvg("");
      setError("");
      return;
    }
    const renderId = `${idRef.current}-${renderNonce.current}`;
    mermaid.render(renderId, src).then(({ svg: svg2 }) => {
      if (!cancelled) {
        setSvg(svg2);
        setError("");
      }
    }).catch((e) => {
      if (!cancelled) {
        setError(String(e && e.message || e));
        setSvg("");
      }
    });
    return () => {
      cancelled = true;
    };
  }, [local, scheme]);
  return /* @__PURE__ */ React.createElement("div", { style: { display: "flex", width: "100%", height: "100%", background: "var(--renderer-surface, #1a1a1a)", color: "var(--signal-white)" } }, !isReadOnly && /* @__PURE__ */ React.createElement("div", { style: { flex: 1, display: "flex", flexDirection: "column", borderRight: "1px solid var(--tungsten-dim)" } }, /* @__PURE__ */ React.createElement("div", { style: { padding: "6px 12px", fontSize: 11, color: "var(--muted-foreground)", borderBottom: "1px solid var(--tungsten-dim)", background: "var(--obsidian-plate)" } }, "mermaid source"), /* @__PURE__ */ React.createElement(
    "textarea",
    {
      value: local,
      onChange: (e) => {
        setLocal(e.target.value);
        debouncedSave(e.target.value);
      },
      spellCheck: false,
      style: {
        flex: 1,
        background: "transparent",
        color: "var(--signal-white)",
        fontFamily: "var(--font-mono, ui-monospace, Menlo, Consolas, monospace)",
        fontSize: 13,
        lineHeight: 1.55,
        padding: 14,
        border: "none",
        outline: "none",
        resize: "none"
      }
    }
  )), /* @__PURE__ */ React.createElement("div", { style: { flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" } }, /* @__PURE__ */ React.createElement("div", { style: { padding: "6px 12px", fontSize: 11, color: "var(--muted-foreground)", borderBottom: "1px solid var(--tungsten-dim)", background: "var(--obsidian-plate)" } }, "preview"), /* @__PURE__ */ React.createElement("div", { style: { flex: 1, overflow: "auto", padding: 16, display: "flex", alignItems: "flex-start", justifyContent: "center" } }, error ? /* @__PURE__ */ React.createElement("pre", { style: { color: "var(--destructive)", fontFamily: "var(--font-mono)", fontSize: 12, whiteSpace: "pre-wrap", maxWidth: "100%" } }, error) : svg ? /* @__PURE__ */ React.createElement("div", { style: { maxWidth: "100%" }, dangerouslySetInnerHTML: { __html: svg } }) : /* @__PURE__ */ React.createElement("div", { style: { color: "var(--comment-grey)", fontSize: 12 } }, "(empty)"))));
}
var main_default = defineRenderer({ component: MermaidView });
export {
  main_default as default
};
