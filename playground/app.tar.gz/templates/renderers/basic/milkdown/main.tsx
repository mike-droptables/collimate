import React, { useEffect, useRef } from 'https://esm.sh/react@18';
import * as CrepeMod from 'https://esm.sh/@milkdown/crepe@7.19.1?deps=codemirror@6.0.1';
import {
    defineRenderer,
    useCollimateFile,
    useTheme,
} from '/api/sdk/react.js';

const Crepe = CrepeMod.Crepe || CrepeMod.default?.Crepe || CrepeMod.default;

// Crepe's "frame" theme assumes a dark surface; the dark-mode variant
// overrides it on [data-theme="dark"]. Toggle the attribute when the
// host scheme flips so Crepe's selectors fire.
function applySchemeToDocument(scheme) {
    document.documentElement.setAttribute('data-theme', scheme);
    if (scheme === 'dark') document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
}

function MilkdownEditor() {
    const { content, saveContent, isReadOnly, api } = useCollimateFile();
    const { scheme, onChange: onThemeChange } = useTheme(api);
    const containerRef = useRef(null);
    const crepeRef = useRef(null);
    // Tracks the markdown the editor last emitted, so an external
    // FILES_CHANGED roundtrip of our own save can be deduped.
    const lastEmittedRef = useRef(content || '');

    useEffect(() => {
        if (!containerRef.current) return;
        let cancelled = false;
        let unsubFiles = null;
        applySchemeToDocument(scheme);

        const buildCrepe = (initial) => {
            const c = new Crepe({
                root: containerRef.current,
                defaultValue: initial || '',
            });
            if (!isReadOnly) {
                c.on((listener) => {
                    listener.markdownUpdated((ctx, markdown) => {
                        // Crepe fires markdownUpdated for every transaction
                        // including selection-only ones. Without this guard,
                        // a click or drag-select would saveContent → host
                        // autosave → server PUT → dag_commit → FILES_CHANGED
                        // broadcast → sibling iframes (e.g. SummaryPane's
                        // mirror of the same file) destroy+rebuild Crepe and
                        // visually jump. The byte-equal short-circuit kills
                        // the cycle at the source.
                        if (markdown === lastEmittedRef.current) return;
                        lastEmittedRef.current = markdown;
                        saveContent(markdown);
                    });
                });
            }
            return c;
        };

        (async () => {
            await api.loadCSS('https://cdn.jsdelivr.net/npm/@milkdown/crepe@7.19.1/lib/theme/common/style.css');
            // Inline both frame-light and frame-dark palettes, scoped by
            // data-theme on the document root. We deliberately ship our
            // OWN palette instead of propagating parent-app tokens — the
            // renderer should be a self-contained dark or light surface,
            // not a recoloured version of whatever the host's theme
            // happens to look like. applySchemeToDocument flips the
            // attribute on scheme change so the palette swap is
            // instant without a stylesheet reload.
            //
            // Values lifted from @milkdown/crepe's built-in `frame`
            // (light) and `frame-dark` themes verbatim — those are
            // already balanced for readability across every crepe
            // widget (slash menu, block handle, toolbar, image
            // picker, latex, code fence).
            api.injectStyle(`
                html, body { margin: 0; padding: 0; width: 100%; height: 100%; overflow: hidden; background: #ffffff; }
                html[data-theme="dark"], html[data-theme="dark"] body { background: #1a1a1a; }

                /* Light palette — crepe frame defaults. */
                .milkdown {
                    --crepe-color-background: #ffffff;
                    --crepe-color-on-background: #000000;
                    --crepe-color-surface: #f7f7f7;
                    --crepe-color-surface-low: #ededed;
                    --crepe-color-on-surface: #1c1c1c;
                    --crepe-color-on-surface-variant: #4d4d4d;
                    --crepe-color-outline: #a8a8a8;
                    --crepe-color-primary: #333333;
                    --crepe-color-secondary: #cfcfcf;
                    --crepe-color-on-secondary: #000000;
                    --crepe-color-inverse: #f0f0f0;
                    --crepe-color-on-inverse: #1a1a1a;
                    --crepe-color-inline-code: #ba1a1a;
                    --crepe-color-error: #ba1a1a;
                    --crepe-color-hover: #e0e0e0;
                    --crepe-color-selected: #d5d5d5;
                    --crepe-color-inline-area: #cacaca;
                    --crepe-font-title: 'Noto Serif', Cambria, 'Times New Roman', Times, serif;
                    --crepe-font-default: 'Noto Sans', Arial, Helvetica, sans-serif;
                    --crepe-font-code: 'Space Mono', Fira Code, Menlo, Monaco, 'Courier New', Courier, monospace;
                    --crepe-shadow-1: 0px 1px 3px 1px rgba(0,0,0,0.15), 0px 1px 2px 0px rgba(0,0,0,0.3);
                    --crepe-shadow-2: 0px 2px 6px 2px rgba(0,0,0,0.15), 0px 1px 2px 0px rgba(0,0,0,0.3);
                }

                /* Dark palette — crepe frame-dark defaults. */
                html[data-theme="dark"] .milkdown {
                    --crepe-color-background: #1a1a1a;
                    --crepe-color-on-background: #e6e6e6;
                    --crepe-color-surface: #121212;
                    --crepe-color-surface-low: #1c1c1c;
                    --crepe-color-on-surface: #d1d1d1;
                    --crepe-color-on-surface-variant: #a9a9a9;
                    --crepe-color-outline: #757575;
                    --crepe-color-primary: #b5b5b5;
                    --crepe-color-secondary: #4d4d4d;
                    --crepe-color-on-secondary: #d6d6d6;
                    --crepe-color-inverse: #e5e5e5;
                    --crepe-color-on-inverse: #2a2a2a;
                    --crepe-color-inline-code: #ff6666;
                    --crepe-color-error: #ff6666;
                    --crepe-color-hover: #232323;
                    --crepe-color-selected: #2f2f2f;
                    --crepe-color-inline-area: #2b2b2b;
                    --crepe-shadow-1: 0px 1px 2px 0px rgba(255,255,255,0.3), 0px 1px 3px 1px rgba(255,255,255,0.15);
                    --crepe-shadow-2: 0px 1px 2px 0px rgba(255,255,255,0.3), 0px 2px 6px 2px rgba(255,255,255,0.15);
                }

                /* .milkdown is the content shell. Give it the theme bg and
                   min-height: 100% so the surface colour extends below
                   the last paragraph instead of clinging to just the
                   text (the default — .milkdown's built-in rules leave
                   it transparent and shrink to content, which let the
                   iframe's body bg peek through only around the text
                   block). */
                .milkdown { background: var(--crepe-color-background); min-height: 100%; }

                /* Left padding tuned so the block-handle "+" has breathing
                   room without eating too much of the reading measure. */
                .milkdown .ProseMirror { padding: 24px 40px 24px 88px; min-height: 100%; outline: none; }

                /* Crepe's reset.css sets margin-top on h1–h6 (32/28/24/20/16/16px)
                   to space headings from preceding content. On the very first
                   block that margin lives ABOVE the first line — visible as an
                   "extra line" at the top when the cursor lands there. Zero it
                   out so the top line sits flush with the editor's top padding.
                   The second selector handles the moment a selection starts:
                   prosemirror-virtual-cursor inserts a zero-height div as the
                   ACTUAL first DOM child, knocking the heading out of
                   :first-child. Without the sibling rule the heading's
                   margin-top suddenly reappears and the document visibly jumps
                   by 32px the moment you click+drag (CSS :first-child matches
                   on DOM order, ignoring display, so display:none on the
                   cursor doesn't fix this). */
                .milkdown .ProseMirror > *:first-child,
                .milkdown .ProseMirror > .prosemirror-virtual-cursor + *,
                .milkdown .ProseMirror > .ProseMirror-widget:first-child + * { margin-top: 0; }

                /* Disable prosemirror-virtual-cursor.
                   Milkdown ships a custom caret renderer whose -left /
                   -right variants paint L-shaped border overlays that
                   dangle ABOVE the caret by 1ch × line-height (see
                   prosemirror-virtual-cursor/style/virtual-cursor.css).
                   At position 0 of the document the -left variant
                   hangs above-and-before the first line — that's the
                   "phantom line" above the top and the cursor you see
                   briefly when holding arrow-up. Making a selection
                   hides the caret entirely so the phantom vanishes.
                   The native browser caret handles everything the
                   virtual cursor did for our case, so force caret-color
                   back and hide the virtual cursor DOM. */
                .milkdown .ProseMirror,
                .milkdown .ProseMirror.virtual-cursor-enabled {
                    caret-color: auto !important;
                }
                /* Drop the .milkdown ancestor: the cursor is a child of
                   .ProseMirror but the original scope was overspecific in
                   ways that didn't bite earlier. Cover the -animation
                   variant explicitly — it's the one that fires on
                   selection. (Note: display:none on the cursor does NOT
                   fix the heading jump on its own — the cursor still
                   inserts as a DOM first-child and CSS :first-child
                   matches by DOM order regardless of display. The
                   jump fix is the sibling rule above.) */
                .prosemirror-virtual-cursor,
                .prosemirror-virtual-cursor-animation,
                .prosemirror-virtual-cursor-left,
                .prosemirror-virtual-cursor-right {
                    display: none !important;
                }

                /* Belt-and-suspenders: also suppress the legacy
                   ProseMirror gap-cursor, which would render a short
                   horizontal bar above the first block for a different
                   reason (non-text-node entry points). Harmless to
                   keep disabled for a markdown editor. */
                .milkdown .ProseMirror-gapcursor,
                .milkdown .ProseMirror-focused .ProseMirror-gapcursor {
                    display: none !important;
                }
            `);
            if (cancelled || !containerRef.current) return;

            const crepe = buildCrepe(content);
            await crepe.create();
            if (cancelled) { crepe.destroy(); return; }
            if (isReadOnly) crepe.setReadonly(true);
            crepeRef.current = crepe;
            lastEmittedRef.current = content || '';
            if (api.ready) api.ready();

            // Pick up external edits (other clients, API writes, git pulls)
            // via the host's FILES_CHANGED broadcast. Host only fires this
            // on server dag_commits, so keystrokes don't churn through here.
            // We still dedupe against lastEmittedRef for the roundtrip on
            // our own save. Crepe has no public replaceAll, so destroy+
            // recreate is the cleanest path — cursor position is lost, but
            // that was the pre-existing behavior when this refresh was
            // driven by an iframe src swap.
            if (api.onFilesChanged) {
                unsubFiles = api.onFilesChanged(async () => {
                    if (cancelled || !crepeRef.current || !containerRef.current) return;
                    let fresh;
                    try { fresh = await api.getSiblingFile(api.getFilename()); } catch { return; }
                    if (fresh == null || fresh === lastEmittedRef.current) return;
                    crepeRef.current.destroy();
                    crepeRef.current = null;
                    const next = buildCrepe(fresh);
                    await next.create();
                    if (cancelled) { next.destroy(); return; }
                    if (isReadOnly) next.setReadonly(true);
                    crepeRef.current = next;
                    lastEmittedRef.current = fresh;
                });
            }
        })();

        const unsubTheme = onThemeChange(applySchemeToDocument);

        return () => {
            cancelled = true;
            if (unsubFiles) unsubFiles();
            if (unsubTheme) unsubTheme();
            if (crepeRef.current) crepeRef.current.destroy();
            crepeRef.current = null;
        };
    }, []);

    // No inline background — the scheme-aware body rule in injectStyle
    // handles the page surface, and .milkdown inside paints itself via
    // --crepe-color-background. Relying on --void-main here left the
    // container transparent (the var isn't defined inside the iframe
    // now that we ship a self-contained palette) which let the browser
    // default white flash through under the milkdown body.
    // overflowAnchor: 'none' — Crepe inserts/removes widgets (toolbar,
    // block handle, link tooltip) on selection. Default scroll-anchoring
    // re-anchors when DOM mutates above the viewport, which manifests
    // as "the whole document jumps up by ~24px the moment selection
    // starts." Disabling anchoring keeps the scroll position stable.
    //
    // scrollPaddingTop matches the ProseMirror top padding (24px) so
    // that ProseMirror's scrollIntoView (called on selection) doesn't
    // hide that padding behind the top edge.
    return <div ref={containerRef} style={{ width: '100%', height: '100%', overflowY: 'auto', overflowAnchor: 'none', scrollPaddingTop: '24px' }} />;
}

export default defineRenderer({ component: MilkdownEditor, deferReady: true });
