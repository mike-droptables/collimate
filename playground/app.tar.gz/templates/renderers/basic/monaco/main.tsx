import React, { useEffect, useRef } from 'https://esm.sh/react@18';
import {
    defineRenderer,
    useCollimateFile,
    useRemoteScript,
    useTheme,
} from '/api/sdk/react.js';

const MONACO_VERSION = '0.44.0';
const MONACO_BASE = `https://cdn.jsdelivr.net/npm/monaco-editor@${MONACO_VERSION}/min/vs`;

// Monaco's loader is AMD-style (exposes window.require / window.monaco)
// so we load it as a <script> via useRemoteScript, then block on the
// AMD require for `vs/editor/editor.main`. Cached across mounts by
// useRemoteScript's dedupe table.
let _monacoPromise: Promise<any> | null = null;
function ensureMonaco(): Promise<any> {
    if (_monacoPromise) return _monacoPromise;
    _monacoPromise = new Promise((resolve) => {
        (window as any).require.config({ paths: { vs: MONACO_BASE } });
        (window as any).require(['vs/editor/editor.main'], () => resolve((window as any).monaco));
    });
    return _monacoPromise;
}

function detectLanguage(content = '', filename = '') {
  const ext = filename.split('.').pop().toLowerCase();
  const extMap = {
    'js': 'javascript', 'jsx': 'javascript', 'mjs': 'javascript', 'cjs': 'javascript',
    'ts': 'typescript', 'tsx': 'typescript',
    'py': 'python', 'go': 'go', 'rs': 'rust', 'java': 'java',
    'c': 'c', 'h': 'c', 'cpp': 'cpp', 'hpp': 'cpp',
    'css': 'css', 'scss': 'scss', 'less': 'less',
    'html': 'html', 'xml': 'xml', 'svg': 'xml',
    'json': 'json', 'jsonc': 'json',
    'yaml': 'yaml', 'yml': 'yaml', 'toml': 'toml',
    'sql': 'sql', 'graphql': 'graphql', 'gql': 'graphql',
    'sh': 'shell', 'bash': 'shell', 'zsh': 'shell', 'fish': 'shell'
  };
  if (extMap[ext]) return extMap[ext];
  const t = content.trimStart();
  if (/^(import|export|const|let|var|function|class|interface|type )\b/.test(t)) return 'typescript';
  if (/^(import |from |def |class |async def )/.test(t) || t.startsWith('#!/usr/bin/env python')) return 'python';
  if (/^package /.test(t) || /^func /.test(t)) return 'go';
  if (/^(fn |use |struct |impl |pub )/.test(t)) return 'rust';
  if (/^(SELECT|INSERT|UPDATE|DELETE|CREATE|DROP)\b/i.test(t)) return 'sql';
  if (t.startsWith('<') && /<html|<div|<span/i.test(t)) return 'html';
  if (t.startsWith('{') || t.startsWith('[')) return 'json';
  if (/^(#|---\n)/.test(t)) return 'yaml';
  return 'plaintext';
}

const monacoThemeFor = (s: string) => (s === 'light' ? 'vs' : 'vs-dark');

function MonacoEditor() {
    const { content, saveContent, isReadOnly, fileName, api } = useCollimateFile();
    const { scheme, onChange: onThemeChange } = useTheme(api);
    const { loading: loaderLoading } = useRemoteScript(`${MONACO_BASE}/loader.js`);
    const containerRef = useRef<HTMLDivElement | null>(null);
    const editorRef = useRef<any>(null);

    useEffect(() => {
        if (loaderLoading || !containerRef.current) return;
        let editor: any;
        let cancelled = false;
        ensureMonaco().then((monaco) => {
            if (cancelled || !containerRef.current) return;
            editor = monaco.editor.create(containerRef.current, {
                value: content || '',
                language: detectLanguage(content, fileName),
                theme: monacoThemeFor(scheme),
                readOnly: isReadOnly,
                automaticLayout: true,
                minimap: { enabled: false },
            });
            if (!isReadOnly) {
                editor.onDidChangeModelContent(() => saveContent(editor.getValue()));
            }
            if (api && typeof api.reportSelection === 'function') {
                editor.onDidChangeCursorSelection(() => {
                    try {
                        const sel = editor.getSelection();
                        const model = editor.getModel();
                        const text = (sel && model && !sel.isEmpty())
                            ? model.getValueInRange(sel)
                            : '';
                        api.reportSelection(text);
                    } catch { /* disposed — ignore */ }
                });
            }
            editorRef.current = editor;
            const unsubTheme = onThemeChange((s) => {
                try { monaco.editor.setTheme(monacoThemeFor(s)); } catch {}
            });
            editor._unsubTheme = unsubTheme;
            requestAnimationFrame(() => { if (!cancelled && api && api.ready) api.ready(); });
        });
        return () => {
            cancelled = true;
            if (editor) {
                if (editor._unsubTheme) editor._unsubTheme();
                editor.dispose();
            }
        };
    }, [loaderLoading]);

    useEffect(() => {
        if (editorRef.current && editorRef.current.getValue() !== content) {
            editorRef.current.setValue(content || '');
        }
    }, [content]);

    return <div ref={containerRef} style={{ width: '100%', height: '100%', backgroundColor: 'var(--void-main)' }} />;
}

function MonacoDiffEditor() {
    const { content, diffContent, fileName, api } = useCollimateFile();
    const { scheme, onChange: onThemeChange } = useTheme(api);
    const { loading: loaderLoading } = useRemoteScript(`${MONACO_BASE}/loader.js`);
    const containerRef = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
        if (loaderLoading || !containerRef.current) return;
        let diffEditor: any;
        let cancelled = false;
        ensureMonaco().then((monaco) => {
            if (cancelled || !containerRef.current) return;
            diffEditor = monaco.editor.createDiffEditor(containerRef.current, {
                theme: monacoThemeFor(scheme),
                automaticLayout: true,
                renderSideBySide: true,
                readOnly: true,
            });
            const lang = detectLanguage(content, fileName);
            diffEditor.setModel({
                original: monaco.editor.createModel(diffContent || '', lang),
                modified: monaco.editor.createModel(content || '', lang),
            });
            const unsubTheme = onThemeChange((s) => {
                try { monaco.editor.setTheme(monacoThemeFor(s)); } catch {}
            });
            diffEditor._unsubTheme = unsubTheme;
            requestAnimationFrame(() => { if (!cancelled && api && api.ready) api.ready(); });
        });
        return () => {
            cancelled = true;
            if (diffEditor) {
                if (diffEditor._unsubTheme) diffEditor._unsubTheme();
                diffEditor.dispose();
            }
        };
    }, [content, diffContent, fileName, loaderLoading]);

    return <div ref={containerRef} style={{ width: '100%', height: '100%', backgroundColor: 'var(--void-main)' }} />;
}

export default defineRenderer({
    component: MonacoEditor,
    diffComponent: MonacoDiffEditor,
    deferReady: true,
});
