import React from "https://esm.sh/react@18";
import { defineRenderer, useCollimateFile } from "/api/sdk/react.js";
function StandardEditor() {
  const { content, saveContent, isReadOnly } = useCollimateFile();
  return /* @__PURE__ */ React.createElement("div", { style: { display: "flex", flexDirection: "column", height: "100%", background: "var(--renderer-surface, #1a1a1a)", padding: 16 } }, /* @__PURE__ */ React.createElement("h2", { style: { color: "var(--electric-teal, #34d399)", fontWeight: "bold", marginBottom: 8, textTransform: "uppercase", fontSize: 12, letterSpacing: "0.1em" } }, "Standard Mode"), /* @__PURE__ */ React.createElement(
    "textarea",
    {
      value: content,
      disabled: isReadOnly,
      onChange: (e) => saveContent(e.target.value),
      style: { flex: 1, background: "var(--obsidian-plate, #0f172a)", border: "1px solid var(--tungsten-dim, #1e293b)", color: "var(--signal-white, #cbd5e1)", fontFamily: "var(--font-mono, monospace)", padding: 16, outline: "none", resize: "none" }
    }
  ));
}
function DiffViewer() {
  const { content, diffContent } = useCollimateFile();
  const removedTint = "color-mix(in srgb, #dc2626 25%, var(--void-main))";
  const removedBorder = "color-mix(in srgb, #dc2626 50%, var(--tungsten-dim))";
  const addedTint = "color-mix(in srgb, #16a34a 20%, var(--void-main))";
  const addedBorder = "color-mix(in srgb, #16a34a 50%, var(--tungsten-dim))";
  return /* @__PURE__ */ React.createElement("div", { style: { display: "flex", flexDirection: "column", height: "100%", background: "var(--renderer-surface, #1a1a1a)", padding: 16 } }, /* @__PURE__ */ React.createElement("h2", { style: { color: "var(--filament-amber, #fbbf24)", fontWeight: "bold", marginBottom: 8, textTransform: "uppercase", fontSize: 12, letterSpacing: "0.1em" } }, "Diff Mode Component"), /* @__PURE__ */ React.createElement("div", { style: { flex: 1, display: "flex", gap: 16 } }, /* @__PURE__ */ React.createElement("div", { style: { flex: 1, display: "flex", flexDirection: "column" } }, /* @__PURE__ */ React.createElement("span", { style: { fontSize: 12, color: "var(--muted-foreground, #64748b)", marginBottom: 4 } }, "Previous"), /* @__PURE__ */ React.createElement("pre", { style: { flex: 1, background: removedTint, border: `1px solid ${removedBorder}`, color: "var(--signal-white)", padding: 16, overflow: "auto", fontFamily: "var(--font-mono, monospace)", fontSize: 14 } }, diffContent)), /* @__PURE__ */ React.createElement("div", { style: { flex: 1, display: "flex", flexDirection: "column" } }, /* @__PURE__ */ React.createElement("span", { style: { fontSize: 12, color: "var(--muted-foreground, #64748b)", marginBottom: 4 } }, "Current"), /* @__PURE__ */ React.createElement("pre", { style: { flex: 1, background: addedTint, border: `1px solid ${addedBorder}`, color: "var(--signal-white)", padding: 16, overflow: "auto", fontFamily: "var(--font-mono, monospace)", fontSize: 14 } }, content))));
}
var main_default = defineRenderer({
  component: StandardEditor,
  diffComponent: DiffViewer
});
export {
  main_default as default
};
