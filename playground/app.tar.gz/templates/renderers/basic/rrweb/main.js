import React, { useEffect, useMemo, useRef, useState } from "https://esm.sh/react@18";
import * as rrweb from "https://esm.sh/rrweb@2.0.0-alpha.4";
import { defineRenderer, useCollimateFile } from "/api/sdk/react.js";
function parse(raw) {
  const s = (raw || "").trim();
  if (!s) return {};
  try {
    return JSON.parse(s);
  } catch {
    return {};
  }
}
function wsUrlFromProxyBase(proxyBase) {
  const abs = new URL(proxyBase + "ws", window.location.origin);
  abs.protocol = abs.protocol === "https:" ? "wss:" : "ws:";
  return abs.toString();
}
function RrwebViewer() {
  const { content } = useCollimateFile();
  const artifact = useMemo(() => parse(content), [content]);
  const stageRef = useRef(null);
  const [status, setStatus] = useState({ kind: "idle" });
  const [eventCount, setEventCount] = useState(0);
  useEffect(() => {
    const proxyBase = (artifact.proxyBase || "").trim();
    if (!proxyBase || !stageRef.current) return;
    let cancelled = false;
    let ws = null;
    const pending = [];
    let replayer = null;
    const ensureReplayer = (events) => {
      if (replayer || cancelled || !stageRef.current) return;
      if (!events.some((e) => e && e.type === 2)) return;
      replayer = new rrweb.Replayer(events, {
        root: stageRef.current,
        liveMode: true,
        showWarning: false,
        mouseTail: false,
        useVirtualDom: false
      });
      replayer.startLive();
      setStatus({ kind: "live" });
      for (const e of pending) {
        try {
          replayer.addEvent(e);
        } catch {
        }
      }
      pending.length = 0;
    };
    const handleEvent = (ev) => {
      setEventCount((n) => n + 1);
      if (replayer) {
        try {
          replayer.addEvent(ev);
        } catch {
        }
      } else {
        pending.push(ev);
        ensureReplayer(pending.slice());
      }
    };
    const connect = () => {
      const url = wsUrlFromProxyBase(proxyBase);
      setStatus({ kind: "connecting" });
      ws = new WebSocket(url);
      ws.onopen = () => setStatus({ kind: "waiting" });
      ws.onmessage = (msg) => {
        let payload;
        try {
          payload = JSON.parse(msg.data);
        } catch {
          return;
        }
        if (payload.kind === "init" && Array.isArray(payload.events)) {
          setEventCount((n) => n + payload.events.length);
          if (!replayer) {
            ensureReplayer(payload.events);
            if (!replayer) {
              pending.push(...payload.events);
            }
          } else {
            for (const e of payload.events) handleEvent(e);
          }
        } else if (payload.kind === "event" && payload.event) {
          handleEvent(payload.event);
        }
      };
      ws.onclose = () => {
        if (cancelled) return;
        setStatus({ kind: "closed", reason: "disconnected \u2014 retrying" });
        setTimeout(() => {
          if (!cancelled) connect();
        }, 1500);
      };
      ws.onerror = () => {
      };
    };
    connect();
    return () => {
      cancelled = true;
      try {
        ws?.close();
      } catch {
      }
      try {
        replayer?.pause?.();
      } catch {
      }
      if (stageRef.current) stageRef.current.innerHTML = "";
    };
  }, [artifact.proxyBase]);
  const statusText = (() => {
    switch (status.kind) {
      case "idle":
        return "no stream";
      case "connecting":
        return "connecting\u2026";
      case "waiting":
        return "connected \u2014 waiting for snapshot";
      case "live":
        return "live";
      case "closed":
        return status.reason;
    }
  })();
  const statusColor = status.kind === "live" ? "var(--electric-teal, #7fcfa8)" : status.kind === "closed" ? "var(--destructive, #ef4444)" : "var(--muted-foreground, #9ca3af)";
  if (!artifact.proxyBase) {
    return /* @__PURE__ */ React.createElement("div", { style: {
      width: "100%",
      height: "100%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      background: "var(--void-main, #0a0b0d)",
      color: "var(--muted-foreground, #6b7280)",
      fontFamily: "var(--font-mono, monospace)",
      fontSize: 13,
      padding: 24,
      textAlign: "center"
    } }, "Waiting for the Playwright rrweb generator to publish a session\u2026");
  }
  const vw = artifact.viewport?.width || 1280;
  const vh = artifact.viewport?.height || 800;
  return /* @__PURE__ */ React.createElement("div", { style: {
    width: "100%",
    height: "100%",
    display: "flex",
    flexDirection: "column",
    background: "var(--void-main, #0a0b0d)"
  } }, /* @__PURE__ */ React.createElement("div", { style: {
    height: 28,
    flexShrink: 0,
    background: "var(--obsidian-plate, #1a1c23)",
    borderBottom: "1px solid var(--tungsten-dim, #2a2d3a)",
    display: "flex",
    alignItems: "center",
    padding: "0 10px",
    gap: 12,
    fontFamily: "var(--font-mono, monospace)",
    fontSize: 11,
    color: "var(--signal-white, #e2e8f0)"
  } }, /* @__PURE__ */ React.createElement("span", { style: {
    width: 8,
    height: 8,
    borderRadius: "50%",
    background: statusColor,
    flexShrink: 0
  } }), /* @__PURE__ */ React.createElement("span", { style: { color: statusColor } }, statusText), /* @__PURE__ */ React.createElement("span", { style: { color: "var(--muted-foreground, #6b7280)" } }, eventCount, " event", eventCount === 1 ? "" : "s"), artifact.url && /* @__PURE__ */ React.createElement("span", { style: {
    marginLeft: "auto",
    color: "var(--muted-foreground, #6b7280)",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    maxWidth: "60%"
  }, title: artifact.url }, artifact.url)), /* @__PURE__ */ React.createElement("div", { style: {
    flex: 1,
    minHeight: 0,
    overflow: "auto",
    // rrweb's Replayer paints the recorded page into an iframe
    // it injects under `root`. We give that iframe a neutral
    // surrounding so anti-aliasing on the borders doesn't
    // bleed through.
    background: "#ffffff",
    display: "flex",
    alignItems: "flex-start",
    justifyContent: "flex-start"
  } }, /* @__PURE__ */ React.createElement(
    "div",
    {
      ref: stageRef,
      style: { width: vw, height: vh, flexShrink: 0 }
    }
  )));
}
var main_default = defineRenderer({ component: RrwebViewer });
export {
  main_default as default
};
