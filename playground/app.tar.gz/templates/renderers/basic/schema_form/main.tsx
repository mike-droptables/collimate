import React, { useState, useEffect, useRef, useCallback } from 'https://esm.sh/react@18';
import jsyaml from 'https://esm.sh/js-yaml@4.1.0';
import {
    defineRenderer,
    useCollimateFile,
    useDebouncedSaveContent,
} from '/api/sdk/react.js';

// ===========================================================================
// Schema definitions
// ===========================================================================

type FieldType = 'text' | 'textarea' | 'number' | 'checkbox' | 'dropdown' | 'list' | 'object';

interface FieldSchema {
    key: string;
    type: FieldType;
    label?: string;
    description?: string;
    required?: boolean;
    default?: any;
    options?: any[];
    secret?: boolean;
    min?: number;
    max?: number;
}

interface FormSchema {
    title: string;
    fields: FieldSchema[];
}

// Field schemas mirror the manifest contract documented in
// shared/docs/how-to-write-a-generator.md and how-to-write-a-wasm-generator.md
// (and enforced in src/collimate/lint/core.py). When you change the
// manifest contract, update all three so the form, the linter, and the
// docs stay in lockstep.
const GEN_MANIFEST_SCHEMA: FormSchema = {
    title: 'Generator Manifest',
    fields: [
        { key: 'id', type: 'text', label: 'ID', required: true, description: 'Unique identifier used by the runner to look up this generator (lowercase, hyphenated).' },
        { key: 'name', type: 'text', label: 'Display Name', required: true },
        { key: 'category', type: 'dropdown', label: 'Category', required: true, options: ['tools', 'chat', 'iterate', 'widen', 'narrow'], default: 'tools', description: 'Drives the picker grouping + icon.' },
        { key: 'version', type: 'text', label: 'Version', required: true, default: '0.1.0' },
        { key: 'summary', type: 'textarea', label: 'Summary', required: true, description: 'One- or two-sentence description shown in the picker.' },
        { key: 'entrypoint', type: 'text', label: 'Entrypoint', required: true, description: 'Relative path to the .py file inside this generator directory.' },
        { key: 'runtime', type: 'dropdown', label: 'Runtime', options: ['', 'native', 'wasm', 'both'], default: '', description: 'Empty = native (default). "wasm" = browser playground only. "both" = either runtime.' },
        { key: 'prompt_intent', type: 'text', label: 'Prompt Intent', description: 'One-line hint shown above the picker textarea (e.g. "What does the best candidate look like?").' },
        { key: 'chat', type: 'checkbox', label: 'Chat-shaped', description: 'true = daemon-style multi-turn run via gen.chat_loop(). Default: false.' },
        { key: 'draft_files', type: 'list', label: 'Draft Files', description: 'Relative paths to files (typically .set_yaml) seeded into .colreserved/config/files/ before the run. Editable in the picker form.' },
        { key: 'summary_file', type: 'text', label: 'Summary File', description: 'Which draft file the Draft cell editor opens first (optional; only with default_route: draft).' },
        { key: 'default_route', type: 'dropdown', label: 'Default Route', options: ['', 'run', 'draft'], default: '', description: 'Empty = picker decides ("draft" if draft_files exist, else "run").' },
        { key: 'inputs.cells.min', type: 'number', label: 'Min Input Cells', min: 0 },
        { key: 'inputs.cells.max', type: 'number', label: 'Max Input Cells', min: 0 },
    ],
};

const REND_MANIFEST_SCHEMA: FormSchema = {
    title: 'Renderer Manifest',
    fields: [
        { key: 'id', type: 'text', label: 'ID', required: true },
        { key: 'name', type: 'text', label: 'Display Name', required: true },
        { key: 'version', type: 'text', label: 'Version', required: true, default: '0.1.0' },
        { key: 'summary', type: 'textarea', label: 'Summary' },
        { key: 'entrypoint', type: 'text', label: 'Entrypoint', required: true, default: 'main.tsx' },
        { key: 'embed', type: 'dropdown', label: 'Embed Mode', required: true, options: ['native', 'iframe'], default: 'native', description: 'native = Shadow DOM, inline styles only. iframe = sandboxed, full CSS.' },
        { key: 'extensions', type: 'list', label: 'File Extensions', description: 'Extensions this renderer claims, e.g. ".md", ".set_yaml".' },
        { key: 'supports_diff', type: 'checkbox', label: 'Supports Diff' },
    ],
};

// ===========================================================================
// Path helpers (for dotted keys like "inputs.cells.min")
// ===========================================================================

function getPath(obj: any, path: string): any {
    if (obj == null) return undefined;
    const parts = path.split('.');
    let cur: any = obj;
    for (const p of parts) {
        if (cur == null || typeof cur !== 'object') return undefined;
        cur = cur[p];
    }
    return cur;
}

function setPath(obj: any, path: string, value: any): void {
    const parts = path.split('.');
    let cur: any = obj;
    for (let i = 0; i < parts.length - 1; i++) {
        const p = parts[i];
        if (cur[p] == null || typeof cur[p] !== 'object') cur[p] = {};
        cur = cur[p];
    }
    cur[parts[parts.length - 1]] = value;
}

function deletePath(obj: any, path: string): void {
    const parts = path.split('.');
    let cur: any = obj;
    for (let i = 0; i < parts.length - 1; i++) {
        const p = parts[i];
        if (cur == null || typeof cur !== 'object') return;
        cur = cur[p];
    }
    delete cur[parts[parts.length - 1]];
}

// ===========================================================================
// Mode detection
// ===========================================================================

type Mode = 'gen' | 'rend' | 'set';

function modeFromFilename(filename: string): Mode | null {
    const lower = (filename || '').toLowerCase();
    if (lower.endsWith('.gen_yaml')) return 'gen';
    if (lower.endsWith('.rend_yaml')) return 'rend';
    if (lower.endsWith('.set_yaml')) return 'set';
    return null;
}

// ===========================================================================
// YAML helpers
// ===========================================================================

function loadYaml(text: string): any {
    try {
        const parsed = jsyaml.load(text);
        return parsed == null ? {} : parsed;
    } catch {
        return {};
    }
}

function dumpYaml(obj: any): string {
    return jsyaml.dump(obj, { lineWidth: 100, noRefs: true, sortKeys: false });
}

// ===========================================================================
// Build initial form state
// ===========================================================================

interface FormState {
    schema: FormSchema;
    // form value per schema-field key (raw, untyped — strings/bools/numbers/arrays)
    values: Record<string, any>;
    // for .gen/.rend: parsed full doc, used to preserve unknown keys on save
    rawObject: any;
    // for .set: the user-authored fields[] array, preserved verbatim on save
    rawFields: any[];
    // for .object fields: the raw YAML text the user is currently editing (per field key)
    objectText: Record<string, string>;
}

function valueToObjectText(v: any): string {
    if (v == null) return '';
    return dumpYaml(v).trimEnd();
}

function buildInitialState(content: string, mode: Mode): FormState {
    const parsed = loadYaml(content);

    if (mode === 'set') {
        const rawFields: any[] = Array.isArray(parsed.fields) ? parsed.fields : [];
        const valuesBlock: Record<string, any> = (parsed.values && typeof parsed.values === 'object') ? parsed.values : {};
        const fields: FieldSchema[] = rawFields.map(normalizeFieldDecl);
        const values: Record<string, any> = {};
        const objectText: Record<string, string> = {};
        for (const f of fields) {
            const present = Object.prototype.hasOwnProperty.call(valuesBlock, f.key);
            const v = present ? valuesBlock[f.key] : f.default;
            values[f.key] = coerceValue(v, f);
            if (f.type === 'object') objectText[f.key] = valueToObjectText(v);
        }
        return {
            schema: { title: 'Settings', fields },
            values,
            rawObject: parsed,
            rawFields,
            objectText,
        };
    }

    // gen / rend manifest mode
    const schema = mode === 'gen' ? GEN_MANIFEST_SCHEMA : REND_MANIFEST_SCHEMA;
    const values: Record<string, any> = {};
    const objectText: Record<string, string> = {};
    for (const f of schema.fields) {
        const v = getPath(parsed, f.key);
        values[f.key] = coerceValue(v === undefined ? f.default : v, f);
        if (f.type === 'object') objectText[f.key] = valueToObjectText(v);
    }
    return {
        schema,
        values,
        rawObject: parsed,
        rawFields: [],
        objectText,
    };
}

function normalizeFieldDecl(decl: any): FieldSchema {
    return {
        key: String(decl.key || ''),
        type: (decl.type || 'text') as FieldType,
        label: decl.label,
        description: decl.description,
        required: !!decl.required,
        default: decl.default,
        options: Array.isArray(decl.options) ? decl.options : undefined,
        secret: !!decl.secret,
        min: typeof decl.min === 'number' ? decl.min : undefined,
        max: typeof decl.max === 'number' ? decl.max : undefined,
    };
}

function coerceValue(v: any, f: FieldSchema): any {
    switch (f.type) {
        case 'checkbox':
            return v === true || v === 'true' || v === 1;
        case 'number':
            if (v === '' || v == null) return null;
            const n = typeof v === 'number' ? v : Number(v);
            return Number.isFinite(n) ? n : null;
        case 'list':
            if (Array.isArray(v)) return v.map((x) => (x == null ? '' : String(x)));
            if (v == null || v === '') return [];
            return [String(v)];
        case 'object':
            return v == null ? null : v;
        case 'text':
        case 'textarea':
        case 'dropdown':
        default:
            if (v == null) return '';
            return String(v);
    }
}

// ===========================================================================
// Validation
// ===========================================================================

function validate(state: FormState): Record<string, string> {
    const errors: Record<string, string> = {};
    for (const f of state.schema.fields) {
        const v = state.values[f.key];
        if (f.required) {
            const empty =
                v == null ||
                (typeof v === 'string' && v.trim() === '') ||
                (Array.isArray(v) && v.length === 0);
            if (empty) {
                errors[f.key] = 'Required';
                continue;
            }
        }
        if (f.type === 'dropdown' && f.options && v && !f.options.includes(v)) {
            errors[f.key] = `Must be one of: ${f.options.join(', ')}`;
        }
        if (f.type === 'number' && v != null && v !== '') {
            if (typeof v !== 'number' || !Number.isFinite(v)) {
                errors[f.key] = 'Must be a number';
            } else {
                if (typeof f.min === 'number' && v < f.min) errors[f.key] = `Must be ≥ ${f.min}`;
                if (typeof f.max === 'number' && v > f.max) errors[f.key] = `Must be ≤ ${f.max}`;
            }
        }
        if (f.type === 'object' && state.objectText[f.key]) {
            try {
                jsyaml.load(state.objectText[f.key]);
            } catch (e: any) {
                errors[f.key] = `Invalid YAML: ${e.message || e}`;
            }
        }
    }
    return errors;
}

// ===========================================================================
// Serialize form state back to a YAML document
// ===========================================================================

function serialize(state: FormState, mode: Mode): string {
    if (mode === 'set') {
        const valuesBlock: Record<string, any> = {};
        for (const f of state.schema.fields) {
            let v = state.values[f.key];
            if (f.type === 'object') {
                const text = state.objectText[f.key] || '';
                try {
                    v = text.trim() === '' ? null : jsyaml.load(text);
                } catch {
                    v = null;
                }
            }
            valuesBlock[f.key] = stripEmpty(v, f);
        }
        const out: any = {
            values: valuesBlock,
            fields: state.rawFields,
        };
        return dumpYaml(out);
    }

    // gen / rend: take a deep copy of the parsed doc, overwrite each known field, dump
    const copy = JSON.parse(JSON.stringify(state.rawObject || {}));
    for (const f of state.schema.fields) {
        let v = state.values[f.key];
        if (f.type === 'object') {
            const text = state.objectText[f.key] || '';
            try {
                v = text.trim() === '' ? undefined : jsyaml.load(text);
            } catch {
                v = undefined;
            }
        }
        if (isEmptyForOmission(v, f)) {
            deletePath(copy, f.key);
        } else {
            setPath(copy, f.key, v);
        }
    }
    return dumpYaml(copy);
}

function stripEmpty(v: any, f: FieldSchema): any {
    if (f.type === 'number' && (v === null || v === '')) return null;
    if (f.type === 'list' && Array.isArray(v)) return v.filter((x) => x !== '');
    return v;
}

function isEmptyForOmission(v: any, f: FieldSchema): boolean {
    if (f.required) return false;
    if (v == null) return true;
    if (typeof v === 'string' && v === '') return true;
    if (Array.isArray(v) && v.length === 0) return true;
    if (f.type === 'number' && (v === null || v === '')) return true;
    return false;
}

// ===========================================================================
// UI — colors and shared styles (inline only — Shadow DOM)
// ===========================================================================

// Palette uses var(...) with hex fallbacks so the same constants
// compose into inline style objects below without hand-writing each
// field. The host's SET_THEME pushes the :root values, and fallbacks
// keep the form usable if SET_THEME hasn't landed yet.
const C = {
    bg: 'var(--renderer-surface, #1a1a1a)',
    panel: 'var(--obsidian-plate, #1a1c23)',
    input: 'var(--renderer-surface, #1a1a1a)',
    border: 'var(--tungsten-dim, #2a2d3a)',
    borderLight: 'var(--tungsten-dim, #3a3d52)',
    text: 'var(--signal-white, #e2e8f0)',
    textDim: 'var(--muted-foreground, #9ca3af)',
    textMuted: 'var(--muted-foreground, #6b7280)',
    label: 'var(--signal-white, #f9fafb)',
    accent: 'var(--electric-teal, #60a5fa)',
    required: 'var(--destructive, #f87171)',
    danger: 'var(--destructive, #ef4444)',
    ok: 'var(--primary, #34d399)',
};

const S = {
    page: { width: '100%', height: '100%', background: C.bg, color: C.text, fontFamily: 'system-ui, -apple-system, sans-serif', fontSize: 13, overflow: 'auto' as const, boxSizing: 'border-box' as const },
    header: { padding: '14px 20px 10px', borderBottom: `1px solid ${C.border}`, background: C.panel, position: 'sticky' as const, top: 0, zIndex: 2 },
    title: { fontSize: 14, fontWeight: 600, color: C.label, letterSpacing: 0.2 },
    subtitle: { fontSize: 11, color: C.textMuted, marginTop: 2, fontFamily: 'monospace' },
    body: { padding: 16, maxWidth: 720, margin: '0 auto' },
    field: { marginBottom: 18 },
    labelRow: { display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 4 },
    label: { color: C.label, fontWeight: 500, fontSize: 12 },
    requiredMark: { color: C.required, fontWeight: 700, fontSize: 12 },
    desc: { color: C.textMuted, fontSize: 11, lineHeight: 1.5, marginBottom: 6 },
    input: { width: '100%', background: C.input, border: `1px solid ${C.border}`, borderRadius: 4, padding: '7px 10px', color: C.text, fontFamily: 'monospace', fontSize: 12, outline: 'none', boxSizing: 'border-box' as const },
    textarea: { width: '100%', background: C.input, border: `1px solid ${C.border}`, borderRadius: 4, padding: '8px 10px', color: C.text, fontFamily: 'monospace', fontSize: 12, outline: 'none', resize: 'vertical' as const, minHeight: 60, boxSizing: 'border-box' as const },
    select: { width: '100%', background: C.input, border: `1px solid ${C.border}`, borderRadius: 4, padding: '7px 10px', color: C.text, fontFamily: 'monospace', fontSize: 12, outline: 'none', boxSizing: 'border-box' as const },
    error: { color: C.danger, fontSize: 11, marginTop: 4, fontFamily: 'monospace' },
    listRow: { display: 'flex', gap: 6, marginBottom: 4 },
    button: { background: 'var(--muted, #2d2f3e)', border: `1px solid ${C.borderLight}`, borderRadius: 'var(--radius-sm, 4px)', padding: '6px 10px', color: C.text, fontFamily: 'var(--font-mono, monospace)', fontSize: 11, cursor: 'pointer' },
    buttonDanger: { background: 'color-mix(in srgb, var(--destructive) 20%, var(--void-main))', border: `1px solid color-mix(in srgb, var(--destructive) 40%, var(--tungsten-dim))`, borderRadius: 'var(--radius-sm, 4px)', padding: '6px 10px', color: 'var(--destructive, #fca5a5)', fontFamily: 'var(--font-mono, monospace)', fontSize: 11, cursor: 'pointer' },
    checkboxRow: { display: 'flex', alignItems: 'center', gap: 8 },
    checkbox: { width: 14, height: 14, accentColor: C.accent, cursor: 'pointer' },
    badge: { display: 'inline-block', padding: '2px 6px', borderRadius: 3, background: 'var(--muted, #1f2937)', color: C.textDim, fontFamily: 'var(--font-mono, monospace)', fontSize: 10 },
    // Warning banner keeps an amber-ish tint — color-mixed against the
    // filament accent so it picks up the theme's primary-ish hue
    // rather than forcing a fixed orange on light themes.
    banner: { padding: '8px 12px', background: 'color-mix(in srgb, var(--filament-amber) 12%, var(--void-main))', border: `1px solid color-mix(in srgb, var(--filament-amber) 40%, var(--tungsten-dim))`, color: 'var(--filament-amber, #fbbf24)', fontSize: 11, borderRadius: 'var(--radius-sm, 4px)', marginBottom: 12, fontFamily: 'var(--font-mono, monospace)' },
};

// ===========================================================================
// Field renderers
// ===========================================================================

interface FieldProps {
    field: FieldSchema;
    value: any;
    objectText?: string;
    error?: string;
    readOnly: boolean;
    onChange: (v: any) => void;
    onObjectTextChange?: (text: string) => void;
}

function FieldView({ field, value, objectText, error, readOnly, onChange, onObjectTextChange }: FieldProps) {
    return (
        <div style={S.field}>
            <div style={S.labelRow}>
                <span style={S.label}>{field.label || field.key}</span>
                {field.required && <span style={S.requiredMark} title="Required">*</span>}
                <span style={{ marginLeft: 'auto', ...S.badge }}>{field.type}</span>
            </div>
            {field.description && <div style={S.desc}>{field.description}</div>}
            {renderInput(field, value, objectText, readOnly, onChange, onObjectTextChange)}
            {error && <div style={S.error}>{error}</div>}
        </div>
    );
}

function renderInput(
    field: FieldSchema,
    value: any,
    objectText: string | undefined,
    readOnly: boolean,
    onChange: (v: any) => void,
    onObjectTextChange?: (text: string) => void
) {
    switch (field.type) {
        case 'textarea':
            return (
                <textarea
                    style={S.textarea}
                    value={value ?? ''}
                    disabled={readOnly}
                    onChange={(e) => onChange(e.target.value)}
                    spellCheck={false}
                />
            );
        case 'number':
            return (
                <input
                    type="number"
                    style={S.input}
                    value={value == null ? '' : value}
                    disabled={readOnly}
                    min={field.min}
                    max={field.max}
                    onChange={(e) => {
                        const raw = e.target.value;
                        if (raw === '') onChange(null);
                        else {
                            const n = Number(raw);
                            onChange(Number.isFinite(n) ? n : null);
                        }
                    }}
                />
            );
        case 'checkbox':
            return (
                <div style={S.checkboxRow}>
                    <input
                        type="checkbox"
                        style={S.checkbox}
                        checked={!!value}
                        disabled={readOnly}
                        onChange={(e) => onChange(e.target.checked)}
                    />
                    <span style={{ color: C.textDim, fontFamily: 'monospace', fontSize: 11 }}>
                        {value ? 'true' : 'false'}
                    </span>
                </div>
            );
        case 'dropdown':
            return (
                <select
                    style={S.select}
                    value={value ?? ''}
                    disabled={readOnly}
                    onChange={(e) => onChange(e.target.value)}
                >
                    {!field.required && <option value="">— none —</option>}
                    {(field.options || []).map((opt) => (
                        <option key={String(opt)} value={String(opt)}>
                            {String(opt)}
                        </option>
                    ))}
                </select>
            );
        case 'list':
            return <ListField value={value} readOnly={readOnly} onChange={onChange} />;
        case 'object':
            return (
                <textarea
                    style={{ ...S.textarea, minHeight: 100 }}
                    value={objectText ?? ''}
                    disabled={readOnly}
                    onChange={(e) => onObjectTextChange && onObjectTextChange(e.target.value)}
                    spellCheck={false}
                    placeholder="# raw YAML"
                />
            );
        case 'text':
        default:
            return (
                <input
                    type={field.secret ? 'password' : 'text'}
                    style={S.input}
                    value={value ?? ''}
                    disabled={readOnly}
                    onChange={(e) => onChange(e.target.value)}
                    spellCheck={false}
                    autoComplete={field.secret ? 'off' : undefined}
                />
            );
    }
}

function ListField({ value, readOnly, onChange }: { value: any; readOnly: boolean; onChange: (v: any) => void }) {
    const items: string[] = Array.isArray(value) ? value : [];
    const update = (idx: number, v: string) => {
        const next = items.slice();
        next[idx] = v;
        onChange(next);
    };
    const remove = (idx: number) => {
        const next = items.slice();
        next.splice(idx, 1);
        onChange(next);
    };
    const add = () => onChange([...items, '']);

    return (
        <div>
            {items.length === 0 && (
                <div style={{ color: C.textMuted, fontSize: 11, fontFamily: 'monospace', marginBottom: 4 }}>
                    (empty)
                </div>
            )}
            {items.map((it, idx) => (
                <div key={idx} style={S.listRow}>
                    <input
                        type="text"
                        style={{ ...S.input, flex: 1 }}
                        value={it}
                        disabled={readOnly}
                        onChange={(e) => update(idx, e.target.value)}
                        spellCheck={false}
                    />
                    {!readOnly && (
                        <button type="button" style={S.buttonDanger} onClick={() => remove(idx)}>
                            ×
                        </button>
                    )}
                </div>
            ))}
            {!readOnly && (
                <button type="button" style={S.button} onClick={add}>
                    + add
                </button>
            )}
        </div>
    );
}

// ===========================================================================
// Top-level component
// ===========================================================================

function SchemaForm() {
    const { content, saveContent, isReadOnly, api } = useCollimateFile();
    const filename = api.getFilename();
    const mode = modeFromFilename(filename);

    // Build initial form state once per (filename, content-identity).
    // We deliberately don't depend on `content` here so the user's typing
    // doesn't reset state on every saveContent → echo cycle.
    const initialContent = useRef(content);
    const [state, setState] = useState<FormState | null>(() => {
        if (!mode) return null;
        return buildInitialState(content || '', mode);
    });

    // Re-initialise if the filename changes (renderer re-mounts on file change anyway,
    // but if React keeps us mounted we still want to react).
    useEffect(() => {
        if (!mode) return;
        if (initialContent.current === content) return;
        // External edit: rebuild state from the new content.
        initialContent.current = content;
        setState(buildInitialState(content || '', mode));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [filename]);

    // Debounced save: any field edit triggers a save 350ms later.
    const saveRaw = useDebouncedSaveContent(saveContent, 350);
    const scheduleSave = useCallback(
        (next: FormState) => {
            if (!mode) return;
            const yamlText = serialize(next, mode);
            initialContent.current = yamlText;
            saveRaw(yamlText);
        },
        [mode, saveRaw]
    );

    if (!mode) {
        return (
            <div style={S.page}>
                <div style={S.body}>
                    <div style={S.banner}>
                        Schema Form was opened on a file with an unrecognised extension: {filename}
                    </div>
                </div>
            </div>
        );
    }

    if (!state) {
        return (
            <div style={S.page}>
                <div style={S.body}>
                    <div style={{ color: C.textMuted, fontFamily: 'monospace' }}>Loading…</div>
                </div>
            </div>
        );
    }

    const errors = validate(state);
    const errorCount = Object.keys(errors).length;

    const updateValue = (key: string, v: any) => {
        const next: FormState = {
            ...state,
            values: { ...state.values, [key]: v },
        };
        setState(next);
        scheduleSave(next);
    };

    const updateObjectText = (key: string, text: string) => {
        const next: FormState = {
            ...state,
            objectText: { ...state.objectText, [key]: text },
        };
        setState(next);
        scheduleSave(next);
    };

    const titleByMode: Record<Mode, string> = {
        gen: 'Generator Manifest',
        rend: 'Renderer Manifest',
        set: 'Settings',
    };

    return (
        <div style={S.page}>
            <div style={S.header}>
                <div style={S.title}>{titleByMode[mode]}</div>
                <div style={S.subtitle}>
                    {filename}
                    {errorCount > 0 && (
                        <span style={{ color: C.danger, marginLeft: 12 }}>
                            {errorCount} error{errorCount === 1 ? '' : 's'}
                        </span>
                    )}
                    {isReadOnly && <span style={{ color: C.textMuted, marginLeft: 12 }}>read-only</span>}
                </div>
            </div>
            <div style={S.body}>
                {state.schema.fields.length === 0 && (
                    <div style={S.banner}>
                        This settings file has no <code>fields:</code> block. The author should declare a list of
                        fields with <code>key</code>, <code>type</code>, and (optionally) <code>label</code>,{' '}
                        <code>default</code>, <code>options</code>, etc.
                    </div>
                )}
                {state.schema.fields.map((f) => (
                    <FieldView
                        key={f.key}
                        field={f}
                        value={state.values[f.key]}
                        objectText={state.objectText[f.key]}
                        error={errors[f.key]}
                        readOnly={isReadOnly}
                        onChange={(v) => updateValue(f.key, v)}
                        onObjectTextChange={(t) => updateObjectText(f.key, t)}
                    />
                ))}
            </div>
        </div>
    );
}

export default defineRenderer({ component: SchemaForm });
