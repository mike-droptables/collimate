import React, { useState, useEffect, useMemo, useCallback } from 'https://esm.sh/react@18';
import {
    defineRenderer,
    useCollimateFile,
    useDebouncedSaveContent,
} from '/api/sdk/react.js';

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function renderSlideMarkdown(md) {
  let html = escapeHtml(md);
  html = html.replace(/`([^`\n]+)`/g, '<code style="background:var(--muted);color:var(--filament-amber);padding:2px 6px;border-radius:4px;font-size:0.85em;font-family:var(--font-mono);">$1</code>');
  html = html.replace(/^# (.+)$/gm, '<h1 style="font-size:2.2em;font-weight:700;color:var(--signal-white);margin:0 0 0.4em 0;line-height:1.15;">$1</h1>');
  html = html.replace(/^## (.+)$/gm, '<h2 style="font-size:1.55em;font-weight:600;color:var(--signal-white);margin:0 0 0.5em 0;">$1</h2>');
  html = html.replace(/^### (.+)$/gm, '<h3 style="font-size:1.2em;font-weight:600;color:var(--signal-white);margin:0 0 0.5em 0;">$1</h3>');
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
  html = html.replace(/^[*\-] (.+)$/gm, '<li style="margin:0.35em 0;font-size:1.1em;line-height:1.45;">$1</li>');
  html = html.replace(/(<li[^>]*>[\s\S]*?<\/li>\n?)+/g, (m) => `<ul style="padding-left:1.4em;margin:0.4em 0;color:var(--signal-white);">${m}</ul>`);
  html = html.split(/\n{2,}/).map((block) => {
    const t = block.trim();
    if (!t) return '';
    if (/^<[hupobldi]/.test(t)) return t;
    return `<p style="margin:0.5em 0;font-size:1.1em;line-height:1.55;color:var(--signal-white);">${t}</p>`;
  }).join('\n');
  return html;
}

function splitSlides(md) {
  const raw = (md || '').split(/^\s*---\s*$/m);
  return raw.map((s) => s.trim()).filter((s) => s.length > 0);
}

function SlidesView() {
  const { content, saveContent, isReadOnly } = useCollimateFile();
  const debouncedSave = useDebouncedSaveContent(saveContent);
  const [local, setLocal] = useState(content);
  const [editing, setEditing] = useState(false);
  const [idx, setIdx] = useState(0);

  useEffect(() => { setLocal(content); }, [content]);

  const slides = useMemo(() => splitSlides(local), [local]);
  const safeIdx = Math.min(idx, Math.max(0, slides.length - 1));

  const next = useCallback(() => setIdx((i) => Math.min(i + 1, slides.length - 1)), [slides.length]);
  const prev = useCallback(() => setIdx((i) => Math.max(i - 1, 0)), []);

  useEffect(() => {
    function onKey(e) {
      if (editing) return;
      if (e.key === 'ArrowRight' || e.key === ' ') { next(); e.preventDefault(); }
      else if (e.key === 'ArrowLeft') { prev(); e.preventDefault(); }
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [next, prev, editing]);

  const wrap = { width: '100%', height: '100%', background: 'var(--renderer-surface, #1a1a1a)', color: 'var(--signal-white)', display: 'flex', flexDirection: 'column' };
  const toolbar = {
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    padding: '8px 14px', borderBottom: '1px solid var(--tungsten-dim)', background: 'var(--obsidian-plate)', fontSize: 12,
  };
  const btn = {
    background: 'var(--muted)', color: 'var(--signal-white)', border: '1px solid var(--tungsten-dim)',
    borderRadius: 'var(--radius-sm)', padding: '4px 10px', cursor: 'pointer', fontSize: 12,
  };

  if (editing) {
    return (
      <div style={wrap}>
        <div style={toolbar}>
          <span style={{ color: 'var(--muted-foreground)' }}>editing source ({slides.length} slide{slides.length === 1 ? '' : 's'})</span>
          <button style={btn} onClick={() => setEditing(false)}>done</button>
        </div>
        <textarea
          value={local}
          onChange={(e) => { setLocal(e.target.value); debouncedSave(e.target.value); }}
          spellCheck={false}
          style={{
            flex: 1, background: 'transparent', color: 'var(--signal-white)',
            fontFamily: 'var(--font-mono, ui-monospace, Menlo, Consolas, monospace)',
            fontSize: 13, lineHeight: 1.55, padding: 16, border: 'none', outline: 'none', resize: 'none',
          }}
        />
      </div>
    );
  }

  const current = slides[safeIdx] || '';

  return (
    <div style={wrap}>
      <div style={toolbar}>
        <div style={{ display: 'flex', gap: 6 }}>
          <button style={btn} onClick={prev} disabled={safeIdx === 0}>‹ prev</button>
          <button style={btn} onClick={next} disabled={safeIdx >= slides.length - 1}>next ›</button>
        </div>
        <div style={{ color: 'var(--muted-foreground)' }}>
          {slides.length === 0 ? 'no slides' : `${safeIdx + 1} / ${slides.length}`}
        </div>
        {!isReadOnly && (
          <button style={btn} onClick={() => setEditing(true)}>edit source</button>
        )}
      </div>
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 32, overflow: 'auto' }}>
        <div
          style={{
            width: '100%', maxWidth: 880, minHeight: 360,
            background: 'var(--obsidian-plate)', border: '1px solid var(--tungsten-dim)', borderRadius: 'var(--radius-lg)',
            padding: '48px 56px', boxShadow: '0 20px 60px rgba(0,0,0,0.45)',
          }}
          dangerouslySetInnerHTML={{ __html: renderSlideMarkdown(current) }}
        />
      </div>
    </div>
  );
}

export default defineRenderer({ component: SlidesView });
