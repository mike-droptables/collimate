import React, { useEffect, useMemo, useRef, useState } from "https://esm.sh/react@18";
import { Terminal } from "https://esm.sh/xterm@5.3.0";
import { FitAddon } from "https://esm.sh/xterm-addon-fit@0.8.0";
import { WebLinksAddon } from "https://esm.sh/xterm-addon-web-links@0.9.0";
import {
  defineRenderer,
  useCollimateFile,
  useTheme
} from "/api/sdk/react.js";
function parseContent(raw) {
  try {
    const j = JSON.parse(raw || "");
    if (typeof j.session_id !== "string" || !j.session_id) return null;
    if (typeof j.ws_path !== "string" || !j.ws_path) return null;
    const buttons = Array.isArray(j.buttons) ? j.buttons.filter((b) => b && typeof b.id === "string" && typeof b.label === "string").map((b) => ({ id: b.id, label: b.label })) : [];
    return {
      session_id: j.session_id,
      ws_path: j.ws_path,
      token: typeof j.token === "string" ? j.token : "",
      label: typeof j.label === "string" ? j.label : "terminal",
      buttons
    };
  } catch {
    return null;
  }
}
function buildWsUrl(ws_path, token) {
  const base = new URL(ws_path, window.location.origin);
  base.protocol = base.protocol === "https:" ? "wss:" : "ws:";
  if (token) base.searchParams.set("token", token);
  return base.toString();
}
function buildXtermTheme() {
  if (typeof document === "undefined") {
    return { background: "#000000", foreground: "#e2e8f0", cursor: "#7fcfa8" };
  }
  const cs = getComputedStyle(document.documentElement);
  const read = (name, fallback) => cs.getPropertyValue(name).trim() || fallback;
  return {
    background: "#000000",
    foreground: read("--signal-white", "#e2e8f0"),
    cursor: read("--electric-teal", "#7fcfa8"),
    selectionBackground: read("--muted", "#2a2d3a")
  };
}
function TerminalViewer() {
  const { content, api } = useCollimateFile();
  const { onChange: onThemeChange } = useTheme(api);
  const parsed = useMemo(() => parseContent(content), [content]);
  const hostRef = useRef(null);
  const [status, setStatus] = useState("idle");
  const [attempt, setAttempt] = useState(0);
  const [pendingAction, setPendingAction] = useState(null);
  const [actionStatus, setActionStatus] = useState("");
  const clickAction = async (id, label) => {
    if (pendingAction) return;
    setPendingAction(id);
    setActionStatus("");
    const ok = typeof api.emitAction === "function" ? await api.emitAction(id) : false;
    setActionStatus(ok ? `${label} sent` : `${label} failed`);
    setPendingAction(null);
    setTimeout(() => setActionStatus(""), 2500);
  };
  useEffect(() => {
    if (!parsed || !hostRef.current) return;
    let cancelled = false;
    api.loadCSS("https://esm.sh/xterm@5.3.0/css/xterm.css");
    const term = new Terminal({
      cursorBlink: true,
      fontFamily: getComputedStyle(document.documentElement).getPropertyValue("--font-mono").trim() || "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
      fontSize: 13,
      theme: buildXtermTheme(),
      convertEol: false,
      scrollback: 5e3,
      allowProposedApi: true
    });
    const fit = new FitAddon();
    term.loadAddon(fit);
    term.loadAddon(new WebLinksAddon());
    term.open(hostRef.current);
    try {
      fit.fit();
    } catch {
    }
    const url = buildWsUrl(parsed.ws_path, parsed.token);
    setStatus("connecting");
    const ws = new WebSocket(url);
    ws.binaryType = "arraybuffer";
    const encoder = new TextEncoder();
    let lastCols = 0;
    let lastRows = 0;
    const sendResize = () => {
      try {
        fit.fit();
      } catch {
        return;
      }
      const cols = term.cols;
      const rows = term.rows;
      if (cols === lastCols && rows === lastRows) return;
      lastCols = cols;
      lastRows = rows;
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ t: "resize", cols, rows }));
      }
    };
    ws.onopen = () => {
      if (cancelled) return;
      setStatus("open");
      sendResize();
      term.focus();
    };
    ws.onmessage = (ev) => {
      if (ev.data instanceof ArrayBuffer) {
        term.write(new Uint8Array(ev.data));
      } else if (typeof ev.data === "string") {
        term.write(ev.data);
      }
    };
    ws.onclose = () => {
      if (cancelled) return;
      setStatus("closed");
      term.write("\r\n\x1B[33m[connection closed]\x1B[0m\r\n");
    };
    ws.onerror = () => {
      if (cancelled) return;
      setStatus("error");
    };
    const disposeOnData = term.onData((d) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(encoder.encode(d));
      }
    });
    const ro = new ResizeObserver(() => sendResize());
    ro.observe(hostRef.current);
    const unsubTheme = onThemeChange(() => {
      try {
        term.options.theme = buildXtermTheme();
      } catch {
      }
    });
    return () => {
      cancelled = true;
      ro.disconnect();
      disposeOnData.dispose();
      if (unsubTheme) unsubTheme();
      try {
        ws.close();
      } catch {
      }
      term.dispose();
    };
  }, [parsed?.session_id, parsed?.token, parsed?.ws_path, attempt]);
  if (!parsed) {
    return /* @__PURE__ */ React.createElement("div", { style: { width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", background: "#000000", color: "var(--muted-foreground, #6b7280)", fontFamily: "var(--font-mono, monospace)", fontSize: 12, padding: 16, textAlign: "center" } }, "Invalid .terminal file \u2014 expected JSON with ", `{ session_id, ws_path, token }`, ".");
  }
  const statusColor = status === "open" ? "var(--electric-teal, #7fcfa8)" : status === "connecting" ? "var(--filament-amber, #d4a94f)" : status === "error" ? "var(--destructive, #e06c75)" : "var(--muted-foreground, #6b7280)";
  return /* @__PURE__ */ React.createElement("div", { style: { width: "100%", height: "100%", display: "flex", flexDirection: "column", background: "#000000" } }, /* @__PURE__ */ React.createElement("div", { style: { height: 24, background: "var(--obsidian-plate, #1a1c23)", borderBottom: "1px solid var(--tungsten-dim, #2a2d3a)", display: "flex", alignItems: "center", padding: "0 8px", gap: 8, flexShrink: 0, fontFamily: "var(--font-mono, monospace)", fontSize: 11 } }, /* @__PURE__ */ React.createElement("span", { style: { color: "var(--muted-foreground, #9ca3af)" } }, parsed.label), /* @__PURE__ */ React.createElement("span", { style: { color: statusColor } }, "\u25CF ", status), actionStatus && /* @__PURE__ */ React.createElement("span", { style: { color: "var(--electric-teal, #7fcfa8)" } }, actionStatus), /* @__PURE__ */ React.createElement("div", { style: { marginLeft: "auto", display: "flex", alignItems: "center", gap: 6 } }, parsed.buttons.map((b) => {
    const busy = pendingAction === b.id;
    const ctaBg = busy ? "var(--muted, #3a3d52)" : "color-mix(in srgb, #10b981 35%, var(--void-main))";
    return /* @__PURE__ */ React.createElement(
      "button",
      {
        key: b.id,
        onClick: () => clickAction(b.id, b.label),
        disabled: busy || !!pendingAction,
        style: { height: 18, padding: "0 8px", background: ctaBg, border: "1px solid color-mix(in srgb, #10b981 60%, var(--tungsten-dim))", borderRadius: "var(--radius-sm, 3px)", color: "var(--signal-white, #d6f5e4)", fontFamily: "var(--font-mono, monospace)", fontSize: 10, cursor: busy ? "wait" : "pointer", opacity: pendingAction && !busy ? 0.6 : 1 }
      },
      busy ? "\u2026" : b.label
    );
  }), (status === "closed" || status === "error") && /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setAttempt((a) => a + 1),
      style: { height: 18, padding: "0 8px", background: "var(--muted, #2d2f3e)", border: "1px solid var(--tungsten-dim, #3a3d52)", borderRadius: "var(--radius-sm, 3px)", color: "var(--signal-white, #e2e8f0)", fontFamily: "var(--font-mono, monospace)", fontSize: 10, cursor: "pointer" }
    },
    "Reconnect"
  ))), /* @__PURE__ */ React.createElement(
    "div",
    {
      ref: hostRef,
      style: { flex: 1, padding: 4, overflow: "hidden" }
    }
  ));
}
var main_default = defineRenderer({ component: TerminalViewer });
export {
  main_default as default
};
