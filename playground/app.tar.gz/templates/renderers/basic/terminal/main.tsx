import React, { useEffect, useMemo, useRef, useState } from 'https://esm.sh/react@18';
import { Terminal } from 'https://esm.sh/xterm@5.3.0';
import { FitAddon } from 'https://esm.sh/xterm-addon-fit@0.8.0';
import { WebLinksAddon } from 'https://esm.sh/xterm-addon-web-links@0.9.0';
import {
    defineRenderer,
    useCollimateFile,
    useTheme,
} from '/api/sdk/react.js';

type ButtonSpec = { id: string; label: string };

type Parsed = {
    session_id: string;
    ws_path: string;
    token: string;
    label: string;
    buttons: ButtonSpec[];
};

function parseContent(raw: string): Parsed | null {
    try {
        const j = JSON.parse(raw || '');
        if (typeof j.session_id !== 'string' || !j.session_id) return null;
        if (typeof j.ws_path !== 'string' || !j.ws_path) return null;
        const buttons: ButtonSpec[] = Array.isArray(j.buttons)
            ? j.buttons
                  .filter((b: any) => b && typeof b.id === 'string' && typeof b.label === 'string')
                  .map((b: any) => ({ id: b.id, label: b.label }))
            : [];
        return {
            session_id: j.session_id,
            ws_path: j.ws_path,
            token: typeof j.token === 'string' ? j.token : '',
            label: typeof j.label === 'string' ? j.label : 'terminal',
            buttons,
        };
    } catch {
        return null;
    }
}

function buildWsUrl(ws_path: string, token: string): string {
    const base = new URL(ws_path, window.location.origin);
    base.protocol = base.protocol === 'https:' ? 'wss:' : 'ws:';
    if (token) base.searchParams.set('token', token);
    return base.toString();
}

// Read xterm theme colors from the host's CSS vars, resolved against the
// current :root. Background is hard-pinned to solid black — a terminal
// is the one surface where TTY palettes (colored prompts, ANSI escape
// codes, syntax highlighting) are authored against a true-black
// background; swapping to the host's off-dark palette mutes contrast
// on high-saturation fore colors.
function buildXtermTheme(): Record<string, string> {
    if (typeof document === 'undefined') {
        return { background: '#000000', foreground: '#e2e8f0', cursor: '#7fcfa8' };
    }
    const cs = getComputedStyle(document.documentElement);
    const read = (name: string, fallback: string) => (cs.getPropertyValue(name).trim() || fallback);
    return {
        background: '#000000',
        foreground: read('--signal-white', '#e2e8f0'),
        cursor: read('--electric-teal', '#7fcfa8'),
        selectionBackground: read('--muted', '#2a2d3a'),
    };
}

function TerminalViewer() {
    const { content, api } = useCollimateFile();
    const { onChange: onThemeChange } = useTheme(api);
    const parsed = useMemo<Parsed | null>(() => parseContent(content), [content]);
    const hostRef = useRef<HTMLDivElement | null>(null);
    const [status, setStatus] = useState<'connecting' | 'open' | 'closed' | 'error' | 'idle'>('idle');
    const [attempt, setAttempt] = useState(0);
    const [pendingAction, setPendingAction] = useState<string | null>(null);
    const [actionStatus, setActionStatus] = useState<string>('');

    const clickAction = async (id: string, label: string) => {
        if (pendingAction) return;
        setPendingAction(id);
        setActionStatus('');
        const ok = typeof api.emitAction === 'function' ? await api.emitAction(id) : false;
        setActionStatus(ok ? `${label} sent` : `${label} failed`);
        setPendingAction(null);
        setTimeout(() => setActionStatus(''), 2500);
    };

    useEffect(() => {
        if (!parsed || !hostRef.current) return;
        let cancelled = false;

        api.loadCSS('https://esm.sh/xterm@5.3.0/css/xterm.css');

        const term = new Terminal({
            cursorBlink: true,
            fontFamily: getComputedStyle(document.documentElement).getPropertyValue('--font-mono').trim()
                || 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
            fontSize: 13,
            theme: buildXtermTheme(),
            convertEol: false,
            scrollback: 5000,
            allowProposedApi: true,
        });
        const fit = new FitAddon();
        term.loadAddon(fit);
        term.loadAddon(new WebLinksAddon());
        term.open(hostRef.current);
        try { fit.fit(); } catch {}

        const url = buildWsUrl(parsed.ws_path, parsed.token);
        setStatus('connecting');
        const ws = new WebSocket(url);
        ws.binaryType = 'arraybuffer';
        const encoder = new TextEncoder();
        let lastCols = 0;
        let lastRows = 0;

        const sendResize = () => {
            try { fit.fit(); } catch { return; }
            const cols = term.cols;
            const rows = term.rows;
            if (cols === lastCols && rows === lastRows) return;
            lastCols = cols;
            lastRows = rows;
            if (ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({ t: 'resize', cols, rows }));
            }
        };

        ws.onopen = () => {
            if (cancelled) return;
            setStatus('open');
            sendResize();
            term.focus();
        };

        ws.onmessage = (ev) => {
            if (ev.data instanceof ArrayBuffer) {
                term.write(new Uint8Array(ev.data));
            } else if (typeof ev.data === 'string') {
                term.write(ev.data);
            }
        };

        ws.onclose = () => {
            if (cancelled) return;
            setStatus('closed');
            term.write('\r\n\x1b[33m[connection closed]\x1b[0m\r\n');
        };

        ws.onerror = () => {
            if (cancelled) return;
            setStatus('error');
        };

        const disposeOnData = term.onData((d) => {
            if (ws.readyState === WebSocket.OPEN) {
                ws.send(encoder.encode(d));
            }
        });

        const ro = new ResizeObserver(() => sendResize());
        ro.observe(hostRef.current);

        // Hot-swap xterm theme on host scheme change. xterm exposes a
        // mutable `options.theme` setter that takes effect on the next
        // paint — no dispose/recreate needed.
        const unsubTheme = onThemeChange(() => {
            try { term.options.theme = buildXtermTheme(); } catch { /* disposed */ }
        });

        return () => {
            cancelled = true;
            ro.disconnect();
            disposeOnData.dispose();
            if (unsubTheme) unsubTheme();
            try { ws.close(); } catch {}
            term.dispose();
        };
    }, [parsed?.session_id, parsed?.token, parsed?.ws_path, attempt]);

    if (!parsed) {
        return (
            <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#000000', color: 'var(--muted-foreground, #6b7280)', fontFamily: 'var(--font-mono, monospace)', fontSize: 12, padding: 16, textAlign: 'center' }}>
                Invalid .terminal file — expected JSON with {`{ session_id, ws_path, token }`}.
            </div>
        );
    }

    // Status pill colors pull semantic tokens where they fit and fall
    // back to fixed hexes for warn/error that don't map cleanly.
    const statusColor =
        status === 'open' ? 'var(--electric-teal, #7fcfa8)' :
        status === 'connecting' ? 'var(--filament-amber, #d4a94f)' :
        status === 'error' ? 'var(--destructive, #e06c75)' :
        'var(--muted-foreground, #6b7280)';

    return (
        <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: '#000000' }}>
            <div style={{ height: 24, background: 'var(--obsidian-plate, #1a1c23)', borderBottom: '1px solid var(--tungsten-dim, #2a2d3a)', display: 'flex', alignItems: 'center', padding: '0 8px', gap: 8, flexShrink: 0, fontFamily: 'var(--font-mono, monospace)', fontSize: 11 }}>
                <span style={{ color: 'var(--muted-foreground, #9ca3af)' }}>{parsed.label}</span>
                <span style={{ color: statusColor }}>● {status}</span>
                {actionStatus && (
                    <span style={{ color: 'var(--electric-teal, #7fcfa8)' }}>{actionStatus}</span>
                )}
                <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6 }}>
                    {parsed.buttons.map(b => {
                        const busy = pendingAction === b.id;
                        // Tinted-green CTA background mirrors the .website
                        // renderer's action buttons — color-mix keeps it
                        // readable under light themes too.
                        const ctaBg = busy
                            ? 'var(--muted, #3a3d52)'
                            : 'color-mix(in srgb, #10b981 35%, var(--void-main))';
                        return (
                            <button
                                key={b.id}
                                onClick={() => clickAction(b.id, b.label)}
                                disabled={busy || !!pendingAction}
                                style={{ height: 18, padding: '0 8px', background: ctaBg, border: '1px solid color-mix(in srgb, #10b981 60%, var(--tungsten-dim))', borderRadius: 'var(--radius-sm, 3px)', color: 'var(--signal-white, #d6f5e4)', fontFamily: 'var(--font-mono, monospace)', fontSize: 10, cursor: busy ? 'wait' : 'pointer', opacity: pendingAction && !busy ? 0.6 : 1 }}
                            >
                                {busy ? '…' : b.label}
                            </button>
                        );
                    })}
                    {(status === 'closed' || status === 'error') && (
                        <button
                            onClick={() => setAttempt(a => a + 1)}
                            style={{ height: 18, padding: '0 8px', background: 'var(--muted, #2d2f3e)', border: '1px solid var(--tungsten-dim, #3a3d52)', borderRadius: 'var(--radius-sm, 3px)', color: 'var(--signal-white, #e2e8f0)', fontFamily: 'var(--font-mono, monospace)', fontSize: 10, cursor: 'pointer' }}
                        >
                            Reconnect
                        </button>
                    )}
                </div>
            </div>
            <div
                ref={hostRef}
                style={{ flex: 1, padding: 4, overflow: 'hidden' }}
            />
        </div>
    );
}

export default defineRenderer({ component: TerminalViewer });
