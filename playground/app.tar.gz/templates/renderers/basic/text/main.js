import React from "https://esm.sh/react@18";
import {
  defineRenderer,
  tokens,
  useCollimateFile
} from "/api/sdk/react.js";
function TextEditor() {
  const { content, saveContent, isReadOnly, fileName } = useCollimateFile();
  return /* @__PURE__ */ React.createElement("div", { style: { width: "100%", height: "100%", display: "flex", flexDirection: "column", background: "var(--renderer-surface, #1a1a1a)", color: tokens.color.signalWhite } }, /* @__PURE__ */ React.createElement(
    "textarea",
    {
      value: content,
      disabled: isReadOnly,
      onChange: (e) => saveContent(e.target.value),
      spellCheck: false,
      style: { flex: 1, width: "100%", background: "transparent", color: tokens.color.signalWhite, fontFamily: tokens.font.mono, fontSize: 13, lineHeight: 1.6, padding: 16, border: "none", outline: "none", resize: "none" }
    }
  ), /* @__PURE__ */ React.createElement("div", { style: { height: 22, background: tokens.color.obsidianPlate, borderTop: `1px solid ${tokens.color.tungstenDim}`, display: "flex", alignItems: "center", padding: "0 12px", gap: 12, fontFamily: tokens.font.mono, fontSize: 10, color: tokens.color.commentGrey } }, /* @__PURE__ */ React.createElement("span", null, content.split("\n").length, " lines"), /* @__PURE__ */ React.createElement("span", null, content.length, " chars"), /* @__PURE__ */ React.createElement("span", { style: { marginLeft: "auto" } }, fileName)));
}
var main_default = defineRenderer({ component: TextEditor });
export {
  main_default as default
};
