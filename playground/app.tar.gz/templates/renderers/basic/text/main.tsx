import React from 'https://esm.sh/react@18';
import {
    defineRenderer,
    tokens,
    useCollimateFile,
} from '/api/sdk/react.js';

// defineRenderer's `injectBaseStyles` default is true — the SDK now ships
// the host's CSS-variable reset, so renderers don't hand-roll `var(...)`
// fallbacks for the shell layout. Lib-specific styling still goes inline.

function TextEditor() {
    const { content, saveContent, isReadOnly, fileName } = useCollimateFile();

    return (
        <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--renderer-surface, #1a1a1a)', color: tokens.color.signalWhite }}>
            <textarea
                value={content}
                disabled={isReadOnly}
                onChange={e => saveContent(e.target.value)}
                spellCheck={false}
                style={{ flex: 1, width: '100%', background: 'transparent', color: tokens.color.signalWhite, fontFamily: tokens.font.mono, fontSize: 13, lineHeight: 1.6, padding: 16, border: 'none', outline: 'none', resize: 'none' }}
            />
            <div style={{ height: 22, background: tokens.color.obsidianPlate, borderTop: `1px solid ${tokens.color.tungstenDim}`, display: 'flex', alignItems: 'center', padding: '0 12px', gap: 12, fontFamily: tokens.font.mono, fontSize: 10, color: tokens.color.commentGrey }}>
                <span>{content.split('\n').length} lines</span>
                <span>{content.length} chars</span>
                <span style={{ marginLeft: 'auto' }}>{fileName}</span>
            </div>
        </div>
    );
}

export default defineRenderer({ component: TextEditor });
