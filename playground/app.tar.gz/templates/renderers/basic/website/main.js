import React, { useMemo, useState } from "https://esm.sh/react@18";
import { defineRenderer, useCollimateFile } from "/api/sdk/react.js";
function parseContent(raw) {
  const s = (raw || "").trim();
  if (s.startsWith("{")) {
    try {
      const j = JSON.parse(s);
      const url = typeof j.url === "string" ? j.url.trim() : "";
      const buttons = Array.isArray(j.buttons) ? j.buttons.filter((b) => b && typeof b.id === "string" && typeof b.label === "string").map((b) => ({ id: b.id, label: b.label })) : [];
      return { url, buttons };
    } catch {
    }
  }
  return { url: s, buttons: [] };
}
function WebsiteViewer() {
  const { content, saveContent, isReadOnly, api } = useCollimateFile();
  const parsed = useMemo(() => parseContent(content), [content]);
  const [localUrl, setLocalUrl] = useState(parsed.url);
  const [activeUrl, setActiveUrl] = useState(parsed.url);
  const [pendingAction, setPendingAction] = useState(null);
  const [actionStatus, setActionStatus] = useState("");
  const commit = () => {
    const u = localUrl.trim();
    if (parsed.buttons.length > 0) {
      saveContent(JSON.stringify({ url: u, buttons: parsed.buttons }));
    } else {
      saveContent(u);
    }
    setActiveUrl(u);
  };
  const resolveExternal = (u) => {
    if (!u) return "";
    if (u.startsWith("http://") || u.startsWith("https://")) return u;
    try {
      return new URL(u, window.location.origin).toString();
    } catch {
      return u;
    }
  };
  const openExternal = () => {
    const target = resolveExternal(localUrl.trim() || activeUrl);
    if (target) window.open(target, "_blank", "noopener,noreferrer");
  };
  const clickAction = async (id, label) => {
    if (pendingAction) return;
    setPendingAction(id);
    setActionStatus("");
    const ok = typeof api.emitAction === "function" ? await api.emitAction(id) : false;
    setActionStatus(ok ? `${label} sent` : `${label} failed`);
    setPendingAction(null);
    setTimeout(() => setActionStatus(""), 2500);
  };
  const btnBase = {
    height: 22,
    padding: "0 12px",
    border: "1px solid var(--tungsten-dim, #3a3d52)",
    borderRadius: "var(--radius-sm, 4px)",
    color: "var(--signal-white, #e2e8f0)",
    fontFamily: "var(--font-mono, monospace)",
    fontSize: 11
  };
  return /* @__PURE__ */ React.createElement("div", { style: { width: "100%", height: "100%", display: "flex", flexDirection: "column", background: "var(--void-main, #0a0b0d)" } }, /* @__PURE__ */ React.createElement("div", { style: { height: 32, background: "var(--obsidian-plate, #1a1c23)", borderBottom: "1px solid var(--tungsten-dim, #2a2d3a)", display: "flex", alignItems: "center", padding: "0 8px", gap: 8, flexShrink: 0 } }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      value: localUrl,
      onChange: (e) => setLocalUrl(e.target.value),
      onKeyDown: (e) => e.key === "Enter" && commit(),
      readOnly: isReadOnly,
      placeholder: "https://...",
      style: { flex: 1, height: 22, background: "var(--void-main, #0d0f14)", border: "1px solid var(--tungsten-dim, #2a2d3a)", borderRadius: "var(--radius-sm, 4px)", padding: "0 8px", color: "var(--signal-white, #e2e8f0)", fontFamily: "var(--font-mono, monospace)", fontSize: 11, outline: "none" }
    }
  ), !isReadOnly && /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: commit,
      style: { ...btnBase, background: "var(--muted, #2d2f3e)", cursor: "pointer" }
    },
    "Go"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: openExternal,
      title: "Open in new browser tab",
      style: { ...btnBase, background: "var(--muted, #2d2f3e)", cursor: "pointer" }
    },
    "Open \u2197"
  ), parsed.buttons.map((b) => {
    const busy = pendingAction === b.id;
    const ctaBg = busy ? "var(--muted, #3a3d52)" : "color-mix(in srgb, #10b981 35%, var(--void-main))";
    return /* @__PURE__ */ React.createElement(
      "button",
      {
        key: b.id,
        onClick: () => clickAction(b.id, b.label),
        disabled: busy || !!pendingAction,
        style: { ...btnBase, background: ctaBg, border: "1px solid color-mix(in srgb, #10b981 60%, var(--tungsten-dim))", color: "var(--signal-white, #d6f5e4)", cursor: busy ? "wait" : "pointer", opacity: pendingAction && !busy ? 0.6 : 1 }
      },
      busy ? "\u2026" : b.label
    );
  }), actionStatus && /* @__PURE__ */ React.createElement("span", { style: { color: "var(--electric-teal, #7fcfa8)", fontFamily: "var(--font-mono, monospace)", fontSize: 11 } }, actionStatus)), activeUrl ? /* @__PURE__ */ React.createElement(
    "iframe",
    {
      src: activeUrl,
      style: { flex: 1, width: "100%", border: "none", background: "var(--renderer-surface, #1a1a1a)" },
      sandbox: "allow-scripts allow-same-origin allow-forms allow-popups"
    }
  ) : /* @__PURE__ */ React.createElement("div", { style: { flex: 1, display: "flex", alignItems: "center", justifyContent: "center", color: "var(--muted-foreground, #4b5563)", fontFamily: "var(--font-mono, monospace)", fontSize: 13 } }, "Enter a URL above and press Enter"));
}
var main_default = defineRenderer({ component: WebsiteViewer });
export {
  main_default as default
};
