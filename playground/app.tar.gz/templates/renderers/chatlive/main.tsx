import React, { useEffect, useMemo, useRef, useState } from 'https://esm.sh/react@18';
import {
    defineRenderer,
    tokens,
    useCollimateFile,
    useTheme,
} from '/api/sdk/react.js';

// ---------------------------------------------------------------------------
// Pointer + transcript parsing (mirror of collimate/pointers.py + chatlog.py).
// ---------------------------------------------------------------------------

type Pointer = { session_id: string; ws_path: string; token: string; label: string; log_file: string };
type Msg = { role: string; content: string };

function parsePointer(raw: string): Pointer | null {
    try {
        const j = JSON.parse(raw || '');
        if (typeof j.session_id !== 'string' || !j.session_id) return null;
        if (typeof j.ws_path !== 'string' || !j.ws_path) return null;
        return {
            session_id: j.session_id,
            ws_path: j.ws_path,
            token: typeof j.token === 'string' ? j.token : '',
            label: typeof j.label === 'string' ? j.label : 'Live Chat',
            log_file: typeof j.log_file === 'string' ? j.log_file : 'conversation.chatlog',
        };
    } catch { return null; }
}

const HEADER_RE = /^###\s+(user|assistant|system)\s*$/i;
function parseChatlog(text: string): Msg[] {
    if (!text) return [];
    const out: Msg[] = [];
    let role: string | null = null;
    let body: string[] = [];
    const flush = () => { if (role !== null) out.push({ role, content: body.join('\n').replace(/^\n+|\n+$/g, '') }); };
    for (const line of text.split('\n')) {
        const m = HEADER_RE.exec(line.trim());
        if (m) { flush(); role = m[1].toLowerCase(); body = []; continue; }
        if (role !== null) body.push(line);
    }
    flush();
    return out;
}

function escapeHtml(s: string): string { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function safeUrl(raw: string): string { const t = String(raw).trim(); return /^(javascript|data|vbscript|file):/i.test(t) ? '#' : t.replace(/"/g, '&quot;'); }
function mdToHtml(md: string): string {
    if (!md) return '';
    let h = escapeHtml(md);
    h = h.replace(/```(\w*)\n([\s\S]*?)```/g, (_m, _l, code) =>
        `<pre style="background:var(--obsidian-plate);padding:10px;border-radius:var(--radius);border:1px solid var(--tungsten-dim);overflow:auto;"><code style="font-family:var(--font-mono);font-size:12px;">${code.replace(/\n+$/, '')}</code></pre>`);
    h = h.replace(/`([^`\n]+)`/g, '<code style="background:var(--muted);color:var(--filament-amber);padding:1px 4px;border-radius:3px;font-family:var(--font-mono);">$1</code>');
    h = h.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/\*(.+?)\*/g, '<em>$1</em>');
    h = h.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_m, t, href) => `<a href="${safeUrl(href)}" target="_blank" rel="noreferrer" style="color:var(--electric-teal);text-decoration:underline;">${t}</a>`);
    return h.replace(/\n/g, '<br/>');
}

function buildWsUrl(ws_path: string, token: string): string {
    const base = new URL(ws_path, window.location.origin);
    base.protocol = base.protocol === 'https:' ? 'wss:' : 'ws:';
    if (token) base.searchParams.set('token', token);
    return base.toString();
}

// Drop leading `extra` messages already present as the tail of `committed`
// (the .chatlog re-read eventually absorbs our optimistic / streamed bubbles).
function trimExtra(committed: Msg[], extra: Msg[]): Msg[] {
    for (let n = Math.min(extra.length, committed.length); n >= 1; n--) {
        let ok = true;
        for (let i = 0; i < n; i++) {
            const c = committed[committed.length - n + i];
            if (!c || c.role !== extra[i].role || c.content !== extra[i].content) { ok = false; break; }
        }
        if (ok) return extra.slice(n);
    }
    return extra;
}

function Bubble({ role, content, streaming }: { role: string; content: string; streaming?: boolean }) {
    const isUser = role === 'user';
    const isSystem = role === 'system';
    const bg = isUser
        ? 'color-mix(in srgb, var(--electric-teal) 16%, var(--void-main))'
        : isSystem ? 'transparent' : 'var(--obsidian-plate)';
    return (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: isUser ? 'flex-end' : 'flex-start', gap: 2 }}>
            <span style={{ fontSize: 10, color: 'var(--muted-foreground)', fontFamily: tokens.font.mono, padding: '0 4px' }}>
                {isUser ? 'You' : isSystem ? 'System' : 'Assistant'}
            </span>
            <div style={{
                maxWidth: '85%', background: bg, border: isSystem ? 'none' : '1px solid var(--tungsten-dim)',
                borderRadius: 'var(--radius)', padding: isSystem ? '2px 6px' : '8px 12px',
                color: isSystem ? 'var(--muted-foreground)' : 'var(--signal-white)', fontFamily: tokens.font.sans,
                fontSize: 14, lineHeight: 1.55, wordBreak: 'break-word', fontStyle: isSystem ? 'italic' : 'normal',
            }}>
                <span dangerouslySetInnerHTML={{ __html: mdToHtml(content) }} />
                {streaming && <span style={{ opacity: 0.6 }}>▍</span>}
            </div>
        </div>
    );
}

// ---------------------------------------------------------------------------
// The live chat renderer.
// ---------------------------------------------------------------------------

type Status = 'connecting' | 'open' | 'closed' | 'error';

function LiveChat() {
    const { content, api } = useCollimateFile() as any;
    const { onChange: onThemeChange } = useTheme(api);
    const ptr = useMemo<Pointer | null>(() => parsePointer(content), [content]);

    const [committed, setCommitted] = useState<Msg[]>([]);
    const [status, setStatus] = useState<Status>('connecting');
    const [draft, setDraft] = useState('');
    const [reconnect, setReconnect] = useState(0);

    // Optimistic / streaming buffer not yet in the .chatlog (reconciled away
    // once the generator commits the turn and the sibling re-read absorbs it).
    const extraRef = useRef<Msg[]>([]);
    const [, force] = useState(0);
    const rerender = () => force(n => n + 1);
    const streamingRef = useRef(false);
    const committedLenAtSendRef = useRef(0);
    const wsRef = useRef<WebSocket | null>(null);
    const scrollRef = useRef<HTMLDivElement | null>(null);

    // Subscribe to theme so CSS-var driven styles re-resolve (no imperative
    // work needed — inline styles read the vars live; this keeps the mount
    // honest about following theme flips).
    useEffect(() => onThemeChange(() => rerender()), [onThemeChange]);

    const refreshHistory = async () => {
        if (!ptr) return;
        try {
            const text = await api.getSiblingFile(ptr.log_file);
            const msgs = parseChatlog(typeof text === 'string' ? text : '');
            setCommitted(msgs);
            // Once the in-flight turn has committed, drop our optimistic buffer.
            if (!streamingRef.current && msgs.length >= committedLenAtSendRef.current && extraRef.current.length) {
                extraRef.current = trimExtra(msgs, extraRef.current);
                rerender();
            }
        } catch { /* no log yet */ }
    };

    // Load history initially + whenever the cell's files change (the generator
    // commits a .chatlog version per turn).
    useEffect(() => {
        refreshHistory();
        const unsub = api.onFilesChanged(() => { refreshHistory(); });
        return unsub;
    }, [api, ptr?.log_file]);

    // WebSocket lifecycle.
    useEffect(() => {
        if (!ptr) return;
        let closed = false;
        setStatus('connecting');
        const ws = new WebSocket(buildWsUrl(ptr.ws_path, ptr.token));
        wsRef.current = ws;

        const ensureAssistant = (turnId: string) => {
            const ex = extraRef.current;
            const last = ex[ex.length - 1];
            if (last && last.role === 'assistant' && (last as any)._turn === turnId) return last;
            const msg: any = { role: 'assistant', content: '', _turn: turnId };
            ex.push(msg);
            return msg;
        };

        ws.onopen = () => { if (!closed) setStatus('open'); };
        ws.onmessage = (ev) => {
            let frame: any;
            try { frame = JSON.parse(ev.data); } catch { return; }
            const t = frame.t;
            if (t === 'history') {
                // Replay of an in-flight turn's partial text on (re)connect.
                if (frame.text) {
                    streamingRef.current = true;
                    const a = ensureAssistant(frame.turn_id || 'resume');
                    a.content = frame.text;
                    rerender();
                }
            } else if (t === 'turn_start') {
                streamingRef.current = true;
                ensureAssistant(frame.turn_id || '');
                rerender();
            } else if (t === 'delta') {
                streamingRef.current = true;
                const a = ensureAssistant(frame.turn_id || '');
                a.content += frame.text || '';
                rerender();
                queueMicrotask(() => { const el = scrollRef.current; if (el) el.scrollTop = el.scrollHeight; });
            } else if (t === 'turn_end') {
                streamingRef.current = false;
                refreshHistory();
                rerender();
            } else if (t === 'error') {
                streamingRef.current = false;
                extraRef.current.push({ role: 'system', content: `⚠ ${frame.message || 'error'}` });
                rerender();
            }
        };
        ws.onclose = () => { if (!closed) { setStatus('closed'); streamingRef.current = false; } };
        ws.onerror = () => { if (!closed) setStatus('error'); };

        return () => {
            closed = true;
            try { ws.close(); } catch { /* already gone */ }
            wsRef.current = null;
        };
    }, [ptr?.session_id, ptr?.ws_path, ptr?.token, reconnect]);

    const live = status === 'open' || status === 'connecting';
    const messages = [...committed, ...trimExtra(committed, extraRef.current)];

    const send = () => {
        const text = draft.trim();
        if (!text || !ptr) return;
        const ws = wsRef.current;
        if (!ws || ws.readyState !== WebSocket.OPEN) return;
        committedLenAtSendRef.current = committed.length;
        if (streamingRef.current) {
            // Mid-turn message → redirect (cancel current, run this next).
            ws.send(JSON.stringify({ t: 'redirect', content: text }));
        } else {
            ws.send(JSON.stringify({ t: 'user_msg', content: text }));
        }
        extraRef.current.push({ role: 'user', content: text });
        setDraft('');
        rerender();
        queueMicrotask(() => { const el = scrollRef.current; if (el) el.scrollTop = el.scrollHeight; });
    };

    const interrupt = () => {
        const ws = wsRef.current;
        if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ t: 'interrupt' }));
    };

    if (!ptr) {
        return (
            <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--void-main)', color: 'var(--muted-foreground)', fontFamily: tokens.font.mono, fontSize: 12, padding: 16, textAlign: 'center' }}>
                Invalid .chatlive file — expected {`{ session_id, ws_path, token, log_file }`}.
            </div>
        );
    }

    const statusColor = status === 'open' ? 'var(--electric-teal)' : status === 'connecting' ? 'var(--filament-amber)' : status === 'error' ? 'var(--destructive)' : 'var(--muted-foreground)';

    return (
        <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--void-main)', boxSizing: 'border-box', minWidth: 0 }}>
            <div style={{ height: 26, flexShrink: 0, display: 'flex', alignItems: 'center', gap: 8, padding: '0 10px', background: 'var(--obsidian-plate)', borderBottom: '1px solid var(--tungsten-dim)', fontFamily: tokens.font.mono, fontSize: 11 }}>
                <span style={{ color: 'var(--muted-foreground)' }}>{ptr.label}</span>
                <span style={{ color: statusColor }}>● {live ? 'live' : status === 'closed' ? 'ended' : status}</span>
                {(status === 'closed' || status === 'error') && (
                    <button onClick={() => setReconnect(n => n + 1)} style={{ marginLeft: 'auto', height: 18, padding: '0 8px', background: 'var(--muted)', border: '1px solid var(--tungsten-dim)', borderRadius: 'var(--radius-sm)', color: 'var(--signal-white)', fontFamily: tokens.font.mono, fontSize: 10, cursor: 'pointer' }}>
                        Reconnect
                    </button>
                )}
            </div>

            <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto' }}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12, padding: 16 }}>
                    {messages.length === 0 && (
                        <div style={{ color: 'var(--muted-foreground)', fontFamily: tokens.font.mono, fontSize: 12, textAlign: 'center', padding: 24 }}>
                            {live ? 'Say something to get started.' : 'No messages.'}
                        </div>
                    )}
                    {messages.map((m, i) => (
                        <Bubble key={i} role={m.role} content={m.content} streaming={streamingRef.current && i === messages.length - 1 && m.role === 'assistant'} />
                    ))}
                </div>
            </div>

            {live ? (
                <div style={{ flexShrink: 0, borderTop: '1px solid var(--tungsten-dim)', padding: 10, display: 'flex', gap: 8, alignItems: 'flex-end', background: 'var(--obsidian-plate)' }}>
                    <textarea
                        value={draft}
                        onChange={e => setDraft(e.target.value)}
                        onKeyDown={e => { if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') { e.preventDefault(); send(); } }}
                        placeholder={streamingRef.current ? 'Redirect the assistant…  (⌘↵ to send)' : 'Message…  (⌘↵ to send)'}
                        rows={2}
                        style={{ flex: 1, background: 'var(--void-main)', color: 'var(--signal-white)', fontFamily: tokens.font.sans, fontSize: 14, lineHeight: 1.5, padding: '8px 10px', border: '1px solid var(--tungsten-dim)', borderRadius: 'var(--radius)', outline: 'none', resize: 'none' }}
                    />
                    {streamingRef.current && (
                        <button onClick={interrupt} style={{ height: 32, padding: '0 12px', background: 'var(--muted)', border: '1px solid var(--tungsten-dim)', borderRadius: 'var(--radius)', color: 'var(--signal-white)', fontFamily: tokens.font.mono, fontSize: 12, cursor: 'pointer' }}>Stop</button>
                    )}
                    <button onClick={send} disabled={!draft.trim()} style={{ height: 32, padding: '0 14px', background: draft.trim() ? 'color-mix(in srgb, var(--electric-teal) 35%, var(--void-main))' : 'var(--muted)', border: '1px solid color-mix(in srgb, var(--electric-teal) 60%, var(--tungsten-dim))', borderRadius: 'var(--radius)', color: 'var(--signal-white)', fontFamily: tokens.font.mono, fontSize: 12, cursor: draft.trim() ? 'pointer' : 'default', opacity: draft.trim() ? 1 : 0.6 }}>Send</button>
                </div>
            ) : (
                <div style={{ flexShrink: 0, borderTop: '1px solid var(--tungsten-dim)', padding: '8px 12px', background: 'var(--obsidian-plate)', color: 'var(--muted-foreground)', fontFamily: tokens.font.mono, fontSize: 11 }}>
                    Session ended — showing the saved transcript. Run the chat again to continue.
                </div>
            )}
        </div>
    );
}

export default defineRenderer({ component: LiveChat });
