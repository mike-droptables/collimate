import React, { useState, useEffect } from "https://esm.sh/react@18";
import {
  defineRenderer,
  tokens,
  useCollimateFile,
  useDebouncedSaveContent
} from "/api/sdk/react.js";
const HEADER_RE = /^###\s+(user|assistant|system)\s*$/i;
function parseChatlog(text) {
  if (!text) return [];
  const out = [];
  let role = null;
  let body = [];
  const flush = () => {
    if (role !== null) out.push({ role, content: body.join("\n").replace(/^\n+|\n+$/g, "") });
  };
  for (const line of text.split("\n")) {
    const m = HEADER_RE.exec(line.trim());
    if (m) {
      flush();
      role = m[1].toLowerCase();
      body = [];
      continue;
    }
    if (role !== null) body.push(line);
  }
  flush();
  return out;
}
function escapeHtml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function safeUrl(raw) {
  const t = String(raw).trim();
  if (/^(javascript|data|vbscript|file):/i.test(t)) return "#";
  return t.replace(/"/g, "&quot;");
}
function mdToHtml(md) {
  if (!md) return "";
  let h = escapeHtml(md);
  h = h.replace(/```(\w*)\n([\s\S]*?)```/g, (_m, _lang, code) => `<pre style="background:var(--obsidian-plate);padding:10px;border-radius:var(--radius);border:1px solid var(--tungsten-dim);overflow:auto;"><code style="font-family:var(--font-mono);font-size:12px;">${code.replace(/\n+$/, "")}</code></pre>`);
  h = h.replace(/`([^`\n]+)`/g, '<code style="background:var(--muted);color:var(--filament-amber);padding:1px 4px;border-radius:3px;font-family:var(--font-mono);">$1</code>');
  h = h.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
  h = h.replace(/\*(.+?)\*/g, "<em>$1</em>");
  h = h.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_m, t, href) => `<a href="${safeUrl(href)}" target="_blank" rel="noreferrer" style="color:var(--electric-teal);text-decoration:underline;">${t}</a>`);
  h = h.replace(/\n/g, "<br/>");
  return h;
}
function Bubble({ role, content, streaming }) {
  const isUser = role === "user";
  const isSystem = role === "system";
  const align = isUser ? "flex-end" : "flex-start";
  const bg = isUser ? "color-mix(in srgb, var(--electric-teal) 16%, var(--void-main))" : isSystem ? "transparent" : "var(--obsidian-plate)";
  const border = isSystem ? "none" : "1px solid var(--tungsten-dim)";
  const label = isUser ? "You" : isSystem ? "System" : "Assistant";
  return /* @__PURE__ */ React.createElement("div", { style: { display: "flex", flexDirection: "column", alignItems: align, gap: 2, maxWidth: "100%" } }, /* @__PURE__ */ React.createElement("span", { style: { fontSize: 10, color: "var(--muted-foreground)", fontFamily: tokens.font.mono, padding: "0 4px" } }, label), /* @__PURE__ */ React.createElement("div", { style: {
    maxWidth: "85%",
    background: bg,
    border,
    borderRadius: "var(--radius)",
    padding: isSystem ? "2px 6px" : "8px 12px",
    color: isSystem ? "var(--muted-foreground)" : "var(--signal-white)",
    fontFamily: tokens.font.sans,
    fontSize: 14,
    lineHeight: 1.55,
    wordBreak: "break-word",
    fontStyle: isSystem ? "italic" : "normal"
  } }, /* @__PURE__ */ React.createElement("span", { dangerouslySetInnerHTML: { __html: mdToHtml(content) } }), streaming && /* @__PURE__ */ React.createElement("span", { style: { opacity: 0.6 } }, "\u258D")));
}
function Transcript({ messages, footer }) {
  return /* @__PURE__ */ React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 12, padding: 16 } }, messages.length === 0 && /* @__PURE__ */ React.createElement("div", { style: { color: "var(--muted-foreground)", fontFamily: tokens.font.mono, fontSize: 12, textAlign: "center", padding: 24 } }, "No messages yet."), messages.map((m, i) => /* @__PURE__ */ React.createElement(Bubble, { key: i, role: m.role, content: m.content })), footer);
}
function ChatLog() {
  const { content, saveContent, isReadOnly } = useCollimateFile();
  const [editing, setEditing] = useState(false);
  const [local, setLocal] = useState(content);
  const debouncedSave = useDebouncedSaveContent(saveContent);
  useEffect(() => {
    setLocal(content);
  }, [content]);
  const messages = parseChatlog(local);
  return /* @__PURE__ */ React.createElement("div", { style: { display: "flex", flexDirection: "column", width: "100%", height: "100%", background: "var(--void-main)" } }, /* @__PURE__ */ React.createElement("div", { style: { height: 26, flexShrink: 0, display: "flex", alignItems: "center", gap: 8, padding: "0 10px", background: "var(--obsidian-plate)", borderBottom: "1px solid var(--tungsten-dim)", fontFamily: tokens.font.mono, fontSize: 11 } }, /* @__PURE__ */ React.createElement("span", { style: { color: "var(--muted-foreground)" } }, "chat log \xB7 ", messages.length, " message", messages.length === 1 ? "" : "s"), !isReadOnly && /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setEditing((e) => !e),
      style: { marginLeft: "auto", height: 18, padding: "0 8px", background: editing ? "color-mix(in srgb, var(--electric-teal) 35%, var(--void-main))" : "var(--muted)", border: "1px solid var(--tungsten-dim)", borderRadius: "var(--radius-sm)", color: "var(--signal-white)", fontFamily: tokens.font.mono, fontSize: 10, cursor: "pointer" }
    },
    editing ? "Done" : "Edit"
  )), editing ? /* @__PURE__ */ React.createElement(
    "textarea",
    {
      value: local,
      onChange: (e) => {
        setLocal(e.target.value);
        debouncedSave(e.target.value);
      },
      spellCheck: false,
      style: { flex: 1, background: "transparent", color: "var(--signal-white)", fontFamily: tokens.font.mono, fontSize: 13, lineHeight: 1.6, padding: 16, border: "none", outline: "none", resize: "none" }
    }
  ) : /* @__PURE__ */ React.createElement("div", { style: { flex: 1, overflowY: "auto" } }, /* @__PURE__ */ React.createElement(Transcript, { messages })));
}
var main_default = defineRenderer({ component: ChatLog });
export {
  Bubble,
  Transcript,
  main_default as default,
  mdToHtml,
  parseChatlog
};
