import React, { useEffect, useRef, useState } from "https://esm.sh/react@18";
import * as CrepeMod from "https://esm.sh/@milkdown/crepe@7.21.2?deps=codemirror@6.0.1";
import { $prose } from "https://esm.sh/@milkdown/kit@7.21.2/utils?deps=codemirror@6.0.1";
import { Plugin, PluginKey } from "https://esm.sh/@milkdown/kit@7.21.2/prose/state?deps=codemirror@6.0.1";
import { Decoration, DecorationSet } from "https://esm.sh/@milkdown/kit@7.21.2/prose/view?deps=codemirror@6.0.1";
import {
  defineRenderer,
  useCollimateFile,
  useTheme
} from "/api/sdk/react.js";
const Crepe = CrepeMod.Crepe || CrepeMod.default?.Crepe || CrepeMod.default;
function applySchemeToDocument(scheme) {
  document.documentElement.setAttribute("data-theme", scheme);
  if (scheme === "dark") document.documentElement.classList.add("dark");
  else document.documentElement.classList.remove("dark");
}
const ZOOM_KEY = "collimate.milkdown.readerZoom";
const ZOOM_MIN = 0.7;
const ZOOM_MAX = 2.2;
const ZOOM_STEP = 0.1;
const clampZoom = (v) => Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, Math.round(v * 100) / 100));
function readStoredZoom() {
  try {
    const v = parseFloat(localStorage.getItem(ZOOM_KEY) || "");
    return Number.isFinite(v) ? clampZoom(v) : 1;
  } catch {
    return 1;
  }
}
function foldKey(level, text) {
  return level + "|" + (text || "").replace(/\s+/g, " ").trim().slice(0, 240);
}
let foldSupported = true;
function createFoldPlugin(foldStateRef) {
  const key = new PluginKey("colmd-fold");
  const toggleFromWidget = (view, getPos) => {
    const pos = getPos();
    if (pos == null) return;
    let heading;
    try {
      heading = view.state.doc.resolve(pos).parent;
    } catch {
      return;
    }
    if (!heading || heading.type.name !== "heading") return;
    const fkey = foldKey(heading.attrs.level || 1, heading.textContent);
    const set = foldStateRef.current;
    if (set.has(fkey)) set.delete(fkey);
    else set.add(fkey);
    view.dispatch(view.state.tr.setMeta(key, true));
  };
  const widget = (className) => (view, getPos) => {
    const el = document.createElement("span");
    el.className = className;
    el.setAttribute("contenteditable", "false");
    el.addEventListener("mousedown", (e) => {
      e.preventDefault();
      e.stopPropagation();
      toggleFromWidget(view, getPos);
    });
    return el;
  };
  const build = (state) => {
    const { doc, selection } = state;
    const head = selection.head;
    const tops = [];
    doc.forEach((node, offset) => {
      tops.push({ node, offset });
    });
    const decos = [];
    for (let i = 0; i < tops.length; i++) {
      const { node, offset } = tops[i];
      if (node.type.name !== "heading") continue;
      const level = node.attrs.level || 1;
      const folded = foldStateRef.current.has(foldKey(level, node.textContent));
      const active = head > offset && head < offset + node.nodeSize;
      const cls = ["colmd-foldable"];
      if (folded) cls.push("colmd-folded");
      if (active) cls.push("colmd-active");
      decos.push(Decoration.node(offset, offset + node.nodeSize, { class: cls.join(" ") }));
      decos.push(Decoration.widget(
        offset + 1,
        widget("colmd-fold-toggle"),
        { side: -1, ignoreSelection: true, key: "colmd-fold-toggle" }
      ));
      if (!folded) continue;
      decos.push(Decoration.widget(
        offset + node.nodeSize - 1,
        widget("colmd-fold-ellipsis"),
        { side: 1, ignoreSelection: true, key: "colmd-fold-ellipsis" }
      ));
      for (let j = i + 1; j < tops.length; j++) {
        const sib = tops[j];
        if (sib.node.type.name === "heading" && (sib.node.attrs.level || 1) <= level) break;
        decos.push(Decoration.node(sib.offset, sib.offset + sib.node.nodeSize, {
          style: "display: none;"
        }));
      }
    }
    return DecorationSet.create(doc, decos);
  };
  return new Plugin({
    key,
    state: {
      init: (_config, state) => build(state),
      // Rebuild on doc changes, explicit fold toggles, AND selection moves
      // (so the caret entering/leaving a heading flips colmd-active).
      apply: (tr, value, _old, newState) => {
        if (tr.docChanged || tr.getMeta(key) || tr.selectionSet) return build(newState);
        return value.map(tr.mapping, tr.doc);
      }
    },
    props: {
      decorations(state) {
        return key.getState(state);
      }
    }
  });
}
function ReaderSizeControl({ zoom, setZoom, scheme }) {
  const [hovered, setHovered] = useState(false);
  const dark = scheme === "dark";
  const bg = dark ? "#232323" : "#f4f4f4";
  const border = dark ? "#3a3a3a" : "#d6d6d6";
  const fg = dark ? "#d1d1d1" : "#333333";
  const btn = {
    appearance: "none",
    border: "none",
    background: "transparent",
    color: fg,
    cursor: "pointer",
    fontFamily: "Arial, Helvetica, sans-serif",
    fontWeight: 600,
    lineHeight: 1,
    padding: "4px 7px",
    borderRadius: 5
  };
  return /* @__PURE__ */ React.createElement(
    "div",
    {
      onMouseEnter: () => setHovered(true),
      onMouseLeave: () => setHovered(false),
      style: {
        position: "absolute",
        top: 8,
        right: 12,
        zIndex: 20,
        display: "flex",
        alignItems: "center",
        gap: 1,
        padding: 2,
        borderRadius: 8,
        background: bg,
        border: `1px solid ${border}`,
        boxShadow: dark ? "0 1px 3px rgba(0,0,0,0.4)" : "0 1px 3px rgba(0,0,0,0.12)",
        opacity: hovered ? 1 : 0.45,
        transition: "opacity 0.15s ease",
        userSelect: "none"
      }
    },
    /* @__PURE__ */ React.createElement(
      "button",
      {
        title: "Smaller text",
        "aria-label": "Decrease text size",
        disabled: zoom <= ZOOM_MIN,
        onClick: () => setZoom((z) => clampZoom(z - ZOOM_STEP)),
        style: { ...btn, fontSize: 12, opacity: zoom <= ZOOM_MIN ? 0.4 : 1 }
      },
      "A\u2212"
    ),
    /* @__PURE__ */ React.createElement(
      "button",
      {
        title: "Reset text size",
        "aria-label": "Reset text size",
        onClick: () => setZoom(1),
        style: { ...btn, fontSize: 11, minWidth: 38, fontVariantNumeric: "tabular-nums" }
      },
      Math.round(zoom * 100),
      "%"
    ),
    /* @__PURE__ */ React.createElement(
      "button",
      {
        title: "Larger text",
        "aria-label": "Increase text size",
        disabled: zoom >= ZOOM_MAX,
        onClick: () => setZoom((z) => clampZoom(z + ZOOM_STEP)),
        style: { ...btn, fontSize: 17, opacity: zoom >= ZOOM_MAX ? 0.4 : 1 }
      },
      "A+"
    )
  );
}
function MilkdownEditor() {
  const { content, saveContent, isReadOnly, api } = useCollimateFile();
  const { scheme, onChange: onThemeChange } = useTheme(api);
  const containerRef = useRef(null);
  const crepeRef = useRef(null);
  const lastEmittedRef = useRef(content || "");
  const saveContentRef = useRef(saveContent);
  saveContentRef.current = saveContent;
  const foldStateRef = useRef(/* @__PURE__ */ new Set());
  const [zoom, setZoom] = useState(readStoredZoom);
  useEffect(() => {
    try {
      document.documentElement.style.setProperty("--colmd-zoom", String(zoom));
    } catch {
    }
    try {
      localStorage.setItem(ZOOM_KEY, String(zoom));
    } catch {
    }
  }, [zoom]);
  useEffect(() => {
    if (!containerRef.current) return;
    let cancelled = false;
    let unsubFiles = null;
    let unsubSetContent = null;
    let unsubFlush = null;
    applySchemeToDocument(scheme);
    const replaceContent = async (fresh) => {
      if (cancelled || !crepeRef.current || !containerRef.current) return;
      if (fresh == null || fresh === lastEmittedRef.current) return;
      crepeRef.current.destroy();
      crepeRef.current = null;
      const next = await createWithFallback(fresh);
      if (cancelled) {
        next.destroy();
        return;
      }
      if (isReadOnly) next.setReadonly(true);
      crepeRef.current = next;
      lastEmittedRef.current = fresh;
    };
    const buildCrepe = (initial) => {
      const c = new Crepe({
        root: containerRef.current,
        defaultValue: initial || "",
        // Drop the "Please enter…" block placeholder that trails the
        // caret on empty lines. Feature value is the stable enum
        // string 'placeholder' (fall back to it if the static enum
        // isn't on this build of Crepe).
        features: {
          [Crepe.Feature && Crepe.Feature.Placeholder || "placeholder"]: false
        }
      });
      if (foldSupported) {
        try {
          c.editor.use($prose(() => createFoldPlugin(foldStateRef)));
        } catch {
          foldSupported = false;
        }
      }
      if (!isReadOnly) {
        c.on((listener) => {
          listener.markdownUpdated((ctx, markdown) => {
            if (markdown === lastEmittedRef.current) return;
            lastEmittedRef.current = markdown;
            saveContent(markdown);
          });
        });
      }
      return c;
    };
    const createWithFallback = async (initial) => {
      let c = buildCrepe(initial);
      try {
        await c.create();
        return c;
      } catch (e) {
        try {
          c.destroy();
        } catch {
        }
        if (!foldSupported) throw e;
        foldSupported = false;
        c = buildCrepe(initial);
        await c.create();
        return c;
      }
    };
    (async () => {
      await api.loadCSS("https://cdn.jsdelivr.net/npm/@milkdown/crepe@7.21.2/lib/theme/common/style.css");
      api.injectStyle(`
                html, body { margin: 0; padding: 0; width: 100%; height: 100%; overflow: hidden; background: #ffffff; }
                html[data-theme="dark"], html[data-theme="dark"] body { background: #1a1a1a; }

                /* Light palette \u2014 crepe frame defaults. */
                .milkdown {
                    --crepe-color-background: #ffffff;
                    --crepe-color-on-background: #000000;
                    --crepe-color-surface: #f7f7f7;
                    --crepe-color-surface-low: #ededed;
                    --crepe-color-on-surface: #1c1c1c;
                    --crepe-color-on-surface-variant: #4d4d4d;
                    --crepe-color-outline: #a8a8a8;
                    --crepe-color-primary: #333333;
                    --crepe-color-secondary: #cfcfcf;
                    --crepe-color-on-secondary: #000000;
                    --crepe-color-inverse: #f0f0f0;
                    --crepe-color-on-inverse: #1a1a1a;
                    --crepe-color-inline-code: #ba1a1a;
                    --crepe-color-error: #ba1a1a;
                    --crepe-color-hover: #e0e0e0;
                    --crepe-color-selected: #d5d5d5;
                    --crepe-color-inline-area: #cacaca;
                    --crepe-font-title: 'Noto Serif', Cambria, 'Times New Roman', Times, serif;
                    --crepe-font-default: 'Noto Sans', Arial, Helvetica, sans-serif;
                    --crepe-font-code: 'Space Mono', Fira Code, Menlo, Monaco, 'Courier New', Courier, monospace;
                    --crepe-shadow-1: 0px 1px 3px 1px rgba(0,0,0,0.15), 0px 1px 2px 0px rgba(0,0,0,0.3);
                    --crepe-shadow-2: 0px 2px 6px 2px rgba(0,0,0,0.15), 0px 1px 2px 0px rgba(0,0,0,0.3);
                }

                /* Dark palette \u2014 crepe frame-dark defaults. */
                html[data-theme="dark"] .milkdown {
                    --crepe-color-background: #1a1a1a;
                    --crepe-color-on-background: #e6e6e6;
                    --crepe-color-surface: #121212;
                    --crepe-color-surface-low: #1c1c1c;
                    --crepe-color-on-surface: #d1d1d1;
                    --crepe-color-on-surface-variant: #a9a9a9;
                    --crepe-color-outline: #757575;
                    --crepe-color-primary: #b5b5b5;
                    --crepe-color-secondary: #4d4d4d;
                    --crepe-color-on-secondary: #d6d6d6;
                    --crepe-color-inverse: #e5e5e5;
                    --crepe-color-on-inverse: #2a2a2a;
                    --crepe-color-inline-code: #ff6666;
                    --crepe-color-error: #ff6666;
                    --crepe-color-hover: #232323;
                    --crepe-color-selected: #2f2f2f;
                    --crepe-color-inline-area: #2b2b2b;
                    --crepe-shadow-1: 0px 1px 2px 0px rgba(255,255,255,0.3), 0px 1px 3px 1px rgba(255,255,255,0.15);
                    --crepe-shadow-2: 0px 1px 2px 0px rgba(255,255,255,0.3), 0px 2px 6px 2px rgba(255,255,255,0.15);
                }

                /* .milkdown is the content shell. Give it the theme bg and
                   min-height: 100% so the surface colour extends below
                   the last paragraph instead of clinging to just the
                   text (the default \u2014 .milkdown's built-in rules leave
                   it transparent and shrink to content, which let the
                   iframe's body bg peek through only around the text
                   block). */
                .milkdown { background: var(--crepe-color-background); min-height: 100%; }

                /* Reader text size. zoom (not font-size) so it scales every
                   content element uniformly \u2014 crepe sizes headings in
                   absolute px, which font-size on the container wouldn't
                   touch. Chromium reports post-zoom rects, so crepe's
                   floating chrome (slash menu, toolbar) still positions
                   correctly. Defaults to 1 until the React effect sets the
                   var from the persisted value. */
                .milkdown .ProseMirror { zoom: var(--colmd-zoom, 1); }

                /* The left block handle (the "+" / drag grip that tracks the
                   mouse down the left margin) is hidden \u2014 it's the one bit of
                   crepe chrome we don't want. The slash menu (type "/") still
                   works; it's a separate widget. */
                .milkdown .milkdown-block-handle { display: none !important; }

                /* Reading measure. Left padding is now symmetric-ish with the
                   right (the old 88px only existed to clear the block handle,
                   which is gone) but keeps ~48px of gutter for the fold
                   chevron to sit in. */
                .milkdown .ProseMirror { padding: 24px 48px 24px 48px; min-height: 100%; outline: none; }

                /* Crepe's "Please enter\u2026" placeholder. The feature is also
                   disabled at construction; this hides the decoration's
                   ::before belt-and-suspenders so no prompt text trails the
                   caret on an empty line. */
                .milkdown .ProseMirror .crepe-placeholder::before { content: none !important; }

                /* Obsidian-style heading fold control.
                   The chevron is a real <span> WIDGET decoration (not a pseudo)
                   so it owns its own click handler \u2014 toggling is independent of
                   the reader-zoom and needs no clientX math. It's absolutely
                   positioned in the left gutter and made 30px wide so its hit
                   area runs flush to the heading text: hovering text \u2192 chevron
                   is one continuous region, no dead gap to cross.
                   It is revealed ONLY when the heading row is hovered or holds
                   the caret (.colmd-active) \u2014 never on a bare editor hover, and
                   never by hovering the body blocks beneath the heading. While
                   collapsed it stays visible (and rotated). */
                .milkdown .ProseMirror .colmd-foldable { position: relative; }
                .milkdown .ProseMirror .colmd-fold-toggle {
                    position: absolute;
                    left: -30px;
                    top: 0;
                    width: 30px;
                    height: 1.3em;
                    display: flex;
                    align-items: center;
                    justify-content: flex-start;
                    padding-left: 6px;
                    box-sizing: border-box;
                    opacity: 0;
                    transition: opacity 0.12s ease;
                    cursor: pointer;
                    user-select: none;
                }
                .milkdown .ProseMirror .colmd-fold-toggle::before {
                    content: '';
                    width: 0;
                    height: 0;
                    border-style: solid;
                    border-width: 6px 4px 0 4px;
                    border-color: var(--crepe-color-on-surface-variant, #888) transparent transparent transparent;
                }
                .milkdown .ProseMirror .colmd-foldable:hover > .colmd-fold-toggle,
                .milkdown .ProseMirror .colmd-foldable.colmd-active > .colmd-fold-toggle { opacity: 0.5; }
                .milkdown .ProseMirror .colmd-foldable.colmd-folded > .colmd-fold-toggle { opacity: 0.9; }
                .milkdown .ProseMirror .colmd-fold-toggle:hover { opacity: 1; }
                .milkdown .ProseMirror .colmd-foldable.colmd-folded > .colmd-fold-toggle::before {
                    border-width: 4px 0 4px 6px;
                    border-color: transparent transparent transparent var(--crepe-color-on-surface-variant, #888);
                }

                /* Obsidian-style "\u2026" trailing a collapsed heading, signalling
                   hidden content. A clickable widget (unfolds on click). */
                .milkdown .ProseMirror .colmd-fold-ellipsis {
                    margin-left: 0.4em;
                    opacity: 0.4;
                    cursor: pointer;
                    user-select: none;
                }
                .milkdown .ProseMirror .colmd-fold-ellipsis::before { content: '\u2026'; }
                .milkdown .ProseMirror .colmd-fold-ellipsis:hover { opacity: 0.7; }

                /* Crepe's reset.css sets margin-top on h1\u2013h6 (32/28/24/20/16/16px)
                   to space headings from preceding content. On the very first
                   block that margin lives ABOVE the first line \u2014 visible as an
                   "extra line" at the top when the cursor lands there. Zero it
                   out so the top line sits flush with the editor's top padding.
                   The second selector handles the moment a selection starts:
                   prosemirror-virtual-cursor inserts a zero-height div as the
                   ACTUAL first DOM child, knocking the heading out of
                   :first-child. Without the sibling rule the heading's
                   margin-top suddenly reappears and the document visibly jumps
                   by 32px the moment you click+drag (CSS :first-child matches
                   on DOM order, ignoring display, so display:none on the
                   cursor doesn't fix this). */
                .milkdown .ProseMirror > *:first-child,
                .milkdown .ProseMirror > .prosemirror-virtual-cursor + *,
                .milkdown .ProseMirror > .ProseMirror-widget:first-child + * { margin-top: 0; }

                /* Disable prosemirror-virtual-cursor.
                   Milkdown ships a custom caret renderer whose -left /
                   -right variants paint L-shaped border overlays that
                   dangle ABOVE the caret by 1ch \xD7 line-height (see
                   prosemirror-virtual-cursor/style/virtual-cursor.css).
                   At position 0 of the document the -left variant
                   hangs above-and-before the first line \u2014 that's the
                   "phantom line" above the top and the cursor you see
                   briefly when holding arrow-up. Making a selection
                   hides the caret entirely so the phantom vanishes.
                   The native browser caret handles everything the
                   virtual cursor did for our case, so force caret-color
                   back and hide the virtual cursor DOM. */
                .milkdown .ProseMirror,
                .milkdown .ProseMirror.virtual-cursor-enabled {
                    caret-color: auto !important;
                }
                /* Drop the .milkdown ancestor: the cursor is a child of
                   .ProseMirror but the original scope was overspecific in
                   ways that didn't bite earlier. Cover the -animation
                   variant explicitly \u2014 it's the one that fires on
                   selection. (Note: display:none on the cursor does NOT
                   fix the heading jump on its own \u2014 the cursor still
                   inserts as a DOM first-child and CSS :first-child
                   matches by DOM order regardless of display. The
                   jump fix is the sibling rule above.) */
                .prosemirror-virtual-cursor,
                .prosemirror-virtual-cursor-animation,
                .prosemirror-virtual-cursor-left,
                .prosemirror-virtual-cursor-right {
                    display: none !important;
                }

                /* Belt-and-suspenders: also suppress the legacy
                   ProseMirror gap-cursor, which would render a short
                   horizontal bar above the first block for a different
                   reason (non-text-node entry points). Harmless to
                   keep disabled for a markdown editor. */
                .milkdown .ProseMirror-gapcursor,
                .milkdown .ProseMirror-focused .ProseMirror-gapcursor {
                    display: none !important;
                }
            `);
      if (cancelled || !containerRef.current) return;
      const crepe = await createWithFallback(content);
      if (cancelled) {
        crepe.destroy();
        return;
      }
      if (isReadOnly) crepe.setReadonly(true);
      crepeRef.current = crepe;
      lastEmittedRef.current = content || "";
      if (api.ready) api.ready();
      if (api.onFilesChanged) {
        unsubFiles = api.onFilesChanged(async () => {
          let fresh;
          try {
            fresh = await api.getSiblingFile(api.getFilename());
          } catch {
            return;
          }
          await replaceContent(fresh);
        });
      }
      if (api.onSetContent) {
        unsubSetContent = api.onSetContent((next) => {
          void replaceContent(next);
        });
      }
      if (api.onFlush) {
        unsubFlush = api.onFlush(() => {
          const crepe2 = crepeRef.current;
          if (!crepe2 || isReadOnly) return;
          let md;
          try {
            md = crepe2.getMarkdown();
          } catch {
            return;
          }
          if (md == null || md === lastEmittedRef.current) return;
          lastEmittedRef.current = md;
          saveContentRef.current(md);
        });
      }
    })();
    const unsubTheme = onThemeChange(applySchemeToDocument);
    return () => {
      cancelled = true;
      if (unsubFiles) unsubFiles();
      if (unsubSetContent) unsubSetContent();
      if (unsubFlush) unsubFlush();
      if (unsubTheme) unsubTheme();
      if (crepeRef.current) crepeRef.current.destroy();
      crepeRef.current = null;
    };
  }, []);
  return /* @__PURE__ */ React.createElement("div", { style: { position: "relative", width: "100%", height: "100%" } }, /* @__PURE__ */ React.createElement("div", { ref: containerRef, style: { width: "100%", height: "100%", overflowY: "auto", overflowAnchor: "none", scrollPaddingTop: "24px" } }), /* @__PURE__ */ React.createElement(ReaderSizeControl, { zoom, setZoom, scheme }));
}
var main_default = defineRenderer({ component: MilkdownEditor, deferReady: true });
export {
  main_default as default
};
