import React, { useState, useEffect, useRef } from "https://esm.sh/react@18";
import { defineRenderer, useCollimateFile } from "/api/sdk/react.js";
function ImageViewer() {
  const { fileName, api } = useCollimateFile();
  const [imgUrl, setImgUrl] = useState(null);
  const [error, setError] = useState(null);
  const [naturalSize, setNaturalSize] = useState(null);
  const [zoom, setZoom] = useState(1);
  const [retryNonce, setRetryNonce] = useState(0);
  const containerRef = useRef(null);
  const ext = fileName.split(".").pop()?.toLowerCase() || "";
  useEffect(() => {
    const url = api.getFileUrl(fileName);
    setImgUrl(url);
    setError(null);
    setNaturalSize(null);
    setZoom(1);
  }, [fileName, api, retryNonce]);
  const handleLoad = (e) => {
    const img = e.currentTarget;
    setNaturalSize({ w: img.naturalWidth, h: img.naturalHeight });
  };
  const handleError = () => {
    setError(`Could not display \u201C${fileName}\u201D \u2014 the file may be empty, corrupt, or an unsupported format (.${ext}).`);
  };
  const btnStyle = {
    background: "none",
    border: "1px solid var(--tungsten-dim, #2a2d3a)",
    color: "var(--comment-grey, #6b7280)",
    cursor: "pointer",
    padding: "1px 6px",
    borderRadius: 3,
    fontSize: 10,
    fontFamily: "var(--font-mono, monospace)"
  };
  return /* @__PURE__ */ React.createElement("div", { style: {
    width: "100%",
    height: "100%",
    display: "flex",
    flexDirection: "column",
    background: "var(--renderer-surface, #1a1a1a)",
    overflow: "hidden"
  } }, /* @__PURE__ */ React.createElement(
    "div",
    {
      ref: containerRef,
      style: {
        flex: 1,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        overflow: "auto",
        padding: 16,
        // Checkerboard uses the panel color so transparency looks right
        // against whatever the current theme paints on.
        backgroundImage: "linear-gradient(45deg, var(--obsidian-plate, #1a1c23) 25%, transparent 25%), linear-gradient(-45deg, var(--obsidian-plate, #1a1c23) 25%, transparent 25%), linear-gradient(45deg, transparent 75%, var(--obsidian-plate, #1a1c23) 75%), linear-gradient(-45deg, transparent 75%, var(--obsidian-plate, #1a1c23) 75%)",
        backgroundSize: "20px 20px",
        backgroundPosition: "0 0, 0 10px, 10px -10px, -10px 0px"
      }
    },
    error ? /* @__PURE__ */ React.createElement("div", { style: { display: "flex", flexDirection: "column", alignItems: "center", gap: 10, textAlign: "center", maxWidth: 420 } }, /* @__PURE__ */ React.createElement("div", { style: { color: "var(--signal-white, #e2e8f0)", fontSize: 13, fontWeight: 600 } }, fileName), /* @__PURE__ */ React.createElement("div", { style: { color: "var(--muted-foreground, #9ca3af)", fontSize: 12, lineHeight: 1.5 } }, error), /* @__PURE__ */ React.createElement("button", { onClick: () => setRetryNonce((n) => n + 1), style: btnStyle }, "Retry")) : imgUrl ? /* @__PURE__ */ React.createElement(
      "img",
      {
        key: retryNonce,
        src: imgUrl,
        onLoad: handleLoad,
        onError: handleError,
        style: {
          maxWidth: zoom === 1 ? "100%" : "none",
          maxHeight: zoom === 1 ? "100%" : "none",
          width: zoom !== 1 ? `${zoom * 100}%` : "auto",
          height: "auto",
          objectFit: "contain",
          imageRendering: zoom > 2 ? "pixelated" : "auto"
        },
        draggable: false
      }
    ) : /* @__PURE__ */ React.createElement("div", { style: { color: "var(--muted-foreground, #9ca3af)", fontFamily: "var(--font-mono, monospace)", fontSize: 12 } }, "loading\u2026")
  ), /* @__PURE__ */ React.createElement("div", { style: {
    height: 26,
    background: "var(--obsidian-plate, #1a1c23)",
    borderTop: "1px solid var(--tungsten-dim, #2a2d3a)",
    display: "flex",
    alignItems: "center",
    padding: "0 12px",
    gap: 16,
    fontFamily: "var(--font-mono, monospace)",
    fontSize: 10,
    color: "var(--comment-grey, #6b7280)",
    flexShrink: 0
  } }, /* @__PURE__ */ React.createElement("span", null, fileName), naturalSize && /* @__PURE__ */ React.createElement("span", null, naturalSize.w, " x ", naturalSize.h), /* @__PURE__ */ React.createElement("span", null, ext.toUpperCase()), /* @__PURE__ */ React.createElement("div", { style: { marginLeft: "auto", display: "flex", gap: 8, alignItems: "center" } }, /* @__PURE__ */ React.createElement("button", { onClick: () => setZoom((z) => Math.max(0.25, z / 2)), style: btnStyle }, "-"), /* @__PURE__ */ React.createElement("span", null, Math.round(zoom * 100), "%"), /* @__PURE__ */ React.createElement("button", { onClick: () => setZoom((z) => Math.min(8, z * 2)), style: btnStyle }, "+"), /* @__PURE__ */ React.createElement("button", { onClick: () => setZoom(1), style: btnStyle }, "Fit"))));
}
var main_default = defineRenderer({ component: ImageViewer });
export {
  main_default as default
};
