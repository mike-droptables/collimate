import React, { useState, useEffect, useRef } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

function ImageViewer() {
    const { fileName, api } = useCollimateFile();
    const [imgUrl, setImgUrl] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [naturalSize, setNaturalSize] = useState<{ w: number; h: number } | null>(null);
    const [zoom, setZoom] = useState(1);
    const [retryNonce, setRetryNonce] = useState(0);
    const containerRef = useRef<HTMLDivElement>(null);

    const ext = fileName.split('.').pop()?.toLowerCase() || '';

    useEffect(() => {
        const url = api.getFileUrl(fileName);
        setImgUrl(url);
        setError(null);
        setNaturalSize(null);
        setZoom(1);
    }, [fileName, api, retryNonce]);

    const handleLoad = (e: React.SyntheticEvent<HTMLImageElement>) => {
        const img = e.currentTarget;
        setNaturalSize({ w: img.naturalWidth, h: img.naturalHeight });
    };

    const handleError = () => {
        setError(`Could not display “${fileName}” — the file may be empty, corrupt, or an unsupported format (.${ext}).`);
    };

    const btnStyle: React.CSSProperties = {
        background: 'none', border: '1px solid var(--tungsten-dim, #2a2d3a)', color: 'var(--comment-grey, #6b7280)',
        cursor: 'pointer', padding: '1px 6px', borderRadius: 3, fontSize: 10,
        fontFamily: 'var(--font-mono, monospace)',
    };

    return (
        <div style={{
            width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
            background: 'var(--renderer-surface, #1a1a1a)', overflow: 'hidden',
        }}>
            <div
                ref={containerRef}
                style={{
                    flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
                    overflow: 'auto', padding: 16,
                    // Checkerboard uses the panel color so transparency looks right
                    // against whatever the current theme paints on.
                    backgroundImage: 'linear-gradient(45deg, var(--obsidian-plate, #1a1c23) 25%, transparent 25%), linear-gradient(-45deg, var(--obsidian-plate, #1a1c23) 25%, transparent 25%), linear-gradient(45deg, transparent 75%, var(--obsidian-plate, #1a1c23) 75%), linear-gradient(-45deg, transparent 75%, var(--obsidian-plate, #1a1c23) 75%)',
                    backgroundSize: '20px 20px',
                    backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px',
                }}
            >
                {error ? (
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, textAlign: 'center', maxWidth: 420 }}>
                        <div style={{ color: 'var(--signal-white, #e2e8f0)', fontSize: 13, fontWeight: 600 }}>{fileName}</div>
                        <div style={{ color: 'var(--muted-foreground, #9ca3af)', fontSize: 12, lineHeight: 1.5 }}>{error}</div>
                        <button onClick={() => setRetryNonce(n => n + 1)} style={btnStyle}>Retry</button>
                    </div>
                ) : imgUrl ? (
                    <img
                        key={retryNonce}
                        src={imgUrl}
                        onLoad={handleLoad}
                        onError={handleError}
                        style={{
                            maxWidth: zoom === 1 ? '100%' : 'none',
                            maxHeight: zoom === 1 ? '100%' : 'none',
                            width: zoom !== 1 ? `${zoom * 100}%` : 'auto',
                            height: 'auto',
                            objectFit: 'contain',
                            imageRendering: zoom > 2 ? 'pixelated' : 'auto',
                        }}
                        draggable={false}
                    />
                ) : (
                    <div style={{ color: 'var(--muted-foreground, #9ca3af)', fontFamily: 'var(--font-mono, monospace)', fontSize: 12 }}>loading…</div>
                )}
            </div>
            <div style={{
                height: 26, background: 'var(--obsidian-plate, #1a1c23)', borderTop: '1px solid var(--tungsten-dim, #2a2d3a)',
                display: 'flex', alignItems: 'center', padding: '0 12px', gap: 16,
                fontFamily: 'var(--font-mono, monospace)', fontSize: 10, color: 'var(--comment-grey, #6b7280)', flexShrink: 0,
            }}>
                <span>{fileName}</span>
                {naturalSize && <span>{naturalSize.w} x {naturalSize.h}</span>}
                <span>{ext.toUpperCase()}</span>
                <div style={{ marginLeft: 'auto', display: 'flex', gap: 8, alignItems: 'center' }}>
                    <button onClick={() => setZoom(z => Math.max(0.25, z / 2))} style={btnStyle}>-</button>
                    <span>{Math.round(zoom * 100)}%</span>
                    <button onClick={() => setZoom(z => Math.min(8, z * 2))} style={btnStyle}>+</button>
                    <button onClick={() => setZoom(1)} style={btnStyle}>Fit</button>
                </div>
            </div>
        </div>
    );
}

export default defineRenderer({ component: ImageViewer });
