import React, { useEffect, useMemo, useRef, useState } from "https://esm.sh/react@19.2.0";
import { createRoot } from "https://esm.sh/react-dom@19.2.0/client?deps=react@19.2.0";
import {
  ActionBarPrimitive,
  AssistantRuntimeProvider,
  AuiIf,
  BranchPickerPrimitive,
  ComposerPrimitive,
  ErrorPrimitive,
  MessagePrimitive,
  ThreadPrimitive,
  useExternalStoreRuntime,
  useMessage,
  useMessagePartReasoning,
  useMessagePartSource,
  useMessagePartText
} from "https://esm.sh/@assistant-ui/react@0.14.24?deps=react@19.2.0,react-dom@19.2.0";
import { MarkdownTextPrimitive } from "https://esm.sh/@assistant-ui/react-markdown@0.14.5?deps=react@19.2.0,react-dom@19.2.0,@assistant-ui/react@0.14.24";
import { createOpencodeClient, useOpenCodeRuntime } from "https://esm.sh/@assistant-ui/react-opencode@0.2.10?deps=react@19.2.0,react-dom@19.2.0,@assistant-ui/react@0.14.24";
import { apiOrigin, openSessionSocket, sessionWsUrl } from "/api/sdk/session.js";
import {
  ArrowDown,
  ArrowUp,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Copy,
  Loader,
  MessageSquarePlus,
  PanelLeftClose,
  PanelLeftOpen,
  Pencil,
  Plus,
  RefreshCw,
  Square,
  Trash2
} from "https://esm.sh/lucide-react@1.23.0?deps=react@19.2.0&exports=ArrowDown,ArrowUp,Check,ChevronDown,ChevronLeft,ChevronRight,ChevronUp,Copy,Loader,MessageSquarePlus,PanelLeftClose,PanelLeftOpen,Pencil,Plus,RefreshCw,Square,Trash2";
const PALETTES = {
  light: {
    bg: "#ffffff",
    panel: "#fafafa",
    fg: "#09090b",
    dim: "#71717a",
    muted: "#f4f4f5",
    active: "#e4e4e7",
    line: "#e4e4e7",
    destructive: "#dc2626"
  },
  dark: {
    bg: "#18181b",
    panel: "#131316",
    fg: "#fafafa",
    dim: "#a1a1aa",
    muted: "#27272a",
    active: "#3f3f46",
    line: "#2b2b30",
    destructive: "#ef4444"
  }
};
function paletteVars(scheme) {
  const p = PALETTES[scheme] || PALETTES.dark;
  return {
    "--aui-bg": p.bg,
    "--aui-panel": p.panel,
    "--aui-fg": p.fg,
    "--aui-dim": p.dim,
    "--aui-muted": p.muted,
    "--aui-active": p.active,
    "--aui-line": p.line,
    "--aui-destructive": p.destructive
  };
}
const T = {
  bg: "var(--aui-bg)",
  panel: "var(--aui-panel)",
  fg: "var(--aui-fg)",
  dim: "var(--aui-dim)",
  muted: "var(--aui-muted)",
  active: "var(--aui-active)",
  line: "var(--aui-line)",
  destructive: "var(--aui-destructive)",
  accent: "#0ea5e9",
  accentFg: "#000000"
};
function useScheme(api) {
  const initial = () => {
    try {
      const s = api?.getTheme?.().scheme;
      if (s === "light" || s === "dark") return s;
    } catch {
    }
    try {
      return matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
    } catch {
    }
    return "dark";
  };
  const [scheme, setScheme] = useState(initial);
  useEffect(() => {
    try {
      return api?.onThemeChange?.((t) => {
        if (t?.scheme === "light" || t?.scheme === "dark") setScheme(t.scheme);
      });
    } catch {
      return void 0;
    }
  }, [api]);
  return scheme;
}
const THREAD_MAX_WIDTH = 704;
const SHADOW_CSS = `
  *, *::before, *::after { box-sizing: border-box; }
  @keyframes aui-spin { to { transform: rotate(360deg); } }
  .aui-spin { animation: aui-spin 1s linear infinite; }
  @keyframes aui-pulse { 50% { opacity: .35; } }
  .aui-pulse { animation: aui-pulse 1.4s ease-in-out infinite; }
  [hidden] { display: none !important; }
  .aui-input::placeholder { color: ${T.dim}; opacity: .8; }
  .aui-composer { transition: border-color .15s; }
  .aui-composer:focus-within { border-color: color-mix(in srgb, ${T.fg} 55%, transparent); }
  .aui-stb[disabled] { visibility: hidden; }
  .aui-iconbtn { transition: background .12s, color .12s, opacity .12s; }
  .aui-iconbtn:hover:not([disabled]) { background: ${T.muted}; color: ${T.fg}; }
  .aui-listbtn:hover { background: ${T.muted}; }
`;
function parsePointer(raw) {
  try {
    const p = JSON.parse(raw);
    if (!p || typeof p !== "object") return null;
    return {
      session_id: p.session_id || "",
      ws_path: p.ws_path || "",
      token: p.token || "",
      label: p.label || "Chat",
      threads_dir: p.threads_dir || "chats",
      active_thread: p.active_thread || "main",
      threads: Array.isArray(p.threads) ? p.threads : [],
      integration: p.integration || null
    };
  } catch {
    return null;
  }
}
function parseTranscript(raw) {
  if (!raw || !raw.trim()) return [];
  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    return [];
  }
  const items = Array.isArray(data) ? data : data?.messages;
  if (!Array.isArray(items)) return [];
  const out = [];
  for (let i = 0; i < items.length; i++) {
    const m = items[i];
    if (!m || typeof m !== "object") continue;
    const role = String(m.role || "").toLowerCase();
    if (role !== "user" && role !== "assistant" && role !== "system") continue;
    out.push({
      id: `h${i}`,
      role,
      text: String(m.content ?? ""),
      // Thinking is an assistant-message concept — assistant-ui rejects
      // reasoning parts on other roles, so never carry it for them.
      thinking: role === "assistant" ? String(m.thinking ?? "") : ""
    });
  }
  return out;
}
function serializeTranscript(msgs) {
  const messages = msgs.map((m) => ({
    role: m.role,
    content: m.text || "",
    ...m.thinking ? { thinking: m.thinking } : {}
  }));
  return JSON.stringify({ messages }, null, 2) + "\n";
}
const convertMessage = (m) => ({
  id: m.id,
  role: m.role,
  content: [
    ...m.role === "assistant" && m.thinking ? [{ type: "reasoning", text: m.thinking }] : [],
    { type: "text", text: m.text }
  ]
});
const textOf = (m) => (m.content || []).map((p) => p.type === "text" ? p.text : "").join("").trim();
function useNativeChat(api, pointer) {
  const [threads, setThreads] = useState(pointer.threads);
  const [active, setActive] = useState(pointer.active_thread);
  const [messages, setMessages] = useState([]);
  const [runningThread, setRunningThread] = useState(null);
  const [unread, setUnread] = useState({});
  const [status, setStatus] = useState("connecting");
  const [banner, setBanner] = useState("");
  const sockRef = useRef(null);
  const streamsRef = useRef({});
  const activeRef = useRef(active);
  activeRef.current = active;
  const threadsRef = useRef(threads);
  threadsRef.current = threads;
  const messagesRef = useRef(messages);
  messagesRef.current = messages;
  const runningThreadRef = useRef(runningThread);
  runningThreadRef.current = runningThread;
  const persistQueueRef = useRef(Promise.resolve());
  const markUnread = React.useCallback((tid) => {
    if (tid !== activeRef.current) {
      setUnread((prev) => prev[tid] ? prev : { ...prev, [tid]: true });
    }
  }, []);
  const clearUnread = React.useCallback((tid) => {
    setUnread((prev) => {
      if (!prev[tid]) return prev;
      const next = { ...prev };
      delete next[tid];
      return next;
    });
  }, []);
  const threadFile = React.useCallback((tid) => {
    const entry = pointer.threads.find((t) => t.id === tid) || threadsRef.current.find((t) => t.id === tid);
    return entry?.file || `${pointer.threads_dir}/${tid}.json`;
  }, [pointer.threads, pointer.threads_dir]);
  const loadThread = React.useCallback(async (tid) => {
    try {
      const raw = await api.getSiblingFile(threadFile(tid));
      const parsed = parseTranscript(typeof raw === "string" ? raw : "");
      setMessages((prev) => {
        const stream = tid === activeRef.current ? streamsRef.current[tid] : void 0;
        const live = stream ? { id: stream.id, role: "assistant", text: stream.text, thinking: stream.thinking } : void 0;
        const base = live ? prev.filter((m) => m.id !== live.id) : prev;
        let next = parsed;
        if (base.length === parsed.length) {
          next = parsed.map((p, i) => base[i].role === p.role && base[i].text === p.text ? { ...p, id: base[i].id } : p);
          const ids = new Set(next.map((m) => m.id));
          if (ids.size !== next.length) next = parsed;
        }
        return live ? [...next, live] : next;
      });
    } catch {
      setMessages([]);
    }
  }, [api, threadFile]);
  useEffect(() => {
    loadThread(active);
  }, [active, loadThread]);
  useEffect(() => {
    const off = api.onFilesChanged?.(() => loadThread(activeRef.current));
    return () => {
      try {
        off && off();
      } catch {
      }
    };
  }, [api, loadThread]);
  useEffect(() => {
    if (!pointer.ws_path) {
      setStatus("closed");
      return;
    }
    const ensureStream = (tid, turnId) => {
      let s = streamsRef.current[tid];
      if (!s) {
        s = { id: turnId ? `a-${turnId}` : `a${Date.now()}`, text: "", thinking: "" };
        streamsRef.current[tid] = s;
      }
      return s;
    };
    const materialize = (s) => {
      setMessages((prev) => prev.some((m) => m.id === s.id) ? prev.map((m) => m.id === s.id ? { ...m, text: s.text, thinking: s.thinking } : m) : [...prev, { id: s.id, role: "assistant", text: s.text, thinking: s.thinking }]);
    };
    const endStream = (tid) => {
      delete streamsRef.current[tid];
      setRunningThread((cur) => cur === tid ? null : cur);
    };
    const sock = openSessionSocket({
      url: sessionWsUrl(api, pointer.ws_path, pointer.token),
      sessionId: pointer.session_id,
      onStatus: (st) => {
        setStatus(st === "open" ? "open" : st === "connecting" ? "connecting" : "closed");
        if (st !== "open") setRunningThread(null);
      },
      onOpen: () => {
        const stale = new Set(Object.values(streamsRef.current).map((s) => s.id));
        setRunningThread(null);
        streamsRef.current = {};
        if (stale.size) {
          setMessages((prev) => prev.filter((m) => !stale.has(m.id)));
        }
        sockRef.current?.sendJson({ t: "thread_switch", thread_id: activeRef.current });
      },
      onMessage: (ev) => {
        let f;
        try {
          f = JSON.parse(ev.data);
        } catch {
          return;
        }
        const tid = f.thread_id || "";
        switch (f.t) {
          case "turn_start": {
            setRunningThread(tid);
            const s = ensureStream(tid, f.turn_id);
            if (tid === activeRef.current) {
              setBanner("");
              materialize(s);
            }
            break;
          }
          case "history": {
            setRunningThread(tid);
            const s = ensureStream(tid, f.turn_id);
            s.text = f.text || "";
            s.thinking = f.thinking || "";
            if (tid === activeRef.current) materialize(s);
            else if (s.text) markUnread(tid);
            break;
          }
          case "delta": {
            if (!f.text) break;
            setRunningThread(tid);
            const s = ensureStream(tid, f.turn_id);
            s.text += f.text;
            if (tid === activeRef.current) materialize(s);
            else markUnread(tid);
            break;
          }
          case "thinking_delta": {
            if (!f.text) break;
            setRunningThread(tid);
            const s = ensureStream(tid, f.turn_id);
            s.thinking += f.text;
            if (tid === activeRef.current) materialize(s);
            break;
          }
          case "threads": {
            if (Array.isArray(f.threads)) setThreads(f.threads);
            if (f.active) {
              setActive(f.active);
              activeRef.current = f.active;
              clearUnread(f.active);
            }
            break;
          }
          case "turn_end":
            endStream(tid);
            if (tid === activeRef.current) {
              loadThread(tid);
            } else {
              markUnread(tid);
            }
            break;
          case "busy": {
            const refused = f.content ? ` Your message: \u201C${String(f.content).slice(0, 200)}\u201D` : "";
            if (tid === activeRef.current) {
              setBanner((f.message || "The assistant is still replying in another thread.") + refused);
            }
            break;
          }
          case "error":
            endStream(tid);
            if (tid === activeRef.current) {
              setBanner(f.message || "error");
              loadThread(tid);
            } else {
              markUnread(tid);
            }
            break;
        }
      }
    });
    sockRef.current = sock;
    return () => {
      sockRef.current = null;
      sock.close();
    };
  }, [pointer.ws_path, pointer.token, pointer.session_id, loadThread, markUnread, clearUnread]);
  const send = (obj) => sockRef.current?.sendJson(obj) ?? false;
  const runningVisible = runningThread !== null && runningThread === active;
  const busyElsewhere = runningThread !== null && runningThread !== active;
  const onNew = async (message) => {
    const text = textOf(message);
    if (!text) return;
    const rt = runningThreadRef.current;
    if (rt !== null && rt !== activeRef.current) {
      setBanner("The assistant is still replying in another thread \u2014 wait for it to finish or stop it first.");
      return;
    }
    const sameThreadBusy = rt !== null && rt === activeRef.current;
    if (!send({
      t: sameThreadBusy ? "redirect" : "user_msg",
      content: text,
      thread_id: activeRef.current
    })) {
      setBanner("The generator is stopped \u2014 run the cell again to continue chatting.");
      return;
    }
    setBanner("");
    setMessages((prev) => [...prev, { id: `u${Date.now()}`, role: "user", text }]);
  };
  const indexOf = (id) => messagesRef.current.findIndex((m) => m.id === id);
  const persistOffline = React.useCallback((next) => {
    const file = threadFile(activeRef.current);
    let base = "";
    try {
      const fileUrl = api.getFileUrl ? api.getFileUrl(file) : "";
      const cut = fileUrl.lastIndexOf("/files/");
      if (cut > 0) base = fileUrl.slice(0, cut);
    } catch {
    }
    if (!base) {
      setBanner("This host can't persist edits to a stopped chat.");
      return;
    }
    const doc = serializeTranscript(next.filter((m) => m.role !== "system" || m.text));
    persistQueueRef.current = persistQueueRef.current.then(async () => {
      const r = await fetch(`${base}/drafts/${encodeURIComponent(file)}`, {
        method: "PUT",
        headers: { "Content-Type": "text/plain" },
        body: doc
      });
      if (!r.ok) throw new Error(`draft save HTTP ${r.status}`);
      await fetch(`${base}/checkpoint`, { method: "POST" });
    }).catch((e) => {
      setBanner(`Saving edit failed: ${e?.message || e}`);
    });
  }, [api, threadFile]);
  const applyCuration = React.useCallback((fn, liveFrame) => {
    if (runningThreadRef.current !== null && runningThreadRef.current === activeRef.current) return;
    const next = fn(messagesRef.current);
    setMessages(next);
    if (!sockRef.current?.sendJson(liveFrame)) {
      persistOffline(next);
    }
  }, [persistOffline]);
  const editMessage = (id, text) => {
    const i = indexOf(id);
    if (i < 0) return;
    applyCuration(
      (prev) => prev.map((m, k) => k === i ? { ...m, text } : m),
      { t: "edit", index: i, content: text }
    );
  };
  const deleteMessage = (id) => {
    const i = indexOf(id);
    if (i < 0) return;
    applyCuration(
      (prev) => prev.filter((_, k) => k !== i),
      { t: "delete", index: i }
    );
  };
  const insertMessage = (afterId, role, text) => {
    const i = afterId === null ? messagesRef.current.length : indexOf(afterId) + 1;
    if (i < 0) return;
    applyCuration(
      (prev) => [...prev.slice(0, i), { id: `n${Date.now()}`, role, text }, ...prev.slice(i)],
      { t: "insert", index: i, role, content: text }
    );
  };
  const moveMessage = (id, dir) => {
    const i = indexOf(id);
    const j = i + dir;
    if (i < 0 || j < 0 || j >= messagesRef.current.length) return;
    applyCuration(
      (prev) => {
        const out = [...prev];
        const [m] = out.splice(i, 1);
        out.splice(j, 0, m);
        return out;
      },
      { t: "move", index: i, to: j }
    );
  };
  const regenerate = (parentId) => {
    if (!parentId) return;
    if (runningThreadRef.current !== null) {
      setBanner("The assistant is still replying in another thread \u2014 wait for it to finish or stop it first.");
      return;
    }
    const i = indexOf(parentId);
    if (i < 0) return;
    if (!send({ t: "regenerate", index: i })) return;
    setMessages((prev) => prev.slice(0, i + 1));
  };
  const newThread = () => send({ t: "thread_new" });
  const switchThread = (tid) => {
    setActive(tid);
    activeRef.current = tid;
    clearUnread(tid);
    send({ t: "thread_switch", thread_id: tid });
  };
  const runtime = useExternalStoreRuntime({
    messages,
    // Running means THIS thread's turn — a background turn in another thread
    // doesn't flip the visible composer to its stop state.
    isRunning: runningVisible,
    convertMessage,
    onNew,
    // Interrupt only — `runningThread` stays set until the generator's
    // turn_end actually arrives. Clearing it optimistically opened a window
    // where curation ops passed the renderer's gate but were silently dropped
    // by serve_chat (its turn is still winding down), desyncing the view.
    // thread_id scopes the cancel to the visible thread's turn.
    onCancel: async () => {
      send({ t: "interrupt", thread_id: activeRef.current });
    },
    setMessages: (ms) => setMessages(ms),
    onReload: async (parentId) => {
      regenerate(parentId);
    },
    unstable_capabilities: { copy: true }
  });
  return {
    runtime,
    messages,
    status,
    banner,
    running: runningVisible,
    runningThread,
    busyElsewhere,
    unread,
    dismissBanner: () => setBanner(""),
    threads: threads.length ? threads : pointer.threads,
    active,
    newThread,
    switchThread,
    curation: { editMessage, deleteMessage, insertMessage, moveMessage }
  };
}
const IconBtn = ({ title, danger, style, ...rest }) => /* @__PURE__ */ React.createElement(
  "button",
  {
    type: "button",
    className: "aui-iconbtn",
    title,
    "aria-label": title,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 28,
      height: 28,
      borderRadius: 8,
      border: "none",
      padding: 0,
      background: "transparent",
      color: danger ? T.destructive : T.dim,
      cursor: "pointer",
      ...style
    },
    ...rest
  }
);
const smallBtn = {
  border: `1px solid ${T.line}`,
  background: "transparent",
  color: T.fg,
  borderRadius: 8,
  padding: "4px 12px",
  fontSize: 13,
  cursor: "pointer"
};
const md = {
  p: (p) => /* @__PURE__ */ React.createElement("p", { style: { margin: "0 0 8px" }, ...p }),
  a: (p) => /* @__PURE__ */ React.createElement("a", { style: { color: T.accent }, target: "_blank", rel: "noopener noreferrer", ...p }),
  ul: (p) => /* @__PURE__ */ React.createElement("ul", { style: { margin: "0 0 8px", paddingLeft: 20 }, ...p }),
  ol: (p) => /* @__PURE__ */ React.createElement("ol", { style: { margin: "0 0 8px", paddingLeft: 20 }, ...p }),
  li: (p) => /* @__PURE__ */ React.createElement("li", { style: { margin: "2px 0" }, ...p }),
  h1: (p) => /* @__PURE__ */ React.createElement("h1", { style: { fontSize: 20, margin: "10px 0 6px" }, ...p }),
  h2: (p) => /* @__PURE__ */ React.createElement("h2", { style: { fontSize: 17, margin: "10px 0 6px" }, ...p }),
  h3: (p) => /* @__PURE__ */ React.createElement("h3", { style: { fontSize: 15, margin: "8px 0 4px" }, ...p }),
  blockquote: (p) => /* @__PURE__ */ React.createElement("blockquote", { style: { margin: "0 0 8px", padding: "2px 10px", borderLeft: `3px solid ${T.line}`, color: T.dim }, ...p }),
  hr: () => /* @__PURE__ */ React.createElement("hr", { style: { border: "none", borderTop: `1px solid ${T.line}`, margin: "10px 0" } }),
  pre: (p) => /* @__PURE__ */ React.createElement("pre", { style: { background: T.panel, border: `1px solid ${T.line}`, padding: 10, borderRadius: 10, overflow: "auto", margin: "0 0 8px" }, ...p }),
  code: (p) => /* @__PURE__ */ React.createElement("code", { style: { background: T.panel, padding: "1px 4px", borderRadius: 4, fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace", fontSize: "0.92em" }, ...p }),
  table: (p) => /* @__PURE__ */ React.createElement("table", { style: { borderCollapse: "collapse", margin: "0 0 8px" }, ...p }),
  th: (p) => /* @__PURE__ */ React.createElement("th", { style: { border: `1px solid ${T.line}`, padding: "3px 8px", textAlign: "left" }, ...p }),
  td: (p) => /* @__PURE__ */ React.createElement("td", { style: { border: `1px solid ${T.line}`, padding: "3px 8px" }, ...p })
};
const MarkdownText = () => /* @__PURE__ */ React.createElement(MarkdownTextPrimitive, { smooth: true, components: md });
const UserText = () => {
  const part = useMessagePartText();
  return /* @__PURE__ */ React.createElement("span", { style: { whiteSpace: "pre-wrap" } }, part?.text ?? "");
};
const Reasoning = () => {
  const part = useMessagePartReasoning();
  const text = part?.text ?? "";
  if (!text) return null;
  return /* @__PURE__ */ React.createElement("details", { style: { margin: "0 0 8px", color: T.dim, fontSize: 13 } }, /* @__PURE__ */ React.createElement("summary", { style: { cursor: "pointer" } }, "Reasoning"), /* @__PURE__ */ React.createElement("div", { style: { whiteSpace: "pre-wrap", paddingTop: 4, fontStyle: "italic" } }, text));
};
const SourcePart = () => {
  const part = useMessagePartSource();
  const url = part?.url;
  if (!url) return null;
  return /* @__PURE__ */ React.createElement(
    "a",
    {
      href: url,
      target: "_blank",
      rel: "noopener noreferrer",
      style: {
        display: "inline-block",
        margin: "2px 6px 2px 0",
        padding: "1px 8px",
        border: `1px solid ${T.line}`,
        borderRadius: 999,
        color: T.accent,
        fontSize: 12,
        textDecoration: "none"
      }
    },
    "\u{1F517} ",
    part?.title || url
  );
};
const ToolFallback = (p) => {
  const name = p?.toolName || p?.part?.toolName || "tool";
  const args = p?.argsText ?? (p?.args ? JSON.stringify(p.args, null, 2) : "");
  const result = typeof p?.result === "string" ? p.result : p?.result !== void 0 ? JSON.stringify(p.result, null, 2) : "";
  return /* @__PURE__ */ React.createElement("details", { style: { margin: "0 0 8px", border: `1px solid ${T.line}`, borderRadius: 10, padding: "6px 10px", fontSize: 13 } }, /* @__PURE__ */ React.createElement("summary", { style: { cursor: "pointer", color: T.dim } }, "\u{1F527} ", name), args ? /* @__PURE__ */ React.createElement("pre", { style: { margin: "6px 0 0", overflow: "auto", fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace", fontSize: 12, color: T.dim } }, args) : null, result ? /* @__PURE__ */ React.createElement("pre", { style: { margin: "6px 0 0", overflow: "auto", fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace", fontSize: 12 } }, result) : null);
};
const assistantParts = {
  Text: MarkdownText,
  Reasoning,
  Source: SourcePart,
  tools: { Fallback: ToolFallback }
};
const CurationCtx = React.createContext(null);
function InlineEditor(props) {
  const [text, setText] = useState(props.initial);
  const taRef = useRef(null);
  useEffect(() => {
    taRef.current?.focus();
  }, []);
  return /* @__PURE__ */ React.createElement("div", { style: {
    display: "flex",
    flexDirection: "column",
    gap: 8,
    background: T.muted,
    borderRadius: 16,
    padding: 12,
    width: "100%"
  } }, props.role && props.onRole && /* @__PURE__ */ React.createElement("div", { style: { display: "flex", gap: 6 } }, ["user", "assistant"].map((r) => /* @__PURE__ */ React.createElement(
    "button",
    {
      key: r,
      type: "button",
      onClick: () => props.onRole(r),
      style: {
        ...smallBtn,
        padding: "2px 10px",
        fontSize: 12,
        borderColor: props.role === r ? T.accent : T.line,
        color: props.role === r ? T.fg : T.dim
      }
    },
    r === "user" ? "User" : "Assistant"
  ))), /* @__PURE__ */ React.createElement(
    "textarea",
    {
      ref: taRef,
      className: "aui-input",
      value: text,
      onChange: (e) => setText(e.target.value),
      onKeyDown: (e) => {
        if (e.key === "Escape") props.onCancel();
        if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) props.onSave(text);
      },
      style: {
        minHeight: 72,
        width: "100%",
        resize: "vertical",
        background: "transparent",
        border: "none",
        outline: "none",
        color: T.fg,
        font: "inherit",
        lineHeight: 1.5
      }
    }
  ), /* @__PURE__ */ React.createElement("div", { style: { display: "flex", gap: 8, justifyContent: "flex-end" } }, /* @__PURE__ */ React.createElement("button", { type: "button", style: { ...smallBtn, border: "none", color: T.dim }, onClick: props.onCancel }, "Cancel"), /* @__PURE__ */ React.createElement(
    "button",
    {
      type: "button",
      style: { ...smallBtn, background: T.fg, color: T.bg, border: "none" },
      onClick: () => props.onSave(text)
    },
    props.saveLabel
  )));
}
function InsertComposer(props) {
  const cur = React.useContext(CurationCtx);
  const [role, setRole] = useState(props.defaultRole);
  if (!cur) return null;
  return /* @__PURE__ */ React.createElement("div", { style: { margin: "8px 0" } }, /* @__PURE__ */ React.createElement(
    InlineEditor,
    {
      initial: "",
      saveLabel: "Insert",
      role,
      onRole: setRole,
      onCancel: props.onDone,
      onSave: (text) => {
        const t = text.trim();
        if (t) cur.insertMessage(props.afterId, role, t);
        props.onDone();
      }
    }
  ));
}
function CurationButtons(props) {
  const cur = React.useContext(CurationCtx);
  if (!cur || !cur.canCurate) return null;
  const i = cur.messages.findIndex((m) => m.id === props.id);
  const last = i === cur.messages.length - 1;
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(IconBtn, { title: "Edit message", onClick: props.onEdit }, /* @__PURE__ */ React.createElement(Pencil, { size: 14 })), /* @__PURE__ */ React.createElement(IconBtn, { title: "Insert message below", onClick: props.onInsert }, /* @__PURE__ */ React.createElement(Plus, { size: 14 })), /* @__PURE__ */ React.createElement(
    IconBtn,
    {
      title: "Move up",
      disabled: i <= 0,
      style: i <= 0 ? { opacity: 0.3, cursor: "default" } : void 0,
      onClick: () => cur.moveMessage(props.id, -1)
    },
    /* @__PURE__ */ React.createElement(ChevronUp, { size: 14 })
  ), /* @__PURE__ */ React.createElement(
    IconBtn,
    {
      title: "Move down",
      disabled: last,
      style: last ? { opacity: 0.3, cursor: "default" } : void 0,
      onClick: () => cur.moveMessage(props.id, 1)
    },
    /* @__PURE__ */ React.createElement(ChevronDown, { size: 14 })
  ), /* @__PURE__ */ React.createElement(IconBtn, { title: "Delete message", danger: true, onClick: () => cur.deleteMessage(props.id) }, /* @__PURE__ */ React.createElement(Trash2, { size: 14 })));
}
function BranchPicker(props) {
  return /* @__PURE__ */ React.createElement(
    BranchPickerPrimitive.Root,
    {
      hideWhenSingleBranch: true,
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 2,
        fontSize: 12,
        color: T.dim,
        ...props.style
      }
    },
    /* @__PURE__ */ React.createElement(BranchPickerPrimitive.Previous, { asChild: true }, /* @__PURE__ */ React.createElement(IconBtn, { title: "Previous" }, /* @__PURE__ */ React.createElement(ChevronLeft, { size: 14 }))),
    /* @__PURE__ */ React.createElement("span", { style: { fontWeight: 500 } }, /* @__PURE__ */ React.createElement(BranchPickerPrimitive.Number, null), " / ", /* @__PURE__ */ React.createElement(BranchPickerPrimitive.Count, null)),
    /* @__PURE__ */ React.createElement(BranchPickerPrimitive.Next, { asChild: true }, /* @__PURE__ */ React.createElement(IconBtn, { title: "Next" }, /* @__PURE__ */ React.createElement(ChevronRight, { size: 14 })))
  );
}
function ThreadWelcome(props) {
  return /* @__PURE__ */ React.createElement("div", { style: {
    margin: "auto",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    width: "100%",
    maxWidth: THREAD_MAX_WIDTH,
    flexGrow: 1,
    padding: "0 24px"
  } }, /* @__PURE__ */ React.createElement("div", { style: { fontSize: 24, fontWeight: 600, color: T.fg } }, props.label), /* @__PURE__ */ React.createElement("div", { style: { fontSize: 24, color: T.dim } }, "How can I help you today?"));
}
function UserMessage() {
  const id = useMessage((m) => m.id);
  const cur = React.useContext(CurationCtx);
  const [editing, setEditing] = useState(false);
  const [inserting, setInserting] = useState(false);
  return /* @__PURE__ */ React.createElement(
    MessagePrimitive.Root,
    {
      "data-role": "user",
      style: { margin: "0 auto", width: "100%", maxWidth: THREAD_MAX_WIDTH, padding: "10px 8px 0" }
    },
    editing && cur ? /* @__PURE__ */ React.createElement("div", { style: { display: "flex", justifyContent: "flex-end" } }, /* @__PURE__ */ React.createElement("div", { style: { width: "min(100%, 85%)" } }, /* @__PURE__ */ React.createElement(
      InlineEditor,
      {
        initial: cur.messages.find((m) => m.id === id)?.text ?? "",
        saveLabel: "Update",
        onCancel: () => setEditing(false),
        onSave: (text) => {
          cur.editMessage(id, text);
          setEditing(false);
        }
      }
    ))) : /* @__PURE__ */ React.createElement("div", { style: { display: "flex", justifyContent: "flex-end", minWidth: 0 } }, /* @__PURE__ */ React.createElement("div", { style: {
      background: T.muted,
      color: T.fg,
      borderRadius: 16,
      padding: "10px 16px",
      maxWidth: "85%",
      overflowWrap: "break-word",
      lineHeight: 1.55,
      minWidth: 0
    } }, /* @__PURE__ */ React.createElement(MessagePrimitive.Parts, { components: { Text: UserText } }))),
    inserting && /* @__PURE__ */ React.createElement(InsertComposer, { afterId: id, defaultRole: "assistant", onDone: () => setInserting(false) }),
    !editing && /* @__PURE__ */ React.createElement("div", { style: {
      display: "flex",
      justifyContent: "flex-end",
      alignItems: "center",
      gap: 4,
      minHeight: 28
    } }, !cur && /* @__PURE__ */ React.createElement(BranchPicker, null), /* @__PURE__ */ React.createElement(
      ActionBarPrimitive.Root,
      {
        hideWhenRunning: true,
        autohide: "always",
        style: { display: "flex", alignItems: "center", gap: 2 }
      },
      /* @__PURE__ */ React.createElement(ActionBarPrimitive.Copy, { asChild: true }, /* @__PURE__ */ React.createElement(IconBtn, { title: "Copy" }, /* @__PURE__ */ React.createElement(Copy, { size: 14 }))),
      /* @__PURE__ */ React.createElement(CurationButtons, { id, onEdit: () => setEditing(true), onInsert: () => setInserting(true) })
    ))
  );
}
function SystemMessage() {
  const id = useMessage((m) => m.id);
  const cur = React.useContext(CurationCtx);
  const [editing, setEditing] = useState(false);
  const [inserting, setInserting] = useState(false);
  return /* @__PURE__ */ React.createElement(
    MessagePrimitive.Root,
    {
      "data-role": "system",
      style: { margin: "0 auto", width: "100%", maxWidth: THREAD_MAX_WIDTH, padding: "10px 8px" }
    },
    editing && cur ? /* @__PURE__ */ React.createElement(
      InlineEditor,
      {
        initial: cur.messages.find((m) => m.id === id)?.text ?? "",
        saveLabel: "Update",
        onCancel: () => setEditing(false),
        onSave: (text) => {
          cur.editMessage(id, text);
          setEditing(false);
        }
      }
    ) : /* @__PURE__ */ React.createElement("div", { style: { display: "flex", alignItems: "flex-start", gap: 6 } }, /* @__PURE__ */ React.createElement("div", { style: {
      flex: 1,
      minWidth: 0,
      border: `1px dashed ${T.line}`,
      borderRadius: 12,
      padding: "8px 12px",
      color: T.dim,
      fontSize: 13,
      whiteSpace: "pre-wrap"
    } }, /* @__PURE__ */ React.createElement("div", { style: { fontSize: 11, textTransform: "uppercase", letterSpacing: 1, marginBottom: 2 } }, "system"), /* @__PURE__ */ React.createElement(MessagePrimitive.Parts, { components: { Text: UserText } })), /* @__PURE__ */ React.createElement("span", { style: { display: "flex", alignItems: "center" } }, /* @__PURE__ */ React.createElement(CurationButtons, { id, onEdit: () => setEditing(true), onInsert: () => setInserting(true) }))),
    inserting && /* @__PURE__ */ React.createElement(InsertComposer, { afterId: id, defaultRole: "user", onDone: () => setInserting(false) })
  );
}
function MessageError() {
  return /* @__PURE__ */ React.createElement(MessagePrimitive.Error, null, /* @__PURE__ */ React.createElement(ErrorPrimitive.Root, { style: {
    marginTop: 8,
    borderRadius: 10,
    padding: 12,
    border: `1px solid ${T.destructive}`,
    color: T.destructive,
    fontSize: 13,
    background: "color-mix(in srgb, currentColor 8%, transparent)"
  } }, /* @__PURE__ */ React.createElement(ErrorPrimitive.Message, null)));
}
function AssistantMessage() {
  const id = useMessage((m) => m.id);
  const cur = React.useContext(CurationCtx);
  const [editing, setEditing] = useState(false);
  const [inserting, setInserting] = useState(false);
  return /* @__PURE__ */ React.createElement(
    MessagePrimitive.Root,
    {
      "data-role": "assistant",
      style: {
        position: "relative",
        margin: "0 auto",
        width: "100%",
        maxWidth: THREAD_MAX_WIDTH,
        padding: "10px 8px"
      }
    },
    editing && cur ? /* @__PURE__ */ React.createElement(
      InlineEditor,
      {
        initial: cur.messages.find((m) => m.id === id)?.text ?? "",
        saveLabel: "Update",
        onCancel: () => setEditing(false),
        onSave: (text) => {
          cur.editMessage(id, text);
          setEditing(false);
        }
      }
    ) : /* @__PURE__ */ React.createElement("div", { style: { color: T.fg, lineHeight: 1.6, overflowWrap: "break-word", minWidth: 0 } }, /* @__PURE__ */ React.createElement(MessagePrimitive.Parts, { components: assistantParts }), /* @__PURE__ */ React.createElement(MessageError, null), /* @__PURE__ */ React.createElement(AuiIf, { condition: (s) => s.thread.isRunning && s.message.content.length === 0 }, /* @__PURE__ */ React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 8, color: T.dim } }, /* @__PURE__ */ React.createElement(Loader, { size: 15, className: "aui-spin" }), /* @__PURE__ */ React.createElement("span", { style: { fontSize: 13 } }, "Thinking\u2026")))),
    inserting && /* @__PURE__ */ React.createElement(InsertComposer, { afterId: id, defaultRole: "user", onDone: () => setInserting(false) }),
    !editing && /* @__PURE__ */ React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 4, minHeight: 28, marginTop: 2 } }, !cur && /* @__PURE__ */ React.createElement(BranchPicker, null), /* @__PURE__ */ React.createElement(
      ActionBarPrimitive.Root,
      {
        hideWhenRunning: true,
        autohide: "always",
        style: { display: "flex", alignItems: "center", gap: 2 }
      },
      /* @__PURE__ */ React.createElement(ActionBarPrimitive.Copy, { asChild: true }, /* @__PURE__ */ React.createElement(IconBtn, { title: "Copy" }, /* @__PURE__ */ React.createElement(AuiIf, { condition: (s) => s.message.isCopied }, /* @__PURE__ */ React.createElement(Check, { size: 14 })), /* @__PURE__ */ React.createElement(AuiIf, { condition: (s) => !s.message.isCopied }, /* @__PURE__ */ React.createElement(Copy, { size: 14 })))),
      (!cur || cur.canGenerate) && /* @__PURE__ */ React.createElement(ActionBarPrimitive.Reload, { asChild: true }, /* @__PURE__ */ React.createElement(IconBtn, { title: "Regenerate" }, /* @__PURE__ */ React.createElement(RefreshCw, { size: 14 }))),
      /* @__PURE__ */ React.createElement(CurationButtons, { id, onEdit: () => setEditing(true), onInsert: () => setInserting(true) })
    ))
  );
}
function ScrollToBottom() {
  return /* @__PURE__ */ React.createElement(ThreadPrimitive.ScrollToBottom, { asChild: true }, /* @__PURE__ */ React.createElement(
    "button",
    {
      type: "button",
      className: "aui-stb",
      title: "Scroll to bottom",
      style: {
        position: "absolute",
        top: -44,
        left: "50%",
        transform: "translateX(-50%)",
        width: 34,
        height: 34,
        borderRadius: 999,
        border: `1px solid ${T.line}`,
        background: T.bg,
        color: T.fg,
        cursor: "pointer",
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        boxShadow: "0 1px 6px #0006",
        zIndex: 10
      }
    },
    /* @__PURE__ */ React.createElement(ArrowDown, { size: 16 })
  ));
}
function Composer(props) {
  return /* @__PURE__ */ React.createElement(
    ComposerPrimitive.Root,
    {
      className: "aui-composer",
      style: {
        display: "flex",
        flexDirection: "column",
        width: "100%",
        border: `1px solid ${T.line}`,
        borderRadius: 16,
        background: T.bg
      }
    },
    /* @__PURE__ */ React.createElement(
      ComposerPrimitive.Input,
      {
        className: "aui-input",
        placeholder: props.disabled ? props.disabledHint : "Send a message\u2026",
        rows: 1,
        autoFocus: true,
        disabled: props.disabled,
        "aria-label": "Message input",
        style: {
          width: "100%",
          minHeight: 52,
          maxHeight: 128,
          resize: "none",
          background: "transparent",
          border: "none",
          outline: "none",
          color: T.fg,
          font: "inherit",
          lineHeight: 1.5,
          padding: "12px 14px 4px"
        }
      }
    ),
    /* @__PURE__ */ React.createElement("div", { style: { display: "flex", alignItems: "center", justifyContent: "flex-end", padding: "0 8px 8px" } }, /* @__PURE__ */ React.createElement(AuiIf, { condition: (s) => !s.thread.isRunning }, /* @__PURE__ */ React.createElement(ComposerPrimitive.Send, { asChild: true }, /* @__PURE__ */ React.createElement(
      "button",
      {
        type: "button",
        title: "Send message",
        "aria-label": "Send message",
        disabled: props.disabled,
        style: {
          width: 32,
          height: 32,
          borderRadius: 999,
          border: "none",
          background: props.disabled ? T.muted : T.accent,
          color: props.disabled ? T.dim : T.accentFg,
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: props.disabled ? "default" : "pointer"
        }
      },
      /* @__PURE__ */ React.createElement(ArrowUp, { size: 16 })
    ))), /* @__PURE__ */ React.createElement(AuiIf, { condition: (s) => s.thread.isRunning }, /* @__PURE__ */ React.createElement(ComposerPrimitive.Cancel, { asChild: true }, /* @__PURE__ */ React.createElement(
      "button",
      {
        type: "button",
        title: "Stop generating",
        "aria-label": "Stop generating",
        style: {
          width: 32,
          height: 32,
          borderRadius: 999,
          border: "none",
          background: T.accent,
          color: T.accentFg,
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: "pointer"
        }
      },
      /* @__PURE__ */ React.createElement(Square, { size: 12, fill: "currentColor" })
    ))))
  );
}
function Sidebar(props) {
  const dot = props.status === "open" || props.status === "opencode" ? "#3fb950" : props.status === "connecting" ? "#d29922" : "#f85149";
  const statusTitle = props.status === "open" ? "connected" : props.status === "opencode" ? "opencode" : props.status === "connecting" ? "connecting\u2026" : "stopped";
  const flagged = (tid) => tid !== props.active && (!!props.unread?.[tid] || props.runningThread === tid);
  const anyFlagged = props.threads.some((t) => flagged(t.id));
  if (!props.expanded) {
    return /* @__PURE__ */ React.createElement("div", { style: {
      width: 44,
      minWidth: 44,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 6,
      padding: "10px 0",
      borderRight: `1px solid ${T.line}`,
      background: T.panel
    } }, /* @__PURE__ */ React.createElement(IconBtn, { title: "Show threads", onClick: props.onToggle }, /* @__PURE__ */ React.createElement(PanelLeftOpen, { size: 16 })), props.onNew && /* @__PURE__ */ React.createElement(
      IconBtn,
      {
        title: "New thread",
        disabled: !props.canNew,
        style: !props.canNew ? { opacity: 0.35, cursor: "default" } : void 0,
        onClick: props.canNew ? props.onNew : void 0
      },
      /* @__PURE__ */ React.createElement(MessageSquarePlus, { size: 16 })
    ), anyFlagged && /* @__PURE__ */ React.createElement(
      "span",
      {
        title: "New messages in another thread",
        className: props.runningThread && props.runningThread !== props.active ? "aui-pulse" : void 0,
        style: { width: 8, height: 8, borderRadius: 999, background: T.accent }
      }
    ), /* @__PURE__ */ React.createElement("span", { title: statusTitle, style: {
      marginTop: "auto",
      width: 8,
      height: 8,
      borderRadius: 999,
      background: dot
    } }));
  }
  return /* @__PURE__ */ React.createElement("div", { style: {
    width: 232,
    minWidth: 232,
    display: "flex",
    flexDirection: "column",
    borderRight: `1px solid ${T.line}`,
    background: T.panel
  } }, /* @__PURE__ */ React.createElement("div", { style: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    padding: "10px 8px 10px 12px",
    borderBottom: `1px solid ${T.line}`
  } }, /* @__PURE__ */ React.createElement("span", { title: statusTitle, style: {
    width: 8,
    height: 8,
    borderRadius: 999,
    background: dot,
    flex: "0 0 auto"
  } }), /* @__PURE__ */ React.createElement("strong", { style: {
    color: T.fg,
    fontSize: 13,
    flex: 1,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap"
  } }, props.label), /* @__PURE__ */ React.createElement(IconBtn, { title: "Hide threads", onClick: props.onToggle }, /* @__PURE__ */ React.createElement(PanelLeftClose, { size: 15 }))), props.onNew && /* @__PURE__ */ React.createElement(
    "button",
    {
      type: "button",
      className: "aui-listbtn",
      disabled: !props.canNew,
      onClick: props.canNew ? props.onNew : void 0,
      title: props.canNew ? "Start a new thread" : "The generator is stopped",
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8,
        margin: 8,
        padding: "7px 10px",
        background: "transparent",
        color: props.canNew ? T.fg : T.dim,
        border: `1px solid ${T.line}`,
        borderRadius: 10,
        cursor: props.canNew ? "pointer" : "default",
        fontSize: 13
      }
    },
    /* @__PURE__ */ React.createElement(Plus, { size: 14 }),
    " New thread"
  ), /* @__PURE__ */ React.createElement("div", { style: { flex: 1, overflowY: "auto", padding: "0 6px 8px" } }, props.threads.map((t) => {
    const streaming = props.runningThread === t.id && t.id !== props.active;
    return /* @__PURE__ */ React.createElement(
      "button",
      {
        key: t.id,
        type: "button",
        className: "aui-listbtn",
        onClick: () => props.onSwitch?.(t.id),
        style: {
          display: "flex",
          alignItems: "center",
          gap: 8,
          width: "100%",
          textAlign: "left",
          marginBottom: 2,
          padding: "7px 10px",
          borderRadius: 8,
          cursor: "pointer",
          fontSize: 13,
          color: T.fg,
          border: "none",
          background: t.id === props.active ? T.active : "transparent",
          fontWeight: t.id === props.active ? 600 : 400
        },
        title: t.title || t.id
      },
      /* @__PURE__ */ React.createElement("span", { style: {
        flex: 1,
        minWidth: 0,
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap"
      } }, t.title || t.id),
      flagged(t.id) && /* @__PURE__ */ React.createElement(
        "span",
        {
          className: streaming ? "aui-pulse" : void 0,
          title: streaming ? "Assistant is replying\u2026" : "New messages",
          style: {
            width: 8,
            height: 8,
            borderRadius: 999,
            background: T.accent,
            flex: "0 0 auto"
          }
        }
      )
    );
  })));
}
const SIDEBAR_KEY = "collimate.assistant.sidebar";
function ChatUI(props) {
  const [expanded, setExpanded] = useState(() => {
    try {
      const saved = localStorage.getItem(SIDEBAR_KEY);
      if (saved === "open") return true;
      if (saved === "closed") return false;
    } catch {
    }
    return props.threads.length > 1;
  });
  const toggle = () => setExpanded((v) => {
    try {
      localStorage.setItem(SIDEBAR_KEY, v ? "closed" : "open");
    } catch {
    }
    return !v;
  });
  const [appending, setAppending] = useState(false);
  const canNew = props.status === "open" || props.status === "opencode";
  return /* @__PURE__ */ React.createElement("div", { style: {
    display: "flex",
    flexDirection: "row",
    height: "100%",
    minHeight: 0,
    ...paletteVars(props.scheme),
    background: T.bg,
    color: T.fg,
    font: "14px system-ui, sans-serif"
  } }, /* @__PURE__ */ React.createElement(
    Sidebar,
    {
      label: props.label,
      threads: props.threads,
      active: props.active,
      status: props.status,
      expanded,
      onToggle: toggle,
      onNew: props.onNew,
      onSwitch: props.onSwitch,
      canNew,
      unread: props.unread,
      runningThread: props.runningThread
    }
  ), /* @__PURE__ */ React.createElement(ThreadPrimitive.Root, { style: {
    flex: 1,
    minWidth: 0,
    display: "flex",
    flexDirection: "column",
    minHeight: 0
  } }, /* @__PURE__ */ React.createElement(
    ThreadPrimitive.Viewport,
    {
      style: {
        position: "relative",
        flex: 1,
        display: "flex",
        flexDirection: "column",
        overflowY: "auto",
        overflowX: "hidden",
        scrollBehavior: "smooth",
        padding: "16px 16px 0"
      }
    },
    /* @__PURE__ */ React.createElement(AuiIf, { condition: (s) => s.thread.isEmpty }, /* @__PURE__ */ React.createElement(ThreadWelcome, { label: props.label })),
    /* @__PURE__ */ React.createElement(
      ThreadPrimitive.Messages,
      {
        components: { UserMessage, AssistantMessage, SystemMessage }
      }
    ),
    /* @__PURE__ */ React.createElement(
      ThreadPrimitive.ViewportFooter,
      {
        style: {
          position: "sticky",
          bottom: 0,
          marginTop: "auto",
          marginLeft: "auto",
          marginRight: "auto",
          width: "100%",
          maxWidth: THREAD_MAX_WIDTH,
          display: "flex",
          flexDirection: "column",
          gap: 8,
          background: T.bg,
          paddingBottom: 12,
          borderRadius: "20px 20px 0 0"
        }
      },
      /* @__PURE__ */ React.createElement(ScrollToBottom, null),
      props.banner ? /* @__PURE__ */ React.createElement("div", { style: {
        display: "flex",
        alignItems: "center",
        gap: 8,
        border: `1px solid ${T.destructive}`,
        borderRadius: 10,
        padding: "8px 12px",
        color: T.destructive,
        fontSize: 13
      } }, /* @__PURE__ */ React.createElement("span", { style: { flex: 1, minWidth: 0, overflowWrap: "break-word" } }, "\u26A0 ", props.banner), props.onDismissBanner && /* @__PURE__ */ React.createElement(
        "button",
        {
          type: "button",
          onClick: props.onDismissBanner,
          style: {
            border: "none",
            background: "transparent",
            color: T.destructive,
            cursor: "pointer",
            fontSize: 13
          }
        },
        "dismiss"
      )) : null,
      props.canCurate && (appending ? /* @__PURE__ */ React.createElement(InsertComposer, { afterId: null, defaultRole: "user", onDone: () => setAppending(false) }) : /* @__PURE__ */ React.createElement(
        "button",
        {
          type: "button",
          className: "aui-listbtn",
          onClick: () => setAppending(true),
          style: {
            alignSelf: "center",
            display: "inline-flex",
            alignItems: "center",
            gap: 6,
            border: "none",
            background: "transparent",
            color: T.dim,
            fontSize: 12,
            cursor: "pointer",
            padding: "2px 10px",
            borderRadius: 8
          }
        },
        /* @__PURE__ */ React.createElement(Plus, { size: 12 }),
        " Add message"
      )),
      /* @__PURE__ */ React.createElement(Composer, { disabled: props.composerDisabled, disabledHint: props.composerHint })
    )
  )));
}
function NativeApp({ api, pointer }) {
  const chat = useNativeChat(api, pointer);
  const scheme = useScheme(api);
  useEffect(() => {
    try {
      api.ready?.();
    } catch {
    }
  }, [api]);
  const curation = useMemo(() => ({
    canCurate: !chat.running && chat.status !== "connecting",
    canGenerate: chat.status === "open",
    messages: chat.messages,
    editMessage: chat.curation.editMessage,
    deleteMessage: chat.curation.deleteMessage,
    insertMessage: chat.curation.insertMessage,
    moveMessage: chat.curation.moveMessage
  }), [chat.running, chat.status, chat.messages]);
  return /* @__PURE__ */ React.createElement(AssistantRuntimeProvider, { runtime: chat.runtime }, /* @__PURE__ */ React.createElement(CurationCtx.Provider, { value: curation }, /* @__PURE__ */ React.createElement(
    ChatUI,
    {
      label: pointer.label,
      threads: chat.threads,
      active: chat.active,
      status: chat.status,
      scheme,
      banner: chat.banner,
      onDismissBanner: chat.dismissBanner,
      onNew: chat.newThread,
      onSwitch: chat.switchThread,
      composerDisabled: chat.status === "closed" || chat.busyElsewhere,
      composerHint: chat.busyElsewhere ? "The assistant is replying in another thread \u2014 wait or stop it first" : "Generator stopped \u2014 the saved conversation is still editable",
      canCurate: curation.canCurate,
      unread: chat.unread,
      runningThread: chat.runningThread
    }
  )));
}
function _opencodeBase(api, proxyUrl) {
  return (apiOrigin(api) + proxyUrl).replace(/\/$/, "");
}
function OpencodeApp({ api, pointer }) {
  const client = useMemo(
    () => createOpencodeClient({ baseUrl: _opencodeBase(api, pointer.integration.proxy_url) }),
    [api, pointer]
  );
  const runtime = useOpenCodeRuntime({ client });
  const scheme = useScheme(api);
  useEffect(() => {
    try {
      api.ready?.();
    } catch {
    }
  }, [api]);
  return /* @__PURE__ */ React.createElement(AssistantRuntimeProvider, { runtime }, /* @__PURE__ */ React.createElement(CurationCtx.Provider, { value: null }, /* @__PURE__ */ React.createElement(
    ChatUI,
    {
      label: `${pointer.label} \xB7 opencode`,
      threads: [],
      active: "",
      status: "opencode",
      scheme,
      composerDisabled: false,
      composerHint: "",
      canCurate: false
    }
  )));
}
function App({ api, initialPointer }) {
  const [pointer, setPointer] = useState(initialPointer);
  const pointerRef = useRef(pointer);
  pointerRef.current = pointer;
  useEffect(() => {
    const apply = (raw) => {
      const next = parsePointer(raw || "");
      if (!next) return;
      const p = pointerRef.current;
      if (next.session_id !== p.session_id || next.token !== p.token || next.ws_path !== p.ws_path || (next.integration?.proxy_url || "") !== (p.integration?.proxy_url || "")) {
        setPointer(next);
      }
    };
    const offContent = api.onSetContent?.((c) => apply(c));
    const offFiles = api.onFilesChanged?.(() => {
      Promise.resolve(api.getContent()).then((c) => apply(c)).catch(() => {
      });
    });
    return () => {
      try {
        offContent && offContent();
      } catch {
      }
      try {
        offFiles && offFiles();
      } catch {
      }
    };
  }, [api]);
  const key = `${pointer.session_id}:${pointer.token}:${pointer.integration?.proxy_url || ""}`;
  return pointer.integration?.type === "opencode" ? /* @__PURE__ */ React.createElement(OpencodeApp, { key, api, pointer }) : /* @__PURE__ */ React.createElement(NativeApp, { key, api, pointer });
}
async function mount(el, api) {
  let raw = "";
  try {
    raw = await api.getContent() || "";
  } catch {
  }
  const pointer = parsePointer(raw);
  if (!pointer) {
    el.innerHTML = `<div style="color:${"#e6e6e6"};background:${"#0f1115"};padding:12px;font:14px system-ui;">Not a valid .chat session.</div>`;
    try {
      api.ready?.();
    } catch {
    }
    return;
  }
  try {
    if (api.injectStyle) api.injectStyle(SHADOW_CSS);
    else {
      const s = document.createElement("style");
      s.textContent = SHADOW_CSS;
      el.getRootNode()?.appendChild?.(s);
    }
  } catch {
  }
  const root = createRoot(el);
  root.render(/* @__PURE__ */ React.createElement(App, { api, initialPointer: pointer }));
  return () => {
    try {
      root.unmount();
    } catch {
    }
  };
}
var main_default = { __collimate_renderer__: true, component: App, mount };
export {
  main_default as default
};
