import React, { useEffect, useMemo, useRef, useState } from "https://esm.sh/react@18";
import { Terminal } from "https://esm.sh/xterm@5.3.0";
import { FitAddon } from "https://esm.sh/xterm-addon-fit@0.8.0";
import { WebLinksAddon } from "https://esm.sh/xterm-addon-web-links@0.9.0";
import {
  defineRenderer,
  useCollimateFile,
  useTheme,
  useVisibility
} from "/api/sdk/react.js";
import {
  clearDeadSession,
  isSessionDead,
  openSessionSocket,
  sessionWsUrl
} from "/api/sdk/session.js";
function parseContent(raw) {
  try {
    const j = JSON.parse(raw || "");
    if (typeof j.session_id !== "string" || !j.session_id) return null;
    if (typeof j.ws_path !== "string" || !j.ws_path) return null;
    const buttons = Array.isArray(j.buttons) ? j.buttons.filter((b) => b && typeof b.id === "string" && typeof b.label === "string").map((b) => ({ id: b.id, label: b.label })) : [];
    return {
      session_id: j.session_id,
      ws_path: j.ws_path,
      token: typeof j.token === "string" ? j.token : "",
      label: typeof j.label === "string" ? j.label : "terminal",
      buttons
    };
  } catch {
    return null;
  }
}
function buildXtermTheme() {
  if (typeof document === "undefined") {
    return { background: "#000000", foreground: "#e2e8f0", cursor: "#7fcfa8" };
  }
  const cs = getComputedStyle(document.documentElement);
  const read = (name, fallback) => cs.getPropertyValue(name).trim() || fallback;
  return {
    background: "#000000",
    foreground: read("--signal-white", "#e2e8f0"),
    cursor: read("--electric-teal", "#7fcfa8"),
    selectionBackground: read("--muted", "#2a2d3a")
  };
}
const FONT_SIZE_KEY = "collimate.terminal.fontSize";
const FONT_SIZE_MIN = 8;
const FONT_SIZE_MAX = 32;
const FONT_SIZE_DEFAULT = 13;
function readFontSize() {
  try {
    const v = parseInt(window.localStorage.getItem(FONT_SIZE_KEY) || "", 10);
    if (Number.isFinite(v) && v >= FONT_SIZE_MIN && v <= FONT_SIZE_MAX) return v;
  } catch {
  }
  return FONT_SIZE_DEFAULT;
}
function writeFontSize(n) {
  try {
    window.localStorage.setItem(FONT_SIZE_KEY, String(n));
  } catch {
  }
}
const FONT_SIZE_LISTENERS = /* @__PURE__ */ new Set();
function broadcastFontSize(n) {
  for (const cb of Array.from(FONT_SIZE_LISTENERS)) {
    try {
      cb(n);
    } catch {
    }
  }
}
const FONT_BTN_STYLE = {
  height: 18,
  minWidth: 20,
  padding: "0 5px",
  background: "var(--muted, #2d2f3e)",
  border: "1px solid var(--tungsten-dim, #3a3d52)",
  borderRadius: "var(--radius-sm, 3px)",
  color: "var(--signal-white, #e2e8f0)",
  fontFamily: "var(--font-mono, monospace)",
  fontSize: 11,
  lineHeight: 1
};
const SESSION_CACHE = /* @__PURE__ */ new Map();
function getGraveyard() {
  const ID = "__collimate_terminal_graveyard__";
  let el = document.getElementById(ID);
  if (el) return el;
  el = document.createElement("div");
  el.id = ID;
  el.style.position = "fixed";
  el.style.left = "-99999px";
  el.style.top = "0";
  el.style.width = "1px";
  el.style.height = "1px";
  el.style.overflow = "hidden";
  el.style.pointerEvents = "none";
  document.body.appendChild(el);
  return el;
}
function notifyStatus(session) {
  for (const cb of Array.from(session.statusListeners)) {
    try {
      cb(session.status);
    } catch {
    }
  }
}
function buildSession(parsed, api) {
  const container = document.createElement("div");
  container.style.width = "100%";
  container.style.height = "100%";
  container.style.background = "#000000";
  const term = new Terminal({
    cursorBlink: true,
    fontFamily: getComputedStyle(document.documentElement).getPropertyValue("--font-mono").trim() || "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
    fontSize: readFontSize(),
    theme: buildXtermTheme(),
    convertEol: false,
    scrollback: 5e3,
    allowProposedApi: true
  });
  const fit = new FitAddon();
  term.loadAddon(fit);
  term.loadAddon(new WebLinksAddon());
  getGraveyard().appendChild(container);
  term.open(container);
  const encoder = new TextEncoder();
  let firstPaint = false;
  const session = {
    sessionId: parsed.session_id,
    term,
    fit,
    sock: null,
    // assigned right below
    container,
    lastCols: 0,
    lastRows: 0,
    status: "connecting",
    statusListeners: /* @__PURE__ */ new Set(),
    disposeOnData: { dispose: () => {
    } },
    unsubTheme: null,
    unsubVisible: null,
    rendererTried: false
  };
  session.sock = openSessionSocket({
    url: sessionWsUrl(api, parsed.ws_path, parsed.token),
    sessionId: parsed.session_id,
    binaryType: "arraybuffer",
    transientRetryMs: false,
    busyRetryMs: false,
    onOpen: () => {
      fitAndSync(session);
      try {
        term.focus();
      } catch {
      }
    },
    onMessage: (ev) => {
      if (ev.data instanceof ArrayBuffer) {
        term.write(new Uint8Array(ev.data));
      } else if (typeof ev.data === "string") {
        term.write(ev.data);
      }
      if (!firstPaint) {
        firstPaint = true;
        refreshTerm(session);
        setTimeout(() => refreshTerm(session), 250);
      }
    },
    onStatus: (st) => {
      session.status = st;
      notifyStatus(session);
      if (st === "ended") {
        term.write("\r\n\x1B[33m[session ended \u2014 run the cell again to start a new terminal]\x1B[0m\r\n");
      } else if (st === "busy") {
        term.write("\r\n\x1B[33m[already attached in another view \u2014 close it or hit Reconnect]\x1B[0m\r\n");
      } else if (st === "closed") {
        term.write("\r\n\x1B[33m[connection closed]\x1B[0m\r\n");
      }
      if (st === "ended" || st === "busy" || st === "closed") {
        SESSION_CACHE.delete(session.sessionId);
      }
    }
  });
  session.disposeOnData = term.onData((d) => {
    session.sock.send(encoder.encode(d));
  });
  SESSION_CACHE.set(parsed.session_id, session);
  return session;
}
function disposeSession(sessionId) {
  const session = SESSION_CACHE.get(sessionId);
  if (!session) return;
  SESSION_CACHE.delete(sessionId);
  try {
    session.disposeOnData.dispose();
  } catch {
  }
  if (session.unsubTheme) {
    try {
      session.unsubTheme();
    } catch {
    }
  }
  if (session.unsubVisible) {
    try {
      session.unsubVisible();
    } catch {
    }
  }
  try {
    session.sock.close();
  } catch {
  }
  try {
    session.term.dispose();
  } catch {
  }
  try {
    session.container.remove();
  } catch {
  }
}
function fitAndSync(session) {
  const rect = session.container.getBoundingClientRect();
  if (rect.width < 2 || rect.height < 2) return;
  try {
    session.fit.fit();
  } catch {
    return;
  }
  const cols = session.term.cols;
  const rows = session.term.rows;
  if (cols !== session.lastCols || rows !== session.lastRows) {
    if (session.sock.sendJson({ t: "resize", cols, rows })) {
      session.lastCols = cols;
      session.lastRows = rows;
    }
  }
}
async function loadRendererAddon(session) {
  if (session.rendererTried) return;
  session.rendererTried = true;
  try {
    const mod = await import("https://esm.sh/xterm-addon-canvas@0.5.0");
    session.term.loadAddon(new mod.CanvasAddon());
    refreshTerm(session);
  } catch {
  }
}
function refreshTerm(session) {
  requestAnimationFrame(() => {
    try {
      const rows = session.term.rows;
      if (rows > 0) session.term.refresh(0, rows - 1);
    } catch {
    }
  });
}
function TerminalViewer() {
  const { content, api } = useCollimateFile();
  const { onChange: onThemeChange } = useTheme(api);
  const { onChange: onVisibleChange } = useVisibility(api);
  const parsed = useMemo(() => parseContent(content), [content]);
  const hostRef = useRef(null);
  const [status, setStatus] = useState("idle");
  const [attempt, setAttempt] = useState(0);
  const [pendingAction, setPendingAction] = useState(null);
  const [actionStatus, setActionStatus] = useState("");
  const [fontSize, setFontSize] = useState(readFontSize());
  const changeFontSize = (delta) => {
    const next = Math.max(FONT_SIZE_MIN, Math.min(FONT_SIZE_MAX, readFontSize() + delta));
    if (next === readFontSize()) return;
    writeFontSize(next);
    broadcastFontSize(next);
  };
  useEffect(() => {
    const apply = (n) => {
      setFontSize(n);
      const session = parsed ? SESSION_CACHE.get(parsed.session_id) : void 0;
      if (session) {
        try {
          session.term.options.fontSize = n;
        } catch {
        }
        fitAndSync(session);
        refreshTerm(session);
      }
    };
    FONT_SIZE_LISTENERS.add(apply);
    const onStorage = (e) => {
      if (e.key === FONT_SIZE_KEY) apply(readFontSize());
    };
    window.addEventListener("storage", onStorage);
    return () => {
      FONT_SIZE_LISTENERS.delete(apply);
      window.removeEventListener("storage", onStorage);
    };
  }, [parsed?.session_id]);
  const clickAction = async (id, label) => {
    if (pendingAction) return;
    setPendingAction(id);
    setActionStatus("");
    const ok = typeof api.emitAction === "function" ? await api.emitAction(id) : false;
    setActionStatus(ok ? `${label} sent` : `${label} failed`);
    setPendingAction(null);
    setTimeout(() => setActionStatus(""), 2500);
  };
  useEffect(() => {
    if (!parsed || !hostRef.current) return;
    api.loadCSS("https://esm.sh/xterm@5.3.0/css/xterm.css");
    if (attempt > 0) {
      clearDeadSession(parsed.session_id);
      disposeSession(parsed.session_id);
    }
    let session = SESSION_CACHE.get(parsed.session_id);
    if (!session) {
      if (isSessionDead(parsed.session_id)) {
        setStatus("ended");
        return;
      }
      session = buildSession(parsed, api);
    }
    const host = hostRef.current;
    host.appendChild(session.container);
    refreshTerm(session);
    setStatus(session.status);
    const statusCb = (s) => setStatus(s);
    session.statusListeners.add(statusCb);
    if (session.unsubTheme) {
      try {
        session.unsubTheme();
      } catch {
      }
    }
    session.unsubTheme = onThemeChange(() => {
      try {
        session.term.options.theme = buildXtermTheme();
      } catch {
      }
    });
    if (session.unsubVisible) {
      try {
        session.unsubVisible();
      } catch {
      }
    }
    session.unsubVisible = onVisibleChange((vis) => {
      if (vis) refreshTerm(session);
    });
    let rafId = 0;
    let wasMeasurable = false;
    const scheduleFit = () => {
      if (rafId) return;
      rafId = requestAnimationFrame(() => {
        rafId = 0;
        fitAndSync(session);
        const r = session.container.getBoundingClientRect();
        const measurable = r.width >= 2 && r.height >= 2;
        if (measurable) void loadRendererAddon(session);
        if (measurable && !wasMeasurable) refreshTerm(session);
        wasMeasurable = measurable;
      });
    };
    const ro = new ResizeObserver(scheduleFit);
    ro.observe(host);
    scheduleFit();
    if (session.status === "open") {
      try {
        session.term.focus();
      } catch {
      }
    }
    return () => {
      if (rafId) cancelAnimationFrame(rafId);
      ro.disconnect();
      session.statusListeners.delete(statusCb);
      try {
        getGraveyard().appendChild(session.container);
      } catch {
      }
    };
  }, [parsed?.session_id, parsed?.token, parsed?.ws_path, attempt]);
  if (!parsed) {
    return /* @__PURE__ */ React.createElement("div", { style: { width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", background: "#000000", color: "var(--muted-foreground, #6b7280)", fontFamily: "var(--font-mono, monospace)", fontSize: 12, padding: 16, textAlign: "center" } }, "Invalid .terminal file \u2014 expected JSON with ", `{ session_id, ws_path, token }`, ".");
  }
  const statusColor = status === "open" ? "var(--electric-teal, #7fcfa8)" : status === "connecting" ? "var(--filament-amber, #d4a94f)" : status === "busy" ? "var(--destructive, #e06c75)" : "var(--muted-foreground, #6b7280)";
  return /* @__PURE__ */ React.createElement("div", { style: {
    width: "100%",
    height: "100%",
    display: "flex",
    flexDirection: "column",
    background: "#000000",
    // Box-sizing: border-box so the host's reported width is the
    // outer width — matters for cell-width fitting; without it
    // any padding/border on a parent would push the terminal
    // wider than the cell.
    boxSizing: "border-box",
    // Hard-cap to the parent's width. The cell can ask the
    // renderer for an exact pixel size; this prevents the
    // xterm canvas from extending past the cell on a wider-than-
    // expected font fallback.
    minWidth: 0,
    overflow: "hidden"
  } }, /* @__PURE__ */ React.createElement("div", { style: { height: 24, background: "var(--obsidian-plate, #1a1c23)", borderBottom: "1px solid var(--tungsten-dim, #2a2d3a)", display: "flex", alignItems: "center", padding: "0 8px", gap: 8, flexShrink: 0, fontFamily: "var(--font-mono, monospace)", fontSize: 11 } }, /* @__PURE__ */ React.createElement("span", { style: { color: "var(--muted-foreground, #9ca3af)" } }, parsed.label), /* @__PURE__ */ React.createElement("span", { style: { color: statusColor } }, "\u25CF ", status), /* @__PURE__ */ React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 2 }, title: "Terminal font size" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => changeFontSize(-1),
      disabled: fontSize <= FONT_SIZE_MIN,
      title: "Decrease font size",
      style: { ...FONT_BTN_STYLE, opacity: fontSize <= FONT_SIZE_MIN ? 0.4 : 1, cursor: fontSize <= FONT_SIZE_MIN ? "default" : "pointer" }
    },
    "A\u2212"
  ), /* @__PURE__ */ React.createElement("span", { style: { color: "var(--muted-foreground, #9ca3af)", minWidth: 16, textAlign: "center" } }, fontSize), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => changeFontSize(1),
      disabled: fontSize >= FONT_SIZE_MAX,
      title: "Increase font size",
      style: { ...FONT_BTN_STYLE, opacity: fontSize >= FONT_SIZE_MAX ? 0.4 : 1, cursor: fontSize >= FONT_SIZE_MAX ? "default" : "pointer" }
    },
    "A+"
  )), actionStatus && /* @__PURE__ */ React.createElement("span", { style: { color: "var(--electric-teal, #7fcfa8)" } }, actionStatus), /* @__PURE__ */ React.createElement("div", { style: { marginLeft: "auto", display: "flex", alignItems: "center", gap: 6 } }, parsed.buttons.map((b) => {
    const busy = pendingAction === b.id;
    const ctaBg = busy ? "var(--muted, #3a3d52)" : "color-mix(in srgb, #10b981 35%, var(--void-main))";
    return /* @__PURE__ */ React.createElement(
      "button",
      {
        key: b.id,
        onClick: () => clickAction(b.id, b.label),
        disabled: busy || !!pendingAction,
        style: { height: 18, padding: "0 8px", background: ctaBg, border: "1px solid color-mix(in srgb, #10b981 60%, var(--tungsten-dim))", borderRadius: "var(--radius-sm, 3px)", color: "var(--signal-white, #d6f5e4)", fontFamily: "var(--font-mono, monospace)", fontSize: 10, cursor: busy ? "wait" : "pointer", opacity: pendingAction && !busy ? 0.6 : 1 }
      },
      busy ? "\u2026" : b.label
    );
  }), (status === "closed" || status === "busy" || status === "ended") && /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setAttempt((a) => a + 1),
      style: { height: 18, padding: "0 8px", background: "var(--muted, #2d2f3e)", border: "1px solid var(--tungsten-dim, #3a3d52)", borderRadius: "var(--radius-sm, 3px)", color: "var(--signal-white, #e2e8f0)", fontFamily: "var(--font-mono, monospace)", fontSize: 10, cursor: "pointer" }
    },
    "Reconnect"
  ))), /* @__PURE__ */ React.createElement(
    "div",
    {
      ref: hostRef,
      style: {
        flex: 1,
        // No padding here — xterm wants the full container
        // box for accurate cell-size measurement, and the
        // padding was eating ~1 column off the right side
        // at narrow cell widths.
        overflow: "hidden",
        minWidth: 0,
        minHeight: 0,
        display: status === "ended" ? "flex" : void 0,
        alignItems: status === "ended" ? "center" : void 0,
        justifyContent: status === "ended" ? "center" : void 0
      }
    },
    status === "ended" && /* @__PURE__ */ React.createElement("span", { style: { color: "var(--muted-foreground, #6b7280)", fontFamily: "var(--font-mono, monospace)", fontSize: 12, padding: 16, textAlign: "center" } }, "Terminal session ended \u2014 run the cell again to start a new one.")
  ));
}
var main_default = defineRenderer({ component: TerminalViewer });
export {
  main_default as default
};
