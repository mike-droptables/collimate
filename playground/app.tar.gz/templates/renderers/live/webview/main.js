import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from "https://esm.sh/react@18";
import { defineRenderer, useCollimateFile } from "/api/sdk/react.js";
import { apiOrigin, openSessionSocket } from "/api/sdk/session.js";
function parse(raw) {
  const s = (raw || "").trim();
  if (!s) return {};
  try {
    return JSON.parse(s);
  } catch {
    return {};
  }
}
function wsUrlFromProxyBase(api, proxyBase) {
  const abs = new URL(proxyBase + "__collimate/ws", apiOrigin(api));
  abs.protocol = abs.protocol === "https:" ? "wss:" : "ws:";
  return abs.toString();
}
function WebView() {
  const { content, api } = useCollimateFile();
  const artifact = useMemo(() => parse(content), [content]);
  const imgRef = useRef(null);
  const liveIframeRef = useRef(null);
  const fitRef = useRef(null);
  const overlayRef = useRef(null);
  const sockRef = useRef(null);
  const selectionCacheRef = useRef("");
  const [focusField, setFocusField] = useState(null);
  const typeOverlayRef = useRef(null);
  const lastTypeEditRef = useRef(0);
  const [blockedNote, setBlockedNote] = useState(null);
  const blockedTimerRef = useRef(void 0);
  useEffect(() => {
    const ta = typeOverlayRef.current;
    if (!ta || !focusField) return;
    const recentlyTyped = Date.now() - lastTypeEditRef.current < 300;
    if (document.activeElement !== ta) {
      ta.value = focusField.value;
      ta.focus({ preventScroll: true });
      try {
        ta.setSelectionRange(focusField.selStart, focusField.selEnd);
      } catch {
      }
    } else if (!recentlyTyped && ta.value !== focusField.value) {
      const pos = focusField.selEnd;
      ta.value = focusField.value;
      try {
        ta.setSelectionRange(pos, pos);
      } catch {
      }
    }
  }, [focusField]);
  const [mode, setMode] = useState(
    () => artifact.renderMode === "live" ? "live" : "image"
  );
  const modeRef = useRef(mode);
  useEffect(() => {
    modeRef.current = mode;
  }, [mode]);
  const [status, setStatus] = useState({ kind: "idle" });
  const [busyAction, setBusyAction] = useState(null);
  const [windowOpen, setWindowOpen] = useState(false);
  const [scale, setScale] = useState(1);
  const [vw, setVw] = useState(() => artifact.viewport?.width || 1280);
  const [vh, setVh] = useState(() => artifact.viewport?.height || 800);
  const [urlInput, setUrlInput] = useState(() => artifact.url || "");
  const editingUrlRef = useRef(false);
  const liveUrlRef = useRef(artifact.url || "");
  const [liveSrc, setLiveSrc] = useState("");
  const postToLive = (msg) => {
    const w = liveIframeRef.current?.contentWindow;
    if (w) {
      try {
        w.postMessage(msg, "*");
      } catch {
      }
    }
  };
  const liveBaseUrl = () => {
    const token = (artifact.liveToken || "").trim();
    return token ? `${window.location.protocol}//${token}.${window.location.host}/` : (artifact.proxyBase || "").trim();
  };
  const liveSrcFor = (target) => liveBaseUrl() + "__collimate/go?url=" + encodeURIComponent(
    /^[a-z][a-z0-9+.-]*:/i.test(target) ? target : "https://" + target
  );
  const scaleRef = useRef(scale);
  useEffect(() => {
    scaleRef.current = scale;
  }, [scale]);
  useEffect(() => {
    if (artifact.renderMode === "live" || artifact.renderMode === "image") {
      setMode(artifact.renderMode);
    }
  }, [artifact.renderMode]);
  useEffect(() => {
    if (mode !== "live") {
      setLiveSrc("");
      return;
    }
    if (!liveBaseUrl()) return;
    setLiveSrc(liveSrcFor((artifact.url || "").trim() || "about:blank"));
    setStatus({ kind: "connecting" });
  }, [mode, artifact.proxyBase, artifact.liveToken]);
  useEffect(() => {
    if (mode !== "live") return;
    const onMessage = (e) => {
      const d = e.data || {};
      if (d.collimateLive === "url" && typeof d.url === "string") {
        liveUrlRef.current = d.url;
        if (!editingUrlRef.current) setUrlInput(d.url);
        sockRef.current?.sendJson({ kind: "nav", action: "go", url: d.url });
      } else if (d.collimateLive === "ready") {
        setStatus({ kind: "live" });
      } else if (d.collimateLive === "error") {
        setStatus({ kind: "closed", reason: "live proxy failed to start" });
      }
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [mode]);
  const sendInput = (msg) => {
    sockRef.current?.sendJson(msg);
  };
  const toPageCoords = (clientX, clientY) => {
    const rect = overlayRef.current?.getBoundingClientRect();
    const s = scaleRef.current || 1;
    if (!rect) return { x: 0, y: 0 };
    return {
      x: Math.max(0, (clientX - rect.left) / s),
      y: Math.max(0, (clientY - rect.top) / s)
    };
  };
  const fireAction = async (actionId) => {
    if (!api?.emitAction || busyAction) return;
    setBusyAction(actionId);
    try {
      await api.emitAction(actionId);
    } finally {
      setTimeout(() => setBusyAction(null), 1e3);
    }
  };
  useEffect(() => {
    const proxyBase = (artifact.proxyBase || "").trim();
    if (!proxyBase) return;
    const paintFrame = (b64) => {
      const el = imgRef.current;
      if (!el) return;
      el.src = `data:image/jpeg;base64,${b64}`;
    };
    const pushUrl = (u) => {
      liveUrlRef.current = u;
      if (!editingUrlRef.current) setUrlInput(u);
    };
    const sock = openSessionSocket({
      url: wsUrlFromProxyBase(api, proxyBase),
      transientRetryMs: 1500,
      maxFailedOpens: 5,
      onStatus: (st) => {
        if (st === "open") setStatus({ kind: "live" });
        else if (st === "connecting") setStatus({ kind: "connecting" });
        else if (st === "ended") setStatus({ kind: "closed", reason: "session ended" });
        else setStatus({ kind: "closed", reason: "disconnected \u2014 retrying" });
      },
      onMessage: (msg) => {
        let payload;
        try {
          payload = JSON.parse(msg.data);
        } catch {
          return;
        }
        if (payload.kind === "init") {
          if (payload.mode === "live" || payload.mode === "image") {
            setMode(payload.mode);
          }
          if (payload.viewport && typeof payload.viewport.width === "number" && typeof payload.viewport.height === "number") {
            setVw(payload.viewport.width);
            setVh(payload.viewport.height);
          }
          if (typeof payload.url === "string" && payload.url && modeRef.current !== "live") {
            pushUrl(payload.url);
          }
          if (typeof payload.headful === "boolean") {
            setWindowOpen(payload.headful);
          }
          if (typeof payload.frame === "string" && payload.frame) {
            paintFrame(payload.frame);
          }
        } else if (payload.kind === "window" && typeof payload.headful === "boolean") {
          setWindowOpen(payload.headful);
        } else if (payload.kind === "frame" && typeof payload.data === "string") {
          paintFrame(payload.data);
        } else if (payload.kind === "viewport" && typeof payload.width === "number" && typeof payload.height === "number") {
          setVw(payload.width);
          setVh(payload.height);
        } else if (payload.kind === "url" && typeof payload.url === "string" && modeRef.current !== "live") {
          pushUrl(payload.url);
        } else if (payload.kind === "clipboard" && typeof payload.text === "string") {
          if (payload.text) navigator.clipboard?.writeText(payload.text).catch(() => {
          });
        } else if (payload.kind === "selection" && typeof payload.text === "string") {
          selectionCacheRef.current = payload.text;
        } else if (payload.kind === "focus") {
          const info = payload.info;
          setFocusField(info && info.rect ? info : null);
        } else if (payload.kind === "cursor" && typeof payload.cursor === "string") {
          let c = payload.cursor;
          if (!c || c === "auto" || c.indexOf("url(") !== -1) c = "default";
          if (overlayRef.current) overlayRef.current.style.cursor = c;
        } else if (payload.kind === "blocked") {
          const u = typeof payload.url === "string" ? payload.url : "";
          setBlockedNote(u ? `Popup blocked: ${u}` : "Popup blocked");
          if (blockedTimerRef.current) clearTimeout(blockedTimerRef.current);
          blockedTimerRef.current = window.setTimeout(() => setBlockedNote(null), 4e3);
        }
      }
    });
    sockRef.current = sock;
    return () => {
      sockRef.current = null;
      sock.close();
    };
  }, [artifact.proxyBase]);
  useLayoutEffect(() => {
    const el = fitRef.current;
    if (!el) return;
    let sendTimer = null;
    let lastSent = null;
    const measure = () => {
      const cw = el.clientWidth;
      const ch = el.clientHeight;
      if (cw === 0 || ch === 0) return;
      const s = Math.min(cw / vw, ch / vh);
      if (s > 0 && Number.isFinite(s)) setScale(s);
      if (modeRef.current === "live") return;
      const targetW = Math.round(cw);
      const targetH = Math.round(ch);
      const dpr = window.devicePixelRatio || 1;
      if (sendTimer !== null) window.clearTimeout(sendTimer);
      sendTimer = window.setTimeout(() => {
        if (lastSent && lastSent.w === targetW && lastSent.h === targetH && lastSent.dpr === dpr) return;
        lastSent = { w: targetW, h: targetH, dpr };
        sendInput({ kind: "viewport", width: targetW, height: targetH, dpr });
      }, 250);
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => {
      ro.disconnect();
      if (sendTimer !== null) window.clearTimeout(sendTimer);
    };
  }, [vw, vh]);
  const pointerMoveSentAtRef = useRef(0);
  const statusColor = status.kind === "live" ? "var(--electric-teal, #7fcfa8)" : status.kind === "closed" ? "var(--destructive, #ef4444)" : "var(--muted-foreground, #9ca3af)";
  if (!artifact.proxyBase) {
    return /* @__PURE__ */ React.createElement("div", { style: {
      width: "100%",
      height: "100%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      background: "var(--void-main, #0a0b0d)",
      color: "var(--muted-foreground, #6b7280)",
      fontFamily: "var(--font-mono, monospace)",
      fontSize: 13,
      padding: 24,
      textAlign: "center"
    } }, "Waiting for the Website Live generator to publish a session\u2026");
  }
  const navigate = (action) => {
    if (modeRef.current === "live") {
      if (action === "reload") {
        const el = liveIframeRef.current;
        if (el) el.src = el.src;
      } else {
        postToLive({ collimateLiveNav: action });
      }
      return;
    }
    sendInput({ kind: "nav", action });
  };
  const commitUrl = () => {
    const u = urlInput.trim();
    if (u) {
      if (modeRef.current === "live") setLiveSrc(liveSrcFor(u));
      else sendInput({ kind: "nav", action: "go", url: u });
    }
    editingUrlRef.current = false;
  };
  const toggleWindow = () => {
    const next = !windowOpen;
    setWindowOpen(next);
    sendInput({ kind: "window", action: next ? "open" : "hide" });
  };
  const navBtnStyle = {
    width: 24,
    height: 20,
    padding: 0,
    flexShrink: 0,
    background: "transparent",
    border: "1px solid var(--tungsten-dim, #2a2d3a)",
    borderRadius: 3,
    color: "var(--signal-white, #e2e8f0)",
    fontFamily: "var(--font-mono, monospace)",
    fontSize: 11,
    lineHeight: "18px",
    cursor: "pointer"
  };
  const buttonName = (b) => b === 1 ? "middle" : b === 2 ? "right" : "left";
  const onPointerMove = (e) => {
    const now = performance.now();
    if (now - pointerMoveSentAtRef.current < 16) return;
    pointerMoveSentAtRef.current = now;
    const { x, y } = toPageCoords(e.clientX, e.clientY);
    sendInput({ kind: "pointer", type: "move", x, y });
  };
  const onPointerDown = (e) => {
    overlayRef.current?.focus({ preventScroll: true });
    const { x, y } = toPageCoords(e.clientX, e.clientY);
    sendInput({ kind: "pointer", type: "down", x, y, button: buttonName(e.button) });
  };
  const onPointerUp = (e) => {
    const { x, y } = toPageCoords(e.clientX, e.clientY);
    sendInput({ kind: "pointer", type: "up", x, y, button: buttonName(e.button) });
  };
  const onContextMenu = (e) => {
    e.preventDefault();
  };
  const onWheel = (e) => {
    const { x, y } = toPageCoords(e.clientX, e.clientY);
    sendInput({ kind: "wheel", x, y, deltaX: e.deltaX, deltaY: e.deltaY });
  };
  const handleClipboardKey = (e) => {
    if (!(e.metaKey || e.ctrlKey) || e.altKey) return false;
    const k = e.key.toLowerCase();
    if (k === "c" || k === "x") {
      const text = selectionCacheRef.current;
      if (text) navigator.clipboard?.writeText(text).catch(() => {
      });
      if (k === "x" && text) {
        sendInput({ kind: "key", type: "down", key: "Delete" });
        sendInput({ kind: "key", type: "up", key: "Delete" });
      }
      e.preventDefault();
      e.stopPropagation();
      return true;
    }
    if (k === "v") {
      e.preventDefault();
      e.stopPropagation();
      navigator.clipboard?.readText().then((text) => {
        if (text) sendInput({ kind: "paste", text });
      }).catch(() => {
      });
      return true;
    }
    return false;
  };
  const modBits = (e) => (e.altKey ? 1 : 0) | (e.ctrlKey ? 2 : 0) | (e.metaKey ? 4 : 0) | (e.shiftKey ? 8 : 0);
  const onKeyDown = (e) => {
    if (handleClipboardKey(e)) return;
    e.preventDefault();
    sendInput({ kind: "key", type: "down", key: e.key, mods: modBits(e) });
  };
  const onKeyUp = (e) => {
    e.preventDefault();
    sendInput({ kind: "key", type: "up", key: e.key, mods: modBits(e) });
  };
  const onOverlayKeyDown = (e) => {
    lastTypeEditRef.current = Date.now();
    const combo = e.metaKey || e.ctrlKey;
    const k = e.key.length === 1 ? e.key.toLowerCase() : "";
    if (combo && (k === "c" || k === "v")) return;
    sendInput({ kind: "key", type: "down", key: e.key, mods: modBits(e) });
    if (e.key === "Enter" && !e.shiftKey) e.preventDefault();
  };
  const onOverlayKeyUp = (e) => {
    const combo = e.metaKey || e.ctrlKey;
    const k = e.key.length === 1 ? e.key.toLowerCase() : "";
    if (combo && (k === "c" || k === "v")) return;
    sendInput({ kind: "key", type: "up", key: e.key, mods: modBits(e) });
  };
  const onOverlayPaste = (e) => {
    const text = e.clipboardData?.getData("text/plain") || "";
    if (text) {
      lastTypeEditRef.current = Date.now();
      sendInput({ kind: "paste", text });
    }
  };
  return /* @__PURE__ */ React.createElement("div", { style: {
    width: "100%",
    height: "100%",
    display: "flex",
    flexDirection: "column",
    background: "var(--void-main, #0a0b0d)",
    position: "relative"
  } }, blockedNote && /* @__PURE__ */ React.createElement("div", { style: {
    position: "absolute",
    bottom: 10,
    left: "50%",
    transform: "translateX(-50%)",
    zIndex: 20,
    maxWidth: "90%",
    padding: "6px 12px",
    background: "rgba(20,22,28,0.95)",
    border: "1px solid var(--tungsten-dim, #2a2d3a)",
    borderRadius: 6,
    color: "var(--signal-white, #e2e8f0)",
    font: "12px var(--font-mono, monospace)",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    pointerEvents: "none",
    boxShadow: "0 2px 10px rgba(0,0,0,0.4)"
  }, title: blockedNote }, "\u{1F6AB} ", blockedNote), /* @__PURE__ */ React.createElement("div", { style: {
    height: 32,
    flexShrink: 0,
    background: "var(--obsidian-plate, #1a1c23)",
    borderBottom: "1px solid var(--tungsten-dim, #2a2d3a)",
    display: "flex",
    alignItems: "center",
    padding: "0 8px",
    gap: 6,
    fontFamily: "var(--font-mono, monospace)",
    fontSize: 11,
    color: "var(--signal-white, #e2e8f0)"
  } }, /* @__PURE__ */ React.createElement("span", { style: {
    width: 8,
    height: 8,
    borderRadius: "50%",
    background: statusColor,
    flexShrink: 0
  }, title: status.kind === "closed" ? status.reason : status.kind }), /* @__PURE__ */ React.createElement(
    "button",
    {
      style: navBtnStyle,
      title: "Back",
      onClick: () => navigate("back")
    },
    "\u2190"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      style: navBtnStyle,
      title: "Forward",
      onClick: () => navigate("forward")
    },
    "\u2192"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      style: navBtnStyle,
      title: "Reload",
      onClick: () => navigate("reload")
    },
    "\u27F3"
  ), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      value: urlInput,
      spellCheck: false,
      placeholder: "https://\u2026",
      onChange: (e) => setUrlInput(e.target.value),
      onFocus: (e) => {
        editingUrlRef.current = true;
        e.target.select();
      },
      onBlur: () => {
        editingUrlRef.current = false;
        setUrlInput(liveUrlRef.current);
      },
      onKeyDown: (e) => {
        if (e.key === "Enter") {
          commitUrl();
          e.target.blur();
        } else if (e.key === "Escape") {
          e.target.blur();
        }
        e.stopPropagation();
      },
      style: {
        flex: 1,
        height: 20,
        minWidth: 60,
        background: "var(--void-main, #0d0f14)",
        border: "1px solid var(--tungsten-dim, #2a2d3a)",
        borderRadius: 3,
        padding: "0 8px",
        color: "var(--signal-white, #e2e8f0)",
        fontFamily: "var(--font-mono, monospace)",
        fontSize: 11,
        outline: "none"
      }
    }
  ), artifact.window && /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: toggleWindow,
      title: windowOpen ? "Hide the desktop browser window (return to streaming only)" : "Open a real browser window to solve a sign-in / Cloudflare challenge",
      style: {
        flexShrink: 0,
        padding: "2px 10px",
        background: windowOpen ? "var(--electric-teal, #63B0A6)" : "transparent",
        color: windowOpen ? "var(--void-main, #0a0b0d)" : "var(--signal-white, #e2e8f0)",
        border: windowOpen ? "none" : "1px solid var(--tungsten-dim, #2a2d3a)",
        borderRadius: 3,
        fontFamily: "var(--font-mono, monospace)",
        fontSize: 11,
        cursor: "pointer",
        whiteSpace: "nowrap"
      }
    },
    windowOpen ? "Hide window" : "Open window"
  ), (artifact.actions || []).map((act) => /* @__PURE__ */ React.createElement(
    "button",
    {
      key: act.id,
      onClick: () => fireAction(act.id),
      disabled: busyAction === act.id,
      style: {
        flexShrink: 0,
        padding: "2px 10px",
        background: "var(--filament-amber, #d4a23c)",
        color: "var(--void-main, #0a0b0d)",
        border: "none",
        borderRadius: 3,
        fontFamily: "var(--font-mono, monospace)",
        fontSize: 11,
        cursor: busyAction === act.id ? "wait" : "pointer",
        opacity: busyAction === act.id ? 0.6 : 1
      }
    },
    busyAction === act.id ? "\u2026" : act.label
  ))), /* @__PURE__ */ React.createElement(
    "div",
    {
      ref: fitRef,
      style: {
        flex: 1,
        minHeight: 0,
        overflow: "hidden",
        // Letterbox bars during cell resizes (before the
        // page reflows to the new aspect) follow the host
        // scheme: --renderer-surface flips dark/light with
        // the theme, so dark mode never flashes white.
        background: "var(--renderer-surface, #1a1a1a)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
      }
    },
    mode === "live" ? (
      // Live mode: embed the cell's subdomain, where the daemon's
      // reverse proxy serves the real target page. It's the real
      // page, so pointer / keyboard / scroll are native — no scaling,
      // no input-capture overlay. Blank until liveSrc is set.
      liveSrc ? /* @__PURE__ */ React.createElement(
        "iframe",
        {
          ref: liveIframeRef,
          title: "Live page",
          src: liveSrc,
          style: {
            width: "100%",
            height: "100%",
            border: "none",
            background: "#fff",
            display: "block"
          }
        }
      ) : /* @__PURE__ */ React.createElement("div", { style: { width: "100%", height: "100%" } })
    ) : (
      // Image mode: the screencast frame sized at the page's native
      // vw × vh and CSS-scaled to fit, with an input-capture overlay
      // forwarding events to the live browser over the WS. The
      // scaled-size wrapper lets flexbox center the visible area
      // rather than the un-transformed native-size box.
      /* @__PURE__ */ React.createElement("div", { style: {
        width: vw * scale,
        height: vh * scale,
        position: "relative",
        flexShrink: 0
      } }, /* @__PURE__ */ React.createElement(
        "img",
        {
          ref: imgRef,
          alt: "",
          draggable: false,
          style: {
            width: vw,
            height: vh,
            position: "absolute",
            top: 0,
            left: 0,
            transform: `scale(${scale})`,
            transformOrigin: "top left",
            // Crisp scaling keeps text legible when the
            // cell is enlarged past the captured frame's
            // native pixel density.
            imageRendering: "auto",
            // Suppress the broken-image icon flash during
            // the brief window before the first frame.
            background: "var(--renderer-surface, #1a1a1a)",
            userSelect: "none",
            pointerEvents: "none"
          }
        }
      ), /* @__PURE__ */ React.createElement(
        "div",
        {
          ref: overlayRef,
          tabIndex: 0,
          "data-capture-keys": "true",
          onPointerMove,
          onPointerDown,
          onPointerUp,
          onContextMenu,
          onWheel,
          onKeyDown,
          onKeyUp,
          style: {
            position: "absolute",
            inset: 0,
            background: "transparent",
            cursor: "default",
            outline: "none",
            // Prevent the browser's pinch-zoom / pan
            // gestures from hijacking pointer events
            // before we get them.
            touchAction: "none",
            userSelect: "none"
          }
        }
      ), focusField && focusField.rect && focusField.rect.w > 1 && focusField.rect.h > 1 && (() => {
        const f = focusField;
        const r = f.rect;
        const pv = (s, fb = 0) => {
          const n = parseFloat(s);
          return (isNaN(n) ? fb : n) * scale;
        };
        return /* @__PURE__ */ React.createElement(
          "textarea",
          {
            ref: typeOverlayRef,
            spellCheck: false,
            dir: f.dir || "ltr",
            onKeyDown: onOverlayKeyDown,
            onKeyUp: onOverlayKeyUp,
            onPaste: onOverlayPaste,
            onContextMenu: (e) => e.preventDefault(),
            onPointerMove,
            onPointerUp,
            onPointerDown: (e) => {
              const { x, y } = toPageCoords(e.clientX, e.clientY);
              sendInput({ kind: "pointer", type: "down", x, y, button: buttonName(e.button) });
            },
            style: {
              position: "absolute",
              left: Math.max(0, r.x * scale),
              top: Math.max(0, r.y * scale),
              width: r.w * scale,
              height: r.h * scale,
              margin: 0,
              border: "none",
              outline: "none",
              resize: "none",
              overflow: "hidden",
              boxSizing: "border-box",
              background: f.bg || "#fff",
              color: f.color || "#000",
              fontSize: pv(f.fontSize, 16),
              fontFamily: f.fontFamily || "inherit",
              lineHeight: f.multiline ? parseFloat(f.lineHeight) ? `${pv(f.lineHeight)}px` : "normal" : `${Math.max(1, r.h * scale - pv(f.padTop) - pv(f.padBottom))}px`,
              paddingTop: pv(f.padTop),
              paddingLeft: pv(f.padLeft),
              paddingRight: pv(f.padRight),
              paddingBottom: pv(f.padBottom),
              textAlign: f.textAlign || "start",
              whiteSpace: f.multiline ? "pre-wrap" : "pre",
              zIndex: 5
            }
          }
        );
      })())
    )
  ));
}
var main_default = defineRenderer({ component: WebView });
export {
  main_default as default
};
