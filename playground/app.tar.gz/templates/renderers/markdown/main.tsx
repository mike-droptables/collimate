import React, { useState, useEffect } from 'https://esm.sh/react@18';
import {
    defineRenderer,
    tokens,
    useCollimateFile,
    useDebouncedSaveContent,
} from '/api/sdk/react.js';

// Quote-escape text interpolated into a double-quoted HTML attribute.
// parseMarkdown pre-escapes &/</>, so `"` is the only breakout char left;
// without this, ![" onerror="...](x) would inject an event handler.
function escAttr(s) {
  return String(s).replace(/"/g, '&quot;');
}

// Block javascript:, data:, vbscript: URLs — they'd otherwise execute
// inside the renderer's shadow DOM, which has access to the SDK API.
function safeUrl(raw) {
  const trimmed = String(raw).trim();
  if (/^(javascript|data|vbscript|file):/i.test(trimmed)) return '#';
  return escAttr(trimmed);
}

function parseMarkdown(md) {
  if (!md) return '';
  let html = md.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  html = html.replace(/```(\w*)\n([\s\S]*?)```/gm, (_, lang, code) =>
    `<pre><code style="background:var(--obsidian-plate);padding:12px;display:block;border-radius:var(--radius);border:1px solid var(--tungsten-dim);font-family:var(--font-mono);">${code.trimEnd()}</code></pre>`);
  html = html.replace(/`([^`\n]+)`/g, '<code style="background:var(--muted);color:var(--filament-amber);padding:2px 4px;border-radius:3px;font-family:var(--font-mono);">$1</code>');
  html = html.replace(/^###### (.+)$/gm, '<h6 style="color:var(--signal-white);font-weight:600;margin-top:1em;">$1</h6>');
  html = html.replace(/^##### (.+)$/gm, '<h5 style="color:var(--signal-white);font-weight:600;margin-top:1em;">$1</h5>');
  html = html.replace(/^#### (.+)$/gm, '<h4 style="color:var(--signal-white);font-weight:600;margin-top:1em;">$1</h4>');
  html = html.replace(/^### (.+)$/gm, '<h3 style="color:var(--signal-white);font-weight:600;margin-top:1em;font-size:1.1em;">$1</h3>');
  html = html.replace(/^## (.+)$/gm, '<h2 style="color:var(--signal-white);font-weight:600;margin-top:1em;font-size:1.35em;">$1</h2>');
  html = html.replace(/^# (.+)$/gm, '<h1 style="color:var(--signal-white);font-weight:600;margin-top:1em;font-size:1.75em;border-bottom:1px solid var(--tungsten-dim);padding-bottom:4px;">$1</h1>');
  html = html.replace(/^---+$/gm, '<hr style="border-top:1px solid var(--tungsten-dim);margin:1.5em 0;">');
  html = html.replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>');
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
  html = html.replace(/^&gt; (.+)$/gm, '<blockquote style="border-left:3px solid var(--tungsten-dim);padding-left:1em;color:var(--muted-foreground);margin:1em 0;"><p>$1</p></blockquote>');
  html = html.replace(/^[*\-] (.+)$/gm, '<li style="margin:0.25em 0;">$1</li>');
  html = html.replace(/(<li style="margin:0.25em 0;">[\s\S]*?<\/li>\n?)+/g, (m) => `<ul style="padding-left:1.5em;margin:0.5em 0;">${m}</ul>`);
  html = html.replace(/^\d+\. (.+)$/gm, '<li style="margin:0.25em 0;">$1</li>');
  html = html.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, (_m, alt, src) => `<img alt="${escAttr(alt)}" src="${safeUrl(src)}" style="max-width:100%">`);
  html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_m, text, href) => `<a href="${safeUrl(href)}" style="color:var(--electric-teal);text-decoration:underline;">${text}</a>`);
  html = html.replace(/\n\n+/g, '\n\n');
  html = html.split('\n\n').map((block) => {
    if (/^<[hpuobldi]/.test(block.trim())) return block;
    return `<p style="margin:0.75em 0;">${block}</p>`;
  }).join('\n');
  return html;
}

function MarkdownEditor() {
    const { content, saveContent, isReadOnly } = useCollimateFile();
    const [local, setLocal] = useState(content);
    const debouncedSave = useDebouncedSaveContent(saveContent);

    useEffect(() => { setLocal(content); }, [content]);

    return (
        <div style={{ display: 'flex', width: '100%', height: '100%', background: 'var(--renderer-surface, #1a1a1a)' }}>
            {!isReadOnly && (
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', borderRight: `1px solid ${tokens.color.tungstenDim}` }}>
                    <textarea
                        value={local}
                        onChange={e => { setLocal(e.target.value); debouncedSave(e.target.value); }}
                        style={{ flex: 1, background: 'transparent', color: tokens.color.signalWhite, fontFamily: tokens.font.mono, fontSize: 13, lineHeight: 1.6, padding: 16, border: 'none', outline: 'none', resize: 'none' }}
                        spellCheck={false}
                    />
                </div>
            )}
            <div
                style={{ flex: 1, overflowY: 'auto', padding: 24, color: tokens.color.signalWhite, fontFamily: tokens.font.sans, fontSize: 14, lineHeight: 1.6 }}
                dangerouslySetInnerHTML={{ __html: parseMarkdown(local) }}
            />
        </div>
    );
}

export default defineRenderer({ component: MarkdownEditor });
