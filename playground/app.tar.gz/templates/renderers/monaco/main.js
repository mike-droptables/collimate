import React, { useEffect, useRef } from "https://esm.sh/react@18";
import {
  defineRenderer,
  useCollimateFile,
  useRemoteScript,
  useTheme
} from "/api/sdk/react.js";
const MONACO_VERSION = "0.44.0";
const MONACO_BASE = `https://cdn.jsdelivr.net/npm/monaco-editor@${MONACO_VERSION}/min/vs`;
let _monacoPromise = null;
function ensureMonaco() {
  if (_monacoPromise) return _monacoPromise;
  _monacoPromise = new Promise((resolve) => {
    window.require.config({ paths: { vs: MONACO_BASE } });
    window.require(["vs/editor/editor.main"], () => resolve(window.monaco));
  });
  return _monacoPromise;
}
function detectLanguage(content = "", filename = "") {
  const base = filename.split("/").pop().toLowerCase();
  if (base === "dockerfile") return "dockerfile";
  if (base === "makefile") return "shell";
  const ext = base.split(".").pop();
  const extMap = {
    "js": "javascript",
    "jsx": "javascript",
    "mjs": "javascript",
    "cjs": "javascript",
    "ts": "typescript",
    "tsx": "typescript",
    "mts": "typescript",
    "cts": "typescript",
    "py": "python",
    "go": "go",
    "rs": "rust",
    "java": "java",
    "kt": "kotlin",
    "kts": "kotlin",
    "rb": "ruby",
    "php": "php",
    "swift": "swift",
    "cs": "csharp",
    "r": "r",
    "pl": "perl",
    "lua": "lua",
    "dart": "dart",
    "scala": "scala",
    "ps1": "powershell",
    "c": "c",
    "h": "c",
    "cpp": "cpp",
    "hpp": "cpp",
    "css": "css",
    "scss": "scss",
    "less": "less",
    "html": "html",
    "xml": "xml",
    "svg": "xml",
    "json": "json",
    "jsonc": "json",
    "md": "markdown",
    "markdown": "markdown",
    // monaco 0.44 has no 'toml' language — it falls back to plaintext;
    // kept so a future monaco bump picks it up. Locks are TOML-ish: ini
    // highlighting reads better than plaintext.
    "yaml": "yaml",
    "yml": "yaml",
    "toml": "toml",
    "lock": "ini",
    "ini": "ini",
    "cfg": "ini",
    "conf": "ini",
    "env": "ini",
    "gitignore": "ini",
    "gitattributes": "ini",
    "dockerignore": "ini",
    "editorconfig": "ini",
    "proto": "protobuf",
    "sql": "sql",
    "graphql": "graphql",
    "gql": "graphql",
    "sh": "shell",
    "bash": "shell",
    "zsh": "shell",
    "fish": "shell"
  };
  if (extMap[ext]) return extMap[ext];
  const t = content.trimStart();
  if (/^(import|export|const|let|var|function|class|interface|type )\b/.test(t)) return "typescript";
  if (/^(import |from |def |class |async def )/.test(t) || t.startsWith("#!/usr/bin/env python")) return "python";
  if (/^package /.test(t) || /^func /.test(t)) return "go";
  if (/^(fn |use |struct |impl |pub )/.test(t)) return "rust";
  if (/^(SELECT|INSERT|UPDATE|DELETE|CREATE|DROP)\b/i.test(t)) return "sql";
  if (t.startsWith("<") && /<html|<div|<span/i.test(t)) return "html";
  if (t.startsWith("{") || t.startsWith("[")) return "json";
  if (/^(#|---\n)/.test(t)) return "yaml";
  return "plaintext";
}
const monacoThemeFor = (s) => s === "light" ? "vs" : "vs-dark";
function MonacoEditor() {
  const { content, saveContent, isReadOnly, fileName, api } = useCollimateFile();
  const { scheme, onChange: onThemeChange } = useTheme(api);
  const { loading: loaderLoading } = useRemoteScript(`${MONACO_BASE}/loader.js`);
  const containerRef = useRef(null);
  const editorRef = useRef(null);
  useEffect(() => {
    if (loaderLoading || !containerRef.current) return;
    let editor;
    let cancelled = false;
    ensureMonaco().then((monaco) => {
      if (cancelled || !containerRef.current) return;
      editor = monaco.editor.create(containerRef.current, {
        value: content || "",
        language: detectLanguage(content, fileName),
        theme: monacoThemeFor(scheme),
        readOnly: isReadOnly,
        automaticLayout: true,
        minimap: { enabled: false }
      });
      if (!isReadOnly) {
        editor.onDidChangeModelContent(() => saveContent(editor.getValue()));
      }
      if (api && typeof api.reportSelection === "function") {
        editor.onDidChangeCursorSelection(() => {
          try {
            const sel = editor.getSelection();
            const model = editor.getModel();
            const text = sel && model && !sel.isEmpty() ? model.getValueInRange(sel) : "";
            api.reportSelection(text);
          } catch {
          }
        });
      }
      editorRef.current = editor;
      const unsubTheme = onThemeChange((s) => {
        try {
          monaco.editor.setTheme(monacoThemeFor(s));
        } catch {
        }
      });
      editor._unsubTheme = unsubTheme;
      requestAnimationFrame(() => {
        if (!cancelled && api && api.ready) api.ready();
      });
    });
    return () => {
      cancelled = true;
      if (editor) {
        if (editor._unsubTheme) editor._unsubTheme();
        editor.dispose();
      }
    };
  }, [loaderLoading]);
  useEffect(() => {
    if (editorRef.current && editorRef.current.getValue() !== content) {
      editorRef.current.setValue(content || "");
    }
  }, [content]);
  return /* @__PURE__ */ React.createElement("div", { ref: containerRef, style: { width: "100%", height: "100%", backgroundColor: "var(--void-main)" } });
}
function MonacoDiffEditor() {
  const { content, diffContent, fileName, api } = useCollimateFile();
  const { scheme, onChange: onThemeChange } = useTheme(api);
  const { loading: loaderLoading } = useRemoteScript(`${MONACO_BASE}/loader.js`);
  const containerRef = useRef(null);
  useEffect(() => {
    if (loaderLoading || !containerRef.current) return;
    let diffEditor;
    let cancelled = false;
    ensureMonaco().then((monaco) => {
      if (cancelled || !containerRef.current) return;
      diffEditor = monaco.editor.createDiffEditor(containerRef.current, {
        theme: monacoThemeFor(scheme),
        automaticLayout: true,
        renderSideBySide: true,
        readOnly: true
      });
      const lang = detectLanguage(content, fileName);
      diffEditor.setModel({
        original: monaco.editor.createModel(diffContent || "", lang),
        modified: monaco.editor.createModel(content || "", lang)
      });
      const unsubTheme = onThemeChange((s) => {
        try {
          monaco.editor.setTheme(monacoThemeFor(s));
        } catch {
        }
      });
      diffEditor._unsubTheme = unsubTheme;
      requestAnimationFrame(() => {
        if (!cancelled && api && api.ready) api.ready();
      });
    });
    return () => {
      cancelled = true;
      if (diffEditor) {
        if (diffEditor._unsubTheme) diffEditor._unsubTheme();
        diffEditor.dispose();
      }
    };
  }, [content, diffContent, fileName, loaderLoading]);
  return /* @__PURE__ */ React.createElement("div", { ref: containerRef, style: { width: "100%", height: "100%", backgroundColor: "var(--void-main)" } });
}
var main_default = defineRenderer({
  component: MonacoEditor,
  diffComponent: MonacoDiffEditor,
  deferReady: true
});
export {
  main_default as default
};
