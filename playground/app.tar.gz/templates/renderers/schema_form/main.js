import React, { useState, useEffect, useRef, useCallback } from "https://esm.sh/react@18";
import jsyaml from "https://esm.sh/js-yaml@4.1.0";
import {
  defineRenderer,
  useCollimateFile,
  useDebouncedSaveContent
} from "/api/sdk/react.js";
const GEN_MANIFEST_SCHEMA = {
  title: "Generator Manifest",
  fields: [
    { key: "id", type: "text", label: "ID", required: true, description: "Unique identifier used by the runner to look up this generator (lowercase, hyphenated)." },
    { key: "name", type: "text", label: "Display Name", required: true },
    { key: "type", type: "dropdown", label: "Type", required: true, options: ["modify", "create"], description: "modify = rewrites the current cell (version chain). create = produces fresh cells; its input shape (no input / single cell / stack) comes from inputs.cells." },
    { key: "version", type: "text", label: "Version", required: true, default: "0.1.0" },
    { key: "summary", type: "textarea", label: "Summary", required: true, description: "One- or two-sentence description shown in the picker." },
    { key: "entrypoint", type: "text", label: "Entrypoint", required: true, description: "Relative path to the .py file inside this generator directory." },
    { key: "runtime", type: "dropdown", label: "Runtime", options: ["", "native", "wasm", "both"], default: "", description: 'Empty = native (default). "wasm" = browser playground only. "both" = either runtime.' },
    { key: "prompt_intent", type: "text", label: "Prompt Intent", description: 'One-line hint shown above the picker textarea (e.g. "What does the best candidate look like?").' },
    { key: "chat", type: "checkbox", label: "Chat-shaped", description: "true = daemon-style multi-turn run via gen.chat_loop(). Default: false." },
    { key: "ephemeral", type: "checkbox", label: "Ephemeral", description: 'true = a throwaway live session (e.g. a browser): its cell is kept out of the DAG history and offers "close" (stop + remove) instead of "stop". Default: false.' },
    { key: "draft_files", type: "list", label: "Draft Files", description: "Relative paths to files (typically .set_yaml) seeded into .colreserved/config/files/ before the run. Editable in the picker form." },
    { key: "summary_file", type: "text", label: "Summary File", description: "Which draft file the picker form opens first (optional)." },
    { key: "default_route", type: "dropdown", label: "Default Route", options: ["", "run"], default: "", description: 'Empty = "run". (The "draft" route was removed in the modify/create rework.)' },
    { key: "output.default", type: "dropdown", label: "Output Default", options: ["", "create", "update"], description: "update = writes a version to the running cell. create = mints a new side cell." },
    { key: "inputs.cells.min", type: "number", label: "Min Input Cells", min: 0, description: "For type=create: 0/0 = no input, 1/1 = single cell, else a stack (min may be 0). For type=modify, leave blank (the current cell)." },
    { key: "inputs.cells.max", type: "number", label: "Max Input Cells", min: 0 }
  ]
};
const REND_MANIFEST_SCHEMA = {
  title: "Renderer Manifest",
  fields: [
    { key: "id", type: "text", label: "ID", required: true },
    { key: "name", type: "text", label: "Display Name", required: true },
    { key: "version", type: "text", label: "Version", required: true, default: "0.1.0" },
    { key: "summary", type: "textarea", label: "Summary" },
    { key: "entrypoint", type: "text", label: "Entrypoint", required: true, default: "main.tsx" },
    { key: "embed", type: "dropdown", label: "Embed Mode", required: true, options: ["native", "iframe"], default: "native", description: "native = Shadow DOM, inline styles only. iframe = sandboxed, full CSS." },
    { key: "extensions", type: "list", label: "File Extensions", description: 'Extensions this renderer claims, e.g. ".md", ".set_yaml".' },
    { key: "supports_diff", type: "checkbox", label: "Supports Diff" }
  ]
};
function getPath(obj, path) {
  if (obj == null) return void 0;
  const parts = path.split(".");
  let cur = obj;
  for (const p of parts) {
    if (cur == null || typeof cur !== "object") return void 0;
    cur = cur[p];
  }
  return cur;
}
function setPath(obj, path, value) {
  const parts = path.split(".");
  let cur = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    const p = parts[i];
    if (cur[p] == null || typeof cur[p] !== "object") cur[p] = {};
    cur = cur[p];
  }
  cur[parts[parts.length - 1]] = value;
}
function deletePath(obj, path) {
  const parts = path.split(".");
  let cur = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    const p = parts[i];
    if (cur == null || typeof cur !== "object") return;
    cur = cur[p];
  }
  delete cur[parts[parts.length - 1]];
}
function modeFromFilename(filename) {
  const lower = (filename || "").toLowerCase();
  if (lower.endsWith(".gen_yaml")) return "gen";
  if (lower.endsWith(".rend_yaml")) return "rend";
  if (lower.endsWith(".set_yaml")) return "set";
  return null;
}
function loadYaml(text) {
  try {
    const parsed = jsyaml.load(text);
    return parsed == null ? {} : parsed;
  } catch {
    return {};
  }
}
function dumpYaml(obj) {
  return jsyaml.dump(obj, { lineWidth: 100, noRefs: true, sortKeys: false });
}
function valueToObjectText(v) {
  if (v == null) return "";
  return dumpYaml(v).trimEnd();
}
function buildInitialState(content, mode) {
  const parsed = loadYaml(content);
  if (mode === "set") {
    const rawFields = Array.isArray(parsed.fields) ? parsed.fields : [];
    const valuesBlock = parsed.values && typeof parsed.values === "object" ? parsed.values : {};
    const fields = rawFields.map(normalizeFieldDecl);
    const values2 = {};
    const objectText2 = {};
    for (const f of fields) {
      const present = Object.prototype.hasOwnProperty.call(valuesBlock, f.key);
      const v = present ? valuesBlock[f.key] : f.default;
      values2[f.key] = coerceValue(v, f);
      if (f.type === "object") objectText2[f.key] = valueToObjectText(v);
    }
    return {
      schema: { title: "Settings", fields },
      values: values2,
      rawObject: parsed,
      rawFields,
      objectText: objectText2
    };
  }
  const schema = mode === "gen" ? GEN_MANIFEST_SCHEMA : REND_MANIFEST_SCHEMA;
  const values = {};
  const objectText = {};
  for (const f of schema.fields) {
    const v = getPath(parsed, f.key);
    values[f.key] = coerceValue(v === void 0 ? f.default : v, f);
    if (f.type === "object") objectText[f.key] = valueToObjectText(v);
  }
  return {
    schema,
    values,
    rawObject: parsed,
    rawFields: [],
    objectText
  };
}
function normalizeOptions(opts) {
  return (opts || []).map((o) => {
    if (o != null && typeof o === "object" && !Array.isArray(o)) {
      const value = o.value == null ? "" : String(o.value);
      return {
        value,
        label: o.label == null ? value : String(o.label),
        description: o.description == null ? void 0 : String(o.description)
      };
    }
    const s = o == null ? "" : String(o);
    return { value: s, label: s };
  });
}
function normalizeFieldDecl(decl) {
  return {
    key: String(decl.key || ""),
    type: decl.type || "text",
    label: decl.label,
    description: decl.description,
    required: !!decl.required,
    default: decl.default,
    options: Array.isArray(decl.options) ? decl.options : void 0,
    secret: !!decl.secret,
    min: typeof decl.min === "number" ? decl.min : void 0,
    max: typeof decl.max === "number" ? decl.max : void 0
  };
}
function coerceValue(v, f) {
  switch (f.type) {
    case "checkbox":
      return v === true || v === "true" || v === 1;
    case "number":
      if (v === "" || v == null) return null;
      const n = typeof v === "number" ? v : Number(v);
      return Number.isFinite(n) ? n : null;
    case "list":
      if (Array.isArray(v)) return v.map((x) => x == null ? "" : String(x));
      if (v == null || v === "") return [];
      return [String(v)];
    case "object":
      return v == null ? null : v;
    case "text":
    case "textarea":
    case "dropdown":
    default:
      if (v == null) return "";
      return String(v);
  }
}
function validate(state) {
  const errors = {};
  for (const f of state.schema.fields) {
    const v = state.values[f.key];
    if (f.required) {
      const empty = v == null || typeof v === "string" && v.trim() === "" || Array.isArray(v) && v.length === 0;
      if (empty) {
        errors[f.key] = "Required";
        continue;
      }
    }
    if (f.type === "dropdown" && f.options && v) {
      const opts = normalizeOptions(f.options);
      if (!opts.some((o) => o.value === String(v))) {
        errors[f.key] = `Must be one of: ${opts.map((o) => o.value).join(", ")}`;
      }
    }
    if (f.type === "number" && v != null && v !== "") {
      if (typeof v !== "number" || !Number.isFinite(v)) {
        errors[f.key] = "Must be a number";
      } else {
        if (typeof f.min === "number" && v < f.min) errors[f.key] = `Must be \u2265 ${f.min}`;
        if (typeof f.max === "number" && v > f.max) errors[f.key] = `Must be \u2264 ${f.max}`;
      }
    }
    if (f.type === "object" && state.objectText[f.key]) {
      try {
        jsyaml.load(state.objectText[f.key]);
      } catch (e) {
        errors[f.key] = `Invalid YAML: ${e.message || e}`;
      }
    }
  }
  return errors;
}
function serialize(state, mode) {
  if (mode === "set") {
    const valuesBlock = {};
    for (const f of state.schema.fields) {
      let v = state.values[f.key];
      if (f.type === "object") {
        const text = state.objectText[f.key] || "";
        try {
          v = text.trim() === "" ? null : jsyaml.load(text);
        } catch {
          v = null;
        }
      }
      valuesBlock[f.key] = stripEmpty(v, f);
    }
    const out = {
      values: valuesBlock,
      fields: state.rawFields
    };
    return dumpYaml(out);
  }
  const copy = JSON.parse(JSON.stringify(state.rawObject || {}));
  for (const f of state.schema.fields) {
    let v = state.values[f.key];
    if (f.type === "object") {
      const text = state.objectText[f.key] || "";
      try {
        v = text.trim() === "" ? void 0 : jsyaml.load(text);
      } catch {
        v = void 0;
      }
    }
    if (isEmptyForOmission(v, f)) {
      deletePath(copy, f.key);
    } else {
      setPath(copy, f.key, v);
    }
  }
  return dumpYaml(copy);
}
function stripEmpty(v, f) {
  if (f.type === "number" && (v === null || v === "")) return null;
  if (f.type === "list" && Array.isArray(v)) return v.filter((x) => x !== "");
  return v;
}
function isEmptyForOmission(v, f) {
  if (f.required) return false;
  if (v == null) return true;
  if (typeof v === "string" && v === "") return true;
  if (Array.isArray(v) && v.length === 0) return true;
  if (f.type === "number" && (v === null || v === "")) return true;
  return false;
}
const C = {
  bg: "var(--renderer-surface, #1a1a1a)",
  panel: "var(--obsidian-plate, #1a1c23)",
  input: "var(--renderer-surface, #1a1a1a)",
  border: "var(--tungsten-dim, #2a2d3a)",
  borderLight: "var(--tungsten-dim, #3a3d52)",
  text: "var(--signal-white, #e2e8f0)",
  textDim: "var(--muted-foreground, #9ca3af)",
  textMuted: "var(--muted-foreground, #6b7280)",
  label: "var(--signal-white, #f9fafb)",
  accent: "var(--electric-teal, #60a5fa)",
  required: "var(--destructive, #f87171)",
  danger: "var(--destructive, #ef4444)",
  ok: "var(--primary, #34d399)"
};
const S = {
  page: { width: "100%", height: "100%", background: C.bg, color: C.text, fontFamily: "system-ui, -apple-system, sans-serif", fontSize: 13, overflow: "auto", boxSizing: "border-box" },
  header: { padding: "14px 20px 10px", borderBottom: `1px solid ${C.border}`, background: C.panel, position: "sticky", top: 0, zIndex: 2 },
  title: { fontSize: 14, fontWeight: 600, color: C.label, letterSpacing: 0.2 },
  subtitle: { fontSize: 11, color: C.textMuted, marginTop: 2, fontFamily: "monospace" },
  body: { padding: 16, maxWidth: 720, margin: "0 auto" },
  field: { marginBottom: 18 },
  labelRow: { display: "flex", alignItems: "baseline", gap: 6, marginBottom: 4 },
  label: { color: C.label, fontWeight: 500, fontSize: 12 },
  requiredMark: { color: C.required, fontWeight: 700, fontSize: 12 },
  desc: { color: C.textMuted, fontSize: 11, lineHeight: 1.5, marginBottom: 6 },
  input: { width: "100%", background: C.input, border: `1px solid ${C.border}`, borderRadius: 4, padding: "7px 10px", color: C.text, fontFamily: "monospace", fontSize: 12, outline: "none", boxSizing: "border-box" },
  textarea: { width: "100%", background: C.input, border: `1px solid ${C.border}`, borderRadius: 4, padding: "8px 10px", color: C.text, fontFamily: "monospace", fontSize: 12, outline: "none", resize: "vertical", minHeight: 60, boxSizing: "border-box" },
  select: { width: "100%", background: C.input, border: `1px solid ${C.border}`, borderRadius: 4, padding: "7px 10px", color: C.text, fontFamily: "monospace", fontSize: 12, outline: "none", boxSizing: "border-box" },
  // Merged over input/textarea/select when validate() flagged the field
  // (required-empty being the main case) so the offender is visible at
  // a glance, not just via the small message underneath.
  inputDanger: { border: `1px solid ${C.danger}`, background: `color-mix(in srgb, ${C.danger} 8%, ${C.input})` },
  error: { color: C.danger, fontSize: 11, marginTop: 4, fontFamily: "monospace" },
  listRow: { display: "flex", gap: 6, marginBottom: 4 },
  button: { background: "var(--muted, #2d2f3e)", border: `1px solid ${C.borderLight}`, borderRadius: "var(--radius-sm, 4px)", padding: "6px 10px", color: C.text, fontFamily: "var(--font-mono, monospace)", fontSize: 11, cursor: "pointer" },
  buttonDanger: { background: "color-mix(in srgb, var(--destructive) 20%, var(--void-main))", border: `1px solid color-mix(in srgb, var(--destructive) 40%, var(--tungsten-dim))`, borderRadius: "var(--radius-sm, 4px)", padding: "6px 10px", color: "var(--destructive, #fca5a5)", fontFamily: "var(--font-mono, monospace)", fontSize: 11, cursor: "pointer" },
  checkboxRow: { display: "flex", alignItems: "center", gap: 8 },
  checkbox: { width: 14, height: 14, accentColor: C.accent, cursor: "pointer" },
  badge: { display: "inline-block", padding: "2px 6px", borderRadius: 3, background: "var(--muted, #1f2937)", color: C.textDim, fontFamily: "var(--font-mono, monospace)", fontSize: 10 },
  // Warning banner keeps an amber-ish tint — color-mixed against the
  // filament accent so it picks up the theme's primary-ish hue
  // rather than forcing a fixed orange on light themes.
  banner: { padding: "8px 12px", background: "color-mix(in srgb, var(--filament-amber) 12%, var(--void-main))", border: `1px solid color-mix(in srgb, var(--filament-amber) 40%, var(--tungsten-dim))`, color: "var(--filament-amber, #fbbf24)", fontSize: 11, borderRadius: "var(--radius-sm, 4px)", marginBottom: 12, fontFamily: "var(--font-mono, monospace)" }
};
function FieldView({ field, value, objectText, error, readOnly, onChange, onObjectTextChange }) {
  return /* @__PURE__ */ React.createElement("div", { style: S.field }, /* @__PURE__ */ React.createElement("div", { style: S.labelRow }, /* @__PURE__ */ React.createElement("span", { style: S.label }, field.label || field.key), field.required && /* @__PURE__ */ React.createElement("span", { style: S.requiredMark, title: "Required" }, "*"), /* @__PURE__ */ React.createElement("span", { style: { marginLeft: "auto", ...S.badge } }, field.type)), field.description && /* @__PURE__ */ React.createElement("div", { style: S.desc }, field.description), renderInput(field, value, objectText, error, readOnly, onChange, onObjectTextChange), error && /* @__PURE__ */ React.createElement("div", { style: S.error }, error));
}
function renderInput(field, value, objectText, error, readOnly, onChange, onObjectTextChange) {
  const danger = error ? S.inputDanger : void 0;
  switch (field.type) {
    case "textarea":
      return /* @__PURE__ */ React.createElement(
        "textarea",
        {
          style: { ...S.textarea, ...danger },
          value: value ?? "",
          disabled: readOnly,
          onChange: (e) => onChange(e.target.value),
          spellCheck: false
        }
      );
    case "number":
      return /* @__PURE__ */ React.createElement(
        "input",
        {
          type: "number",
          style: { ...S.input, ...danger },
          value: value == null ? "" : value,
          disabled: readOnly,
          min: field.min,
          max: field.max,
          onChange: (e) => {
            const raw = e.target.value;
            if (raw === "") onChange(null);
            else {
              const n = Number(raw);
              onChange(Number.isFinite(n) ? n : null);
            }
          }
        }
      );
    case "checkbox":
      return /* @__PURE__ */ React.createElement("div", { style: S.checkboxRow }, /* @__PURE__ */ React.createElement(
        "input",
        {
          type: "checkbox",
          style: S.checkbox,
          checked: !!value,
          disabled: readOnly,
          onChange: (e) => onChange(e.target.checked)
        }
      ), /* @__PURE__ */ React.createElement("span", { style: { color: C.textDim, fontFamily: "monospace", fontSize: 11 } }, value ? "true" : "false"));
    case "dropdown":
      return /* @__PURE__ */ React.createElement(
        "select",
        {
          style: { ...S.select, ...danger },
          value: value ?? "",
          disabled: readOnly,
          onChange: (e) => onChange(e.target.value)
        },
        !field.required && /* @__PURE__ */ React.createElement("option", { value: "" }, "\u2014 none \u2014"),
        normalizeOptions(field.options).map((opt) => /* @__PURE__ */ React.createElement("option", { key: opt.value, value: opt.value, title: opt.description }, opt.label))
      );
    case "list":
      return /* @__PURE__ */ React.createElement(ListField, { value, readOnly, onChange });
    case "object":
      return /* @__PURE__ */ React.createElement(
        "textarea",
        {
          style: { ...S.textarea, minHeight: 100, ...danger },
          value: objectText ?? "",
          disabled: readOnly,
          onChange: (e) => onObjectTextChange && onObjectTextChange(e.target.value),
          spellCheck: false,
          placeholder: "# raw YAML"
        }
      );
    case "text":
    default:
      return /* @__PURE__ */ React.createElement(
        "input",
        {
          type: field.secret ? "password" : "text",
          style: { ...S.input, ...danger },
          value: value ?? "",
          disabled: readOnly,
          onChange: (e) => onChange(e.target.value),
          spellCheck: false,
          autoComplete: field.secret ? "off" : void 0
        }
      );
  }
}
function ListField({ value, readOnly, onChange }) {
  const items = Array.isArray(value) ? value : [];
  const update = (idx, v) => {
    const next = items.slice();
    next[idx] = v;
    onChange(next);
  };
  const remove = (idx) => {
    const next = items.slice();
    next.splice(idx, 1);
    onChange(next);
  };
  const add = () => onChange([...items, ""]);
  return /* @__PURE__ */ React.createElement("div", null, items.length === 0 && /* @__PURE__ */ React.createElement("div", { style: { color: C.textMuted, fontSize: 11, fontFamily: "monospace", marginBottom: 4 } }, "(empty)"), items.map((it, idx) => /* @__PURE__ */ React.createElement("div", { key: idx, style: S.listRow }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      style: { ...S.input, flex: 1 },
      value: it,
      disabled: readOnly,
      onChange: (e) => update(idx, e.target.value),
      spellCheck: false
    }
  ), !readOnly && /* @__PURE__ */ React.createElement("button", { type: "button", style: S.buttonDanger, onClick: () => remove(idx) }, "\xD7"))), !readOnly && /* @__PURE__ */ React.createElement("button", { type: "button", style: S.button, onClick: add }, "+ add"));
}
function SchemaForm() {
  const { content, saveContent, isReadOnly, api } = useCollimateFile();
  const filename = api.getFilename();
  const mode = modeFromFilename(filename);
  const initialContent = useRef(content);
  const [state, setState] = useState(() => {
    if (!mode) return null;
    return buildInitialState(content || "", mode);
  });
  useEffect(() => {
    if (!mode) return;
    if (initialContent.current === content) return;
    initialContent.current = content;
    setState(buildInitialState(content || "", mode));
  }, [filename]);
  useEffect(() => {
    if (!mode) return;
    if (initialContent.current === content) return;
    initialContent.current = content;
    setState(buildInitialState(content || "", mode));
  }, [content]);
  const saveRaw = useDebouncedSaveContent(saveContent, 350);
  useEffect(() => {
    if (!api.onFlush) return;
    return api.onFlush(() => {
      saveRaw.flush();
    });
  }, [api, saveRaw]);
  const scheduleSave = useCallback(
    (next) => {
      if (!mode) return;
      const yamlText = serialize(next, mode);
      initialContent.current = yamlText;
      saveRaw(yamlText);
    },
    [mode, saveRaw]
  );
  if (!mode) {
    return /* @__PURE__ */ React.createElement("div", { style: S.page }, /* @__PURE__ */ React.createElement("div", { style: S.body }, /* @__PURE__ */ React.createElement("div", { style: S.banner }, "Schema Form was opened on a file with an unrecognised extension: ", filename)));
  }
  if (!state) {
    return /* @__PURE__ */ React.createElement("div", { style: S.page }, /* @__PURE__ */ React.createElement("div", { style: S.body }, /* @__PURE__ */ React.createElement("div", { style: { color: C.textMuted, fontFamily: "monospace" } }, "Loading\u2026")));
  }
  const errors = validate(state);
  const errorCount = Object.keys(errors).length;
  const updateValue = (key, v) => {
    const next = {
      ...state,
      values: { ...state.values, [key]: v }
    };
    setState(next);
    scheduleSave(next);
  };
  const updateObjectText = (key, text) => {
    const next = {
      ...state,
      objectText: { ...state.objectText, [key]: text }
    };
    setState(next);
    scheduleSave(next);
  };
  const titleByMode = {
    gen: "Generator Manifest",
    rend: "Renderer Manifest",
    set: "Settings"
  };
  return /* @__PURE__ */ React.createElement("div", { style: S.page }, /* @__PURE__ */ React.createElement("div", { style: S.header }, /* @__PURE__ */ React.createElement("div", { style: S.title }, titleByMode[mode]), /* @__PURE__ */ React.createElement("div", { style: S.subtitle }, filename, errorCount > 0 && /* @__PURE__ */ React.createElement("span", { style: { color: C.danger, marginLeft: 12 } }, errorCount, " error", errorCount === 1 ? "" : "s"), isReadOnly && /* @__PURE__ */ React.createElement("span", { style: { color: C.textMuted, marginLeft: 12 } }, "read-only"))), /* @__PURE__ */ React.createElement("div", { style: S.body }, state.schema.fields.length === 0 && /* @__PURE__ */ React.createElement("div", { style: S.banner }, "This settings file has no ", /* @__PURE__ */ React.createElement("code", null, "fields:"), " block. The author should declare a list of fields with ", /* @__PURE__ */ React.createElement("code", null, "key"), ", ", /* @__PURE__ */ React.createElement("code", null, "type"), ", and (optionally) ", /* @__PURE__ */ React.createElement("code", null, "label"), ",", " ", /* @__PURE__ */ React.createElement("code", null, "default"), ", ", /* @__PURE__ */ React.createElement("code", null, "options"), ", etc."), state.schema.fields.map((f) => /* @__PURE__ */ React.createElement(
    FieldView,
    {
      key: f.key,
      field: f,
      value: state.values[f.key],
      objectText: state.objectText[f.key],
      error: errors[f.key],
      readOnly: isReadOnly,
      onChange: (v) => updateValue(f.key, v),
      onObjectTextChange: (t) => updateObjectText(f.key, t)
    }
  ))));
}
var main_default = defineRenderer({ component: SchemaForm });
export {
  main_default as default
};
