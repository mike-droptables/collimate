import React, { useState, useEffect, useMemo } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

function parseCsv(text, sep) {
  const rows = [];
  let i = 0, field = '', row = [], inQuotes = false;
  while (i < text.length) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i += 2; continue; }
        inQuotes = false; i++; continue;
      }
      field += c; i++; continue;
    }
    if (c === '"') { inQuotes = true; i++; continue; }
    if (c === sep) { row.push(field); field = ''; i++; continue; }
    if (c === '\n' || c === '\r') {
      row.push(field); rows.push(row); field = ''; row = [];
      if (c === '\r' && text[i + 1] === '\n') i += 2; else i++;
      continue;
    }
    field += c; i++;
  }
  if (field.length > 0 || row.length > 0) { row.push(field); rows.push(row); }
  return rows.filter((r) => !(r.length === 1 && r[0] === ''));
}

function scoreboardToTable(obj) {
  const rubric = Array.isArray(obj.rubric) ? obj.rubric : [];
  const headers = ['name', ...rubric, 'total', 'notes'];
  const rows = (obj.rows || []).map((r) => {
    const out = [String(r.name || '')];
    for (const k of rubric) {
      const v = r.scores && r.scores[k];
      out.push(v === undefined || v === null ? '' : String(v));
    }
    out.push(r.total === undefined ? '' : String(r.total));
    out.push(String(r.notes || ''));
    return out;
  });
  return { headers, rows, verdict: obj.verdict || '', winner: obj.winner || '' };
}

function looksNumeric(values) {
  let n = 0, total = 0;
  for (const v of values) {
    if (v === '' || v == null) continue;
    total++;
    if (!isNaN(Number(v))) n++;
  }
  return total > 0 && n / total > 0.7;
}

function TableView() {
  const { content, fileName } = useCollimateFile();
  const [sortCol, setSortCol] = useState(-1);
  const [sortDir, setSortDir] = useState(1);
  const [filter, setFilter] = useState('');

  const parsed = useMemo(() => {
    const name = (fileName || '').toLowerCase();
    if (name.endsWith('.scoreboard.json') || name.endsWith('.json')) {
      try {
        const obj = JSON.parse(content || '{}');
        if (obj && (obj.rubric || obj.rows)) return scoreboardToTable(obj);
      } catch (e) { /* fall through */ }
    }
    const sep = name.endsWith('.tsv') ? '\t' : ',';
    const rows = parseCsv(content || '', sep);
    if (rows.length === 0) return { headers: [], rows: [] };
    return { headers: rows[0], rows: rows.slice(1) };
  }, [content, fileName]);

  const numericCols = useMemo(() => {
    const out = new Set();
    parsed.headers && parsed.headers.forEach((_, ci) => {
      if (looksNumeric(parsed.rows.map((r) => r[ci]))) out.add(ci);
    });
    return out;
  }, [parsed]);

  const filteredRows = useMemo(() => {
    const needle = filter.trim().toLowerCase();
    if (!needle) return parsed.rows;
    return parsed.rows.filter((r) => r.some((cell) => String(cell ?? '').toLowerCase().includes(needle)));
  }, [parsed, filter]);

  const sortedRows = useMemo(() => {
    if (sortCol < 0) return filteredRows;
    const isNum = numericCols.has(sortCol);
    return [...filteredRows].sort((a, b) => {
      const av = a[sortCol] ?? '';
      const bv = b[sortCol] ?? '';
      if (isNum) return (Number(av) - Number(bv)) * sortDir;
      return String(av).localeCompare(String(bv)) * sortDir;
    });
  }, [filteredRows, sortCol, sortDir, numericCols]);

  function clickHeader(i) {
    if (sortCol === i) setSortDir((d) => -d);
    else { setSortCol(i); setSortDir(1); }
  }

  const wrap = { width: '100%', height: '100%', background: 'var(--renderer-surface, #1a1a1a)', color: 'var(--signal-white, #e2e8f0)', display: 'flex', flexDirection: 'column', overflow: 'hidden' };
  const th = {
    textAlign: 'left', padding: '8px 12px', background: 'var(--obsidian-plate, #11131a)',
    borderBottom: '1px solid var(--tungsten-dim, #2a2d3a)', fontSize: 12, fontWeight: 600,
    color: 'var(--muted-foreground, #9ca3af)', cursor: 'pointer', userSelect: 'none', whiteSpace: 'nowrap',
  };
  const td = { padding: '7px 12px', borderBottom: '1px solid var(--tungsten-dim, #1a1d27)', fontSize: 13, color: 'var(--signal-white, #d1d5db)' };
  // Zebra striping uses a color-mix against the panel so it reads on
  // either light or dark themes. Fallback is the previous hardcoded dark stripe.
  const zebraBg = 'color-mix(in srgb, var(--signal-white) 4%, transparent)';

  if (parsed.headers.length === 0) {
    return (
      <div style={{ ...wrap, alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ color: 'var(--muted-foreground, #9ca3af)', fontSize: 13 }}>
          No tabular data — expected CSV/TSV or scoreboard JSON
        </div>
      </div>
    );
  }

  return (
    <div style={wrap}>
      {parsed.verdict && (
        <div style={{ padding: '12px 16px', background: 'var(--obsidian-plate, #11131a)', borderBottom: '1px solid var(--tungsten-dim, #2a2d3a)' }}>
          {parsed.winner && (
            <div style={{ fontSize: 11, color: 'var(--comment-grey, #6b7280)', marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.5 }}>winner</div>
          )}
          {parsed.winner && (
            <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--signal-white, #f9fafb)', marginBottom: 6 }}>{parsed.winner}</div>
          )}
          <div style={{ fontSize: 13, color: 'var(--muted-foreground, #9ca3af)', lineHeight: 1.5 }}>{parsed.verdict}</div>
        </div>
      )}
      {parsed.rows.length > 0 && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '6px 12px', background: 'var(--obsidian-plate, #11131a)', borderBottom: '1px solid var(--tungsten-dim, #2a2d3a)' }}>
          <input
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="filter rows…"
            spellCheck={false}
            style={{ flex: '0 1 220px', background: 'transparent', color: 'var(--signal-white, #d1d5db)', border: '1px solid var(--tungsten-dim, #2a2d3a)', borderRadius: 4, padding: '4px 8px', fontSize: 12, outline: 'none' }}
          />
          <span style={{ fontSize: 11, color: 'var(--comment-grey, #6b7280)', whiteSpace: 'nowrap' }}>
            {filter.trim() ? `${filteredRows.length}/${parsed.rows.length} rows` : `${parsed.rows.length} rows`}
          </span>
        </div>
      )}
      <div style={{ flex: 1, overflow: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              {parsed.headers.map((h, i) => (
                <th key={i} style={th} onClick={() => clickHeader(i)}>
                  {String(h)}
                  {sortCol === i ? (sortDir > 0 ? ' ▲' : ' ▼') : ''}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sortedRows.map((row, ri) => (
              <tr key={ri} style={{ background: ri % 2 === 0 ? 'transparent' : zebraBg }}>
                {parsed.headers.map((_, ci) => (
                  <td key={ci} style={{ ...td, textAlign: numericCols.has(ci) ? 'right' : 'left', fontVariantNumeric: numericCols.has(ci) ? 'tabular-nums' : 'normal' }}>
                    {row[ci] ?? ''}
                  </td>
                ))}
              </tr>
            ))}
            {sortedRows.length === 0 && (
              <tr><td style={{ ...td, color: 'var(--comment-grey, #4b5563)' }} colSpan={parsed.headers.length || 1}>
                {filter.trim() ? `no rows match “${filter.trim()}”` : '(empty)'}
              </td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default defineRenderer({ component: TableView });
