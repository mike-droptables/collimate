import React, { useEffect, useMemo, useRef, useState } from 'https://esm.sh/react@18';
import { Terminal } from 'https://esm.sh/xterm@5.3.0';
import { FitAddon } from 'https://esm.sh/xterm-addon-fit@0.8.0';
import { WebLinksAddon } from 'https://esm.sh/xterm-addon-web-links@0.9.0';
import {
    defineRenderer,
    useCollimateFile,
    useTheme,
} from '/api/sdk/react.js';

type ButtonSpec = { id: string; label: string };

type Parsed = {
    session_id: string;
    ws_path: string;
    token: string;
    label: string;
    buttons: ButtonSpec[];
};

function parseContent(raw: string): Parsed | null {
    try {
        const j = JSON.parse(raw || '');
        if (typeof j.session_id !== 'string' || !j.session_id) return null;
        if (typeof j.ws_path !== 'string' || !j.ws_path) return null;
        const buttons: ButtonSpec[] = Array.isArray(j.buttons)
            ? j.buttons
                  .filter((b: any) => b && typeof b.id === 'string' && typeof b.label === 'string')
                  .map((b: any) => ({ id: b.id, label: b.label }))
            : [];
        return {
            session_id: j.session_id,
            ws_path: j.ws_path,
            token: typeof j.token === 'string' ? j.token : '',
            label: typeof j.label === 'string' ? j.label : 'terminal',
            buttons,
        };
    } catch {
        return null;
    }
}

function buildWsUrl(ws_path: string, token: string): string {
    const base = new URL(ws_path, window.location.origin);
    base.protocol = base.protocol === 'https:' ? 'wss:' : 'ws:';
    if (token) base.searchParams.set('token', token);
    return base.toString();
}

// Read xterm theme colors from the host's CSS vars, resolved against the
// current :root. Background is hard-pinned to solid black — a terminal
// is the one surface where TTY palettes (colored prompts, ANSI escape
// codes, syntax highlighting) are authored against a true-black
// background; swapping to the host's off-dark palette mutes contrast
// on high-saturation fore colors.
function buildXtermTheme(): Record<string, string> {
    if (typeof document === 'undefined') {
        return { background: '#000000', foreground: '#e2e8f0', cursor: '#7fcfa8' };
    }
    const cs = getComputedStyle(document.documentElement);
    const read = (name: string, fallback: string) => (cs.getPropertyValue(name).trim() || fallback);
    return {
        background: '#000000',
        foreground: read('--signal-white', '#e2e8f0'),
        cursor: read('--electric-teal', '#7fcfa8'),
        selectionBackground: read('--muted', '#2a2d3a'),
    };
}

// ---------------------------------------------------------------------------
// Module-level session cache — keeps xterm + WebSocket alive across
// component unmount/remount so tab switches, dive-deep, and zoom transitions
// don't lose scrollback or drop the connection.
//
// Key: session_id. Value: { term, ws, fit, container, status, status_listeners }.
// The ``container`` is the xterm DOM root — when the component unmounts we
// re-parent it into a hidden graveyard div in document.body so xterm's
// internal renderer keeps painting (it computes dimensions off
// `getBoundingClientRect`, which still resolves on a detached-from-host but
// in-DOM element). On remount we move it back into the new hostRef.
//
// Sessions self-evict when their WebSocket transitions to ``closed`` —
// no point keeping a dead terminal in memory across the rest of the
// page lifetime.
// ---------------------------------------------------------------------------

type CachedStatus = 'connecting' | 'open' | 'closed' | 'error';

type CachedSession = {
    sessionId: string;
    term: Terminal;
    fit: FitAddon;
    ws: WebSocket;
    container: HTMLDivElement;
    lastCols: number;
    lastRows: number;
    status: CachedStatus;
    statusListeners: Set<(s: CachedStatus) => void>;
    disposeOnData: { dispose: () => void };
    unsubTheme: (() => void) | null;
};

const SESSION_CACHE: Map<string, CachedSession> = new Map();

function getGraveyard(): HTMLDivElement {
    const ID = '__collimate_terminal_graveyard__';
    let el = document.getElementById(ID) as HTMLDivElement | null;
    if (el) return el;
    el = document.createElement('div');
    el.id = ID;
    // Off-screen but in-DOM so xterm's renderer keeps a valid layout
    // and we don't lose its measured cell dimensions.
    el.style.position = 'fixed';
    el.style.left = '-99999px';
    el.style.top = '0';
    el.style.width = '1px';
    el.style.height = '1px';
    el.style.overflow = 'hidden';
    el.style.pointerEvents = 'none';
    document.body.appendChild(el);
    return el;
}

function notifyStatus(session: CachedSession) {
    for (const cb of Array.from(session.statusListeners)) {
        try { cb(session.status); } catch { /* listener disposed */ }
    }
}

function buildSession(parsed: Parsed): CachedSession {
    const container = document.createElement('div');
    container.style.width = '100%';
    container.style.height = '100%';
    container.style.background = '#000000';

    const term = new Terminal({
        cursorBlink: true,
        fontFamily: getComputedStyle(document.documentElement).getPropertyValue('--font-mono').trim()
            || 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
        fontSize: 13,
        theme: buildXtermTheme(),
        convertEol: false,
        scrollback: 5000,
        allowProposedApi: true,
    });
    const fit = new FitAddon();
    term.loadAddon(fit);
    term.loadAddon(new WebLinksAddon());

    // Stash the container in the graveyard so xterm has a parent
    // when we call open(). We'll move it into the live hostRef
    // on mount.
    getGraveyard().appendChild(container);
    term.open(container);

    const url = buildWsUrl(parsed.ws_path, parsed.token);
    const ws = new WebSocket(url);
    ws.binaryType = 'arraybuffer';
    const encoder = new TextEncoder();

    const session: CachedSession = {
        sessionId: parsed.session_id,
        term,
        fit,
        ws,
        container,
        lastCols: 0,
        lastRows: 0,
        status: 'connecting',
        statusListeners: new Set(),
        disposeOnData: { dispose: () => {} },
        unsubTheme: null,
    };

    const sendResize = () => {
        try { fit.fit(); } catch { return; }
        const cols = term.cols;
        const rows = term.rows;
        if (cols === session.lastCols && rows === session.lastRows) return;
        session.lastCols = cols;
        session.lastRows = rows;
        if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ t: 'resize', cols, rows }));
        }
    };

    ws.onopen = () => {
        session.status = 'open';
        notifyStatus(session);
        sendResize();
        try { term.focus(); } catch {}
    };

    ws.onmessage = (ev) => {
        if (ev.data instanceof ArrayBuffer) {
            term.write(new Uint8Array(ev.data));
        } else if (typeof ev.data === 'string') {
            term.write(ev.data);
        }
    };

    ws.onclose = () => {
        session.status = 'closed';
        notifyStatus(session);
        term.write('\r\n\x1b[33m[connection closed]\x1b[0m\r\n');
        // Self-evict the cache once the connection is dead — the
        // session is gone server-side too, no value in keeping the
        // rendered scrollback for a session the user can never
        // reconnect to.
        SESSION_CACHE.delete(session.sessionId);
    };

    ws.onerror = () => {
        session.status = 'error';
        notifyStatus(session);
    };

    session.disposeOnData = term.onData((d: string) => {
        if (ws.readyState === WebSocket.OPEN) {
            ws.send(encoder.encode(d));
        }
    });

    SESSION_CACHE.set(parsed.session_id, session);
    return session;
}

function disposeSession(sessionId: string) {
    const session = SESSION_CACHE.get(sessionId);
    if (!session) return;
    SESSION_CACHE.delete(sessionId);
    try { session.disposeOnData.dispose(); } catch {}
    if (session.unsubTheme) { try { session.unsubTheme(); } catch {} }
    try { session.ws.close(); } catch {}
    try { session.term.dispose(); } catch {}
    try { session.container.remove(); } catch {}
}

function TerminalViewer() {
    const { content, api } = useCollimateFile();
    const { onChange: onThemeChange } = useTheme(api);
    const parsed = useMemo<Parsed | null>(() => parseContent(content), [content]);
    const hostRef = useRef<HTMLDivElement | null>(null);
    const [status, setStatus] = useState<CachedStatus | 'idle'>('idle');
    const [attempt, setAttempt] = useState(0);
    const [pendingAction, setPendingAction] = useState<string | null>(null);
    const [actionStatus, setActionStatus] = useState<string>('');

    const clickAction = async (id: string, label: string) => {
        if (pendingAction) return;
        setPendingAction(id);
        setActionStatus('');
        const ok = typeof api.emitAction === 'function' ? await api.emitAction(id) : false;
        setActionStatus(ok ? `${label} sent` : `${label} failed`);
        setPendingAction(null);
        setTimeout(() => setActionStatus(''), 2500);
    };

    useEffect(() => {
        if (!parsed || !hostRef.current) return;
        api.loadCSS('https://esm.sh/xterm@5.3.0/css/xterm.css');

        // Reconnect button (Reconnect: bumps `attempt`) lets the user
        // explicitly recreate after a closed/errored socket. Kill the
        // cached session on a manual retry so buildSession reconstructs
        // a fresh WebSocket; the React effect cleanup below will then
        // re-attach the new session's container.
        if (attempt > 0) {
            disposeSession(parsed.session_id);
        }

        let session = SESSION_CACHE.get(parsed.session_id);
        if (!session) {
            session = buildSession(parsed);
        }

        // Move the cached container into our host. document.adoptNode
        // isn't needed — appendChild on an in-DOM element relocates it
        // and preserves all internal state (event listeners, refs).
        // xterm's renderer recomputes layout via ResizeObserver below.
        const host = hostRef.current;
        host.appendChild(session.container);

        // Status subscription. Surface the cached session's current
        // status immediately on mount so we don't show 'idle' for the
        // brief window before the first state change after remount.
        setStatus(session.status);
        const statusCb = (s: CachedStatus) => setStatus(s);
        session.statusListeners.add(statusCb);

        // Theme hot-swap is per-mount (each component mount has its
        // own `onThemeChange` subscription), but we route the new
        // listener through the cached session so the most recent
        // mount's subscriber wins. Replace any prior listener.
        if (session.unsubTheme) {
            try { session.unsubTheme(); } catch {}
        }
        session.unsubTheme = onThemeChange(() => {
            try { session!.term.options.theme = buildXtermTheme(); } catch {}
        });

        // Width/height fit. fit.fit() reads getBoundingClientRect off
        // the xterm container — wait one rAF after attach so the
        // layout has resolved against the real cell width before
        // measuring. Without the rAF the first fit can underflow when
        // the cell is being mounted from a zoom transition (parent
        // width is still 0 at attach time).
        const fitOnce = () => {
            try { session!.fit.fit(); } catch {}
            const cols = session!.term.cols;
            const rows = session!.term.rows;
            if (cols !== session!.lastCols || rows !== session!.lastRows) {
                session!.lastCols = cols;
                session!.lastRows = rows;
                if (session!.ws.readyState === WebSocket.OPEN) {
                    session!.ws.send(JSON.stringify({ t: 'resize', cols, rows }));
                }
            }
        };
        const rafFit = requestAnimationFrame(fitOnce);

        const ro = new ResizeObserver(() => fitOnce());
        ro.observe(host);

        // Focus the terminal so keypresses land directly without an
        // explicit click — matches the prior behavior. Skip if the
        // socket isn't yet open (we'll focus from the onopen handler
        // in the build path on first connect).
        if (session.status === 'open') {
            try { session.term.focus(); } catch {}
        }

        return () => {
            cancelAnimationFrame(rafFit);
            ro.disconnect();
            session!.statusListeners.delete(statusCb);
            // DO NOT dispose the term/ws here — the whole point of
            // the cache is that the next mount re-attaches. Just
            // park the container in the graveyard so xterm keeps a
            // valid in-DOM parent (its renderer wants a layout-able
            // ancestor for cell-size measurement; an unparented div
            // returns 0×0 from getBoundingClientRect and the next
            // remount's fit.fit() would compute zero cols).
            try { getGraveyard().appendChild(session!.container); } catch {}
        };
    // attempt → forces effect re-run on Reconnect click
    }, [parsed?.session_id, parsed?.token, parsed?.ws_path, attempt]);

    if (!parsed) {
        return (
            <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#000000', color: 'var(--muted-foreground, #6b7280)', fontFamily: 'var(--font-mono, monospace)', fontSize: 12, padding: 16, textAlign: 'center' }}>
                Invalid .terminal file — expected JSON with {`{ session_id, ws_path, token }`}.
            </div>
        );
    }

    // Status pill colors pull semantic tokens where they fit and fall
    // back to fixed hexes for warn/error that don't map cleanly.
    const statusColor =
        status === 'open' ? 'var(--electric-teal, #7fcfa8)' :
        status === 'connecting' ? 'var(--filament-amber, #d4a94f)' :
        status === 'error' ? 'var(--destructive, #e06c75)' :
        'var(--muted-foreground, #6b7280)';

    return (
        <div style={{
            width: '100%',
            height: '100%',
            display: 'flex',
            flexDirection: 'column',
            background: '#000000',
            // Box-sizing: border-box so the host's reported width is the
            // outer width — matters for cell-width fitting; without it
            // any padding/border on a parent would push the terminal
            // wider than the cell.
            boxSizing: 'border-box',
            // Hard-cap to the parent's width. The cell can ask the
            // renderer for an exact pixel size; this prevents the
            // xterm canvas from extending past the cell on a wider-than-
            // expected font fallback.
            minWidth: 0,
            overflow: 'hidden',
        }}>
            <div style={{ height: 24, background: 'var(--obsidian-plate, #1a1c23)', borderBottom: '1px solid var(--tungsten-dim, #2a2d3a)', display: 'flex', alignItems: 'center', padding: '0 8px', gap: 8, flexShrink: 0, fontFamily: 'var(--font-mono, monospace)', fontSize: 11 }}>
                <span style={{ color: 'var(--muted-foreground, #9ca3af)' }}>{parsed.label}</span>
                <span style={{ color: statusColor }}>● {status}</span>
                {actionStatus && (
                    <span style={{ color: 'var(--electric-teal, #7fcfa8)' }}>{actionStatus}</span>
                )}
                <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6 }}>
                    {parsed.buttons.map(b => {
                        const busy = pendingAction === b.id;
                        // Tinted-green CTA background mirrors the .website
                        // renderer's action buttons — color-mix keeps it
                        // readable under light themes too.
                        const ctaBg = busy
                            ? 'var(--muted, #3a3d52)'
                            : 'color-mix(in srgb, #10b981 35%, var(--void-main))';
                        return (
                            <button
                                key={b.id}
                                onClick={() => clickAction(b.id, b.label)}
                                disabled={busy || !!pendingAction}
                                style={{ height: 18, padding: '0 8px', background: ctaBg, border: '1px solid color-mix(in srgb, #10b981 60%, var(--tungsten-dim))', borderRadius: 'var(--radius-sm, 3px)', color: 'var(--signal-white, #d6f5e4)', fontFamily: 'var(--font-mono, monospace)', fontSize: 10, cursor: busy ? 'wait' : 'pointer', opacity: pendingAction && !busy ? 0.6 : 1 }}
                            >
                                {busy ? '…' : b.label}
                            </button>
                        );
                    })}
                    {(status === 'closed' || status === 'error') && (
                        <button
                            onClick={() => setAttempt(a => a + 1)}
                            style={{ height: 18, padding: '0 8px', background: 'var(--muted, #2d2f3e)', border: '1px solid var(--tungsten-dim, #3a3d52)', borderRadius: 'var(--radius-sm, 3px)', color: 'var(--signal-white, #e2e8f0)', fontFamily: 'var(--font-mono, monospace)', fontSize: 10, cursor: 'pointer' }}
                        >
                            Reconnect
                        </button>
                    )}
                </div>
            </div>
            <div
                ref={hostRef}
                style={{
                    flex: 1,
                    // No padding here — xterm wants the full container
                    // box for accurate cell-size measurement, and the
                    // padding was eating ~1 column off the right side
                    // at narrow cell widths.
                    overflow: 'hidden',
                    minWidth: 0,
                    minHeight: 0,
                }}
            />
        </div>
    );
}

export default defineRenderer({ component: TerminalViewer });
