import React, { useState, useEffect, useRef, useCallback } from "https://esm.sh/react@18";
import { defineRenderer, useCollimateFile, useDebouncedSaveContent } from "/api/sdk/react.js";
const FORMAT = "collimate.axes-frame";
const ACCEPT_ACTION = "axes:accept";
const text = { color: "var(--signal-white, #d1d5db)" };
const dim = { color: "var(--muted-foreground, #9ca3af)" };
const faint = { color: "var(--comment-grey, #6b7280)" };
const border = "1px solid var(--tungsten-dim, #2a2d3a)";
const AMBER = "#f59e0b";
const SOURCE_META = {
  both: { label: "both passes", color: "#22c55e" },
  pass_a: { label: "pass A only", color: "#60a5fa" },
  pass_b: { label: "pass B only", color: "#a78bfa" },
  user: { label: "you", color: "#f472b6" }
};
function serialize(doc) {
  return JSON.stringify(doc, null, 2) + "\n";
}
function normalized(s) {
  try {
    return JSON.stringify(JSON.parse(s));
  } catch (e) {
    return null;
  }
}
function Chip({ label, color, title }) {
  return /* @__PURE__ */ React.createElement("span", { title: title || "", style: {
    display: "inline-block",
    padding: "1px 7px",
    borderRadius: 9,
    fontSize: 10,
    fontWeight: 600,
    letterSpacing: 0.4,
    whiteSpace: "nowrap",
    color,
    border: `1px solid ${color}`
  } }, label);
}
function WeightStepper({ value, editable, onChange }) {
  const btn = (delta, glyph) => /* @__PURE__ */ React.createElement(
    "button",
    {
      disabled: !editable,
      onClick: () => onChange(Math.max(0, Math.min(5, (value || 0) + delta))),
      style: {
        width: 20,
        height: 20,
        lineHeight: "16px",
        padding: 0,
        borderRadius: 4,
        background: "transparent",
        ...dim,
        border,
        cursor: editable ? "pointer" : "default",
        opacity: editable ? 1 : 0.4,
        fontSize: 12
      }
    },
    glyph
  );
  return /* @__PURE__ */ React.createElement("span", { style: { display: "inline-flex", gap: 4, alignItems: "center" } }, btn(-1, "\u2212"), /* @__PURE__ */ React.createElement("span", { title: `weight ${value}/5`, style: { ...text, fontSize: 12, fontVariantNumeric: "tabular-nums", letterSpacing: 1 } }, "\u25CF".repeat(value || 0), "\u25CB".repeat(Math.max(0, 5 - (value || 0)))), btn(1, "+"));
}
function AxisRow({ axis, editable, onPatch }) {
  const [confirmStrike, setConfirmStrike] = useState(false);
  const struck = !!axis.struck;
  const src = SOURCE_META[axis.source] || { label: axis.source || "?", color: "#6b7280" };
  const strike = () => {
    if (axis.standing && !struck && !confirmStrike) {
      setConfirmStrike(true);
      return;
    }
    setConfirmStrike(false);
    onPatch(axis.id, { struck: !struck }, true);
  };
  const inputStyle = {
    background: "transparent",
    border: "none",
    outline: "none",
    width: "100%",
    fontFamily: "inherit",
    padding: 0
  };
  return /* @__PURE__ */ React.createElement("div", { style: {
    padding: "10px 16px",
    borderBottom: border,
    opacity: struck ? 0.45 : 1,
    background: axis.standing ? "color-mix(in srgb, var(--signal-white) 3%, transparent)" : "transparent"
  } }, /* @__PURE__ */ React.createElement("div", { style: { display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" } }, editable ? /* @__PURE__ */ React.createElement(
    "input",
    {
      key: `${axis.id}-name`,
      defaultValue: axis.name,
      disabled: !editable,
      spellCheck: false,
      onChange: (e) => onPatch(axis.id, { name: e.target.value }, false),
      style: {
        ...inputStyle,
        ...text,
        fontSize: 13,
        fontWeight: 600,
        flex: "1 1 200px",
        textDecoration: struck ? "line-through" : "none"
      }
    }
  ) : /* @__PURE__ */ React.createElement("span", { style: { ...text, fontSize: 13, fontWeight: 600, flex: "1 1 200px", textDecoration: struck ? "line-through" : "none" } }, axis.name), axis.standing ? /* @__PURE__ */ React.createElement(Chip, { label: "standing check", color: AMBER, title: "Every candidate must answer this; striking it accepts the frame unexamined." }) : /* @__PURE__ */ React.createElement(Chip, { label: src.label, color: src.color }), /* @__PURE__ */ React.createElement(
    WeightStepper,
    {
      value: axis.weight,
      editable: editable && !struck,
      onChange: (w) => onPatch(axis.id, { weight: w }, true)
    }
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      disabled: !editable,
      onClick: strike,
      style: {
        padding: "2px 9px",
        fontSize: 11,
        borderRadius: 4,
        border,
        background: "transparent",
        color: struck ? "#22c55e" : "#ef4444",
        cursor: editable ? "pointer" : "default",
        opacity: editable ? 1 : 0.4,
        fontWeight: 600
      }
    },
    struck ? "restore" : confirmStrike ? "strike the framing check?" : "strike"
  )), editable ? /* @__PURE__ */ React.createElement(
    "textarea",
    {
      key: `${axis.id}-desc`,
      defaultValue: axis.description,
      disabled: !editable,
      spellCheck: false,
      rows: 1,
      onChange: (e) => onPatch(axis.id, { description: e.target.value }, false),
      style: { ...inputStyle, ...dim, fontSize: 12, marginTop: 4, resize: "vertical", lineHeight: 1.5 }
    }
  ) : /* @__PURE__ */ React.createElement("div", { style: { ...dim, fontSize: 12, marginTop: 4, lineHeight: 1.5 } }, axis.description), axis.disagreement && /* @__PURE__ */ React.createElement("details", { style: { marginTop: 6 } }, /* @__PURE__ */ React.createElement("summary", { style: { cursor: "pointer", fontSize: 11, color: AMBER, fontWeight: 600 } }, "\u26A0 CONTESTED FRAME \u2014 the two passes framed this differently"), /* @__PURE__ */ React.createElement("div", { style: {
    margin: "4px 0 0",
    padding: "6px 10px",
    borderLeft: `3px solid ${AMBER}`,
    background: "color-mix(in srgb, #f59e0b 8%, transparent)",
    fontSize: 12,
    ...dim,
    lineHeight: 1.5
  } }, axis.disagreement)), editable && /* @__PURE__ */ React.createElement(
    "input",
    {
      key: `${axis.id}-note`,
      defaultValue: axis.user_note || "",
      placeholder: "note\u2026",
      spellCheck: false,
      onChange: (e) => onPatch(axis.id, { user_note: e.target.value }, false),
      style: { ...inputStyle, ...faint, fontSize: 11, marginTop: 4, fontStyle: "italic" }
    }
  ), !editable && axis.user_note && /* @__PURE__ */ React.createElement("div", { style: { ...faint, fontSize: 11, marginTop: 4, fontStyle: "italic" } }, "\u{1F4DD} ", axis.user_note));
}
function AddAxisRow({ onAdd }) {
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const add = () => {
    if (!name.trim()) return;
    onAdd(name.trim(), desc.trim());
    setName("");
    setDesc("");
  };
  const inp = {
    background: "transparent",
    ...text,
    border,
    borderRadius: 4,
    padding: "4px 8px",
    fontSize: 12,
    outline: "none",
    fontFamily: "inherit"
  };
  return /* @__PURE__ */ React.createElement("div", { style: { padding: "10px 16px", borderBottom: border, display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" } }, /* @__PURE__ */ React.createElement(
    "input",
    {
      value: name,
      onChange: (e) => setName(e.target.value),
      placeholder: "missing axis\u2026",
      spellCheck: false,
      style: { ...inp, flex: "0 1 180px" },
      onKeyDown: (e) => {
        if (e.key === "Enter") add();
      }
    }
  ), /* @__PURE__ */ React.createElement(
    "input",
    {
      value: desc,
      onChange: (e) => setDesc(e.target.value),
      placeholder: "what it trades off\u2026",
      spellCheck: false,
      style: { ...inp, flex: "1 1 240px" },
      onKeyDown: (e) => {
        if (e.key === "Enter") add();
      }
    }
  ), /* @__PURE__ */ React.createElement("button", { onClick: add, disabled: !name.trim(), style: {
    padding: "3px 12px",
    fontSize: 11,
    borderRadius: 4,
    border,
    fontWeight: 600,
    background: "transparent",
    color: name.trim() ? "#f472b6" : "var(--comment-grey, #6b7280)",
    cursor: name.trim() ? "pointer" : "default"
  } }, "+ add axis"));
}
function AxesView() {
  const { content, saveContent, isReadOnly, api } = useCollimateFile();
  const [doc, setDoc] = useState(null);
  const [parseFailed, setParseFailed] = useState(false);
  const [accepting, setAccepting] = useState(false);
  const sentRef = useRef(null);
  useEffect(() => {
    let parsed = null;
    try {
      parsed = JSON.parse(content || "");
    } catch (e) {
      parsed = null;
    }
    if (!parsed || parsed.format !== FORMAT) {
      setDoc(null);
      setParseFailed(true);
      return;
    }
    setParseFailed(false);
    if (sentRef.current && normalized(content) === normalized(sentRef.current)) return;
    setDoc(parsed);
  }, [content]);
  const save = useDebouncedSaveContent(saveContent, 350);
  useEffect(() => {
    if (api && typeof api.onFlush === "function") return api.onFlush(() => save.flush());
  }, [api, save]);
  const persist = useCallback((next, immediate) => {
    setDoc(next);
    const json = serialize(next);
    sentRef.current = json;
    if (immediate) {
      save.flush();
      saveContent(json);
    } else save(json);
  }, [save, saveContent]);
  const editable = !isReadOnly && doc && doc.status === "proposed";
  const onPatch = useCallback((id, patch, immediate) => {
    setDoc((cur) => {
      if (!cur) return cur;
      const next = { ...cur, axes: (cur.axes || []).map((a) => a.id === id ? { ...a, ...patch } : a) };
      const json = serialize(next);
      sentRef.current = json;
      if (immediate) {
        save.flush();
        saveContent(json);
      } else save(json);
      return next;
    });
  }, [save, saveContent]);
  const onAdd = useCallback((name, description) => {
    setDoc((cur) => {
      if (!cur) return cur;
      const axes2 = [...cur.axes || []];
      const at = axes2.findIndex((a) => a.standing);
      const row = {
        id: `ax-user-${Date.now()}`,
        name,
        description,
        weight: 3,
        source: "user",
        disagreement: null,
        standing: false,
        struck: false,
        user_note: ""
      };
      if (at >= 0) axes2.splice(at, 0, row);
      else axes2.push(row);
      const next = { ...cur, axes: axes2 };
      const json = serialize(next);
      sentRef.current = json;
      save.flush();
      saveContent(json);
      return next;
    });
  }, [save, saveContent]);
  const onContinue = useCallback(async () => {
    if (!doc || accepting) return;
    setAccepting(true);
    try {
      const next = { ...doc, status: "accepted", accepted_at: (/* @__PURE__ */ new Date()).toISOString() };
      persist(next, true);
      if (api && typeof api.emitAction === "function") await api.emitAction(ACCEPT_ACTION);
    } finally {
      setAccepting(false);
    }
  }, [doc, accepting, persist, api]);
  if (parseFailed || !doc) {
    return /* @__PURE__ */ React.createElement("div", { style: { width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", background: "var(--renderer-surface, #1a1a1a)" } }, /* @__PURE__ */ React.createElement("div", { style: { ...dim, fontSize: 13 } }, "Not a trade-off frame \u2014 expected ", FORMAT, " JSON"));
  }
  const axes = doc.axes || [];
  const ordered = [...axes.filter((a) => a.standing), ...axes.filter((a) => !a.standing)];
  const accepted = doc.status === "accepted";
  const contested = axes.filter((a) => a.disagreement).length;
  const struck = axes.filter((a) => a.struck).length;
  return /* @__PURE__ */ React.createElement("div", { style: { width: "100%", height: "100%", background: "var(--renderer-surface, #1a1a1a)", display: "flex", flexDirection: "column", overflow: "hidden" } }, /* @__PURE__ */ React.createElement("div", { style: { padding: "10px 16px", background: "var(--obsidian-plate, #11131a)", borderBottom: border } }, /* @__PURE__ */ React.createElement("div", { style: { display: "flex", gap: 12, alignItems: "baseline", flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("span", { style: { ...text, fontSize: 14, fontWeight: 600 } }, "Trade-off frame"), /* @__PURE__ */ React.createElement(Chip, { label: accepted ? "accepted \u2713" : "proposed \u2014 under review", color: accepted ? "#22c55e" : AMBER }), /* @__PURE__ */ React.createElement("span", { style: { ...dim, fontSize: 12 } }, axes.length, " axes"), contested > 0 && /* @__PURE__ */ React.createElement("span", { style: { color: AMBER, fontSize: 12 } }, contested, " contested"), struck > 0 && /* @__PURE__ */ React.createElement("span", { style: { ...faint, fontSize: 12 } }, struck, " struck")), doc.problem && /* @__PURE__ */ React.createElement("div", { style: { ...dim, fontSize: 12, marginTop: 6, lineHeight: 1.5 } }, doc.problem), !accepted && !isReadOnly && /* @__PURE__ */ React.createElement("div", { style: { ...faint, fontSize: 11, marginTop: 6 } }, "Strike what doesn't matter here, add what's missing, reweight \u2014 then Continue. The generator is paused on this frame.")), /* @__PURE__ */ React.createElement("div", { style: { flex: 1, overflow: "auto" } }, ordered.map((a) => /* @__PURE__ */ React.createElement(AxisRow, { key: a.id, axis: a, editable, onPatch })), editable && /* @__PURE__ */ React.createElement(AddAxisRow, { onAdd })), editable && /* @__PURE__ */ React.createElement("div", { style: { padding: "10px 16px", background: "var(--obsidian-plate, #11131a)", borderTop: border, display: "flex", gap: 12, alignItems: "center" } }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: onContinue,
      disabled: accepting,
      style: {
        padding: "6px 18px",
        fontSize: 13,
        fontWeight: 600,
        borderRadius: 5,
        background: "#22c55e",
        color: "#0b0e14",
        border: "none",
        cursor: accepting ? "default" : "pointer",
        opacity: accepting ? 0.6 : 1
      }
    },
    accepting ? "continuing\u2026" : "Continue with this frame"
  ), /* @__PURE__ */ React.createElement("span", { style: { ...faint, fontSize: 11 } }, "accepts the frame and starts one candidate worker per kept axis")), accepted && /* @__PURE__ */ React.createElement("div", { style: { padding: "8px 16px", background: "var(--obsidian-plate, #11131a)", borderTop: border, ...faint, fontSize: 11 } }, "Accepted ", doc.accepted_at ? new Date(doc.accepted_at).toLocaleString() : "", " \u2014 this frame is part of the decision record."));
}
var main_default = defineRenderer({ component: AxesView });
export {
  main_default as default
};
