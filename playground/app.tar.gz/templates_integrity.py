"""Integrity checks for the materialized SDK copies under api/templates/.

The build script vendors generators + renderers from collimate-sdk into
api/templates/ and writes a SHA-256 manifest at .checksum.json. At boot
the server verifies the manifest so a drift between the SDK source of
truth and the materialized copy surfaces early instead of after a user
hits a stale generator.

Two ways drift happens:

  1. An engineer edits a file directly under api/templates/ thinking
     it's a regular source dir. The next build clobbers their edit;
     this catches it before that.
  2. Distribution corruption — a copy operation truncated a file, a
     filesystem flip, etc. Cheap to verify; useful to know.

The manifest is best-effort: a missing manifest (during local dev with
no build) skips the check entirely. A present manifest with mismatches
gets surfaced via ``/ready`` so an operator can act on it.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
from typing import Iterator

logger = logging.getLogger(__name__)

CHECKSUM_FILENAME = ".checksum.json"


def _iter_files(root: str) -> Iterator[str]:
    """Yield every regular file under root, sorted, paths relative to root.

    Skips the manifest itself + dotfiles like .pytest_cache that aren't
    part of the SDK contract.
    """
    for dirpath, dirnames, filenames in os.walk(root):
        # Don't descend into noise dirs the build never produces.
        dirnames[:] = sorted(d for d in dirnames if not d.startswith("__pycache__"))
        for fname in sorted(filenames):
            if fname == CHECKSUM_FILENAME:
                continue
            full = os.path.join(dirpath, fname)
            yield os.path.relpath(full, root)


def _hash_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def write_manifest(root: str) -> str:
    """Walk ``root`` and write a SHA-256 manifest to ``<root>/.checksum.json``.

    Returns the absolute path of the manifest written. Intended to be
    called from the build script after it materializes api/templates/.
    """
    entries: dict[str, str] = {}
    for rel in _iter_files(root):
        full = os.path.join(root, rel)
        entries[rel] = _hash_file(full)
    manifest_path = os.path.join(root, CHECKSUM_FILENAME)
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump({"version": 1, "files": entries}, f, indent=2, sort_keys=True)
    return manifest_path


def verify_manifest(root: str) -> dict:
    """Verify materialized files under ``root`` match ``.checksum.json``.

    Returns a status dict::

        {
          "status": "ok" | "drift" | "no_manifest",
          "checked": <int>,           # files compared
          "mismatched": [<rel>, ...], # files whose hash differs
          "missing": [<rel>, ...],    # in manifest but not on disk
          "extra": [<rel>, ...],      # on disk but not in manifest
        }

    Best-effort: returns ``status="no_manifest"`` cleanly when the
    manifest is absent (local dev, fresh checkout). Callers decide what
    severity to attach to drift.
    """
    manifest_path = os.path.join(root, CHECKSUM_FILENAME)
    if not os.path.isfile(manifest_path):
        return {
            "status": "no_manifest",
            "checked": 0,
            "mismatched": [],
            "missing": [],
            "extra": [],
        }

    try:
        with open(manifest_path, "r", encoding="utf-8") as f:
            manifest = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        logger.warning("templates manifest unreadable: %s", exc)
        return {
            "status": "no_manifest",
            "checked": 0,
            "mismatched": [],
            "missing": [],
            "extra": [],
        }

    expected: dict[str, str] = manifest.get("files") or {}
    on_disk = {rel for rel in _iter_files(root)}
    expected_set = set(expected.keys())

    mismatched: list[str] = []
    missing: list[str] = []
    for rel, want in expected.items():
        full = os.path.join(root, rel)
        if not os.path.isfile(full):
            missing.append(rel)
            continue
        try:
            got = _hash_file(full)
        except OSError as exc:
            logger.warning("could not hash %s: %s", full, exc)
            mismatched.append(rel)
            continue
        if got != want:
            mismatched.append(rel)

    extra = sorted(on_disk - expected_set)

    status = "ok" if (not mismatched and not missing and not extra) else "drift"
    return {
        "status": status,
        "checked": len(expected),
        "mismatched": sorted(mismatched),
        "missing": sorted(missing),
        "extra": extra,
    }
