"""User-level settings (`.colsettings.json`).

Stores user-chosen defaults for new-channel creation:
  - defaults.colgen:  list of bundles (each either bundle:// or data:) that
                      replace the SDK-bundled generator seed.
  - defaults.colrend: same, for renderer bundles.
  - defaults.colchan: a single .colchan archive used as the starter-channel
                      template. Stored here; applied by a future PR (genesis
                      override for full-channel templates is out of scope
                      for the initial settings PR).
  - preferences:      free-form dict for small key/value UI prefs.

Persistence: single row in the global sqlite DB (`.collimate/app.db`), key
``user_settings``. Portable to pyodide's IndexedDB-backed sqlite without
schema changes.
"""
import base64
import hashlib
import json
from dataclasses import dataclass
from importlib.resources import as_file, files
from pathlib import Path
from typing import Optional

SETTINGS_FORMAT_VERSION = 1
STORAGE_KEY = "user_settings"

_API_DIR = Path(__file__).resolve().parent
_PROJECT_ROOT = _API_DIR.parent
_IN_TREE_SDK_ROOT = _PROJECT_ROOT / "collimate-sdk"


# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

def empty_settings() -> dict:
    return {
        "version": SETTINGS_FORMAT_VERSION,
        "defaults": {"colgen": [], "colrend": [], "colchan": None},
        "preferences": {},
    }


def validate(settings: dict) -> dict:
    """Return a normalized, schema-valid settings dict. Raises ValueError on
    malformed input. Unknown top-level keys are discarded."""
    if not isinstance(settings, dict):
        raise ValueError("settings must be a JSON object")

    version = settings.get("version", SETTINGS_FORMAT_VERSION)
    if version != SETTINGS_FORMAT_VERSION:
        raise ValueError(f"Unsupported settings version {version}")

    defaults_in = settings.get("defaults") or {}
    if not isinstance(defaults_in, dict):
        raise ValueError("defaults must be an object")

    out_defaults = {"colgen": [], "colrend": [], "colchan": None}

    for slot in ("colgen", "colrend"):
        entries = defaults_in.get(slot) or []
        if not isinstance(entries, list):
            raise ValueError(f"defaults.{slot} must be a list")
        for i, e in enumerate(entries):
            if not isinstance(e, dict):
                raise ValueError(f"defaults.{slot}[{i}] must be an object")
            if not isinstance(e.get("name", ""), str):
                raise ValueError(f"defaults.{slot}[{i}].name must be a string")
            source = e.get("source")
            if not isinstance(source, str) or not source:
                raise ValueError(f"defaults.{slot}[{i}].source must be a non-empty string")
            entry = {"name": e.get("name", ""), "source": source}
            if isinstance(e.get("sha256"), str):
                entry["sha256"] = e["sha256"]
            out_defaults[slot].append(entry)

    colchan = defaults_in.get("colchan")
    if colchan is not None:
        if not isinstance(colchan, dict):
            raise ValueError("defaults.colchan must be an object or null")
        source = colchan.get("source")
        if not isinstance(source, str) or not source:
            raise ValueError("defaults.colchan.source must be a non-empty string")
        entry = {"source": source}
        if isinstance(colchan.get("name"), str):
            entry["name"] = colchan["name"]
        if isinstance(colchan.get("sha256"), str):
            entry["sha256"] = colchan["sha256"]
        out_defaults["colchan"] = entry

    prefs = settings.get("preferences") or {}
    if not isinstance(prefs, dict):
        raise ValueError("preferences must be an object")

    return {
        "version": SETTINGS_FORMAT_VERSION,
        "defaults": out_defaults,
        "preferences": prefs,
    }


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------

def load_settings() -> dict:
    from database import get_global_db_connection
    conn = get_global_db_connection()
    try:
        row = conn.execute("SELECT value FROM ui_state WHERE key=?", (STORAGE_KEY,)).fetchone()
    finally:
        conn.close()
    if not row:
        return empty_settings()
    try:
        return validate(json.loads(row["value"]))
    except (ValueError, json.JSONDecodeError):
        return empty_settings()


def save_settings(settings: dict) -> dict:
    """Validate and upsert. Returns the normalized dict that was stored."""
    normalized = validate(settings)
    from database import get_global_db_connection
    conn = get_global_db_connection()
    try:
        conn.execute(
            "INSERT INTO ui_state (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (STORAGE_KEY, json.dumps(normalized)),
        )
        conn.commit()
    finally:
        conn.close()
    return normalized


# ---------------------------------------------------------------------------
# Bundle discovery + source resolution
# ---------------------------------------------------------------------------

@dataclass
class BundleRoot:
    """Filesystem location of a bundle tree (SDK-shipped generators/renderers)."""
    path: Path
    kind: str  # "generators" | "renderers"


def _bundle_asset_path(asset: str) -> Optional[Path]:
    """Locate a top-level SDK asset dir (`generators`, `renderers`, etc.).
    Mirrors collimate.packaging.vendor_defaults._asset_path; duplicated here
    so this module does not require collimate-sdk to be on sys.path at import
    time (the api process adds it at startup via main.py)."""
    try:
        installed = files("collimate").joinpath(asset)
        with as_file(installed) as p:
            if p.is_dir():
                return Path(p)
    except (ModuleNotFoundError, FileNotFoundError):
        pass
    in_tree = _IN_TREE_SDK_ROOT / asset
    if in_tree.is_dir():
        return in_tree
    return None


def list_available_bundles(runtime: str = "native") -> dict[str, list[str]]:
    """List bundle names available in the SDK for each kind.
    Returns {"generators": [...], "renderers": [...]}. Used by the Settings
    UI to populate the 'Use bundled' picker."""
    gen_dir_name = "generators" if runtime == "native" else "generators-wasm"
    gen_root = _bundle_asset_path(gen_dir_name)
    ren_root = _bundle_asset_path("renderers")

    def _top_level_dirs(root: Optional[Path]) -> list[str]:
        if not root or not root.is_dir():
            return []
        return sorted(
            p.name for p in root.iterdir()
            if p.is_dir() and not p.name.startswith(".") and not p.name.startswith("__")
        )

    return {
        "generators": _top_level_dirs(gen_root),
        "renderers": _top_level_dirs(ren_root),
    }


def bundle_root_for(kind: str, runtime: str = "native") -> Optional[Path]:
    """Return the filesystem root where bundles of `kind` live.
    `kind` is 'generator' or 'renderer'."""
    if kind == "generator":
        name = "generators" if runtime == "native" else "generators-wasm"
        return _bundle_asset_path(name)
    if kind == "renderer":
        return _bundle_asset_path("renderers")
    return None


def resolve_source_to_bytes(source: str, bundle_root: Optional[Path]) -> bytes:
    """Resolve a settings `source` URI to raw archive bytes.

    Supported URIs:
      bundle://<name>          — read the bundled tree; encoded as a v2 .colgen
                                 archive so the caller can read it via
                                 collimate.packaging.read_archive. (For callers
                                 who want cells directly, use
                                 resolve_source_to_cells instead.)
      data:<mime>;base64,<b64> — inline base64 payload. MIME is informational.

    `bundle_root` is required for bundle:// entries."""
    if source.startswith("bundle://"):
        raise ValueError(
            "bundle:// sources must be resolved via resolve_source_to_cells — "
            "the archive form is a lossy round-trip."
        )
    if source.startswith("data:"):
        try:
            header, payload = source.split(",", 1)
        except ValueError as e:
            raise ValueError(f"malformed data URI: {e}")
        if ";base64" not in header:
            raise ValueError("only base64-encoded data: URIs are supported")
        try:
            return base64.b64decode(payload)
        except Exception as e:
            raise ValueError(f"invalid base64 payload: {e}")
    raise ValueError(f"unsupported source scheme: {source.split(':', 1)[0] or '(none)'}")


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def encode_data_uri(content: bytes, mime: str = "application/gzip") -> str:
    """Produce a data: URI the UI can store as a settings entry source."""
    return f"data:{mime};base64,{base64.b64encode(content).decode('ascii')}"
