"""Periodic WAL checkpoint for SQLite durability.

Bounds worst-case data loss on a power cut. Without checkpoints, the
WAL journal grows until SQLite's auto-checkpoint threshold (1000 pages
by default) forces one — which can be a long time for a quiet channel,
during which an unclean shutdown could lose the last N seconds of
writes even at synchronous=NORMAL.

A scheduled ``PRAGMA wal_checkpoint(TRUNCATE)`` every minute is cheap
when the WAL is near-empty (single page truncate) and keeps recovery
windows bounded under all loads.

Why TRUNCATE: rotating the WAL back to zero bytes also keeps disk
usage of the running database stable. PASSIVE / FULL would leave the
file on disk grown to its high-water mark.
"""

from __future__ import annotations

import asyncio
import logging
import os
import sqlite3

logger = logging.getLogger(__name__)

DEFAULT_INTERVAL_SECONDS = 60.0


def _checkpoint_one(db_path: str) -> tuple[int, int, int] | None:
    """Run TRUNCATE checkpoint against one DB.

    Returns the ``(busy, log, checkpointed)`` triple SQLite emits, or
    None if the DB couldn't be opened (the file is missing or being
    rebuilt from a backup). A busy=1 is normal — it means another
    writer beat us to it, which is fine; we'll catch up next pass."""
    if not os.path.isfile(db_path):
        return None
    try:
        conn = sqlite3.connect(db_path, timeout=2.0)
        try:
            row = conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
        finally:
            conn.close()
        return tuple(row) if row else None
    except sqlite3.DatabaseError as exc:
        logger.warning("wal_checkpoint failed for %s: %s", db_path, exc)
        return None


def checkpoint_all() -> dict:
    """Checkpoint the global DB + every channel DB once. Returns a
    summary dict for logging / surfacing on /ready."""
    summary: dict = {"global": None, "channels": {}}

    summary["global"] = _checkpoint_one(os.path.join(".collimate", "app.db"))

    channels_dir = os.path.join(".collimate", "channels")
    if os.path.isdir(channels_dir):
        for fname in os.listdir(channels_dir):
            if not fname.endswith(".db"):
                continue
            slug = fname[:-3]
            summary["channels"][slug] = _checkpoint_one(os.path.join(channels_dir, fname))
    return summary


async def run_periodic(interval_seconds: float = DEFAULT_INTERVAL_SECONDS) -> None:
    """Run forever, checkpointing every ``interval_seconds``.

    Designed to be scheduled as a background task from the FastAPI
    lifespan and cancelled on shutdown. asyncio.CancelledError exits
    cleanly without an extra log line — the lifespan already records
    "shutting down".
    """
    interval = max(5.0, float(interval_seconds))  # floor of 5s — sanity bound
    logger.info("wal_checkpoint: running every %.1fs", interval)
    try:
        while True:
            await asyncio.sleep(interval)
            try:
                await asyncio.to_thread(checkpoint_all)
            except Exception:
                logger.exception("wal_checkpoint pass failed; continuing")
    except asyncio.CancelledError:
        # Final checkpoint on shutdown so a clean stop doesn't leave a
        # large WAL file behind.
        try:
            await asyncio.to_thread(checkpoint_all)
        except Exception:
            logger.exception("final wal_checkpoint failed")
        raise
