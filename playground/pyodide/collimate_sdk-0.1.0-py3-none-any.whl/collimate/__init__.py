# SPDX-License-Identifier: Apache-2.0
"""Collimate SDK — build generators and renderers for Collimate.

Generators import the top-level :mod:`gen` package (a runtime-aware
shim that re-exports from :mod:`collimate.native` under native and
:mod:`collimate.wasm` under pyodide). The :mod:`collimate.llm` module
provides a small set of provider-agnostic helpers used by the
LLM-driven generators.

Everything else under :mod:`collimate` is internal (the IPC bridge,
the wasm runner-host protocol, the manifest linter) and not part of
the public surface.
"""
from collimate import llm

__all__ = ["llm"]
