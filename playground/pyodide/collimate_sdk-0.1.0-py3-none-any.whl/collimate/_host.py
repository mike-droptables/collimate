# SPDX-License-Identifier: Apache-2.0
"""Internal host-protocol bridge for native generators.

This module is **not user-facing**. Generators consume the singleton
:mod:`collimate.native` (re-exported as ``import gen``); ``native``
internally delegates IPC + filesystem + lifecycle to a single
:class:`HostBridge` instance constructed by :func:`gen.main`.

The bridge owns:

  * the localhost TCP IPC channel (line-delimited JSON, with
    request/ack and NAK frames);
  * SIGTERM-driven cancellation (a self-pipe so the handler stays
    async-signal-safe);
  * the workspace filesystem and the output-stage tracking
    (``tracked_writes`` and ``tracked_deletions``) that drive
    artifact selection on :meth:`update_cell`;
  * chat-history persistence in
    ``.colreserved/.collimate_messages.json``;
  * per-key attempt counters so the in-cell key-request modal can
    show "previous value rejected" on a force-retry;
  * named methods for every IPC op the host understands (cell ops,
    key requests, terminal sessions, port binding, settings modals,
    action polling, chat-stream events, status / progress / log,
    subprocess streaming, snapshot).

A new instance is created exactly once per generator process by
:func:`collimate.native.main`, which then calls
:func:`collimate.native._set_bridge` and invokes ``run()``.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import select
import signal
import socket
import subprocess
import sys
import time
from dataclasses import dataclass
from typing import Any, Optional


# ──────────────────────────────────────────────────────────────────────
# Public dataclasses (consumed by collimate.native via ``Message``)
# ──────────────────────────────────────────────────────────────────────


@dataclass
class Message:
    """A single chat message in the generator conversation."""
    role: str  # "user" | "assistant" | "system"
    content: str
    timestamp: str = ""


# ──────────────────────────────────────────────────────────────────────
# Exception types (re-exported as ``gen.IPCError`` etc.)
# ──────────────────────────────────────────────────────────────────────


class IPCError(Exception):
    """Base for IPC-protocol failures surfaced to generator code.

    Generators that want to handle a failed ack-await (retry, downsize,
    abort) catch this. The three subclasses below let callers
    distinguish *why* the wait failed.
    """


class IPCNakError(IPCError):
    """The host actively rejected the message via a NAK frame."""

    def __init__(self, reason: str, for_op: str = "unknown"):
        super().__init__(f"host NAK for {for_op!r}: {reason}")
        self.reason = reason
        self.for_op = for_op


class IPCTimeoutError(IPCError):
    """No ack arrived within the wall-clock budget."""

    def __init__(self, op: str, timeout: float):
        super().__init__(f"timed out waiting for ack on {op!r} after {timeout:.1f}s")
        self.op = op
        self.timeout = timeout


class IPCDisconnectedError(IPCError):
    """The host closed the IPC socket before sending an ack."""


class _StopRequested(Exception):
    """Internal sentinel used by :meth:`HostBridge.get_key` and
    :meth:`HostBridge.request_settings_update` when the user cancels.

    Translated to :class:`gen.Cancelled` by the public-facing wrappers
    in :mod:`collimate.native`.
    """


# ──────────────────────────────────────────────────────────────────────
# Path filter — `.colreserved/` is private to the SDK + backend
# ──────────────────────────────────────────────────────────────────────


def _is_colreserved_path(path: str) -> bool:
    """``.colreserved/`` is private; generators do not read or write it
    via the public ``gen.*`` API. The single exception is the chat-history
    file which is committed as a cell artifact."""
    norm = path.replace("\\", "/").lstrip("/")
    if norm == ".colreserved/.collimate_messages.json":
        return False
    return norm == ".colreserved" or norm.startswith(".colreserved/")


# ──────────────────────────────────────────────────────────────────────
# HostBridge
# ──────────────────────────────────────────────────────────────────────


_DEFAULT_ACK_TIMEOUT_SECONDS: float = 60.0

# Debounce window for concurrent force-retries on the same env var.
# Long enough to absorb a parallel ``asyncio.gather`` of N agent calls
# that all auth-fail; short enough that a deliberate sequential retry
# (e.g. user fixed the key, ran again, hit auth fail again) still pops
# the modal.
_FORCE_DEBOUNCE_S: float = 5.0


class HostBridge:
    """Single source of truth for everything that talks to the host.

    Lifecycle: constructed once by :func:`collimate.native.main` from
    process env vars (``COLLIMATE_WORKSPACE``, ``COLLIMATE_IPC_PORT``,
    ``COLLIMATE_PARAMS``); :meth:`finish` is called on the way out and
    closes the IPC socket. A second instantiation in the same process
    is a programming error and is not supported.
    """

    def __init__(self) -> None:
        self.workspace: str = os.environ.get("COLLIMATE_WORKSPACE", os.getcwd())
        self.params: dict = json.loads(os.environ.get("COLLIMATE_PARAMS", "{}"))
        self._messages_path = os.path.join(
            self.workspace, ".colreserved", ".collimate_messages.json",
        )

        # Output-stage tracking. ``tracked_writes`` collects every relative
        # path the generator has written via ``gen.update_file``, so the
        # next ``update_cell`` call can compose the artifact list.
        # ``tracked_deletions`` accumulates explicit deletions for the
        # same flush. ``history_dirty`` flips True on the first
        # ``chat_append`` and is cleared once the messages file is
        # included as an artifact.
        self.tracked_writes: set[str] = set()
        self.tracked_deletions: set[str] = set()
        self.history_dirty: bool = False

        # Per-key attempt counter for force-retry hints.
        self._key_attempts: dict[str, int] = {}
        # Wall-clock timestamps (monotonic) of the last force-prompt
        # success per env var. Used by ``collimate.native.api_key`` to
        # debounce concurrent retries: a value set within the last
        # ``_FORCE_DEBOUNCE_S`` seconds is reused instead of popping
        # the modal again.
        self._force_set_ts: dict[str, float] = {}
        # Track whether ``update_cell`` has been called at least once;
        # the host treats the first call as ``initial`` and skips the
        # version-history entry.
        self._has_updated: bool = False

        # Stderr log for the run-events panel. The host scrapes stderr
        # so a plain ``StreamHandler`` is enough; per-line ``[INFO] ...``
        # framing matches the existing run-log conventions.
        self.log = logging.getLogger("collimate.generator")
        if not self.log.handlers:
            handler = logging.StreamHandler(sys.stderr)
            handler.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
            self.log.addHandler(handler)
            self.log.setLevel(logging.DEBUG)

        # Primary user prompt — written to ``.colreserved/prompt.md`` by
        # the host at run start regardless of how the picker / draft /
        # reconfigure path delivered it.
        self.prompt: str = ""
        prompt_path = os.path.join(self.workspace, ".colreserved", "prompt.md")
        try:
            if os.path.isfile(prompt_path):
                with open(prompt_path, "r", encoding="utf-8") as fh:
                    self.prompt = fh.read()
        except OSError:
            self.prompt = ""

        # IPC socket. Dev mode (no port set) keeps everything else
        # working but makes ``emit`` a no-op so generators can be
        # exercised outside the runtime.
        self._socket: Optional[socket.socket] = None
        self._sock_rfile = None
        self._sock_wfile = None
        port_str = os.environ.get("COLLIMATE_IPC_PORT")
        if port_str:
            try:
                self._socket = socket.create_connection(("127.0.0.1", int(port_str)))
                self._sock_rfile = self._socket.makefile("r", encoding="utf-8")
                self._sock_wfile = self._socket.makefile("w", encoding="utf-8")
            except Exception as exc:
                self._socket = None
                self.log.warning("IPC connect failed (port %s): %s", port_str, exc)
        else:
            self.log.warning("COLLIMATE_IPC_PORT not set — running in dev mode")

        # Cancellation. A self-pipe so the SIGTERM handler is
        # async-signal-safe (Event.set() can deadlock under repeated
        # signal delivery; os.write on a pipe is reentrant by POSIX).
        self._stop_pipe_r, self._stop_pipe_w = os.pipe()
        os.set_blocking(self._stop_pipe_r, True)
        os.set_blocking(self._stop_pipe_w, False)
        signal.signal(signal.SIGTERM, self._handle_stop)
        if sys.platform == "win32":
            signal.signal(signal.SIGBREAK, self._handle_stop)

    # ──────────────────────────────────────────────────────────────────
    # Cancellation
    # ──────────────────────────────────────────────────────────────────

    def _handle_stop(self, signum, frame) -> None:
        # Async-signal-safe: write a single byte to the self-pipe.
        # Non-blocking on the write side, so a full pipe (repeated
        # SIGTERMs) drops extra bytes silently rather than blocking.
        try:
            os.write(self._stop_pipe_w, b"x")
        except (BlockingIOError, OSError):
            pass

    @property
    def cancelled(self) -> bool:
        """Non-blocking poll for Stop. True if SIGTERM has been delivered."""
        ready, _, _ = select.select([self._stop_pipe_r], [], [], 0)
        return bool(ready)

    # ──────────────────────────────────────────────────────────────────
    # Filesystem (workspace-scoped)
    # ──────────────────────────────────────────────────────────────────

    def fs_read(self, path: str) -> str:
        if _is_colreserved_path(path):
            raise PermissionError(f".colreserved/ is reserved: {path}")
        with open(os.path.join(self.workspace, path), "r", encoding="utf-8") as fh:
            return fh.read()

    def fs_write(self, path: str, content: str) -> None:
        if _is_colreserved_path(path):
            raise PermissionError(f".colreserved/ is reserved: {path}")
        full = os.path.join(self.workspace, path)
        os.makedirs(os.path.dirname(full) or ".", exist_ok=True)
        with open(full, "w", encoding="utf-8") as fh:
            fh.write(content)
        self.tracked_writes.add(path)
        self.tracked_deletions.discard(path)

    def fs_exists(self, path: str) -> bool:
        if _is_colreserved_path(path):
            return False
        return os.path.exists(os.path.join(self.workspace, path))

    def fs_list(self) -> list[str]:
        """Every workspace file relative path. ``.colreserved/`` and
        ``.collimate_messages*`` are filtered out so generators never see
        SDK-internal state."""
        out: list[str] = []
        for root, dirs, files in os.walk(self.workspace):
            dirs[:] = [
                d for d in dirs
                if not _is_colreserved_path(
                    os.path.relpath(os.path.join(root, d), self.workspace)
                )
            ]
            for fname in files:
                if fname.startswith(".collimate_messages"):
                    continue
                rel = os.path.relpath(
                    os.path.join(root, fname), self.workspace,
                ).replace("\\", "/")
                if _is_colreserved_path(rel):
                    continue
                out.append(rel)
        return out

    def fs_unlink(self, path: str) -> None:
        full = os.path.join(self.workspace, path)
        try:
            if os.path.isfile(full):
                os.remove(full)
        except OSError:
            pass
        self.tracked_writes.discard(path)
        self.tracked_deletions.add(path)

    # ──────────────────────────────────────────────────────────────────
    # Config (draft files seeded into the workspace by the run dispatcher)
    # ──────────────────────────────────────────────────────────────────

    def config(self, name: str) -> Any:
        """Read a draft file by extension.

        ``.set_yaml`` / ``.yaml`` / ``.yml`` parse YAML and merge the
        ``fields:`` defaults with ``values:`` (returns a flat dict).
        ``.json`` parses JSON. Anything else returns the raw string.
        Missing or malformed files yield ``{}`` (or ``""`` for raw)
        so callers can use ``cfg.get(...)`` without try/except.
        """
        # The run dispatcher seeds the user's edited draft files into
        # ``.colreserved/config/files/<name>`` (the WASM runner reads from
        # the same place). Workspace-root path is the legacy fallback.
        config_path = os.path.join(
            self.workspace, ".colreserved", "config", "files", name,
        )
        full = config_path if os.path.isfile(config_path) else os.path.join(self.workspace, name)
        if not os.path.isfile(full):
            return "" if not name.lower().endswith((".set_yaml", ".yaml", ".yml", ".json")) else {}
        try:
            with open(full, "r", encoding="utf-8") as fh:
                raw = fh.read()
        except OSError:
            return ""
        lower = name.lower()
        if lower.endswith((".set_yaml", ".yaml", ".yml")):
            return _parse_schema_values(raw)
        if lower.endswith(".json"):
            try:
                return json.loads(raw)
            except json.JSONDecodeError:
                return {}
        return raw

    # ──────────────────────────────────────────────────────────────────
    # Chat history (persisted as .colreserved/.collimate_messages.json)
    # ──────────────────────────────────────────────────────────────────

    def chat_history(self) -> list[Message]:
        path = self._messages_path
        if not os.path.isfile(path):
            return []
        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, json.JSONDecodeError):
            return []
        if not isinstance(data, list):
            return []
        return [
            Message(
                role=m.get("role", "user"),
                content=m.get("content", ""),
                timestamp=m.get("timestamp", ""),
            )
            for m in data
        ]

    def chat_append(self, role: str, content: str) -> None:
        """Append a message to the persisted history. Idempotent: a
        duplicate of the last entry (e.g. the frontend's draft flush
        already wrote it) is a no-op aside from marking dirty."""
        messages = self.chat_history()
        if messages and messages[-1].role == role and messages[-1].content == content:
            self.history_dirty = True
            return
        messages.append(Message(role=role, content=content))
        raw = [{"role": m.role, "content": m.content} for m in messages]
        os.makedirs(os.path.dirname(self._messages_path), exist_ok=True)
        with open(self._messages_path, "w", encoding="utf-8") as fh:
            json.dump(raw, fh, indent=2, ensure_ascii=False)
        self.history_dirty = True

    # ──────────────────────────────────────────────────────────────────
    # IPC primitives
    # ──────────────────────────────────────────────────────────────────

    def emit(self, payload: dict) -> None:
        if self._sock_wfile is None:
            self.log.debug("IPC (dev): %s", json.dumps(payload))
            return
        self._sock_wfile.write(json.dumps(payload) + "\n")
        self._sock_wfile.flush()

    def emit_and_wait(
        self,
        payload: dict,
        wait_op: str,
        *,
        timeout: Optional[float] = None,
    ) -> dict:
        """Emit a message and block until the matching ack arrives.

        Failure modes (each raises a distinct subclass of :class:`IPCError`):

          * :class:`IPCNakError` — host returned ``{"op": "nak", ...}``.
          * :class:`IPCTimeoutError` — no ack within the budget.
          * :class:`IPCDisconnectedError` — host closed the socket.
        """
        budget = _DEFAULT_ACK_TIMEOUT_SECONDS if timeout is None else float(timeout)
        self.emit(payload)
        if self._sock_rfile is None:
            return {}

        deadline = time.monotonic() + budget
        sock_fd = self._socket.fileno() if self._socket is not None else None

        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise IPCTimeoutError(wait_op, budget)

            if sock_fd is not None:
                ready, _, _ = select.select([sock_fd], [], [], remaining)
                if not ready:
                    raise IPCTimeoutError(wait_op, budget)

            line = self._sock_rfile.readline()
            if not line:
                raise IPCDisconnectedError(
                    f"host closed IPC channel while awaiting ack on {wait_op!r}"
                )

            try:
                ack = json.loads(line.strip())
            except json.JSONDecodeError:
                continue

            ack_op = ack.get("op")
            if ack_op == wait_op:
                return ack
            if ack_op == "nak":
                raise IPCNakError(
                    reason=str(ack.get("reason", "unspecified")),
                    for_op=str(ack.get("for_op", "unknown")),
                )
            # Stale ack from a previous op — keep reading.

    # ──────────────────────────────────────────────────────────────────
    # Lifecycle
    # ──────────────────────────────────────────────────────────────────

    def finish(self, *, success: bool, error_message: str = "") -> None:
        self.emit({
            "op": "finish",
            "success": success,
            "error_message": error_message,
        })
        for fileobj in (self._sock_wfile, self._sock_rfile, self._socket):
            if fileobj is not None:
                try:
                    fileobj.close()
                except OSError:
                    pass

    # ──────────────────────────────────────────────────────────────────
    # Cell ops
    # ──────────────────────────────────────────────────────────────────

    def update_cell(
        self,
        *,
        name: Optional[str] = None,
        summary: Optional[str] = None,
        summary_artifact: Optional[str] = None,
        deleted_files: Optional[list[str]] = None,
    ) -> str:
        """Flush tracked writes (and dirty chat history) to the placeholder
        cell. First call is treated as initial; subsequent calls append a
        new version row linked via ``cell_edges``.

        Returns the cell id.
        """
        artifacts: list[dict] = []
        for path in self.tracked_writes:
            if _is_colreserved_path(path):
                continue
            artifacts.append({
                "type": "workspace",
                "cell_path": path,
                "local_path": path,
            })
        if self.history_dirty:
            artifacts.append({
                "type": "workspace",
                "cell_path": ".colreserved/.collimate_messages.json",
                "local_path": ".colreserved/.collimate_messages.json",
            })

        self.tracked_writes.clear()
        self.history_dirty = False

        metadata: dict[str, Any] = {}
        if summary_artifact is not None:
            metadata["summary_artifact"] = summary_artifact

        payload: dict[str, Any] = {
            "op": "update_cell",
            "name": name,
            "summary": summary,
            "artifacts": artifacts,
            "metadata": metadata,
        }
        # Mirrors create_side_cell: the host reads ``summary_artifact``
        # from the top level (legacy protocol). Keeping it in metadata
        # too because newer host paths look there.
        if summary_artifact is not None:
            payload["summary_artifact"] = summary_artifact
        if deleted_files:
            payload["deleted_files"] = list(deleted_files)
        if not self._has_updated:
            payload["initial"] = True
            self._has_updated = True

        ack = self.emit_and_wait(payload, wait_op="ack_update")
        return ack.get("cell_id", "")

    def create_side_cell(
        self,
        *,
        name: str,
        summary: Optional[str] = None,
        summary_artifact: Optional[str] = None,
        files: Optional[dict[str, str]] = None,
    ) -> str:
        """Create a new side cell. If ``files`` is provided, each entry is
        written to disk first (so the host's workspace artifacts resolve
        cleanly), and only those paths are included as artifacts —
        ``tracked_writes`` is left untouched.
        """
        artifacts: list[dict] = []
        if files is not None:
            for path, content in files.items():
                self.fs_write(path, content)
                if _is_colreserved_path(path):
                    continue
                # The fs_write call added the path to tracked_writes;
                # remove it so the next ``update_cell`` doesn't double-
                # commit the same path into the placeholder.
                self.tracked_writes.discard(path)
                artifacts.append({
                    "type": "workspace",
                    "cell_path": path,
                    "local_path": path,
                })
        else:
            for path in sorted(self.tracked_writes):
                if _is_colreserved_path(path):
                    continue
                artifacts.append({
                    "type": "workspace",
                    "cell_path": path,
                    "local_path": path,
                })

        metadata: dict[str, Any] = {}
        if summary_artifact is not None:
            metadata["summary_artifact"] = summary_artifact

        payload: dict[str, Any] = {
            "op": "create_side_cell",
            "name": name,
            "summary": summary,
            "artifacts": artifacts,
            "metadata": metadata,
        }
        if summary_artifact is not None:
            payload["summary_artifact"] = summary_artifact

        ack = self.emit_and_wait(payload, wait_op="ack_create_side_cell")
        return ack.get("cell_id", "")

    # ──────────────────────────────────────────────────────────────────
    # Status / control
    # ──────────────────────────────────────────────────────────────────

    def push_log(self, line: str) -> None:
        self.log.info(line)

    def set_status(self, message: str) -> None:
        self.emit({"op": "status", "status": "running", "message": message})

    def progress(self, current: int, total: int) -> None:
        self.emit({"op": "progress", "current": current, "total": total})

    # ──────────────────────────────────────────────────────────────────
    # Keys + secrets
    # ──────────────────────────────────────────────────────────────────

    def _was_recently_force_set(self, env_name: str) -> bool:
        """Did a force-retry for ``env_name`` succeed within the
        debounce window? Used to coordinate concurrent retries."""
        ts = self._force_set_ts.get(env_name, 0.0)
        return (time.monotonic() - ts) < _FORCE_DEBOUNCE_S

    def _mark_force_set(self, env_name: str) -> None:
        """Record that ``env_name`` was just force-set so subsequent
        concurrent retries within the debounce window skip the modal."""
        self._force_set_ts[env_name] = time.monotonic()

    def get_key(
        self,
        name: str,
        *,
        description: str = "",
        force: bool = False,
    ) -> str:
        """Resolve ``name`` from the keystore (env-var fast path) or via
        the in-cell modal. Raises :class:`_StopRequested` on user cancel
        — :mod:`collimate.native` translates that to ``gen.Cancelled``.
        """
        if not force:
            existing = (os.environ.get(name) or "").strip()
            if existing:
                return existing

        attempts = self._key_attempts.get(name, 0) + 1
        self._key_attempts[name] = attempts

        ack = self.emit_and_wait(
            {
                "op": "request_key",
                "key_name": name,
                "description": description,
                "force": force,
                "attempt": attempts,
            },
            wait_op="ack_request_key",
            timeout=620.0,
        )
        if ack.get("cancelled"):
            raise _StopRequested()
        if not ack.get("ok"):
            raise RuntimeError(
                f"get_key({name!r}) failed: {ack.get('error', 'unknown')}"
            )
        value = ack.get("value") or ""
        if not value:
            raise RuntimeError(f"get_key({name!r}) returned empty value — host bug")
        os.environ[name] = value
        return value

    # ──────────────────────────────────────────────────────────────────
    # User input mid-run
    # ──────────────────────────────────────────────────────────────────

    def poll_user_message(self) -> Optional[str]:
        """Single non-blocking poll. Returns the next queued message
        content, or ``None`` if the queue is empty."""
        ack = self.emit_and_wait(
            {"op": "poll_user_message"},
            wait_op="ack_poll_user_message",
        )
        content = ack.get("content")
        return content if content else None

    def poll_renderer_action(self) -> Optional[str]:
        ack = self.emit_and_wait(
            {"op": "poll_renderer_action"},
            wait_op="ack_poll_renderer_action",
        )
        action_id = ack.get("action_id")
        return action_id if action_id else None

    # ──────────────────────────────────────────────────────────────────
    # Settings modal
    # ──────────────────────────────────────────────────────────────────

    def request_settings_update(self, settings_file_path: str) -> dict:
        ack = self.emit_and_wait(
            {
                "op": "request_settings_update",
                "settings_file_path": settings_file_path,
            },
            wait_op="ack_settings_update",
            timeout=620.0,
        )
        if not ack.get("ok", False):
            raise RuntimeError(
                f"request_settings_update failed: {ack.get('error', 'unknown')}"
            )
        return ack.get("values", {})

    # ──────────────────────────────────────────────────────────────────
    # Ports + terminals + chat sessions
    # ──────────────────────────────────────────────────────────────────

    def serve_port(
        self,
        port: int,
        *,
        name: str = "preview",
        path: str = "",
        snapshot_source: Optional[dict[str, str]] = None,
    ) -> None:
        payload: dict[str, Any] = {"op": "port_bound", "port": port, "name": name}
        if path:
            payload["path"] = path
        if snapshot_source:
            payload["snapshot_source"] = snapshot_source
        self.emit(payload)

    def start_terminal(
        self,
        *,
        container_id: str,
        command: list[str],
        cwd: Optional[str] = None,
        env: Optional[dict[str, str]] = None,
    ) -> dict:
        cell_id = os.environ.get("COLLIMATE_IN_PLACE_CELL_ID", "")
        ack = self.emit_and_wait(
            {
                "op": "create_terminal_session",
                "cell_id": cell_id,
                "container_id": container_id,
                "command": list(command),
                "cwd": cwd or "",
                "env": dict(env or {}),
            },
            wait_op="ack_create_terminal_session",
        )
        if not ack.get("ok", False):
            raise RuntimeError(
                f"start_terminal failed: {ack.get('error', 'unknown')}"
            )
        return {
            "session_id": ack.get("session_id", ""),
            "ws_path": ack.get("ws_path", ""),
            "token": ack.get("token", ""),
        }

    def stop_terminal(self, session_id: str) -> None:
        if not session_id:
            return
        self.emit({"op": "destroy_terminal_session", "session_id": session_id})

    def chat_session_start(
        self,
        *,
        image: str,
        dockerfile_dir: str,
        shared: bool = True,
        backend: str = "claude_code_session",
        model: str = "sonnet",
        system_prompt: str = "",
    ) -> dict:
        cell_id = os.environ.get("COLLIMATE_IN_PLACE_CELL_ID", "")
        ack = self.emit_and_wait(
            {
                "op": "chat_start_session",
                "cell_id": cell_id,
                "image": image,
                "dockerfile_dir": dockerfile_dir,
                "shared": bool(shared),
                "backend": backend,
                "model": model,
                "system_prompt": system_prompt,
            },
            wait_op="ack_chat_start_session",
            timeout=300.0,
        )
        if not ack.get("ok", False):
            raise RuntimeError(
                f"chat_session_start failed: {ack.get('error', 'unknown')}"
            )
        return ack

    def chat_session_send(self, content: str) -> dict:
        cell_id = os.environ.get("COLLIMATE_IN_PLACE_CELL_ID", "")
        ack = self.emit_and_wait(
            {"op": "chat_send_turn", "cell_id": cell_id, "content": content},
            wait_op="ack_chat_send_turn",
            timeout=3600.0,
        )
        if not ack.get("ok", False):
            raise RuntimeError(
                f"chat_session_send failed: {ack.get('error', 'unknown')}"
            )
        return ack

    def chat_stream_event(self, turn_id: str, event: dict) -> None:
        cell_id = os.environ.get("COLLIMATE_IN_PLACE_CELL_ID", "")
        self.emit({
            "op": "chat_stream_event",
            "cell_id": cell_id,
            "turn_id": turn_id,
            "event": event,
        })

    # ──────────────────────────────────────────────────────────────────
    # Subprocess streaming + workspace snapshot
    # ──────────────────────────────────────────────────────────────────

    def run_streamed_subprocess(
        self,
        command,
        *,
        turn_id: Optional[str] = None,
        timeout: int = 120,
        cwd: Optional[str] = None,
        shell: bool = False,
        emit_bash_stdout: bool = True,
        emit_text_delta: bool = False,
        print_stdout: bool = True,
    ) -> tuple[int, str]:
        """Spawn + stream a subprocess. Returns ``(returncode, full_output)``.

        Cooperative cancellation: ``self.cancelled`` polled per line; on
        True the child is ``terminate``d. On timeout it is ``kill``ed.
        """
        if cwd is None:
            cwd = self.workspace
        collected: list[str] = []
        proc: Optional[subprocess.Popen] = None
        start_ts = time.time()

        try:
            proc = subprocess.Popen(
                command,
                shell=shell,
                cwd=cwd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
        except FileNotFoundError as exc:
            return -1, f"(command not found: {exc})"
        except Exception as exc:
            return -1, f"(spawn error: {exc})"

        assert proc.stdout is not None
        try:
            for raw in proc.stdout:
                line = raw.rstrip("\n")
                collected.append(line)
                if turn_id and emit_bash_stdout:
                    try:
                        self.chat_stream_event(turn_id, {
                            "type": "bash_stdout",
                            "turn_id": turn_id,
                            "text": line,
                        })
                    except Exception:
                        pass
                if turn_id and emit_text_delta:
                    try:
                        self.chat_stream_event(turn_id, {
                            "type": "text_delta",
                            "turn_id": turn_id,
                            "text": line + "\n",
                        })
                    except Exception:
                        pass
                if print_stdout:
                    print(line, flush=True)
                if self.cancelled:
                    try:
                        proc.terminate()
                    except ProcessLookupError:
                        pass
                    collected.append("(interrupted by user)")
                    break
                if time.time() - start_ts > timeout:
                    try:
                        proc.kill()
                    except ProcessLookupError:
                        pass
                    collected.append(f"(timed out after {timeout}s)")
                    break
        finally:
            if proc.poll() is None:
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    try:
                        proc.kill()
                    except ProcessLookupError:
                        pass
                    try:
                        proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        pass

        rc = proc.returncode if proc is not None else -1
        return rc, "\n".join(collected)

    def snapshot_workspace(
        self,
        *,
        skip_dirs: Optional[set[str]] = None,
    ) -> dict[str, str]:
        """``{relpath: sha256_hex}`` for every workspace file. Pair with a
        second snapshot to detect what changed."""
        if skip_dirs is None:
            skip_dirs = {".git", "node_modules", ".venv", "__pycache__"}
        skip_dirs = set(skip_dirs) | {".colreserved"}
        result: dict[str, str] = {}
        ws = self.workspace
        if not os.path.isdir(ws):
            return result
        for root, dirs, files in os.walk(ws):
            dirs[:] = [d for d in dirs if d not in skip_dirs]
            for fname in files:
                if fname.startswith(".collimate_messages"):
                    continue
                abs_path = os.path.join(root, fname)
                rel = os.path.relpath(abs_path, ws).replace("\\", "/")
                try:
                    with open(abs_path, "rb") as fh:
                        result[rel] = hashlib.sha256(fh.read()).hexdigest()
                except OSError:
                    continue
        return result


# ──────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────


def _parse_schema_values(raw: str) -> dict:
    """Parse a ``.set_yaml`` / ``.yaml`` schema-form file and merge
    ``fields:`` defaults with the ``values:`` block. Plain YAML maps
    pass through unchanged."""
    if not raw.strip():
        return {}
    try:
        import yaml
    except ImportError:
        return {}
    try:
        parsed = yaml.safe_load(raw)
    except yaml.YAMLError:
        return {}
    if not isinstance(parsed, dict):
        return {}
    values = parsed.get("values") if isinstance(parsed.get("values"), dict) else {}
    fields = parsed.get("fields") if isinstance(parsed.get("fields"), list) else []
    if fields or values:
        out: dict = {}
        for field in fields:
            if isinstance(field, dict) and isinstance(field.get("key"), str) and "default" in field:
                out[field["key"]] = field["default"]
        out.update(values)
        return out
    return parsed


__all__ = [
    "HostBridge",
    "IPCDisconnectedError",
    "IPCError",
    "IPCNakError",
    "IPCTimeoutError",
    "Message",
    "_StopRequested",
]
