# SPDX-License-Identifier: Apache-2.0
"""Internal host-protocol bridge for native generators.

This module is **not user-facing**. Generators consume the singleton
:mod:`collimate.native` (re-exported as ``import gen``); ``native``
internally delegates IPC + filesystem + lifecycle to a single
:class:`HostBridge` instance constructed by :func:`gen.main`.

The bridge owns:

  * the localhost TCP IPC channel (line-delimited JSON, with
    request/ack and NAK frames);
  * SIGTERM-driven cancellation (a self-pipe so the handler stays
    async-signal-safe);
  * the workspace filesystem and the output-stage tracking
    (``tracked_writes`` and ``tracked_deletions``) that drive
    artifact selection on :meth:`update_cell`;
  * chat-history persistence in
    ``.colreserved/.collimate_messages.json``;
  * per-key attempt counters so the in-cell key-request modal can
    show "previous value rejected" on a force-retry;
  * named methods for every IPC op the host understands (cell ops,
    key requests, terminal sessions, port binding, settings modals,
    action polling, chat-stream events, status / progress / log,
    subprocess streaming, snapshot).

A new instance is created exactly once per generator process by
:func:`collimate.native.main`, which then calls
:func:`collimate.native._set_bridge` and invokes ``run()``.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import select
import signal
import socket
import subprocess
import sys
import threading
import time
from dataclasses import dataclass
from typing import Any, Optional

# Leaf module (imports nothing from native/host) — safe, no cycle.
from collimate._results import _encode_files


# ──────────────────────────────────────────────────────────────────────
# Public dataclasses (consumed by collimate.native via ``Message``)
# ──────────────────────────────────────────────────────────────────────


@dataclass
class Message:
    """A single chat message in the generator conversation."""
    role: str  # "user" | "assistant" | "system"
    content: str
    # The model's reasoning behind an assistant message (extended-thinking
    # text). Optional — empty for user/system messages and for backends/models
    # that expose no thinking. Persisted in the open transcript only when
    # non-empty, so plain transcripts stay plain.
    thinking: str = ""


# ──────────────────────────────────────────────────────────────────────
# Exception types (re-exported as ``gen.IPCError`` etc.)
# ──────────────────────────────────────────────────────────────────────


class IPCError(Exception):
    """Base for IPC-protocol failures surfaced to generator code.

    Generators that want to handle a failed ack-await (retry, downsize,
    abort) catch this. The three subclasses below let callers
    distinguish *why* the wait failed.
    """


class IPCNakError(IPCError):
    """The host actively rejected the message via a NAK frame."""

    def __init__(self, reason: str, for_op: str = "unknown"):
        super().__init__(f"host NAK for {for_op!r}: {reason}")
        self.reason = reason
        self.for_op = for_op


class IPCTimeoutError(IPCError):
    """No ack arrived within the wall-clock budget."""

    def __init__(self, op: str, timeout: float):
        super().__init__(f"timed out waiting for ack on {op!r} after {timeout:.1f}s")
        self.op = op
        self.timeout = timeout


class IPCDisconnectedError(IPCError):
    """The host closed the IPC socket before sending an ack."""


class _StopRequested(Exception):
    """Internal sentinel used by :meth:`HostBridge.get_key` and
    :meth:`HostBridge.request_settings_update` when the user cancels.

    Translated to :class:`gen.Cancelled` by the public-facing wrappers
    in :mod:`collimate.native`.
    """


# ──────────────────────────────────────────────────────────────────────
# Path filter — `.colreserved/` is private to the SDK + backend
# ──────────────────────────────────────────────────────────────────────


def _is_colreserved_path(path: str) -> bool:
    """``.colreserved/`` is private; generators do not read or write it
    via the public ``gen.*`` API."""
    norm = path.replace("\\", "/").lstrip("/")
    return norm == ".colreserved" or norm.startswith(".colreserved/")


# ──────────────────────────────────────────────────────────────────────
# HostBridge
# ──────────────────────────────────────────────────────────────────────


_DEFAULT_ACK_TIMEOUT_SECONDS: float = 60.0

# Debounce window for concurrent force-retries on the same env var.
# Long enough to absorb a parallel ``asyncio.gather`` of N agent calls
# that all auth-fail; short enough that a deliberate sequential retry
# (e.g. user fixed the key, ran again, hit auth fail again) still pops
# the modal.
_FORCE_DEBOUNCE_S: float = 5.0


class HostBridge:
    """Single source of truth for everything that talks to the host.

    Lifecycle: constructed once by :func:`collimate.native.main` from
    process env vars (``COLLIMATE_WORKSPACE``, ``COLLIMATE_IPC_PORT``,
    ``COLLIMATE_PARAMS``); :meth:`finish` is called on the way out and
    closes the IPC socket. A second instantiation in the same process
    is a programming error and is not supported.
    """

    def __init__(self) -> None:
        self.workspace: str = os.environ.get("COLLIMATE_WORKSPACE", os.getcwd())
        self.params: dict = json.loads(os.environ.get("COLLIMATE_PARAMS", "{}"))

        # Output-stage tracking. ``tracked_writes`` collects every relative
        # path the generator has written via ``gen.update_file`` (the chat
        # transcript is an ordinary one of these), so the next
        # ``update_cell`` call can compose the artifact list.
        # ``tracked_deletions`` accumulates explicit deletions for the
        # same flush.
        self.tracked_writes: set[str] = set()
        self.tracked_deletions: set[str] = set()

        # Per-key attempt counter for force-retry hints.
        self._key_attempts: dict[str, int] = {}
        # Wall-clock timestamps (monotonic) of the last force-prompt
        # success per env var. Used by ``collimate.native.api_key`` to
        # debounce concurrent retries: a value set within the last
        # ``_FORCE_DEBOUNCE_S`` seconds is reused instead of popping
        # the modal again.
        self._force_set_ts: dict[str, float] = {}
        # Track whether ``update_cell`` has been called at least once;
        # the host treats the first call as ``initial`` and skips the
        # version-history entry.
        self._has_updated: bool = False

        # Stderr log for the run-events panel. The host scrapes stderr
        # so a plain ``StreamHandler`` is enough; per-line ``[INFO] ...``
        # framing matches the existing run-log conventions.
        self.log = logging.getLogger("collimate.generator")
        if not self.log.handlers:
            handler = logging.StreamHandler(sys.stderr)
            handler.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
            self.log.addHandler(handler)
            self.log.setLevel(logging.DEBUG)

        # Primary user prompt — written to ``.colreserved/prompt.md`` by
        # the host at run start regardless of how the picker / draft /
        # reconfigure path delivered it.
        self.prompt: str = ""
        prompt_path = os.path.join(self.workspace, ".colreserved", "prompt.md")
        try:
            if os.path.isfile(prompt_path):
                with open(prompt_path, "r", encoding="utf-8") as fh:
                    self.prompt = fh.read()
        except OSError:
            self.prompt = ""

        # The invocation type — one of "modify", "create" — is the mode
        # the user selected when invoking this generator. Manifests declare
        # a ``type`` array of every mode they support; the host injects the
        # chosen mode here so the entrypoint can branch via
        # ``gen.invocation_type``.
        self.invocation_type: str = os.environ.get(
            "COLLIMATE_INVOCATION_TYPE", "",
        ).strip()

        # IPC socket. Dev mode (no port set) keeps everything else
        # working but makes ``emit`` a no-op so generators can be
        # exercised outside the runtime.
        self._socket: Optional[socket.socket] = None
        self._sock_rfile = None
        self._sock_wfile = None
        # Serialises the whole emit→ack transaction: one socket + one reader,
        # and acks correlate by op-name, so two concurrent emit_and_wait calls
        # (e.g. asyncio.gather-ed handle ops, or an env's serve loop + reply)
        # would interleave frames and steal each other's acks. Reentrant so the
        # nested self.emit() inside emit_and_wait doesn't self-deadlock.
        self._ipc_lock = threading.RLock()
        port_str = os.environ.get("COLLIMATE_IPC_PORT")
        if port_str:
            try:
                self._socket = socket.create_connection(("127.0.0.1", int(port_str)))
                self._sock_rfile = self._socket.makefile("r", encoding="utf-8")
                self._sock_wfile = self._socket.makefile("w", encoding="utf-8")
            except Exception as exc:
                self._socket = None
                self.log.warning("IPC connect failed (port %s): %s", port_str, exc)
        else:
            self.log.warning("COLLIMATE_IPC_PORT not set — running in dev mode")

        # Cancellation. A self-pipe so the SIGTERM handler is
        # async-signal-safe (Event.set() can deadlock under repeated
        # signal delivery; os.write on a pipe is reentrant by POSIX).
        self._stop_pipe_r, self._stop_pipe_w = os.pipe()
        os.set_blocking(self._stop_pipe_r, True)
        os.set_blocking(self._stop_pipe_w, False)
        signal.signal(signal.SIGTERM, self._handle_stop)
        if sys.platform == "win32":
            signal.signal(signal.SIGBREAK, self._handle_stop)

    # ──────────────────────────────────────────────────────────────────
    # Cancellation
    # ──────────────────────────────────────────────────────────────────

    def _handle_stop(self, signum, frame) -> None:
        # Async-signal-safe: write a single byte to the self-pipe.
        # Non-blocking on the write side, so a full pipe (repeated
        # SIGTERMs) drops extra bytes silently rather than blocking.
        try:
            os.write(self._stop_pipe_w, b"x")
        except (BlockingIOError, OSError):
            pass

    @property
    def cancelled(self) -> bool:
        """Non-blocking poll for Stop. True if SIGTERM has been delivered."""
        ready, _, _ = select.select([self._stop_pipe_r], [], [], 0)
        return bool(ready)

    # ──────────────────────────────────────────────────────────────────
    # Filesystem (workspace-scoped)
    # ──────────────────────────────────────────────────────────────────

    def fs_read(self, path: str) -> str:
        if _is_colreserved_path(path):
            raise PermissionError(f".colreserved/ is reserved: {path}")
        with open(os.path.join(self.workspace, path), "r", encoding="utf-8") as fh:
            return fh.read()

    def fs_read_bytes(self, path: str) -> bytes:
        if _is_colreserved_path(path):
            raise PermissionError(f".colreserved/ is reserved: {path}")
        with open(os.path.join(self.workspace, path), "rb") as fh:
            return fh.read()

    def fs_read_any(self, path: str) -> "str | bytes":
        """Read a workspace file as text if utf-8 decodable, else bytes.

        Mirrors the WASM runtime's ``read_workspace_any`` so generators
        get the same str/bytes auto-detect on both runtimes.
        """
        try:
            return self.fs_read(path)
        except UnicodeDecodeError:
            return self.fs_read_bytes(path)

    def fs_write(self, path: str, content: str) -> None:
        if _is_colreserved_path(path):
            raise PermissionError(f".colreserved/ is reserved: {path}")
        full = os.path.join(self.workspace, path)
        os.makedirs(os.path.dirname(full) or ".", exist_ok=True)
        with open(full, "w", encoding="utf-8") as fh:
            fh.write(content)
        self.tracked_writes.add(path)
        self.tracked_deletions.discard(path)

    def fs_write_any(self, path: str, content: "str | bytes") -> None:
        """Write a workspace file, accepting either str or bytes.

        Bytes go through binary mode (``wb``); str through text mode
        (``w``, utf-8). Tracked the same way as :meth:`fs_write` so the
        next ``update_cell`` flush picks them up regardless of encoding.
        """
        if _is_colreserved_path(path):
            raise PermissionError(f".colreserved/ is reserved: {path}")
        full = os.path.join(self.workspace, path)
        os.makedirs(os.path.dirname(full) or ".", exist_ok=True)
        if isinstance(content, bytes):
            with open(full, "wb") as fh:
                fh.write(content)
        elif isinstance(content, str):
            with open(full, "w", encoding="utf-8") as fh:
                fh.write(content)
        else:
            raise TypeError(
                f"fs_write_any: content must be str or bytes, got {type(content).__name__}",
            )
        self.tracked_writes.add(path)
        self.tracked_deletions.discard(path)

    def fs_exists(self, path: str) -> bool:
        if _is_colreserved_path(path):
            return False
        return os.path.exists(os.path.join(self.workspace, path))

    def fs_list(self) -> list[str]:
        """Every workspace file relative path. ``.colreserved/`` is filtered
        out so generators never see SDK-internal state."""
        out: list[str] = []
        for root, dirs, files in os.walk(self.workspace):
            dirs[:] = [
                d for d in dirs
                if not _is_colreserved_path(
                    os.path.relpath(os.path.join(root, d), self.workspace)
                )
            ]
            for fname in files:
                rel = os.path.relpath(
                    os.path.join(root, fname), self.workspace,
                ).replace("\\", "/")
                if _is_colreserved_path(rel):
                    continue
                out.append(rel)
        return out

    def fs_unlink(self, path: str) -> None:
        full = os.path.join(self.workspace, path)
        try:
            if os.path.isfile(full):
                os.remove(full)
        except OSError:
            pass
        self.tracked_writes.discard(path)
        self.tracked_deletions.add(path)

    # ──────────────────────────────────────────────────────────────────
    # Config (draft files seeded into the workspace by the run dispatcher)
    # ──────────────────────────────────────────────────────────────────

    def config(self, name: str) -> Any:
        """Read a draft file by extension.

        ``.set_yaml`` / ``.yaml`` / ``.yml`` parse YAML and merge the
        ``fields:`` defaults with ``values:`` (returns a flat dict).
        ``.json`` parses JSON. Anything else returns the raw string.
        Missing or malformed files yield ``{}`` (or ``""`` for raw)
        so callers can use ``cfg.get(...)`` without try/except.
        """
        # The run dispatcher seeds the user's edited draft files into
        # ``.colreserved/config/files/<name>`` (the WASM runner reads from
        # the same place).
        full = os.path.join(
            self.workspace, ".colreserved", "config", "files", name,
        )
        if not os.path.isfile(full):
            return "" if not name.lower().endswith((".set_yaml", ".yaml", ".yml", ".json")) else {}
        try:
            with open(full, "r", encoding="utf-8") as fh:
                raw = fh.read()
        except OSError:
            return ""
        lower = name.lower()
        if lower.endswith((".set_yaml", ".yaml", ".yml")):
            return _parse_schema_values(raw)
        if lower.endswith(".json"):
            try:
                return json.loads(raw)
            except json.JSONDecodeError:
                return {}
        return raw

    # ──────────────────────────────────────────────────────────────────
    # IPC primitives
    # ──────────────────────────────────────────────────────────────────

    def _io_lock(self) -> "threading.RLock":
        # Lazily create so bridges built via __new__ (some tests) still work.
        lock = getattr(self, "_ipc_lock", None)
        if lock is None:
            lock = threading.RLock()
            self._ipc_lock = lock
        return lock

    def emit(self, payload: dict) -> None:
        if self._sock_wfile is None:
            self.log.debug("IPC (dev): %s", json.dumps(payload))
            return
        line = json.dumps(payload) + "\n"
        with self._io_lock():
            self._sock_wfile.write(line)
            self._sock_wfile.flush()

    def emit_and_wait(
        self,
        payload: dict,
        wait_op: str,
        *,
        timeout: Optional[float] = None,
    ) -> dict:
        """Emit a message and block until the matching ack arrives.

        Failure modes (each raises a distinct subclass of :class:`IPCError`):

          * :class:`IPCNakError` — host returned ``{"op": "nak", ...}``.
          * :class:`IPCTimeoutError` — no ack within the budget.
          * :class:`IPCDisconnectedError` — host closed the socket.
        """
        budget = _DEFAULT_ACK_TIMEOUT_SECONDS if timeout is None else float(timeout)
        if self._sock_rfile is None:
            self.emit(payload)
            return {}

        deadline = time.monotonic() + budget
        sock_fd = self._socket.fileno() if self._socket is not None else None

        # Hold the lock across the WHOLE transaction (emit + read-until-ack):
        # one socket + one reader, acks correlate only by op-name, so a
        # concurrent caller must not write/read between our emit and our ack.
        with self._io_lock():
            self.emit(payload)
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise IPCTimeoutError(wait_op, budget)

                if sock_fd is not None:
                    ready, _, _ = select.select([sock_fd], [], [], remaining)
                    if not ready:
                        raise IPCTimeoutError(wait_op, budget)

                line = self._sock_rfile.readline()
                if not line:
                    raise IPCDisconnectedError(
                        f"host closed IPC channel while awaiting ack on {wait_op!r}"
                    )

                try:
                    ack = json.loads(line.strip())
                except json.JSONDecodeError:
                    continue

                ack_op = ack.get("op")
                if ack_op == wait_op:
                    return ack
                if ack_op == "nak":
                    raise IPCNakError(
                        reason=str(ack.get("reason", "unspecified")),
                        for_op=str(ack.get("for_op", "unknown")),
                    )
                # Stale ack from a previous op — keep reading.

    # ──────────────────────────────────────────────────────────────────
    # Lifecycle
    # ──────────────────────────────────────────────────────────────────

    def finish(self, *, success: bool, error_message: str = "") -> None:
        self.emit({
            "op": "finish",
            "success": success,
            "error_message": error_message,
        })
        for fileobj in (self._sock_wfile, self._sock_rfile, self._socket):
            if fileobj is not None:
                try:
                    fileobj.close()
                except OSError:
                    pass
        # Close the SIGTERM self-pipe. -1 sentinels guard a double
        # finish(); a late signal hits _handle_stop's OSError catch.
        for fd in (self._stop_pipe_r, self._stop_pipe_w):
            if fd >= 0:
                try:
                    os.close(fd)
                except OSError:
                    pass
        self._stop_pipe_r = self._stop_pipe_w = -1

    # ──────────────────────────────────────────────────────────────────
    # Cell ops
    # ──────────────────────────────────────────────────────────────────

    def update_cell(
        self,
        *,
        name: Optional[str] = None,
        summary: Optional[str] = None,
        pinned: Optional[str] = None,
        deleted_files: Optional[list[str]] = None,
    ) -> str:
        """Flush tracked writes (and dirty chat history) to the placeholder
        cell. First call is treated as initial; subsequent calls append a
        new version row linked via ``cell_edges``.

        Returns the cell id.
        """
        artifacts: list[dict] = []
        for path in self.tracked_writes:
            if _is_colreserved_path(path):
                continue
            artifacts.append({
                "type": "workspace",
                "cell_path": path,
                "local_path": path,
            })

        self.tracked_writes.clear()

        metadata: dict[str, Any] = {}
        if pinned is not None:
            metadata["pinned"] = pinned

        payload: dict[str, Any] = {
            "op": "update_cell",
            "name": name,
            "summary": summary,
            "artifacts": artifacts,
            "metadata": metadata,
        }
        if deleted_files:
            payload["deleted_files"] = list(deleted_files)
        if not self._has_updated:
            payload["initial"] = True
            self._has_updated = True

        ack = self.emit_and_wait(payload, wait_op="ack_update")
        return ack.get("cell_id", "")

    def read_cell_files(self, *, raise_on_error: bool = False) -> dict:
        """The cell's live file state as the user sees it in the Files tab —
        the committed version tip overlaid with any pending Files-tab drafts —
        as ``{path: str | bytes}``.

        This is the read half of ``live_files``: it lets a running generator
        observe the user's mid-run edits (which live in the cell, not the
        workspace) without waiting for a chat turn. Empty in dev mode / when
        there is no host.

        ``raise_on_error`` re-raises a transport failure or a host-reported
        error instead of returning ``{}``. The live-files mirror sets it so a
        transient read failure is never mistaken for "the cell is empty" — which
        would otherwise delete every synced file."""
        try:
            ack = self.emit_and_wait(
                {"op": "read_cell_files"}, wait_op="ack_read_cell_files",
            )
        except Exception:
            if raise_on_error:
                raise
            return {}
        if ack.get("error"):
            if raise_on_error:
                raise RuntimeError(f"read_cell_files failed: {ack['error']}")
            return {}
        from collimate._results import _decode_files
        return _decode_files(ack.get("files") or {})

    def create_side_cell(
        self,
        *,
        name: str,
        summary: Optional[str] = None,
        pinned: Optional[str] = None,
        files: Optional[dict[str, str]] = None,
    ) -> str:
        """Create a new side cell. If ``files`` is provided, each entry is
        written to disk first (so the host's workspace artifacts resolve
        cleanly), and only those paths are included as artifacts —
        ``tracked_writes`` is left untouched.
        """
        artifacts: list[dict] = []
        if files is not None:
            for path, content in files.items():
                # fs_write_any: side-cell file sets legitimately carry binary
                # entries (images an agent produced, carried-through assets).
                self.fs_write_any(path, content)
                if _is_colreserved_path(path):
                    continue
                # The fs_write call added the path to tracked_writes;
                # remove it so the next ``update_cell`` doesn't double-
                # commit the same path into the placeholder.
                self.tracked_writes.discard(path)
                artifacts.append({
                    "type": "workspace",
                    "cell_path": path,
                    "local_path": path,
                })
        else:
            for path in sorted(self.tracked_writes):
                if _is_colreserved_path(path):
                    continue
                artifacts.append({
                    "type": "workspace",
                    "cell_path": path,
                    "local_path": path,
                })

        metadata: dict[str, Any] = {}
        if pinned is not None:
            metadata["pinned"] = pinned

        payload: dict[str, Any] = {
            "op": "create_side_cell",
            "name": name,
            "summary": summary,
            "artifacts": artifacts,
            "metadata": metadata,
        }

        ack = self.emit_and_wait(payload, wait_op="ack_create_side_cell")
        return ack.get("cell_id", "")

    def start_modify_run(
        self,
        *,
        cell_id: str,
        generator: str,
        prompt: Optional[str] = None,
    ) -> None:
        """One-shot handoff of a just-created side cell to a ``modify``
        generator.

        The host validates that ``cell_id`` was created by THIS run via
        ``create_side_cell`` and hasn't been handed off yet, then starts
        an independent top-level ``modify`` run of ``generator`` against
        it. Fire-and-forget by design: no handle comes back, and the
        cell is consumed — this run can't target it again.

        Dev mode (no host): logged and skipped, like the other
        host-backed capabilities.
        """
        if not self._host_available():
            self.log.info(
                "start_modify_run (dev): would hand cell %r to generator %r",
                cell_id, generator,
            )
            return
        # Generous budget — the host synchronously prepares the child
        # run (code copy + workspace hydration) before acking.
        ack = self.emit_and_wait(
            {
                "op": "start_modify_run",
                "cell_id": cell_id,
                "generator": generator,
                "prompt": prompt or "",
            },
            wait_op="ack_start_modify_run",
            timeout=120.0,
        )
        if not ack.get("ok"):
            raise RuntimeError(
                f"start_modify_run failed: {ack.get('error', 'unknown')}"
            )

    # ──────────────────────────────────────────────────────────────────
    # Status / control
    # ──────────────────────────────────────────────────────────────────

    def push_log(self, line: str) -> None:
        self.log.info(line)

    def set_phase(self, phase: str, message: str = "") -> None:
        self.emit({"op": "phase", "phase": phase, "message": message})

    def set_status(self, message: str) -> None:
        # Status is the message of the current phase — send a phase op with no
        # phase key; the host keeps the active phase and updates the message.
        self.emit({"op": "phase", "message": message})

    def progress(self, current: int, total: int) -> None:
        self.emit({"op": "progress", "current": current, "total": total})

    # ──────────────────────────────────────────────────────────────────
    # Keys + secrets
    # ──────────────────────────────────────────────────────────────────

    def _was_recently_force_set(self, env_name: str) -> bool:
        """Did a force-retry for ``env_name`` succeed within the
        debounce window? Used to coordinate concurrent retries."""
        ts = self._force_set_ts.get(env_name, 0.0)
        return (time.monotonic() - ts) < _FORCE_DEBOUNCE_S

    def _mark_force_set(self, env_name: str) -> None:
        """Record that ``env_name`` was just force-set so subsequent
        concurrent retries within the debounce window skip the modal."""
        self._force_set_ts[env_name] = time.monotonic()

    def get_key(
        self,
        name: str,
        *,
        description: str = "",
        force: bool = False,
    ) -> str:
        """Resolve ``name`` from the keystore (env-var fast path) or via
        the in-cell modal. Raises :class:`_StopRequested` on user cancel
        — :mod:`collimate.native` translates that to ``gen.Cancelled``.
        """
        if not force:
            existing = (os.environ.get(name) or "").strip()
            if existing:
                return existing

        attempts = self._key_attempts.get(name, 0) + 1
        self._key_attempts[name] = attempts

        ack = self.emit_and_wait(
            {
                "op": "request_key",
                "key_name": name,
                "description": description,
                "force": force,
                "attempt": attempts,
            },
            wait_op="ack_request_key",
            timeout=620.0,
        )
        if ack.get("cancelled"):
            raise _StopRequested()
        if not ack.get("ok"):
            raise RuntimeError(
                f"get_key({name!r}) failed: {ack.get('error', 'unknown')}"
            )
        value = ack.get("value") or ""
        if not value:
            raise RuntimeError(f"get_key({name!r}) returned empty value — host bug")
        os.environ[name] = value
        return value

    # ──────────────────────────────────────────────────────────────────
    # User input mid-run
    # ──────────────────────────────────────────────────────────────────

    def poll_renderer_action(self) -> Optional[str]:
        ack = self.emit_and_wait(
            {"op": "poll_renderer_action"},
            wait_op="ack_poll_renderer_action",
        )
        action_id = ack.get("action_id")
        return action_id if action_id else None

    # ──────────────────────────────────────────────────────────────────
    # Settings modal
    # ──────────────────────────────────────────────────────────────────

    def request_settings_update(self, settings_file_path: str) -> dict:
        ack = self.emit_and_wait(
            {
                "op": "request_settings_update",
                "settings_file_path": settings_file_path,
            },
            wait_op="ack_settings_update",
            timeout=620.0,
        )
        if not ack.get("ok", False):
            raise RuntimeError(
                f"request_settings_update failed: {ack.get('error', 'unknown')}"
            )
        return ack.get("values", {})

    # ──────────────────────────────────────────────────────────────────
    # Ports + terminals + live chat
    # ──────────────────────────────────────────────────────────────────

    def serve_port(
        self,
        port: int,
        *,
        name: str = "preview",
        path: str = "",
        snapshot_source: Optional[dict[str, str]] = None,
    ) -> None:
        payload: dict[str, Any] = {"op": "port_bound", "port": port, "name": name}
        if path:
            payload["path"] = path
        if snapshot_source:
            payload["snapshot_source"] = snapshot_source
        self.emit(payload)

    def start_terminal(
        self,
        *,
        container_id: str,
        command: list[str],
        cwd: Optional[str] = None,
        env: Optional[dict[str, str]] = None,
    ) -> dict:
        cell_id = os.environ.get("COLLIMATE_IN_PLACE_CELL_ID", "")
        ack = self.emit_and_wait(
            {
                "op": "create_terminal_session",
                "cell_id": cell_id,
                "container_id": container_id,
                "command": list(command),
                "cwd": cwd or "",
                "env": dict(env or {}),
            },
            wait_op="ack_create_terminal_session",
        )
        if not ack.get("ok", False):
            raise RuntimeError(
                f"start_terminal failed: {ack.get('error', 'unknown')}"
            )
        return {
            "session_id": ack.get("session_id", ""),
            "ws_path": ack.get("ws_path", ""),
            "token": ack.get("token", ""),
        }

    def stop_terminal(self, session_id: str) -> None:
        if not session_id:
            return
        self.emit({"op": "destroy_terminal_session", "session_id": session_id})

    def chat_register(self) -> dict:
        """Allocate a live chat session bound to this run's cell. Returns
        ``{session_id, ws_path, token}`` for the ``.chatlive`` pointer the
        renderer opens its WebSocket against."""
        cell_id = os.environ.get("COLLIMATE_IN_PLACE_CELL_ID", "")
        ack = self.emit_and_wait(
            {"op": "chat_register", "cell_id": cell_id},
            wait_op="ack_chat_register",
        )
        if not ack.get("ok", False):
            raise RuntimeError(
                f"chat_register failed: {ack.get('error', 'unknown')}"
            )
        return {
            "session_id": ack.get("session_id", ""),
            "ws_path": ack.get("ws_path", ""),
            "token": ack.get("token", ""),
        }

    def chat_poll(self) -> Optional[dict]:
        """Non-blocking pop of the next inbound chat command from the
        renderer (``{kind: "user_msg"|"interrupt"|"redirect", content}``),
        or ``None`` when the queue is empty."""
        ack = self.emit_and_wait(
            {"op": "chat_poll"},
            wait_op="ack_chat_poll",
        )
        cmd = ack.get("command")
        return cmd if isinstance(cmd, dict) else None

    def stream_event(self, turn_id: str, event: dict) -> None:
        """Fire-and-forget: push a typed stream event to the cell's live
        renderer (routed to the chat session's WebSocket by the host)."""
        cell_id = os.environ.get("COLLIMATE_IN_PLACE_CELL_ID", "")
        self.emit({
            "op": "stream_event",
            "cell_id": cell_id,
            "turn_id": turn_id,
            "event": event,
        })

    def emit_event(self, event: dict) -> None:
        """Fire-and-forget: push a typed event from this (sub-)run to its
        parent's event buffer. The host keys the buffer by this connection's
        run id (the parent reads it back via :meth:`sub_run_poll_events`). A
        no-op with no host, or when this run has no parent (the host simply
        drops events for a parentless run)."""
        if self._sock_wfile is None:
            return
        self.emit({"op": "sub_run_emit", "event": event})

    # ──────────────────────────────────────────────────────────────────
    # Composition (parent-bound sub-runs) + renderer compile
    #
    # All host-backed. In dev mode (no socket) they degrade to a clean
    # "no host" value rather than hanging or raising, so a generator that
    # uses gen.spawn/gen.call/gen.check_renderer can still be exercised
    # offline. Full IPC contract: see the plan's Workstream 7.
    # ──────────────────────────────────────────────────────────────────

    def _host_available(self) -> bool:
        return self._sock_wfile is not None

    def list_generators(self) -> list:
        if not self._host_available():
            return []
        ack = self.emit_and_wait({"op": "list_generators"}, wait_op="ack_list_generators")
        gens = ack.get("generators")
        return gens if isinstance(gens, list) else []

    def start_sub_run(
        self,
        source: dict,
        *,
        inputs: Optional[dict] = None,
        input_groups: Optional[dict] = None,
        prompt: str = "",
        invocation_type: str = "create",
        config: Optional[dict] = None,
        secrets: Optional[list] = None,
        surface: Optional[dict] = None,
    ) -> str:
        """Start a parent-bound child generator; return its sub-run id ('' in
        dev mode). ``source`` is ``{"id": ...}`` or ``{"inline": {...}}``."""
        if not self._host_available():
            return ""
        try:
            call_depth = int(os.environ.get("COLLIMATE_CALL_DEPTH", "0"))
        except ValueError:
            call_depth = 0
        payload = {
            "op": "start_sub_run",
            "source": source,
            "inputs": _encode_files(inputs or {}),
            "input_groups": {k: _encode_files(v or {}) for k, v in (input_groups or {}).items()},
            "prompt": prompt,
            "invocation_type": invocation_type,
            "config": config or {},
            "secrets": list(secrets or []),
            "surface": surface,
            "call_depth": call_depth,
        }
        ack = self.emit_and_wait(payload, wait_op="ack_start_sub_run", timeout=120.0)
        if not ack.get("ok"):
            raise RuntimeError(f"start_sub_run failed: {ack.get('error', 'unknown')}")
        return ack.get("sub_run_id", "")

    def sub_run_endpoints(self, sub_run_id: str) -> list:
        if not (self._host_available() and sub_run_id):
            return []
        ack = self.emit_and_wait(
            {"op": "sub_run_endpoints", "sub_run_id": sub_run_id},
            wait_op="ack_sub_run_endpoints",
        )
        eps = ack.get("endpoints")
        return eps if isinstance(eps, list) else []

    def sub_run_status(self, sub_run_id: str) -> str:
        if not (self._host_available() and sub_run_id):
            return "failed"
        ack = self.emit_and_wait(
            {"op": "sub_run_status", "sub_run_id": sub_run_id},
            wait_op="ack_sub_run_status",
        )
        return ack.get("state", "failed")

    def sub_run_files(self, sub_run_id: str) -> dict:
        if not (self._host_available() and sub_run_id):
            return {}
        ack = self.emit_and_wait(
            {"op": "sub_run_files", "sub_run_id": sub_run_id},
            wait_op="ack_sub_run_files",
        )
        files = ack.get("files")
        return files if isinstance(files, dict) else {}

    def sub_run_poll_events(self, sub_run_id: str, cursor: int) -> dict:
        """Drain a child's parent-bound event buffer past ``cursor``. Returns
        ``{"events": [...], "cursor": int, "state": "running"|"done"|"failed"}``.
        In dev mode / unknown id, reports an empty failed stream so callers
        exit their loop cleanly."""
        if not (self._host_available() and sub_run_id):
            return {"events": [], "cursor": cursor, "state": "failed"}
        ack = self.emit_and_wait(
            {"op": "sub_run_poll_events", "sub_run_id": sub_run_id, "cursor": int(cursor)},
            wait_op="ack_sub_run_poll_events",
        )
        events = ack.get("events")
        return {
            "events": events if isinstance(events, list) else [],
            "cursor": int(ack.get("cursor", cursor)),
            "state": ack.get("state", "running"),
        }

    def sub_run_wait(self, sub_run_id: str, timeout: Optional[float] = None) -> dict:
        if not (self._host_available() and sub_run_id):
            return {"ok": False, "error": "no host available"}
        budget = 3600.0 if timeout is None else float(timeout)
        return self.emit_and_wait(
            {"op": "sub_run_wait", "sub_run_id": sub_run_id, "timeout": budget},
            wait_op="ack_sub_run_wait", timeout=budget + 30.0,
        )

    def stop_sub_run(self, sub_run_id: str) -> None:
        if not (self._host_available() and sub_run_id):
            return
        self.emit({"op": "stop_sub_run", "sub_run_id": sub_run_id})

    def surface_sub_run(self, sub_run_id: str, spec: Optional[dict] = None) -> str:
        if not (self._host_available() and sub_run_id):
            return ""
        ack = self.emit_and_wait(
            {"op": "surface_sub_run", "sub_run_id": sub_run_id, "spec": spec or {}},
            wait_op="ack_surface_sub_run",
        )
        return ack.get("cell_id", "")

    def check_renderer(self, files: dict, entrypoint: str) -> dict:
        if not self._host_available():
            return {"ok": False, "errors": ["no host available (dev mode)"], "warnings": []}
        return self.emit_and_wait(
            {"op": "check_renderer", "files": _encode_files(files), "entrypoint": entrypoint},
            wait_op="ack_check_renderer", timeout=120.0,
        )

    # ──────────────────────────────────────────────────────────────────
    # Cross-cell read / write — gated host-side on cell exposure. Reads/writes
    # an arbitrary EXPOSED cell (generator- or renderer-source), distinct from
    # read_cell_files/update_cell which only touch this run's own cell. Refusals
    # ride as ``ok=False, reason=...`` and map to typed Python errors.
    # ──────────────────────────────────────────────────────────────────

    @staticmethod
    def _raise_cell_rw(ack: dict, default: str) -> None:
        """Map an ``ok=False`` cross-cell ack to a typed error."""
        reason = ack.get("reason")
        msg = ack.get("error") or default
        if reason == "not_exposed":
            raise PermissionError(msg)
        if reason == "not_found":
            raise LookupError(msg)
        if reason == "lint":
            raise ValueError(msg)
        raise RuntimeError(msg)

    def list_exposed_cells(self) -> list:
        if not self._host_available():
            return []
        ack = self.emit_and_wait(
            {"op": "list_exposed_cells"}, wait_op="ack_list_exposed_cells",
        )
        cells = ack.get("cells")
        return cells if isinstance(cells, list) else []

    def read_cell(self, cell_id: str) -> dict:
        if not self._host_available():
            return {}
        ack = self.emit_and_wait(
            {"op": "read_cell", "cell_id": cell_id}, wait_op="ack_read_cell",
        )
        if not ack.get("ok", False):
            self._raise_cell_rw(ack, f"read_cell({cell_id!r}) failed")
        from collimate._results import _decode_files
        return _decode_files(ack.get("files") or {})

    def write_cell(
        self,
        cell_id: str,
        files: dict,
        *,
        summary: Optional[str] = None,
        deleted: Optional[list] = None,
    ) -> str:
        if not self._host_available():
            return ""
        ack = self.emit_and_wait(
            {
                "op": "write_cell",
                "cell_id": cell_id,
                "files": _encode_files(files),
                "summary": summary,
                "deleted": list(deleted) if deleted else None,
            },
            wait_op="ack_write_cell", timeout=120.0,
        )
        if not ack.get("ok", False):
            self._raise_cell_rw(ack, f"write_cell({cell_id!r}) failed")
        return str(ack.get("version_id") or "")

    def create_source_cell(
        self,
        stack: str,
        name: str,
        files: dict,
        *,
        summary: Optional[str] = None,
        pinned: Optional[str] = None,
    ) -> str:
        if not self._host_available():
            return ""
        ack = self.emit_and_wait(
            {
                "op": "create_source_cell",
                "stack": stack,
                "name": name,
                "files": _encode_files(files),
                "summary": summary,
                "pinned": pinned,
            },
            wait_op="ack_create_source_cell", timeout=120.0,
        )
        if not ack.get("ok", False):
            self._raise_cell_rw(ack, f"create_source_cell({stack!r}) failed")
        return str(ack.get("cell_id") or "")

    # ──────────────────────────────────────────────────────────────────
    # Environments — worker side (a parent drives a child environment).
    #
    # Workspace plane (put/read/delete/list/snapshot) is serviced by the host
    # against the child sub-run's workspace dir — guaranteed, no env code.
    # Execution plane (exec / exec_background / expose_port / open_terminal) is
    # routed by the host to the child environment's own process. All keyed by
    # sub_run_id; all dev-mode safe (benign value, never hang/raise).
    # ──────────────────────────────────────────────────────────────────

    def sub_run_capabilities(self, sub_run_id: str) -> Optional[dict]:
        if not (self._host_available() and sub_run_id):
            return None
        ack = self.emit_and_wait(
            {"op": "sub_run_capabilities", "sub_run_id": sub_run_id},
            wait_op="ack_sub_run_capabilities",
        )
        env = ack.get("environment")
        return env if isinstance(env, dict) else None

    def sub_run_exec(self, sub_run_id, command, *, cwd=None, env=None, timeout=120) -> dict:
        if not (self._host_available() and sub_run_id):
            return {"ok": False, "rc": -1, "output": "", "error": "no host available"}
        return self.emit_and_wait(
            {
                "op": "sub_run_exec", "sub_run_id": sub_run_id,
                "command": command if isinstance(command, list) else str(command),
                "cwd": cwd or "", "env": dict(env or {}), "timeout": float(timeout),
            },
            wait_op="ack_sub_run_exec", timeout=float(timeout) + 30.0,
        )

    def sub_run_exec_background(self, sub_run_id, command, *, cwd=None, env=None) -> dict:
        if not (self._host_available() and sub_run_id):
            return {"ok": False, "process_id": "", "error": "no host available"}
        return self.emit_and_wait(
            {
                "op": "sub_run_exec_background", "sub_run_id": sub_run_id,
                "command": command if isinstance(command, list) else str(command),
                "cwd": cwd or "", "env": dict(env or {}),
            },
            wait_op="ack_sub_run_exec_background",
        )

    def sub_run_stop_process(self, sub_run_id, process_id) -> None:
        if not (self._host_available() and sub_run_id and process_id):
            return
        self.emit({"op": "sub_run_stop_process", "sub_run_id": sub_run_id, "process_id": process_id})

    def sub_run_wait_process(self, sub_run_id, process_id, *, timeout=None) -> dict:
        if not (self._host_available() and sub_run_id and process_id):
            return {"ok": False, "rc": -1}
        budget = 3600.0 if timeout is None else float(timeout)
        return self.emit_and_wait(
            {"op": "sub_run_wait_process", "sub_run_id": sub_run_id,
             "process_id": process_id, "timeout": budget},
            wait_op="ack_sub_run_wait_process", timeout=budget + 30.0,
        )

    def sub_run_expose_port(self, sub_run_id, port) -> dict:
        if not (self._host_available() and sub_run_id):
            return {"ok": False}
        return self.emit_and_wait(
            {"op": "sub_run_expose_port", "sub_run_id": sub_run_id, "port": int(port)},
            wait_op="ack_sub_run_expose_port",
        )

    def sub_run_open_terminal(self, sub_run_id, command, *, cwd=None, env=None) -> dict:
        if not (self._host_available() and sub_run_id):
            return {}
        ack = self.emit_and_wait(
            {"op": "sub_run_open_terminal", "sub_run_id": sub_run_id,
             "command": list(command), "cwd": cwd or "", "env": dict(env or {})},
            wait_op="ack_sub_run_open_terminal",
        )
        if not ack.get("ok", False):
            return {}
        return {
            "session_id": ack.get("session_id", ""),
            "ws_path": ack.get("ws_path", ""), "token": ack.get("token", ""),
        }

    def sub_run_put_files(self, sub_run_id, files) -> None:
        if not (self._host_available() and sub_run_id):
            return
        self.emit_and_wait(
            {"op": "sub_run_put_files", "sub_run_id": sub_run_id, "files": _encode_files(files)},
            wait_op="ack_sub_run_put_files",
        )

    def sub_run_read_file(self, sub_run_id, path) -> dict:
        if not (self._host_available() and sub_run_id):
            return {"ok": False}
        return self.emit_and_wait(
            {"op": "sub_run_read_file", "sub_run_id": sub_run_id, "path": path},
            wait_op="ack_sub_run_read_file",
        )

    def sub_run_delete_file(self, sub_run_id, path) -> None:
        if not (self._host_available() and sub_run_id):
            return
        self.emit_and_wait(
            {"op": "sub_run_delete_file", "sub_run_id": sub_run_id, "path": path},
            wait_op="ack_sub_run_delete_file",
        )

    def sub_run_list_files(self, sub_run_id) -> list:
        if not (self._host_available() and sub_run_id):
            return []
        ack = self.emit_and_wait(
            {"op": "sub_run_list_files", "sub_run_id": sub_run_id},
            wait_op="ack_sub_run_list_files",
        )
        files = ack.get("files")
        return files if isinstance(files, list) else []

    def sub_run_snapshot(self, sub_run_id) -> dict:
        if not (self._host_available() and sub_run_id):
            return {}
        ack = self.emit_and_wait(
            {"op": "sub_run_snapshot", "sub_run_id": sub_run_id},
            wait_op="ack_sub_run_snapshot",
        )
        snap = ack.get("snapshot")
        return snap if isinstance(snap, dict) else {}

    # ──────────────────────────────────────────────────────────────────
    # Environments — environment side (this run serves its parent).
    #
    # register declares the contract; poll long-waits for the next parent
    # request; reply sends a handler's result back. Mirrors the user-message
    # poll channel. Dev-mode safe (poll returns None so the serve loop idles).
    # ──────────────────────────────────────────────────────────────────

    def serve_environment_register(self, spec: dict) -> None:
        if not self._host_available():
            return
        self.emit_and_wait(
            {"op": "serve_environment_register", "spec": dict(spec or {})},
            wait_op="ack_serve_environment_register",
        )

    def serve_environment_poll(self, timeout: float = 30.0) -> Optional[dict]:
        if not self._host_available():
            return None
        ack = self.emit_and_wait(
            {"op": "serve_environment_poll", "timeout": float(timeout)},
            wait_op="ack_serve_environment_poll", timeout=float(timeout) + 30.0,
        )
        req = ack.get("request")
        return req if isinstance(req, dict) else None

    def serve_environment_reply(self, request_id: str, result: dict) -> None:
        if not self._host_available():
            return
        self.emit({
            "op": "serve_environment_reply",
            "request_id": request_id,
            "result": dict(result or {}),
        })

    # ──────────────────────────────────────────────────────────────────
    # Subprocess streaming + workspace snapshot
    # ──────────────────────────────────────────────────────────────────

    def run_streamed_subprocess(
        self,
        command,
        *,
        turn_id: Optional[str] = None,
        timeout: int = 120,
        cwd: Optional[str] = None,
        shell: bool = False,
        emit_bash_stdout: bool = True,
        emit_text_delta: bool = False,
        print_stdout: bool = True,
    ) -> tuple[int, str]:
        """Spawn + stream a subprocess. Returns ``(returncode, full_output)``.

        Cooperative cancellation: ``self.cancelled`` polled per line; on
        True the child is ``terminate``d. On timeout it is ``kill``ed.
        """
        if cwd is None:
            cwd = self.workspace
        collected: list[str] = []
        proc: Optional[subprocess.Popen] = None
        start_ts = time.time()

        try:
            proc = subprocess.Popen(
                command,
                shell=shell,
                cwd=cwd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
        except FileNotFoundError as exc:
            return -1, f"(command not found: {exc})"
        except Exception as exc:
            return -1, f"(spawn error: {exc})"

        assert proc.stdout is not None
        try:
            for raw in proc.stdout:
                line = raw.rstrip("\n")
                collected.append(line)
                if turn_id and emit_bash_stdout:
                    try:
                        self.stream_event(turn_id, {
                            "type": "bash_stdout",
                            "turn_id": turn_id,
                            "text": line,
                        })
                    except Exception:
                        pass
                if turn_id and emit_text_delta:
                    try:
                        self.stream_event(turn_id, {
                            "type": "text_delta",
                            "turn_id": turn_id,
                            "text": line + "\n",
                        })
                    except Exception:
                        pass
                if print_stdout:
                    print(line, flush=True)
                if self.cancelled:
                    try:
                        proc.terminate()
                    except ProcessLookupError:
                        pass
                    collected.append("(interrupted by user)")
                    break
                if time.time() - start_ts > timeout:
                    try:
                        proc.kill()
                    except ProcessLookupError:
                        pass
                    collected.append(f"(timed out after {timeout}s)")
                    break
        finally:
            if proc.poll() is None:
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    try:
                        proc.kill()
                    except ProcessLookupError:
                        pass
                    try:
                        proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        pass

        rc = proc.returncode if proc is not None else -1
        return rc, "\n".join(collected)

    def snapshot_workspace(
        self,
        *,
        skip_dirs: Optional[set[str]] = None,
    ) -> dict[str, str]:
        """``{relpath: sha256_hex}`` for every workspace file. Pair with a
        second snapshot to detect what changed."""
        if skip_dirs is None:
            skip_dirs = {".git", "node_modules", ".venv", "__pycache__"}
        skip_dirs = set(skip_dirs) | {".colreserved"}
        result: dict[str, str] = {}
        ws = self.workspace
        if not os.path.isdir(ws):
            return result
        for root, dirs, files in os.walk(ws):
            dirs[:] = [d for d in dirs if d not in skip_dirs]
            for fname in files:
                abs_path = os.path.join(root, fname)
                rel = os.path.relpath(abs_path, ws).replace("\\", "/")
                try:
                    with open(abs_path, "rb") as fh:
                        result[rel] = hashlib.sha256(fh.read()).hexdigest()
                except OSError:
                    continue
        return result


# ──────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────


def _parse_schema_values(raw: str) -> dict:
    """Parse a ``.set_yaml`` / ``.yaml`` schema-form file and merge
    ``fields:`` defaults with the ``values:`` block. Plain YAML maps
    pass through unchanged."""
    if not raw.strip():
        return {}
    try:
        import yaml
    except ImportError:
        return {}
    try:
        parsed = yaml.safe_load(raw)
    except yaml.YAMLError:
        return {}
    if not isinstance(parsed, dict):
        return {}
    values = parsed.get("values") if isinstance(parsed.get("values"), dict) else {}
    fields = parsed.get("fields") if isinstance(parsed.get("fields"), list) else []
    if fields or values:
        out: dict = {}
        for field in fields:
            if isinstance(field, dict) and isinstance(field.get("key"), str) and "default" in field:
                out[field["key"]] = field["default"]
        out.update(values)
        return out
    return parsed


__all__ = [
    "HostBridge",
    "IPCDisconnectedError",
    "IPCError",
    "IPCNakError",
    "IPCTimeoutError",
    "Message",
    "_StopRequested",
]
