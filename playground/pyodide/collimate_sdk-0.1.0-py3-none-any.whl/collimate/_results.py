# SPDX-License-Identifier: Apache-2.0
"""Shared, dependency-light result/spec types for running a generator.

This is a **leaf** module: it imports nothing from :mod:`collimate.native`
or :mod:`collimate.testing`, so both can import it without a cycle. It
defines the single result abstraction returned by every way of running a
generator — the host-free harness (:func:`collimate.testing.run_generator`)
and, in the composition API, ``gen.call`` / ``GeneratorHandle.wait`` — plus
the file (de)serialisation helpers the host-IPC path and the in-process
path share.

Re-exported (same object identity) from :mod:`collimate.native` (so
``gen.GeneratorResult`` resolves) and from :mod:`collimate.testing`.
"""
from __future__ import annotations

import base64
from dataclasses import dataclass, field
from typing import Optional


# ---------------------------------------------------------------------------
# File (de)serialisation across IPC / journals
# ---------------------------------------------------------------------------


def _encode_files(files: Optional[dict]) -> dict:
    """Encode a ``{path: str | bytes}`` mapping to a JSON-safe
    ``{path: {"text" | "b64": ...}}``.

    ``str`` values ride as ``{"text": s}``; ``bytes`` as
    ``{"b64": base64}``. The inverse is :func:`_decode_files`. Used wherever
    file contents cross a JSON boundary (host sub-run IPC, subprocess
    journals)."""
    out: dict = {}
    for path, content in (files or {}).items():
        key = path if isinstance(path, str) else str(path)
        if isinstance(content, bytes):
            out[key] = {"b64": base64.b64encode(content).decode("ascii")}
        elif isinstance(content, str):
            out[key] = {"text": content}
        else:
            out[key] = {"text": str(content)}
    return out


def _decode_files(encoded: Optional[dict]) -> dict:
    """Inverse of :func:`_encode_files`. Tolerant: a bare string/None entry
    decodes to text, a bad base64 payload to empty bytes."""
    out: dict = {}
    for path, payload in (encoded or {}).items():
        if not isinstance(payload, dict):
            out[path] = "" if payload is None else str(payload)
            continue
        if "b64" in payload:
            try:
                out[path] = base64.b64decode(payload["b64"])
            except (ValueError, TypeError):
                out[path] = b""
        else:
            out[path] = payload.get("text", "")
    return out


# ---------------------------------------------------------------------------
# Result / spec dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CellRecord:
    """A cell a run produced: the placeholder update, or a side/stack cell."""

    kind: str  # "update" | "stack"
    name: Optional[str] = None
    summary: Optional[str] = None
    pinned: Optional[str] = None
    files: dict = field(default_factory=dict)  # path -> str|bytes at emit time


@dataclass(frozen=True)
class Endpoint:
    """A live endpoint a (daemon) run exposed — a bound port or a terminal."""

    kind: str  # "http" | "terminal"
    name: str = ""
    url: Optional[str] = None
    port: Optional[int] = None
    path: str = ""
    session_id: Optional[str] = None


@dataclass(frozen=True)
class GeneratorResult:
    """What a generator run produced.

    The single result abstraction returned by BOTH the host-free harness
    (:func:`collimate.testing.run_generator`) and the composition API
    (``gen.call`` / ``GeneratorHandle.wait``)."""

    ok: bool
    files: dict = field(default_factory=dict)  # final output-cell files (the "result")
    name: Optional[str] = None  # last update()/final cell name
    summary: Optional[str] = None
    cells: list = field(default_factory=list)  # ordered: every update() + create_stack_cell()
    endpoints: list = field(default_factory=list)  # ports/terminals bound (daemons)
    tier_b_calls: list = field(default_factory=list)  # recorded serve_port/terminal/...
    # (host-free harness only; [] for host sub-runs)
    logs: list = field(default_factory=list)  # gen.log lines
    status: Optional[str] = None  # last gen.status string
    error: Optional[str] = None  # exception message, None if ok
    traceback: Optional[str] = None  # full traceback when not ok

    def raise_for_status(self) -> None:
        """Raise ``RuntimeError`` when the run failed (``ok`` is False)."""
        if not self.ok:
            msg = self.error or "generator run failed"
            if self.traceback:
                msg = f"{msg}\n{self.traceback}"
            raise RuntimeError(msg)


@dataclass(frozen=True)
class EnvironmentSpec:
    """The contract an ``environment`` generator offers — what a worker can
    rely on **before** spawning it (read from ``GeneratorInfo.environment``)
    and on the live handle via ``handle.capabilities``.

    Two planes: the **workspace plane** (``files``, host-serviced and
    guaranteed read-write) and the **execution plane** (``exec`` /
    ``exec_background`` / ``expose_port`` are the guaranteed core; ``terminals``
    / ``watch`` / ``concurrent_exec`` are declared extras)."""

    exec: bool = True
    exec_background: bool = True
    expose_port: bool = True
    files: str = "read-write"  # "read-write" | "none"
    terminals: int = 0  # max concurrent worker-opened PTYs (0 = none)
    watch: bool = False  # push file-change events (else pull via snapshot)
    concurrent_exec: bool = False  # exec/exec_background may run in parallel


@dataclass(frozen=True)
class Request:
    """One parent→environment request handed to a ``gen.serve_environment``
    handler. Pure data — the handler **returns** its result; the serve loop
    sends the reply. ``kind`` selects which fields are meaningful:

    - ``"exec"`` / ``"exec_background"`` → ``command`` (+ ``cwd``, ``env``, ``timeout``)
    - ``"expose_port"`` → ``port``
    - ``"open_terminal"`` → ``command`` (+ ``cwd``, ``env``)
    - ``"stop_process"`` → ``process_id``
    """

    kind: str
    command: Optional[list] = None
    cwd: str = ""
    env: dict = field(default_factory=dict)
    port: Optional[int] = None
    process_id: Optional[str] = None
    timeout: Optional[float] = None


@dataclass(frozen=True)
class GeneratorInfo:
    """Metadata for one discoverable generator (composition listing)."""

    id: str
    name: str = ""
    summary: str = ""
    group: Optional[str] = None  # source-cell name this generator lives in
    type: list = field(default_factory=list)  # ["modify","create"] subset
    daemon: bool = False  # long-lived (serve_port/terminal) — spawn, don't call
    chat: bool = False
    ephemeral: bool = False  # throwaway live session — absent from the DAG history
    min_inputs: int = 0
    max_inputs: int = 0
    prompt_intent: Optional[str] = None
    prompt_required: bool = False
    environment: Optional[EnvironmentSpec] = None  # the contract, when this is an environment


@dataclass(frozen=True)
class RendererCheck:
    """Result of compiling a renderer (``gen.check_renderer``)."""

    ok: bool
    errors: list = field(default_factory=list)
    warnings: list = field(default_factory=list)


# ---------------------------------------------------------------------------
# Ack -> result decoder (shared by the host sub-run path)
# ---------------------------------------------------------------------------


def _result_from_ack(ack: Optional[dict]) -> GeneratorResult:
    """Build a :class:`GeneratorResult` from a ``sub_run_wait`` ack dict.

    Tolerant of missing keys so a partial/legacy ack still yields a usable
    result. File contents arrive in the :func:`_encode_files` shape."""
    ack = ack or {}
    cells = [
        CellRecord(
            kind=c.get("kind", "update"),
            name=c.get("name"),
            summary=c.get("summary"),
            pinned=c.get("pinned"),
            files=_decode_files(c.get("files")),
        )
        for c in (ack.get("cells") or [])
        if isinstance(c, dict)
    ]
    endpoints = [
        Endpoint(
            kind=e.get("kind", "http"),
            name=e.get("name", ""),
            url=e.get("url"),
            port=e.get("port"),
            path=e.get("path", ""),
            session_id=e.get("session_id"),
        )
        for e in (ack.get("endpoints") or [])
        if isinstance(e, dict)
    ]
    statuses = ack.get("statuses")
    status = statuses[-1] if isinstance(statuses, list) and statuses else ack.get("status")
    return GeneratorResult(
        ok=bool(ack.get("ok", False)),
        files=_decode_files(ack.get("files")),
        name=ack.get("name"),
        summary=ack.get("summary"),
        cells=cells,
        endpoints=endpoints,
        tier_b_calls=list(ack.get("tier_b_calls") or []),
        logs=list(ack.get("logs") or []),
        status=status,
        error=ack.get("error"),
        traceback=ack.get("traceback"),
    )


def _result_to_ack(result: GeneratorResult) -> dict:
    """Serialise a :class:`GeneratorResult` to the ``sub_run_wait`` ack
    shape (inverse of :func:`_result_from_ack`). Used by the in-process
    composition stub so a stubbed sub-run round-trips through the same
    decoder the host path uses."""
    return {
        "ok": result.ok,
        "files": _encode_files(result.files),
        "name": result.name,
        "summary": result.summary,
        "cells": [
            {
                "kind": c.kind, "name": c.name, "summary": c.summary,
                "pinned": c.pinned, "files": _encode_files(c.files),
            }
            for c in result.cells
        ],
        "endpoints": [
            {
                "kind": e.kind, "name": e.name, "url": e.url,
                "port": e.port, "path": e.path, "session_id": e.session_id,
            }
            for e in result.endpoints
        ],
        "tier_b_calls": list(result.tier_b_calls),
        "logs": list(result.logs),
        "statuses": [result.status] if result.status else [],
        "error": result.error,
        "traceback": result.traceback,
    }


def _env_spec_from_dict(d) -> Optional[EnvironmentSpec]:
    """Normalise a manifest/host ``environment`` value to an
    :class:`EnvironmentSpec`. ``None``/falsy → not an environment; ``True`` or a
    mapping → an environment (core capabilities default on; extras from the
    mapping). An empty mapping ``{}`` still means an environment (core only) —
    only ``None``/``False`` mean 'not an environment'."""
    if d is None or d is False:
        return None
    if d is True:
        d = {}
    if not isinstance(d, dict):
        return None
    return EnvironmentSpec(
        exec=bool(d.get("exec", True)),
        exec_background=bool(d.get("exec_background", True)),
        expose_port=bool(d.get("expose_port", True)),
        files=str(d.get("files", "read-write")),
        terminals=int(d.get("terminals", 0) or 0),
        watch=bool(d.get("watch", False)),
        concurrent_exec=bool(d.get("concurrent_exec", False)),
    )


def _info_from_dict(d: dict) -> GeneratorInfo:
    """Build a :class:`GeneratorInfo` from a host ``list_generators`` entry."""
    return GeneratorInfo(
        id=str(d.get("id", "")),
        name=str(d.get("name", "")),
        summary=str(d.get("summary", "")),
        group=d.get("group"),
        type=list(d.get("type") or []),
        daemon=bool(d.get("daemon", False)),
        chat=bool(d.get("chat", False)),
        ephemeral=bool(d.get("ephemeral", False)),
        min_inputs=int(d.get("min_inputs", 0) or 0),
        max_inputs=int(d.get("max_inputs", 0) or 0),
        prompt_intent=d.get("prompt_intent"),
        prompt_required=bool(d.get("prompt_required", False)),
        environment=_env_spec_from_dict(d.get("environment")),
    )


def _endpoint_from_dict(d: dict) -> Endpoint:
    return Endpoint(
        kind=d.get("kind", "http"), name=d.get("name", ""), url=d.get("url"),
        port=d.get("port"), path=d.get("path", ""), session_id=d.get("session_id"),
    )


__all__ = [
    "CellRecord",
    "Endpoint",
    "EnvironmentSpec",
    "GeneratorInfo",
    "GeneratorResult",
    "RendererCheck",
    "Request",
]
