# SPDX-License-Identifier: Apache-2.0
"""The ``.chatlog`` text transcript format (one place, both sides).

A ``.chatlog`` is the **durable, human-readable & editable** record of a
chat — a markdown document with ``### Role`` section headers. It is the
source of truth at close and the seed for resuming a conversation; the
``.chatlive`` pointer drives the *live* streaming experience and disappears
when the run ends.

Format::

    <!-- collimate-chatlog v1 -->

    ### User
    hello there

    ### Assistant
    hi — how can I help?

Rules (kept deliberately forgiving so a human can edit the file by hand):

* A line matching ``### <Role>`` (case-insensitive ``user``/``assistant``/
  ``system``) starts a new message; everything up to the next header is its
  content (trailing/leading blank lines trimmed).
* The ``<!-- collimate-chatlog vN -->`` marker is optional on read.
* Unknown role headers are skipped (their body is dropped) so a stray
  ``### Notes`` a user types doesn't corrupt the parse.

``parse_chatlog`` and ``serialize_chatlog`` round-trip: ``parse(serialize(m))``
yields messages equal to ``m`` (modulo timestamps, which the text format does
not carry).
"""
from __future__ import annotations

import re

from collimate._host import Message

MARKER = "<!-- collimate-chatlog v1 -->"

_ROLE_LABELS = {"user": "User", "assistant": "Assistant", "system": "System"}
_HEADER_RE = re.compile(r"^###\s+(user|assistant|system)\s*$", re.IGNORECASE)


def serialize_chatlog(messages: list[Message]) -> str:
    """Render messages to the ``.chatlog`` text format."""
    out: list[str] = [MARKER, ""]
    for m in messages:
        label = _ROLE_LABELS.get((m.role or "").lower())
        if label is None:
            continue
        out.append(f"### {label}")
        out.append("")
        out.append((m.content or "").strip("\n"))
        out.append("")
    return "\n".join(out).rstrip("\n") + "\n"


def parse_chatlog(text: str) -> list[Message]:
    """Parse ``.chatlog`` text back into messages. Tolerant of hand edits."""
    if not text:
        return []
    messages: list[Message] = []
    role: str | None = None
    body: list[str] = []

    def _flush() -> None:
        if role is not None:
            messages.append(Message(role=role, content="\n".join(body).strip("\n")))

    for line in text.splitlines():
        m = _HEADER_RE.match(line.strip())
        if m:
            _flush()
            role = m.group(1).lower()
            body = []
            continue
        if role is not None:
            body.append(line)
    _flush()
    return messages


__all__ = ["MARKER", "parse_chatlog", "serialize_chatlog"]
