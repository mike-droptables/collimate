# SPDX-License-Identifier: Apache-2.0
"""Per-field-type "empty value" semantics for ``.set_yaml`` schema forms.

Public and stable — the single Python source of truth for what counts
as an *empty* field value. The SDK lint derives its
required-on-checkbox check from it and the app's ``api/config_tags.py``
builds the required-field run gate on it. The TypeScript mirrors (the
schema_form renderer's ``validate`` and the frontend's ``setYaml.ts``)
are pinned to the same behavior by the cross-language fixture at
``shared/empty-values-contract.json`` — when the semantics change,
update that table first, then every implementation against it.
"""

from __future__ import annotations

__all__ = ["is_empty", "type_empty_default"]

# Base value per field type before the defaults overlay. checkbox is
# False — never empty — everything else starts at None.
_EMPTY_BASE: dict = {"checkbox": False}


def type_empty_default(field_type):
    """The base value a field of ``field_type`` holds before any
    ``default:`` or ``values:`` overlay — the bottom layer of the value
    resolution formula. ``False`` for checkbox (a checkbox always holds
    a real value), ``None`` for everything else, so the base reads as
    empty per :func:`is_empty` for every type but checkbox.
    """
    return _EMPTY_BASE.get(field_type)


def is_empty(value, field_type) -> bool:
    """Single per-type "empty value" rule. ``0``/``False`` are NOT empty.

    text/textarea: ``None`` | ``""`` (trimmed) — number: ``None`` —
    dropdown: ``None`` | ``""`` — checkbox: never — list: ``None`` |
    ``[]`` — object: ``None``. Unknown/missing types get text
    semantics (matches schema_form's text fallback).
    """
    if field_type == "checkbox":
        return False
    if value is None:
        return True
    if field_type == "number":
        return False
    if field_type == "dropdown":
        return value == ""
    if field_type == "list":
        return isinstance(value, list) and len(value) == 0
    if field_type == "object":
        return False
    # text / textarea / anything else string-shaped
    return isinstance(value, str) and value.strip() == ""
