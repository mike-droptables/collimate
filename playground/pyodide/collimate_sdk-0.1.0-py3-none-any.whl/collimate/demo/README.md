# demo/ — playground (WASM) runtime

This directory is the **demo/playground** runtime, kept separate from the
canonical SDK on purpose. The canonical way to author for Collimate is the
native runtime — generators live at [`../generators/`](../generators/),
renderers at [`../renderers/`](../renderers/), and the authoring guides at
[`../shared/docs/`](../shared/docs/). **You do not need anything in `demo/`
to write a normal generator or renderer.**

The Collimate playground compiles the FastAPI backend to WebAssembly via
Pyodide and runs entirely in the browser — no server, no subprocess, no
Docker. That sandbox can only expose a subset of the SDK, so it has its own
generator set and its own authoring guide:

- [`generators/`](./generators/) — the WASM/pyodide generator set
  (`pydantic-ai-slim`, CORS-safe providers, one-cell-per-run). A demo mirror
  of the core native generators.
- [`docs/how-to-write-a-wasm-generator.md`](./docs/how-to-write-a-wasm-generator.md)
  — the full WASM authoring contract (system prompt for the
  `wasm-generator-builder`).
- [`docs/wasm-api-delta.md`](./docs/wasm-api-delta.md) — how the `gen.*`
  surface differs under WASM vs. the canonical native reference.

The WASM runtime *engine* itself lives in `src/collimate/wasm*.py` (imported
by the `gen` shim under pyodide) — it stays with the SDK source because it's
import-resolved, but it is demo-only and not part of the canonical authoring
surface.

The release builder ships this tree as `wasm.colgen` / `wasm.colrend`
(see `releases.yaml`, the `gen_root: demo/generators` bundle) and the
playground build (`collimatedev/build/assemble_site.sh`) seeds it as the
playground's generator set.
