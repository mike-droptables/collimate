# How to write a WASM generator

WASM generators run inside the browser. The Collimate playground build compiles the FastAPI backend to WebAssembly via Pyodide and loads it on the page — no server, no subprocess, no Docker. Generators are imported and called **directly in the same Python event loop as the host**.

The runtime API is a single top-level package: **`gen`**. A generator imports it and calls `gen.*` to read inputs, stage output files, push cells, request user input, and resolve API keys. There is no `ctx` argument — the host hydrates the `gen` singleton before calling `run()`.

WASM (demo/playground) generators live under `demo/generators/`, kept separate from the canonical native `generators/` tree. This doc is the full contract; it is also loaded at runtime as the system prompt for the `wasm-generator-builder` scaffolding agent, so style and idioms here are reflected in every generator the LLM produces.

---

## 1. File layout

One generator = one directory:

```
demo/generators/my-gen/
├── manifest.gen_yaml          # identity + schema (required)
├── my_gen.py                  # the run() function (required)
└── pydantic-config.set_yaml   # optional draft file for user-editable knobs
```

The host imports `my_gen.py` via `importlib` and calls `run()` (no arguments).

---

## 2. Minimal generator

```python
# my_gen.py
import gen

async def run():
    name = gen.config("pydantic-config.set_yaml").get("name", "world")
    gen.update_file("greeting.md", f"# Hello {name}\n")
    await gen.update(name="Greeting", summary=f"Greeted {name}")
```

```yaml
# manifest.gen_yaml
id: "wasm-hello"
name: "Hello"
type: ["create"]
version: "0.1.0"
summary: "Write a greeting file."
entrypoint: "my_gen.py"
prompt_intent: "Who to greet"
inputs:
  cells: { min: 0, max: 0 }   # no input → a fresh cell from scratch
config_tags:
  default: {}   # required whenever the generator takes config (see §4)
```

That's the whole contract. Demo/playground generators live under `demo/generators/`; the playground build seeds them into the pyodide runtime — there's no per-manifest `runtime:` field.

---

## 3. The `run()` contract

```python
async def run() -> None: ...   # canonical
def run() -> None: ...         # also accepted for trivial cases
```

The function takes **no arguments**. The host hydrates the `gen` singleton with the run's state before calling it. Returning produces an empty placeholder cell **unless** the generator called `gen.update()` at least once — by design.

`async def` is strongly preferred. Pyodide runs on a single thread; `asyncio.to_thread` parks forever, so any blocking I/O has to be cooperatively scheduled.

### Cancellation

```python
if gen.cancelled:
    return  # or: break out of a loop
```

`gen.cancelled` flips to True when the user clicks Stop. Long-running generators should poll it between chunks of work.

---

## 4. Manifest fields

```yaml
id: "wasm-my-gen"           # unique, lowercase, hyphenated
name: "My Generator"         # display name in picker
version: "0.1.0"
summary: "One-line description for the picker."   # required; 1–2 sentences
entrypoint: "my_gen.py"

prompt_intent: "What the user types into the picker textarea"

# Optional, default false. When true, the run is blocked until the
# prompt is non-empty (after trimming) — enforced by both pickers and
# by the server. Only legal alongside `prompt_intent` (lint error
# otherwise).
prompt_required: true

# Named sets of default input values (prompt + .set_yaml fields),
# shown as selectable chips in both pickers. **Required whenever the
# generator "takes config"** — i.e. it has a `prompt_intent` or at
# least one `.set_yaml` in `draft_files` — and must then contain a
# `default` tag. `default: {}` means "pure field defaults".
#
# Tag names must match ^[A-Za-z0-9][A-Za-z0-9 ._-]{0,31}$ (1–32 chars).
# Each tag body allows exactly two keys, both optional:
#   prompt — string seeded into the picker's prompt box when the tag
#            is selected.
#   files  — mapping of .set_yaml draft-file path → **sparse overlay**:
#            only the field keys it names are overridden; every other
#            field keeps its resolved default. Keys must be .set_yaml
#            members of `draft_files`, and each field key must exist in
#            that file's `fields:` list.
# Mapping order = display order; users can add/edit/delete tags from
# the UI (those edits persist to the channel's copy, not this file).
config_tags:
  default: {}
  "small model":
    prompt: "Summarise the inputs"
    files:
      pydantic-config.set_yaml:
        model: llama3.1-8b
        max_tokens: 1024

# How the generator is invoked. **Required.** A list of 1–2 modes, each
# drawn from {"modify", "create"}. Drives which picker(s) the generator
# appears in and what inputs it receives; the input shape for `create`
# is read off `inputs.cells` (see below):
#   modify    — rewrites the single current cell in place. Takes exactly
#               1 input cell (the current cell). Surfaces in the per-cell
#               button. No new cell is created at run start; 'update'
#               emissions append versions. Implicit bounds: 1/1.
#   create    — produces fresh cell(s). The input shape comes from
#               `inputs.cells`: no input (min/max 0; surfaces in the
#               top-bar button), a single cell (min/max 1), or a stack of
#               cells (e.g. min 1/2, max 99 — min may be 0 for an
#               optional stack). A fresh running cell is created.
#
# Declare every mode the generator supports. The host injects the mode
# the user picked as ``gen.invocation_type`` so the run can branch.
type: ["create"]

# Whether this is a chat-shaped (long-lived, conversational) run.
# Default: false. Set to true for daemon-style generators that loop
# over user messages via `gen.chat_loop()`. The runtime infers Stop
# semantics, picker routing, log-drawer behaviour, and history
# persistence from this one bit.
chat: false

# Optional, default false. Marks a throwaway live session whose output
# cell never enters the DAG history; the cell offers "close" (stop +
# remove) instead of "stop".
ephemeral: false

# Optional: files seeded into .colreserved/config/files/ before the
# run. The picker renders a form from any .set_yaml schema; the user
# fills it, the run starts.
draft_files:
  - "pydantic-config.set_yaml"

# Bounds on the number of input cells. For `create`, this is what picks
# the input shape (no input vs. single cell vs. stack). When omitted,
# each declared mode contributes its implicit bounds and the runtime
# takes the union (modify → 1/1, create → defaults to a stack 1/99).
# When declared, every declared mode's per-mode rule must hold:
#   "modify" in type   — bounds must include 1 (min ≤ 1 ≤ max), i.e. the
#                        single current cell
#   "create" in type   — min ≥ 0; the bounds choose the shape:
#                        no input (min/max 0), a single cell (min/max 1),
#                        or a stack (e.g. min 1/2, max 99; min may be 0
#                        for an optional stack)
inputs:
  cells:
    min: 1
    max: 99
```

That's the entire schema. Anything else is ignored (and lints as an unknown field).

### Removed fields

The following used to exist and are no longer accepted:

- `runtime` — the runtime is folder-based: demo/playground generators under
  `demo/generators/` run in the WASM runtime; the canonical native generators
  under `generators/` run native.
- `new_opt_in` — superseded by the `type` array. A generator that wants to
  appear in both the per-cell and top-bar pickers now declares
  `type: ["modify", "create"]`.
- `default_route`, `summary_file` — vestigial; both dropped.
- `output: { default, supports }` — the host no longer gates emissions by
  declared kind. Call `gen.update()` and/or `gen.create_stack_cell()` as the
  run requires.
- `execution_mode`, `live_chat_mode` — replaced by `chat: true|false`.
- `live_files_mode` — mid-run file editing is native-only.
- `output_mode` — replaced by free use of `gen.update` / `gen.create_stack_cell`.
- `pinned` — now a per-call argument to `gen.update(...)` / `gen.create_stack_cell(...)`.
- `keys` — key resolution is live (`gen.api_key`); no pre-flight gate.
- `parameters`, `pickoptions_file`, `settings_file`, `auto_dismiss_log` — superseded by `draft_files` + the new SDK.

Old manifests carrying these will lint as `unknown-field` warnings; new generators must not declare them.

---

## 5. Settings schema (`.set_yaml`)

Generators that need user-editable knobs ship a draft file with a schema-form layout:

```yaml
# pydantic-config.set_yaml
fields:
  - key: provider
    type: dropdown
    label: Provider
    description: Which LLM provider to call (only CORS-safe providers work in the browser).
    default: cerebras
    options:
      - { value: cerebras, label: Cerebras }
      - { value: groq,     label: Groq     }
      - { value: openrouter, label: OpenRouter }

  - key: model
    type: text
    label: Model
    description: Provider-specific model name. Cerebras uses `llama3.1-8b`, Groq uses `openai/gpt-oss-20b`, etc.
    default: "llama3.1-8b"
    required: true

  - key: max_tokens
    type: number
    label: Max output tokens
    default: 2048
    min: 256
    max: 16384
    required: true

  - key: system_prompt
    type: textarea
    label: System prompt
    default: "You are a concise assistant."
```

Generators read this back with one line:

```python
cfg = gen.config("pydantic-config.set_yaml")
provider = cfg.get("provider", "cerebras")
system_prompt = cfg.get("system_prompt", "")
```

`gen.config(name)` auto-detects by extension: `.set_yaml` / `.yaml` / `.yml` parse as YAML and merge `fields:` defaults with the `values:` block (which the picker writes when the user edits the form). `.json` parses as JSON. Anything else returns the raw string.

### Field types

| Type | Purpose | Type-specific options |
|---|---|---|
| `text` | single-line input | `placeholder`, `multiline` |
| `textarea` | multi-line input | (same as text) |
| `number` | numeric input | `min`, `max`, `step`, `widget: slider` |
| `dropdown` | enum selection | `options: [{value, label, description}]` |
| `checkbox` | true/false | — |
| `list` | repeated subform | `item: { fields: [...] }` |
| `object` | grouped subform | `fields: [...]` |

Every field accepts: `key`, `label`, `description`, `default`, `required`, `advanced` (collapse under "Advanced" expander), `show_when` (conditional visibility — `{earlierFieldKey: expectedValue}`).

### Required fields and the run gate

`required: true` on a field is a **run gate**, not just a styling flag: both
pickers and the server refuse to start a run while a required field's
effective value is empty. "Empty" is defined per field type:

| Field type | Empty when |
|---|---|
| `text` / `textarea` | `null`, or `""` after trimming |
| `number` | `null` |
| `dropdown` | `null` or `""` |
| `checkbox` | never — a checkbox always holds true/false (`required:` on one is a lint warning) |
| `list` | `null` or `[]` |
| `object` | `null` |
| the prompt | `""` after trimming (gated by the manifest's `prompt_required`) |

`0` and `false` are NOT empty.

### Value resolution

The effective value of each field, for a given config tag, is layered
left-to-right (later wins):

```
per-type empty default  ⊕  field `default:`  ⊕  the file's `values:` block  ⊕  the tag's `files[<path>]` overlay
```

The tag overlay is sparse — it only touches the keys it names. The
effective prompt seeded by a tag is `tag.prompt`, or none when the tag
doesn't set one.

---

## 6. The `gen.*` core surface

These are always available and have no LLM dependency. A pure-Python generator (no API keys, no model) uses only these.

### Inputs

```python
gen.prompt              # str — the picker textarea text
gen.messages            # list[Message] — prior chat history from input cells
gen.cancelled           # bool — Stop button check (poll between chunks)
gen.invocation_type     # str — "modify" | "create", the mode the user
                        # picked. Useful when the manifest's `type` array
                        # lists more than one mode and the run needs to branch.
```

### Reading input cell files

```python
gen.read_input(path)    # str | bytes — utf-8 → str, else bytes
gen.input_files()       # dict[str, str | bytes]
gen.input_groups()      # dict[str, dict[str, str | bytes]] — files split by source cell
                        #   single input  → {"input": {...}}
                        #   multi-input   → {"00_label": {...}, "01_other": {...}}
                        #   paths in each group are relative to the cell root
```

### Reading draft / config files

```python
gen.config(name)        # dict — YAML or JSON, by extension; {} on missing/malformed
```

`gen.config(name)` always returns a dict (matches native), so callers can use `cfg.get(...)` without try/except. Non-dict file content yields `{}`.

### Output stage (file I/O on the cell being written)

The stage starts pre-populated with every input file, so reads "just work" and unwritten input files carry forward to the placeholder.

```python
gen.update_file(path, content)  # content: str | bytes
gen.read_file(path)             # str | bytes — read from stage (input + own writes)
gen.has_file(path)              # collision predicate
gen.list_files()                # sorted staged paths
gen.delete_file(path)            # drop from stage (e.g. don't carry forward)
```

### Cell operations — two only

```python
await gen.update(*, name=None, summary=None, pinned=None)
await gen.create_stack_cell(name, *, summary=None, pinned=None, files=None)
```

`gen.update()` flushes the current stage (files + chat history) as a new **version** of the running cell — each call adds a row to the cell's version chain; the visible cell on the canvas always shows the latest. **May be called many times during a run** — each call refreshes the visible cell live; the host debounces persistence. Maps to the manifest's `output: 'update'` kind.

Calling `update_file()` without ever calling `update()` produces an empty placeholder. Explicit by design.

`gen.create_stack_cell(name, ...)` mints a new cell on the canvas. Used by fan-out generators (e.g. `seed-ideas`) to create N siblings while the running cell holds an index. If `files` is omitted, it snapshots the current stage.

**Where created cells land** is decided by the running cell's placement toggle (user-controlled via the placement chip in the log header; channel default):

| Placement | Where the new cell lands |
|-----------|--------------------------|
| `under`     | appended below the running cell, same stack |
| `new_stack` | first cell of a fresh stack inserted to the right |
| `on_top`    | top of the stack immediately to the right |

There is no `update_cell(cell_id, ...)` escape hatch. Generators that want to "modify an input cell" should declare `type: ["modify"]` (the input cell becomes the running cell), or for `type: ["create"]` carry the input files forward into the running cell and update those.

### Chat history

```python
gen.history.append(role, content)   # role: "user" | "assistant"
gen.history.as_pai()                # translate to pydantic_ai ModelMessage
list(gen.history)                   # iterate (read-only)
```

`history.append()` mutates the in-memory list and marks dirty; the next `gen.update()` flushes it to `.colreserved/.collimate_messages.json` as a memory artifact.

### User input mid-run

```python
async for user_msg in gen.chat_loop():
    # Body runs once per turn. Yields gen.prompt first (if non-empty),
    # then blocks on the user's chat input. Loop exits cleanly on Stop.
    ...

await gen.next_message()    # str | None — one-off polling outside chat_loop
```

### Secrets

```python
await gen.api_key(provider, *, force=False, description="")
# Resolves the API key for "cerebras"/"groq"/"openrouter" and sets the
# standard env var (CEREBRAS_API_KEY etc.) so pydantic_ai's native
# provider lookup picks it up. Pops the in-cell modal when the env
# isn't set. force=True skips the env-var fast path — for auth-retry
# after a 401. Raises gen.Cancelled when the user cancels the modal.

await gen.secret(name, *, prompt_if_missing=False, description="")
# Escape hatch for non-LLM secrets (webhook tokens, custom service
# keys, …). Default: env-var fast path only — empty string when not
# set. prompt_if_missing=True opts into the modal flow.
```

### Status / logging

```python
gen.log(line)           # append to the run log (visible in the events panel)
gen.status(msg)         # set the live status string next to the run row
```

### Exceptions

```python
gen.Cancelled           # raised by api_key / secret on user-cancel
```

---

## 7. The LLM convenience tier (opt-in sugar)

These are the only entries that import `pydantic_ai`. Importing them lazily triggers `ensure_pydantic_ai()` (micropip install + jiter stub + pyfetch transport patch). A non-LLM generator never touches these and never pays the install cost.

```python
agent_obj = await gen.agent(
    *,
    system_prompt="",
    tools=None,
    output_type=None,
    provider=None, model=None, max_tokens=None,  # override pydantic-config.set_yaml
    config_file="pydantic-config.set_yaml",
)
# Reads provider/model/max_tokens from the config file when not
# overridden, calls gen.api_key() to resolve the key, and returns a
# vanilla pydantic_ai.Agent. Call .run() / .run_stream() on it
# directly — we deliberately don't wrap pydantic_ai's surface.

tools = gen.file_tools()
# Returns list/read/write/edit pydantic_ai Tool objects bound to the
# output stage. read_file / list_files see input-cell files (the stage
# is pre-populated); write_file / edit_file mutate the stage so the
# next gen.update() call reflects the agent's edits.

python_tool = gen.python_tool_inline(files=None)
# Returns a pydantic_ai Tool that lets the agent call ``run_python(code)``.
# **Named ``python_tool_inline`` (not ``python_tool``)** to flag that wasm
# runs the agent's Python *inline* in the same Pyodide interpreter as the
# generator — different execution model from the native SDK's
# ``gen.python_tool`` (which spawns a subprocess and diffs the workspace
# snapshot). The code runs against a persistent namespace re-used across
# calls in this run, with helpers pre-bound for cell-file I/O. Top-level
# await is supported (e.g. ``await install("matplotlib")``).
#
# ``files=None`` (default) operates on the singleton stage. Pass an
# explicit dict when running parallel fan-out branches so concurrent
# agents don't trample each other through the singleton.

await gen.bootstrap()
# Call this if you `import pydantic_ai` directly at module top level.
# gen.agent / gen.file_tools / gen.python_tool_inline call it for you,
# so most generators don't need to.
```

### Provider constraint

Only **CORS-safe providers** work in the browser: `cerebras`, `groq`, `openrouter`. Anthropic / OpenAI / Gemini direct endpoints reject browser-origin CORS. Use those through the native runtime, not WASM.

---

## 8. Worked examples

### Example A — pure Python, no LLM (the `merge` generator)

```python
"""Union 2+ input cells into one output cell. Topmost wins on collisions."""
import gen

async def run():
    rows: list[str] = []
    for label, cell_files in gen.input_groups().items():
        rows.append(f"- **{label}**: {len(cell_files)} files")
        for path, content in cell_files.items():
            if not gen.has_file(path):
                gen.update_file(path, content)

    gen.update_file("_merge.md", "# Merge\n\n" + "\n".join(rows) + "\n")
    await gen.update(name="merged", summary=f"merged {len(gen.input_groups())} cells",
                     pinned="_merge.md")
```

Manifest:
```yaml
id: "wasm-merge"
name: "Merge"
type: ["create"]
version: "0.1.0"
summary: "Union 2+ input cells. Topmost wins on filename collisions, no LLM."
entrypoint: "merge.py"
inputs:
  cells:
    min: 2          # a stack of ≥2 input cells
    max: 99
```

### Example B — single-shot LLM agent (modify-files-style)

```python
"""Run an agent over the input cell's files. Carries unedited files forward."""
import gen

async def run():
    cfg = gen.config("pydantic-config.set_yaml")
    if not gen.prompt.strip():
        gen.update_file("error.md", "# No prompt\n\nDescribe what to do.\n")
        await gen.update(summary="empty prompt")
        return

    agent_obj = await gen.agent(
        system_prompt=cfg.get("system_prompt", "")
            + "\n\nEdit files using the read/write/edit tools. "
              "Leave unrelated files alone.",
        tools=gen.file_tools(),
    )

    result = await agent_obj.run(gen.prompt)
    gen.update_file("answer.md", str(result.output))
    await gen.update(summary=str(result.output)[:120])
```

### Example C — daemon chat (live-chat-style)

```python
"""Multi-turn chat with file + python tools. Stop ends the conversation."""
import gen

async def run():
    cfg = gen.config("pydantic-config.set_yaml")
    agent_obj = await gen.agent(
        system_prompt=cfg.get("system_prompt", ""),
        tools=gen.file_tools() + [gen.python_tool_inline()],
    )

    async for user_msg in gen.chat_loop():
        gen.history.append("user", user_msg)
        await gen.update()  # show the user message immediately

        try:
            result = await agent_obj.run(
                user_msg, message_history=gen.history.as_pai()
            )
            answer = str(result.output) or "_(empty response)_"
        except Exception as e:
            answer = f"**Error:** `{e}`"

        gen.history.append("assistant", answer)
        await gen.update()  # show the assistant turn
```

Manifest needs `chat: true`. Chat generators typically declare
`type: ["modify", "create"]` so the per-cell button resumes the chat
against the current cell's prior history *and* the top-bar button can
fire a fresh chat against an empty cell. Pair `create` with `inputs.cells:
{min: 0, max: 0}` so the fresh-chat path takes no input:
```yaml
id: "wasm-live-chat"
name: "Live Chat"
type: ["modify", "create"]
version: "0.1.0"
summary: "Multi-turn pydantic-ai chat with read/write/edit file tools."
entrypoint: "live_chat.py"
prompt_intent: "Next message to the agent"
chat: true
inputs:
  cells: { min: 0, max: 1 }   # 0 → fresh chat; 1 → the modify path
draft_files:
  - "pydantic-config.set_yaml"
config_tags:
  default: {}
```

---

## 9. Pyodide constraints

Things you cannot do in WASM:

- **No threads.** Pyodide's threading module is a stub. `anyio.to_thread.run_sync`, `concurrent.futures`, `subprocess`, `multiprocessing` all raise `RuntimeError: can't start new thread`. Sync `pydantic_ai` tools fall in this trap; that's why `gen.file_tools()` returns async tools.
- **No raw sockets.** `urllib`, `requests`, `httpx` over raw sockets all fail. Use `pyodide.http.pyfetch`. `gen.agent()` configures pydantic_ai to route through `pyfetch` transparently.
- **No subprocess.** No `uv run`, no `os.system`, no Docker. Everything happens in this one Python event loop.
- **CORS-locked HTTP.** Only browser-CORS-safe providers (Cerebras, Groq, OpenRouter) work. Don't try Anthropic, OpenAI, or Gemini direct endpoints.
- **No arbitrary `micropip.install`.** The playground preloads a fixed package set; `gen.bootstrap()` knows how to add `pydantic-ai-slim[openai]`. Other packages may or may not have emscripten wheels.

---

## 10. WASM-vs-native gaps

WASM intentionally has fewer knobs than the native SDK. If your generator needs any of these, target the native runtime:

- **Mid-run file editing** — the native SDK lets the user edit cell files while a run is in flight (`live_files_mode: auto` / `manual`, via `gen.live_files()`). WASM does not.
- **Unlocked chat history** — the native SDK supports re-running from an earlier turn by editing prior messages (`live_chat_mode: unlocked_history`). WASM only supports append-only chat.
- **Docker / sandboxes** — the native SDK can spawn Docker containers (`gen.chat.start_session(image=...)`). WASM cannot.
- **Server-only LLM providers** — Anthropic, OpenAI, Gemini direct endpoints work natively but not in the browser (CORS).

These are runtime-capability limits, not SDK design choices. The `gen.*` API surface is otherwise designed to be uniform across both runtimes; a future native sweep will mirror it.

