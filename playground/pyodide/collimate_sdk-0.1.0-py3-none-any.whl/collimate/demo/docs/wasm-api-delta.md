# WASM API delta (demo/playground runtime)

The canonical `gen.*` surface is documented in
[`../../shared/docs/api-reference.md`](../../shared/docs/api-reference.md).
This file lists only how the **demo/playground WASM runtime**
(`src/collimate/wasm.py`, pyodide, in-browser, ContextVar-scoped stage dict)
differs from it. For the full WASM authoring contract see
[`how-to-write-a-wasm-generator.md`](./how-to-write-a-wasm-generator.md).

WASM mirrors the **Tier A** (core) surface so a generator that uses only
Tier A can run on either runtime unchanged. It does **not** offer the
**Tier B-native** features (subprocess, ports, terminals, Docker,
`request_settings`, `wait_for_action`, raw filesystem access).

## Behavioural differences within Tier A

| Symbol | Native | WASM |
|---|---|---|
| `agent` | Returns `_AutoRetryAgent` (auth-retry wrapper). | Returns a vanilla `pydantic_ai.Agent`. Defaults match the WASM provider mix. |
| `api_key` | Supports the full provider set + concurrency lock. | CORS-locked to `cerebras` / `groq` / `openrouter` — Anthropic / OpenAI / Gemini direct endpoints reject browser-origin CORS. |
| `file_tools` | Same names/shape. | Same names/shape; binary files yield the same `BINARY (N bytes) …` placeholder. |

## WASM-only functions

| Function | Signature | Description |
|---|---|---|
| `python_tool_inline` | `(*, files: dict[str,str\|bytes] \| None = None)` | In-browser inline Python runner (persistent namespace, top-level await). The WASM analogue of native's subprocess-based `python_tool` — different name flags the different execution model. |
| `bootstrap` | `async () -> None` | Install `pydantic_ai` under pyodide + patch the HTTP transport. Called automatically by `agent()` / `file_tools()` / `python_tool_inline()`. |

## Not available under WASM

The Tier B-native functions are absent (calling one raises `AttributeError`
rather than failing deep in a stub): `workspace_path`, `progress`,
`serve_port`, `run_subprocess`, `snapshot`, `terminal`, `stop_terminal`,
`wait_for_action`, `request_settings`, `chat_stream`, `chat_session`,
`chat_turn`, `python_tool`. Also: mid-run file editing (`live_files_mode`)
and unlocked chat history are native-only.
