"""Evaluate Best — independent judgments, then final pick.

Two phases:

  1. Each input cell is judged independently (parallel agent runs).
     The judge sees only that candidate's files and the user's
     criteria. Output: a structured score + reasoning per candidate.
  2. A second agent sees all judgments — but not the files directly —
     and picks one winner.

The output cell carries the winning cell's files verbatim and adds
``why_picked.md`` with the final reasoning. The rankings appear in
``judgments.md``.
"""
from __future__ import annotations

import asyncio

from pydantic import BaseModel, Field

import gen


class Judgment(BaseModel):
    score: int = Field(ge=0, le=100, description="How well this candidate meets the criteria, 0–100.")
    strengths: list[str] = Field(default_factory=list, description="Short bullets of what it does well.")
    weaknesses: list[str] = Field(default_factory=list, description="Short bullets of what it does poorly.")
    summary: str = Field(description="1–2 sentence overall take.")


class Pick(BaseModel):
    winner: str = Field(description="Exact label of the winning candidate, copied from the list.")
    reasoning: str = Field(description="2–6 sentences explaining why this candidate won over the others.")


async def run() -> None:
    cfg = gen.config("pydantic-config.set_yaml")
    system_prompt = (cfg.get("system_prompt") or "").strip()
    criteria = (gen.prompt or "").strip()
    if not criteria:
        # Fail loudly. The picker is the right gate for "describe what
        # the best candidate looks like" — committing a stub cell would
        # surface as a confusing UI lock-up since the renderer-pick
        # path expects a real markdown summary.
        raise ValueError(
            "evaluate-best needs a criteria prompt — describe what the "
            "best candidate should look like in the picker prompt."
        )

    candidates = gen.input_groups()  # {label: {relpath: content}}
    if len(candidates) < 2:
        gen.update_file(
            "why_picked.md",
            "# Need 2+ candidates\n\nAttach at least two input cells.\n",
        )
        await gen.update(name="evaluate-best · too few inputs",
                         summary="Need 2+ inputs",
                         pinned="why_picked.md")
        return

    gen.update_file("why_picked.md", f"_(judging {len(candidates)} candidates…)_\n")
    await gen.update(name=f"evaluate-best · {len(candidates)} candidates",
                     summary=f"{len(candidates)} candidates",
                     pinned="why_picked.md")
    gen.log(f"[evaluate-best] {len(candidates)} candidates, criteria={criteria[:80]!r}")

    judgments = await asyncio.gather(
        *[
            _judge(label, files, criteria, system_prompt)
            for label, files in candidates.items()
        ],
        return_exceptions=True,
    )
    ranked: list[tuple[str, Judgment | BaseException]] = list(
        zip(candidates.keys(), judgments)
    )

    pick = await _pick(ranked, criteria)
    if isinstance(pick, BaseException):
        gen.log(f"[evaluate-best] pick failed: {pick}")
        winner = _heuristic_winner(ranked)
        reasoning = (
            f"Automatic pick (judge call failed: `{pick}`). Chose the "
            "highest-scoring candidate from the independent judgments."
        )
    else:
        winner = (
            pick.winner
            if any(label == pick.winner for label, _ in ranked)
            else _heuristic_winner(ranked)
        )
        reasoning = pick.reasoning

    # Carry the winning candidate's files into the output stage.
    for path, content in candidates.get(winner, {}).items():
        gen.update_file(path, content)
    gen.update_file("why_picked.md", _why_md(winner, reasoning, ranked, criteria))
    gen.update_file("judgments.md", _judgments_md(ranked))

    await gen.update(
        name=f"Winner: {winner}",
        summary=_first_line(reasoning),
        pinned="why_picked.md",
    )


async def _judge(
    label: str,
    files: dict[str, str],
    criteria: str,
    system_prompt: str,
) -> Judgment:
    user = (
        f"## Criteria\n\n{criteria}\n\n"
        f"## Candidate `{label}`\n\n{_preview(files)}\n\n"
        "Produce a Judgment. Be specific."
    )
    agent_obj = await gen.agent(
        system_prompt=system_prompt,
        output_type=Judgment,
    )
    result = await agent_obj.run(user)
    out = getattr(result, "output", None) or getattr(result, "data", None)
    if not isinstance(out, Judgment):
        raise RuntimeError(f"judge returned no structured output for {label}")
    return out


async def _pick(
    ranked: list[tuple[str, Judgment | BaseException]],
    criteria: str,
) -> Pick | BaseException:
    lines = [f"## Criteria\n\n{criteria}\n", "## Judgments", ""]
    for label, jmt in ranked:
        if isinstance(jmt, BaseException):
            lines.append(f"### `{label}` — (judgment failed: {jmt})")
            lines.append("")
            continue
        lines.append(
            f"### `{label}` — score {jmt.score}\n\n"
            + (f"**Strengths:** {'; '.join(jmt.strengths)}\n\n" if jmt.strengths else "")
            + (f"**Weaknesses:** {'; '.join(jmt.weaknesses)}\n\n" if jmt.weaknesses else "")
            + jmt.summary
        )
        lines.append("")
    user = (
        "\n".join(lines)
        + "\n\nPick one winner. The winner label MUST be one of the labels above."
    )

    try:
        agent_obj = await gen.agent(
            system_prompt=(
                "You pick a single winner from the independent judgments "
                "below. Weigh the criteria and scores together; do not "
                "re-open file contents."
            ),
            output_type=Pick,
        )
        result = await agent_obj.run(user)
    except Exception as e:
        return e
    out = getattr(result, "output", None) or getattr(result, "data", None)
    if not isinstance(out, Pick):
        return RuntimeError("pick agent returned no structured output")
    return out


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _preview(files: dict[str, str], max_bytes: int = 4000) -> str:
    if not files:
        return "_(no files)_"
    out: list[str] = []
    for path, content in sorted(files.items()):
        body = content
        if len(body) > max_bytes:
            body = body[:max_bytes] + f"\n\n_(truncated — full size {len(content)} bytes)_"
        out.append(f"### `{path}`\n\n```\n{body}\n```")
    return "\n\n".join(out)


def _heuristic_winner(
    ranked: list[tuple[str, Judgment | BaseException]],
) -> str:
    valid = [(label, j) for label, j in ranked if isinstance(j, Judgment)]
    if valid:
        return max(valid, key=lambda pair: pair[1].score)[0]
    return ranked[0][0] if ranked else "unknown"


def _judgments_md(ranked: list[tuple[str, Judgment | BaseException]]) -> str:
    lines = ["# Independent judgments", ""]
    for label, j in sorted(
        ranked,
        key=lambda pair: pair[1].score if isinstance(pair[1], Judgment) else -1,
        reverse=True,
    ):
        if isinstance(j, BaseException):
            lines += [f"## `{label}` — error", "", f"```\n{j}\n```", ""]
            continue
        lines += [f"## `{label}` — score {j.score}", "", j.summary, ""]
        if j.strengths:
            lines.append("**Strengths**")
            lines += [f"- {s}" for s in j.strengths]
            lines.append("")
        if j.weaknesses:
            lines.append("**Weaknesses**")
            lines += [f"- {w}" for w in j.weaknesses]
            lines.append("")
    return "\n".join(lines) + "\n"


def _why_md(
    winner: str,
    reasoning: str,
    ranked: list[tuple[str, Judgment | BaseException]],
    criteria: str,
) -> str:
    lines = [
        f"# Winner: `{winner}`",
        "",
        "## Why",
        "",
        reasoning.strip(),
        "",
        "## Criteria",
        "",
        criteria.strip(),
        "",
        "## Scoreboard",
        "",
    ]
    for label, j in sorted(
        ranked,
        key=lambda pair: pair[1].score if isinstance(pair[1], Judgment) else -1,
        reverse=True,
    ):
        if isinstance(j, BaseException):
            lines.append(f"- `{label}` — judgment failed")
        else:
            marker = "**" if label == winner else ""
            lines.append(f"- {marker}`{label}`{marker} — score {j.score}")
    return "\n".join(lines) + "\n"


def _first_line(text: str, limit: int = 120) -> str:
    text = (text or "").strip()
    if not text:
        return ""
    first = text.splitlines()[0]
    return first[:limit] + ("…" if len(first) > limit else "")
