"""Seed Ideas — fan out N idea directions along a user-specified axis.

Two phases:

  1. Ask the agent for N short seed labels (2–4 words). The system
     prompt leans on ``gen.prompt`` — the axis + requirements text the
     user typed in the picker.
  2. Run N agents in parallel, one per seed, each asked to produce a
     full ``SeedIdea.md`` grounded in the input cell's files (if any).

Each idea lands in its **own stack cell** (``gen.create_stack_cell``)
so downstream generators see them as N siblings rather than one
monolithic folder cell. The run's primary placeholder stays as an
index that lists every idea + a one-line summary, updated
progressively as each side cell finishes building.
"""
from __future__ import annotations

import asyncio
import re

from pydantic import BaseModel, Field

import gen


class Seeds(BaseModel):
    labels: list[str] = Field(
        description="Exactly N short labels (2–4 words each) for the distinct ideas."
    )


async def run() -> None:
    cfg = gen.config("pydantic-config.set_yaml")
    count = max(2, min(12, _int(cfg.get("num_ideas"), default=4)))
    system_prompt = (cfg.get("system_prompt") or "").strip()
    axis = (gen.prompt or "").strip()

    if not axis:
        gen.update_file("index.md", "# No axis\n\nType the axis to explore into the picker prompt.\n")
        await gen.update(name="seed-ideas · no axis", summary="Empty prompt",
                         pinned="index.md")
        return

    # The primary placeholder holds only ``index.md`` — clear the
    # auto-carried input files so they don't show up there. The side
    # cells re-add them via ``files=`` on create_stack_cell.
    carry = dict(gen.input_files())
    for p in list(gen.list_files()):
        gen.delete_file(p)

    files_context = _files_context(carry)

    gen.update_file("index.md", f"_(seeding {count} ideas…)_\n")
    await gen.update(name=f"seed-ideas · {count} ideas",
                     summary=f"seeding {count}", pinned="index.md")
    gen.log(f"[seed-ideas] count={count}, axis={axis[:80]!r}")

    seeds = await _seed(count, axis, system_prompt, files_context)
    if isinstance(seeds, BaseException):
        gen.update_file("index.md", f"# Seeding failed\n\n```\n{seeds}\n```\n")
        await gen.update(name="seed-ideas · seed failed",
                         summary=str(seeds)[:120], pinned="index.md")
        return
    gen.log(f"[seed-ideas] seeds: {seeds}")

    gen.update_file("index.md", _seeds_preview(seeds, axis))
    await gen.update(name=f"{count} ideas", summary=f"building {count}",
                     pinned="index.md")

    # Track per-idea outcome — body or exception — keyed by index so
    # the index renders in seed order regardless of completion order.
    outcomes: list[str | BaseException | None] = [None] * len(seeds)

    async def _build_and_emit(idx0: int, seed: str) -> None:
        try:
            body = await _build(seed, axis, idx0 + 1, system_prompt, files_context)
        except Exception as e:
            outcomes[idx0] = e
            gen.log(f"[seed-ideas] idea {idx0 + 1} ({seed}) failed: {e}")
            await _refresh_index(seeds, outcomes, axis, count)
            return
        outcomes[idx0] = body

        cell_files = {**carry, "SeedIdea.md": f"# {seed}\n\n{body}\n"}
        try:
            await gen.create_stack_cell(
                name=seed[:80],
                summary=_summary_from_body(body),
                pinned="SeedIdea.md",
                files=cell_files,
            )
        except Exception as e:
            gen.log(f"[seed-ideas] create_stack_cell({seed!r}) failed: {e}")
        await _refresh_index(seeds, outcomes, axis, count)

    await asyncio.gather(
        *[_build_and_emit(i, seed) for i, seed in enumerate(seeds)],
        return_exceptions=True,
    )

    # Final placeholder update — the index reflects every idea's terminal state.
    gen.update_file("index.md", _final_index(seeds, outcomes, axis, count))
    await gen.update(name=f"{count} ideas",
                     summary=" · ".join(seeds), pinned="index.md")


# ---------------------------------------------------------------------------
# Phase functions
# ---------------------------------------------------------------------------


async def _seed(
    count: int,
    axis: str,
    system_prompt: str,
    files_context: str,
) -> list[str] | BaseException:
    try:
        agent_obj = await gen.agent(
            system_prompt=(
                system_prompt
                + f"\n\nReturn exactly {count} short labels (2–4 words each), "
                "genuinely distinct directions along the axis. Do not repeat."
                + files_context
            ),
            output_type=Seeds,
        )
        result = await agent_obj.run(f"Axis and requirements:\n\n{axis}")
    except Exception as e:
        return e
    out = getattr(result, "output", None) or getattr(result, "data", None)
    if not out or not out.labels:
        return RuntimeError("model returned no seeds")
    seeds = [s.strip() for s in out.labels if s and s.strip()]
    if len(seeds) > count:
        seeds = seeds[:count]
    while len(seeds) < count:
        seeds.append(f"Idea {len(seeds) + 1}")
    return seeds


async def _build(
    seed: str,
    axis: str,
    idx: int,
    system_prompt: str,
    files_context: str,
) -> str:
    agent_obj = await gen.agent(
        system_prompt=(
            system_prompt
            + "\n\nProduce the seeded idea as a complete, self-contained "
            "markdown document. Ground any concrete details in the input "
            "files if the user attached any. No preamble, no meta commentary."
            + files_context
        ),
    )
    user = (
        f"Axis and requirements:\n\n{axis}\n\n"
        f"Write out idea {idx}: **{seed}**. Just the idea body in markdown."
    )
    result = await agent_obj.run(user)
    return str(getattr(result, "output", "") or getattr(result, "data", "") or "")


async def _refresh_index(
    seeds: list[str],
    outcomes: list[str | BaseException | None],
    axis: str,
    count: int,
) -> None:
    """Re-render the placeholder's index.md as ideas finish."""
    gen.update_file("index.md", _final_index(seeds, outcomes, axis, count))
    await gen.update(name=f"{count} ideas",
                     summary=_done_count_summary(outcomes, count),
                     pinned="index.md")


# ---------------------------------------------------------------------------
# File context + index rendering
# ---------------------------------------------------------------------------


def _files_context(files: dict[str, str], max_bytes_per_file: int = 4000) -> str:
    """Inline up to ``max_bytes_per_file`` of each input file as a
    markdown context suffix for the agent's system prompt. Empty
    string when there are no input files."""
    if not files:
        return ""
    out: list[str] = []
    for path, content in sorted(files.items()):
        body = content
        if len(body) > max_bytes_per_file:
            body = body[:max_bytes_per_file] + f"\n\n_(truncated — full size {len(content)} bytes)_"
        out.append(f"### `{path}`\n\n```\n{body}\n```")
    return "\n\n## Input files (inline)\n\n" + "\n\n".join(out)


def _seeds_preview(seeds: list[str], axis: str) -> str:
    lines = [f"# Seeding along: {axis}", "", "## Seeds", ""]
    lines += [f"- {s}" for s in seeds]
    lines.append("")
    lines.append("_(building each idea in parallel — stack cells will appear as they finish.)_")
    return "\n".join(lines) + "\n"


def _final_index(
    seeds: list[str],
    outcomes: list[str | BaseException | None],
    axis: str,
    count: int,
) -> str:
    lines = [f"# {count} ideas along: {axis}", "", "## Generated cells", ""]
    for seed, outcome in zip(seeds, outcomes):
        if outcome is None:
            lines.append(f"- ⏳ **{seed}** — _building…_")
        elif isinstance(outcome, BaseException):
            lines.append(f"- ⚠️ **{seed}** — _failed: {outcome}_")
        else:
            tagline = _summary_from_body(outcome)
            lines.append(f"- ✅ **{seed}** — {tagline}" if tagline else f"- ✅ **{seed}**")
    lines.append("")
    lines.append("_Each idea above is its own stack cell below this one._")
    return "\n".join(lines) + "\n"


def _done_count_summary(
    outcomes: list[str | BaseException | None], count: int,
) -> str:
    done = sum(1 for o in outcomes if o is not None)
    return f"{done}/{count} ideas built"


_INLINE_BOLD = re.compile(r"\*\*(.+?)\*\*")
_INLINE_ITAL = re.compile(r"(?<![*_])\*(?!\s)(.+?)(?<!\s)\*(?!\*)")
_INLINE_CODE = re.compile(r"`([^`]+)`")
_INLINE_LINK = re.compile(r"\[([^\]]+)\]\([^)]+\)")


def _summary_from_body(body: str | BaseException | None, limit: int = 120) -> str:
    """Pull a one-line tagline out of an idea body. Skip leading
    headings; strip inline markdown so the cell summary reads as plain
    prose. Returns "" when no usable line exists — the host then shows
    nothing, which is cleaner than echoing a heading or error stub."""
    if not isinstance(body, str):
        return ""
    text = body.strip()
    if not text:
        return ""
    lower = text.lower()
    if lower.startswith("_error") or lower.startswith("**error"):
        return ""
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        cleaned = _INLINE_BOLD.sub(r"\1", line)
        cleaned = _INLINE_ITAL.sub(r"\1", cleaned)
        cleaned = _INLINE_CODE.sub(r"\1", cleaned)
        cleaned = _INLINE_LINK.sub(r"\1", cleaned)
        cleaned = cleaned.strip()
        if not cleaned:
            continue
        if len(cleaned) > limit:
            return cleaned[:limit - 1] + "…"
        return cleaned
    return ""


def _int(raw, default: int) -> int:
    try:
        n = int(raw)
        return n if n > 0 else default
    except (TypeError, ValueError):
        return default
