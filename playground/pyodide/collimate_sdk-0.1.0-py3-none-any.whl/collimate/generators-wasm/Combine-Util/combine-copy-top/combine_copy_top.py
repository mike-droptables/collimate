"""Combine: Copy Top — apply the top cell as an overlay onto each below cell.

With inputs ``[top, a, b, c]`` the output contains three subfolders:

  - ``a_with_top/`` — all of a's files, with top's files overwriting on collision
  - ``b_with_top/`` — same shape, using b as the base
  - ``c_with_top/`` — same, using c

An ``index.md`` at the root lists the variants and the origin of each
file within them. The wasm runtime only permits one output cell per
run, so the N-1 "cells" semantics from the spec are emitted as
subfolders. Chain ``expand-folder`` downstream to split them apart.
"""
from __future__ import annotations

from collimate.wasm_sdk import WasmContext, WasmResult


async def run(ctx: WasmContext) -> WasmResult:
    groups = _group_inputs(ctx)
    if len(groups) < 2:
        return WasmResult(
            files={"index.md": "# Need 2+ inputs\n\nAttach at least two input cells."},
            cell_name="copy-top · too few inputs",
            summary="Need 2+ inputs",
        )

    top_label, top_paths = groups[0]
    top: dict[str, str] = {}
    for src in top_paths:
        dest = _rel_within_cell(src)
        if dest:
            try:
                top[dest] = ctx.read_workspace(src)
            except OSError:
                continue

    files: dict[str, str] = {}
    lines = [
        f"# Copy-top — {len(groups) - 1} variants",
        "",
        f"**Top cell:** `{top_label}` ({len(top)} file(s))",
        "",
    ]

    for label, paths in groups[1:]:
        variant = f"{label}_with_top"
        base: dict[str, str] = {}
        for src in paths:
            dest = _rel_within_cell(src)
            if dest:
                try:
                    base[dest] = ctx.read_workspace(src)
                except OSError:
                    continue

        merged = dict(base)
        overwritten: list[str] = []
        for path, content in top.items():
            if path in merged and merged[path] != content:
                overwritten.append(path)
            merged[path] = content

        for path, content in merged.items():
            files[f"{variant}/{path}"] = content

        lines.append(f"## `{variant}`")
        lines.append("")
        lines.append(
            f"Base `{label}` ({len(base)} files) + top `{top_label}` → "
            f"{len(merged)} files, {len(overwritten)} overwritten."
        )
        if overwritten:
            lines.append("")
            lines += [f"- `{p}` (from top)" for p in sorted(overwritten)]
        lines.append("")

    files["index.md"] = "\n".join(lines) + "\n"

    return WasmResult(
        files=files,
        cell_name=f"{top_label} onto {len(groups) - 1}",
        summary=f"{len(groups) - 1} variants",
    )


def _rel_within_cell(src: str) -> str:
    """``inputs/00_foo/a/b.md`` → ``a/b.md``."""
    if not src.startswith("inputs/"):
        return ""
    rest = src[len("inputs/"):]
    _, _, within = rest.partition("/")
    return within


def _group_inputs(ctx: WasmContext) -> list[tuple[str, list[str]]]:
    under = [p for p in ctx.workspace_files() if p.startswith("inputs/")]
    groups: dict[str, list[str]] = {}
    for p in under:
        label = p[len("inputs/"):].split("/", 1)[0]
        groups.setdefault(label, []).append(p)
    return [(k, sorted(v)) for k, v in sorted(groups.items())]
