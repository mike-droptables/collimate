"""Combine: Flatten — overlay 2+ input cells into one tree, top wins.

Iterates from the bottom input up: each cell's files land at the output
root, and later (higher-up) cells overwrite earlier ones on conflict.
End result: the TOP input's files win every collision.

Emits an ``_flatten.md`` note alongside the merged tree showing which
source a given path came from after the overlay resolved.
"""
from __future__ import annotations

from collimate.wasm_sdk import WasmContext, WasmResult


async def run(ctx: WasmContext) -> WasmResult:
    groups = _group_inputs(ctx)
    if len(groups) < 2:
        return WasmResult(
            files={"_flatten.md": "# Need 2+ inputs\n\nAttach at least two input cells."},
            cell_name="flatten · too few inputs",
            summary="Need 2+ inputs",
        )

    files: dict[str, str] = {}
    origin: dict[str, str] = {}
    conflicts: list[tuple[str, str, str]] = []

    # Walk bottom-to-top so top's writes land last and therefore win.
    for label, paths in reversed(groups):
        for src in paths:
            rel = src[len("inputs/"):]
            _, _, dest = rel.partition("/")
            if not dest:
                continue
            try:
                content = ctx.read_workspace(src)
            except OSError:
                continue
            if dest in files and files[dest] != content:
                conflicts.append((dest, origin[dest], label))
            files[dest] = content
            origin[dest] = label

    note_lines = [
        f"# Flatten — {len(groups)} cells",
        "",
        f"Top-wins overlay of `{'`, `'.join(l for l, _ in groups)}`.",
        "",
        f"**Files in output:** {len(files)}  ",
        f"**Conflicts resolved:** {len(conflicts)}",
        "",
    ]
    if conflicts:
        note_lines += ["## Conflicts", ""]
        for path, loser, winner in conflicts:
            note_lines.append(f"- `{path}`: `{winner}` overwrote `{loser}`")
        note_lines.append("")
    note_lines += ["## Origins", ""]
    for path in sorted(files):
        note_lines.append(f"- `{path}` ← `{origin[path]}`")

    files["_flatten.md"] = "\n".join(note_lines) + "\n"

    return WasmResult(
        files=files,
        cell_name=f"Flattened × {len(groups)}",
        summary=f"{len(files) - 1} files, {len(conflicts)} conflicts",
    )


def _group_inputs(ctx: WasmContext) -> list[tuple[str, list[str]]]:
    under = [p for p in ctx.workspace_files() if p.startswith("inputs/")]
    groups: dict[str, list[str]] = {}
    for p in under:
        label = p[len("inputs/"):].split("/", 1)[0]
        groups.setdefault(label, []).append(p)
    # Preserve hydration order (labels like 00_… 01_… sort correctly).
    return [(k, sorted(v)) for k, v in sorted(groups.items())]
