"""Combine: Merge — one output cell with a subfolder per input cell.

The host hydrates multi-input runs into ``inputs/NN_slug/`` already, so
this generator mostly strips the ``inputs/`` prefix and re-emits files
under ``<slug>/...``. An ``index.md`` lists each source cell and its
file count for quick orientation.

No conflict resolution is needed — files from different cells live in
different subfolders. If you want flattened semantics (top overrides
bottom), use ``combine-flatten`` instead.
"""
from __future__ import annotations

from collimate.wasm_sdk import WasmContext, WasmResult


async def run(ctx: WasmContext) -> WasmResult:
    groups = _group_inputs(ctx)
    if len(groups) < 2:
        return WasmResult(
            files={"index.md": "# Need 2+ inputs\n\nAttach at least two input cells."},
            cell_name="merge · too few inputs",
            summary="Need 2+ inputs",
        )

    files: dict[str, str] = {}
    lines = [f"# Merge — {len(groups)} cells", ""]
    total = 0
    for label, paths in groups:
        lines.append(f"## `{label}` — {len(paths)} file(s)")
        lines.append("")
        for src in paths:
            rel = src[len("inputs/"):]  # "NN_slug/foo/bar.md"
            _, _, relative_to_cell = rel.partition("/")
            dest = f"{label}/{relative_to_cell}" if relative_to_cell else f"{label}/{rel}"
            try:
                files[dest] = ctx.read_workspace(src)
                total += 1
                lines.append(f"- `{dest}`")
            except OSError as e:
                lines.append(f"- `{dest}` — (read failed: {e})")
        lines.append("")

    files["index.md"] = "\n".join(lines) + "\n"
    return WasmResult(
        files=files,
        cell_name=f"Merged × {len(groups)}",
        summary=f"{total} files from {len(groups)} cells",
    )


def _group_inputs(ctx: WasmContext) -> list[tuple[str, list[str]]]:
    """Multi-input groups under ``inputs/NN_slug/``. Returns empty when
    the workspace was hydrated as a single input (no ``inputs/`` prefix)."""
    under = [p for p in ctx.workspace_files() if p.startswith("inputs/")]
    groups: dict[str, list[str]] = {}
    for p in under:
        label = p[len("inputs/"):].split("/", 1)[0]
        groups.setdefault(label, []).append(p)
    return [(k, sorted(v)) for k, v in sorted(groups.items())]
