"""Expand: By Folder — group a single input cell's files by top-level folder.

Semantically wants one output cell per top-level folder, but the wasm
dispatcher caps each ``run()`` at a single cell. The compromise: each
top-level folder is preserved as a subfolder in the output, loose
root-level files are collected under ``_root/``, and ``index.md`` lists
each group so the user can chain subsequent runs to split further.
"""
from __future__ import annotations

from collimate.wasm_sdk import WasmContext, WasmResult


async def run(ctx: WasmContext) -> WasmResult:
    paths = ctx.workspace_files()
    if not paths:
        return WasmResult(
            files={"index.md": "# No input\n\nAttach one input cell."},
            cell_name="expand-folder · no input",
            summary="No input",
        )

    groups: dict[str, list[str]] = {}
    for p in paths:
        top, _, rest = p.partition("/")
        if rest:
            groups.setdefault(top, []).append(p)
        else:
            groups.setdefault("_root", []).append(p)

    files: dict[str, str] = {}
    lines = [f"# Expand by folder — {len(groups)} group(s)", ""]

    for group, members in sorted(groups.items()):
        lines.append(f"## `{group}` — {len(members)} file(s)")
        lines.append("")
        for src in members:
            if group == "_root":
                dest = f"_root/{src}"
            else:
                dest = src  # already under `<group>/...`
            try:
                files[dest] = ctx.read_workspace(src)
                lines.append(f"- `{dest}`")
            except OSError as e:
                lines.append(f"- `{dest}` — (read failed: {e})")
        lines.append("")

    files["index.md"] = "\n".join(lines) + "\n"

    return WasmResult(
        files=files,
        cell_name=f"Expanded × {len(groups)}",
        summary=f"{len(groups)} folder(s), {sum(len(g) for g in groups.values())} files",
    )
