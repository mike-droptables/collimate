# Evaluation criteria

Describe how to judge the input cells. Be concrete — the LLM has to
pick exactly one winner and justify the pick against these criteria.

Examples:

- Which plan is most likely to ship in one sprint?
- Which draft is clearest for a non-technical reader?
- Which approach has the smallest blast radius if it fails?
