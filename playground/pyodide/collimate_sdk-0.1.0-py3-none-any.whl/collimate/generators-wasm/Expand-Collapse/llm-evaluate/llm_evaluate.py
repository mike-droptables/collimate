"""LLM Evaluate & Pick — compare 2+ input cells and commit to one winner.

Each input cell is hydrated under ``inputs/NN_slug/``. The agent is
given:
  - the user's criteria (from ``criteria.md``)
  - a catalog of candidate cells with their labels
  - file-reading tools scoped to the full workspace (so it can inspect
    any candidate's files on demand)

It's asked to return a structured decision (winner label + reasoning)
which we render into ``decision.md``.
"""
from __future__ import annotations

from pydantic import BaseModel, Field

from collimate.wasm_llm import (
    INLINE_FILE_THRESHOLD,
    PROVIDER_KEY_ENV,
    build_agent,
    make_file_tools,
    preview_workspace_files,
    resolve_api_key,
)
from collimate.wasm_sdk import WasmContext, WasmResult


class Decision(BaseModel):
    winner: str = Field(
        description="Exact label of the winning candidate, copied from the catalog."
    )
    reasoning: str = Field(
        description="2–6 sentences explaining why the winner beat the others."
    )
    runners_up: list[str] = Field(
        default_factory=list,
        description="Other candidates, best-first, with a one-line note each "
                    "(format: 'LABEL — note').",
    )


async def run(ctx: WasmContext) -> WasmResult:
    s = ctx.config_yaml("settings.set_yaml")
    provider = (s.get("provider") or "gemini").strip().lower()
    model = (s.get("model") or "").strip() or "gemini-2.0-flash"
    system_prompt = (s.get("system_prompt") or "").strip()
    api_key = resolve_api_key(ctx, provider, s.get("api_key") or "")
    criteria = (ctx.config("criteria.md") or "").strip()

    if not criteria:
        return WasmResult(
            files={"decision.md": "# No criteria\n\nEdit `criteria.md` in the Draft."},
            cell_name="evaluate · no criteria",
            summary="Empty criteria",
        )
    if not api_key:
        env = PROVIDER_KEY_ENV.get(provider, "API_KEY")
        return WasmResult(
            files={"decision.md": f"# Missing `{env}`\n\nSet it in Settings → Keys."},
            cell_name=f"{provider} · no key",
            summary="Missing API key",
        )

    candidates = _list_candidates(ctx)
    if len(candidates) < 2:
        return WasmResult(
            files={"decision.md": "# Need 2+ inputs\n\nAttach at least two input cells."},
            cell_name="evaluate · too few inputs",
            summary="Need 2+ inputs",
        )

    catalog = _render_catalog(ctx, candidates)
    system_with_catalog = (
        system_prompt
        + "\n\n## Candidate cells\n\n"
        + catalog
        + "\n\nAnswer with a Decision. The `winner` MUST exactly match "
        "one of the candidate labels above."
    )

    # Tools only help when candidates weren't inlined; otherwise they
    # just burn tokens on redundant reads.
    tools = (
        [] if _all_inlined(candidates) else make_file_tools(ctx)
    )

    await ctx.emit_partial(
        files={"decision.md": f"_(evaluating {len(candidates)} candidates…)_\n"},
        cell_name=f"evaluate · {provider} · {model}",
        summary=f"{len(candidates)} candidates",
    )
    ctx.push_log(f"[evaluate] {provider} · {model} · {len(candidates)} candidates")

    try:
        agent = await build_agent(
            provider=provider,
            model=model,
            api_key=api_key,
            system_prompt=system_with_catalog,
            tools=tools,
            output_type=Decision,
        )
        result = await agent.run(criteria)
    except Exception as e:
        ctx.push_log(f"[evaluate] error: {e}")
        return WasmResult(
            files={"decision.md": f"# Evaluation error\n\n```\n{e}\n```"},
            cell_name=f"evaluate · error",
            summary=str(e)[:120],
        )

    decision: Decision = getattr(result, "output", None) or getattr(result, "data", None)
    if decision is None:
        return WasmResult(
            files={"decision.md": "# No structured decision returned"},
            cell_name="evaluate · no output",
            summary="No output",
        )

    valid_labels = {label for label, _ in candidates}
    winner = decision.winner if decision.winner in valid_labels else _closest(
        decision.winner, valid_labels
    )

    md = _render_decision(winner, decision, candidates)
    return WasmResult(
        files={"decision.md": md},
        cell_name=f"Winner: {winner}",
        summary=_first_line(decision.reasoning),
    )


def _list_candidates(ctx: WasmContext) -> list[tuple[str, list[str]]]:
    all_paths = ctx.workspace_files()
    under = [p for p in all_paths if p.startswith("inputs/")]
    if not under:
        return []
    groups: dict[str, list[str]] = {}
    for p in under:
        label = p[len("inputs/"):].split("/", 1)[0]
        groups.setdefault(label, []).append(p)
    return [(k, sorted(v)) for k, v in sorted(groups.items())]


def _all_inlined(candidates: list[tuple[str, list[str]]]) -> bool:
    total = sum(len(paths) for _, paths in candidates)
    return total < INLINE_FILE_THRESHOLD


def _render_catalog(
    ctx: WasmContext, candidates: list[tuple[str, list[str]]]
) -> str:
    out: list[str] = []
    inline_all = _all_inlined(candidates)
    for label, paths in candidates:
        out.append(f"### `{label}` ({len(paths)} file(s))")
        if inline_all:
            out.append("")
            out.append(preview_workspace_files(ctx, paths))
        else:
            listing = "\n".join(f"- `{p}`" for p in paths)
            out.append("")
            out.append(listing)
        out.append("")
    return "\n".join(out).rstrip() + "\n"


def _render_decision(
    winner: str, d: Decision, candidates: list[tuple[str, list[str]]]
) -> str:
    lines = [f"# Winner: `{winner}`", "", "## Reasoning", "", d.reasoning.strip(), ""]
    if d.runners_up:
        lines += ["## Runners-up", ""]
        lines += [f"- {item}" for item in d.runners_up]
        lines.append("")
    lines += ["## Candidates considered", ""]
    for label, paths in candidates:
        marker = "**" if label == winner else ""
        lines.append(f"- {marker}`{label}`{marker} — {len(paths)} file(s)")
    return "\n".join(lines) + "\n"


def _closest(name: str, labels: set[str]) -> str:
    """If the model returned a near-match, pick the label with the
    longest shared prefix. Falls back to sorted-first when nothing matches."""
    if not labels:
        return name
    best = max(labels, key=lambda l: _prefix_len(l, name))
    return best if _prefix_len(best, name) > 0 else sorted(labels)[0]


def _prefix_len(a: str, b: str) -> int:
    n = 0
    for x, y in zip(a, b):
        if x != y:
            break
        n += 1
    return n


def _first_line(text: str, limit: int = 120) -> str:
    text = (text or "").strip()
    if not text:
        return ""
    first = text.splitlines()[0]
    return first[:limit] + ("…" if len(first) > limit else "")
