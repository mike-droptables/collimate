# Lens / guidance

Optional: tell the LLM what lens or axis should distinguish the
options. Leave blank to let it choose a dimension itself.

Examples:

- Vary by tone: one formal, one casual, one sardonic.
- Vary by risk: one safe, one moderate, one ambitious.
- Vary by audience: engineer, PM, customer.
