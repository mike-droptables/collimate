"""LLM Expand Options — two-phase fan-out from one input cell.

Phase 1: ask the model for N short seed labels (2–4 words each) that
cover genuinely distinct directions, shaped by the optional lens the
user wrote into ``lens.md``.

Phase 2: run N agents in parallel, one per seed, each asked to produce
a full version of its option grounded in the input cell's files.

Wasm caps ``run()`` at a single output cell, so each option lands in
its own subfolder (``option_01_<slug>/body.md``) and an ``index.md``
lists them all. Chain ``expand-folder`` after if you want each option
split into its own cell.
"""
from __future__ import annotations

import asyncio
import re

from pydantic import BaseModel, Field

from collimate.wasm_llm import (
    PROVIDER_KEY_ENV,
    build_agent,
    files_context_block,
    resolve_api_key,
)
from collimate.wasm_sdk import WasmContext, WasmResult


class Seeds(BaseModel):
    options: list[str] = Field(
        description="Short labels (2–4 words each) for the distinct options. "
                    "Exactly N entries in the order you'd present them."
    )


async def run(ctx: WasmContext) -> WasmResult:
    s = ctx.config_yaml("settings.set_yaml")
    provider = (s.get("provider") or "gemini").strip().lower()
    model = (s.get("model") or "").strip() or "gemini-2.0-flash"
    system_prompt = (s.get("system_prompt") or "").strip()
    api_key = resolve_api_key(ctx, provider, s.get("api_key") or "")
    count = _parse_count(s.get("count"))
    lens = (ctx.config("lens.md") or "").strip()

    if not api_key:
        env = PROVIDER_KEY_ENV.get(provider, "API_KEY")
        return WasmResult(
            files={"index.md": f"# Missing `{env}`\n\nSet it in Settings → Keys."},
            cell_name=f"{provider} · no key",
            summary="Missing API key",
        )
    if not ctx.workspace_files():
        return WasmResult(
            files={"index.md": "# No input\n\nAttach exactly one input cell."},
            cell_name="expand · no input",
            summary="No input",
        )

    ctx_suffix, tools = files_context_block(ctx)

    await ctx.emit_partial(
        files={"index.md": f"_(seeding {count} options…)_\n"},
        cell_name=f"expand · {provider} · {model}",
        summary=f"seeding {count}",
    )

    seeds = await _seed_options(
        ctx, provider, model, api_key, system_prompt, ctx_suffix, tools, count, lens
    )
    if isinstance(seeds, Exception):
        return WasmResult(
            files={"index.md": f"# Seeding failed\n\n```\n{seeds}\n```"},
            cell_name="expand · seed failed",
            summary=str(seeds)[:120],
        )

    ctx.push_log(f"[expand] seeds: {seeds}")
    await ctx.emit_partial(
        files={
            "index.md": _seeds_index(seeds)
            + "\n\n_(building each option in parallel…)_\n"
        },
        summary=f"building {count}",
    )

    bodies = await asyncio.gather(
        *[
            _build_option(
                ctx, provider, model, api_key, system_prompt, ctx_suffix, tools,
                seed, lens, i,
            )
            for i, seed in enumerate(seeds, start=1)
        ],
        return_exceptions=True,
    )

    files: dict[str, str] = {}
    index_rows: list[str] = []
    for i, (seed, body) in enumerate(zip(seeds, bodies), start=1):
        slug = _slug(seed) or f"option_{i:02d}"
        folder = f"option_{i:02d}_{slug}"
        text = body if isinstance(body, str) else f"_Error: {body}_"
        files[f"{folder}/body.md"] = f"# {seed}\n\n{text}\n"
        index_rows.append(f"- [{seed}](./{folder}/body.md)")

    files["index.md"] = (
        f"# {count} options\n\n"
        + (f"**Lens:** {lens}\n\n" if lens else "")
        + "\n".join(index_rows)
        + "\n"
    )

    return WasmResult(
        files=files,
        cell_name=f"{count} options · {provider}",
        summary=" · ".join(seeds),
    )


async def _seed_options(
    ctx, provider, model, api_key, system_prompt, ctx_suffix, tools, count, lens,
) -> list[str] | Exception:
    try:
        agent = await build_agent(
            provider=provider,
            model=model,
            api_key=api_key,
            system_prompt=(
                system_prompt
                + "\n\nYou are seeding a fan-out. Return exactly "
                f"{count} short labels (2–4 words each), genuinely distinct. "
                "Don't repeat the input verbatim."
                + ctx_suffix
            ),
            tools=tools,
            output_type=Seeds,
        )
        user = (
            f"Seed {count} distinct options for expanding on the input cell."
            + (f"\n\nLens: {lens}" if lens else "")
        )
        result = await agent.run(user)
    except Exception as e:
        return e

    out = getattr(result, "output", None) or getattr(result, "data", None)
    if not out or not out.options:
        return RuntimeError("model returned no seeds")
    seeds = [s.strip() for s in out.options if s and s.strip()]
    # Truncate or pad if the model ignored the count instruction.
    if len(seeds) > count:
        seeds = seeds[:count]
    while len(seeds) < count:
        seeds.append(f"Option {len(seeds) + 1}")
    return seeds


async def _build_option(
    ctx, provider, model, api_key, system_prompt, ctx_suffix, tools,
    seed, lens, idx,
) -> str:
    try:
        agent = await build_agent(
            provider=provider,
            model=model,
            api_key=api_key,
            system_prompt=(
                system_prompt
                + "\n\nProduce the requested option as a complete, self-"
                "contained markdown document. Ground it in the input files."
                + ctx_suffix
            ),
            tools=tools,
        )
        user = (
            f"Build out the option titled: **{seed}**.\n"
            + (f"\nLens: {lens}\n" if lens else "")
            + "\nWrite the full option as a markdown document (no preamble)."
        )
        result = await agent.run(user)
    except Exception as e:
        ctx.push_log(f"[expand:{idx}] error: {e}")
        raise
    text = getattr(result, "output", None) or getattr(result, "data", "") or ""
    ctx.push_log(f"[expand:{idx}] '{seed}' → {len(text)} chars")
    return text


def _parse_count(raw) -> int:
    try:
        n = int(raw)
    except (TypeError, ValueError):
        n = 4
    return n if n in (2, 4, 8) else 4


def _slug(text: str, max_len: int = 30) -> str:
    text = (text or "").lower()
    text = re.sub(r"[^a-z0-9]+", "_", text).strip("_")
    return text[:max_len]


def _seeds_index(seeds: list[str]) -> str:
    lines = ["# Seeds"]
    lines += [f"- {s}" for s in seeds]
    return "\n".join(lines)
