"""Run LLM Prompt — fan out a prompt across one or more input cells.

Reads the user's prompt from ``prompt.md`` and runs it through a
pydantic-ai agent. With a single input cell, emits one ``response.md``
at the workspace root. With N>1 input cells (hydrated by the host
under ``inputs/NN_slug/``), runs N agents in parallel, each scoped to
one cell's files, and writes each response to its own subfolder of the
output cell.

The wasm dispatcher caps ``run()`` at one output cell, so fan-out lives
as subfolders rather than separate cells. Chain an ``expand-folder``
generator afterwards if you need to split them back apart.
"""
from __future__ import annotations

import asyncio

from collimate.wasm_llm import (
    INLINE_FILE_THRESHOLD,
    PROVIDER_KEY_ENV,
    build_agent,
    preview_workspace_files,
    resolve_api_key,
)
from collimate.wasm_sdk import WasmContext, WasmResult


async def run(ctx: WasmContext) -> WasmResult:
    s = ctx.config_yaml("settings.set_yaml")
    provider = (s.get("provider") or "gemini").strip().lower()
    model = (s.get("model") or "").strip() or "gemini-2.0-flash"
    system_prompt = (s.get("system_prompt") or "").strip()
    api_key = resolve_api_key(ctx, provider, s.get("api_key") or "")
    prompt = (ctx.config("prompt.md") or "").strip()

    if not prompt:
        return WasmResult(
            files={"response.md": "# No prompt\n\nEdit `prompt.md` in the Draft."},
            cell_name="run-prompt · no prompt",
            summary="Empty prompt",
        )
    if not api_key:
        env = PROVIDER_KEY_ENV.get(provider, "API_KEY")
        return WasmResult(
            files={"response.md": _missing_key_md(provider, env)},
            cell_name=f"{provider} · no key",
            summary="Missing API key",
        )

    groups = _group_inputs(ctx)
    if not groups:
        return WasmResult(
            files={"response.md": "# No inputs\n\nAttach at least one input cell."},
            cell_name="run-prompt · no inputs",
            summary="No inputs",
        )

    await ctx.emit_partial(
        files={"response.md": f"_(running against {len(groups)} input(s)…)_\n"},
        cell_name=f"run-prompt · {provider} · {model}",
        summary=f"{len(groups)} input(s)",
    )
    ctx.push_log(
        f"[run-prompt] {provider} · {model} · {len(groups)} input group(s) · parallel"
    )

    results = await asyncio.gather(
        *[
            _run_one(ctx, label, paths, provider, model, api_key, system_prompt, prompt)
            for label, paths in groups
        ],
        return_exceptions=True,
    )

    if len(groups) == 1:
        label, _paths = groups[0]
        out = _format_result(label, results[0])
        return WasmResult(
            files={"response.md": out},
            cell_name=f"{provider} · {model}",
            summary=_first_line(out),
        )

    files: dict[str, str] = {}
    index_lines = [f"# Fan-out — {provider} · {model}", ""]
    for (label, _paths), res in zip(groups, results):
        body = _format_result(label, res)
        files[f"{label}/response.md"] = body
        index_lines.append(f"- [`{label}/response.md`](./{label}/response.md)")
    files["index.md"] = "\n".join(index_lines) + "\n"

    return WasmResult(
        files=files,
        cell_name=f"{provider} · {model} × {len(groups)}",
        summary=f"Fanned out across {len(groups)} inputs",
    )


async def _run_one(
    ctx: WasmContext,
    label: str,
    paths: list[str],
    provider: str,
    model: str,
    api_key: str,
    system_prompt: str,
    prompt: str,
) -> str:
    """Run one agent scoped to ``paths`` and return its text output."""
    suffix, tools = _scoped_files_block(ctx, paths)
    try:
        agent = await build_agent(
            provider=provider,
            model=model,
            api_key=api_key,
            system_prompt=system_prompt + suffix,
            tools=tools,
        )
        result = await agent.run(prompt)
    except Exception as e:
        ctx.push_log(f"[run-prompt:{label}] error: {e}")
        raise
    text = getattr(result, "output", None) or getattr(result, "data", "") or ""
    ctx.push_log(f"[run-prompt:{label}] ok ({len(text)} chars)")
    return text


def _scoped_files_block(ctx: WasmContext, paths: list[str]) -> tuple[str, list]:
    """Build a prompt suffix + tools scoped to exactly ``paths``.

    When the scope is small enough, inline file contents. Otherwise,
    expose filtered ``list_files`` / ``read_file`` tools that only see
    the paths in scope — so parallel runs can't accidentally cross-read
    each other's inputs."""
    if not paths:
        return "", []
    if len(paths) < INLINE_FILE_THRESHOLD:
        return (
            "\n\n## Input files (inline)\n\n" + preview_workspace_files(ctx, paths),
            [],
        )
    from pydantic_ai import Tool

    allowed = set(paths)
    listing = "\n".join(f"- `{p}`" for p in paths)

    def list_files() -> list[str]:
        """List input file paths available to this run."""
        return sorted(allowed)

    def read_file(path: str) -> str:
        """Read one of the input files. Must be a path returned by
        ``list_files`` — other paths are rejected."""
        if path not in allowed:
            return f"ERROR: {path} is not available to this run."
        try:
            return ctx.read_workspace(path)
        except OSError as e:
            return f"ERROR: {e}"

    suffix = (
        f"\n\n## Input files ({len(paths)})\n\n{listing}\n\n"
        "Use `list_files` / `read_file` to inspect contents as needed."
    )
    return suffix, [Tool(list_files), Tool(read_file)]


def _group_inputs(ctx: WasmContext) -> list[tuple[str, list[str]]]:
    """Multi-input → one group per ``inputs/NN_slug/`` subfolder.
    Single-input → one group at the root labeled ``input``."""
    all_paths = ctx.workspace_files()
    under = [p for p in all_paths if p.startswith("inputs/")]
    if not under:
        return [("input", all_paths)] if all_paths else []
    groups: dict[str, list[str]] = {}
    for p in under:
        rest = p[len("inputs/"):]
        label = rest.split("/", 1)[0]
        groups.setdefault(label, []).append(p)
    return [(k, sorted(v)) for k, v in sorted(groups.items())]


def _format_result(label: str, result) -> str:
    if isinstance(result, BaseException):
        return f"# {label} — error\n\n```\n{result}\n```\n"
    return result or "_(empty response)_\n"


def _first_line(text: str, limit: int = 120) -> str:
    text = (text or "").strip()
    if not text:
        return ""
    first = text.splitlines()[0]
    return first[:limit] + ("…" if len(first) > limit else "")


def _missing_key_md(provider: str, env: str) -> str:
    return (
        f"# Missing API key\n\n"
        f"Set `{env}` in **Settings → Keys**, or paste an override into "
        f"`api_key` for this cell.\n"
    )
