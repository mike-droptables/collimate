# Prompt

Describe what you want the LLM to do with the input cell(s).

The contents of this file are sent as the user message. The input
cell's files are attached as context (inlined when there are <5, or
exposed as `list_files` / `read_file` tools otherwise).

When multiple input cells are provided, this same prompt runs against
each cell in parallel and the output cell contains one subfolder per
input.
