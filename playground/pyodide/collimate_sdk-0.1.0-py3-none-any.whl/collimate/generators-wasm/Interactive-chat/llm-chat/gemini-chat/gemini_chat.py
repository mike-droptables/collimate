"""Gemini Chat — streaming wasm generator.

Calls Google's ``streamGenerateContent`` endpoint via ``pyodide.http`` and
emits each chunk into the cell as it arrives, so the user sees tokens
appear live. Cooperatively honors ``ctx.cancelled`` when the user stops
the run.

Exercises every live-update surface of ``collimate.wasm_sdk``:
  * ``ctx.emit_partial`` — incremental updates
  * ``ctx.cancelled``    — user-triggered interrupt
  * ``ctx.push_log``     — run-log diagnostics
  * ``chat_messages``    — conversation history appended to the cell's
                            ``.colreserved/.collimate_messages.json``
"""
import json

from collimate.wasm_sdk import Message, WasmContext, WasmResult


async def run(ctx: WasmContext) -> WasmResult:
    s = ctx.config_yaml("settings.set_yaml")
    # Keystore takes precedence so users who set GEMINI_API_KEY in
    # Settings → Keys don't have to re-paste in every cell. An explicit
    # per-cell value in settings.set_yaml still wins if they'd rather
    # scope the key to one conversation.
    api_key = (s.get("api_key") or "").strip() or ctx.secret("GEMINI_API_KEY")
    model = s.get("model") or "gemini-2.0-flash"
    system_prompt = (s.get("system_prompt") or "").strip()
    prompt = (s.get("prompt") or "").strip()

    if not api_key:
        err = (
            "# Missing API key\n\n"
            "Either:\n\n"
            "- Open **Settings → Keys** and add one named `GEMINI_API_KEY` "
            "(applies to every Gemini cell in this browser), or\n"
            "- Edit this cell's Draft and paste the key into `api_key` "
            "(scoped to this cell).\n\n"
            "Get a free key at "
            "[aistudio.google.com/apikey](https://aistudio.google.com/apikey).\n"
        )
        return WasmResult(
            files={"response.md": err},
            cell_name="Gemini · no key",
            summary="Missing API key",
        )

    if not prompt:
        return WasmResult(
            files={"response.md": "# No prompt\n\nType something in the `prompt` field."},
            cell_name="Gemini · no prompt",
            summary="Empty prompt",
        )

    # Build the conversation. Prior messages carried from input cells are
    # in ctx.messages already; append the current turn's user prompt.
    turn_messages = list(ctx.messages) + [Message(role="user", content=prompt)]
    contents = [
        {
            "role": "user" if m.role == "user" else "model",
            "parts": [{"text": m.content}],
        }
        for m in turn_messages
        if m.role in ("user", "assistant") and m.content
    ]

    body: dict = {"contents": contents}
    if system_prompt:
        body["systemInstruction"] = {"parts": [{"text": system_prompt}]}

    url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/{model}"
        ":streamGenerateContent?alt=sse"
    )
    ctx.push_log(f"[gemini] {model} · {len(contents)} messages · streaming")

    # Show the user's turn immediately so the cell isn't empty while we
    # wait for first-byte.
    accum = ""
    pending_tail = ""
    await ctx.emit_partial(
        files={
            "response.md": f"_(thinking…)_\n",
        },
        cell_name=f"Gemini · {model}",
        summary="thinking…",
        chat_messages=turn_messages,
    )

    try:
        from pyodide.http import pyfetch
    except ImportError:
        # Running natively under the sim — pyfetch isn't available; fall
        # back to a non-streaming httpx call.
        return await _fallback_non_streaming(url, body, api_key, turn_messages, model, ctx)

    resp = await pyfetch(
        url,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "x-goog-api-key": api_key,
        },
        body=json.dumps(body),
    )
    if resp.status != 200:
        err_text = await resp.string()
        ctx.push_log(f"[gemini] error {resp.status}: {err_text[:300]}")
        return WasmResult(
            files={"response.md": f"# Gemini error {resp.status}\n\n```\n{err_text}\n```"},
            cell_name=f"Gemini · error {resp.status}",
            summary=f"HTTP {resp.status}",
            chat_messages=turn_messages,
        )

    # Gemini's SSE framing: lines like `data: {...}`, blank-line separated.
    # pyfetch exposes the body as an async-iterable reader; we consume
    # chunks, split on newlines, and parse `data: ` lines.
    reader = resp.js_response.body.getReader()
    decoder_buf = ""
    # Messages the user queued via the push_message endpoint while this
    # stream was running. We append them after the current turn so the
    # frontend's "stop & redirect" UX carries forward into chat_messages.
    interjections: list[Message] = []
    try:
        while True:
            if ctx.cancelled:
                accum += "\n\n_(stopped by user)_"
                ctx.push_log("[gemini] cancelled by user — aborting stream")
                break
            # Honor mid-turn redirects: if the user submitted another
            # message while we were streaming, drain the queue and break
            # so the next Run picks up where this one left off.
            interjected = ctx.poll_user_message()
            if interjected is not None:
                interjections.append(interjected)
                # Drain the rest (debounce)
                while (more := ctx.poll_user_message()) is not None:
                    interjections.append(more)
                accum += "\n\n_(redirected — new message queued)_"
                ctx.push_log(
                    f"[gemini] user redirected mid-stream — {len(interjections)} message(s) queued"
                )
                break
            chunk = await reader.read()
            if chunk.done:
                break
            value = chunk.value
            # value is a Uint8Array — decode to str via JS TextDecoder
            text = _decode_chunk(value)
            decoder_buf += text
            while "\n" in decoder_buf:
                line, decoder_buf = decoder_buf.split("\n", 1)
                line = line.strip()
                if not line or not line.startswith("data:"):
                    continue
                payload = line[len("data:"):].strip()
                if not payload or payload == "[DONE]":
                    continue
                try:
                    obj = json.loads(payload)
                except json.JSONDecodeError:
                    continue
                token = _extract_text(obj)
                if not token:
                    continue
                accum += token
                pending_tail += token
                # Flush to the UI on each token. The host debounces its
                # own persistence writes so this is cheap.
                await ctx.emit_partial(
                    files={"response.md": accum},
                    summary=_summary_line(accum),
                    chat_messages=turn_messages + [Message(role="assistant", content=accum)],
                )
                pending_tail = ""
    finally:
        try:
            reader.releaseLock()
        except Exception:
            pass

    # Final commit. Assistant turn is whatever we accumulated; any mid-
    # stream redirects come after as queued user messages so the next
    # run sees them in ctx.messages.
    final_messages = turn_messages + [Message(role="assistant", content=accum)] + interjections
    return WasmResult(
        files={"response.md": accum or "_(empty response)_\n"},
        cell_name=f"Gemini · {model}",
        summary=_summary_line(accum),
        chat_messages=final_messages,
    )


def _decode_chunk(js_uint8: object) -> str:
    """Turn a JS Uint8Array (from pyodide fetch reader) into a Python str."""
    from js import TextDecoder
    return TextDecoder.new("utf-8").decode(js_uint8)


def _extract_text(obj: dict) -> str:
    """Pull the delta text out of one Gemini stream chunk."""
    candidates = obj.get("candidates") or []
    if not candidates:
        return ""
    parts = (candidates[0].get("content") or {}).get("parts") or []
    return "".join(p.get("text", "") for p in parts)


def _summary_line(text: str) -> str:
    if not text:
        return ""
    first = text.strip().splitlines()[0] if text.strip() else ""
    return first[:120] + ("…" if len(first) > 120 else "")


async def _fallback_non_streaming(url, body, api_key, turn_messages, model, ctx):
    """Non-streaming path for environments without pyodide (e.g. native
    simulation of wasm_run). Uses httpx if available, else synthesizes
    an error response."""
    nonstream_url = url.replace(":streamGenerateContent?alt=sse", ":generateContent")
    try:
        import httpx
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(
                nonstream_url,
                headers={"Content-Type": "application/json", "x-goog-api-key": api_key},
                content=json.dumps(body),
            )
        if resp.status_code != 200:
            return WasmResult(
                files={"response.md": f"# Gemini error {resp.status_code}\n\n```\n{resp.text}\n```"},
                cell_name=f"Gemini · error {resp.status_code}",
                chat_messages=turn_messages,
            )
        data = resp.json()
    except ImportError:
        return WasmResult(
            files={"response.md": "# No HTTP client available in this environment."},
            cell_name="Gemini · no http",
            chat_messages=turn_messages,
        )

    text = _extract_text(data) or ""
    return WasmResult(
        files={"response.md": text or "_(empty response)_\n"},
        cell_name=f"Gemini · {model}",
        summary=_summary_line(text),
        chat_messages=turn_messages + [Message(role="assistant", content=text)],
    )
