"""LLM Chat — streaming pydantic-ai agent against a workspace cell.

Picks one of four OpenAI-compatible providers (Gemini, Groq, Cerebras,
OpenRouter), builds an Agent wired to the workspace (files inline when
<5, exposed as tools otherwise), and streams assistant tokens into the
cell via ``ctx.emit_partial``.

Chat history is carried forward from ``ctx.messages`` and the final
assistant turn is appended to the cell's chat log so the next chat cell
that takes this one as input picks up the conversation.
"""
from __future__ import annotations

from collimate.wasm_llm import (
    PROVIDER_KEY_ENV,
    build_agent,
    files_context_block,
    resolve_api_key,
)
from collimate.wasm_sdk import Message, WasmContext, WasmResult


async def run(ctx: WasmContext) -> WasmResult:
    s = ctx.config_yaml("settings.set_yaml")
    provider = (s.get("provider") or "gemini").strip().lower()
    model = (s.get("model") or "").strip() or "gemini-2.0-flash"
    system_prompt = (s.get("system_prompt") or "").strip()
    prompt = (s.get("prompt") or "").strip()
    api_key = resolve_api_key(ctx, provider, s.get("api_key") or "")

    if not prompt:
        return WasmResult(
            files={"response.md": "# No prompt\n\nType something in the `prompt` field."},
            cell_name=f"{provider} · no prompt",
            summary="Empty prompt",
        )
    if not api_key:
        return WasmResult(
            files={"response.md": _missing_key_md(provider)},
            cell_name=f"{provider} · no key",
            summary="Missing API key",
        )

    ctx_block, tools = files_context_block(ctx)
    try:
        agent = await build_agent(
            provider=provider,
            model=model,
            api_key=api_key,
            system_prompt=system_prompt + ctx_block,
            tools=tools,
        )
    except Exception as e:
        return WasmResult(
            files={"response.md": f"# Setup error\n\n```\n{e}\n```"},
            cell_name=f"{provider} · setup failed",
            summary=str(e)[:120],
        )

    history = list(ctx.messages)
    turn_messages = history + [Message(role="user", content=prompt)]

    await ctx.emit_partial(
        files={"response.md": "_(thinking…)_\n"},
        cell_name=f"{provider} · {model}",
        summary="thinking…",
        chat_messages=turn_messages,
    )
    ctx.push_log(f"[llm-chat] {provider} · {model} · {len(ctx.workspace_files())} files")

    accum = ""
    try:
        message_history = _to_pai_history(history)
        async with agent.run_stream(prompt, message_history=message_history) as stream:
            async for chunk in stream.stream_text(delta=True):
                if ctx.cancelled:
                    accum += "\n\n_(stopped by user)_"
                    ctx.push_log("[llm-chat] cancelled")
                    break
                accum += chunk
                await ctx.emit_partial(
                    files={"response.md": accum},
                    summary=_first_line(accum),
                    chat_messages=turn_messages
                    + [Message(role="assistant", content=accum)],
                )
    except Exception as e:
        ctx.push_log(f"[llm-chat] error: {e}")
        err = f"{accum}\n\n---\n\n**Error:** `{e}`\n" if accum else f"# Error\n\n```\n{e}\n```"
        return WasmResult(
            files={"response.md": err},
            cell_name=f"{provider} · error",
            summary=str(e)[:120],
            chat_messages=turn_messages,
        )

    final = turn_messages + [Message(role="assistant", content=accum)]
    return WasmResult(
        files={"response.md": accum or "_(empty response)_\n"},
        cell_name=f"{provider} · {model}",
        summary=_first_line(accum),
        chat_messages=final,
    )


def _first_line(text: str, limit: int = 120) -> str:
    text = (text or "").strip()
    if not text:
        return ""
    first = text.splitlines()[0]
    return first[:limit] + ("…" if len(first) > limit else "")


def _missing_key_md(provider: str) -> str:
    env = PROVIDER_KEY_ENV.get(provider, "API_KEY")
    return (
        f"# Missing API key\n\n"
        f"Set `{env}` in **Settings → Keys** (applies to every {provider} cell "
        f"in this browser), or paste a per-cell override into `api_key` in "
        f"this cell's Draft.\n"
    )


def _to_pai_history(messages: list[Message]) -> list:
    """Translate SDK Messages into the pydantic-ai ``ModelMessage`` form
    that ``Agent.run_stream(message_history=...)`` expects.

    Returns an empty list if there's no history — pydantic-ai handles
    that as a fresh conversation."""
    if not messages:
        return []
    from pydantic_ai.messages import (
        ModelRequest,
        ModelResponse,
        TextPart,
        UserPromptPart,
    )

    out: list = []
    for m in messages:
        if m.role == "user":
            out.append(ModelRequest(parts=[UserPromptPart(content=m.content or "")]))
        elif m.role == "assistant":
            out.append(ModelResponse(parts=[TextPart(content=m.content or "")]))
    return out
