# Wasm generators

Generators in this tree run **inside the browser** via the Collimate
playground's pyodide build. The host imports them in-process; there's no
subprocess, no Docker, no TCP IPC. They use the reduced
`collimate.wasm_sdk` API.

**Start here:** [`how-to-write-a-wasm-generator.md`](./how-to-write-a-wasm-generator.md) — full contract + example.

**Reference generators:**
- [`note/`](./note/) — minimal: title + body → markdown file.
- [`echo/`](./echo/) — diagnostic: walks the workspace + chat history and
  emits a report. Useful for confirming your hydration works.
- [`gemini-chat/`](./gemini-chat/) — streaming Gemini chat, direct via
  `pyfetch`. Reference for `emit_partial` + `ctx.cancelled`.

**LLM (pydantic-ai):** each generator picks a provider (Gemini, Groq,
Cerebras, OpenRouter) and model in its Draft. All four providers expose
OpenAI-compatible endpoints that accept browser CORS, so calls go
direct from pyodide with no proxy. `pydantic-ai-slim[openai]` is
installed via `micropip` on first use; shared setup lives in
[`src/collimate/wasm_llm.py`](../src/collimate/wasm_llm.py). Files under
5 are inlined into the system prompt; at or above the threshold the
agent is given `list_files` / `read_file` tools.

- [`llm-chat/`](./llm-chat/) — streaming chat against 1 input cell.
- [`llm-run-prompt/`](./llm-run-prompt/) — run a markdown prompt
  against 1+ input cells; multi-input fans out in parallel into
  subfolders of the output cell.
- [`llm-evaluate/`](./llm-evaluate/) — given 2+ input cells and
  criteria, pick exactly one winner with structured reasoning.
- [`llm-expand/`](./llm-expand/) — seed N (2/4/8) distinct options
  from 1 input cell, then build each option in parallel; one
  subfolder per option.

**Combine / expand utilities (no LLM):**

- [`combine-merge/`](./combine-merge/) — 2+ inputs → one cell with a
  subfolder per input (no collisions by construction).
- [`combine-flatten/`](./combine-flatten/) — 2+ inputs → one flat tree;
  top input wins on conflict. Emits `_flatten.md` with origin trace.
- [`combine-copy-top/`](./combine-copy-top/) — overlay the top input
  onto each cell below; N-1 variants live as subfolders of the output.
- [`expand-folder/`](./expand-folder/) — regroup one input cell by its
  top-level folders. Loose root files go under `_root/`.

**One-cell-per-run note.** The wasm dispatcher caps each `run()` at a
single output cell. Generators that semantically want multiple outputs
(fan-out prompts, expand options, copy-top variants, folder splits)
emit them as subfolders inside a single cell. Chain an `expand-folder`
run downstream if you need to split them back into separate cells —
each run produces one cell, so the split happens one folder at a time.

**Build-time CLI:** `python -m collimate.packaging.vendor_defaults --runtime wasm --out <dir>` copies this tree into `<dir>/generators/` when producing the pyodide bundle.
