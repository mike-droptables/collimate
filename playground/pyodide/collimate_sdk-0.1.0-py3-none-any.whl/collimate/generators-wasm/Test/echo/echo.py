"""Echo — a diagnostic wasm generator.

Walks the hydrated workspace and emits a markdown report listing what it
saw: file paths, sizes, and any chat messages. Useful for confirming the
wasm dispatch hydrated inputs correctly.
"""
import os

from collimate.wasm_sdk import WasmContext, WasmResult


async def run(ctx: WasmContext) -> WasmResult:
    lines = ["# Echo report", ""]
    paths = ctx.workspace_files()
    lines.append(f"**Workspace:** `{ctx.workspace}`  ")
    lines.append(f"**Files seen:** {len(paths)}  ")
    lines.append(f"**Run:** `{ctx.run_id}`  ")
    lines.append(f"**Channel:** `{ctx.channel}`")
    lines.append("")

    if paths:
        lines.append("## Files")
        lines.append("")
        for p in paths:
            try:
                size = os.path.getsize(os.path.join(ctx.workspace, p))
                lines.append(f"- `{p}` — {size} bytes")
            except OSError:
                lines.append(f"- `{p}` — (stat failed)")
        lines.append("")

    if ctx.messages:
        lines.append(f"## Chat history ({len(ctx.messages)} messages)")
        lines.append("")
        for i, m in enumerate(ctx.messages[-5:], start=max(1, len(ctx.messages) - 4)):
            snippet = (m.content or "").strip().replace("\n", " ")
            if len(snippet) > 100:
                snippet = snippet[:97] + "…"
            lines.append(f"{i}. **{m.role}**: {snippet}")
        lines.append("")
    else:
        lines.append("_No prior chat messages._")
        lines.append("")

    if ctx.params:
        lines.append("## Params")
        lines.append("")
        for k, v in ctx.params.items():
            lines.append(f"- `{k}`: `{v!r}`")

    return WasmResult(
        files={"echo.md": "\n".join(lines) + "\n"},
        cell_name="Echo",
        summary=f"{len(paths)} files, {len(ctx.messages)} messages",
    )
