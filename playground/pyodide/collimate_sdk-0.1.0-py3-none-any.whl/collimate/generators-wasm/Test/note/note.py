"""Note — a minimal wasm generator.

Takes a title and body from ``settings.set_yaml`` and emits a single
markdown file (``note.md``). The simplest possible reference for the
collimate.wasm_sdk API.
"""
from collimate.wasm_sdk import WasmContext, WasmResult


async def run(ctx: WasmContext) -> WasmResult:
    settings = ctx.config_yaml("settings.set_yaml")
    title = (settings.get("title") or "Untitled note").strip() or "Untitled note"
    body = settings.get("body") or ""

    # Build the markdown file
    if body.strip():
        content = f"# {title}\n\n{body}\n"
    else:
        content = f"# {title}\n\n_(empty note)_\n"

    # One-line summary shown in the cell card
    summary_line = body.strip().splitlines()[0] if body.strip() else "Empty note"
    if len(summary_line) > 120:
        summary_line = summary_line[:117] + "…"

    return WasmResult(
        files={"note.md": content},
        cell_name=title,
        summary=summary_line,
    )
