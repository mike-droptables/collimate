# How to write a wasm generator

Wasm generators run inside the browser. The Collimate "playground" build
compiles the FastAPI backend to WebAssembly via pyodide and loads it on
the page — there's no server, no subprocess, no Docker. Generators are
imported and called **directly in the same Python event loop as the
backend**.

Because of that, wasm generators use a smaller, different API than
native ones. They live under `generators-wasm/` and never mix with the
native `generators/` tree. This doc is the full contract.

---

## 1. File layout

One generator = one directory with three files:

```
generators-wasm/my-gen/
├── manifest.gen_yaml    # identity + schema
├── my_gen.py            # the run() function
└── settings.set_yaml    # (optional) user-editable config
```

No PEP 723 script metadata, no `uv run` entrypoint. The host imports
`my_gen.py` via `importlib` and calls `run(ctx)`.

---

## 2. The `run` function — the whole API

Every wasm generator exports one coroutine:

```python
# my_gen.py
from collimate.wasm_sdk import WasmContext, WasmResult

async def run(ctx: WasmContext) -> WasmResult:
    settings = ctx.config_yaml("settings.set_yaml")
    return WasmResult(
        files={"out.md": f"# Hello {settings.get('name', 'world')}\n"},
        cell_name="Hello",
        summary="greeted",
    )
```

A plain `def run(ctx)` (sync) is also accepted; the host wraps it in
`asyncio.to_thread` for you. Prefer `async def` — pyodide runs on a
single thread and `asyncio.to_thread` still blocks the event loop.

If `run` raises, the run flips to `failed` and the traceback lands in
the run's event log. No partial writes to the cell happen.

---

## 3. `WasmContext` — what the host gives you

```python
@dataclass
class WasmContext:
    workspace: str                    # filesystem path with hydrated input files
    params: dict                      # merged manifest params + run-time overrides
    channel: str
    run_id: str
    config_files: dict[str, str]      # {draft_file_name: content}
    messages: list[Message]           # prior chat history from input cells
    placeholder_cell_id: str | None   # the cell this run's output populates
```

**Workspace helpers** — read the hydrated input files:

```python
ctx.workspace_files()           # -> list[str]  (relative paths)
ctx.read_workspace(relpath)     # -> str        (file contents)
```

**Config / draft-file helpers** — read what the user edited in the Draft
flow, or the defaults your manifest seeded:

```python
ctx.config(name)         # raw string
ctx.config_yaml(name)    # YAML dict. For .set_yaml schema_forms, merges
                         #   `fields:` defaults with the `values:` overlay
                         #   the UI saves. Same behavior as native
                         #   gen.config.read_schema_values().
ctx.config_json(name)    # parsed JSON dict
```

**Messages** — `ctx.messages` is the chat history extracted from input
cells' `.colreserved/.collimate_messages.json`. Each entry has `role`,
`content`, `timestamp`.

**Live-update surface** (during `run`):

```python
await ctx.emit_partial(
    files={"out.md": partial_content},   # overlay onto current cell files
    cell_name="…",                       # optional; last value sticks
    summary="…",                         # optional; last value sticks
    chat_messages=[...],                 # optional; replaces chat log
)
# Call as often as you want — the host debounces persistence writes.

ctx.cancelled                            # -> bool, True if user hit Stop.
                                         # Check between chunks of work.

ctx.push_log("progress message")         # -> appears in the run log panel

msg = ctx.poll_user_message()            # -> Message | None. Pops from the
                                         # push_message queue if the user
                                         # typed something while you were
                                         # streaming. Use for mid-turn
                                         # redirects.

ctx.secret("GEMINI_API_KEY")             # -> str. Reads from the keystore
                                         # (Settings → Keys).
```

`emit_partial` writes to the DB and refreshes the in-memory channel state
immediately. The frontend polls `/api/state` every 500ms under wasm, so
each emit surfaces within ~half a second.

---

## 4. `WasmResult` — what you return

Exactly **one output cell** per run:

```python
@dataclass
class WasmResult:
    files: dict[str, str]              # filepath -> content
    cell_name: str = ""                # falls back to the generator id
    summary: str = ""                  # short text on the cell card
    chat_messages: list[Message] = []  # appended to .colreserved/.collimate_messages.json
```

All paths in `files` are relative to the cell. Subdirectories are fine
(e.g. `{"notes/day1.md": ...}`); the host hashes each file into CAS and
records the mapping.

When `emit_partial` was called during the run, an empty `WasmResult` is
valid — the cell keeps whatever state the last partial left it in.
Returning a non-empty `WasmResult` is treated as the authoritative final
snapshot (files not mentioned are removed from the cell).

Need more than one cell? Chain generators in the UI — one cell per run
is a hard limit of the in-process dispatcher.

---

## 5. Manifest — `manifest.gen_yaml`

Wasm generators declare `runtime: wasm` so the host dispatches in-process:

```yaml
id: "my-gen"
name: "My Generator"
version: "0.1.0"
summary: "One-line what it does."
entrypoint: "my_gen.py"
runtime: "wasm"                  # required
execution_mode: "oneshot"        # daemons unsupported in wasm

# Optional: user-editable config files seeded into the Draft flow.
draft_files:
  - "settings.set_yaml"
summary_file: "settings.set_yaml"  # opens first in the Draft editor
summary_artifact: "out.md"         # the file shown on the cell card
default_route: "draft"             # "draft" | "run"

# Inputs — same meaning as native.
inputs:
  cells:
    min: 0
    max: 10
```

Native-only manifest fields that wasm ignores:

- `live_chat_mode`, `live_files_mode` — there's no live running state.
- `keys` — OS keychain doesn't exist in the browser. For API keys,
  accept them as a `secret: true` field in `settings.set_yaml`.

---

## 6. Draft files + schema_form

Same as native: anything listed in `draft_files` gets seeded into
`.colreserved/config/files/` and becomes editable in the UI's Draft
editor. Read them via `ctx.config_files[name]` or the parsed helpers.

A typical `settings.set_yaml`:

```yaml
fields:
  - key: title
    type: text
    label: "Title"
    default: "Untitled"

  - key: body
    type: textarea
    label: "Body"
    default: ""
```

When the user edits and submits, the UI writes a `values:` block next
to the schema. `ctx.config_yaml("settings.set_yaml")` merges both sides
and gives you back a flat dict.

---

## 7. Constraints

These are hard — pyodide can't do them, so the SDK doesn't expose them:

- **No `gen.chat.start_session(image=...)`** — no Docker in the browser.
- **No subprocess** — `subprocess.Popen`, `asyncio.create_subprocess_*`,
  `os.system`, `shell=True`. All unavailable.
- **No multi-cell output** — one `run()` → one cell. Use `emit_partial`
  for in-place updates; chain generators for a new cell.
- **No daemons** — `execution_mode: daemon` is rejected. Long-running
  work must live inside a single `run()` call, checking `ctx.cancelled`
  between chunks.
- **No `watchdog` / inotify** — file watchers don't exist in pyodide.
- **Network via `pyodide.http`, not `urllib`/`requests`/`httpx`** —
  standard sync HTTP libs don't reach the network. Use:
  ```python
  from pyodide.http import pyfetch
  resp = await pyfetch("https://api.example.com/endpoint")
  data = await resp.json()
  ```
  For streaming responses, `pyfetch(...).js_response.body.getReader()`
  returns a browser ReadableStream reader — see `gemini-chat/gemini_chat.py`
  for a working streaming example. CORS still applies; the origin you're
  calling must allow the playground's origin.
- **No pure-Python packages beyond what the playground preloads** —
  `micropip.install(...)` can be called at boot, but each dep pulls from
  pyodide's lockfile or PyPI. Stick to pure-Python libs.

If your generator needs any of the above, it belongs in the native
`generators/` tree instead.

---

## 8. Complete example

`generators-wasm/note/` — the simplest possible generator, fits on a screen:

**`manifest.gen_yaml`**
```yaml
id: "note"
name: "Note"
version: "0.1.0"
summary: "Create a markdown note from a title and body."
entrypoint: "note.py"
runtime: "wasm"
execution_mode: "oneshot"

draft_files:
  - "settings.set_yaml"
summary_file: "settings.set_yaml"
summary_artifact: "note.md"
default_route: "draft"

inputs:
  cells:
    min: 0
    max: 0
```

**`settings.set_yaml`**
```yaml
fields:
  - key: title
    type: text
    label: "Title"
    default: "Untitled note"
  - key: body
    type: textarea
    label: "Body"
    default: ""
```

**`note.py`**
```python
from collimate.wasm_sdk import WasmContext, WasmResult

async def run(ctx: WasmContext) -> WasmResult:
    s = ctx.config_yaml("settings.set_yaml")
    title = (s.get("title") or "Untitled note").strip() or "Untitled note"
    body = s.get("body") or ""

    content = f"# {title}\n\n{body}\n" if body.strip() else f"# {title}\n\n_(empty note)_\n"
    summary = (body.strip().splitlines()[0] if body.strip() else "Empty note")[:120]

    return WasmResult(
        files={"note.md": content},
        cell_name=title,
        summary=summary,
    )
```

See also:

- `generators-wasm/echo/` — reads the workspace + chat history and writes
  a diagnostic report. Useful for confirming hydration works.
- `generators-wasm/gemini-chat/` — full streaming chat against Google
  Gemini, using `emit_partial` per-token + `ctx.cancelled` for Stop.
  Reference for the live-update pattern.

---

## 8a. The live-chat pattern

For generators that stream LLM output (or any other progress), the shape is:

```python
from collimate.wasm_sdk import Message, WasmContext, WasmResult

async def run(ctx: WasmContext) -> WasmResult:
    prompt = ctx.config_yaml("settings.set_yaml").get("prompt", "")
    history = list(ctx.messages) + [Message(role="user", content=prompt)]

    accum = ""
    async for token in stream_llm(history):
        if ctx.cancelled:
            accum += "\n\n_(stopped)_"
            break
        accum += token
        await ctx.emit_partial(
            files={"response.md": accum},
            summary=accum.splitlines()[0][:120],
            chat_messages=history + [Message(role="assistant", content=accum)],
        )

    return WasmResult(
        files={"response.md": accum},
        cell_name="Chat response",
        summary=accum.splitlines()[0][:120] if accum else "",
        chat_messages=history + [Message(role="assistant", content=accum)],
    )
```

Under pyodide the frontend polls `/api/state` every 500ms, so each
`emit_partial` surfaces in ~half a second. The final `WasmResult`
supersedes the last partial as the authoritative commit.

---

## 9. How the host runs it

You don't need to know this to write a generator, but briefly —
`api/process_manager.py::_run_wasm` is the dispatcher:

1. Read the manifest, confirm `runtime: wasm` (or `both`).
2. Hydrate `WasmContext`: read draft files from
   `.colreserved/config/files/`, chat messages from
   `.colreserved/.collimate_messages.json`, merge params. Inject
   `_host=self` so `emit_partial` / `cancelled` / `push_log` can call
   back into the ProcessManager.
3. `importlib.util.spec_from_file_location(...)` loads your module under
   a unique name so re-runs don't collide.
4. `await module.run(ctx)` — dispatched as an asyncio task so the
   `POST /runs` response returns immediately with `status: running`.
   The task persists through `manager._cleanup_task` so the reaper can
   clean up `active_managers` when it finishes.
5. Each `emit_partial` call goes through `_update_cell_initial` — same
   path the native IPC `update_cell_initial` uses. Files hash into CAS,
   a cell row is written, in-memory UI state refreshes.
6. Final `WasmResult` is committed identically; the cell keeps its state
   even when the generator returns an empty result (letting the last
   `emit_partial` stand).
7. `DELETE /runs/<id>` flips `manager._cancelled = True`; your
   generator must poll `ctx.cancelled` cooperatively to honor it.

No socket, no subprocess. Network calls from inside `run()` are the
usual pyodide `pyfetch` ones — they yield to the event loop, letting
concurrent `/api/state` pollers observe the partial state.
