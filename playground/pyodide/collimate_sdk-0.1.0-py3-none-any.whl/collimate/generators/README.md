# Generators — native generator set

The canonical generators. **The parent folders are the seeded cells** (see
`collimate.packaging.layout`): each top-level directory —
`browser/`, `guide/`, `code_env/`, `linux_env/`, `file_management/`,
`agent_run/`, `judgment/`, `agent/` — is one cell, its `cell.yaml` carrying
the display name, summary, icon, order, and the shared `_*` libraries
(`_agent_shared`, `_env_shared`, `_cdp_shared`, kept top-level) materialised
into it at build/seed time.

They run in a native Python subprocess. Running an
LLM is **not** a built-in — it lives in the `agent` generator, which owns the
multi-backend LLM engine + the composition tool definitions (in the sibling
`_agent_shared` cell). Other generators reach its one-shot mode by id via
`gen.call("agent", ...)` / `gen.spawn("agent", ...)`; users pick a mode preset
to run it directly. Backends (one-shot / chat modes):

- `pydantic-ai` — multi-provider (anthropic / gemini / openai / groq /
  cerebras), file + python tools, token streaming, 401 auto-retry.
- `claude-agent-sdk` — the Python Claude Agent SDK (headless), with two billing
  modes: `api_key` (`ANTHROPIC_API_KEY`) or `claude_code` (the logged-in Claude
  Code subscription — non-API).
- `gemini` — the Gemini CLI agent (`gemini -p`, headless), with two auth modes:
  `api_key` (`GEMINI_API_KEY`) or `google_oauth` (the CLI's logged-in Google
  account in `~/.gemini`).
- `google-adk` / `openai-agents` / `maf` — three additional agent frameworks,
  each adding a distinct paradigm (ADK = deterministic workflow agents;
  openai-agents = handoffs + guardrails; MAF = Microsoft Agent Framework teams,
  **experimental**). Multi-provider like pydantic-ai (`api_key` only); composition
  tools reach them over the streamable-http MCP bridge. Each needs its package
  installed (`google-adk` / `openai-agents[litellm]` / `agent-framework`) — a
  missing package fails only that backend. File/python workspace tools for these
  backends are a follow-up; the current backends cover that.

`auth` is a top-level choice honored only by the engine it belongs to: `api_key`
works everywhere, `claude_code` only on the claude-agent-sdk backend /
claude-terminal mode, `google_oauth` only on the gemini backend. A subscription/
OAuth option paired with a selection that can't honor it is rejected outright
rather than silently billing an API key.

The `agent` generator has four `mode`s: `oneshot` (the composition default),
`chat` (interactive streaming), `claude-terminal` (a live `claude` TTY in a
container; Claude models only), and `opencode` (opencode's own web UI). The
chat/terminal/opencode modes all leave a durable open-format transcript (`chats/<id>.json`), rendered by the assistant-ui chat renderer.

A single `exposure` dropdown grants composition tools as one **cumulative
ladder**, each tier a superset of the one below (every tier respects each cell's
"expose to generators" flag):

- **`none`** — no composition tools.
- **`create_cell`** — `create_cell`: drop a new **content** cell beside the
  current one for extra material (a draft, a side result), distinct from
  committing a generator/renderer.
- **`run_generators`** — read + run, no authoring: `list_generators` (discover
  installed generator ids/types), `list_exposed_cells`, `read_other_cell`,
  `call_generator` (one-shot preview), and `create_cell_with_generator` — create
  a new cell and run an existing **modify** generator on it (e.g. stand up a
  running terminal). Includes `create_cell`.
- **`modify_and_run`** — the full builder: everything above plus
  `write_other_cell`, `add_generator`/`add_renderer`, `check_renderer`, and
  `commit_generator` / `commit_renderer` to install a finished
  one (auto-exposed so the agent can keep iterating on it).

The tools are defined **once** (the `_COMPOSITION_TOOLS` registry in
`_agent_shared`) and every backend builds its own native format from it: the
pydantic-ai backend consumes an in-memory FastMCP server as a toolset, the
claude-agent-sdk backend gets an in-process MCP server, and the out-of-process
agents reach the same tools over the **SSE MCP bridge** in
`_agent_shared/mcp_bridge.py` — a small server hosted in the generator process
(where `gen.*` works): the **container agents** (claude-terminal, opencode)
connect over the Docker host gateway, and the **gemini CLI** (a headless
subprocess) connects on localhost via a trusted MCP server entry in a throwaway
`GEMINI_CLI_SYSTEM_SETTINGS_PATH` settings file. Adding a new harness is one
adapter over the same registry.

Every agent run also carries the **assumptions ledger** companion pass
(`ledger`, default ON, on a cheap model): the full-fidelity trace of the run
(thinking, tool activity) persists as `_agent/trace.json`, and two extraction
passes mine the commitments the agent *claimed* (from the trace) and the
commitments the artifacts *enact* (from the files) — linked into
confirmed / decoration / unstated-doctrine and written as
`_agent/assumptions.ledger` (+ `.md`), rendered by the `ledger` renderer.
Callers promote the ledger into whatever cell the call's output becomes;
fan-out generators (`seed_ideas`, `axes_first`) additionally merge their
workers' ledgers and compute the cross-candidate **differential** — the seams
where the candidates genuinely disagree.

`merge` is a deterministic file-union with no LLM.

| Generator | Type | Input cells | What it does |
|---|---|---|---|
| [`agent`](./agent/) | create/modify | 0–1 | The unified LLM agent. `mode` picks the surface: `oneshot` (engine for composition), `chat` (streaming chat), `claude-terminal` (live `claude` TTY in a container, with a Capture-Chat button; writes a `chats/main.json` transcript), `opencode` (its own TUI, or with `prefer_terminal` off the assistant-ui chat over `opencode serve`; writes a `chats/main.json` transcript). Every mode runs the assumptions-ledger companion pass by default (`_agent/trace.json` + `_agent/assumptions.ledger`). The `exposure` ladder grants composition tools (`none` → `create_cell` → `run_generators`: discover/read/run generators incl. a live modify cell → `modify_and_run`: the full builder). Self-contained Dockerfiles for the two container modes (`collimate-claude-tui`, `collimate-opencode`). |
| [`axes_first`](./axes_first/) | create | 0–1 | Frame the decision **before** generating: two independent agent passes propose the trade-off axes (disagreements flagged as contested frame), the run pauses on an editable `frame.axes` (the `axes` renderer — strike/add/reweight, then Continue), then one worker per accepted axis region emits a candidate cell carrying the accepted frame + its `assumptions.ledger`; the index cell gets the cross-candidate differential ledger. |
| [`challenge`](./challenge/) | create | 1–99 | The loop's namesake verb: throw one objection at every candidate side by side — adversarial agent runs (code execution on by default; reproductions beat arguments) produce a survived/failed evidence matrix (`challenges.challenge`, the `challenge` renderer). Leave the prompt blank to challenge the candidates' own recorded assumptions: differential seams first, then fact-kind claims, then unstated doctrines. |
| [`guide`](./guide/) | create | 0–1 | The resident Collimate expert (formerly `workshop`, which merged the former `builder` + `help`): one interactive surface that orients newcomers, answers Collimate/SDK questions (vision and philosophy as well as mechanics), writes reading material as docs cells beside the chat, **and** builds, tests, and installs generators & renderers. The `engine` field picks the surface — `in-process` (Collimate's streaming chat, spawning the agent per turn), `claude-cli` (a live Claude Code terminal), or `opencode` (opencode's web UI). All three get the generator/renderer + create-cell tools (the container engines via the MCP bridge) and the full reference library (`_shared_docs/`, including `collimate-overview.md` and `authoring-best-practices.md`). Tests by running a generator / compiling a renderer; commits via `commit_generator` / `commit_renderer`; publishes anything the agent writes under `deliverable/` as a new docs cell. |
| [`modify_files`](./modify_files/) | create | 0–1 | Calls the `agent` generator with file tools to edit the cell. Edited files come back in `result.files`; the run's `assumptions.ledger` is promoted into the modified cell. User-verified **facts** from the cell's ledger feed forward as established constraints (never preferences — that boundary is load-bearing). Summary points at the file the agent flagged as the answer. |
| [`seed_ideas`](./seed_ideas/) | create | 0–1 | Generates N mechanism-distinct idea directions and emits **N real output cells** via `gen.create_stack_cell` — each carrying its worker's `assumptions.ledger`; the index cell gets the merged cross-idea differential ledger. When the input carries an accepted `frame.axes`, directions are pinned to regions of the user's axis space — the go-wide-again move inside a chosen frame. |
| [`evaluate_best`](./evaluate_best/) | create | 2–99 | Judges each candidate independently, then picks one — on the **user's axes** when a `frame.axes` is present (per-axis scores → `results.scoreboard.json`, table renderer, pinned), weighing each candidate's ledger seams/doctrines and any attached challenge report (detected by format, excluded from candidates) as evidence. Output cell: winner's files + scoreboard + `why_picked.md` + `judgments.md` + the pick's own `assumptions.ledger`. |
| [`merge`](./merge/) | create | 2–99 | Union the files of every input cell. Topmost wins collisions — except colliding assumptions ledgers, which are **unioned deterministically** so merging never destroys the judgment record. No LLM. |
| [`vscode_env`](./vscode_env/) | modify | 0–1 | Containerised VS Code Server. Self-contained — ships its own `Dockerfile` + `entrypoint.sh` and builds `collimate-vscode-env:v3` on first use. Configurable extension list (Claude Code + Python + **Cline**), optional GitHub-keystore login, optional host `~/.claude` mount. No capture buttons on the iframe. Empty workspace when no input cell is attached. |
| [`run_terminal`](./run_terminal/) | modify | 1 | Run a terminal app on the cell's files in a Linux container, with live **bidirectional** file sync — whatever the app writes flows back to the cell. Self-contained — ships its own `Dockerfile` and builds `collimate-run-terminal:latest` (bash + git + gh + lazygit) on first use. Daemon. Default `command` is a live `bash` shell; the `lazygit` config tag runs lazygit with GitHub HTTPS auto-auth, and `command`/`image` point it at any other terminal app. |
| [`git_clone`](./git_clone/) | create | 0 | Clone a repo (https or ssh) from the picker prompt. Uses GitHub keystore creds for https when available, and the host SSH agent / `ssh_key_path` for `git@` URLs. Supports `--depth`, `--branch`, and `--recurse-submodules`. |

## Demo/playground (WASM) variant

A demo-only WASM mirror exists under [`../demo/`](../demo/) — see
`demo/README.md`. It is a separate, playground-only path.

## Config convention — one tag, not mirrored settings

**A generator's settings live on that generator.** The `agent`'s
`agent-config.set_yaml` carries the full LLM surface — `mode`, `backend`
(`pydantic-ai` / `claude-agent-sdk` / `gemini`), `auth` (`api_key` /
`claude_code` / `google_oauth`), `provider`, `model`, `max_tokens`,
`system_prompt`, the tool
knobs (`enable_python_tool` and the `exposure` composition ladder —
`none` / `create_cell` / `run_generators` / `modify_and_run`), and the
assumptions-ledger knobs (`ledger`
default **on**, `ledger_model`, `ledger_max_tokens`, `ledger_every_turns`);
`linux_env`'s `settings.set_yaml` carries its image. Each generator's
manifest `config_tags` name reusable presets of its own values.

**A parent that drives a sub-generator doesn't mirror those settings** — it
surfaces ONE text field per callee, `<callee>_config_tag`, plus only its
parent-specific knobs. The LLM parents (`axes_first`, `seed_ideas`,
`challenge`, `evaluate_best`, `modify_files`, `guide`) name an
`agent_config_tag` in their `config.set_yaml`; `code_runner` names a
`linux_env_config_tag` for the environment it spawns. Semantics everywhere:

- **blank** → the callee's own defaults;
- **a tag name** → the tag's settings, over which the parent overrides only
  what it has opinions about (e.g. an LLM parent takes the model from the
  tag while pinning one-shot mode, tools, and output schemas);
- **an unknown tag** → the run fails immediately, naming the available tags.

Resolution is one generic call — `gen.tag_config(gid, tag, overrides=...)`
— for any callee. The point: the user tunes each sub-generator ONCE, as
named tags on that generator, and every parent follows — no drifting copies
of the same dropdowns. It's a convention, not a hard rule: a parent
surfaces an individual callee setting only when it genuinely owns that
decision (the way `challenge` owns its python-on default).

API keys come from the centralized keystore (Settings → Keys). The `agent`
generator resolves them with `gen.api_key(provider)`, which pops the in-cell
modal when the relevant entry (`ANTHROPIC_API_KEY` / `GEMINI_API_KEY` /
`OPENAI_API_KEY` / `GROQ_API_KEY`) is missing.

Defaults are tuned so every config file is **optional to edit** — the
generator runs fine if the user doesn't open the Draft, provided the
relevant API key is set in Settings → Keys.

Each generator declares its PEP-723 dependencies inline so `uv run`
resolves them on first run. The LLM machinery lives in the `agent`
generator, so the **callers** depend only on `pyyaml` (plus `pydantic`
where they re-validate structured output):

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
```
