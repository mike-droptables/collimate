# Generators — native pydantic-ai generator set

The canonical generators. They run in a native Python subprocess using the
full `pydantic-ai` package (not slim). The LLM generators share the same
`pydantic-config.set_yaml` schema and support four providers out of the
box: Anthropic, Gemini, OpenAI, and Groq (via OpenAI-compatible
adapter).

`merge` is a deterministic file-union with no LLM.

| Generator | Type | Input cells | What it does |
|---|---|---|---|
| [`live_chat`](./live_chat/) | modify | 0–1 | Daemon-mode pydantic-ai chat with read/write/edit file tools. Files are live-editable; the user can keep sending messages after the first turn. |
| [`modify_files`](./modify_files/) | create | 0–1 | Agent with file tools edits the cell. Untouched files carry through via `gen.update_cell`'s implicit artifact selection. Summary points at the file the agent flagged as the answer. |
| [`seed_ideas`](./seed_ideas/) | create | 0–1 | Generates N distinct idea directions and emits **N real output cells** (not subfolders) via `gen.update_cell` + `gen.create_cell`. |
| [`evaluate_best`](./evaluate_best/) | create | 2–99 | Judges each candidate independently, then picks one. Output cell: the winner's files + `why_picked.md` + `judgments.md`. |
| [`generator_builder`](./generator_builder/) | create | 0–1 | Scaffolds a new native generator from a description. System prompt is the full `how-to-write-a-generator.md`. Input files are guidance only. |
| [`renderer_builder`](./renderer_builder/) | create | 0–1 | Same shape, but scaffolds a renderer using `how-to-write-a-renderer.md`. |
| [`merge`](./merge/) | create | 2–99 | Union the files of every input cell. On filename collisions the topmost wins. No LLM. |
| [`claude_cli`](./claude_cli/) | modify | 0–1 | Live Claude CLI in a terminal renderer. Self-contained — ships its own `Dockerfile` and builds `collimate-claude-cli:latest` on first use. Daemon + live-files. Extra button on the terminal snapshots the transcript (as a chat file) plus every project file into a new sibling cell. Auth is host `~/.claude` by default; switch to `api_key` to rely on `ANTHROPIC_API_KEY`. |
| [`vscode_env`](./vscode_env/) | modify | 0–1 | Containerised VS Code Server. Self-contained — ships its own `Dockerfile` + `entrypoint.sh` and builds `collimate-vscode-env:latest` on first use. Configurable extension list (defaults to Claude Code + Python), optional GitHub-keystore login, optional host `~/.claude` mount. No capture buttons on the iframe. Empty workspace when no input cell is attached. |
| [`git_clone`](./git_clone/) | create | 0 | Clone a repo (https or ssh) from the picker prompt. Uses GitHub keystore creds for https when available, and the host SSH agent / `ssh_key_path` for `git@` URLs. Supports `--depth`, `--branch`, and `--recurse-submodules`. |

## Demo/playground (WASM) variant

A demo-only WASM mirror exists under [`../demo/`](../demo/) — see
`demo/README.md`. It is a separate, playground-only path.

## Config file convention

Every LLM generator here has a `pydantic-config.set_yaml` with these
fields:

- `provider` — one of `anthropic` / `gemini` / `openai` / `groq`
- `model` — raw model id for that provider
- `max_tokens` — max tokens per message (default varies by generator)
- `system_prompt` — prepended to every turn (where applicable)

API keys come from the centralized keystore (Settings → Keys); the
generator's `llm.resolve_api_key(gen, provider)` call pops the in-cell
modal when the relevant entry (`ANTHROPIC_API_KEY` / `GEMINI_API_KEY`
/ `OPENAI_API_KEY` / `GROQ_API_KEY`) is missing.

Defaults are tuned so the file is **optional to edit** — the generator
runs fine if the user doesn't open the Draft, provided the relevant
API key is set in Settings → Keys.

Every LLM generator declares its PEP-723 dependencies inline so `uv run`
resolves them on first run:

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic-ai"]
# ///
```
