# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "docker"]
# ///
"""Claude CLI — live Claude Code TTY with a Capture Chat button.

Self-contained: ships its own ``Dockerfile`` and builds
``collimate-claude-cli:latest`` on first use.

What it does:
  * Builds (or reuses) the local image.
  * Starts one container per cell, PID 1 is ``sleep infinity`` — we just
    need a live target for ``docker exec -ti … claude``.
  * Mounts input-cell files into ``/home/coder/project`` and, when
    ``auth_source=host_claude``, bind-mounts ``~/.claude``.
  * Attaches a terminal via ``gen.terminal`` and publishes a
    ``claude.terminal`` artifact with a ``Capture Chat`` button.

Capture Chat clicks arrive through ``gen.wait_for_action()``. We respond
by reading the latest Claude transcript + project tree out of the live
container and emitting them as a new sibling cell via
``gen.create_stack_cell``.
"""
from __future__ import annotations

import asyncio
import io
import json
import os
import shlex
import tarfile
import time
import uuid
from pathlib import Path

import gen


IMAGE_TAG = "collimate-claude-cli:latest"
_CAPTURE_MAX_FILE_BYTES = 1_000_000


async def run() -> None:
    import docker
    import docker.errors

    cfg = gen.config("settings.set_yaml")
    auth_source = (cfg.get("auth_source") or "host_claude").strip().lower()
    model = (cfg.get("model") or "sonnet").strip()
    extra_args = (cfg.get("extra_args") or "").strip()
    first_message = (gen.prompt or "").strip()

    await gen.update(name="Claude CLI", summary="Starting…")

    try:
        client = docker.from_env()
        client.ping()
    except docker.errors.DockerException as e:
        raise RuntimeError(f"Cannot connect to Docker: {e}. Is Docker running?")

    _ensure_image(client)
    container = await _start_container(client, auth_source)

    try:
        command = ["claude"]
        if extra_args:
            command += shlex.split(extra_args)
        env: dict[str, str] = {"TERM": "xterm-256color"}
        if model:
            env["ANTHROPIC_MODEL"] = _full_model_id(model)

        gen.status("Registering terminal session…")
        term = await gen.terminal(
            container_id=container.id,
            command=command,
            cwd="/home/coder/project",
            env=env,
        )

        try:
            gen.update_file(
                "claude.terminal",
                json.dumps(
                    {
                        **term,
                        "label": f"Claude CLI · {model}",
                        "buttons": [
                            {"id": "capture_chat", "label": "Capture Chat"},
                        ],
                        "auth_source": auth_source,
                    },
                    indent=2,
                ),
            )

            if first_message:
                gen.history.append("user", first_message)
                _prime_first_message(container, first_message)

            await gen.update(
                name="Claude CLI",
                summary=f"live · {model}",
                summary_artifact="claude.terminal",
            )
            gen.status("Terminal ready — open the cell to attach.")

            while not gen.cancelled:
                action = await gen.wait_for_action(timeout=1.0)
                if action == "capture_chat":
                    try:
                        await _capture_chat(container)
                    except Exception as e:
                        gen.log(f"capture_chat failed: {e}")
                        gen.status(f"Capture failed: {e}")
                elif action:
                    gen.log(f"Unknown renderer action: {action}")
        finally:
            try:
                gen.stop_terminal(term.get("session_id", ""))
            except Exception as e:
                gen.log(f"stop_terminal failed: {e}")
    finally:
        _cleanup_container(container)


# ---------------------------------------------------------------------------
# Image build + container lifecycle
# ---------------------------------------------------------------------------

def _ensure_image(client) -> None:
    import docker.errors
    try:
        client.images.get(IMAGE_TAG)
        return
    except docker.errors.ImageNotFound:
        pass

    app_dir = Path(__file__).resolve().parent
    gen.status("Building Docker image (first run — may take a few minutes)…")
    gen.log(f"Building {IMAGE_TAG} from {app_dir}")
    started = time.monotonic()
    try:
        _, build_logs = client.images.build(path=str(app_dir), tag=IMAGE_TAG, rm=True)
        for chunk in build_logs:
            if chunk.get("error"):
                detail = chunk.get("errorDetail", {}).get("message") or chunk["error"]
                raise RuntimeError(f"Docker build failed: {detail}")
            line = (chunk.get("stream") or "").rstrip()
            if line:
                gen.log(line)
                if line.startswith("Step "):
                    gen.status(f"Building image — {line.split(':', 1)[0].strip()}")
    except docker.errors.BuildError as e:
        raise RuntimeError(f"Docker build failed: {e}")
    gen.log(f"Built {IMAGE_TAG} in {time.monotonic() - started:.1f}s")


async def _start_container(client, auth_source: str):
    workspace = gen.workspace_path()
    _relax_perms(workspace)

    volumes: dict = {
        workspace: {"bind": "/workspace", "mode": "ro"},
    }
    if auth_source == "host_claude":
        host_claude = os.path.expanduser("~/.claude")
        if os.path.isdir(host_claude):
            volumes[host_claude] = {"bind": "/home/coder/.claude", "mode": "rw"}
            gen.log("Mounting host ~/.claude into container")
        else:
            gen.log(
                f"auth_source=host_claude but {host_claude} does not exist — container "
                "will start unauthenticated"
            )

    env: dict[str, str] = {}
    if auth_source == "api_key":
        env["ANTHROPIC_API_KEY"] = await gen.api_key(
            "anthropic",
            description="Anthropic API key for Claude CLI",
        )

    container_name = f"collimate-claude-cli-{uuid.uuid4().hex[:8]}"
    gen.status(f"Starting container {container_name}…")
    container = client.containers.run(
        IMAGE_TAG,
        detach=True,
        name=container_name,
        volumes=volumes,
        environment=env,
        labels={
            "com.collimate.run_id": os.environ.get("COLLIMATE_RUN_ID", ""),
            "com.collimate.kind": "claude_cli",
        },
    )

    container.exec_run(
        [
            "bash", "-lc",
            "mkdir -p /home/coder/project && "
            "if compgen -G '/workspace/*' > /dev/null; then "
            "  cp -a /workspace/. /home/coder/project/ || true; "
            "fi",
        ],
        user="coder",
    )
    return container


def _prime_first_message(container, message: str) -> None:
    """Run ``claude -p <msg>`` in the background so the transcript
    contains the first turn by the time the user attaches the terminal."""
    try:
        container.exec_run(
            [
                "bash", "-lc",
                f"nohup claude -p {shlex.quote(message)} "
                "--dangerously-skip-permissions >/dev/null 2>&1 &",
            ],
            user="coder",
            workdir="/home/coder/project",
            detach=True,
        )
    except Exception as e:
        gen.log(f"could not prime first message: {e}")


def _cleanup_container(container) -> None:
    import docker.errors
    gen.log(f"Stopping container {container.name}…")
    try:
        container.stop(timeout=2)
        container.remove(force=True)
    except docker.errors.NotFound:
        pass
    except Exception as e:
        gen.log(f"container stop failed ({e}); force removing")
        try:
            container.remove(force=True)
        except Exception as e2:
            gen.log(f"Failed to remove container {container.name}: {e2}")


def _relax_perms(root: str) -> None:
    try:
        os.chmod(root, 0o755)
        for dirpath, dirnames, filenames in os.walk(root):
            for d in dirnames:
                try:
                    os.chmod(os.path.join(dirpath, d), 0o755)
                except OSError:
                    pass
            for f in filenames:
                try:
                    os.chmod(os.path.join(dirpath, f), 0o644)
                except OSError:
                    pass
    except OSError as e:
        gen.log(f"Could not relax workspace permissions: {e}")


def _full_model_id(short: str) -> str:
    table = {
        "haiku": "claude-haiku-4-5-20251001",
        "sonnet": "claude-sonnet-4-6",
        "opus": "claude-opus-4-7",
    }
    return table.get(short, short)


# ---------------------------------------------------------------------------
# Capture Chat — snapshot messages + files into a new side cell
# ---------------------------------------------------------------------------

async def _capture_chat(container) -> None:
    gen.status("Capturing chat + files…")
    messages, raw_jsonl = _pull_claude_transcript(container)
    files = _pull_project_files(container, "/home/coder/project")

    snapshot: dict[str, str] = {}
    for rel, text in files:
        if rel == "claude_session.jsonl":
            continue
        snapshot[rel] = text
    if raw_jsonl:
        snapshot["claude_session.jsonl"] = raw_jsonl

    cell_id = await gen.create_stack_cell(
        "Claude CLI capture",
        summary=f"{len(messages)} messages · {len(files)} files",
        files=snapshot,
    )
    gen.log(
        f"Captured Claude CLI session into cell {cell_id} "
        f"({len(messages)} messages, {len(files)} files)"
    )
    gen.status("Terminal ready — open the cell to attach.")


def _pull_claude_transcript(container) -> tuple[list[dict], str | None]:
    ls = container.exec_run(
        ["bash", "-lc", "ls -t /home/coder/.claude/projects/*/*.jsonl 2>/dev/null | head -1"]
    )
    if ls.exit_code != 0:
        return [], None
    latest = ls.output.decode("utf-8", errors="replace").strip()
    if not latest:
        return [], None

    cat = container.exec_run(["cat", latest])
    if cat.exit_code != 0:
        return [], None
    raw = cat.output.decode("utf-8", errors="replace")

    messages: list[dict] = []
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue
        if entry.get("type") not in ("user", "assistant"):
            continue
        msg = entry.get("message") or {}
        role = msg.get("role") or entry.get("type")
        text = _extract_text(msg.get("content"))
        if not text:
            continue
        messages.append({"role": role, "content": text})
    return messages, raw


def _extract_text(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                t = block.get("text") or ""
                if t:
                    parts.append(t)
        return "\n".join(parts)
    return ""


def _pull_project_files(container, project_dir: str) -> list[tuple[str, str]]:
    allowed: set[str] | None = None
    if container.exec_run(["test", "-d", os.path.join(project_dir, ".git")]).exit_code == 0:
        ls = container.exec_run(
            ["git", "-C", project_dir, "ls-files", "--cached", "--others", "--exclude-standard"]
        )
        if ls.exit_code == 0:
            raw = ls.output.decode("utf-8", errors="replace")
            allowed = {line for line in raw.splitlines() if line.strip()}

    bits, _ = container.get_archive(project_dir)
    buf = io.BytesIO()
    for chunk in bits:
        buf.write(chunk)
    buf.seek(0)

    out: list[tuple[str, str]] = []
    with tarfile.open(fileobj=buf, mode="r") as tar:
        for member in tar.getmembers():
            if not member.isfile():
                continue
            parts = member.name.split("/", 1)
            if len(parts) < 2:
                continue
            rel = parts[1]
            if rel == ".git" or rel.startswith(".git/"):
                continue
            if allowed is not None and rel not in allowed:
                continue
            if member.size > _CAPTURE_MAX_FILE_BYTES:
                continue
            f = tar.extractfile(member)
            if f is None:
                continue
            try:
                text = f.read().decode("utf-8")
            except UnicodeDecodeError:
                continue
            out.append((rel, text))
    return out


if __name__ == "__main__":
    gen.main(run)
