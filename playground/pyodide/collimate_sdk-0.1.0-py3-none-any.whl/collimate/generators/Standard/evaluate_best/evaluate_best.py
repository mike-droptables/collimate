# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic-ai"]
# ///
"""Evaluate Best — independent judgments, then final pick.

Two phases:

  1. Each input cell is judged independently (parallel pydantic-ai
     agents). Output: score + strengths/weaknesses per candidate.
  2. A second agent sees the judgments and picks one winner.

Output cell: the winning cell's files carried over verbatim + two new
files — ``why_picked.md`` (the pick reasoning) and ``judgments.md``
(the full scoreboard).
"""
from __future__ import annotations

import asyncio

from pydantic import BaseModel, Field

import gen


class Judgment(BaseModel):
    score: int = Field(ge=0, le=100, description="0–100, how well this candidate meets the criteria.")
    strengths: list[str] = Field(default_factory=list)
    weaknesses: list[str] = Field(default_factory=list)
    summary: str = Field(description="1–2 sentence overall take.")


class Pick(BaseModel):
    winner: str = Field(description="Exact label of the winning candidate.")
    reasoning: str = Field(description="2–6 sentences on why this candidate won.")


async def run() -> None:
    cfg = gen.config("pydantic-config.set_yaml")
    provider = (cfg.get("provider") or "anthropic").strip().lower()
    model = (cfg.get("model") or "claude-sonnet-4-6").strip()
    max_tokens = _int(cfg.get("max_tokens"), default=2048)
    system_prompt = (cfg.get("system_prompt") or "").strip()
    criteria = (gen.prompt or "").strip()
    if not criteria:
        raise Exception("Describe the criteria for 'best' in the picker prompt.")

    candidates = list(gen.input_groups().items())
    if len(candidates) < 2:
        raise Exception("Evaluate Best needs at least 2 input cells.")

    gen.status(f"Judging {len(candidates)} candidates…")

    async def judge(label: str, files: dict[str, str]) -> Judgment:
        preview = _preview_files(files)
        agent_obj = await gen.agent(
            system_prompt=system_prompt or "",
            output_type=Judgment,
            provider=provider,
            model=model,
            max_tokens=max_tokens,
        )
        user = (
            f"## Criteria\n\n{criteria}\n\n"
            f"## Candidate `{label}`\n\n{preview}\n\n"
            "Produce a Judgment. Be specific."
        )
        result = await agent_obj.run(user)
        out = getattr(result, "output", None) or getattr(result, "data", None)
        if not isinstance(out, Judgment):
            raise Exception(f"judge returned no structured output for {label}")
        return out

    # Each ``judge`` builds its own auto-retry agent; concurrent
    # auth-failures coordinate behind ``gen.api_key``'s per-provider lock
    # so only one modal pops per retry burst.
    coros = [judge(label, files) for label, files in candidates]
    results = await asyncio.gather(*coros, return_exceptions=True)
    ranked: list[tuple[str, Judgment | Exception]] = list(
        zip([label for label, _ in candidates], results)
    )

    gen.status("Picking winner…")

    async def pick() -> Pick:
        lines = [f"## Criteria\n\n{criteria}\n", "## Judgments", ""]
        for label, jmt in ranked:
            if isinstance(jmt, Exception):
                lines.append(f"### `{label}` — (judgment failed: {jmt})")
                lines.append("")
                continue
            lines.append(
                f"### `{label}` — score {jmt.score}\n\n"
                + (f"**Strengths:** {'; '.join(jmt.strengths)}\n\n" if jmt.strengths else "")
                + (f"**Weaknesses:** {'; '.join(jmt.weaknesses)}\n\n" if jmt.weaknesses else "")
                + jmt.summary
            )
            lines.append("")
        user = "\n".join(lines) + "\n\nPick one winner. The winner label MUST be one from the list."
        agent_obj = await gen.agent(
            system_prompt=(
                "You pick a single winner from the independent judgments below. "
                "Weigh the criteria and scores together."
            ),
            output_type=Pick,
            provider=provider,
            model=model,
            max_tokens=max_tokens,
        )
        result = await agent_obj.run(user)
        out = getattr(result, "output", None) or getattr(result, "data", None)
        if not isinstance(out, Pick):
            raise Exception("pick agent returned no structured output")
        return out

    try:
        p = await pick()
        winner = p.winner if any(label == p.winner for label, _ in ranked) else _heuristic_winner(ranked)
        reasoning = p.reasoning
    except Exception as e:
        gen.log(f"pick agent failed: {e}")
        winner = _heuristic_winner(ranked)
        reasoning = f"Automatic pick (judge call failed: `{e}`). Chose the highest-scoring candidate."

    # Drop every input file from the output stage; we'll only carry the
    # winning candidate's files forward.
    for inp in list(gen.list_files()):
        gen.delete_file(inp)

    winning_files = dict(next((fs for label, fs in candidates if label == winner), {}))
    for rel, content in winning_files.items():
        gen.update_file(rel, content)

    gen.update_file("why_picked.md", _why_md(winner, reasoning, ranked, criteria))
    gen.update_file("judgments.md", _judgments_md(ranked))

    await gen.update(
        name=f"Winner: {winner}",
        summary=_first_line(reasoning),
        summary_artifact="why_picked.md",
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _preview_files(files: dict[str, str], max_bytes: int = 4000) -> str:
    if not files:
        return "_(no files)_"
    out: list[str] = []
    for p in sorted(files):
        content = files[p]
        if len(content) > max_bytes:
            content = content[:max_bytes] + f"\n\n_(truncated — full size {len(content)} bytes)_"
        out.append(f"### `{p}`\n\n```\n{content}\n```")
    return "\n\n".join(out)


def _heuristic_winner(ranked: list[tuple[str, Judgment | Exception]]) -> str:
    valid = [(label, j) for label, j in ranked if isinstance(j, Judgment)]
    if valid:
        return max(valid, key=lambda pair: pair[1].score)[0]
    return ranked[0][0] if ranked else "unknown"


def _judgments_md(ranked: list[tuple[str, Judgment | Exception]]) -> str:
    lines = ["# Independent judgments", ""]
    for label, j in sorted(
        ranked,
        key=lambda pair: pair[1].score if isinstance(pair[1], Judgment) else -1,
        reverse=True,
    ):
        if isinstance(j, Exception):
            lines += [f"## `{label}` — error", "", f"```\n{j}\n```", ""]
            continue
        lines += [f"## `{label}` — score {j.score}", "", j.summary, ""]
        if j.strengths:
            lines.append("**Strengths**")
            lines += [f"- {s}" for s in j.strengths]
            lines.append("")
        if j.weaknesses:
            lines.append("**Weaknesses**")
            lines += [f"- {w}" for w in j.weaknesses]
            lines.append("")
    return "\n".join(lines) + "\n"


def _why_md(
    winner: str, reasoning: str, ranked: list[tuple[str, Judgment | Exception]], criteria: str,
) -> str:
    lines = [
        f"# Winner: `{winner}`",
        "",
        "## Why",
        "",
        reasoning.strip(),
        "",
        "## Criteria",
        "",
        criteria.strip(),
        "",
        "## Scoreboard",
        "",
    ]
    for label, j in sorted(
        ranked,
        key=lambda pair: pair[1].score if isinstance(pair[1], Judgment) else -1,
        reverse=True,
    ):
        if isinstance(j, Exception):
            lines.append(f"- `{label}` — judgment failed")
        else:
            marker = "**" if label == winner else ""
            lines.append(f"- {marker}`{label}`{marker} — score {j.score}")
    return "\n".join(lines) + "\n"


def _first_line(text: str, limit: int = 120) -> str:
    text = (text or "").strip()
    if not text:
        return ""
    first = text.splitlines()[0]
    return first[:limit] + ("…" if len(first) > limit else "")


def _int(raw, default: int) -> int:
    try:
        n = int(raw)
        return n if n > 0 else default
    except (TypeError, ValueError):
        return default


if __name__ == "__main__":
    gen.main(run)
