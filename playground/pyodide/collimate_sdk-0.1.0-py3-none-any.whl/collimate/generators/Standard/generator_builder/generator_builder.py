# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic-ai"]
# ///
"""Generator Builder — pydantic-ai scaffold of a new generator.

Reads the canonical ``how-to-write-a-generator.md`` guide via
``collimate.shared.shared_path`` and passes it as the system prompt. The
agent uses ``write_file`` tool calls to emit files into a staging dict;
after the run, each staged file is written to the output cell.

Input files (if any) are exposed as read-only guidance via
``read_guidance`` and are explicitly dropped from the output cell —
only files the agent writes survive.

After the agent finishes, the staged ``manifest.gen_yaml`` is linted via
``collimate.lint.lint_generator_manifest_data`` with
``target_runtime='native'``. If lint errors are found, the agent gets one
retry with the errors fed back as a fix prompt; if errors persist after
the retry, the run fails loudly rather than committing a broken
generator.
"""
from __future__ import annotations

import yaml
from collimate.lint import Level, lint_generator_manifest_data
from collimate.shared import shared_path
import gen


async def run() -> None:
    cfg = gen.config("pydantic-config.set_yaml")
    provider = (cfg.get("provider") or "anthropic").strip().lower()
    model = (cfg.get("model") or "claude-sonnet-4-6").strip()
    max_tokens = _int(cfg.get("max_tokens"), default=8192)
    prompt = (gen.prompt or "").strip()
    if not prompt:
        raise Exception("Describe the generator you want to build in the picker prompt.")

    try:
        guide = shared_path("docs", "how-to-write-a-generator.md").read_text(encoding="utf-8")
    except FileNotFoundError as e:
        raise Exception(
            "Reference guide 'how-to-write-a-generator.md' not found under "
            f"shared/docs/. Details: {e}"
        )

    # Guidance is the input cell's files; surface them as a tool, not a carry-through.
    guidance = {p: gen.read_file(p) for p in gen.list_files()}
    stage: dict[str, str] = {}

    from pydantic_ai import Tool

    async def list_guidance() -> list[str]:
        """List any reference files attached via the input cell. These
        are for reading only — do NOT copy them into the output."""
        return sorted(guidance.keys())

    async def read_guidance(path: str) -> str:
        """Read a guidance file attached via the input cell."""
        return guidance.get(path, f"ERROR: file not found: {path}")

    async def write_file(path: str, content: str) -> str:
        """Write a file into the new scaffold. Path is relative to the
        new cell root (e.g. ``manifest.gen_yaml``, ``my_gen.py``)."""
        stage[path] = content
        return f"wrote {len(content)} bytes to {path}"

    async def list_written() -> list[str]:
        """List what you've written so far."""
        return sorted(stage.keys())

    required = (
        "Required files for a generator:\n"
        "  - manifest.gen_yaml (MUST declare a `category`; runtime defaults "
        "to native, declare `runtime: \"native\"` or `\"both\"` explicitly "
        "if you want both)\n"
        "  - <id>.py  (the entrypoint; filename must match 'entrypoint' in the manifest)\n"
        "  - settings.set_yaml or any other draft files if the manifest declares them\n"
    )

    system_prompt = (
        "You are scaffolding a complete, working Collimate generator from a "
        "user description. Follow the reference guide below exactly — it is "
        "the authoritative spec for the manifest schema, the SDK API, and "
        "the file layout.\n\n"
        f"{required}\n"
        "Use the write_file tool to emit every file in full. Do not "
        "abbreviate, do not use placeholders. When you're done, stop — do "
        "not describe the files in prose.\n\n"
        f"--- BEGIN REFERENCE GUIDE ---\n{guide}\n--- END REFERENCE GUIDE ---\n"
    )

    gen.status(f"Scaffolding generator with {provider} · {model}…")
    gen.log(f"[generator-builder] {provider} · {model} · guide={len(guide)} chars")

    tools = [
        Tool(list_guidance),
        Tool(read_guidance),
        Tool(write_file),
        Tool(list_written),
        # Python execution: lets the agent sanity-check or generate
        # auxiliary content (test the scaffolded entrypoint, render a
        # diagram, exercise an example) before claiming done.
        gen.python_tool(),
    ]
    user_msg = (
        f"Build a generator that does the following:\n\n{prompt}\n\n"
        "Write every required file via write_file. Do not write README.md "
        "or any extra files — only the files the generator needs to run."
    )

    agent = await gen.agent(
        system_prompt=system_prompt,
        tools=tools,
        provider=provider,
        model=model,
        max_tokens=max_tokens,
    )
    await agent.run(user_msg)  # auto-retries on auth failure

    if not stage:
        raise Exception("The agent returned without writing any files.")

    # Validate the agent's manifest. One retry with errors fed back; if
    # the retry doesn't fix things, fail loudly instead of committing a
    # broken scaffold.
    errors = _lint_stage(stage)
    if errors:
        gen.log(f"[generator-builder] lint errors after first agent run: {len(errors)}")
        await agent.run(_fix_prompt(errors))
        errors = _lint_stage(stage)
    if errors:
        raise Exception(
            "Generator scaffold is invalid after one retry. "
            "Common causes: missing `category`, `entrypoint:` referencing "
            "a file the agent didn't write, or unknown manifest fields. "
            "Errors:\n" + "\n".join(f"  - {e}" for e in errors)
        )

    # Drop guidance files from the output cell — they were read-only context.
    for guidance_path in guidance:
        gen.delete_file(guidance_path)
    # Stage every file the agent wrote.
    for path, content in stage.items():
        gen.update_file(path, content)

    entry = (
        "manifest.gen_yaml" if "manifest.gen_yaml" in stage
        else ("manifest.rend_yaml" if "manifest.rend_yaml" in stage else sorted(stage)[0])
    )
    await gen.update(
        name=f"generator scaffold · {provider}",
        summary=f"{len(stage)} file(s) · entry: `{entry}`",
        summary_artifact=entry,
    )


def _lint_stage(stage: dict[str, str]) -> list[str]:
    """Lint the staged ``manifest.gen_yaml`` against the native runtime
    contract. Returns a list of human-readable error strings (empty when
    valid). Warnings are not surfaced — only hard errors block commit.
    """
    if "manifest.gen_yaml" not in stage:
        return ["manifest.gen_yaml was not written"]
    try:
        data = yaml.safe_load(stage["manifest.gen_yaml"])
    except yaml.YAMLError as e:
        return [f"manifest.gen_yaml is not valid YAML: {e}"]
    issues = lint_generator_manifest_data(
        data if isinstance(data, dict) else {},
        files_present=set(stage.keys()),
        target_runtime="native",
    )
    return [
        f"{i.field or '<root>'}: {i.message}"
        for i in issues
        if i.level == Level.ERROR
    ]


def _fix_prompt(errors: list[str]) -> str:
    bullets = "\n".join(f"  - {e}" for e in errors)
    return (
        "Your previous output has the following manifest problems. "
        "Fix EVERY one of them by re-emitting the corrected files via "
        "write_file. Do not write README.md or any explanation files — "
        "just the corrected manifest and any other files that need "
        f"updating.\n\n{bullets}\n"
    )


def _int(raw, default: int) -> int:
    try:
        n = int(raw)
        return n if n > 0 else default
    except (TypeError, ValueError):
        return default


if __name__ == "__main__":
    gen.main(run)
