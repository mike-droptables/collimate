# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic-ai"]
# ///
"""Live Chat — streaming pydantic-ai chat with read/write/edit tools.

The whole turn body is one ``gen.chat_turn`` call: it streams text
deltas via ``gen.chat_stream`` so the assistant bubble fills in live,
polls ``gen.cancelled`` per chunk, and retries once on auth failure.
"""
from __future__ import annotations

import gen


async def run() -> None:
    cfg = gen.config("pydantic-config.set_yaml")
    agent = await gen.agent(
        system_prompt=(cfg.get("system_prompt") or "").strip(),
        tools=gen.file_tools() + [gen.python_tool()],
    )

    await gen.update(name="Live Chat", summary="Ready — type your message below")

    async for user_msg in gen.chat_loop():
        gen.history.append("user", user_msg)
        await gen.update()  # surface the user turn immediately

        reply = await gen.chat_turn(agent, user_msg)
        gen.history.append("assistant", reply or "_(empty response)_")
        await gen.update(summary=user_msg[:80].replace("\n", " "))


if __name__ == "__main__":
    gen.main(run)
