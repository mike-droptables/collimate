# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic-ai"]
# ///
"""Modify Files — pydantic-ai agent edits cell files.

  * 0 or 1 input cells → single agent run; mutates the placeholder.
  * 2+ input cells → fan out (n → n): one agent per input, in parallel,
    each emitted as its own stack cell.

The agent gets the standard ``gen.file_tools()``-shaped read/write/edit
tools (scoped to a per-candidate in-memory dict so parallel runs don't
collide), a ``pick_summary_file`` tool that nominates the file the
result should preview, and a ``run_python`` tool for arbitrary
computation / artifact generation.
"""
from __future__ import annotations

import asyncio

import gen


async def run() -> None:
    cfg = gen.config("pydantic-config.set_yaml")
    provider = (cfg.get("provider") or "anthropic").strip().lower()
    model = (cfg.get("model") or "claude-sonnet-4-6").strip()
    max_tokens = _int(cfg.get("max_tokens"), default=4096)
    system_prompt = (cfg.get("system_prompt") or "").strip()
    prompt = (gen.prompt or "").strip()
    if not prompt:
        raise Exception("Describe the task in the picker prompt.")

    groups = gen.input_groups()

    # 0 or 1 input → single placeholder. Multi-input → n→n fan-out.
    if len(groups) <= 1:
        files = next(iter(groups.values())) if groups else {}
        await _modify_one(
            label="input",
            files=files,
            prompt=prompt,
            system_prompt=system_prompt,
            provider=provider,
            model=model,
            max_tokens=max_tokens,
            as_stack_cell=False,
        )
        return

    gen.status(f"Modifying {len(groups)} cells in parallel…")
    await asyncio.gather(*[
        _modify_one(
            label=label,
            files=files,
            prompt=prompt,
            system_prompt=system_prompt,
            provider=provider,
            model=model,
            max_tokens=max_tokens,
            as_stack_cell=True,
        )
        for label, files in groups.items()
    ])
    # Drop the workspace-level inputs/ files from the placeholder; the
    # n stack cells own the per-candidate output now.
    for inp in list(gen.list_files()):
        gen.delete_file(inp)
    await gen.update(
        name=f"modify-files × {len(groups)}",
        summary=f"Modified {len(groups)} cells in parallel",
    )


async def _modify_one(
    *,
    label: str,
    files: dict[str, str],
    prompt: str,
    system_prompt: str,
    provider: str,
    model: str,
    max_tokens: int,
    as_stack_cell: bool,
) -> None:
    """Run the agent against ONE candidate file set.

    The candidate's files live in an in-memory dict ``stage`` (rather
    than the bridge's workspace) so parallel ``_modify_one`` calls
    don't collide on shared filesystem state. Tools read / write
    against the dict; on completion the dict is committed as either
    the placeholder cell (single-input) or a fresh stack cell (multi).
    """
    stage = dict(files)
    original = dict(files)
    summary_ref = {"path": ""}

    from pydantic_ai import Tool

    async def list_files_t() -> list[str]:
        """List every file currently in this candidate's set."""
        return sorted(stage.keys())

    async def read_file_t(path: str) -> str:
        """Read the full text of one of this candidate's files."""
        if path not in stage:
            return f"ERROR: file not found: {path}"
        return stage[path]

    async def write_file_t(path: str, content: str) -> str:
        """Create or overwrite ``path`` (UTF-8) in this candidate."""
        stage[path] = content
        return f"wrote {len(content)} bytes to {path}"

    async def edit_file_t(path: str, old: str, new: str) -> str:
        """First-match string replace inside ``path``."""
        if path not in stage:
            return f"ERROR: file not found: {path}"
        if old not in stage[path]:
            return f"ERROR: old text not found in {path}"
        stage[path] = stage[path].replace(old, new, 1)
        return f"edited {path}"

    async def pick_summary_file(path: str) -> str:
        """Nominate the one file that best answers the user's ask."""
        if path not in stage:
            return f"ERROR: {path} is not a file in this candidate."
        summary_ref["path"] = path
        return f"summary file set to {path}"

    tools = [
        Tool(list_files_t, name="list_files"),
        Tool(read_file_t, name="read_file"),
        Tool(write_file_t, name="write_file"),
        Tool(edit_file_t, name="edit_file"),
        Tool(pick_summary_file),
        # Per-candidate Python tool also runs against the bridge's
        # workspace, but artifacts created from the script are
        # captured into the stack cell at flush time below — see the
        # snapshot-diff merge after agent.run.
        gen.python_tool(),
    ]

    gen.log(f"[modify-files:{label}] {provider} · {model} · {len(original)} input files")

    user_msg = (
        f"Candidate: `{label}`\n\n"
        f"User task:\n\n{prompt}\n\n"
        "Use list_files / read_file / write_file / edit_file to mutate "
        "this candidate's files. You may call run_python to compute or "
        "generate artifacts (charts, tables, …). When done, call "
        "pick_summary_file with the single path that best answers the "
        "task; that file drives the cell's summary preview."
    )

    # Snapshot the bridge workspace before the agent runs so any files
    # the python_tool creates can be merged into ``stage`` afterwards.
    # This means an agent that runs Python in parallel candidates may
    # see workspace-level cross-talk — acceptable for v1; downstream
    # candidates won't include another candidate's python output
    # because we filter by "new since this candidate started".
    workspace_before = gen.snapshot() if as_stack_cell else None

    agent = await gen.agent(
        system_prompt=system_prompt or "",
        tools=tools,
        provider=provider,
        model=model,
        max_tokens=max_tokens,
    )
    result = await agent.run(user_msg)  # auto-retries on auth failure

    # Merge any python_tool-produced files into this candidate's stage.
    if as_stack_cell and workspace_before is not None:
        workspace_after = gen.snapshot()
        for path, h in workspace_after.items():
            if workspace_before.get(path) == h:
                continue
            # Skip cross-cell input dirs — we don't want one candidate
            # to swallow another's input files.
            if path.startswith("inputs/"):
                continue
            try:
                stage[path] = gen.read_file(path)
            except FileNotFoundError:
                continue

    # Prose-only fallback: agent answered in chat instead of editing files.
    if _stage_unchanged(stage, original):
        text = _extract_text(result)
        if text:
            stage["output.md"] = text
            if not summary_ref["path"]:
                summary_ref["path"] = "output.md"

    picked = summary_ref["path"]
    if not picked or picked not in stage:
        picked = _best_guess_summary(stage, original)

    summary = f"→ `{picked}`" if picked else f"Modified {_changed_count(stage, original)} file(s)"

    if as_stack_cell:
        await gen.create_stack_cell(
            name=f"{label} · {model}",
            summary=summary,
            summary_artifact=picked or None,
            files=stage,
        )
    else:
        for path, content in stage.items():
            gen.update_file(path, content)
        await gen.update(
            name=f"modify-files · {provider} · {model}",
            summary=summary,
            summary_artifact=picked or None,
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_text(result) -> str:
    if result is None:
        return ""
    for attr in ("output", "data"):
        val = getattr(result, attr, None)
        if val:
            return str(val).strip()
    return ""


def _stage_unchanged(stage: dict[str, str], original: dict[str, str]) -> bool:
    return stage == original


def _changed_count(stage: dict[str, str], original: dict[str, str]) -> int:
    changed = sum(1 for p, c in stage.items() if original.get(p) != c)
    changed += sum(1 for p in original if p not in stage)
    return changed


def _best_guess_summary(stage: dict[str, str], original: dict[str, str]) -> str:
    changed = [p for p, c in stage.items() if original.get(p) != c]
    if not changed:
        return ""
    md = [p for p in changed if p.lower().endswith(".md")]
    return md[0] if md else changed[0]


def _int(raw, default: int) -> int:
    try:
        n = int(raw)
        return n if n > 0 else default
    except (TypeError, ValueError):
        return default


if __name__ == "__main__":
    gen.main(run)
