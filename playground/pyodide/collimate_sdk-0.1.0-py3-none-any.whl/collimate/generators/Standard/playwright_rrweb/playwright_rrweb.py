# /// script
# requires-python = ">=3.11"
# dependencies = ["playwright", "aiohttp", "pyyaml"]
# ///
"""Playwright rrweb Live — daemon that streams a live website via rrweb.

Headless Chromium navigates to the user's URL with CSP bypass on, rrweb
records DOM mutations + input events from inside the page, and a tiny
aiohttp server broadcasts those events over a WebSocket. The companion
``rrweb`` renderer replays the stream in the cell — sidestepping
X-Frame-Options and frame-ancestors because no iframe of the target
site is involved.
"""
from __future__ import annotations

import asyncio
import json
import os
import socket
import sys
from typing import Any

from aiohttp import web
from playwright.async_api import Error as PlaywrightError, async_playwright

import gen

# In-process state shared between the page-side binding and the WS handler.
_events: list[dict[str, Any]] = []
_clients: set[web.WebSocketResponse] = set()
_buffer_lock = asyncio.Lock()

_FULL_SNAPSHOT = 2
_META = 4


INIT_JS_TEMPLATE = """
(() => {
  if (window.__rrweb_started) return;
  window.__rrweb_started = true;
  const start = () => {
    if (!window.rrweb) { setTimeout(start, 50); return; }
    try {
      window.rrweb.record({
        emit: (event) => {
          try { window.__rrwebPush(JSON.stringify(event)); }
          catch (e) { /* binding gone (page closing) */ }
        },
        checkoutEveryNms: __CHECKOUT_MS__,
      });
    } catch (e) { console.error('rrweb record failed', e); }
  };
  if (window.rrweb) { start(); return; }
  const s = document.createElement('script');
  s.src = 'https://cdn.jsdelivr.net/npm/rrweb@__VERSION__/dist/rrweb.min.js';
  s.onload = start;
  s.onerror = () => console.error('failed to load rrweb');
  (document.head || document.documentElement).appendChild(s);
})();
"""


async def run() -> None:
    cfg = gen.config("settings.set_yaml")
    width = _int(cfg.get("viewport_width"), 1280)
    height = _int(cfg.get("viewport_height"), 800)
    user_agent = (cfg.get("user_agent") or "").strip() or None
    rrweb_version = (cfg.get("rrweb_version") or "2.0.0-alpha.4").strip()
    checkout_ms = _int(cfg.get("checkout_every_ms"), 30000)

    url = (gen.prompt or "").strip()
    if not url:
        raise RuntimeError(
            "Provide a URL as the picker prompt (e.g. https://example.com)."
        )
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    init_js = (
        INIT_JS_TEMPLATE
        .replace("__VERSION__", rrweb_version)
        .replace("__CHECKOUT_MS__", str(checkout_ms))
    )

    port = _find_free_port(9100)
    runner = await _start_aiohttp(port)

    gen.status("Launching Chromium…")
    pw = await async_playwright().start()
    try:
        browser = await pw.chromium.launch(headless=True)
    except PlaywrightError as exc:
        msg = str(exc)
        if "Executable doesn't exist" not in msg and "playwright install" not in msg:
            raise
        gen.status("Installing Chromium (first run)…")
        gen.log("Chromium not found, running 'playwright install chromium'")
        rc, out = await gen.run_subprocess(
            [sys.executable, "-m", "playwright", "install", "chromium"],
            timeout=600,
        )
        if rc != 0:
            raise RuntimeError(f"playwright install chromium failed:\n{out}")
        gen.log("Chromium installed; retrying launch")
        browser = await pw.chromium.launch(headless=True)

    context = await browser.new_context(
        bypass_csp=True,
        viewport={"width": width, "height": height},
        user_agent=user_agent,
        ignore_https_errors=True,
    )
    page = await context.new_page()

    async def _push(event_json: str) -> None:
        try:
            ev = json.loads(event_json)
        except Exception:
            return
        await _broadcast(ev)

    await page.expose_function("__rrwebPush", _push)
    await page.add_init_script(init_js)

    gen.status(f"Loading {url}…")
    try:
        await page.goto(url, wait_until="load", timeout=60_000)
    except Exception as exc:
        gen.log(f"page.goto raised {exc} — continuing; partial loads still record")
    try:
        await page.evaluate(init_js)
    except Exception as exc:
        gen.log(f"post-load evaluate failed: {exc}")

    await gen.serve_port(port, name="rrweb stream")
    channel = os.environ.get("COLLIMATE_CHANNEL", "")
    run_id = os.environ.get("COLLIMATE_RUN_ID", "")
    proxy_base = f"/proxy/{channel}/{run_id}/{port}/"
    gen.update_file(
        "session.rrweb",
        json.dumps({
            "url": url,
            "proxyBase": proxy_base,
            "viewport": {"width": width, "height": height},
        }),
    )
    await gen.update(
        name="Playwright rrweb",
        summary=f"Live: {url}",
        summary_artifact="session.rrweb",
    )
    gen.status(f"Recording {url}")

    try:
        while not gen.cancelled:
            await asyncio.sleep(0.5)
    finally:
        gen.log("Tearing down browser + server")
        for ws in list(_clients):
            try:
                await ws.close()
            except Exception:
                pass
        try:
            await context.close()
        except Exception:
            pass
        try:
            await browser.close()
        except Exception:
            pass
        try:
            await pw.stop()
        except Exception:
            pass
        await runner.cleanup()


# ---------------------------------------------------------------------------
# WS broadcast
# ---------------------------------------------------------------------------

async def _broadcast(event: dict[str, Any]) -> None:
    async with _buffer_lock:
        _events.append(event)
        if event.get("type") == _FULL_SNAPSHOT:
            cut = len(_events) - 1
            if cut > 0 and _events[cut - 1].get("type") == _META:
                cut -= 1
            del _events[:cut]

    dead: list[web.WebSocketResponse] = []
    payload = json.dumps({"kind": "event", "event": event})
    for ws in _clients:
        if ws.closed:
            dead.append(ws)
            continue
        try:
            await ws.send_str(payload)
        except Exception:
            dead.append(ws)
    for ws in dead:
        _clients.discard(ws)


async def _ws_handler(request: web.Request) -> web.WebSocketResponse:
    ws = web.WebSocketResponse(heartbeat=20)
    await ws.prepare(request)

    async with _buffer_lock:
        initial = list(_events)
    try:
        await ws.send_str(json.dumps({"kind": "init", "events": initial}))
    except Exception:
        return ws

    _clients.add(ws)
    try:
        async for _msg in ws:
            pass
    finally:
        _clients.discard(ws)
    return ws


async def _index(_request: web.Request) -> web.Response:
    return web.Response(
        text=(
            "<!doctype html><meta charset=utf-8>"
            "<title>rrweb live stream</title>"
            "<p>This is a live rrweb event stream. Connect a WebSocket to "
            "<code>./ws</code> to consume it, or open the cell's renderer.</p>"
        ),
        content_type="text/html",
    )


async def _start_aiohttp(port: int) -> web.AppRunner:
    app = web.Application()
    app.router.add_get("/", _index)
    app.router.add_get("/ws", _ws_handler)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", port)
    await site.start()
    gen.log(f"rrweb broadcaster listening on 127.0.0.1:{port}")
    return runner


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _find_free_port(start: int = 9100) -> int:
    port = start
    while port < start + 1000:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                port += 1
    raise RuntimeError(f"No free port found in range {start}-{start + 1000}")


def _int(raw: Any, default: int) -> int:
    try:
        n = int(raw)
        return n if n > 0 else default
    except (TypeError, ValueError):
        return default


if __name__ == "__main__":
    gen.main(run)
