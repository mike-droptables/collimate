# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic-ai"]
# ///
"""Renderer Builder — pydantic-ai scaffold of a new renderer.

Mirrors ``generator_builder`` but loads ``how-to-write-a-renderer.md`` as
the reference and emits renderer files (manifest.rend_yaml + main.tsx).

After the agent finishes, the staged ``manifest.rend_yaml`` is linted via
``collimate.lint.lint_renderer_manifest_data``. If lint errors are
found, the agent gets one retry with the errors fed back; if errors
persist, the run fails loudly rather than committing a broken renderer.
"""
from __future__ import annotations

import yaml
from collimate.lint import Level, lint_renderer_manifest_data
from collimate.shared import shared_path
import gen


async def run() -> None:
    cfg = gen.config("pydantic-config.set_yaml")
    provider = (cfg.get("provider") or "anthropic").strip().lower()
    model = (cfg.get("model") or "claude-sonnet-4-6").strip()
    max_tokens = _int(cfg.get("max_tokens"), default=8192)
    prompt = (gen.prompt or "").strip()
    if not prompt:
        raise Exception("Describe the renderer you want to build in the picker prompt.")

    try:
        guide = shared_path("docs", "how-to-write-a-renderer.md").read_text(encoding="utf-8")
    except FileNotFoundError as e:
        raise Exception(
            "Reference guide how-to-write-a-renderer.md not found under shared/docs/. "
            f"Details: {e}"
        )

    guidance = {p: gen.read_file(p) for p in gen.list_files()}
    stage: dict[str, str] = {}

    from pydantic_ai import Tool

    async def list_guidance() -> list[str]:
        """List any reference files attached via the input cell. These
        are for reading only — do NOT copy them into the output."""
        return sorted(guidance.keys())

    async def read_guidance(path: str) -> str:
        """Read a guidance file attached via the input cell."""
        return guidance.get(path, f"ERROR: file not found: {path}")

    async def write_file(path: str, content: str) -> str:
        """Write a file into the new renderer scaffold. Path is relative
        to the cell root (e.g. ``manifest.rend_yaml``, ``main.tsx``)."""
        stage[path] = content
        return f"wrote {len(content)} bytes to {path}"

    async def list_written() -> list[str]:
        """List what you've written so far."""
        return sorted(stage.keys())

    system_prompt = (
        "You are scaffolding a complete, working Collimate renderer from a "
        "user description. Follow the reference guide below exactly — it is "
        "the authoritative spec for the manifest.rend_yaml schema, the "
        "entrypoint module, and the runtime contract.\n\n"
        "Required files:\n"
        "  - manifest.rend_yaml\n"
        "  - main.tsx (or whatever the manifest declares as entrypoint)\n\n"
        "Use the write_file tool to emit every file in full. Do not "
        "abbreviate, do not use placeholders. When you're done, stop — do "
        "not describe the files in prose.\n\n"
        "--- BEGIN REFERENCE GUIDE ---\n"
        f"{guide}\n"
        "--- END REFERENCE GUIDE ---\n"
    )

    gen.status(f"Scaffolding renderer with {provider} · {model}…")
    gen.log(f"[renderer-builder] {provider} · {model} · guide={len(guide)} chars")

    tools = [
        Tool(list_guidance),
        Tool(read_guidance),
        Tool(write_file),
        Tool(list_written),
    ]
    user_msg = (
        f"Build a renderer that does the following:\n\n{prompt}\n\n"
        "Write every required file via write_file. Do not write README.md "
        "or any extra files — only the files the renderer needs to run."
    )

    agent = await gen.agent(
        system_prompt=system_prompt,
        tools=tools,
        provider=provider,
        model=model,
        max_tokens=max_tokens,
    )
    await agent.run(user_msg)  # auto-retries on auth failure

    if not stage:
        raise Exception("The agent returned without writing any files.")

    # Validate + one retry with errors fed back. Fail loudly on still-invalid.
    errors = _lint_stage(stage)
    if errors:
        gen.log(f"[renderer-builder] lint errors after first agent run: {len(errors)}")
        await agent.run(_fix_prompt(errors))
        errors = _lint_stage(stage)
    if errors:
        raise Exception(
            "Renderer scaffold is invalid after one retry. Errors:\n"
            + "\n".join(f"  - {e}" for e in errors)
        )

    for guidance_path in guidance:
        gen.delete_file(guidance_path)
    for path, content in stage.items():
        gen.update_file(path, content)

    entry = "manifest.rend_yaml" if "manifest.rend_yaml" in stage else sorted(stage)[0]
    await gen.update(
        name=f"renderer scaffold · {provider}",
        summary=f"{len(stage)} file(s) · entry: `{entry}`",
        summary_artifact=entry,
    )


def _lint_stage(stage: dict[str, str]) -> list[str]:
    """Lint the staged ``manifest.rend_yaml``. Returns a list of error
    strings (empty when valid)."""
    if "manifest.rend_yaml" not in stage:
        return ["manifest.rend_yaml was not written"]
    try:
        data = yaml.safe_load(stage["manifest.rend_yaml"])
    except yaml.YAMLError as e:
        return [f"manifest.rend_yaml is not valid YAML: {e}"]
    issues = lint_renderer_manifest_data(
        data if isinstance(data, dict) else {},
        files_present=set(stage.keys()),
    )
    return [
        f"{i.field or '<root>'}: {i.message}"
        for i in issues
        if i.level == Level.ERROR
    ]


def _fix_prompt(errors: list[str]) -> str:
    bullets = "\n".join(f"  - {e}" for e in errors)
    return (
        "Your previous output has the following manifest problems. "
        "Fix EVERY one of them by re-emitting the corrected files via "
        "write_file. Do not write README.md or any explanation files — "
        "just the corrected manifest and any other files that need "
        f"updating.\n\n{bullets}\n"
    )


def _int(raw, default: int) -> int:
    try:
        n = int(raw)
        return n if n > 0 else default
    except (TypeError, ValueError):
        return default


if __name__ == "__main__":
    gen.main(run)
