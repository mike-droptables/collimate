# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic-ai"]
# ///
"""Seed Ideas — fan out N idea directions along a user-specified axis.

Multi-cell output: phase 1 seeds N short labels in one agent call;
phase 2 runs N agents in parallel to produce the idea bodies; phase 3
creates **N stack cells**, one per idea (carry-through files land in
each); phase 4 writes the run's primary cell as a single ``index.md``
listing every idea + its one-line summary, so the placeholder isn't
itself one of the ideas — it's the overview.
"""
from __future__ import annotations

import asyncio
import re

from pydantic import BaseModel, Field

import gen


class Seeds(BaseModel):
    labels: list[str] = Field(
        description="Exactly N short labels (2–4 words each) for the distinct ideas."
    )


async def run() -> None:
    cfg = gen.config("pydantic-config.set_yaml")
    provider = (cfg.get("provider") or "anthropic").strip().lower()
    model = (cfg.get("model") or "claude-sonnet-4-6").strip()
    max_tokens = _int(cfg.get("max_tokens"), default=2048)
    count = max(2, min(12, _int(cfg.get("num_ideas"), default=4)))
    system_prompt = (cfg.get("system_prompt") or "").strip()
    axis = (gen.prompt or "").strip()
    if not axis:
        raise Exception("Describe the axis to explore in the picker prompt.")

    carry = {p: gen.read_file(p) for p in gen.list_files()}

    gen.status(f"Seeding {count} idea directions…")

    seed_system = (
        system_prompt
        + f"\n\nReturn exactly {count} short labels (2–4 words each), "
        "genuinely distinct directions along the axis."
    )
    if carry:
        seed_system += (
            "\n\nInput files for reference (do not repeat their content):\n"
            + "\n".join(f"- `{p}`" for p in sorted(carry))
        )

    seed_agent = await gen.agent(
        system_prompt=seed_system,
        output_type=Seeds,
        provider=provider,
        model=model,
        max_tokens=max_tokens,
    )
    seed_result = await seed_agent.run(f"Axis and requirements:\n\n{axis}")
    out = getattr(seed_result, "output", None) or getattr(seed_result, "data", None)
    if not isinstance(out, Seeds) or not out.labels:
        raise Exception("seed agent returned no structured output")
    seeds = [x.strip() for x in out.labels if x and x.strip()]
    if len(seeds) > count:
        seeds = seeds[:count]
    while len(seeds) < count:
        seeds.append(f"Idea {len(seeds) + 1}")

    gen.log(f"[seed-ideas] seeds: {seeds}")

    build_system = (
        system_prompt
        + "\n\nProduce the seeded idea as a complete, self-contained "
        "markdown document. No preamble, no meta commentary."
    )
    if carry:
        build_system += (
            "\n\n## Input files\n\n"
            + "\n\n".join(f"### `{p}`\n\n```\n{carry[p][:2000]}\n```" for p in sorted(carry))
        )

    async def build_one(idx: int, label: str) -> str:
        agent_obj = await gen.agent(
            system_prompt=build_system,
            tools=[gen.python_tool()],
            provider=provider,
            model=model,
            max_tokens=max_tokens,
        )
        result = await agent_obj.run(
            f"Axis and requirements:\n\n{axis}\n\n"
            f"Write out idea {idx + 1}: **{label}**. Just the idea body in markdown. "
            f"You may call run_python to compute, analyse, or generate "
            f"diagrams that strengthen the idea — any files the script "
            f"creates land in this idea's cell."
        )
        text = getattr(result, "output", None) or getattr(result, "data", "") or ""
        return text if isinstance(text, str) else str(text)

    gen.status(f"Building {count} ideas in parallel…")
    raw_results = await asyncio.gather(
        *(build_one(i, seeds[i]) for i in range(len(seeds))),
        return_exceptions=True,
    )
    bodies: list[str] = [
        f"_Error: {r}_" if isinstance(r, BaseException) else r for r in raw_results
    ]

    # Phase 3: one stack cell per idea. The carry-through files are
    # bundled into the explicit ``files`` arg so each side cell
    # snapshots them deterministically.
    for seed_label, body in zip(seeds, bodies):
        files = dict(carry)
        files["SeedIdea.md"] = f"# {seed_label}\n\n{body}\n"
        await gen.create_stack_cell(
            seed_label[:80] or "idea",
            summary=_summary_from_body(body),
            summary_artifact="SeedIdea.md",
            files=files,
        )

    # Phase 4: turn the placeholder into a summary index.
    gen.update_file("index.md", _final_index(seeds, bodies, axis, count))
    await gen.update(
        name=f"{count} ideas · {provider}",
        summary=" · ".join(seeds),
        summary_artifact="index.md",
    )


def _final_index(seeds: list[str], bodies: list[str], axis: str, count: int) -> str:
    lines = [f"# {count} ideas along: {axis}", "", "## Generated cells", ""]
    for seed, body in zip(seeds, bodies):
        body_text = body or ""
        is_err = body_text.lstrip().lower().startswith(("_error", "**error"))
        marker = "⚠️" if is_err else "✅"
        tagline = body_text if is_err else _summary_from_body(body_text)
        if is_err:
            tagline = _first_line(tagline)
        lines.append(f"- {marker} **{seed}** — {tagline}" if tagline else f"- {marker} **{seed}**")
    lines.append("")
    lines.append("_Each idea above is its own side cell to the right of this one._")
    return "\n".join(lines) + "\n"


_INLINE_BOLD = re.compile(r"\*\*(.+?)\*\*")
_INLINE_ITAL = re.compile(r"(?<![*_])\*(?!\s)(.+?)(?<!\s)\*(?!\*)")
_INLINE_CODE = re.compile(r"`([^`]+)`")
_INLINE_LINK = re.compile(r"\[([^\]]+)\]\([^)]+\)")


def _summary_from_body(body: str | None, limit: int = 120) -> str:
    if not isinstance(body, str):
        return ""
    text = body.strip()
    if not text:
        return ""
    lower = text.lower()
    if lower.startswith("_error") or lower.startswith("**error"):
        return ""
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#"):
            continue
        cleaned = _INLINE_BOLD.sub(r"\1", line)
        cleaned = _INLINE_ITAL.sub(r"\1", cleaned)
        cleaned = _INLINE_CODE.sub(r"\1", cleaned)
        cleaned = _INLINE_LINK.sub(r"\1", cleaned)
        cleaned = cleaned.strip()
        if not cleaned:
            continue
        if len(cleaned) > limit:
            return cleaned[:limit - 1] + "…"
        return cleaned
    return ""


def _first_line(text: str, limit: int = 120) -> str:
    text = (text or "").strip()
    if not text:
        return ""
    first = text.splitlines()[0]
    return first[:limit] + ("…" if len(first) > limit else "")


def _int(raw, default: int) -> int:
    try:
        n = int(raw)
        return n if n > 0 else default
    except (TypeError, ValueError):
        return default


if __name__ == "__main__":
    gen.main(run)
