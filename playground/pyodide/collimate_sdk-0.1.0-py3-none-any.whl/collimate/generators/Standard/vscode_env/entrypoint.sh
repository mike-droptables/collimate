#!/usr/bin/env bash
set -euo pipefail

echo "[entrypoint] starting"
echo "[entrypoint] PORT=${PORT:-unset}"

PROJECT_DIR=/home/coder/project
mkdir -p "${PROJECT_DIR}"

# 1. Copy workspace files into the project directory.
if [[ -d /workspace ]]; then
    echo "[entrypoint] copying /workspace into ${PROJECT_DIR}"
    # The backend already strips .colreserved/* during hydration; we
    # filter again as defense in depth.
    (cd /workspace && find . -mindepth 1 -maxdepth 1 \
        ! -name '.colreserved' \
        -exec cp -a {} "${PROJECT_DIR}/" \;)
    file_count=$(find "${PROJECT_DIR}" -type f | wc -l)
    echo "[entrypoint] copied ${file_count} files into project"
else
    echo "[entrypoint] WARNING: /workspace not mounted; starting with empty project"
fi

# 2. Configure git author identity if provided.
if [[ -n "${GIT_USER_NAME:-}" ]]; then
    git config --global user.name "${GIT_USER_NAME}"
    echo "[entrypoint] git user.name = ${GIT_USER_NAME}"
fi
if [[ -n "${GIT_USER_EMAIL:-}" ]]; then
    git config --global user.email "${GIT_USER_EMAIL}"
    echo "[entrypoint] git user.email = ${GIT_USER_EMAIL}"
fi

# 3. Seed git credentials for github.com if provided.
if [[ -n "${GITHUB_USER:-}" && -n "${GITHUB_PASSWORD:-}" ]]; then
    git config --global credential.helper store
    # URL-encode user + password in case they contain special chars.
    enc_user=$(python3 -c 'import os, urllib.parse; print(urllib.parse.quote(os.environ["GITHUB_USER"], safe=""))')
    enc_pw=$(python3 -c 'import os, urllib.parse; print(urllib.parse.quote(os.environ["GITHUB_PASSWORD"], safe=""))')
    {
        echo "https://${enc_user}:${enc_pw}@github.com"
    } > /home/coder/.git-credentials
    chmod 600 /home/coder/.git-credentials
    echo "[entrypoint] git credentials configured for github.com"
fi

# 4. Install extensions requested by the generator (JSON array of
#    marketplace ids). Idempotent — code-server skips already-installed
#    extensions. `|| true` so a single bad id doesn't stop the chain.
if [[ -n "${EXTENSIONS:-}" ]]; then
    echo "[entrypoint] installing extensions: ${EXTENSIONS}"
    python3 - <<'PYEOF'
import json, os, subprocess
for ext in json.loads(os.environ.get("EXTENSIONS", "[]")):
    ext = (ext or "").strip()
    if not ext:
        continue
    print(f"[extensions] install {ext}", flush=True)
    subprocess.call(["code-server", "--install-extension", ext])
PYEOF
fi

# 5. Run startup commands in background, in parallel with code-server.
if [[ -n "${STARTUP_COMMANDS:-}" ]]; then
    echo "[entrypoint] launching startup commands in background"
    (
        cd "${PROJECT_DIR}"
        python3 - <<'PYEOF'
import json, os, subprocess, sys
cmds = json.loads(os.environ.get("STARTUP_COMMANDS", "[]"))
for c in cmds:
    print(f"[startup] running: {c}", flush=True)
    rc = subprocess.call(c, shell=True)
    if rc != 0:
        print(f"[startup] command failed with exit {rc}: {c}", flush=True)
        sys.exit(rc)
print("[startup] all commands completed", flush=True)
PYEOF
    ) &
    echo "[entrypoint] startup pid: $!"
fi

# 6. Wipe per-workspace editor state so the workbench never reopens
#    stale file tabs from a previous run. code-server keys this state
#    by workspace hash under ~/.local/share/code-server/User/
#    workspaceStorage/; the image's persistent layer can carry it
#    across rebuilds when cached.
WORKSPACE_STORAGE="/home/coder/.local/share/code-server/User/workspaceStorage"
if [[ -d "${WORKSPACE_STORAGE}" ]]; then
    rm -rf "${WORKSPACE_STORAGE}"/* 2>/dev/null || true
    echo "[entrypoint] cleared workspaceStorage"
fi

# 7. Launch code-server. Background startup commands keep running as
#    children of code-server (PID-stable thanks to exec).
echo "[entrypoint] launching code-server on 0.0.0.0:${PORT}"
exec code-server \
    --bind-addr "0.0.0.0:${PORT}" \
    "${PROJECT_DIR}"
