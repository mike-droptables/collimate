# /// script
# requires-python = ">=3.11"
# dependencies = ["docker", "pyyaml"]
# ///
"""VS Code Env — containerised VS Code Server for the cell.

Self-contained: ships its own ``Dockerfile`` + ``entrypoint.sh`` and
builds ``collimate-vscode-env:latest`` on first use.
"""
from __future__ import annotations

import asyncio
import json
import os
import socket
import threading
import time
import urllib.request
import uuid
from pathlib import Path

import docker
import docker.errors

import gen

IMAGE_TAG = "collimate-vscode-env:latest"


async def run() -> None:
    cfg = gen.config("settings.set_yaml")
    extensions = _as_string_list(cfg.get("extensions"))
    github_login = bool(cfg.get("github_login", True))
    startup_commands = _as_string_list(cfg.get("startup_commands"))
    mount_host_claude = bool(cfg.get("mount_host_claude", True))

    gen.status("Checking Docker…")
    try:
        client = docker.from_env()
        client.ping()
    except docker.errors.DockerException as e:
        raise RuntimeError(f"Cannot connect to Docker: {e}. Is Docker running?")

    workspace = gen.workspace_path()
    _ensure_image(client)

    port = _find_free_port(8080)
    gen.log(f"Using port {port}")

    _relax_workspace_perms(workspace)
    _ensure_workspace_has_placeholder()

    env: dict[str, str] = {"PORT": str(port)}
    if extensions:
        env["EXTENSIONS"] = json.dumps(extensions)
    if github_login:
        env["GITHUB_USER"] = await gen.secret(
            "githubuser",
            prompt_if_missing=True,
            description="GitHub username for HTTPS clone/push from VSCode",
        )
        env["GITHUB_PASSWORD"] = await gen.secret(
            "githubpassword",
            prompt_if_missing=True,
            description="GitHub personal-access token (HTTPS password)",
        )
        gen.log("Passing keystore git credentials into the container")
    if startup_commands:
        env["STARTUP_COMMANDS"] = json.dumps(startup_commands)

    volumes: dict = {
        workspace: {"bind": "/workspace", "mode": "ro"},
    }
    if mount_host_claude:
        host_claude = os.path.expanduser("~/.claude")
        if os.path.isdir(host_claude):
            volumes[host_claude] = {"bind": "/home/coder/.claude", "mode": "rw"}
            gen.log("Mounting host ~/.claude into the container")
        else:
            gen.log(
                f"mount_host_claude is on but {host_claude} does not exist — "
                "Claude Code will start unauthenticated"
            )

    container_name = f"collimate-vscode-env-{uuid.uuid4().hex[:8]}"
    gen.status(f"Starting container {container_name}…")
    container = client.containers.run(
        IMAGE_TAG,
        detach=True,
        name=container_name,
        ports={f"{port}/tcp": ("127.0.0.1", port)},
        volumes=volumes,
        environment=env,
        labels={
            "com.collimate.run_id": os.environ.get("COLLIMATE_RUN_ID", ""),
            "com.collimate.kind": "vscode_env",
        },
    )

    try:
        gen.status("Waiting for VS Code Server…")
        if not _wait_for_ready(port, timeout=120):
            raise RuntimeError("VS Code Server did not become ready within 120s.")

        iframe_path = "?command=claude-code.chat.focus"
        await gen.serve_port(
            port,
            name="VS Code",
            path=iframe_path,
            snapshot_source={
                "container_name": container_name,
                "project_dir": "/home/coder/project",
            },
        )

        channel = os.environ.get("COLLIMATE_CHANNEL", "")
        run_id = os.environ.get("COLLIMATE_RUN_ID", "")
        proxy_url = f"/proxy/{channel}/{run_id}/{port}/{iframe_path}"
        gen.update_file(
            "vscode-server.website",
            json.dumps({"url": proxy_url}),
        )

        await gen.update(
            name="VS Code Env",
            summary=f"VS Code Server on port {port}",
            summary_artifact="vscode-server.website",
        )
        gen.status("VS Code Server is running.")

        threading.Thread(
            target=_tail_logs, args=(container,), daemon=True,
        ).start()

        while not gen.cancelled:
            await asyncio.sleep(0.5)
    finally:
        gen.log(f"Stopping container {container_name}…")
        try:
            container.stop(timeout=2)
            container.remove(force=True)
        except docker.errors.NotFound:
            pass
        except Exception as e:
            gen.log(f"container stop failed ({e}); force removing")
            try:
                container.remove(force=True)
            except Exception as e2:
                gen.log(f"Failed to remove container {container_name}: {e2}")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ensure_image(client) -> None:
    """Build the image locally on first run. Subsequent runs skip the
    build because Docker caches the tag."""
    try:
        client.images.get(IMAGE_TAG)
        return
    except docker.errors.ImageNotFound:
        pass

    app_dir = Path(__file__).resolve().parent
    gen.status("Building Docker image (first run — may take a few minutes)…")
    gen.log(f"Building {IMAGE_TAG} from {app_dir}")
    started = time.monotonic()
    try:
        _, build_logs = client.images.build(path=str(app_dir), tag=IMAGE_TAG, rm=True)
        for chunk in build_logs:
            if chunk.get("error"):
                detail = chunk.get("errorDetail", {}).get("message") or chunk["error"]
                raise RuntimeError(f"Docker build failed: {detail}")
            line = (chunk.get("stream") or "").rstrip()
            if line:
                gen.log(line)
                if line.startswith("Step "):
                    gen.status(f"Building image — {line.split(':', 1)[0].strip()}")
    except docker.errors.BuildError as e:
        raise RuntimeError(f"Docker build failed: {e}")
    gen.log(f"Built {IMAGE_TAG} in {time.monotonic() - started:.1f}s")


def _find_free_port(start: int = 8080) -> int:
    port = start
    while port < 9000:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                port += 1
    raise RuntimeError("No free port found in range 8080-8999")


def _wait_for_ready(port: int, timeout: int = 120) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=2)
            return True
        except Exception:
            time.sleep(2)
    return False


def _relax_workspace_perms(root: str) -> None:
    """``tempfile.mkdtemp`` creates 0700 dirs; the container's coder user
    can't traverse those. Open everything up to 0755/0644."""
    try:
        os.chmod(root, 0o755)
        for dirpath, dirnames, filenames in os.walk(root):
            for d in dirnames:
                try:
                    os.chmod(os.path.join(dirpath, d), 0o755)
                except OSError:
                    pass
            for f in filenames:
                try:
                    os.chmod(os.path.join(dirpath, f), 0o644)
                except OSError:
                    pass
    except OSError as e:
        gen.log(f"Could not relax workspace permissions: {e}")


def _ensure_workspace_has_placeholder() -> None:
    """Empty workspaces get a README so VS Code's explorer isn't blank."""
    if gen.list_files():
        return
    gen.update_file(
        "README.md",
        "# Empty workspace\n\n"
        "No input cell was attached. Create files with the VS Code explorer "
        "or run a previous generator (e.g. `git_clone`) to populate this "
        "cell before running `VS Code Env`.\n",
    )


def _tail_logs(container) -> None:
    try:
        for chunk in container.logs(stream=True, follow=True):
            line = chunk.decode("utf-8", errors="replace").rstrip()
            if line:
                gen.log(f"[container] {line}")
    except Exception as e:
        gen.log(f"log tail ended: {e}")


def _as_string_list(raw) -> list[str]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return [str(x) for x in raw if x is not None and str(x).strip()]
    if isinstance(raw, str):
        return [raw] if raw.strip() else []
    return []


if __name__ == "__main__":
    gen.main(run)
