# WASM — pydantic-ai-slim generator set

Seven generators that run entirely in the browser via the Collimate
playground's pyodide build. All six LLM generators share the same
`pydantic-config.set_yaml` schema (provider, model, max tokens) and
use `pydantic-ai-slim[openai]` against any of the three
OpenAI-compatible providers wired by `collimate.wasm_llm.build_agent`:
Groq, Cerebras, OpenRouter. Gemini, Anthropic, and OpenAI direct are
deliberately not listed — their public endpoints reject browser-origin
CORS, so calls from the playground get blocked at the preflight. Reach
those through a server-side proxy or run the native (non-wasm) runtime.

The seventh (`merge`) is a deterministic file-union with no LLM.

| Generator | Category | Input cells | What it does |
|---|---|---|---|
| [`live-chat`](./live-chat/) | chat | 0–1 | Streaming pydantic-ai chat with read/write/edit file tools. Mid-stream user messages queue as the next user turn. |
| [`modify-files`](./modify-files/) | iterate | 0–1 | Agent with file tools makes the edits the user asked for. Untouched files carry through. Summary points at the file the agent flagged as the answer. |
| [`seed-ideas`](./seed-ideas/) | widen | 0–1 | Generates N distinct idea directions along the axis in the picker prompt. Each lands as a subfolder (`idea_NN_<slug>/SeedIdea.md`) because wasm is one-cell-per-run. |
| [`evaluate-best`](./evaluate-best/) | narrow | 2–99 | Judges each candidate independently, then picks one. Output: winning cell's files + `why_picked.md` + `judgments.md`. |
| [`generator-builder`](./generator-builder/) | tools | 0–1 | Scaffolds a new wasm generator from a description. System prompt is the full `how-to-write-a-wasm-generator.md`. Input files are guidance only. |
| [`renderer-builder`](./renderer-builder/) | tools | 0–1 | Same shape, but scaffolds a renderer using `how-to-write-a-renderer.md`. |
| [`merge`](./merge/) | tools | 2–99 | Union the files of every input cell. On filename collisions the topmost wins. No LLM. |

## Mirror of the `Standard` set

A mirrored group lives at [`../Standard/`](../Standard/) — same seven
generators, but using full `pydantic-ai` (not slim) in a native
subprocess. Native gets to use `gen.create_cell` for real multi-cell
output (so `seed_ideas` emits N cells, not N subfolders) and daemon
mode for live chat. The Standard set also adds three non-LLM
generators (`claude_cli`, `vscode_env`, `git_clone`) that depend on
Docker and can't run in the browser.

## Config file convention

Every LLM generator here has a `pydantic-config.set_yaml` with these
fields:

- `provider` — one of `groq` / `cerebras` / `openrouter` (Gemini /
  OpenAI / Anthropic don't allow browser-origin CORS, so they're out
  of scope here — proxy them through a server or use the native runtime)
- `model` — raw model id for that provider
- `max_tokens` — max tokens per message (default varies by generator)
- `system_prompt` — prepended to every turn (where applicable)

API keys come from the centralized keystore (Settings → Keys); the
generator's `await resolve_api_key(ctx, provider)` call pops the
in-cell modal when the relevant entry is missing.

The defaults are tuned so the file is **optional to edit** — the
generator runs with sensible defaults if the user doesn't open the
Draft.
