# SPDX-License-Identifier: Apache-2.0
"""Shared agent engine for the hidden ``agent`` toolset generator.

This is the LLM toolset that used to be the privileged ``gen.agent`` /
``gen.file_tools`` / ``gen.python_tool`` / ``gen.agent_chat_turn`` built-ins.
It is no longer a special part of the SDK surface — it lives generator-side as
an ordinary ``_*`` shared cell sibling (like ``_env_shared``) and is reached by
other generators through ``gen.call('agent', ...)`` / ``gen.spawn``.

One ``run_agent`` call, three interchangeable backends:

  * ``pydantic-ai``      — multi-provider (anthropic / gemini / openai / groq /
                           cerebras), file + python tools, token streaming,
                           401 auto-retry.
  * ``claude-agent-sdk`` — the Python Claude Agent SDK driving the installed
                           ``claude`` CLI, with two billing modes: ``api_key``
                           (``ANTHROPIC_API_KEY``) or ``claude_code`` (the
                           logged-in Claude Code subscription — non-API).
  * ``gemini``           — the Gemini CLI agent (``gemini -p`` headless).

Only the public ``gen.*`` surface is used (no private bridge), so the engine
works as plain generator-side code. The agent operates on the run's own
workspace; the whole workspace is returned to the caller of ``gen.call``.
Token deltas are emitted via the ``on_event`` callback so the agent generator
can forward them to its parent with ``gen.emit_event`` (the generator→generator
streaming twin of run→UI streaming). Structured output is requested with a
JSON-only instruction and parsed back uniformly across all three backends — the
caller re-validates with its own model.
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import sys
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

import gen


@dataclass
class AgentResult:
    """One agent turn's outcome. File edits live in the workspace (returned to
    the caller verbatim); this carries the assistant text + parsed structured
    output (when an ``output_schema`` was requested) + the full-fidelity trace
    of the turn (thinking, tool activity, token usage) in the normalized event
    vocabulary of :mod:`_agent_shared.ledger`."""
    text: str = ""
    structured: Optional[Any] = None
    backend: str = ""
    trace: list = field(default_factory=list)
    usage: dict = field(default_factory=dict)


# Backend label aliases → canonical keys.
_PYDANTIC = {"pydantic-ai", "pydantic_ai", "pydantic"}
_CLAUDE = {"claude-agent-sdk", "claude_agent_sdk", "claude", "claude-code"}
_GEMINI = {"gemini", "gemini-cli", "google"}
# Multi-provider, in-process external-MCP-client backends (composition tools
# reach them over the streamable-http bridge; model routing is provider-driven,
# exactly like pydantic-ai). Each adds a distinct paradigm: ADK = deterministic
# workflow agents; openai-agents = handoffs + guardrails; MAF = teams.
_ADK = {"google-adk", "adk"}
_OPENAI_AGENTS = {"openai-agents", "openai-agent", "agents-sdk"}
_MAF = {"maf", "agent-framework", "microsoft-agent-framework"}
_KNOWN_BACKENDS = _PYDANTIC | _CLAUDE | _GEMINI | _ADK | _OPENAI_AGENTS | _MAF


# ──────────────────────────────────────────────────────────────────────
# Trace capture — the normalized full-fidelity record of one agent turn.
#
# Every backend collects far richer data than the reply text (thinking
# blocks, tool_use/tool_result, token usage); the trace retains it in one
# shared event vocabulary so downstream consumers (the assumptions-ledger
# extraction in ledger.py, `_agent/trace.json`) are backend-agnostic:
#
#   {"type": "user",        "text": ...}
#   {"type": "text",        "text": ...}
#   {"type": "thinking",    "text": ...}
#   {"type": "tool_use",    "tool": ..., "input": ...}
#   {"type": "tool_result", "tool": ..., "output": ...}
#   {"type": "system_note", "text": ...}
#
# The live ``on_event`` stream uses a smaller progress vocabulary:
#   {"type": "text_delta",     "text": ...}   reply chunks (streaming; whole
#                                             completed blocks when stream=False)
#   {"type": "thinking_delta", "text": ...}   extended-thinking chunks (claude
#                                             backend, streaming only)
#   {"type": "tool",  "name": ..., "status": ...}   tool activity heartbeat
# ──────────────────────────────────────────────────────────────────────


def _jsonable(v):
    """``v`` if it survives JSON round-tripping, else its ``str()`` form —
    trace events must always be serializable."""
    try:
        json.dumps(v)
        return v
    except (TypeError, ValueError):
        return str(v)


def _trace_event(kind: str, **kw) -> dict:
    ev: dict = {"type": kind}
    for k, v in kw.items():
        if v is None or v == "":
            continue
        ev[k] = _jsonable(v)
    return ev


def _pai_trace(messages) -> list:
    """pydantic-ai ``all_messages()`` → normalized trace events, keyed off
    each part's ``part_kind`` discriminator."""
    trace: list = []
    for msg in messages or []:
        for part in getattr(msg, "parts", []) or []:
            kind = getattr(part, "part_kind", "")
            if kind == "user-prompt":
                trace.append(_trace_event("user", text=str(getattr(part, "content", ""))))
            elif kind == "text":
                trace.append(_trace_event("text", text=getattr(part, "content", "")))
            elif kind == "thinking":
                trace.append(_trace_event("thinking", text=getattr(part, "content", "")))
            elif kind == "tool-call":
                trace.append(_trace_event(
                    "tool_use",
                    tool=getattr(part, "tool_name", ""),
                    input=getattr(part, "args", None),
                ))
            elif kind == "tool-return":
                trace.append(_trace_event(
                    "tool_result",
                    tool=getattr(part, "tool_name", ""),
                    output=str(getattr(part, "content", "")),
                ))
            elif kind == "retry-prompt":
                trace.append(_trace_event("system_note", text=str(getattr(part, "content", ""))))
    return trace


def _pai_usage(u) -> dict:
    usage: dict = {}
    for attr in ("input_tokens", "output_tokens", "total_tokens",
                 "request_tokens", "response_tokens", "requests"):
        v = getattr(u, attr, None)
        if isinstance(v, int):
            usage[attr] = v
    return usage


# ──────────────────────────────────────────────────────────────────────
# Config parsing — one place, used by the agent generator AND every
# consumer (modify_files / seed_ideas / evaluate_best / guide). Replaces
# the per-consumer _int / _bool / model-default copies.
# ──────────────────────────────────────────────────────────────────────


def to_int(raw, default: int) -> int:
    try:
        n = int(raw)
        return n if n > 0 else default
    except (TypeError, ValueError):
        return default


def to_bool(raw, default: bool = False) -> bool:
    if isinstance(raw, bool):
        return raw
    if isinstance(raw, str):
        return raw.strip().lower() in ("1", "true", "yes", "on")
    if raw is None:
        return default
    return bool(raw)


def as_schema(raw):
    if isinstance(raw, dict):
        return raw or None
    if isinstance(raw, str) and raw.strip():
        try:
            v = json.loads(raw)
            return v if isinstance(v, dict) else None
        except Exception:
            return None
    return None


# Per-provider default models — used when the model field is blank, and as the
# substitute when a configured model contradicts the selected backend/provider
# (see :func:`resolve_model`).
_PROVIDER_DEFAULT_MODEL = {
    "anthropic": "claude-sonnet-4-6",
    "gemini": "gemini-2.5-flash",
    "openai": "gpt-5",
    "groq": "llama-3.3-70b-versatile",
    "cerebras": "llama-3.3-70b",
    # openrouter takes ``vendor/model`` slugs (OPENROUTER_API_KEY); the default
    # is the anthropic-sonnet equivalent of the flagship tier above.
    "openrouter": "anthropic/claude-sonnet-4.6",
}

# Model-id prefixes → the provider family they belong to. Used to detect a
# model/backend mismatch — the classic trap being the model field still holding
# ``claude-sonnet-4-6`` after the backend dropdown was switched to gemini. Ids
# with an explicit provider prefix (``openai/gpt-oss-120b`` on groq) or an
# unrecognised family pass through untouched; only a KNOWN-contradicting id is
# swapped for the target's default.
_FAMILY_PREFIXES = {
    "anthropic": ("claude", "sonnet", "opus", "haiku"),
    "gemini": ("gemini",),
    "openai": ("gpt", "o1", "o3", "o4", "chatgpt"),
}


def model_family(model: str) -> str:
    """The provider family a model id belongs to (``anthropic`` / ``gemini`` /
    ``openai``), or ``""`` when unknown or explicitly provider-prefixed."""
    m = (model or "").strip().lower()
    if not m or "/" in m:
        return ""
    for family, prefixes in _FAMILY_PREFIXES.items():
        if any(m == p or m.startswith(p) for p in prefixes):
            return family
    return ""


def default_model(backend: str, provider: str) -> str:
    bk = (backend or "").strip().lower()
    if bk in _GEMINI:
        return _PROVIDER_DEFAULT_MODEL["gemini"]
    if bk in _CLAUDE:
        return "sonnet"
    return _PROVIDER_DEFAULT_MODEL.get((provider or "").strip().lower(), "")


# Per-provider cheap models — what the assumptions-ledger extraction runs on
# when its model field is blank. Extraction is a high-volume companion pass;
# it should never default to the flagship tier.
_PROVIDER_CHEAP_MODEL = {
    "anthropic": "claude-haiku-4-5",
    "gemini": "gemini-2.5-flash",
    "openai": "gpt-5-mini",
    "groq": "llama-3.1-8b-instant",
    "cerebras": "llama-3.1-8b",
    # openrouter cheap tier: the anthropic-haiku equivalent (vendor/model slug).
    "openrouter": "anthropic/claude-haiku-4.5",
}


def resolve_ledger_model(mode: str, backend: str, provider: str, model) -> str:
    """The model the assumptions-ledger extraction runs on. Blank → a cheap
    model for whatever the selection actually talks to; an explicit value is
    resolved with the same family guard as the main model."""
    m = str(model or "").strip()
    if m:
        # An explicit ledger model is family-guarded exactly like the main
        # model: a contradicting one can't be honored and raises (never swapped).
        return resolve_model(mode, backend, provider, m)
    mode_l = (mode or "oneshot").strip().lower()
    bk = (backend or "pydantic-ai").strip().lower()
    if mode_l == "claude-terminal" or (mode_l != "opencode" and bk in _CLAUDE):
        return "haiku"   # claude CLI/SDK alias
    if mode_l != "opencode" and bk in _GEMINI:
        return _PROVIDER_CHEAP_MODEL["gemini"]
    return _PROVIDER_CHEAP_MODEL.get((provider or "anthropic").strip().lower(), "")


def resolve_model(mode: str, backend: str, provider: str, model) -> str:
    """The effective model for a mode/backend/provider selection.

    Blank model → the target's default. A NON-blank model whose family
    contradicts what the selection actually talks to (claude-* on the gemini
    backend, gemini-* on provider openai, …) can't be honored as set and raises
    ``ValueError`` — it is NOT silently swapped for the default. A model of
    unknown family, or one carrying an explicit provider prefix
    (``openai/gpt-oss-120b``), passes through untouched (best effort).
    """
    mode = (mode or "oneshot").strip().lower()
    bk = (backend or "pydantic-ai").strip().lower()
    prov = (provider or "anthropic").strip().lower()
    m = str(model or "").strip()

    # Which provider family this selection actually talks to.
    if mode == "claude-terminal" or (mode not in ("opencode",) and bk in _CLAUDE):
        target, fallback = "anthropic", "sonnet"   # claude CLI/SDK alias
    elif mode != "opencode" and bk in _GEMINI:
        target, fallback = "gemini", _PROVIDER_DEFAULT_MODEL["gemini"]
    else:  # pydantic-ai backend / opencode mode — the provider dropdown picks
        target, fallback = prov, _PROVIDER_DEFAULT_MODEL.get(prov, "")

    if not m:
        return fallback
    fam = model_family(m)
    if fam and fam != target:
        hint = (
            f"set the Model field to a {target} model or leave it blank for "
            f"the default ({fallback!r})" if fallback
            else f"provider {prov!r} cannot serve a {fam} model"
        )
        raise ValueError(
            f"model {m!r} is a {fam} model, but the selected "
            f"mode/backend/provider needs a {target} one — {hint}."
        )
    return m


def _litellm_route(provider: str, model: str) -> str:
    """LiteLLM ``<provider>/<model>`` route id for the google-adk / openai-agents
    LiteLLM shims. Single-prefix and idempotent: a model already carrying the
    provider prefix (``openrouter/openai/gpt-4o``) is returned unchanged; every
    other id — a bare model (``llama-3.3-70b-versatile``) or a vendor-prefixed
    openrouter slug (``openai/gpt-4o``) — gets the provider prefixed exactly
    once (``groq/llama-…`` / ``openrouter/openai/gpt-4o``).

    This supersedes the old ``model if "/" in model`` guard, which skipped
    prefixing for ANY slash-bearing id — right for a provider that never carries
    an internal slash, but wrong for openrouter, whose every slug is
    ``vendor/model`` and would otherwise route to the wrong LiteLLM provider (an
    ``anthropic/…`` slug billed as anthropic, not openrouter). The startswith
    form keeps existing bare-model routing identical while fixing the slash case.
    """
    return model if model.startswith(provider + "/") else f"{provider}/{model}"


# Claude model identifiers the claude-agent-sdk / claude-terminal modes accept.
_CLAUDE_MODEL_PREFIXES = _FAMILY_PREFIXES["anthropic"]


def is_claude_model(model: str) -> bool:
    return model_family(model) == "anthropic"


def full_claude_model_id(short: str) -> str:
    """Map the friendly aliases used by the picker to full model ids for the
    ANTHROPIC_MODEL env var the `claude` CLI reads."""
    return {
        "haiku": "claude-haiku-4-5-20251001",
        "sonnet": "claude-sonnet-4-6",
        "opus": "claude-opus-4-8",
    }.get((short or "").strip().lower(), short)


_MODES = ("oneshot", "chat", "claude-terminal", "opencode")

# ── The exposure-ladder composition model ────────────────────────────────
# THREE independent ladders gate the composition tools (superseding the old
# single ``exposure`` dropdown, kept below as a legacy alias). Each ladder is
# cumulative, low → high privilege:
#   * generator exposure — none / read / read_call / read_call_write
#   * renderer  exposure — none / read / read_write
#   * cell creation      — no   / create_cell / create_cell_with_generator
# ``composition_flags`` fans the three tiers out into the SEVEN booleans the
# ONE tool registry gates on (the source of truth every backend builds from).
_GEN_TIERS = ("none", "read", "read_call", "read_call_write")
_REND_TIERS = ("none", "read", "read_write")
_CELL_TIERS = ("no", "create_cell", "create_cell_with_generator")

# The seven composition-flag booleans, in registry/gate order — the canonical
# key set for a ``comp_flags`` dict threaded to every backend.
_COMP_FLAG_NAMES = (
    "gen_read", "gen_call", "gen_write",
    "rend_read", "rend_write",
    "cell_create", "cell_create_gen",
)


def _one_of(field: str, raw, tiers: tuple) -> str:
    """A ladder value normalised to its tier: blank/``None`` → the first
    (``none``/``no``) tier; any other unknown value can't be honored as set and
    raises naming ``field`` — the shared dropdown-error style used across
    :func:`parse_agent_config`."""
    val = str(raw or "").strip().lower() or tiers[0]
    if val not in tiers:
        raise ValueError(
            f"unknown {field} {val!r} — expected one of {', '.join(tiers)}"
        )
    return val


def composition_flags(generator_exposure, renderer_exposure, cell_creation) -> dict:
    """Fan the three composition ladders — generator exposure, renderer exposure
    and cell creation — out into the SEVEN boolean gates the tool registry uses.

    Each ladder is cumulative: a higher tier turns on every flag a lower one
    does. Blank/``None`` → the ladder's first tier (all-off for the two
    exposures, no-create for cells); an unknown explicit value raises, naming
    the offending field (see :func:`_one_of`)."""
    gen_t = _one_of("generator_exposure", generator_exposure, _GEN_TIERS)
    rend_t = _one_of("renderer_exposure", renderer_exposure, _REND_TIERS)
    cell_t = _one_of("cell_creation", cell_creation, _CELL_TIERS)
    return {
        "gen_read": gen_t in ("read", "read_call", "read_call_write"),
        "gen_call": gen_t in ("read_call", "read_call_write"),
        "gen_write": gen_t == "read_call_write",
        "rend_read": rend_t in ("read", "read_write"),
        "rend_write": rend_t == "read_write",
        "cell_create": cell_t in ("create_cell", "create_cell_with_generator"),
        "cell_create_gen": cell_t == "create_cell_with_generator",
    }


def comp_flags_from(cfg: dict) -> dict:
    """The seven composition-flag booleans pulled out of a parsed agent config
    (or any dict carrying them) — the ``comp_flags`` a backend threads through."""
    cfg = cfg or {}
    return {k: bool(cfg.get(k)) for k in _COMP_FLAG_NAMES}


# The old single ``exposure`` dropdown, kept as a LEGACY alias over the three
# ladders. Cumulative tiers, low → high privilege.
_EXPOSURE_TIERS = ("none", "create_cell", "run_generators", "modify_and_run")

# Each legacy tier as a (generator_exposure, renderer_exposure, cell_creation)
# triple over the new ladders.
_LEGACY_EXPOSURE_MAP = {
    "none":           ("none",            "none",       "no"),
    "create_cell":    ("none",            "none",       "create_cell"),
    "run_generators": ("read_call",       "none",       "create_cell_with_generator"),
    "modify_and_run": ("read_call_write", "read_write", "create_cell_with_generator"),
}


def exposure_flags(raw) -> dict:
    """LEGACY alias — map the old single ``exposure`` dropdown to the SAME seven
    composition gates :func:`composition_flags` produces, via
    :data:`_LEGACY_EXPOSURE_MAP`. Kept so ``parse_agent_config``'s existing
    ``**exposure_flags(cfg.get("exposure"))`` keeps working (now fanning out to
    seven flags); new callers should use :func:`composition_flags` directly.

    Blank/absent → ``none``; any other unknown value can't be honored as set and
    raises, matching every other dropdown in :func:`parse_agent_config`.
    """
    val = str(raw or "").strip().lower() or "none"
    if val not in _EXPOSURE_TIERS:
        raise ValueError(
            f"unknown exposure {val!r} — expected one of {', '.join(_EXPOSURE_TIERS)}"
        )
    return composition_flags(*_LEGACY_EXPOSURE_MAP[val])


def parse_agent_config(cfg: dict) -> dict:
    """Normalise an ``agent-config.set_yaml`` mapping into the kwargs the agent
    machinery expects. The single source of truth for defaults + coercion.

    Validation policy (one place, every consumer): a **blank/absent** field
    takes a sensible default; a field **explicitly set to a value that can't be
    honored as set** is a hard ``ValueError``, never a silent reinterpretation.
    Concretely — an unknown ``mode`` / ``backend`` / ``auth`` / ``provider`` (a
    value outside its dropdown's options), a ``model`` whose family contradicts
    what the selection actually talks to (see :func:`resolve_model`), and a
    non-API ``auth`` paired with an engine that can't honor it all raise. Each
    OAuth/subscription option is honored only by its own engine:
    ``auth=claude_code`` (Claude subscription) by the claude-agent-sdk backend
    and claude-terminal mode, ``auth=google_oauth`` (the Gemini CLI's logged-in
    Google account) by the gemini backend; anywhere else they fail rather than
    silently billing the provider API key. The returned ``"warnings"`` list
    remains for any future non-fatal notes; today it is empty on success.
    """
    cfg = cfg or {}
    warnings: list = []
    # Every dropdown: blank/whitespace → the field default; anything else must
    # be a known option, else the config can't be honored as set → hard error.
    mode = (cfg.get("mode") or "").strip().lower() or "oneshot"
    if mode not in _MODES:
        raise ValueError(
            f"unknown mode {mode!r} — expected one of {', '.join(_MODES)}"
        )
    backend = (cfg.get("backend") or "").strip().lower() or "pydantic-ai"
    if backend not in _KNOWN_BACKENDS:
        raise ValueError(
            f"unknown backend {backend!r} — expected pydantic-ai / "
            "claude-agent-sdk / gemini / google-adk / openai-agents / maf"
        )
    auth = (cfg.get("auth") or "").strip().lower() or "api_key"
    if auth not in ("api_key", "claude_code", "google_oauth"):
        raise ValueError(
            f"unknown auth {auth!r} — expected api_key / claude_code / google_oauth"
        )
    provider = (cfg.get("provider") or "").strip().lower() or "anthropic"
    if provider not in _PROVIDER_DEFAULT_MODEL:
        raise ValueError(
            f"unknown provider {provider!r} — expected one of "
            f"{', '.join(_PROVIDER_DEFAULT_MODEL)}"
        )
    # Blank model → the target's default; a contradicting explicit model raises.
    model = resolve_model(mode, backend, provider, cfg.get("model"))
    # Extended thinking: "auto" (backend/model default — today's behavior),
    # "on" (request thinking with visible summarized text), "off" (disable).
    # YAML 1.1 parses bare on/off as booleans, so the dropdown's values reach
    # us as True/False — coerce them back before normalizing.
    raw_thinking = cfg.get("thinking")
    if isinstance(raw_thinking, bool):
        raw_thinking = "on" if raw_thinking else "off"
    thinking = str(raw_thinking or "").strip().lower() or "auto"
    if thinking not in ("auto", "on", "off"):
        raise ValueError(
            f"unknown thinking {thinking!r} — expected auto / on / off"
        )
    # Non-API auth is honored only by the engine it belongs to; any other
    # selection can't honor it, so refuse rather than silently billing an API
    # key. Each OAuth/subscription option is a distinct top-level choice —
    # claude_code (Claude subscription) and google_oauth (the Gemini CLI's
    # logged-in Google account) are NOT interchangeable.
    is_claude_engine = mode == "claude-terminal" or (
        mode in ("oneshot", "chat") and backend in _CLAUDE
    )
    is_gemini_engine = mode in ("oneshot", "chat") and backend in _GEMINI
    if auth == "claude_code" and not is_claude_engine:
        raise ValueError(
            "auth=claude_code (Claude subscription) can't be honored by this "
            "selection — it is only available on the claude-agent-sdk backend "
            "or claude-terminal mode. Use one of those, or set auth=api_key."
        )
    if auth == "google_oauth" and not is_gemini_engine:
        raise ValueError(
            "auth=google_oauth (Gemini CLI Google login) can't be honored by "
            "this selection — it is only available on the gemini backend. Use "
            "backend=gemini, or set auth=api_key."
        )
    return {
        "mode": mode,
        "backend": backend,
        "auth": auth,
        "provider": provider,
        "model": model,
        "max_tokens": to_int(cfg.get("max_tokens"), 4096),
        "system_prompt": (cfg.get("system_prompt") or "").strip(),
        # File access is the norm — every agent works on the cell's files
        # (interactive modes live-sync them). Composition callers can still
        # pass enable_file_tools: false explicitly for a text-only turn.
        "enable_file_tools": to_bool(cfg.get("enable_file_tools"), True),
        "enable_python_tool": to_bool(cfg.get("enable_python_tool"), False),
        # Composition tools: the legacy single ``exposure`` dropdown fans out
        # into the SEVEN composition gates (generator read/call/write, renderer
        # read/write, cell create + create-with-generator) via the legacy alias.
        # (A later stage adds the three-ladder config keys directly.)
        **exposure_flags(cfg.get("exposure")),
        "prefer_terminal": to_bool(cfg.get("prefer_terminal"), True),
        "history_char_budget": to_int(cfg.get("history_char_budget"), 24000),
        "stream": to_bool(cfg.get("stream"), False),
        "thinking": thinking,
        "output_schema": as_schema(cfg.get("output_schema")),
        # Assumptions-ledger companion pass — on by default, on a cheap model.
        "ledger": to_bool(cfg.get("ledger"), True),
        "ledger_model": resolve_ledger_model(mode, backend, provider, cfg.get("ledger_model")),
        "ledger_max_tokens": to_int(cfg.get("ledger_max_tokens"), 4096),
        "ledger_every_turns": to_int(cfg.get("ledger_every_turns"), 1),
        "warnings": warnings,
    }


def oneshot_tag_values(tag_values: dict, **overrides) -> dict:
    """Fold a resolved agent config tag into a ONE-SHOT ``gen.call("agent")``
    config — the parent-generator convention, hardened.

    The tag may be authored for a container mode: ``claude-terminal`` is the
    same claude engine as the ``claude-agent-sdk`` backend, so its oneshot
    twin forces that backend (keeping ``auth=claude_code`` and CLI model
    aliases honorable); ``opencode`` tags carry provider/model that the
    pydantic-ai default already honors. The folded config is validated HERE
    (``parse_agent_config`` raises), so a tag the child would reject fails
    before the parent spends a single fan-out call on it.

    **Cost default:** the assumptions-ledger companion pass is on-by-default
    for a *user-facing* agent run, but a composition fan-out usually discards
    it — one wasted LLM call per child. So this helper defaults ``ledger`` OFF
    (a tag that explicitly sets it, or an explicit ``ledger=True`` override for
    a call whose ledger you PROMOTE, still wins).
    """
    values = dict(tag_values or {})
    if (values.get("mode") or "").strip().lower() == "claude-terminal":
        values["backend"] = "claude-agent-sdk"
    values["mode"] = "oneshot"
    values.setdefault("ledger", False)   # composition-cheap; tag/override wins
    values.update(overrides)
    parse_agent_config(values)   # can't be honored → raise pre-fan-out
    return values


async def gather_agent_calls(
    specs: list, *, timeout: float = 600.0, poll_interval: float = 0.4,
    max_concurrent: Optional[int] = None,
) -> list:
    """Run N one-shot ``agent`` sub-runs CONCURRENTLY — the agent-specific
    sugar over :func:`gen.call_many`. Each spec is spawn kwargs for the
    ``agent`` generator (``prompt`` / ``config`` / ``inputs`` / …); the
    ``"source": "agent"`` is filled in for you.

    See :func:`gen.call_many` for the full contract: concurrent (a plain
    ``asyncio.gather`` over ``gen.call`` would serialize on the bridge's
    single IPC lock), per-item ``ok=False`` isolation, ``timeout`` bounding
    the whole batch, ``max_concurrent`` capping the spawn window, and
    :class:`gen.Cancelled` raised on a user stop.
    """
    return await gen.call_many(
        [{"source": "agent", **dict(s)} for s in specs],
        timeout=timeout, poll_interval=poll_interval, max_concurrent=max_concurrent,
    )


# ──────────────────────────────────────────────────────────────────────
# Composition tools. SEVEN gates over THREE independent, cumulative ladders
# (see :func:`composition_flags`), matching the kinds of act an agent can do:
#
#   * generator exposure (``gen_read`` ⊂ ``gen_call`` ⊂ ``gen_write``):
#       - ``gen_read`` — discover installed generators (list_generators) and
#         exposed source cells (list_exposed_cells, read_other_cell).
#       - ``gen_call`` — run a generator one-shot to preview/test it
#         (call_generator).
#       - ``gen_write`` — the generator BUILDER bundle: edit exposed cells
#         (write_other_cell), author a generator (add_generator), and commit a
#         NEW generator into the stack (commit_generator).
#   * renderer exposure (``rend_read`` ⊂ ``rend_write``):
#       - ``rend_read`` — discover/read exposed renderer-source cells
#         (list_renderers, read_renderer).
#       - ``rend_write`` — author/compile-check/commit renderers
#         (add_renderer, check_renderer, commit_renderer).
#   * cell creation (``cell_create`` ⊂ ``cell_create_gen``):
#       - ``cell_create`` — the cheap default: drop a new CONTENT cell beside
#         this one (create_cell). No contract, no program.
#       - ``cell_create_gen`` — stand up a LIVE cell backed by an existing modify
#         generator (create_cell_with_generator — e.g. a running terminal).
#
# The three ladders are independent, so a config can expose generators without
# renderers (or either without cell creation) — the legacy ``exposure`` alias
# just picks four fixed points across them.
#
# Every gate respects each cell's per-cell "expose to generators" flag — read,
# write, run-via-gen.call, discovery via gen.generators(), and the
# create_cell_with_generator handoff all refuse a cell turned off to generators.
#
# The impls call the public ``gen.*`` surface and degrade cleanly with no host
# (dev mode). They take/return JSON strings so the schema is uniform across
# every backend: pydantic-ai (in-memory FastMCP toolset), claude-agent-sdk
# (in-process SDK MCP server), the container agents and the gemini CLI (both
# over the SSE MCP bridge — gemini is a headless subprocess, so it reaches the
# same bridge on localhost).
# ──────────────────────────────────────────────────────────────────────


def _loads_files(s):
    """Parse a JSON ``{path: text}`` object the model passes for file maps.
    Returns the dict (values coerced to str) or ``None`` on bad input."""
    if not s:
        return {}
    try:
        v = json.loads(s)
    except Exception:
        return None
    if not isinstance(v, dict):
        return None
    return {str(k): (x if isinstance(x, str) else json.dumps(x)) for k, x in v.items()}


async def _tool_list_exposed_cells() -> str:
    """List the generator- and renderer-source cells exposed to generators in
    this channel (cell_id, name, stack_type, generators, files). Use this to
    discover what you can view, edit, or run."""
    cells = gen.exposed_cells()
    return json.dumps(cells, indent=2) if cells else "(no exposed cells)"


async def _tool_read_other_cell(cell_id: str) -> str:
    """Read an exposed cell's full file tree as a JSON object {path: text}."""
    try:
        tree = gen.read_cell(cell_id)
    except Exception as e:  # noqa: BLE001
        return f"ERROR: {e}"
    out = {p: (c if isinstance(c, str) else f"<binary {len(c)} bytes>") for p, c in tree.items()}
    return json.dumps(out, indent=2) if out else "(empty cell)"


async def _tool_list_renderers() -> str:
    """List the renderer-source cells exposed to generators — the renderers you can
    view and (with renderer write access) extend. Each entry: cell_id, name and its
    files. Use read_renderer to see a renderer's source before authoring one with
    add_renderer / commit_renderer. Only cells exposed to generators appear."""
    cells = [c for c in gen.exposed_cells() if c.get("stack_type") == "renderer"]
    return json.dumps(cells, indent=2) if cells else "(no exposed renderer cells)"


async def _tool_read_renderer(cell_id: str) -> str:
    """Read a renderer-source cell's full file tree as JSON {path: text} — its
    manifest.rend_yaml and component source. Find cell_ids with list_renderers.
    Only renderer-source cells; use read_other_cell for generator/content cells."""
    match = next(
        (c for c in gen.exposed_cells() if str(c.get("cell_id")) == cell_id), None
    )
    if match is None:
        return f"ERROR: no exposed cell {cell_id!r}"
    if match.get("stack_type") != "renderer":
        return (
            f"ERROR: cell {cell_id!r} is not a renderer-source cell — "
            "use read_other_cell"
        )
    try:
        tree = gen.read_cell(cell_id)
    except Exception as e:  # noqa: BLE001
        return f"ERROR: {e}"
    out = {p: (c if isinstance(c, str) else f"<binary {len(c)} bytes>") for p, c in tree.items()}
    return json.dumps(out, indent=2) if out else "(empty cell)"


async def _tool_write_other_cell(cell_id: str, files_json: str, summary: str = "") -> str:
    """Edit an exposed cell: merge a JSON object {path: text} over its files and
    commit an undoable version (applies on the cell's next run)."""
    files = _loads_files(files_json)
    if files is None:
        return "ERROR: files_json must be a JSON object of {path: text}"
    try:
        vid = gen.write_cell(cell_id, files, summary=summary or None)
    except Exception as e:  # noqa: BLE001
        return f"ERROR: {e}"
    return f"wrote version {vid or '(dev)'} to cell {cell_id} ({len(files)} file(s))"


async def _tool_add_generator(
    cell_id: str, generator_id: str, name: str, entrypoint: str,
    files_json: str, types: str = "create", summary: str = "",
) -> str:
    """Add a NEW generator to an exposed cell: writes <generator_id>/manifest.gen_yaml
    + the files under <generator_id>/. files_json is {relpath: text} rooted at the
    generator dir and MUST include the entrypoint. types is a comma list of
    modify/create."""
    files = _loads_files(files_json)
    if files is None:
        return "ERROR: files_json must be a JSON object of {path: text}"
    type_list = [t.strip() for t in (types or "create").split(",") if t.strip()] or ["create"]
    try:
        vid = gen.add_generator(
            cell_id, id=generator_id, name=name, entrypoint=entrypoint,
            files=files, type=type_list, summary=summary,
        )
    except Exception as e:  # noqa: BLE001
        return f"ERROR: {e}"
    return f"added generator {generator_id!r} (version {vid or '(dev)'})"


async def _tool_add_renderer(
    cell_id: str, renderer_id: str, name: str, entrypoint: str,
    files_json: str, extensions: str = "", summary: str = "",
) -> str:
    """Add a NEW renderer to an exposed renderer-source cell: writes
    <renderer_id>/manifest.rend_yaml + files under <renderer_id>/. extensions is
    a comma list like '.foo,.bar'."""
    files = _loads_files(files_json)
    if files is None:
        return "ERROR: files_json must be a JSON object of {path: text}"
    exts = [e.strip() for e in (extensions or "").split(",") if e.strip()]
    try:
        vid = gen.add_renderer(
            cell_id, id=renderer_id, name=name, entrypoint=entrypoint,
            files=files, extensions=exts or None, summary=summary,
        )
    except Exception as e:  # noqa: BLE001
        return f"ERROR: {e}"
    return f"added renderer {renderer_id!r} (version {vid or '(dev)'})"


async def _tool_create_cell(name: str, files_json: str, summary: str = "", pinned: str = "") -> str:
    """Create a NEW content cell right beside this one — the DEFAULT "make a new
    cell" action. Use it to surface extra material: a draft, a side result, an
    alternative to compare, anything worth its own cell in the stack. files_json
    is {path: text} (the cell's files); pinned is which file to show first
    (defaults to the first file). This creates ordinary CONTENT, not a program —
    it is NOT how you add a generator or renderer. Those are real contracts:
    use commit_generator / commit_renderer for those."""
    files = _loads_files(files_json)
    if files is None:
        return "ERROR: files_json must be a JSON object of {path: text}"
    try:
        cid = await gen.create_stack_cell(
            name, files=files or None, summary=summary or None, pinned=pinned or None,
        )
    except Exception as e:  # noqa: BLE001
        return f"ERROR: {e}"
    return f"created cell {cid}" if cid else "no host (dev mode) — nothing created"


async def _commit_source_cell(stack: str, name: str, files_json: str, summary: str) -> str:
    """Shared impl for the two commit_new_*_cell tools (stack: 'generator'|'renderer')."""
    files = _loads_files(files_json)
    if files is None:
        return "ERROR: files_json must be a JSON object of {path: text}"
    make = gen.create_generator_cell if stack == "generator" else gen.create_renderer_cell
    try:
        cid = make(name, files=files, summary=summary or None)
    except Exception as e:  # noqa: BLE001
        return f"ERROR: {e}"
    return f"committed {stack} cell {cid}" if cid else "no host (dev mode) — nothing created"


async def _tool_commit_generator(name: str, files_json: str, summary: str = "") -> str:
    """Commit a NEW generator into the channel's generator stack — an intentional
    act that adds a real, permanent capability to the app. A generator is NOT
    just any cell: it is a Python program with a contract — a valid
    `manifest.gen_yaml` plus the entrypoint it names, implementing the run()
    lifecycle over the `gen.*` API. READ `how-to-write-a-generator.md` before
    authoring one, and TEST it first (sanity-run the logic, then `call_generator`
    once it exists) — committing is the finish line, not the draft. files_json is
    {path: text} for the whole cell and MUST include `manifest.gen_yaml` + the
    entrypoint. The new cell is exposed to you immediately, so you can read it
    back and refine with `write_other_cell`. To just show content, use
    `create_cell` instead."""
    return await _commit_source_cell("generator", name, files_json, summary)


async def _tool_commit_renderer(name: str, files_json: str, summary: str = "") -> str:
    """Commit a NEW renderer into the channel's renderer stack — an intentional
    act that adds a real, permanent way to view a file type. A renderer is NOT
    just any cell: it is a React component with a contract — a valid
    `manifest.rend_yaml` (declaring the extensions it claims) plus the entrypoint
    it names, following the shadow-DOM styling rules. READ
    `how-to-write-a-renderer.md` before authoring one, and TEST it first with
    `check_renderer` — committing is the finish line, not the draft. files_json
    is {path: text} for the whole cell and MUST include `manifest.rend_yaml` +
    the entrypoint. The new cell is exposed to you immediately, so you can read
    it back and refine with `write_other_cell`. To just show content, use
    `create_cell` instead."""
    return await _commit_source_cell("renderer", name, files_json, summary)


async def _tool_call_generator(generator_id: str, prompt: str = "", files_json: str = "") -> str:
    """Run another generator by id (one-shot) and report its result — the way to
    test/preview a generator. files_json is an optional {path: text} input map."""
    inputs = None
    if files_json:
        inputs = _loads_files(files_json)
        if inputs is None:
            return "ERROR: files_json must be a JSON object of {path: text}"
    # A test/preview call discards everything but the reply text — don't pay
    # for the agent's default assumptions-ledger companion pass on it.
    config = (
        {"agent-config.set_yaml": {"ledger": False}}
        if (generator_id or "").strip() == "agent" else None
    )
    try:
        res = await gen.call(
            generator_id, prompt=prompt, inputs=inputs or None,
            config=config, timeout=600,
        )
    except Exception as e:  # noqa: BLE001
        return f"ERROR: {e}"
    if not res.ok:
        return f"generator {generator_id!r} failed: {res.error or '(no detail)'}"
    txt = res.files.get("_agent/output.md", "") if res.files else ""
    if len(txt) > 8000:
        txt = txt[:8000] + f"\n…[truncated — full size {len(txt)} chars]"
    names = sorted(p for p in (res.files or {}) if not p.startswith("_agent/"))
    return f"ok. files: {names}\n\noutput:\n{txt}".strip()


async def _tool_check_renderer(files_json: str, entrypoint: str) -> str:
    """Compile-check a renderer (esbuild) — the way to test/preview a renderer.
    files_json is {path: text} of the renderer's files; entrypoint is the main
    module. Returns 'compiled OK' or the compile errors."""
    files = _loads_files(files_json)
    if files is None:
        return "ERROR: files_json must be a JSON object of {path: text}"
    try:
        chk = gen.check_renderer(files, entrypoint=entrypoint)
    except Exception as e:  # noqa: BLE001
        return f"ERROR: {e}"
    if chk.ok:
        return "compiled OK"
    return "compile errors:\n" + "\n".join(chk.errors or ["(no detail)"])


async def _tool_list_generators() -> str:
    """List the generators installed in this channel that you can RUN — id,
    name, summary, group (source cell), type (a subset of modify/create),
    whether it's a daemon (long-lived, e.g. a terminal), input-cell bounds, and
    whether it needs a prompt. This is how you discover ids for call_generator
    and create_cell_with_generator. Only generators whose source cell is exposed
    to generators appear (the same visibility as list_exposed_cells)."""
    try:
        infos = gen.generators()
    except Exception as e:  # noqa: BLE001
        return f"ERROR: {e}"
    out = [
        {
            "id": i.id,
            "name": i.name,
            "summary": i.summary,
            "group": i.group,
            "type": list(i.type or []),
            "daemon": i.daemon,
            "min_inputs": i.min_inputs,
            "max_inputs": i.max_inputs,
            "prompt_required": i.prompt_required,
        }
        for i in infos
    ]
    return json.dumps(out, indent=2) if out else "(no generators installed)"


async def _tool_create_cell_with_generator(
    name: str, generator_id: str, files_json: str = "",
    prompt: str = "", summary: str = "",
) -> str:
    """Create a NEW cell and RUN an existing generator on it in MODIFY mode —
    the way to stand up a LIVE cell backed by a generator (e.g. a running
    terminal via the `run-terminal` generator, a VS Code env, a browser
    session). ALWAYS discover the exact ids/types with list_generators first
    (ids are hyphenated, e.g. `run-terminal` / `vscode-env`, not the directory
    name). files_json is an optional {path: text} seed for the new cell; prompt
    seeds the generator's run. The target generator MUST declare `modify` in its
    type and accept a single input cell (the new cell is its only input). This
    hands the cell off ONCE (fire-and-forget):
    the generator's run becomes an independent live cell in the stack, not a
    value returned to you. For static content use create_cell; to test a
    generator's text output without creating a durable cell use call_generator."""
    files = _loads_files(files_json) if files_json else {}
    if files is None:
        return "ERROR: files_json must be a JSON object of {path: text}"
    try:
        cid = await gen.create_stack_cell(
            name, files=files or None, summary=summary or None,
        )
    except Exception as e:  # noqa: BLE001
        return f"ERROR: {e}"
    if not cid:
        return "no host (dev mode) — nothing created"
    try:
        await gen.start_modify_run(cid, generator_id, prompt=prompt or None)
    except Exception as e:  # noqa: BLE001
        # The cell exists with its seed files; only the handoff failed (bad id,
        # a create-only generator, an unexposed cell, wrong input bounds).
        return (
            f"created cell {cid}, but running {generator_id!r} on it failed: {e}"
        )
    return f"created cell {cid} and started {generator_id!r} on it (modify)"


# ──────────────────────────────────────────────────────────────────────
# ONE tool registry, MANY harness formats.
#
# The composition tools are declared ONCE here — a name, its gate, whether it
# must run on the generator's main loop, its ``gen.*`` authoring twin, and the
# typed async impl. Every backend builds its OWN native tool format FROM this
# one list, so a tool is added in exactly one place and a new harness is one
# adapter over the same registry:
#
#   * pydantic-ai      → an in-memory ``fastmcp`` server consumed via MCPToolset
#                        (no network; pydantic-ai natively speaks FastMCP).
#   * claude-agent-sdk → an in-process ``create_sdk_mcp_server`` (its blessed
#                        in-process MCP surface).
#   * container agents → the same FastMCP tools served over SSE by mcp_bridge.
#
# The JSON schema is derived once from each impl's typed signature (never
# restated), and the description is the impl's docstring plus its ``gen.*`` twin
# — so the calling surface (tool name) and the authoring surface (gen.* name)
# stay cross-referenced for the LLMs that do both.
#
# Registry columns: (tool_name, gate, main_loop, gen_twin, impl). ``gate`` is
# one of the seven composition-flag names (gen_read/gen_call/gen_write,
# rend_read/rend_write, cell_create/cell_create_gen — see
# :func:`composition_flags`); ``main_loop`` marks impls that await an async
# ``gen.*`` (so the threaded SSE bridge bounces them to the generator's loop —
# the in-process backends already run there). The ladders are cumulative, so a
# write tier always ships with the read/call tiers below it.
# ──────────────────────────────────────────────────────────────────────

_MCP_SERVER_NAME = "composition"

_COMPOSITION_TOOLS = [
    # generator READ — discover / read exposed generator + content cells
    ("list_generators",            "gen_read",       False, "gen.generators()",            _tool_list_generators),
    ("list_exposed_cells",         "gen_read",       False, "gen.exposed_cells()",         _tool_list_exposed_cells),
    ("read_other_cell",            "gen_read",       False, "gen.read_cell()",             _tool_read_other_cell),
    # generator CALL — run a generator one-shot (preview/test)
    ("call_generator",             "gen_call",       True,  "gen.call()",                  _tool_call_generator),
    # generator WRITE — edit exposed cells + author/commit generators
    ("write_other_cell",           "gen_write",      False, "gen.write_cell()",            _tool_write_other_cell),
    ("add_generator",              "gen_write",      False, "gen.add_generator()",         _tool_add_generator),
    ("commit_generator",           "gen_write",      False, "gen.create_generator_cell()", _tool_commit_generator),
    # renderer READ — discover / read exposed renderer-source cells
    ("list_renderers",             "rend_read",      False, "gen.exposed_cells()",         _tool_list_renderers),
    ("read_renderer",              "rend_read",      False, "gen.read_cell()",             _tool_read_renderer),
    # renderer WRITE — author / compile-check / commit renderers
    ("add_renderer",               "rend_write",     False, "gen.add_renderer()",          _tool_add_renderer),
    ("check_renderer",             "rend_write",     False, "gen.check_renderer()",        _tool_check_renderer),
    ("commit_renderer",            "rend_write",     False, "gen.create_renderer_cell()",  _tool_commit_renderer),
    # cell CREATE — the standalone content cell
    ("create_cell",                "cell_create",    True,  "gen.create_stack_cell()",     _tool_create_cell),
    # cell CREATE + generator handoff — a new cell backed by a live generator
    ("create_cell_with_generator", "cell_create_gen", True, "gen.create_stack_cell() + gen.start_modify_run()", _tool_create_cell_with_generator),
]


def _gated_tools(
    *, gen_read: bool = False, gen_call: bool = False, gen_write: bool = False,
    rend_read: bool = False, rend_write: bool = False,
    cell_create: bool = False, cell_create_gen: bool = False,
) -> list:
    """The registry rows whose gate flag is on, in registry order."""
    on = {
        "gen_read": gen_read, "gen_call": gen_call, "gen_write": gen_write,
        "rend_read": rend_read, "rend_write": rend_write,
        "cell_create": cell_create, "cell_create_gen": cell_create_gen,
    }
    return [row for row in _COMPOSITION_TOOLS if on[row[1]]]


def _arg_schema(fn) -> dict:
    """``{arg: type}`` for an impl, read straight from its typed signature — the
    claude ``@tool`` dict-schema form. One source of truth (the signature);
    never a hand-restated schema that can drift.

    ``get_type_hints`` RESOLVES the annotations to real types: this module runs
    under ``from __future__ import annotations`` (PEP 563), so ``__annotations__``
    holds the *strings* ``"str"``/… — claude's ``@tool`` needs the actual ``str``
    type, not its name. (FastMCP resolves this itself, so its path is unaffected.)"""
    import inspect
    import typing
    try:
        hints = typing.get_type_hints(fn)
    except Exception:  # noqa: BLE001 — degrade to str for any unresolvable hint
        hints = {}
    return {
        name: hints.get(name, str)
        for name in inspect.signature(fn).parameters
        if name != "return"
    }


def _tool_description(fn, gen_twin: str) -> str:
    """The impl's docstring plus its authoring twin, so the calling surface
    always points back at the ``gen.*`` an author would write for the same act."""
    doc = (fn.__doc__ or "").strip()
    return f"{doc}\n\nAuthoring-API twin (when writing a generator): {gen_twin}.".strip()


def _build_fastmcp_server(entries: list):
    """A ``fastmcp`` server exposing ``entries`` — the single definition the
    pydantic-ai backend consumes in-memory and the SSE bridge serves. Returns
    ``None`` when fastmcp isn't importable (degrade cleanly, like the bridge)."""
    if not entries:
        return None
    try:
        from fastmcp import FastMCP
    except Exception as e:  # noqa: BLE001
        gen.log(f"fastmcp unavailable — composition tools not exposed to this surface ({e})")
        return None
    server = FastMCP(_MCP_SERVER_NAME)
    for name, _gate, _main_loop, gen_twin, fn in entries:
        # run_in_thread=False: the impls are async and await loop-affine gen.*
        # calls, so FastMCP must await them on the caller's loop (the generator's
        # main loop for the in-memory pydantic-ai path), never a worker thread.
        server.tool(
            name=name, description=_tool_description(fn, gen_twin), run_in_thread=False,
        )(fn)
    return server


def _composition_mcp_server(comp_flags: dict):
    """The in-process ``create_sdk_mcp_server`` for the claude-agent-sdk backend,
    built from the ONE registry. ``comp_flags`` is the seven-boolean composition
    dict (see :func:`composition_flags`). Returns ``(server, allowed_tool_names)``
    or ``(None, [])`` when every gate is off."""
    entries = _gated_tools(**(comp_flags or {}))
    if not entries:
        return None, []
    from claude_agent_sdk import create_sdk_mcp_server, tool

    built: list = []
    names: list = []
    for tname, _gate, _main_loop, gen_twin, fn in entries:
        @tool(tname, _tool_description(fn, gen_twin), _arg_schema(fn))
        async def _impl(args, _fn=fn):
            try:
                text = await _fn(**args)
            except Exception as e:  # noqa: BLE001 — keep the agent loop alive
                return {"content": [{"type": "text", "text": f"ERROR: {e}"}], "is_error": True}
            return {"content": [{"type": "text", "text": text}]}

        built.append(_impl)
        names.append(f"mcp__{_MCP_SERVER_NAME}__{tname}")
    server = create_sdk_mcp_server(name=_MCP_SERVER_NAME, version="1.0.0", tools=built)
    return server, names


async def run_agent(
    *,
    prompt: str,
    backend: str = "pydantic-ai",
    auth: str = "api_key",
    provider: str = "anthropic",
    model: str = "claude-sonnet-4-6",
    max_tokens: int = 4096,
    system_prompt: str = "",
    enable_file_tools: bool = False,
    enable_python_tool: bool = False,
    gen_read: bool = False,
    gen_call: bool = False,
    gen_write: bool = False,
    rend_read: bool = False,
    rend_write: bool = False,
    cell_create: bool = False,
    cell_create_gen: bool = False,
    enable_read_tools: bool = True,
    output_schema: Optional[dict] = None,
    stream: bool = False,
    thinking: str = "auto",
    on_event: Optional[Callable[[dict], None]] = None,
    should_stop: Optional[Callable[[], bool]] = None,
) -> AgentResult:
    """Run one agent turn with the selected backend. See module docstring.

    ``should_stop`` is polled by the streaming backends between chunks; when it
    returns True the backend stops consuming the model stream and returns the
    text accumulated so far (a live chat interrupt that actually halts
    generation, not just delta forwarding).

    ``thinking``: "auto" leaves the backend/model default untouched; "on"
    requests extended thinking with visible (summarized) text; "off" disables
    it. Streaming turns additionally emit ``{"type": "thinking_delta"}``
    events on the claude backend; every backend records full thinking in the
    trace as ``{"type": "thinking"}`` events.

    ``enable_read_tools=False`` makes the turn BLIND to the workspace: even
    the claude backend's read-only surface (Read/Glob/Grep, web) is blocked.
    For callers whose turn must judge only its inlined corpora — the ledger's
    extraction passes run in the PARENT's workspace and use this."""
    emit = on_event or (lambda ev: None)
    sys_prompt = (system_prompt or "").strip()
    if output_schema:
        sys_prompt = (sys_prompt + _json_instruction(output_schema)).strip()
    # Structured-output turns are one-shot — never streamed.
    do_stream = bool(stream) and not output_schema
    # The seven composition gates travel as one dict, threaded to every backend.
    comp_flags = {
        "gen_read": gen_read, "gen_call": gen_call, "gen_write": gen_write,
        "rend_read": rend_read, "rend_write": rend_write,
        "cell_create": cell_create, "cell_create_gen": cell_create_gen,
    }

    bk = (backend or "pydantic-ai").strip().lower()
    if bk in _PYDANTIC:
        # pydantic-ai exposes no workspace tools beyond the explicit toggles,
        # so enable_read_tools has nothing to block there.
        text, trace, usage = await _run_pydantic_ai(
            provider=provider, model=model, max_tokens=max_tokens,
            system_prompt=sys_prompt, prompt=prompt,
            enable_file_tools=enable_file_tools, enable_python_tool=enable_python_tool,
            comp_flags=comp_flags,
            stream=do_stream, thinking=thinking, emit=emit, should_stop=should_stop,
        )
        canonical = "pydantic-ai"
    elif bk in _CLAUDE:
        text, trace, usage = await _run_claude_agent_sdk(
            auth=auth, model=model, system_prompt=sys_prompt, prompt=prompt,
            max_tokens=max_tokens,
            enable_file_tools=enable_file_tools, enable_python_tool=enable_python_tool,
            comp_flags=comp_flags,
            enable_read_tools=enable_read_tools,
            stream=do_stream, thinking=thinking, emit=emit, should_stop=should_stop,
        )
        canonical = "claude-agent-sdk"
    elif bk in _GEMINI:
        text, trace, usage = await _run_gemini(
            auth=auth, model=model, system_prompt=sys_prompt, prompt=prompt,
            enable_file_tools=enable_file_tools, enable_python_tool=enable_python_tool,
            comp_flags=comp_flags,
            stream=do_stream, emit=emit, should_stop=should_stop,
        )
        canonical = "gemini"
    elif bk in _ADK or bk in _OPENAI_AGENTS or bk in _MAF:
        # The external-MCP-client backends share one entry point; composition
        # tools reach them over the streamable-http bridge, model routing is
        # provider-driven (like pydantic-ai).
        runner = (
            _run_google_adk if bk in _ADK
            else _run_openai_agents if bk in _OPENAI_AGENTS
            else _run_maf
        )
        text, trace, usage = await runner(
            provider=provider, model=model, max_tokens=max_tokens,
            system_prompt=sys_prompt, prompt=prompt,
            comp_flags=comp_flags,
            stream=do_stream, emit=emit, should_stop=should_stop,
        )
        canonical = (
            "google-adk" if bk in _ADK
            else "openai-agents" if bk in _OPENAI_AGENTS else "maf"
        )
    else:
        raise ValueError(
            f"unknown backend {backend!r}; expected one of pydantic-ai / "
            "claude-agent-sdk / gemini / google-adk / openai-agents / maf"
        )

    structured = _parse_json(text) if output_schema else None
    return AgentResult(
        text=text or "", structured=structured, backend=canonical,
        trace=trace, usage=usage,
    )


# ──────────────────────────────────────────────────────────────────────
# pydantic-ai backend
# ──────────────────────────────────────────────────────────────────────


def _file_tools() -> list:
    """list/read/write/edit tools bound to the workspace via public gen.*."""
    from pydantic_ai import Tool

    async def list_files_t() -> list[str]:
        """List every file currently in the workspace."""
        return [p for p in gen.list_files() if not p.startswith("_agent/")]

    async def read_file_t(path: str) -> str:
        """Read the full text of a workspace file."""
        if not gen.has_file(path):
            return f"ERROR: file not found: {path}"
        v = gen.read_file(path)
        if isinstance(v, bytes):
            return f"BINARY ({len(v)} bytes) — read via run_python to inspect."
        return v

    async def write_file_t(path: str, content: str) -> str:
        """Create or overwrite ``path`` (UTF-8)."""
        gen.update_file(path, content)
        return f"wrote {len(content)} bytes to {path}"

    async def edit_file_t(path: str, old: str, new: str) -> str:
        """First-match string replace inside ``path``."""
        if not gen.has_file(path):
            return f"ERROR: file not found: {path}"
        cur = gen.read_file(path)
        if not isinstance(cur, str):
            return f"ERROR: {path} is binary"
        if old not in cur:
            return f"ERROR: old text not found in {path}"
        gen.update_file(path, cur.replace(old, new, 1))
        return f"edited {path}"

    return [
        Tool(list_files_t, name="list_files"),
        Tool(read_file_t, name="read_file"),
        Tool(write_file_t, name="write_file"),
        Tool(edit_file_t, name="edit_file"),
    ]


def _python_tool() -> list:
    """A run_python tool. Files it writes stay in the workspace and flow back
    to the caller. Extra packages spin up an ephemeral uv env."""
    from pydantic_ai import Tool

    async def run_python(code: str, packages: Optional[list[str]] = None) -> str:
        """Run a Python script in the workspace. Files it creates are kept.

        Args:
            code: Python source (multi-line OK).
            packages: Extra pip packages for this run (e.g. ["matplotlib"]).
        """
        pkgs = list(packages or [])
        if pkgs:
            cmd: list[str] = ["uv", "run", "--no-project"]
            for p in pkgs:
                cmd += ["--with", str(p)]
            cmd += ["python", "-c", code]
        else:
            cmd = [sys.executable, "-c", code]
        rc, out = await gen.run_subprocess(
            cmd, cwd=gen.workspace_path(), timeout=120,
            print_stdout=False, emit_bash_stdout=False,
        )
        return f"return code: {rc}\n--- output ---\n{out if out else '(empty)'}"

    return [Tool(run_python, name="run_python")]


async def _run_pydantic_ai(
    *, provider, model, max_tokens, system_prompt, prompt,
    enable_file_tools, enable_python_tool, comp_flags,
    stream, thinking="auto", emit, should_stop=None,
) -> tuple:
    from collimate.llm import looks_like_auth_error

    p = (provider or "anthropic").strip().lower()
    if not (model or "").strip():
        raise ValueError(
            f"no model configured for provider {p!r} — set the Model field in "
            "agent-config (default_model only fills it in for anthropic)"
        )
    # ``gemini`` is our label; pydantic-ai uses ``google-gla`` for the free API.
    pa_provider = "google-gla" if p == "gemini" else p
    tools: list = []
    if enable_file_tools:
        tools += _file_tools()
    if enable_python_tool:
        tools += _python_tool()
    # Composition tools ride the ONE registry as an in-memory fastmcp server,
    # consumed via pydantic-ai's native MCP toolset — no network, same event
    # loop as the run, so each tool's ``await gen.*`` stays on the generator's
    # main loop. (File/python tools stay plain pydantic Tools — they're this
    # backend's own surface, not part of the cross-harness composition set.)
    comp_entries = _gated_tools(**comp_flags)
    comp_toolset = None
    if comp_entries:
        comp_server = _build_fastmcp_server(comp_entries)
        if comp_server is not None:
            from pydantic_ai.mcp import MCPToolset
            comp_toolset = MCPToolset(comp_server)

    await gen.api_key(p)

    def _build():
        from pydantic_ai import Agent
        from pydantic_ai.settings import ModelSettings
        settings: dict = {"max_tokens": max_tokens}
        if thinking == "on":
            if p == "anthropic":
                # Adaptive thinking with VISIBLE (summarized) text — Opus 4.7+
                # defaults display to "omitted", so it must be explicit.
                settings["anthropic_thinking"] = {
                    "type": "adaptive", "display": "summarized",
                }
            else:
                settings["thinking"] = True   # pydantic-ai unified knob
        elif thinking == "off":
            settings["thinking"] = False
        # No live thinking stream from run_stream — thinking parts land in the
        # trace via all_messages() after the run (post-hoc attach).
        return Agent(
            f"{pa_provider}:{model}",
            system_prompt=system_prompt or "",
            tools=tools,
            toolsets=[comp_toolset] if comp_toolset is not None else [],
            model_settings=ModelSettings(**settings),
        )

    agent = _build()
    emitted = {"chunks": 0}

    def _harvest(res) -> tuple:
        """(trace, usage) off a run result — both streamed and plain results
        expose ``all_messages()`` / ``usage()`` once the run has finished. An
        interrupted stream may not; degrade to an empty trace."""
        try:
            trace = _pai_trace(res.all_messages())
        except Exception:  # noqa: BLE001
            trace = []
        try:
            usage = _pai_usage(res.usage())
        except Exception:  # noqa: BLE001
            usage = {}
        return trace, usage

    async def _once() -> tuple:
        # Enter the agent (opens the in-memory MCP toolset session) only when
        # composition tools are attached; text/file/python-only turns run as
        # before. nullcontext doubles as an async CM, so the shape is uniform.
        from contextlib import nullcontext
        ctx = agent if comp_toolset is not None else nullcontext()
        async with ctx:
            if stream:
                acc = ""
                async with agent.run_stream(prompt) as s:
                    async for chunk in s.stream_text(delta=True):
                        if should_stop and should_stop():
                            break
                        acc += chunk
                        emitted["chunks"] += 1
                        emit({"type": "text_delta", "text": chunk})
                    trace, usage = _harvest(s)
                if not trace:
                    trace = [_trace_event("user", text=prompt), _trace_event("text", text=acc)]
                return acc, trace, usage
            res = await agent.run(prompt)
            trace, usage = _harvest(res)
            return _pai_result_text(res), trace, usage

    try:
        return await _once()
    except Exception as exc:
        # Retry once on an auth failure — but only while the turn is still
        # clean: once deltas have streamed (or tools may have run), a full
        # re-run would duplicate the emitted text in the caller's accumulation
        # and re-execute side effects.
        if not looks_like_auth_error(exc) or emitted["chunks"]:
            raise
        await gen.api_key(
            p, force=True,
            description=f"Previous {p} key was rejected. Enter a fresh API key.",
        )
        agent = _build()
        return await _once()


def _pai_result_text(res) -> str:
    """The reply text off a pydantic-ai run result. The Agent is built without
    an output_type, so ``output`` is always a plain string."""
    v = res.output
    return v if isinstance(v, str) else ("" if v is None else str(v))


# ──────────────────────────────────────────────────────────────────────
# claude-agent-sdk backend (Python SDK driving the `claude` CLI)
# ──────────────────────────────────────────────────────────────────────


async def _run_claude_agent_sdk(
    *, auth, model, system_prompt, prompt, max_tokens=0,
    enable_file_tools, enable_python_tool, comp_flags,
    enable_read_tools=True, stream, thinking="auto", emit, should_stop=None,
) -> tuple:
    from collimate.llm import looks_like_auth_error

    api_billing = (auth or "api_key").strip().lower() != "claude_code"

    env = dict(os.environ)
    if not api_billing:
        # Force subscription (non-API) billing: the `claude` CLI must NOT see an
        # API key, so it falls back to the logged-in ~/.claude OAuth creds. The
        # claude-agent-sdk transport spawns the CLI with env
        # ``{**os.environ, **options.env}``, so merely OMITTING the key from the
        # ``env`` copy does NOT delete an inherited value — we must scrub the
        # real environment of THIS process too. Safe: the agent runs in its own
        # isolated sub-run, never the host or another generator.
        for _k in ("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN"):
            os.environ.pop(_k, None)
            env.pop(_k, None)
    else:
        key = await gen.api_key("anthropic", description="Anthropic API key for the agent")
        if key:
            env["ANTHROPIC_API_KEY"] = key
    if max_tokens:
        # The claude CLI has no max-tokens flag; it reads this env var.
        env["CLAUDE_CODE_MAX_OUTPUT_TOKENS"] = str(max_tokens)

    allowed: list[str] = []
    if enable_file_tools:
        allowed += ["Read", "Write", "Edit"]
    if enable_python_tool:
        allowed += ["Bash"]
    # The engine runs with permission_mode="bypassPermissions" (headless — no
    # one is there to answer prompts), which makes ``allowed_tools`` purely a
    # prompt-skipping allowlist. The tool TOGGLES therefore have to be enforced
    # as hard blocks: everything a disabled toggle covers goes in
    # ``disallowed_tools`` so a text-only agent config really is text-only,
    # matching the pydantic-ai backend. Read-only inspection (Read/Glob/Grep)
    # stays available — it's the workspace the caller handed the agent.
    disallowed: list[str] = []
    if not enable_file_tools:
        disallowed += ["Write", "Edit", "MultiEdit", "NotebookEdit"]
    if not enable_python_tool:
        disallowed += ["Bash"]
    if not enable_read_tools:
        # A BLIND turn (the ledger's extraction passes): it judges only its
        # inlined corpora, and it runs in the CALLER's workspace — block the
        # read surface that enable_file_tools=False deliberately leaves open.
        disallowed += ["Read", "Glob", "Grep", "WebFetch", "WebSearch"]

    # Composition tools ride an in-process SDK MCP server (the claude backend
    # has no native equivalent of these).
    mcp_server, mcp_names = _composition_mcp_server(comp_flags)
    allowed += mcp_names

    def _build_opts():
        from claude_agent_sdk import ClaudeAgentOptions
        kwargs: dict = dict(
            cwd=gen.workspace_path(),
            permission_mode="bypassPermissions",
            env=env,
            setting_sources=[],                 # hermetic: ignore host settings/CLAUDE.md
            include_partial_messages=bool(stream),
        )
        if model:
            kwargs["model"] = model
        if system_prompt:
            kwargs["system_prompt"] = system_prompt
        if allowed:
            kwargs["allowed_tools"] = allowed
        if disallowed:
            kwargs["disallowed_tools"] = disallowed
        if mcp_server is not None:
            kwargs["mcp_servers"] = {_MCP_SERVER_NAME: mcp_server}
        if thinking == "on":
            # Adaptive thinking with VISIBLE (summarized) text — Opus 4.7+
            # defaults display to "omitted", so it must be explicit.
            kwargs["thinking"] = {"type": "adaptive", "display": "summarized"}
        elif thinking == "off":
            kwargs["thinking"] = {"type": "disabled"}
        return ClaudeAgentOptions(**kwargs)

    # Track whether anything already streamed out — an auth retry after that
    # point would duplicate the emitted text in the caller's accumulation.
    emitted = {"any": False}
    _raw_emit = emit

    def _tracked_emit(ev: dict) -> None:
        emitted["any"] = True
        _raw_emit(ev)

    emit = _tracked_emit

    async def _once() -> tuple:
        from claude_agent_sdk import (
            query, AssistantMessage, TextBlock, ThinkingBlock, ToolUseBlock,
            ToolResultBlock, UserMessage, ResultMessage, StreamEvent,
        )
        parts: list[str] = []
        streamed: list[str] = []
        trace: list = [_trace_event("user", text=prompt)]
        usage: dict = {}
        final = ""
        stream_gen = query(prompt=prompt, options=_build_opts())
        async for msg in stream_gen:
            if should_stop and should_stop():
                # Live-chat interrupt: stop consuming the model stream and close
                # the underlying CLI subprocess promptly rather than draining to
                # the end.
                aclose = getattr(stream_gen, "aclose", None)
                if aclose is not None:
                    try:
                        await aclose()
                    except Exception:  # noqa: BLE001
                        pass
                break
            if stream and isinstance(msg, StreamEvent):
                kind, d = _claude_stream_delta(msg)
                if kind == "text" and d:
                    streamed.append(d)
                    emit({"type": "text_delta", "text": d})
                elif kind == "thinking" and d:
                    # NOT appended to ``streamed`` — the reply-text fallback
                    # below must stay text-only.
                    emit({"type": "thinking_delta", "text": d})
                continue
            if isinstance(msg, AssistantMessage):
                for block in msg.content:
                    if isinstance(block, TextBlock) and block.text:
                        parts.append(block.text)
                        trace.append(_trace_event("text", text=block.text))
                        if not stream:
                            # No partial messages in non-streaming mode — emit
                            # each completed text block once so a long run
                            # still shows output (and life) as it lands.
                            emit({"type": "text_delta", "text": block.text})
                    elif isinstance(block, ThinkingBlock):
                        trace.append(_trace_event("thinking", text=getattr(block, "thinking", "")))
                    elif isinstance(block, ToolUseBlock):
                        trace.append(_trace_event(
                            "tool_use", tool=block.name, input=block.input,
                        ))
                        # Progress signal regardless of ``stream`` — tool-heavy
                        # turns otherwise look hung from the outside.
                        emit({"type": "tool", "name": block.name, "status": "running"})
            elif isinstance(msg, UserMessage):
                # Tool results ride back as user-role messages.
                content = msg.content if isinstance(msg.content, list) else []
                for block in content:
                    if isinstance(block, ToolResultBlock):
                        trace.append(_trace_event(
                            "tool_result", output=_claude_result_text(block.content),
                        ))
            elif isinstance(msg, ResultMessage):
                # A turn-level failure (auth, rate limit, overload, max-turns)
                # must surface — otherwise it would be swallowed into an empty
                # reply.
                if getattr(msg, "is_error", False):
                    detail = (
                        getattr(msg, "result", None)
                        or getattr(msg, "api_error_status", None)
                        or getattr(msg, "subtype", None)
                        or "claude-agent-sdk run failed"
                    )
                    raise RuntimeError(f"claude-agent-sdk error: {detail}")
                u = getattr(msg, "usage", None)
                if isinstance(u, dict):
                    usage.update({k: v for k, v in u.items() if isinstance(v, (int, float))})
                cost = getattr(msg, "total_cost_usd", None)
                if isinstance(cost, (int, float)):
                    usage["total_cost_usd"] = cost
                r = getattr(msg, "result", None)
                if isinstance(r, str) and r.strip():
                    final = r
        # On interrupt neither `final` nor complete AssistantMessage blocks
        # exist yet — the partial deltas ARE the reply (run_agent's contract:
        # "returns the text accumulated so far").
        text = final or "".join(parts) or "".join(streamed)
        if len(trace) == 1 and text:
            trace.append(_trace_event("text", text=text))
        # Safety net: if streaming was requested but no partial deltas were
        # extracted (the unpinned SDK/bundled CLI can drift its stream-event
        # schema under us), emit the whole reply once so the parent still
        # streams something.
        if stream and not streamed and text:
            emit({"type": "text_delta", "text": text})
        return text, trace, usage

    try:
        return await _once()
    except Exception as exc:
        # A graceful stop's SIGTERM reaches the whole process group, so the
        # CLI child can die (exit 143) and its error surface here before any
        # gen.* checkpoint raises Cancelled. Once the run's cancel flag is
        # set, this exception IS the stop — reclassify it so the run reports
        # "stopped by user", not a generator failure.
        if isinstance(exc, gen.Cancelled):
            raise
        if gen.cancelled:
            raise gen.Cancelled("stopped during claude-agent-sdk turn") from exc
        # One auth-retry, mirroring the pydantic-ai backend: only on API-key
        # billing (a subscription auth failure needs `claude login`, not a
        # key), only for auth-shaped failures, and only while the turn is
        # still clean — once anything streamed (or tools may have run), a
        # re-run would duplicate output and side effects.
        if not api_billing or not looks_like_auth_error(exc) or emitted["any"]:
            raise
        key = await gen.api_key(
            "anthropic", force=True,
            description="Previous Anthropic key was rejected. Enter a fresh API key.",
        )
        if key:
            env["ANTHROPIC_API_KEY"] = key
        return await _once()


def _claude_result_text(content) -> str:
    """Flatten a ToolResultBlock's content (str, or a list of content-block
    dicts) to plain text for the trace."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        out: list[str] = []
        for item in content:
            if isinstance(item, dict) and isinstance(item.get("text"), str):
                out.append(item["text"])
            elif isinstance(item, str):
                out.append(item)
        return "\n".join(out)
    return "" if content is None else str(content)


def _claude_stream_delta(msg) -> tuple:
    """``(kind, text)`` from a raw StreamEvent: ``("text", ...)`` for reply
    deltas, ``("thinking", ...)`` for extended-thinking deltas, ``(None, "")``
    for everything else."""
    ev = getattr(msg, "event", None)
    if not isinstance(ev, dict):
        return None, ""
    if ev.get("type") == "content_block_delta":
        delta = ev.get("delta") or {}
        if isinstance(delta, dict):
            if delta.get("type") == "text_delta":
                return "text", delta.get("text") or ""
            if delta.get("type") == "thinking_delta":
                return "thinking", delta.get("thinking") or ""
    return None, ""


# ──────────────────────────────────────────────────────────────────────
# gemini backend (the Gemini CLI agent, headless)
# ──────────────────────────────────────────────────────────────────────


def _safe_log(msg: str) -> None:
    """``gen.log`` that never raises — ``gen.log`` needs a host and throws in
    dev/no-host, which must not turn best-effort wiring into a hard failure."""
    try:
        gen.log(msg)
    except Exception:  # noqa: BLE001
        pass


# Every OUT-OF-PROCESS-tools backend (the gemini CLI subprocess AND the
# in-process ADK / openai-agents / MAF MCP clients, which can't mount an
# in-memory FastMCP) reaches the composition tools over a localhost MCP bridge.
# Bridges are created ONCE per (flags, transport) and cached for the process, so
# a multi-turn chat reuses one server instead of leaking a daemon thread + port
# per turn. transport: "sse" (gemini CLI) or "streamable-http" (the modern
# transport ADK/openai-agents/MAF speak natively).
_LOCAL_BRIDGES: dict = {}


def _localhost_bridge(*, comp_flags, transport):
    """A cached localhost :class:`McpBridge` serving the gated composition tools,
    or ``None`` (no composition tools, or the mcp package / bridge is
    unavailable). ``comp_flags`` is the seven-boolean composition dict. Never
    raises — a missing bridge just means the turn runs without composition
    tools."""
    cf = comp_flags or {}
    if not any(cf.values()):
        return None
    key = (tuple(bool(cf.get(k)) for k in _COMP_FLAG_NAMES), transport)
    if key in _LOCAL_BRIDGES:
        return _LOCAL_BRIDGES[key]
    import asyncio
    from .mcp_bridge import start_bridge
    bridge = None
    try:
        bridge = start_bridge(
            comp_flags=cf,
            loop=asyncio.get_running_loop(),
            bind_host="127.0.0.1", transport=transport,
        )
    except Exception as e:  # noqa: BLE001 — never break a plain text turn
        _safe_log(f"MCP bridge unavailable ({e}) — composition tools off this turn")
        bridge = None
    _LOCAL_BRIDGES[key] = bridge   # hold the bridge so its daemon thread stays alive
    return bridge


_GEMINI_SETTINGS: dict = {}


def _gemini_mcp(comp_flags: dict):
    """``(settings_path, tool_count)`` for the gemini CLI: a throwaway
    SYSTEM-settings JSON (highest precedence — no ~/.gemini clobber, no workspace
    pollution) pointing the CLI at the localhost SSE bridge and ``trust``ing it
    (the documented headless auto-approve), with only our server allowed.
    ``comp_flags`` is the seven-boolean composition dict. ``(None, 0)`` when
    composition is off or the bridge is unavailable."""
    cf = comp_flags or {}
    key = tuple(bool(cf.get(k)) for k in _COMP_FLAG_NAMES)
    if key in _GEMINI_SETTINGS:
        return _GEMINI_SETTINGS[key]
    path = None
    bridge = _localhost_bridge(comp_flags=cf, transport="sse")
    if bridge is not None:
        try:
            import json
            import os
            import tempfile
            fd, path = tempfile.mkstemp(prefix="collimate-gemini-", suffix=".json")
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump({
                    "mcpServers": {"collimate": {"url": bridge.url_host, "trust": True}},
                    "mcp": {"allowed": ["collimate"]},
                }, f)
            _safe_log(f"gemini: composition tools via MCP bridge ({len(bridge.tool_names)} tools)")
        except Exception as e:  # noqa: BLE001
            _safe_log(f"gemini: could not write MCP settings ({e}) — built-in tools only")
            path = None
    result = (path, len(bridge.tool_names) if bridge else 0)
    _GEMINI_SETTINGS[key] = result
    return result


async def _run_gemini(
    *, auth, model, system_prompt, prompt,
    enable_file_tools=False, enable_python_tool=False, comp_flags=None,
    stream, emit, should_stop=None,
) -> tuple:
    import asyncio
    import os
    import time

    # auth=google_oauth → set no key so the gemini CLI uses its logged-in Google
    # account creds (~/.gemini); auth=api_key → fetch/inject a Gemini API key
    # (a dismissed key modal still falls through to whatever creds the CLI has).
    if (auth or "api_key").strip().lower() != "google_oauth":
        try:
            await gen.api_key("gemini", description="Gemini API key for the agent")
        except Exception:
            pass
    # Gemini CLI has no system-prompt flag; fold it into the prompt.
    full = prompt if not system_prompt else f"{system_prompt}\n\n---\n\n{prompt}"
    # Honour the tool toggles: the CLI's built-in tool suite (shell, file
    # writes, web) is auto-approved ONLY when the matching toggles are on.
    # Headless runs auto-decline whatever the approval mode doesn't cover, so
    # a text-only config (both toggles off) really is text-only — matching the
    # other backends instead of silently granting yolo to everything.
    if enable_python_tool:
        approval = "yolo"                # shell + edits + web
    elif enable_file_tools:
        approval = "auto_edit"           # file edits only
    else:
        approval = "default"             # tool calls are declined headless
    cmd = ["gemini", "-o", "json", "--approval-mode", approval, "-p", full]
    if model:
        cmd[1:1] = ["-m", model]

    # Composition tools reach the CLI over MCP: a throwaway SYSTEM-settings file
    # (pointed at by GEMINI_CLI_SYSTEM_SETTINGS_PATH) wires it to the localhost
    # bridge and trusts it, so its tools auto-approve regardless of the built-in
    # approval mode above. Best-effort — a missing bridge leaves the CLI with
    # only its built-in tools. env is a copy of the current environment (which
    # already carries any GEMINI_API_KEY the auth block injected).
    env = dict(os.environ)
    cf = comp_flags or {}
    if any(cf.values()):
        settings_path, _n = _gemini_mcp(cf)
        if settings_path:
            env["GEMINI_CLI_SYSTEM_SETTINGS_PATH"] = settings_path

    # Run the CLI directly (not gen.run_subprocess) so a live-chat interrupt
    # (`should_stop`) can kill it mid-turn — the CLI has no streaming output,
    # so the only meaningful interrupt is ending the process.
    proc = await asyncio.create_subprocess_exec(
        *cmd, cwd=gen.workspace_path(), env=env,
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
    )
    reader = asyncio.ensure_future(proc.communicate())
    deadline = time.monotonic() + 600
    interrupted = False
    try:
        while True:
            done, _pending = await asyncio.wait({reader}, timeout=0.5)
            if done:
                break
            if (should_stop and should_stop()) or gen.cancelled or time.monotonic() > deadline:
                interrupted = True
                try:
                    proc.kill()
                except ProcessLookupError:
                    pass
                await asyncio.wait({reader}, timeout=5)
                break
    except BaseException:
        # A CancelledError landing in the poll wait (loop teardown) would
        # otherwise unwind without ever reaching the kill above and orphan
        # the CLI process for the rest of the run.
        if proc.returncode is None:
            try:
                proc.kill()
            except ProcessLookupError:
                pass
        reader.cancel()
        raise
    if interrupted:
        # Nothing streamed — an interrupted gemini turn has no partial.
        return "", [], {}
    stdout, _ = reader.result() if reader.done() else (b"", b"")
    out = (stdout or b"").decode("utf-8", errors="replace")
    rc = proc.returncode

    text, error_detail = _extract_gemini_text(out)
    if rc != 0 or (error_detail and not text):
        raise RuntimeError(
            f"gemini exited {rc}: {(error_detail or text or out or '')[:500]}"
        )
    if stream and text:
        emit({"type": "text_delta", "text": text})
    # The CLI's -o json blob is the entire record — no thinking/tool structure
    # is exposed. Trace = the prompt + reply; usage from the stats envelope
    # when present. The lowest-fidelity backend, by design.
    trace = [_trace_event("user", text=prompt), _trace_event("text", text=text)]
    usage: dict = {}
    data = _parse_json(out)
    if isinstance(data, dict) and isinstance(data.get("stats"), dict):
        usage = {k: v for k, v in data["stats"].items() if isinstance(v, (int, float))}
    return text, trace, usage


def _extract_gemini_text(out: str) -> tuple:
    """``(text, error_detail)`` from the CLI's stdout. The CLI can prepend
    diagnostic lines ("Loaded cached credentials.") even with -o json, so a
    JSON object embedded in surrounding noise is tolerated. An error envelope
    (``{"error": ...}`` with no response text) comes back as ``("", detail)``
    so the caller can raise instead of presenting the blob as the reply."""
    s = (out or "").strip()
    if not s:
        return "", ""
    data = _parse_json(s)
    if isinstance(data, dict):
        for k in ("response", "text", "output", "content", "result"):
            v = data.get(k)
            if isinstance(v, str) and v.strip():
                return v, ""
        resp = data.get("response")
        if isinstance(resp, dict):
            for k in ("text", "content", "output"):
                v = resp.get(k)
                if isinstance(v, str) and v.strip():
                    return v, ""
        err = data.get("error")
        if err is not None:
            detail = err.get("message") if isinstance(err, dict) else None
            return "", str(detail or json.dumps(err)[:300] or "gemini error")
        return "", ""
    if isinstance(data, str) and data.strip():
        return data, ""
    return s, ""


# ──────────────────────────────────────────────────────────────────────
# External-MCP-client backends: Google ADK / OpenAI Agents SDK / MAF.
#
# All three are in-process python but consume tools ONLY over an external MCP
# transport (no in-memory FastMCP mount), so composition tools reach them over
# the streamable-http bridge (the modern transport all three speak natively),
# exactly like the gemini CLI reaches the SSE bridge. Model routing is
# provider-driven (like pydantic-ai). Each adds a distinct paradigm: ADK =
# deterministic workflow agents; openai-agents = handoffs + guardrails; MAF =
# teams. Structured output is handled upstream (run_agent appends the JSON
# instruction and parses the returned text), and streaming turns emit
# text_delta / tool events like the other backends.
#
# NOTE (unverified): these follow the documented current APIs but could not be
# exercised against a live run here (no keys / packages). Deps are lazy-imported,
# so a missing package fails ONLY that backend, informatively. File/python
# workspace tools are not yet wired for these backends — a documented follow-up.
# MAF is the most experimental (two coexisting API generations, newest project).
# ──────────────────────────────────────────────────────────────────────


async def _external_backend_prep(
    provider, *, enable_run_generators, enable_cross_cell, enable_create_cell,
):
    """Shared setup for the external-MCP-client backends: fetch the provider's
    API key and stand up the streamable-http composition bridge. Returns
    ``(api_key, mcp_url_or_None)`` — ``mcp_url`` is ``None`` when composition is
    off or the bridge is unavailable (the turn then runs tool-free)."""
    key = await gen.api_key(provider)
    bridge = _localhost_bridge(
        enable_run_generators=enable_run_generators,
        enable_cross_cell=enable_cross_cell,
        enable_create_cell=enable_create_cell,
        transport="streamable-http",
    )
    return key, (bridge.url_host if bridge is not None else None)


async def _run_google_adk(
    *, provider, model, max_tokens, system_prompt, prompt,
    enable_run_generators, enable_cross_cell, enable_create_cell,
    stream, emit, should_stop=None,
) -> tuple:
    """Google ADK backend. Gemini is native; every other provider runs through
    ADK's LiteLLM shim (``LiteLlm(model="anthropic/<model>", api_key=...)``)."""
    from google.adk.agents import LlmAgent
    from google.adk.runners import Runner
    from google.adk.sessions import InMemorySessionService
    from google.adk.agents.run_config import RunConfig, StreamingMode
    from google.genai import types

    key, mcp_url = await _external_backend_prep(
        provider, enable_run_generators=enable_run_generators,
        enable_cross_cell=enable_cross_cell, enable_create_cell=enable_create_cell)

    p = (provider or "anthropic").strip().lower()
    if p == "gemini":
        from google.adk.models import Gemini
        adk_model = Gemini(model=model, client_kwargs={"api_key": key}) if key else model
    else:
        from google.adk.models.lite_llm import LiteLlm
        route = _litellm_route(p, model)
        adk_model = LiteLlm(model=route, api_key=key, max_tokens=max_tokens)

    tools: list = []
    mcp_toolset = None
    if mcp_url:
        from google.adk.tools.mcp_tool.mcp_toolset import McpToolset
        from google.adk.tools.mcp_tool.mcp_session_manager import (
            StreamableHTTPConnectionParams,
        )
        mcp_toolset = McpToolset(
            connection_params=StreamableHTTPConnectionParams(url=mcp_url),
        )
        tools.append(mcp_toolset)

    agent = LlmAgent(
        name="collimate_agent", model=adk_model,
        instruction=system_prompt or "", tools=tools,
    )
    session_service = InMemorySessionService()
    runner = Runner(app_name="collimate", agent=agent, session_service=session_service)
    await session_service.create_session(app_name="collimate", user_id="u", session_id="s")

    trace: list = [_trace_event("user", text=prompt)]
    usage: dict = {}
    final_text = ""
    try:
        async for event in runner.run_async(
            user_id="u", session_id="s",
            new_message=types.Content(role="user", parts=[types.Part(text=prompt)]),
            run_config=RunConfig(streaming_mode=StreamingMode.SSE, max_llm_calls=50),
        ):
            if should_stop and should_stop():
                break
            content = getattr(event, "content", None)
            partial = getattr(event, "partial", False)
            for part in (getattr(content, "parts", None) or []) if content else []:
                txt = getattr(part, "text", None)
                if not txt:
                    continue
                if getattr(part, "thought", False):
                    trace.append(_trace_event("thinking", text=txt))
                    if stream:
                        emit({"type": "thinking_delta", "text": txt})
                elif partial and stream:
                    emit({"type": "text_delta", "text": txt})
            for fc in (event.get_function_calls() or []):
                trace.append(_trace_event("tool_use", tool=fc.name, input=getattr(fc, "args", None)))
                emit({"type": "tool", "name": fc.name, "status": "running"})
            for fr in (event.get_function_responses() or []):
                trace.append(_trace_event(
                    "tool_result", tool=getattr(fr, "name", ""),
                    output=str(getattr(fr, "response", "")),
                ))
            um = getattr(event, "usage_metadata", None)
            if um is not None:
                usage = {
                    "input_tokens": getattr(um, "prompt_token_count", None),
                    "output_tokens": getattr(um, "candidates_token_count", None),
                    "total_tokens": getattr(um, "total_token_count", None),
                }
            if getattr(event, "error_code", None):
                raise RuntimeError(f"{event.error_code}: {getattr(event, 'error_message', '')}")
            if event.is_final_response() and content:
                final_text = "".join(
                    pt.text for pt in (getattr(content, "parts", None) or [])
                    if getattr(pt, "text", None) and not getattr(pt, "thought", False)
                ) or final_text
    finally:
        if mcp_toolset is not None:
            try:
                await mcp_toolset.close()
            except Exception:  # noqa: BLE001
                pass
    if final_text:
        trace.append(_trace_event("text", text=final_text))
    return final_text, trace, usage


async def _run_openai_agents(
    *, provider, model, max_tokens, system_prompt, prompt,
    enable_run_generators, enable_cross_cell, enable_create_cell,
    stream, emit, should_stop=None,
) -> tuple:
    """OpenAI Agents SDK backend. OpenAI is native; every other provider runs via
    the LiteLLM shim (needs the ``openai-agents[litellm]`` extra)."""
    from agents import Agent, Runner, ItemHelpers
    from agents.model_settings import ModelSettings
    from openai.types.responses import ResponseTextDeltaEvent

    key, mcp_url = await _external_backend_prep(
        provider, enable_run_generators=enable_run_generators,
        enable_cross_cell=enable_cross_cell, enable_create_cell=enable_create_cell)

    p = (provider or "anthropic").strip().lower()
    if p == "openai":
        from agents import AsyncOpenAI, OpenAIChatCompletionsModel
        oa_model = OpenAIChatCompletionsModel(model=model, openai_client=AsyncOpenAI(api_key=key))
    else:
        from agents.extensions.models.litellm_model import LitellmModel
        route = _litellm_route(p, model)
        oa_model = LitellmModel(model=route, api_key=key)

    mcp_servers: list = []
    mcp_server = None
    if mcp_url:
        from agents.mcp import MCPServerStreamableHttp
        mcp_server = MCPServerStreamableHttp(name="collimate", params={"url": mcp_url})
        await mcp_server.connect()
        mcp_servers.append(mcp_server)

    agent = Agent(
        name="collimate_agent", instructions=system_prompt or "",
        model=oa_model, mcp_servers=mcp_servers,
        model_settings=ModelSettings(include_usage=True),
    )

    trace: list = [_trace_event("user", text=prompt)]
    usage: dict = {}
    result = Runner.run_streamed(agent, input=prompt, max_turns=20)
    try:
        async for event in result.stream_events():
            if should_stop and should_stop():
                result.cancel()
                break
            et = getattr(event, "type", "")
            if et == "raw_response_event":
                data = getattr(event, "data", None)
                if isinstance(data, ResponseTextDeltaEvent) and getattr(data, "delta", None):
                    if stream:
                        emit({"type": "text_delta", "text": data.delta})
            elif et == "run_item_stream_event":
                item = getattr(event, "item", None)
                it = getattr(item, "type", "")
                if it == "tool_call_item":
                    raw = getattr(item, "raw_item", None)
                    name = getattr(raw, "name", "tool")
                    trace.append(_trace_event("tool_use", tool=name, input=getattr(raw, "arguments", None)))
                    emit({"type": "tool", "name": name, "status": "running"})
                elif it == "tool_call_output_item":
                    trace.append(_trace_event("tool_result", output=str(getattr(item, "output", ""))))
                elif it == "reasoning_item":
                    trace.append(_trace_event("thinking", text=str(getattr(item, "raw_item", ""))))
                elif it == "message_output_item":
                    txt = ItemHelpers.text_message_output(item)
                    if txt:
                        trace.append(_trace_event("text", text=txt))
    finally:
        if mcp_server is not None:
            try:
                await mcp_server.cleanup()
            except Exception:  # noqa: BLE001
                pass
    final_text = getattr(result, "final_output", None) or ""
    try:
        u = result.context_wrapper.usage
        usage = {
            "requests": u.requests, "input_tokens": u.input_tokens,
            "output_tokens": u.output_tokens, "total_tokens": u.total_tokens,
        }
    except Exception:  # noqa: BLE001
        pass
    return str(final_text), trace, usage


async def _run_maf(
    *, provider, model, max_tokens, system_prompt, prompt,
    enable_run_generators, enable_cross_cell, enable_create_cell,
    stream, emit, should_stop=None,
) -> tuple:
    """Microsoft Agent Framework (MAF) backend — the AutoGen/Semantic-Kernel
    successor. EXPERIMENTAL: two API generations coexist (``Agent`` +
    ``run(stream=True)`` vs ``ChatAgent`` + ``run_stream``), so the entry points
    are probed. Native Anthropic client; gemini/groq/cerebras/openrouter via an
    OpenAI-compatible ``base_url``. MCP over streamable-http (MAF's only http
    transport)."""
    from contextlib import AsyncExitStack

    import agent_framework as af

    key, mcp_url = await _external_backend_prep(
        provider, enable_run_generators=enable_run_generators,
        enable_cross_cell=enable_cross_cell, enable_create_cell=enable_create_cell)

    p = (provider or "anthropic").strip().lower()
    if p == "anthropic":
        from agent_framework.anthropic import AnthropicClient
        client = AnthropicClient(model=model, api_key=key)
    elif p == "openai":
        from agent_framework.openai import OpenAIChatClient
        client = OpenAIChatClient(model=model, api_key=key)
    else:
        from agent_framework.openai import OpenAIChatCompletionClient
        base = {
            "gemini": "https://generativelanguage.googleapis.com/v1beta/openai/",
            "groq": "https://api.groq.com/openai/v1",
            "cerebras": "https://api.cerebras.ai/v1",
            "openrouter": "https://openrouter.ai/api/v1",
        }.get(p)
        client = OpenAIChatCompletionClient(model=model, api_key=key, base_url=base)

    AgentCls = getattr(af, "Agent", None) or getattr(af, "ChatAgent", None)
    if AgentCls is None:
        raise RuntimeError("agent_framework: no Agent/ChatAgent class found")

    trace: list = [_trace_event("user", text=prompt)]
    usage: dict = {}
    parts: list = []
    async with AsyncExitStack() as stack:
        tools: list = []
        McpTool = getattr(af, "MCPStreamableHTTPTool", None)
        if mcp_url and McpTool is not None:
            tools.append(await stack.enter_async_context(McpTool(name="collimate", url=mcp_url)))
        try:
            agent = AgentCls(client=client, instructions=system_prompt or "", tools=tools)
        except TypeError:
            agent = AgentCls(chat_client=client, instructions=system_prompt or "", tools=tools)

        try:
            stream_obj = agent.run(prompt, stream=True)   # newer API
        except TypeError:
            stream_obj = agent.run_stream(prompt)         # older API

        async for update in stream_obj:
            if should_stop and should_stop():
                break
            txt = getattr(update, "text", None)
            if txt:
                parts.append(txt)
                if stream:
                    emit({"type": "text_delta", "text": txt})
            for c in (getattr(update, "contents", None) or []):
                ct = getattr(c, "type", None)
                if ct == "function_call":
                    trace.append(_trace_event("tool_use", tool=getattr(c, "name", ""), input=getattr(c, "arguments", None)))
                elif ct == "function_result":
                    trace.append(_trace_event("tool_result", output=str(getattr(c, "result", ""))))
                elif ct == "text_reasoning":
                    trace.append(_trace_event("thinking", text=getattr(c, "text", "")))
                elif ct == "usage":
                    d = getattr(c, "details", None)
                    if d is not None:
                        usage = {
                            "input_tokens": getattr(d, "input_tokens", None),
                            "output_tokens": getattr(d, "output_tokens", None),
                            "total_tokens": getattr(d, "total_tokens", None),
                        }
    text = "".join(parts)
    if text:
        trace.append(_trace_event("text", text=text))
    return text, trace, usage


# ──────────────────────────────────────────────────────────────────────
# Structured output: JSON-only instruction + tolerant parse
# ──────────────────────────────────────────────────────────────────────


def _json_instruction(schema: dict) -> str:
    return (
        "\n\nRespond with ONLY a single JSON value conforming to this JSON "
        "Schema. No prose, no explanation, no markdown code fences:\n"
        + json.dumps(schema, indent=2)
    )


def _parse_json(text: str):
    if not text:
        return None
    s = text.strip()
    if s.startswith("```"):
        s = re.sub(r"^```[A-Za-z0-9_-]*\n", "", s)
        s = re.sub(r"\n```\s*$", "", s).strip()
    try:
        return json.loads(s)
    except Exception:
        pass
    # Fall back to the first parseable {...} or [...] embedded in the text.
    # raw_decode from each opener position (rather than first-{-to-last-})
    # tolerates braces in surrounding prose on either side of the JSON.
    dec = json.JSONDecoder()
    for opener in ("{", "["):
        i = s.find(opener)
        attempts = 0
        while i != -1 and attempts < 20:
            try:
                v, _end = dec.raw_decode(s[i:])
                return v
            except Exception:
                attempts += 1
                i = s.find(opener, i + 1)
    return None


__all__ = [
    "AgentResult",
    "run_agent",
    "parse_agent_config",
    "exposure_flags",
    "oneshot_tag_values",
    "gather_agent_calls",
    "default_model",
    "resolve_model",
    "resolve_ledger_model",
    "model_family",
    "full_claude_model_id",
    "is_claude_model",
    "to_int",
    "to_bool",
    "as_schema",
]
