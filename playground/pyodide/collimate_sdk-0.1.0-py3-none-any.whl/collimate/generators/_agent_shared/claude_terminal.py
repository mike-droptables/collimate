# SPDX-License-Identifier: Apache-2.0
"""Claude-terminal mode — a live ``claude`` TTY in a container.

Surfaced through the ``.terminal`` renderer (replacement for the old standalone
``claude_cli`` generator). Requires a Claude model. The CLI works directly on
the cell's own workspace (bind-mounted rw at ``/workspace``), with
``gen.live_files()`` keeping the Files tab in live bidirectional sync — the
agent's file writes appear in the cell as they happen, and the user's edits
reach the agent's working tree mid-session. A ``Capture Chat`` button
snapshots the session into a new cell, and on teardown the CLI transcript is
serialised into the open-format transcript ``chats/main.json`` (collimate.transcript).

When the caller turns on the tool toggles, an MCP bridge (see
:mod:`mcp_bridge`) is started in the generator process and wired into the
container's ``.mcp.json`` so the in-container ``claude`` gets the same
view/edit/run + create-cell tools as the in-process backends. An optional
``extra_system`` prompt is appended to claude's system prompt and any ``docs``
are dropped into the project so the agent can read them (used by the Guide).
"""
from __future__ import annotations

import io
import json
import os
import sys
import tarfile
import uuid
from pathlib import Path

import gen
from collimate.transcript import serialize_transcript
from collimate._host import Message

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from _agent_shared import full_claude_model_id, is_claude_model  # noqa: E402
from _agent_shared import ledger as ledger_mod  # noqa: E402
from _agent_shared.mcp_bridge import start_bridge  # noqa: E402

IMAGE_TAG = "collimate-claude-tui:latest"
_TRANSCRIPT_FILE = "chats/main.json"
_CAPTURE_MAX_FILE_BYTES = 1_000_000
# The claude project dir IS the bind-mounted cell workspace — the CLI edits
# the cell's files directly (live_files mirrors them to the Files tab), rather
# than a container-local copy that silently diverges.
_PROJECT = "/workspace"


async def run_claude_terminal(
    cfg: dict,
    *,
    extra_system: str = "",
    docs: dict | None = None,
    label: str = "Agent · Claude terminal",
) -> None:
    import asyncio

    from _env_shared import DockerEnvironment  # noqa: E402

    model = (cfg.get("model") or "sonnet").strip()
    if not is_claude_model(model):
        reason = f"claude-terminal mode needs a Claude model (got {model!r})"
        gen.log(reason)
        gen.update_file(
            "error.md",
            f"# Wrong model\n\nClaude-terminal mode runs the `claude` CLI and only "
            f"accepts Claude models (sonnet/opus/haiku/claude-*). Got `{model}`.\n",
        )
        await gen.update(name=label, summary=f"Failed: {reason}")
        return

    auth = (cfg.get("auth") or "api_key").strip().lower()
    first_message = (gen.prompt or "").strip()

    await gen.update(name=label, summary="Starting…")
    gen.phase("spinning_up", "starting container")

    bridge = start_bridge(
        enable_run_generators=bool(cfg.get("enable_run_generators")),
        enable_cross_cell=bool(cfg.get("enable_cross_cell")),
        enable_create_cell=bool(cfg.get("enable_create_cell")),
        loop=asyncio.get_running_loop(),
    )

    volumes: dict = {}
    env_vars: dict = {}
    if auth == "claude_code":
        host_claude = os.path.expanduser("~/.claude")
        if os.path.isdir(host_claude):
            # rw because the CLI must write sessions/config there (an ro mount
            # breaks session recording entirely). Trade-off: the in-container
            # agent runs with --dangerously-skip-permissions and can therefore
            # touch host-side ~/.claude state (settings hooks, credentials) —
            # subscription auth trusts the agent with your Claude login.
            volumes[host_claude] = {"bind": "/home/coder/.claude", "mode": "rw"}
            gen.log(
                "Mounting host ~/.claude into the container rw (subscription "
                "auth) — the agent shares your Claude login and settings"
            )
        else:
            gen.log(f"auth=claude_code but {host_claude} is absent — CLI starts unauthenticated")
    else:
        env_vars["ANTHROPIC_API_KEY"] = await gen.api_key(
            "anthropic", description="Anthropic API key for the Claude CLI",
        )

    env = DockerEnvironment(
        image=IMAGE_TAG,
        mount=_PROJECT, mount_mode="rw",
        build_context=str(Path(__file__).resolve().parent / "claude_terminal"),
        volumes=volumes, environment=env_vars,
        extra_hosts={"host.docker.internal": "host-gateway"} if bridge else None,
        name_prefix="collimate-claude-tui", kind="claude_terminal",
    )
    container = env.container

    # Pin a deterministic session id so the interactive TTY, the first
    # message, and the transcript export all refer to the SAME claude
    # session — no headless prime running as a separate (invisible) session,
    # and export reads exactly this session's jsonl (never another project's
    # or a stale run's newest-by-mtime file). Minted before the try so the
    # finally's transcript export always has it, whatever failed.
    session_id = str(uuid.uuid4())
    try:
        if docs:
            _write_docs(container, docs)
        if bridge:
            _write_mcp_config(container, bridge.url_container)

        command = ["claude", "--dangerously-skip-permissions", "--session-id", session_id]
        if extra_system:
            command += ["--append-system-prompt", extra_system]
        if first_message:
            # `--` ends option parsing so a prompt that happens to start with
            # a dash isn't rejected as an unknown CLI flag.
            command += ["--", first_message]   # seed the visible TTY's first turn
        term_env = {"TERM": "xterm-256color", "ANTHROPIC_MODEL": full_claude_model_id(model)}

        gen.status("Registering terminal session…")
        async with gen.serve_terminal(
            env.container_id, command, cwd=_PROJECT, env=term_env,
            label=f"Claude · {model}", pointer="claude.terminal",
            buttons=[{"id": "capture_chat", "label": "Capture Chat"}],
            name=label, summary=f"live · {model}",
        ):
            gen.phase("running", "terminal ready")
            gen.status("Terminal ready — open the cell to attach.")

            # Bidirectional cell <-> workspace sync while the TTY is live: the
            # CLI's edits to the bind-mounted /workspace surface in the Files
            # tab as they happen, and the user's Files-tab edits land in the
            # working tree the CLI reads.
            async with gen.live_files():
                async for action in gen.actions():
                    if action == "capture_chat":
                        try:
                            await _capture_chat(container, session_id, cfg)
                        except Exception as e:  # noqa: BLE001
                            gen.log(f"capture_chat failed: {e}")
                    else:
                        gen.log(f"Unknown renderer action: {action}")
    finally:
        try:
            _write_chatlog(container, session_id)
        except Exception as e:  # noqa: BLE001
            gen.log(f"chatlog export failed: {e}")
        if cfg.get("ledger"):
            try:
                await _teardown_ledger(container, session_id, cfg)
            except Exception as e:  # noqa: BLE001
                gen.log(f"[ledger] extraction failed: {e}")
        env.close()


def _write_docs(container, docs: dict) -> None:
    import shlex
    container.exec_run(["bash", "-lc", f"mkdir -p {_PROJECT}/_docs"], user="coder")
    for name, content in docs.items():
        # basename strips path tricks but not shell metacharacters — quote the
        # destination so a doc name with spaces/backticks can't corrupt (or
        # execute inside) the bash -lc string.
        safe = shlex.quote(f"{_PROJECT}/_docs/{os.path.basename(name)}")
        b64 = _b64(content)
        container.exec_run(
            ["bash", "-lc", f"echo {b64} | base64 -d > {safe}"],
            user="coder",
        )


def _write_mcp_config(container, url: str) -> None:
    cfg = json.dumps({"mcpServers": {"collimate": {"type": "sse", "url": url}}})
    b64 = _b64(cfg)
    container.exec_run(
        ["bash", "-lc", f"echo {b64} | base64 -d > {_PROJECT}/.mcp.json"], user="coder",
    )
    gen.log("Wrote .mcp.json (collimate tools) into the claude project")


def _b64(text: str) -> str:
    import base64
    import shlex
    return shlex.quote(base64.b64encode(text.encode("utf-8")).decode("ascii"))


def _write_chatlog(container, session_id: str) -> None:
    messages, _raw = _pull_claude_transcript(container, session_id)
    if not messages:
        return
    gen.update_file(
        _TRANSCRIPT_FILE,
        serialize_transcript([Message(role=m["role"], content=m["content"]) for m in messages]),
    )
    gen.log(f"Wrote {_TRANSCRIPT_FILE} ({len(messages)} messages)")


async def _capture_chat(container, session_id: str, cfg: dict) -> None:
    gen.status("Capturing chat + files…")
    messages, raw_jsonl = _pull_claude_transcript(container, session_id)
    files = _pull_project_files(container, _PROJECT)
    snapshot: dict[str, str] = {}
    for rel, text in files:
        if rel in ("claude_session.jsonl", _TRANSCRIPT_FILE):
            continue
        snapshot[rel] = text
    if cfg.get("ledger") and raw_jsonl:
        # The raw session jsonl still holds the thinking + tool blocks the
        # open-format transcript drops — extract the ledger from it while the
        # full record is in hand, so the captured cell carries its own
        # assumptions record (promoted names: this IS a new cell).
        gen.status("Extracting assumptions ledger…")
        try:
            doc = await ledger_mod.extract_ledger(
                trace=ledger_mod.trace_from_claude_session(raw_jsonl),
                artifact_files=dict(snapshot),
                cfg=cfg,
                trace_sources=["claude_session.jsonl"],
            )
            snapshot[ledger_mod.LEDGER_PROMOTED] = ledger_mod.dumps_ledger(doc)
            snapshot["assumptions.md"] = ledger_mod.ledger_to_md(doc)
        except Exception as e:  # noqa: BLE001
            gen.log(f"[ledger] capture extraction failed: {e}")
    if messages:
        snapshot[_TRANSCRIPT_FILE] = serialize_transcript(
            [Message(role=m["role"], content=m["content"]) for m in messages]
        )
    if raw_jsonl:
        snapshot["claude_session.jsonl"] = raw_jsonl
    cell_id = await gen.create_stack_cell(
        "Claude terminal capture",
        summary=f"{len(messages)} messages · {len(files)} files",
        files=snapshot,
    )
    gen.log(f"Captured Claude session into cell {cell_id}")
    gen.status("Terminal ready — open the cell to attach.")


async def _teardown_ledger(container, session_id: str, cfg: dict) -> None:
    """Ledger extraction for the primary cell as the terminal session ends —
    from the raw session jsonl (thinking + tool blocks intact) over the
    live-synced workspace files."""
    _messages, raw_jsonl = _pull_claude_transcript(container, session_id)
    if not raw_jsonl:
        return
    trace = ledger_mod.trace_from_claude_session(raw_jsonl)
    gen.update_file(ledger_mod.TRACE_FILE, json.dumps(trace, indent=2, default=str))
    artifacts = {
        p: gen.read_file(p) for p in gen.list_files()
        if not p.startswith(("_agent/", "chats/"))
    }
    doc = await ledger_mod.extract_ledger(
        trace=trace, artifact_files=artifacts, cfg=cfg,
        trace_sources=["claude_session.jsonl"],
    )
    gen.update_file(ledger_mod.LEDGER_FILE, ledger_mod.dumps_ledger(doc))
    gen.update_file(ledger_mod.LEDGER_MD_FILE, ledger_mod.ledger_to_md(doc))


def _pull_claude_transcript(container, session_id: str):
    # Read EXACTLY this run's session jsonl. claude stores sessions under a
    # project dir whose name is the cwd with '/' → '-'; with auth=claude_code the
    # host's whole ~/.claude is mounted, so scoping to (our project slug, our
    # session id) is what keeps a concurrent host session or a stale prior run
    # from being exported in place of this conversation.
    slug = _PROJECT.replace("/", "-")
    path = f"/home/coder/.claude/projects/{slug}/{session_id}.jsonl"
    cat = container.exec_run(["cat", path])
    if cat.exit_code != 0:
        return [], None
    raw = cat.output.decode("utf-8", errors="replace")
    messages: list[dict] = []
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue
        if entry.get("type") not in ("user", "assistant"):
            continue
        msg = entry.get("message") or {}
        role = msg.get("role") or entry.get("type")
        text = _extract_text(msg.get("content"))
        if not text:
            continue
        messages.append({"role": role, "content": text})
    return messages, raw


def _extract_text(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = [b.get("text") or "" for b in content
                 if isinstance(b, dict) and b.get("type") == "text"]
        return "\n".join(p for p in parts if p)
    return ""


def _pull_project_files(container, project_dir: str):
    allowed = None
    if container.exec_run(["test", "-d", os.path.join(project_dir, ".git")]).exit_code == 0:
        ls = container.exec_run(
            ["git", "-C", project_dir, "ls-files", "--cached", "--others", "--exclude-standard"]
        )
        if ls.exit_code == 0:
            raw = ls.output.decode("utf-8", errors="replace")
            allowed = {line for line in raw.splitlines() if line.strip()}
    bits, _ = container.get_archive(project_dir)
    buf = io.BytesIO()
    for chunk in bits:
        buf.write(chunk)
    buf.seek(0)
    out = []
    with tarfile.open(fileobj=buf, mode="r") as tar:
        for member in tar.getmembers():
            if not member.isfile():
                continue
            parts = member.name.split("/", 1)
            if len(parts) < 2:
                continue
            rel = parts[1]
            if rel == ".git" or rel.startswith(".git/"):
                continue
            if rel == ".colreserved" or rel.startswith(".colreserved/"):
                continue
            if allowed is not None and rel not in allowed:
                continue
            if member.size > _CAPTURE_MAX_FILE_BYTES:
                continue
            f = tar.extractfile(member)
            if f is None:
                continue
            try:
                text = f.read().decode("utf-8")
            except UnicodeDecodeError:
                continue
            out.append((rel, text))
    return out
