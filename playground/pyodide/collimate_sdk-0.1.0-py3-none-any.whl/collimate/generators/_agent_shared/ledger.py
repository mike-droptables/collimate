# SPDX-License-Identifier: Apache-2.0
"""Assumptions ledger — the agent's companion extraction pass.

Every agent run silently commits to assumptions: frame-level doctrines that
exist as one sentence of reasoning and then manifest as dozens of small,
locally-reasonable decisions diffused across the artifact. The ledger makes
them a first-class output. After (or alongside) the main work, two cheap
extraction passes mine the run at both granularities and a linker joins them:

  * **claimed**  — commitments the agent stated or reasoned from, mined from
    the full-fidelity trace (thinking blocks, tool activity, replies).
  * **enacted**  — commitments the artifacts themselves enact (structural
    choices, hard-coded values, implicit exclusions), mined from the produced
    files with no sight of the trace.
  * **linked**   — claimed+enacted pairs → ``confirmed`` (the doctrine
    demonstrably structured the output); claimed-only → ``decoration``;
    enacted-only → ``unstated_doctrine`` (acted on but never chosen — the
    most dangerous class).

The two extraction passes never see each other's corpus and never consume the
agent's own summary of itself — post-hoc self-report is confabulation-prone,
so extraction is structurally separate from generation.

Commitments are tagged by kind (``fact`` / ``preference`` / ``frame``) because
the reader's action differs per kind (verify / override / contest), and ranked
by **spread** — the number of manifestation sites — a value-neutral, computable
priority signal. Fan-out callers merge per-candidate ledgers and compute the
cross-candidate **differential**: commitments shared by all candidates are
background; commitments where candidates disagree are the live seams.

The extraction runs on its own (typically cheaper) model via a second
in-process :func:`run_agent` call — see ``ledger_*`` in ``parse_agent_config``.
Failures degrade to a ledger document carrying an ``error`` field; the
companion pass never fails the parent run.
"""
from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from typing import Literal, Optional

from pydantic import BaseModel, Field

import gen

from _agent_shared import run_agent

LEDGER_FORMAT = "collimate.assumptions-ledger"
LEDGER_VERSION = 1

# Where the agent generator writes the companion outputs — under _agent/ so
# callers that sweep "everything the run produced" (modify_files, seed_ideas)
# never leak bookkeeping into their output cells. Callers PROMOTE the ledger
# to LEDGER_PROMOTED wherever the call's output becomes a cell.
TRACE_FILE = "_agent/trace.json"
LEDGER_FILE = "_agent/assumptions.ledger"
LEDGER_MD_FILE = "_agent/assumptions.md"
LEDGER_PROMOTED = "assumptions.ledger"

_TRACE_BUDGET = 40_000
_ARTIFACT_BUDGET = 40_000
_PER_FILE_CAP = 4_000
_CONTEXT_CAP = 4_000
_MAX_COMMITMENTS = 12

_KIND_GUIDE = """Classify each commitment's kind by what the reader must do with it:
- "fact": a fact-checkable claim about the world or system ("the DB handles 5k writes/sec") -> verify
- "preference": a preference assigned on the user's behalf ("latency matters more than fairness here") -> override
- "frame": a choice about how the problem itself is framed ("treated this as a caching problem") -> contest"""


# ──────────────────────────────────────────────────────────────────────
# Structured-output models for the three LLM passes
# ──────────────────────────────────────────────────────────────────────


class Site(BaseModel):
    ref: str = Field(description="Where the commitment manifests: a file path, or a trace line marker like trace[12].")
    evidence: str = Field(description="Short quote or paraphrase showing the commitment at this site.")


class Commitment(BaseModel):
    statement: str = Field(description="The assumption/commitment, one sentence, testable phrasing.")
    kind: Literal["fact", "preference", "frame"]
    sites: list[Site] = Field(default_factory=list)


class ClaimedExtraction(BaseModel):
    commitments: list[Commitment] = Field(
        description=f"At most {_MAX_COMMITMENTS} commitments, most load-bearing first."
    )


class EnactedExtraction(BaseModel):
    commitments: list[Commitment] = Field(
        description=f"At most {_MAX_COMMITMENTS} commitments, most load-bearing first."
    )


class LinkedCommitment(BaseModel):
    statement: str = Field(description="Canonical one-sentence phrasing (keep the crisper of the two).")
    kind: Literal["fact", "preference", "frame"]
    link: Literal["confirmed", "decoration", "unstated_doctrine"]
    claimed_sites: list[Site] = Field(default_factory=list)
    enacted_sites: list[Site] = Field(default_factory=list)


class LinkedLedger(BaseModel):
    commitments: list[LinkedCommitment]


class DifferentialCluster(BaseModel):
    statement: str = Field(description="Canonical phrasing covering every member candidate's version.")
    kind: Literal["fact", "preference", "frame"]
    members: dict[str, int] = Field(
        description="candidate label -> index into that candidate's numbered commitment list."
    )
    seam_note: Optional[str] = Field(
        default=None,
        description="Set ONLY when the member candidates genuinely disagree on this territory — describe the disagreement.",
    )


class Differential(BaseModel):
    commitments: list[DifferentialCluster]


# ──────────────────────────────────────────────────────────────────────
# Corpus builders — pure, deterministic, unit-testable
# ──────────────────────────────────────────────────────────────────────


def trace_corpus(trace: list, budget: int = _TRACE_BUDGET) -> str:
    """Render normalized trace events as numbered lines the claimed pass can
    cite back (``trace[i]``). Per-event caps keep single huge tool outputs
    from starving the rest; over-budget traces keep head + tail with an
    elision marker (the opening frame and the closing decisions are where
    commitments concentrate)."""
    caps = {"thinking": 2000, "text": 2000, "user": 1200,
            "tool_use": 600, "tool_result": 800, "system_note": 400}
    lines: list[str] = []
    for i, ev in enumerate(trace or []):
        kind = ev.get("type", "")
        if kind == "tool_use":
            body = json.dumps(ev.get("input"), default=str) if ev.get("input") is not None else ""
            head = f"TOOL_USE {ev.get('tool', '')}".rstrip()
        elif kind == "tool_result":
            body = str(ev.get("output", ""))
            head = f"TOOL_RESULT {ev.get('tool', '')}".rstrip()
        else:
            body = str(ev.get("text", ""))
            head = kind.upper()
        cap = caps.get(kind, 800)
        if len(body) > cap:
            body = body[:cap] + " …[truncated]"
        lines.append(f"trace[{i}] {head}: {body}")
    corpus = "\n".join(lines)
    if len(corpus) <= budget:
        return corpus
    head = corpus[: int(budget * 0.5)]
    tail = corpus[-int(budget * 0.4):]
    return head + "\n…[trace elided to fit budget]…\n" + tail


def artifact_corpus(
    files: dict, budget: int = _ARTIFACT_BUDGET, per_file: int = _PER_FILE_CAP,
) -> str:
    """Render the run's produced files for the enacted pass. Skips agent
    bookkeeping, PRIOR ledger artifacts (mining a promoted assumptions.ledger
    would feed earlier extractions back into this one — a self-amplifying
    loop, not evidence of what THIS work enacts), and binary content;
    per-file + total caps, with omissions named rather than silent."""
    sections: list[str] = []
    used = 0
    omitted: list[str] = []
    for path in sorted(files or {}):
        base = path.rsplit("/", 1)[-1]
        if (path.startswith("_agent/") or path.endswith(".ledger")
                or base == "assumptions.md"):
            continue
        content = files[path]
        if not isinstance(content, str):
            omitted.append(f"{path} (binary)")
            continue
        if len(content) > per_file:
            content = content[:per_file] + f"\n…[truncated — full size {len(content)} chars]"
        section = f"### `{path}`\n\n```\n{content}\n```"
        if used + len(section) > budget:
            omitted.append(path)
            continue
        sections.append(section)
        used += len(section)
    if omitted:
        sections.append("(omitted for budget: " + ", ".join(omitted) + ")")
    return "\n\n".join(sections)


# ──────────────────────────────────────────────────────────────────────
# Trace normalizers for the container modes' raw session records
# ──────────────────────────────────────────────────────────────────────


def trace_from_claude_session(raw_jsonl: str) -> list:
    """Normalize a raw claude CLI session (``claude_session.jsonl``) — the
    fullest-fidelity record the claude-terminal mode has, with thinking and
    tool_use/tool_result blocks intact — into the shared trace vocabulary."""
    trace: list = []
    for line in (raw_jsonl or "").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue
        if entry.get("type") not in ("user", "assistant"):
            continue
        msg = entry.get("message") or {}
        role = msg.get("role") or entry.get("type")
        content = msg.get("content")
        if isinstance(content, str):
            if content.strip():
                trace.append({"type": "user" if role == "user" else "text", "text": content})
            continue
        for block in content if isinstance(content, list) else []:
            if not isinstance(block, dict):
                continue
            btype = block.get("type")
            if btype == "text" and block.get("text"):
                trace.append({"type": "user" if role == "user" else "text",
                              "text": block["text"]})
            elif btype == "thinking" and block.get("thinking"):
                trace.append({"type": "thinking", "text": block["thinking"]})
            elif btype == "tool_use":
                trace.append({"type": "tool_use", "tool": block.get("name", ""),
                              "input": block.get("input")})
            elif btype == "tool_result":
                trace.append({"type": "tool_result",
                              "output": _flatten_blocks(block.get("content"))})
    return trace


def trace_from_opencode_export(data: dict) -> list:
    """Normalize an ``opencode export`` document — whose ``messages[].parts``
    carry text, reasoning, and tool parts — into the shared trace vocabulary."""
    trace: list = []
    for m in (data or {}).get("messages") or []:
        if not isinstance(m, dict):
            continue
        info = m.get("info") if isinstance(m.get("info"), dict) else m
        role = str(info.get("role") or m.get("role") or "").lower()
        parts = m.get("parts") if isinstance(m.get("parts"), list) else \
            info.get("parts") if isinstance(info.get("parts"), list) else []
        for p in parts:
            if not isinstance(p, dict):
                continue
            ptype = p.get("type")
            if ptype == "text" and p.get("text"):
                trace.append({"type": "user" if role == "user" else "text",
                              "text": p["text"]})
            elif ptype == "reasoning" and p.get("text"):
                trace.append({"type": "thinking", "text": p["text"]})
            elif ptype == "tool":
                state = p.get("state") if isinstance(p.get("state"), dict) else {}
                trace.append({"type": "tool_use", "tool": p.get("tool", ""),
                              "input": state.get("input")})
                output = state.get("output")
                if output:
                    trace.append({"type": "tool_result", "tool": p.get("tool", ""),
                                  "output": str(output)})
    return trace


def _flatten_blocks(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        out = [b.get("text", "") for b in content
               if isinstance(b, dict) and b.get("type") == "text"]
        return "\n".join(t for t in out if t)
    return "" if content is None else str(content)


# ──────────────────────────────────────────────────────────────────────
# The extraction pass
# ──────────────────────────────────────────────────────────────────────


def _extraction_kwargs(cfg: dict) -> dict:
    """run_agent kwargs for the extraction calls. Container modes run their
    main work out-of-process, so the extraction picks the in-process backend
    that matches the mode's auth story: claude-terminal → claude-agent-sdk
    (shares the subscription/API auth), opencode → pydantic-ai (bills the
    same provider key). Tools stay off — extraction reads corpora, not files."""
    mode = (cfg.get("mode") or "oneshot").strip().lower()
    backend = (cfg.get("backend") or "pydantic-ai").strip().lower()
    if mode == "claude-terminal":
        backend = "claude-agent-sdk"
    elif mode == "opencode":
        backend = "pydantic-ai"
    return dict(
        backend=backend,
        auth=cfg.get("auth") or "api_key",
        provider=cfg.get("provider") or "anthropic",
        model=cfg.get("ledger_model") or "",
        max_tokens=cfg.get("ledger_max_tokens") or 4096,
        enable_file_tools=False,
        # The extraction is BLIND by contract — it reads the inlined corpora,
        # never the workspace. enable_file_tools=False alone leaves the claude
        # backend's read surface (Read/Glob/Grep) open, and these passes run
        # in the PARENT's workspace; lock it down entirely.
        enable_read_tools=False,
    )


async def _structured_pass(system: str, prompt: str, schema_model, cfg: dict):
    result = await run_agent(
        prompt=prompt,
        system_prompt=system,
        output_schema=schema_model.model_json_schema(),
        **_extraction_kwargs(cfg),
    )
    data = result.structured
    if isinstance(data, list):
        # A bare top-level array is the model returning just the envelope's
        # single list field (commitments / clusters) — wrap it rather than
        # failing the whole pass.
        list_fields = [
            name for name, f in schema_model.model_fields.items()
            if "list" in str(f.annotation).lower()
        ]
        if len(list_fields) == 1:
            data = {list_fields[0]: data}
    if not isinstance(data, dict):
        raise ValueError(f"{schema_model.__name__} pass returned no parseable JSON")
    return schema_model(**data)


_CLAIMED_SYSTEM = f"""You are an assumptions auditor. You will see the working trace of an AI agent \
(its reasoning, tool activity, and replies) recorded while it produced a piece of work.

Mine the COMMITMENTS THE AGENT STATED OR REASONED FROM — the assumptions that shaped its choices. \
Frame-level commitments matter most: doctrines stated once that then drive many downstream decisions.

{_KIND_GUIDE}

For each commitment cite sites: ref is the trace line marker (e.g. "trace[12]"), evidence a short quote. \
Report only what is IN the trace — never invent, never infer from absence."""

_ENACTED_SYSTEM = f"""You are an assumptions auditor. You will see the files an AI agent produced or modified.

Mine the COMMITMENTS THE ARTIFACTS THEMSELVES ENACT — structural choices, hard-coded values, implicit \
exclusions, uniform patterns — regardless of what any author said anywhere. A rate limiter that keys on \
IP address has enacted "one IP ≈ one user" whether or not anyone wrote that down.

{_KIND_GUIDE}

For each commitment cite sites: ref is the file path, evidence a short quote or the concrete pattern. \
Report only what the files show — never invent."""

_LINK_SYSTEM = """You link two independently mined commitment lists about the same piece of work: \
CLAIMED (mined from the agent's working trace) and ENACTED (mined from the artifacts, blind to the trace).

Match semantically, not textually — "keep infrastructure costs low" and "chose SQLite over a hosted DB" \
are the same commitment at two granularities. For each output commitment:
- a claimed+enacted pair -> link "confirmed"; union both site lists; keep the crisper statement.
- claimed with no enacted counterpart -> link "decoration" (stated but left no footprint).
- enacted with no claimed counterpart -> link "unstated_doctrine" (acted on but never chosen).
Never drop a commitment; never manufacture matches."""


def _new_row(c: LinkedCommitment, label: str, no_trace: bool) -> dict:
    claimed = [s.model_dump() for s in c.claimed_sites]
    enacted = [s.model_dump() for s in c.enacted_sites]
    return {
        "id": "",   # assigned by _rank_and_sort
        "statement": c.statement,
        "kind": c.kind,
        "differential": "background",
        "seam_note": None,
        "rank": 0,
        "per_candidate": {
            label: {
                "link": c.link,
                "claimed_sites": claimed,
                "enacted_sites": enacted,
                "spread": len(claimed) + len(enacted),
                "no_trace": no_trace,
            }
        },
        "user": {"status": "unmarked", "note": "", "marked_at": None},
    }


def _rank_and_sort(doc: dict) -> dict:
    """Deterministic priority: live seams first, then commitments containing
    an unstated doctrine, then by max spread descending. Assigns ids + ranks
    and sorts the rows in place."""
    def max_spread(row: dict) -> int:
        return max((pc.get("spread", 0) for pc in row["per_candidate"].values()), default=0)

    def has_doctrine(row: dict) -> bool:
        return any(pc.get("link") == "unstated_doctrine" for pc in row["per_candidate"].values())

    rows = doc.get("commitments", [])
    rows.sort(key=lambda r: (
        0 if r.get("seam_note") else 1,
        0 if has_doctrine(r) else 1,
        -max_spread(r),
        r.get("statement", ""),
    ))
    for i, row in enumerate(rows):
        row["id"] = f"cm-{i + 1}"
        row["rank"] = i + 1
    return doc


def _empty_doc(label: str, *, has_trace: bool, trace_sources: list, context: str) -> dict:
    return {
        "format": LEDGER_FORMAT,
        "version": LEDGER_VERSION,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "context": context or "",
        "candidates": [
            {"label": label, "has_trace": has_trace, "trace_sources": list(trace_sources)}
        ],
        "commitments": [],
    }


async def extract_ledger(
    *,
    trace: list,
    artifact_files: dict,
    cfg: dict,
    label: str = "run",
    context: str = "",
    trace_sources: list | None = None,
) -> dict:
    """Run the companion pass over one candidate: claimed + enacted extraction
    in parallel, then linking. Returns a single-candidate ledger document;
    never raises — failures land in the doc's ``error`` field."""
    has_trace = bool(trace)
    doc = _empty_doc(label, has_trace=has_trace,
                     trace_sources=trace_sources or (["trace"] if has_trace else []),
                     context=context)
    # The parent prompt rides along as orientation, capped like every other
    # corpus — a book-length prompt must not starve the actual evidence.
    ctx_text = context.strip()
    if len(ctx_text) > _CONTEXT_CAP:
        ctx_text = ctx_text[:_CONTEXT_CAP] + " …[truncated]"
    ctx = f"## Task context\n\n{ctx_text}\n\n" if ctx_text else ""

    async def claimed_pass() -> list[Commitment]:
        if not has_trace:
            return []
        out = await _structured_pass(
            _CLAIMED_SYSTEM,
            f"{ctx}## Agent working trace\n\n{trace_corpus(trace)}\n\n"
            f"Extract at most {_MAX_COMMITMENTS} claimed commitments.",
            ClaimedExtraction, cfg,
        )
        return out.commitments

    async def enacted_pass() -> list[Commitment]:
        corpus = artifact_corpus(artifact_files)
        if not corpus.strip():
            return []
        out = await _structured_pass(
            _ENACTED_SYSTEM,
            f"{ctx}## Produced files\n\n{corpus}\n\n"
            f"Extract at most {_MAX_COMMITMENTS} enacted commitments.",
            EnactedExtraction, cfg,
        )
        return out.commitments

    claimed, enacted = await asyncio.gather(
        claimed_pass(), enacted_pass(), return_exceptions=True,
    )
    errors: list[str] = []
    if isinstance(claimed, BaseException):
        errors.append(f"claimed extraction failed: {claimed}")
        claimed = []
    if isinstance(enacted, BaseException):
        errors.append(f"enacted extraction failed: {enacted}")
        enacted = []

    linked = await _link(claimed, enacted, cfg, errors)

    doc["commitments"] = [_new_row(c, label, not has_trace) for c in linked]
    if errors:
        doc["error"] = "; ".join(errors)
    return _rank_and_sort(doc)


async def _link(
    claimed: list[Commitment], enacted: list[Commitment], cfg: dict, errors: list,
) -> list[LinkedCommitment]:
    """Join the two extractions. No trace / no claimed → pure code (every
    enacted commitment is potentially-unstated; the ``no_trace`` flag on the
    candidate carries the caveat). Link-call failure → the conservative
    deterministic join."""
    def as_linked(c: Commitment, link: str) -> LinkedCommitment:
        return LinkedCommitment(
            statement=c.statement, kind=c.kind, link=link,
            claimed_sites=c.sites if link != "unstated_doctrine" else [],
            enacted_sites=c.sites if link == "unstated_doctrine" else [],
        )

    if not claimed:
        return [as_linked(c, "unstated_doctrine") for c in enacted]
    if not enacted:
        return [as_linked(c, "decoration") for c in claimed]

    def dump(cs: list[Commitment]) -> str:
        return json.dumps([c.model_dump() for c in cs], indent=2)

    try:
        out = await _structured_pass(
            _LINK_SYSTEM,
            f"## CLAIMED\n\n{dump(claimed)}\n\n## ENACTED\n\n{dump(enacted)}\n\n"
            "Produce the linked ledger.",
            LinkedLedger, cfg,
        )
        return out.commitments
    except Exception as e:  # noqa: BLE001
        errors.append(f"linking failed: {e}")
        return (
            [as_linked(c, "decoration") for c in claimed]
            + [as_linked(c, "unstated_doctrine") for c in enacted]
        )


# ──────────────────────────────────────────────────────────────────────
# Fan-out helpers: merge per-candidate ledgers + cross-candidate differential
# ──────────────────────────────────────────────────────────────────────


def merge_ledgers(ledgers: dict) -> dict:
    """Union N single-candidate ledger docs (label → doc) into one
    multi-candidate doc. Rows keep their per-candidate columns; the
    differential fields are settled by :func:`compute_differential`."""
    merged: dict = {
        "format": LEDGER_FORMAT,
        "version": LEDGER_VERSION,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "context": "",
        "candidates": [],
        "commitments": [],
    }
    errors: list[str] = []
    for label, doc in ledgers.items():
        if not isinstance(doc, dict):
            continue
        merged["context"] = merged["context"] or doc.get("context", "")
        for cand in doc.get("candidates", []):
            merged["candidates"].append({**cand, "label": label})
        if doc.get("error"):
            errors.append(f"{label}: {doc['error']}")
        for row in doc.get("commitments", []):
            pc = {label: col for _, col in row.get("per_candidate", {}).items()}
            merged["commitments"].append({**row, "per_candidate": pc})
    if errors:
        merged["error"] = "; ".join(errors)
    return _rank_and_sort(_settle_differential(merged))


def _settle_differential(doc: dict) -> dict:
    labels = {c["label"] for c in doc.get("candidates", [])}
    for row in doc.get("commitments", []):
        covered = set(row.get("per_candidate", {}))
        if row.get("seam_note"):
            row["differential"] = "seam"
        elif labels and covered >= labels:
            row["differential"] = "background"
        else:
            row["differential"] = "partial"
    return doc


async def compute_differential(doc: dict, cfg: dict) -> dict:
    """Cluster same-commitments across candidates and mark the live seams.
    One LLM pass over the merged doc's statements; deterministic guards keep
    a bad clustering from corrupting the ledger (invalid member indices drop
    the cluster; unclustered rows survive as-is)."""
    labels = [c["label"] for c in doc.get("candidates", [])]
    if len(labels) < 2 or not doc.get("commitments"):
        return _rank_and_sort(_settle_differential(doc))

    by_label: dict = {lb: [] for lb in labels}
    for row in doc["commitments"]:
        for lb in row["per_candidate"]:
            if lb in by_label:
                by_label[lb].append(row)

    listing: list[str] = []
    for lb in labels:
        listing.append(f"## Candidate `{lb}`")
        for i, row in enumerate(by_label[lb]):
            listing.append(f"{i}. [{row['kind']}] {row['statement']}")
        listing.append("")

    try:
        out = await _structured_pass(
            "You cluster commitments mined independently from several candidate solutions "
            "to the same problem. Commitments from different candidates that cover the same "
            "territory belong in one cluster — matched semantically, not textually. Set "
            "seam_note ONLY where member candidates genuinely DISAGREE (contradictory "
            "commitments on the same territory); shared commitments get no seam_note. "
            "Single-candidate commitments need no cluster at all — omit them.",
            "\n".join(listing) + "\nProduce the differential clusters.",
            Differential, cfg,
        )
        clusters = out.commitments
    except Exception as e:  # noqa: BLE001
        gen.log(f"[ledger] differential pass failed: {e}")
        clusters = []

    consumed: set = set()
    merged_rows: list[dict] = []
    for cluster in clusters:
        members: list[tuple[str, dict]] = []
        ok = True
        for lb, idx in cluster.members.items():
            rows = by_label.get(lb)
            if rows is None or not (0 <= idx < len(rows)) or (lb, idx) in consumed:
                ok = False
                break
            members.append((lb, rows[idx]))
        if not ok or len(members) < 2:
            continue
        for lb, idx in cluster.members.items():
            consumed.add((lb, idx))
        pc: dict = {}
        for lb, row in members:
            pc[lb] = row["per_candidate"][lb]
        merged_rows.append({
            "id": "",
            "statement": cluster.statement,
            "kind": cluster.kind,
            "differential": "background",
            "seam_note": cluster.seam_note or None,
            "rank": 0,
            "per_candidate": pc,
            "user": {"status": "unmarked", "note": "", "marked_at": None},
        })

    kept: list[dict] = []
    for lb in labels:
        for i, row in enumerate(by_label[lb]):
            if (lb, i) not in consumed:
                kept.append({**row, "per_candidate": {lb: row["per_candidate"][lb]}})
    doc["commitments"] = merged_rows + kept
    return _rank_and_sort(_settle_differential(doc))


# ──────────────────────────────────────────────────────────────────────
# Serialization + markdown fallback
# ──────────────────────────────────────────────────────────────────────


def dumps_ledger(doc: dict) -> str:
    return json.dumps(doc, indent=2, default=str) + "\n"


def verified_facts(doc: dict) -> list:
    """Commitments safe to feed forward into future generation: user-marked
    ``verified`` AND kind ``fact`` — never preferences or frame choices. The
    boundary is load-bearing: feed back what the user KNOWS; a tool that
    learns what the user PREFERS starts pre-filtering to the predicted
    choice, which is the oracle failure state rebuilt from the user's own
    judgment."""
    facts: list = []
    if not (isinstance(doc, dict) and doc.get("format") == LEDGER_FORMAT):
        return facts
    for row in doc.get("commitments", []):
        user = row.get("user") or {}
        if user.get("status") == "verified" and row.get("kind") == "fact":
            statement = (row.get("statement") or "").strip()
            if statement:
                facts.append(statement)
    return facts


def verified_facts_from_files(files: dict) -> list:
    """Every verified fact across the ``.ledger`` docs in a file map — the
    caller-facing sugar for the feed-forward path."""
    facts: list = []
    seen: set = set()
    for path in sorted(files or {}):
        if not path.endswith(".ledger"):
            continue
        content = files[path]
        if not isinstance(content, str):
            continue
        try:
            doc = json.loads(content)
        except Exception:  # noqa: BLE001
            continue
        for fact in verified_facts(doc):
            key = " ".join(fact.lower().split())
            if key not in seen:
                seen.add(key)
                facts.append(fact)
    return facts


_LINK_BADGE = {"confirmed": "✔", "decoration": "✱", "unstated_doctrine": "⚠"}
_KIND_ORDER = ("frame", "preference", "fact")


def ledger_to_md(doc: dict) -> str:
    """Human-readable fallback rendering, seams first, grouped by kind."""
    rows = doc.get("commitments", [])
    lines = ["# Assumptions ledger", ""]
    cands = doc.get("candidates", [])
    lines.append(
        f"_{len(cands)} candidate(s) · {len(rows)} commitment(s) · "
        f"{sum(1 for r in rows if r.get('differential') == 'seam')} live seam(s) · "
        f"{sum(1 for r in rows if any(pc.get('link') == 'unstated_doctrine' for pc in r['per_candidate'].values()))} unstated doctrine(s)_"
    )
    lines.append("")
    if doc.get("error"):
        lines += [f"> ⚠ extraction degraded: {doc['error']}", ""]

    seams = [r for r in rows if r.get("differential") == "seam"]
    if seams:
        lines += ["## Live seams — candidates disagree here", ""]
        for r in seams:
            lines += _row_md(r)
    for kind in _KIND_ORDER:
        group = [r for r in rows if r["kind"] == kind and r.get("differential") != "seam"]
        if not group:
            continue
        title = {"frame": "Frame choices", "preference": "Preferences assigned",
                 "fact": "Fact-checkable claims"}[kind]
        lines += [f"## {title}", ""]
        for r in group:
            lines += _row_md(r)
    return "\n".join(lines) + "\n"


def _row_md(row: dict) -> list:
    lines = [f"### {row['id']} · {row['statement']}"]
    if row.get("seam_note"):
        lines.append(f"> **Seam:** {row['seam_note']}")
    for label, pc in row["per_candidate"].items():
        badge = _LINK_BADGE.get(pc.get("link", ""), "?")
        caveat = " _(no trace — 'never claimed' cannot be established)_" \
            if pc.get("no_trace") and pc.get("link") == "unstated_doctrine" else ""
        lines.append(f"- `{label}` {badge} {pc.get('link')} · spread {pc.get('spread', 0)}{caveat}")
        for site in (pc.get("claimed_sites") or []) + (pc.get("enacted_sites") or []):
            lines.append(f"  - `{site.get('ref', '')}` — {site.get('evidence', '')}")
    lines.append("")
    return lines


__all__ = [
    "LEDGER_FORMAT",
    "LEDGER_VERSION",
    "TRACE_FILE",
    "LEDGER_FILE",
    "LEDGER_MD_FILE",
    "LEDGER_PROMOTED",
    "extract_ledger",
    "merge_ledgers",
    "compute_differential",
    "trace_corpus",
    "artifact_corpus",
    "trace_from_claude_session",
    "trace_from_opencode_export",
    "dumps_ledger",
    "ledger_to_md",
    "verified_facts",
    "verified_facts_from_files",
]
