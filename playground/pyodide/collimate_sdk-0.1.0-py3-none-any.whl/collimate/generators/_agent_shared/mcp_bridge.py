# SPDX-License-Identifier: Apache-2.0
"""Network MCP bridge — expose the composition tools to container/CLI agents.

The cross-cell / create-cell tools call ``gen.*``, which only works inside the
generator's Python process (it routes over the IPC bridge to the host). The
in-process backends use them directly (pydantic-ai Tools / the claude-agent-sdk
in-process MCP server), but the **container** agents — the ``claude`` CLI in the
claude-terminal mode and ``opencode`` in the opencode mode — run in their own
process and can't reach ``gen.*``.

This module hosts a small MCP server (SSE transport, ``mcp`` package's FastMCP)
**in the generator process**, in a background thread, bound to a host port. The
container connects back to it over the Docker host gateway
(``host.docker.internal``), so the same view/edit/run + create-cell tools become
available to claude/opencode too. Sync tools call ``gen.*`` directly (the IPC
bridge serialises on its own lock); the one async tool (``call_generator`` →
``gen.call``) is scheduled back onto the generator's main event loop.

Degrades cleanly: if the ``mcp`` package isn't importable or the server can't
start, :func:`start_bridge` returns ``None`` and the caller simply runs without
the extra tools.
"""
from __future__ import annotations

import asyncio
import socket
import threading
from dataclasses import dataclass

import gen

from . import _gated_tools, _tool_description

SERVER_NAME = "collimate"


@dataclass
class McpBridge:
    """A running MCP bridge. ``url_container`` is the SSE endpoint a container
    reaches over the host gateway (``host.docker.internal``); ``url_host`` is the
    same endpoint reached from a HOST process (the gemini CLI subprocess) at the
    actual bind address; ``tool_names`` are the fully-qualified
    ``mcp__collimate__*`` names."""
    port: int
    url_container: str
    url_host: str
    tool_names: list


def _docker_gateway_host() -> str:
    """The Docker bridge-gateway IP the container reaches the host on (the
    address ``host.docker.internal`` → ``host-gateway`` resolves to on Linux).

    Binding the bridge here instead of ``0.0.0.0`` is the security fix: the tools
    include ``call_generator`` (arbitrary generator execution) and the cell-write
    tools, so an all-interfaces bind hands unauthenticated code-exec to the whole
    LAN. The gateway address keeps the LAN out, but any container on the same
    docker bridge (not just ours) can still reach it — which is why
    :func:`start_bridge` also hides the endpoint behind an unguessable per-run
    URL path."""
    try:
        import docker  # provided by the harness runtime
        net = docker.from_env().networks.get("bridge")
        cfg = (net.attrs.get("IPAM") or {}).get("Config") or []
        gw = (cfg[0].get("Gateway") if cfg else "") or ""
        if gw:
            return gw
    except Exception:  # noqa: BLE001 — fall back to the Linux default bridge gateway
        pass
    return "172.17.0.1"


def _free_port(host: str, start: int = 8765) -> int:
    port = start
    while port < start + 2000:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind((host, port))
                return port
            except OSError:
                port += 1
    raise RuntimeError("no free port for the MCP bridge")


def start_bridge(
    *, enable_run_generators: bool, enable_cross_cell: bool, enable_create_cell: bool, loop,
    bind_host: "str | None" = None, transport: str = "sse",
) -> "McpBridge | None":
    """Start the SSE MCP bridge in a daemon thread. ``loop`` is the generator's
    running event loop (so the async ``call_generator`` tool can be scheduled
    back onto it from the server thread). Returns ``None`` when no tools are
    requested or the ``mcp`` package / server is unavailable.

    ``bind_host`` picks the interface. Default (``None``) binds the Docker
    bridge-gateway IP so a CONTAINER reaches it over ``host.docker.internal``.
    A HOST-process consumer (the gemini CLI subprocess) passes ``"127.0.0.1"``
    — it needs no docker and only this host can reach it (the unguessable slug
    path is still the capability check).

    The three gates mirror the in-process backends (see :func:`exposure_flags`):
    ``enable_run_generators`` (discover/read/run + the modify-on-a-new-cell
    handoff), ``enable_cross_cell`` (write/author/commit), ``enable_create_cell``
    (the content-cell tool)."""
    if not (enable_run_generators or enable_cross_cell or enable_create_cell):
        return None
    try:
        from mcp.server.fastmcp import FastMCP
    except Exception as e:  # noqa: BLE001
        gen.log(f"mcp package unavailable — cross-cell tools not exposed to this surface ({e})")
        return None

    # The gateway bind limits reachability to the docker network — but every
    # container on that bridge (not just ours) can reach the gateway IP, so the
    # SSE endpoint additionally lives under an unguessable per-run path: a
    # capability URL only this run's agent config ever sees. (A localhost bind
    # for the gemini host process is already host-private; the slug still gates.)
    import secrets
    slug = secrets.token_urlsafe(16)

    try:
        bind_host = bind_host or _docker_gateway_host()
        port = _free_port(bind_host)
    except (OSError, RuntimeError) as e:
        # e.g. the fallback gateway address isn't locally bindable (no docker
        # bridge on this host). Degrade cleanly per the module contract.
        gen.log(f"MCP bridge unavailable — cross-cell tools not exposed to this surface ({e})")
        return None
    # Transport: "sse" (default; the gemini CLI + container agents were wired for
    # it) or "streamable-http" (the modern, non-deprecated MCP transport the
    # in-process ADK / OpenAI-Agents / MAF backends speak natively). Path differs:
    # SSE serves /<slug>/sse, streamable-http serves /<slug>/mcp.
    http_transport = "streamable-http" if transport == "streamable-http" else "sse"
    _path_kwargs = (
        {"streamable_http_path": f"/{slug}/mcp"} if http_transport == "streamable-http"
        else {"sse_path": f"/{slug}/sse", "message_path": f"/{slug}/messages/"}
    )
    try:
        server = FastMCP(SERVER_NAME, host=bind_host, port=port, **_path_kwargs)
    except TypeError:
        # Older FastMCP: host/port/paths via settings/env.
        import os as _os
        _os.environ["FASTMCP_HOST"] = bind_host
        _os.environ["FASTMCP_PORT"] = str(port)
        server = FastMCP(SERVER_NAME)
        try:
            server.settings.host = bind_host
            server.settings.port = port
            for _k, _v in _path_kwargs.items():
                setattr(server.settings, _k, _v)
        except Exception:  # noqa: BLE001
            slug = ""      # settings object without path knobs — default paths
            pass

    names: list = []

    def _bounced(fn):
        """Wrap an impl that awaits a loop-affine ``gen.*`` coroutine so it runs
        on the generator's main loop (where the IPC bridge lives), not FastMCP's
        server thread. The wrapper carries the impl's signature so FastMCP still
        derives the right input schema; ``__wrapped__`` is stripped so FastMCP
        can't unwrap past the bounce and call the raw impl on the wrong loop."""
        import functools
        import inspect

        @functools.wraps(fn)
        async def wrapper(*args, **kwargs):
            fut = asyncio.run_coroutine_threadsafe(fn(*args, **kwargs), loop)
            return await asyncio.wrap_future(fut)

        wrapper.__signature__ = inspect.signature(fn)
        del wrapper.__wrapped__
        return wrapper

    # The ONE registry drives registration: each gated tool is served under its
    # name with its ``gen.*``-twin description; ``main_loop`` rows (they await an
    # async gen.*) get the main-loop bounce, the sync-bodied rows register
    # directly (their gen.* calls block on their own IPC lock, thread-safe).
    for name, _gate, main_loop, gen_twin, fn in _gated_tools(
        enable_run_generators=enable_run_generators,
        enable_cross_cell=enable_cross_cell,
        enable_create_cell=enable_create_cell,
    ):
        handler = _bounced(fn) if main_loop else fn
        server.tool(name=name, description=_tool_description(fn, gen_twin))(handler)
        names.append(f"mcp__{SERVER_NAME}__{name}")

    def _serve() -> None:
        try:
            server.run(transport=http_transport)
        except Exception as e:  # noqa: BLE001
            gen.log(f"MCP bridge server stopped: {e}")

    threading.Thread(target=_serve, name="collimate-mcp-bridge", daemon=True).start()
    _suffix = "mcp" if http_transport == "streamable-http" else "sse"
    path = f"/{slug}/{_suffix}" if slug else f"/{_suffix}"
    url_container = f"http://host.docker.internal:{port}{path}"
    url_host = f"http://{bind_host}:{port}{path}"
    gen.log(f"MCP bridge serving {len(names)} tool(s) on {bind_host}:{port} (per-run path)")
    return McpBridge(port=port, url_container=url_container, url_host=url_host, tool_names=names)
