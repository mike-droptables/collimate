# SPDX-License-Identifier: Apache-2.0
"""OpenCode mode — opencode's own web UI in a container.

Runs ``opencode web`` and surfaces it through the ``.website`` renderer. The
picked model is written into opencode's config as ``<provider>/<model>``; auth
rides the provider API-key env. opencode works on the cell's own workspace
(bind-mounted rw at ``/workspace``), and both surfaces run under
``gen.live_files()`` so the Files tab stays in live bidirectional sync — the
agent's writes appear in the cell as they happen, and the user's edits reach
the agent's working tree mid-session. On teardown the session storage is
snapshotted into the cell and a best-effort open-format transcript
``chats/main.json`` is reconstructed.

When the tool toggles are on, the MCP bridge (see :mod:`mcp_bridge`) is started
in the generator process and registered in opencode's config ``mcp`` section as
a remote server, so the in-container opencode gets the same view/edit/run +
create-cell tools. An optional ``extra_system`` prompt is written as
``AGENTS.md`` and any ``docs`` are dropped into the workspace (used by the
Guide).
"""
from __future__ import annotations

import json
import os
import re
import shlex
import socket
import sys
import time
from pathlib import Path

import gen
from collimate.transcript import serialize_transcript
from collimate._host import Message

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from _agent_shared import resolve_model  # noqa: E402
from _agent_shared import ledger as ledger_mod  # noqa: E402
from _agent_shared.mcp_bridge import start_bridge  # noqa: E402

IMAGE_TAG = "collimate-opencode:latest"
_TRANSCRIPT_FILE = "chats/main.json"
_HOME = "/home/coder"

# Collimate provider labels → opencode/models.dev provider ids. The one real
# divergence: the Gemini API is provider id "google" in models.dev, so a
# verbatim "gemini/<model>" never resolves even with GEMINI_API_KEY set.
_OPENCODE_PROVIDER_IDS = {"gemini": "google"}


async def run_opencode(
    cfg: dict,
    *,
    extra_system: str = "",
    docs: dict | None = None,
    label: str = "Agent · OpenCode",
) -> None:
    """Run opencode in a container. ``prefer_terminal`` picks the surface:

      * ``True`` → opencode's own **TUI**, attached through the ``.terminal``
        renderer. opencode is terminal-first, so this is its native interface —
        and, unlike ``opencode web`` (a SPA with absolute asset paths + a strict
        CSP that can't be served behind the cell's path-prefix proxy), a PTY has
        no reverse-proxy/origin constraints.
      * ``False`` → headless ``opencode serve`` rendered through the assistant-ui
        chat (a ``.chat`` pointer whose opencode integration talks to the API
        over the cell's ``/proxy/`` route).
    """
    import asyncio

    provider = (cfg.get("provider") or "anthropic").strip().lower()
    # resolve_model raises on a contradicting explicit model; parse_agent_config
    # already validated this selection upstream, so this just recomputes it.
    model = resolve_model("opencode", "", provider, cfg.get("model"))
    oc_provider = _OPENCODE_PROVIDER_IDS.get(provider, provider)
    # Prefix ``<provider>/`` exactly once (idempotent): openrouter slugs are
    # ``vendor/model`` and must still become ``openrouter/vendor/model`` — a bare
    # ``"/" in model`` guard would wrongly leave the openrouter/ prefix off.
    opencode_model = (
        model if model.startswith(f"{oc_provider}/") else f"{oc_provider}/{model}"
    )

    await gen.update(name=label, summary="Starting…")
    gen.phase("spinning_up", "starting container")

    bridge = start_bridge(
        enable_run_generators=bool(cfg.get("enable_run_generators")),
        enable_cross_cell=bool(cfg.get("enable_cross_cell")),
        enable_create_cell=bool(cfg.get("enable_create_cell")),
        loop=asyncio.get_running_loop(),
    )

    env_vars: dict = {}
    try:
        key = await gen.api_key(provider, description=f"{provider} API key for OpenCode")
        if key:
            env_vars[f"{provider.upper()}_API_KEY"] = key
    except Exception:  # noqa: BLE001 — incl. a dismissed key modal
        gen.log(f"no {provider} key supplied — authenticate inside OpenCode")

    if bool(cfg.get("prefer_terminal", True)):
        await _run_tui(cfg, opencode_model, env_vars, bridge, extra_system, docs, label)
    else:
        await _run_serve(cfg, opencode_model, env_vars, bridge, extra_system, docs, label)


def _make_env(env_vars: dict, bridge, *, ports=None):
    from _env_shared import DockerEnvironment  # noqa: E402
    return DockerEnvironment(
        image=IMAGE_TAG,
        mount="/workspace", mount_mode="rw",
        build_context=str(Path(__file__).resolve().parent / "opencode"),
        environment=env_vars,
        ports=ports,
        extra_hosts={"host.docker.internal": "host-gateway"} if bridge else None,
        working_dir="/workspace",
        name_prefix="collimate-opencode", kind="opencode",
    )


def _seed(container, opencode_model: str, bridge, extra_system: str, docs: dict | None) -> None:
    oc: dict = {"$schema": "https://opencode.ai/config.json", "model": opencode_model}
    if bridge:
        oc["mcp"] = {"collimate": {"type": "remote", "url": bridge.url_container, "enabled": True}}
    _write_container_file(container, f"{_HOME}/.config/opencode/opencode.json",
                          json.dumps(oc), mkdir=f"{_HOME}/.config/opencode")
    if extra_system:
        _write_container_file(container, "/workspace/AGENTS.md", extra_system)
    if docs:
        container.exec_run(["bash", "-lc", "mkdir -p /workspace/_docs"], user="coder")
        for name, content in docs.items():
            _write_container_file(container, f"/workspace/_docs/{os.path.basename(name)}", content)


async def _run_tui(cfg, opencode_model, env_vars, bridge, extra_system, docs, label) -> None:
    env = _make_env(env_vars, bridge)
    container = env.container
    try:
        _seed(container, opencode_model, bridge, extra_system, docs)
        term_env = {"TERM": "xterm-256color"}
        if env_vars.get("ANTHROPIC_API_KEY"):
            term_env["ANTHROPIC_API_KEY"] = env_vars["ANTHROPIC_API_KEY"]
        gen.status("Registering terminal session…")
        async with gen.serve_terminal(
            env.container_id, ["opencode"], cwd="/workspace", env=term_env,
            label=f"OpenCode · {opencode_model}", pointer="opencode.terminal",
            name=label, summary=f"live · {opencode_model}",
        ):
            gen.phase("running", "terminal ready")
            gen.status("OpenCode TUI ready — open the cell to attach.")
            # Live cell <-> /workspace sync for the whole session (see module doc).
            async with gen.live_files():
                await gen.wait_until_cancelled()
    finally:
        await _finalize(cfg, container)
        env.close()


async def _run_serve(cfg, opencode_model, env_vars, bridge, extra_system, docs, label) -> None:
    port = _find_free_port(4096)
    gen.log(f"Using port {port}")
    env = _make_env(env_vars, bridge, ports={f"{port}/tcp": ("127.0.0.1", port)})
    container = env.container
    try:
        _seed(container, opencode_model, bridge, extra_system, docs)
        container.exec_run(
            ["bash", "-lc",
             f"nohup opencode serve --hostname 0.0.0.0 --port {port} "
             ">/tmp/opencode.log 2>&1 &"],
            user="coder", workdir="/workspace", detach=True,
        )
        gen.status("Waiting for OpenCode…")
        if not _wait_for_ready(port, timeout=120):
            log = container.exec_run(["bash", "-lc", "tail -n 40 /tmp/opencode.log 2>/dev/null"])
            detail = (log.output or b"").decode("utf-8", errors="replace")
            raise RuntimeError(f"OpenCode serve did not become ready within 120s.\n{detail}")
        await gen.serve_port(port, name="OpenCode", path="")
        channel = os.environ.get("COLLIMATE_CHANNEL", "")
        run_id = os.environ.get("COLLIMATE_RUN_ID", "")
        proxy_url = f"/proxy/{channel}/{run_id}/{port}/"
        from collimate.pointers import chat_session_pointer
        gen.update_file("conversation.chat", json.dumps(chat_session_pointer(
            {}, label=label,
            integration={"type": "opencode", "proxy_url": proxy_url},
        )))
        await gen.update(name=label, summary=f"assistant-ui · {opencode_model}",
                         pinned="conversation.chat")
        gen.phase("running", "OpenCode ready")
        gen.status("OpenCode is running — open the cell to use it.")
        # Live cell <-> /workspace sync for the whole session (see module doc).
        async with gen.live_files():
            await gen.wait_until_cancelled()
    finally:
        await _finalize(cfg, container)
        env.close()


def _write_container_file(container, path: str, content: str, *, mkdir: str | None = None) -> None:
    import base64
    b64 = shlex.quote(base64.b64encode(content.encode("utf-8")).decode("ascii"))
    # Quote the destination too — doc names are caller-supplied and a space or
    # shell metacharacter in an unquoted path would corrupt (or execute) it.
    pre = f"mkdir -p {shlex.quote(mkdir)} && " if mkdir else ""
    container.exec_run(
        ["bash", "-lc", f"{pre}echo {b64} | base64 -d > {shlex.quote(path)}"], user="coder",
    )


def _find_free_port(start: int = 4096) -> int:
    # Spread concurrent cells across the range — the bind-probe here and the
    # docker publish happen minutes apart on a first-run image build, so two
    # cells probing from the same fixed start would collide.
    port = start + (os.getpid() % 500)
    while port < start + 1500:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                port += 1
    raise RuntimeError("No free port found")


def _wait_for_ready(port: int, timeout: int = 120) -> bool:
    """Wait until the opencode server answers HTTP on the published port.

    A bare TCP connect is not a readiness signal: Docker's userland proxy
    accepts on 127.0.0.1:<port> from container start, so connect_ex()==0 even
    while `opencode serve` is still booting (or crashed). Any HTTP response —
    whatever the status — means the server itself answered."""
    import urllib.error
    import urllib.request
    deadline = time.time() + timeout
    url = f"http://127.0.0.1:{port}/"
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2):
                return True
        except urllib.error.HTTPError:
            return True     # got an HTTP status — the server is up
        except Exception:   # noqa: BLE001 — conn refused/reset while booting
            pass
        time.sleep(2)
    return False


async def _finalize(cfg, container) -> None:
    """Teardown: export the transcript and — when the ledger is on — run the
    assumptions-ledger extraction over the export's full parts (tool +
    reasoning parts included, which the open-format transcript strips)."""
    try:
        data = _export_chatlog(container)
    except Exception as e:  # noqa: BLE001
        gen.log(f"chatlog export failed: {e}")
        data = None
    if not (cfg.get("ledger") and data):
        return
    try:
        trace = ledger_mod.trace_from_opencode_export(data)
        if not trace:
            return
        gen.update_file(ledger_mod.TRACE_FILE, json.dumps(trace, indent=2, default=str))
        artifacts = {
            p: gen.read_file(p) for p in gen.list_files()
            if not p.startswith(("_agent/", "chats/"))
        }
        doc = await ledger_mod.extract_ledger(
            trace=trace, artifact_files=artifacts, cfg=cfg,
            trace_sources=["opencode export"],
        )
        gen.update_file(ledger_mod.LEDGER_FILE, ledger_mod.dumps_ledger(doc))
        gen.update_file(ledger_mod.LEDGER_MD_FILE, ledger_mod.ledger_to_md(doc))
    except Exception as e:  # noqa: BLE001
        gen.log(f"[ledger] extraction failed: {e}")


def _export_chatlog(container):
    """Write the open-format transcript from opencode's own export; returns
    the parsed export document (``{"info", "messages"}``) or ``None``.

    opencode (>=1.x) keeps sessions in a SQLite DB, not a JSON storage tree, so
    the session id is sourced from ``opencode session list`` (newest first) and
    the conversation from ``opencode export <id>`` — a clean
    ``{"info", "messages"}`` document — rather than reconstructing raw files.
    """
    sid = _latest_session_id(container)
    if not sid:
        gen.log("opencode: no session found to export")
        return None
    res = container.exec_run(
        ["bash", "-lc", f"opencode export {shlex.quote(sid)} 2>/dev/null"], user="coder",
    )
    raw = (res.output or b"").decode("utf-8", errors="replace")
    start = raw.find("{")
    if start < 0:
        gen.log(f"opencode export {sid}: no JSON output")
        return None
    try:
        data = json.loads(raw[start:])
    except Exception as e:  # noqa: BLE001
        gen.log(f"opencode export {sid}: could not parse export ({e})")
        return None
    out = []
    for m in data.get("messages") or []:
        if not isinstance(m, dict):
            continue
        info = m.get("info") if isinstance(m.get("info"), dict) else m
        role = str(info.get("role") or m.get("role") or "").lower()
        text = _text_from_parts(m.get("parts")) or _text_from_parts(info.get("parts")) \
            or (m.get("content") if isinstance(m.get("content"), str) else "")
        if role in ("user", "assistant", "system") and text and text.strip():
            out.append(Message(role=role, content=text.strip()))
    if not out:
        gen.log(f"opencode export {sid}: no chat text to write")
        return data
    gen.update_file(_TRANSCRIPT_FILE, serialize_transcript(out))
    gen.log(f"Wrote {_TRANSCRIPT_FILE} ({len(out)} messages) via `opencode export {sid}`")
    return data


def _latest_session_id(container) -> str:
    """The most-recent opencode session id (``ses_…``), via ``opencode session
    list`` (newest first). Empty string when there are no sessions."""
    res = container.exec_run(
        ["bash", "-lc", "opencode session list 2>/dev/null"], user="coder",
    )
    text = (res.output or b"").decode("utf-8", errors="replace")
    m = re.search(r"ses_[A-Za-z0-9]+", text)
    return m.group(0) if m else ""


def _text_from_parts(parts) -> str:
    if not isinstance(parts, list):
        return ""
    chunks = []
    for p in parts:
        if isinstance(p, dict) and p.get("type") == "text" and p.get("text"):
            chunks.append(p["text"])
        elif isinstance(p, str):
            chunks.append(p)
    return "\n".join(chunks)
