"""Shared internals for raw-CDP daemon generators.

This package is intentionally private (leading underscore on the dir
name) — it has no manifest.gen_yaml, so the picker skips it. Sibling
generators import it via a small sys.path shim:

    import os, sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from _cdp_shared.runtime import run_cdp_daemon
"""
from .runtime import run_cdp_daemon, CaptureContext  # noqa: F401
