"""Shared core for raw-CDP daemon generators — no Playwright, no Docker.

The flow:
  1. Launch the Chrome/Chromium already installed on the host with
     ``--remote-debugging-port=0`` and read the chosen port back from
     the profile's ``DevToolsActivePort`` file.
  2. Connect straight to the page target's DevTools WebSocket and
     speak the protocol by hand (a ~100-line JSON-RPC client below).
  3. ``Page.startScreencast`` ships JPEG frames at ~native paint rate.
     A tiny aiohttp WebSocket relays the frames + accepts input
     messages (pointer / wheel / key / text / viewport / nav) from the
     cell's renderer, which are fed back as ``Input.dispatch*`` /
     ``Page.navigate`` commands.
  4. (Optional) loop on ``gen.wait_for_action()`` so a renderer button
     can trigger a Python-side capture that emits a sibling cell.

The wire protocol to the renderer is init/frame/viewport/url/window down
and pointer/wheel/key/text/viewport/nav/window up. No pip browser dep, no
container image — it drives the user's real Chrome, one (hidden,
headless) process per cell, killed on Stop.

Two render modes feed the renderer (``render_mode``):

  * ``image`` (default) — the CDP screencast above: pixel-exact JPEG
    frames at paint rate, with renderer input forwarded back as
    ``Input.dispatch*``. Everything renders (canvas, video, hover
    states) at the cost of being a compressed raster, and every click
    round-trips through CDP. The safe, universal path.
  * ``live`` — no screencast and no input forwarding. The renderer runs
    the REAL page in a native iframe, served by a reverse proxy on this
    server (reached via the cell's subdomain). The proxy performs each
    outbound request through the live browser's session — injecting the
    profile's cookies and stripping ``X-Frame-Options`` / CSP
    ``frame-ancestors`` so framebusting pages embed and stay logged in —
    and rewrites only the target's own origin onto the subdomain, so the
    page (and its bundle) executes natively with no in-browser rewriting.
    The headless Chrome stays attached only as the session/cookie
    authority, the "Open window" challenge-solver, and the capture scraper.

Navigation, capture, and the window toggle work in both modes; the mode
changes whether the page is streamed (image) or run natively (live).

Sibling generators import this via a `sys.path` shim — see the
package's `__init__.py` for the canonical snippet.
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import os
import re
import shutil
import signal
import socket
import subprocess
import sys
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Optional
from urllib.parse import urlparse

import aiohttp
from aiohttp import web

import gen


# Screencast tuning — quality is a JPEG 0..100; everyNthFrame=1 means
# every paint. JPEG@85 keeps small text legible (the dominant content
# in chat/UI pages) and the stream is only proxied locally, so the
# bandwidth cost of the higher setting doesn't matter. The max bounds
# clamp the encoder when a user drags the cell huge; the actual frame
# resolution follows viewport × deviceScaleFactor below these caps, so
# most resizes need no screencast restart. The caps must fit the max
# viewport at the max DPR (HiDPI clients render at 2-3× and frames
# below their physical resolution paint blurry).
_SCREENCAST_QUALITY = 92
_SCREENCAST_MAX_W = 3840
_SCREENCAST_MAX_H = 2400

_SCREENCAST_PARAMS = {
    "format": "jpeg",
    "quality": _SCREENCAST_QUALITY,
    "maxWidth": _SCREENCAST_MAX_W,
    "maxHeight": _SCREENCAST_MAX_H,
    "everyNthFrame": 1,
}

# Injected into the captured (headless) page in image mode. The page's OS
# clipboard isn't the user's, and the user can't see the focused field's caret,
# so this bridges three things back to the renderer over a CDP binding
# (``__collimateBridge``): (1) copy capture — the page's clipboard writes / copy
# events, so Ctrl+C and "copy" buttons reach the real clipboard; (2) the live
# selection, so a plain drag-select copies even without a page handler; (3) the
# focused <input>/<textarea> geometry + value, so the renderer can float a
# local input over it for instant typing echo. Best-effort and idempotent.
_INPUT_BRIDGE_JS = r"""
(function(){
  if (window.__collimateInputBridge) return;
  window.__collimateInputBridge = true;
  function B(o){ try { if (window.__collimateBridge) window.__collimateBridge(JSON.stringify(o)); } catch(e){} }
  try {
    var c = navigator.clipboard;
    if (c && c.writeText) { var ow = c.writeText.bind(c);
      c.writeText = function(t){ B({t:"copy", text:String(t==null?"":t)}); return ow(t); }; }
  } catch(e){}
  function onCopy(e){ try {
    var t = "";
    if (e.clipboardData) t = e.clipboardData.getData("text/plain") || "";
    if (!t && window.getSelection) t = String(window.getSelection()||"");
    if (t) B({t:"copy", text:t});
  } catch(err){} }
  document.addEventListener("copy", onCopy, true);
  document.addEventListener("cut", onCopy, true);
  var selTmr = 0;
  document.addEventListener("selectionchange", function(){
    if (selTmr) return;
    selTmr = setTimeout(function(){ selTmr = 0;
      try { B({t:"sel", text: window.getSelection ? String(window.getSelection()||"") : ""}); } catch(e){}
    }, 120);
  }, true);
  function rectOf(el){ try { var r = el.getBoundingClientRect();
    return {x:r.left, y:r.top, w:r.width, h:r.height}; } catch(e){ return null; } }
  function effBg(el){
    var n = el;
    while (n && n.nodeType === 1) {
      try { var b = getComputedStyle(n).backgroundColor;
        if (b && b !== "transparent" && b.replace(/\s/g,"") !== "rgba(0,0,0,0)") return b;
      } catch(e){}
      n = n.parentElement;
    }
    return "#ffffff";
  }
  function info(el){
    if (!el) return null;
    var tag = (el.tagName||"").toLowerCase(), ml=false, val="", ok=false;
    if (tag === "input") {
      var ty = (el.type||"text").toLowerCase();
      if (["text","search","url","email","tel","number",""].indexOf(ty) < 0) return null;
      ok = true; val = el.value||"";
    } else if (tag === "textarea") { ok = true; ml = true; val = el.value||""; }
    if (!ok) return null;
    var cs=null; try { cs = getComputedStyle(el); } catch(e){}
    return { multiline: ml, value: val, rect: rectOf(el),
      fontSize: cs?cs.fontSize:"16px", fontFamily: cs?cs.fontFamily:"",
      lineHeight: cs?cs.lineHeight:"normal", color: cs?cs.color:"#000",
      bg: effBg(el),
      padTop: cs?cs.paddingTop:"0px", padLeft: cs?cs.paddingLeft:"0px",
      padRight: cs?cs.paddingRight:"0px", padBottom: cs?cs.paddingBottom:"0px",
      textAlign: cs?cs.textAlign:"start", dir: cs?cs.direction:"ltr",
      selStart: (el.selectionStart!=null?el.selectionStart:val.length),
      selEnd: (el.selectionEnd!=null?el.selectionEnd:val.length) };
  }
  var fTmr = 0;
  function pushFocus(){ try { B({t:"focus", info: info(document.activeElement)}); } catch(e){} }
  function pushFocusSoon(){ if (fTmr) return; fTmr = setTimeout(function(){ fTmr=0; pushFocus(); }, 60); }
  document.addEventListener("focusin", pushFocusSoon, true);
  document.addEventListener("focusout", function(){ setTimeout(pushFocus, 0); }, true);
  document.addEventListener("input", pushFocusSoon, true);
  document.addEventListener("scroll", pushFocusSoon, true);
  window.addEventListener("resize", pushFocusSoon, true);
  setTimeout(pushFocus, 400);
  // Cursor mirroring: report the page's effective cursor under the pointer so
  // the renderer can set its own CSS cursor (instant I-beam over text, pointer
  // over links) instead of a one-frame-late streamed one.
  var lastCur = "";
  document.addEventListener("mousemove", function(e){
    var c = "default";
    try { var el = e.target; if (el && el.nodeType === 1) { var v = getComputedStyle(el).cursor; if (v) c = v; } } catch(err){}
    if (c !== lastCur) { lastCur = c; B({t:"cursor", cursor:c}); }
  }, true);
  // Block new pages: a popup / new tab spawns a separate browser target that
  // steals the foreground and FREEZES this tab's screencast. Neutralise the
  // common page-level routes (window.open, target=_blank, middle/ctrl-click);
  // anything that still slips through the daemon closes. Each is reported so
  // the renderer can show a "popup blocked" notice.
  try { window.open = function(u){ B({t:"blocked", url: u ? String(u) : ""}); return null; }; } catch(e){}
  function blockNav(e){
    try {
      var a = e.target && e.target.closest ? e.target.closest("a[href],area[href]") : null;
      if (!a) return;
      var tgt = (a.getAttribute("target")||"").toLowerCase();
      var newTab = (tgt && tgt !== "_self" && tgt !== "_top" && tgt !== "_parent")
        || (e.type === "auxclick" && e.button === 1)
        || (e.type === "click" && (e.ctrlKey || e.metaKey));
      if (newTab) { e.preventDefault(); e.stopPropagation(); B({t:"blocked", url: a.href || ""}); }
    } catch(err){}
  }
  document.addEventListener("click", blockNav, true);
  document.addEventListener("auxclick", blockNav, true);
})();
"""

# Clamp client-requested viewport sizes. Sub-300px renders break most
# layouts (mobile sites fall back to a different breakpoint); 4K is the
# top end before Chrome starts allocating absurd surface memory.
_MIN_VIEWPORT = (320, 240)
_MAX_VIEWPORT = (3840, 2400)

# Clamp client-reported devicePixelRatio. 1 is a standard display; 3
# covers every real HiDPI panel — anything past that just multiplies
# Chrome's surface memory for no visible gain.
_MIN_DPR = 1.0
_MAX_DPR = 3.0

# Per-domain Chrome user-data dirs live under a root chosen by the
# browser's packaging (see ``_profile_root_for``): native installs get
# ``~/.collimate-chrome-profiles``; Flatpak/Snap browsers can only write
# inside their own sandbox, so their profiles go under ``~/.var/app`` /
# ``~/snap`` respectively. All roots live outside ``.collimate/`` so
# logins survive reinstalls.
_NATIVE_PROFILES_ROOT = os.path.expanduser("~/.collimate-chrome-profiles")

# Special-key dispatch table: renderer ``e.key`` →
# (windowsVirtualKeyCode, code, text). Chrome's default-action handling
# (caret moves, deletes, form submit) keys off the VK code, and Enter
# only commits text when the event carries a carriage return. Printable
# single-char keys don't need an entry — ``keyDown`` + ``text`` covers
# them (see ``_dispatch_key``).
_KEY_VK: dict[str, tuple[int, str, Optional[str]]] = {
    "Enter": (13, "Enter", "\r"),
    "Tab": (9, "Tab", None),
    "Backspace": (8, "Backspace", None),
    "Delete": (46, "Delete", None),
    "Escape": (27, "Escape", None),
    "ArrowLeft": (37, "ArrowLeft", None),
    "ArrowUp": (38, "ArrowUp", None),
    "ArrowRight": (39, "ArrowRight", None),
    "ArrowDown": (40, "ArrowDown", None),
    "Home": (36, "Home", None),
    "End": (35, "End", None),
    "PageUp": (33, "PageUp", None),
    "PageDown": (34, "PageDown", None),
    "Shift": (16, "ShiftLeft", None),
    "Control": (17, "ControlLeft", None),
    "Alt": (18, "AltLeft", None),
    "Meta": (91, "MetaLeft", None),
}

# CDP ``modifiers`` bitmask values, tracked across key events so
# shift-click / shift-arrow selection works.
_MODIFIER_BITS = {"Alt": 1, "Control": 2, "Meta": 4, "Shift": 8}

# CDP ``buttons`` bitmask values, tracked across pointer events so
# drags report the held button on every move.
_BUTTON_BITS = {"left": 1, "right": 2, "middle": 4}


# ---------------------------------------------------------------------------
# Anti-detection — make headless read as the ordinary desktop browser it
# actually is. ``--headless=new`` brands itself in two places bot checks
# (Cloudflare Turnstile, Google sign-in) look first:
#
#   * the User-Agent string says ``HeadlessChrome/<ver>`` and the
#     Sec-CH-UA client hints repeat it → fixed via
#     ``Emulation.setUserAgentOverride`` (one call fixes the HTTP
#     headers AND ``navigator.userAgentData`` consistently);
#   * WebGL's UNMASKED_VENDOR/RENDERER report "SwiftShader" — the
#     canonical "no GPU, I'm a server" signal → patched per-document
#     with a plausible GPU string for this OS.
#
# Deliberately NOT spoofed: ``navigator.webdriver`` (the launch flag
# ``--disable-blink-features=AutomationControlled`` already makes it the
# native ``false``), ``navigator.languages`` / ``deviceMemory`` /
# ``plugins`` (headless=new reports sane values, and redefining them as
# instance getters moves the property off Navigator.prototype — which
# reads as MORE automated, not less).
#
# The same override strings are applied in visible-window mode too, so
# a clearance cookie earned in the window stays valid when the session
# swaps back to headless (Cloudflare ties clearance to the UA).
# ---------------------------------------------------------------------------


def _webgl_strings() -> tuple[str, str]:
    """A plausible UNMASKED_VENDOR / UNMASKED_RENDERER pair for this OS —
    a macOS GPU string under a Linux UA would be its own mismatch."""
    if sys.platform == "darwin":
        return ("Google Inc. (Apple)",
                "ANGLE (Apple, ANGLE Metal Renderer: Apple M2, Unspecified Version)")
    if sys.platform.startswith("win"):
        return ("Google Inc. (Intel)",
                "ANGLE (Intel, Intel(R) UHD Graphics 630 Direct3D11 vs_5_0 ps_5_0, D3D11)")
    return ("Google Inc. (Intel)",
            "ANGLE (Intel, Mesa Intel(R) UHD Graphics (CML GT2), "
            "OpenGL 4.6 (Core Profile) Mesa 22.0.5)")


def _stealth_init_js() -> str:
    vend, rend = _webgl_strings()
    return (
        "if (!window.chrome) window.chrome = { runtime: {} };"
        "(() => {"
        "  const V = 0x9245, R = 0x9246;"
        f"  const VEND = {json.dumps(vend)};"
        f"  const REND = {json.dumps(rend)};"
        "  const patch = (proto) => {"
        "    if (!proto) return;"
        "    const gp = proto.getParameter;"
        "    proto.getParameter = function (p) {"
        "      if (p === V) return VEND;"
        "      if (p === R) return REND;"
        "      return gp.call(this, p);"
        "    };"
        "  };"
        "  patch(window.WebGLRenderingContext && WebGLRenderingContext.prototype);"
        "  patch(window.WebGL2RenderingContext && WebGL2RenderingContext.prototype);"
        "})();"
    )


def _ua_platform_metadata() -> tuple[str, str]:
    if sys.platform == "darwin":
        return "macOS", "13.6.0"
    if sys.platform.startswith("win"):
        return "Windows", "10.0.0"
    return "Linux", "6.6.0"


def _stealth_ua_override(real_ua: str, override: Optional[str]) -> tuple[str, dict]:
    """Build a Headless-free User-Agent + matching Client-Hints metadata
    for ``Emulation.setUserAgentOverride``.

    ``real_ua`` comes from the live browser (``Browser.getVersion``), so
    the cleaned string never drifts from the actual Chrome build — a
    version skew between the UA and the real JS engine is itself a
    tell. ``override``, when set, is used verbatim but still gets
    consistent Client-Hints derived from its Chrome/<ver> token.

    Returns ``("", {})`` when nothing needs overriding (already-clean UA
    in visible mode, no caller override) so real values stay untouched.
    """
    ua = override or real_ua.replace("HeadlessChrome", "Chrome")
    if not ua or (not override and ua == real_ua):
        return "", {}
    m = re.search(r"Chrome/(\d+(?:\.\d+)*)", ua)
    full = m.group(1) if m else "120.0.0.0"
    major = full.split(".")[0]
    platform_name, platform_version = _ua_platform_metadata()
    metadata = {
        "brands": [
            {"brand": "Chromium", "version": major},
            {"brand": "Google Chrome", "version": major},
            {"brand": "Not=A?Brand", "version": "24"},
        ],
        "fullVersionList": [
            {"brand": "Chromium", "version": full},
            {"brand": "Google Chrome", "version": full},
            {"brand": "Not=A?Brand", "version": "24.0.0.0"},
        ],
        "platform": platform_name,
        "platformVersion": platform_version,
        "architecture": "x86",
        "bitness": "64",
        "model": "",
        "mobile": False,
        "wow64": False,
    }
    return ua, metadata


class CDPError(RuntimeError):
    """A DevTools command failed or the connection died."""


class CDP:
    """Minimal JSON-RPC client for one DevTools page target.

    ``send`` issues a command and awaits its response; ``on`` registers
    a sync callback per event method. ``read_loop`` must run as a task
    for the lifetime of the connection — it routes responses to their
    futures and events to their listeners, and fails every pending
    future when the socket closes so callers don't hang."""

    def __init__(self, ws: aiohttp.ClientWebSocketResponse) -> None:
        self._ws = ws
        self._next_id = 1
        self._pending: dict[int, asyncio.Future] = {}
        self._listeners: dict[str, list[Callable[[dict], None]]] = {}

    def on(self, method: str, cb: Callable[[dict], None]) -> None:
        self._listeners.setdefault(method, []).append(cb)

    async def close(self) -> None:
        try:
            await self._ws.close()
        except Exception:
            pass

    async def send(
        self, method: str, params: Optional[dict] = None, *, timeout: float = 30.0
    ) -> dict:
        msg_id = self._next_id
        self._next_id += 1
        fut: asyncio.Future = asyncio.get_running_loop().create_future()
        self._pending[msg_id] = fut
        try:
            await self._ws.send_str(
                json.dumps({"id": msg_id, "method": method, "params": params or {}})
            )
        except Exception as exc:
            self._pending.pop(msg_id, None)
            raise CDPError(f"{method}: connection gone ({exc})") from exc
        try:
            return await asyncio.wait_for(fut, timeout)
        finally:
            self._pending.pop(msg_id, None)

    async def read_loop(self) -> None:
        try:
            async for msg in self._ws:
                if msg.type != aiohttp.WSMsgType.TEXT:
                    continue
                try:
                    data = json.loads(msg.data)
                except Exception:
                    continue
                if "id" in data:
                    fut = self._pending.get(data["id"])
                    if fut is not None and not fut.done():
                        if "error" in data:
                            fut.set_exception(CDPError(str(data["error"])))
                        else:
                            fut.set_result(data.get("result") or {})
                else:
                    for cb in self._listeners.get(data.get("method", ""), []):
                        try:
                            cb(data.get("params") or {})
                        except Exception as exc:
                            gen.log(f"CDP event handler failed: {exc}")
        finally:
            for fut in self._pending.values():
                if not fut.done():
                    fut.set_exception(CDPError("CDP connection closed"))
            self._pending.clear()


@dataclass
class CaptureContext:
    """Handle passed to capture callbacks. ``evaluate`` is the main
    attachment point — pass a zero-arg JS function source
    (``() => {...}``) and get its JSON-safe return value back."""
    cdp: CDP
    url: str
    capture_count: int  # 1-indexed; bumps before each on_capture call.
    # Whether a screencast is running (image render mode). screenshot_png
    # must pause/resume it; in dom mode there is nothing to pause.
    screencast: bool = True

    async def evaluate(self, js_function: str) -> Any:
        res = await self.cdp.send("Runtime.evaluate", {
            "expression": f"({js_function})()",
            "returnByValue": True,
            "awaitPromise": True,
        })
        details = res.get("exceptionDetails")
        if details:
            raise CDPError(str(details.get("text") or "evaluate failed"))
        return (res.get("result") or {}).get("value")

    async def html(self) -> str:
        return await self.evaluate("() => document.documentElement.outerHTML") or ""

    async def screenshot_png(self) -> bytes:
        # ``Page.captureScreenshot`` stalls while a screencast is
        # running — both ride the same frame-capture path. Pause the
        # cast for the shot and resume after (image mode only; dom mode
        # never starts one).
        if self.screencast:
            try:
                await self.cdp.send("Page.stopScreencast")
            except Exception:
                pass
        try:
            res = await self.cdp.send(
                "Page.captureScreenshot", {"format": "png"}, timeout=60.0
            )
            return base64.b64decode(res.get("data") or "")
        finally:
            if self.screencast:
                try:
                    await self.cdp.send("Page.startScreencast", _SCREENCAST_PARAMS)
                except Exception:
                    pass


@dataclass
class _SessionState:
    clients: set[web.WebSocketResponse] = field(default_factory=set)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    # Bound once the CDP connection is up so the WS handler can route
    # client-originated input into the live browser. ``buttons`` /
    # ``modifiers`` persist input state across events (CDP events are
    # stateless — drags and shift-selection need the running mask).
    cdp: Optional[CDP] = None
    viewport: tuple[int, int] = (1280, 800)
    # Renderer-reported devicePixelRatio, applied as Chrome's
    # deviceScaleFactor so HiDPI clients get frames at their physical
    # resolution instead of a CSS-pixel image upscaled by the display.
    dpr: float = 1.0
    main_frame_id: str = ""
    # Main-frame URL, kept current across link clicks / redirects /
    # renderer nav messages so address-bar renderers can follow along.
    current_url: str = ""
    buttons: int = 0
    modifiers: int = 0
    # Visual transport: "image" streams screencast JPEGs; "live" runs the real
    # page in a native iframe via the reverse proxy below (no screencast).
    # Fixed for the session's lifetime.
    render_mode: str = "image"
    # Live mode: the origin (scheme://host[:port]) the subdomain reverse-proxies
    # right now. Seeded from the initial URL, updated by the /__collimate/go nav
    # bootstrap. Empty in image mode.
    live_target_origin: str = ""
    # This session's subdomain token (``<token>.<app>``). Lets the daemon turn a
    # frame subdomain (``<extra>.<token>.<app>``, used for cross-origin sub-frames
    # that are subdomains of the primary — e.g. claude's ``a.claude.ai``) back
    # into the real origin ``<extra>.<primary-host>``.
    live_token: str = ""
    last_frame: Optional[str] = None  # base64 JPEG, no data: prefix (image mode)
    # Shared client session + live UA string for the reverse proxy's outbound
    # fetches (live mode), where the cookies/UA are injected so the framed page
    # presents the live browser's session.
    http: Optional[aiohttp.ClientSession] = None
    ua: str = ""
    # Window-visibility control. The browser runs headless by default
    # (hidden — only the cell renders it). A renderer "Open window"
    # message flips ``want_headful`` True; the run loop notices the
    # mismatch with the live mode and relaunches the SAME profile
    # visibly so the user can clear a Cloudflare / sign-in challenge a
    # headless browser keeps looping on. ``headful`` mirrors the live
    # mode so the renderer can show the right button label.
    want_headful: bool = False
    headful: bool = False


@dataclass
class _Chrome:
    # None when this cell ATTACHED to a Chrome another same-session cell
    # launched (shared browser, multi-tab) — we drive our own tab over CDP but
    # don't own the OS process, so there's no handle to wait on or signal.
    proc: Optional[asyncio.subprocess.Process]
    port: int
    stderr_tail: deque


# ---------------------------------------------------------------------------
# Browser discovery — mirrors the collimate app launcher
# (api/collimate_app_launcher.py) so a generator drives the SAME browser
# the desktop app opens: the user's default if it's Chromium-family,
# else the first Chromium-family browser found. Host code can't be
# imported from a generator subprocess (it runs standalone with only the
# SDK on its path), so the relevant tables are ported here. Firefox/Safari
# are intentionally absent — CDP screencast is Chromium-only.
#
# Each entry is ``(desktop_keys, binaries)``. ``binaries`` are tried in
# order: absolute paths checked for existence, bare names resolved via
# PATH. Forks with longer keys precede the generic ``chromium`` entry so
# their desktop id matches first.
# ---------------------------------------------------------------------------

_FLATPAK_BIN_ROOTS = (
    "/var/lib/flatpak/exports/bin",
    os.path.expanduser("~/.local/share/flatpak/exports/bin"),
)


def _linux_chromium_table() -> list[tuple[list[str], list[str]]]:
    home = os.path.expanduser("~")
    table: list[tuple[list[str], list[str]]] = [
        (["google-chrome"],
         ["google-chrome", "google-chrome-stable",
          "google-chrome-beta", "google-chrome-unstable"]),
        (["ungoogled-chromium"], ["ungoogled-chromium"]),
        (["thorium-browser", "thorium"], ["thorium-browser", "thorium"]),
        (["brave-browser", "brave"],
         ["brave-browser", "brave-browser-stable", "brave-browser-beta",
          "brave-browser-nightly", "brave"]),
        (["microsoft-edge"],
         ["microsoft-edge", "microsoft-edge-stable",
          "microsoft-edge-beta", "microsoft-edge-dev"]),
        (["vivaldi"], ["vivaldi", "vivaldi-stable", "vivaldi-snapshot"]),
        (["opera"], ["opera", "opera-stable", "opera-beta"]),
        (["yandex-browser", "yandex"],
         ["yandex-browser", "yandex-browser-stable"]),
        (["chromium"], ["chromium", "chromium-browser"]),
    ]
    # Flatpak: the export-bin wrapper accepts the same flags as the native
    # binary and runs the sandboxed Chrome. ``_profile_root_for`` keeps its
    # profile inside ``~/.var/app`` where the sandbox can write.
    flatpaks = [
        (["com.google.chrome"], "com.google.Chrome"),
        (["io.github.ungoogled_software.ungoogled_chromium",
          "ungoogled-chromium"], "io.github.ungoogled_software.ungoogled_chromium"),
        (["org.chromium.chromium"], "org.chromium.Chromium"),
        (["com.brave.browser"], "com.brave.Browser"),
        (["com.microsoft.edge"], "com.microsoft.Edge"),
        (["com.vivaldi.vivaldi"], "com.vivaldi.Vivaldi"),
    ]
    for keys, app_id in flatpaks:
        wrappers = [os.path.join(r, app_id) for r in _FLATPAK_BIN_ROOTS]
        table.append(([app_id.lower(), *keys], wrappers))
    # Snap: ``<name>_<name>`` desktop ids; ``_profile_root_for`` keeps the
    # profile under ``~/snap/<name>/current``.
    for name in ("chromium", "brave", "microsoft-edge"):
        table.append(([f"{name}_{name}", name], [os.path.join("/snap/bin", name)]))
    return table


def _macos_chromium_table() -> list[tuple[list[str], list[str]]]:
    return [
        (["com.google.chrome"],
         ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]),
        (["org.chromium.chromium"],
         ["/Applications/Chromium.app/Contents/MacOS/Chromium"]),
        (["com.brave.browser"],
         ["/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"]),
        (["com.microsoft.edgemac"],
         ["/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"]),
        (["com.vivaldi.vivaldi"],
         ["/Applications/Vivaldi.app/Contents/MacOS/Vivaldi"]),
        (["company.thebrowser"], ["/Applications/Arc.app/Contents/MacOS/Arc"]),
    ]


def _windows_chromium_table() -> list[tuple[list[str], list[str]]]:
    localapp = os.environ.get("LOCALAPPDATA", "")
    progf = os.environ.get("ProgramFiles", "C:/Program Files")
    progf86 = os.environ.get("ProgramFiles(x86)", "C:/Program Files (x86)")
    j = os.path.join
    return [
        (["chrome"], [j(progf, "Google/Chrome/Application/chrome.exe"),
                      j(progf86, "Google/Chrome/Application/chrome.exe"),
                      j(localapp, "Google/Chrome/Application/chrome.exe")]),
        (["brave"], [j(progf, "BraveSoftware/Brave-Browser/Application/brave.exe"),
                     j(localapp, "BraveSoftware/Brave-Browser/Application/brave.exe")]),
        (["msedge"], [j(progf, "Microsoft/Edge/Application/msedge.exe"),
                      j(progf86, "Microsoft/Edge/Application/msedge.exe")]),
        (["chromium"], [j(localapp, "Chromium/Application/chrome.exe")]),
        (["vivaldi"], [j(localapp, "Vivaldi/Application/vivaldi.exe")]),
    ]


def _chromium_table() -> list[tuple[list[str], list[str]]]:
    s = sys.platform
    if s.startswith("linux"):
        return _linux_chromium_table()
    if s == "darwin":
        return _macos_chromium_table()
    if s.startswith("win"):
        return _windows_chromium_table()
    return []


def _resolve_binary(binaries: list[str]) -> Optional[str]:
    for b in binaries:
        if os.path.isabs(b) or b.endswith(".exe"):
            if os.path.isfile(b):
                return b
        else:
            found = shutil.which(b)
            if found:
                return found
    return None


def _default_browser_id() -> str:
    """Return the OS's default-browser identifier (lower-cased), or ''."""
    try:
        if sys.platform.startswith("linux"):
            out = subprocess.run(
                ["xdg-settings", "get", "default-web-browser"],
                capture_output=True, text=True, timeout=3,
            ).stdout.strip()
            return out.lower().removesuffix(".desktop")
        if sys.platform == "darwin":
            # LaunchServices http handler bundle id.
            plist = os.path.expanduser(
                "~/Library/Preferences/com.apple.LaunchServices/"
                "com.apple.launchservices.secure.plist"
            )
            if os.path.isfile(plist):
                out = subprocess.run(
                    ["plutil", "-convert", "json", "-o", "-", plist],
                    capture_output=True, text=True, timeout=3,
                ).stdout
                data = json.loads(out or "{}")
                for h in data.get("LSHandlers", []):
                    if h.get("LSHandlerURLScheme") == "http":
                        return (h.get("LSHandlerRoleAll")
                                or h.get("LSHandlerRoleViewer") or "").lower()
        if sys.platform.startswith("win"):
            import winreg  # type: ignore[import-not-found]
            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\Shell\Associations"
                r"\UrlAssociations\http\UserChoice",
            ) as key:
                return str(winreg.QueryValueEx(key, "ProgId")[0]).lower()
    except Exception:
        pass
    return ""


def _find_chrome(explicit: Optional[str]) -> str:
    """Pick the browser binary the same way the desktop app does: an
    explicit override wins; else the OS default browser if it's
    Chromium-family; else the first Chromium-family browser found."""
    if explicit:
        found = shutil.which(explicit) or (
            explicit if os.path.isfile(explicit) else None
        )
        if not found:
            raise RuntimeError(f"Browser binary not found at '{explicit}'.")
        return found

    table = _chromium_table()
    default_id = _default_browser_id()
    if default_id:
        for keys, binaries in table:
            if any(k in default_id for k in keys):
                found = _resolve_binary(binaries)
                if found:
                    return found
    for _keys, binaries in table:
        found = _resolve_binary(binaries)
        if found:
            return found
    raise RuntimeError(
        "No Chromium-family browser found (scanned PATH, Flatpak exports, "
        "and Snap). Install Chrome / Chromium / Brave / Edge, or set the "
        "chrome_path setting. Firefox/Safari can't be driven over CDP."
    )


def _profile_root_for(chrome_bin: str) -> str:
    """Root dir for per-domain profiles, chosen so the browser can write
    it. Flatpak/Snap browsers are sandboxed and can only write inside
    their own data area — an arbitrary host path is denied — so their
    profiles live there; native installs use the host root."""
    home = os.path.expanduser("~")
    for root in _FLATPAK_BIN_ROOTS:
        if chrome_bin.startswith(root + os.sep):
            app_id = os.path.basename(chrome_bin)
            return os.path.join(home, ".var/app", app_id,
                                "data", "collimate-chrome-profiles")
    if chrome_bin.startswith("/snap/bin/"):
        name = os.path.basename(chrome_bin)
        return os.path.join(home, "snap", name, "current",
                            "collimate-chrome-profiles")
    return _NATIVE_PROFILES_ROOT


def _safe_path_token(raw: str, fallback: str = "default") -> str:
    """Collapse anything outside [a-z0-9.-] to underscores so a hostname
    or user-typed profile name can't escape the profiles root via path
    traversal."""
    return re.sub(r"[^a-z0-9.\-]", "_", (raw or "").lower()) or fallback


def _profile_dir_for(url: str, chrome_bin: str, profile_name: str = "default") -> str:
    """Resolve the persistent-profile directory for ``url`` under the
    named profile ``profile_name``.

    Cookies + storage are keyed by ``(profile_name, hostname)``: all
    cells that share a profile name AND a domain resume the same login,
    while a different name is a separate session (fresh, or one another
    cell created). ``default`` keeps the legacy host-only path so logins
    created before named profiles existed still resolve.

    Both the name and the hostname are sanitised before use so an
    arbitrary URL or name can't escape the profiles root."""
    host = _safe_path_token(urlparse(url).hostname or "default")
    root = _profile_root_for(chrome_bin)
    name = _safe_path_token(profile_name)
    # 'default' → legacy root/<host> (preserves pre-named-profile logins).
    # Any other name → root/<name>/<host> (an independent session bucket).
    path = os.path.join(root, host) if name == "default" \
        else os.path.join(root, "_named", name, host)
    os.makedirs(path, exist_ok=True)
    return path


async def _devtools_port_if_live(profile_dir: str, http: aiohttp.ClientSession) -> int:
    """Return the DevTools port of a Chrome already running on
    ``profile_dir`` (its ``DevToolsActivePort`` resolves to a server that
    answers ``/json/version``), else 0.

    Lets the caller tell a genuinely-live profile from a stale lock left
    by a crash: a live one means another same-session cell already runs a
    Chrome on this user-data dir, so we ATTACH to it and open our own tab
    rather than launch a second (conflicting) instance."""
    port_file = os.path.join(profile_dir, "DevToolsActivePort")
    try:
        with open(port_file, encoding="utf-8") as f:
            port = int(f.readline().strip())
    except (OSError, ValueError):
        return 0
    if port <= 0:
        return 0
    try:
        async with http.get(f"http://127.0.0.1:{port}/json/version",
                            timeout=aiohttp.ClientTimeout(total=2.0)) as resp:
            if resp.status == 200:
                return port
    except Exception:
        pass
    return 0


# ---------------------------------------------------------------------------
# Shared-browser session refcount + multi-tab attach
#
# Cells that share a session (same profile name + host) share ONE Chrome —
# each cell drives its own TAB (CDP page target), so they behave like tabs in
# one logged-in browser. Cells are independent OS processes, so the shared
# Chrome's lifetime is refcounted across them by a directory of PID marker
# files in the profile dir: the cell that finds itself the last one out closes
# the browser; a crashed cell's marker is reaped by PID liveness. A per-profile
# launch lock serializes the launch-vs-attach decision so a startup race
# doesn't spawn two Chromes on the same user-data dir.
# ---------------------------------------------------------------------------


def _pid_alive(pid: int) -> bool:
    """Best-effort: is the process owning a marker still running?"""
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
            if handle:
                ctypes.windll.kernel32.CloseHandle(handle)
                return True
            return False
        except Exception:
            return True  # can't tell → keep the marker (don't kill the browser)
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except OSError:
        return True  # exists but not signalable by us
    return True


def _session_marker_dir(profile_dir: str) -> str:
    d = os.path.join(profile_dir, ".collimate-cells")
    os.makedirs(d, exist_ok=True)
    return d


def _live_session_cells(profile_dir: str) -> list[int]:
    """PIDs of cells currently sharing this profile, pruning dead markers."""
    d = _session_marker_dir(profile_dir)
    live: list[int] = []
    for name in os.listdir(d):
        try:
            pid = int(name)
        except ValueError:
            continue
        if _pid_alive(pid):
            live.append(pid)
        else:
            try:
                os.unlink(os.path.join(d, name))
            except OSError:
                pass
    return live


def _register_session_cell(profile_dir: str) -> str:
    """Drop this cell's PID marker into the session and return its path."""
    path = os.path.join(_session_marker_dir(profile_dir), str(os.getpid()))
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(str(os.getpid()))
    except OSError:
        pass
    return path


def _release_session_cell(marker_path: str) -> None:
    try:
        os.unlink(marker_path)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Live-mode subdomain registry
#
# The host's session_proxy middleware routes <token>.<apphost> → this daemon's
# loopback port, giving each live cell its own clean browser ORIGIN — what the
# reverse proxy needs so the target page's relative URLs + same-origin API calls
# resolve back through us. Login flows across same-session cells through the
# shared Chrome profile + the proxy's cookie injection. The registry is a marker
# file the middleware polls; we heartbeat its mtime and remove it on exit.
# NOTE: _SESSION_DAEMON_DIR mirrors api/routes/session_proxy.py REGISTRY_DIR —
# keep the two paths in sync.
# ---------------------------------------------------------------------------
_SESSION_DAEMON_DIR = os.path.expanduser("~/.collimate-session-daemons")


def _live_token(run_id: str, port: int) -> str:
    """A short, DNS-label-safe token unique to this cell's daemon."""
    return "cl" + hashlib.sha256(f"{run_id}:{port}".encode("utf-8")).hexdigest()[:20]


def _write_session_marker(token: str, port: int) -> str:
    os.makedirs(_SESSION_DAEMON_DIR, exist_ok=True)
    path = os.path.join(_SESSION_DAEMON_DIR, token)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"port": port, "pid": os.getpid()}, f)
    except OSError:
        pass
    return path


async def _heartbeat_session_marker(path: str) -> None:
    """Touch the marker's mtime so the middleware's freshness TTL keeps routing."""
    while True:
        await asyncio.sleep(10)
        try:
            os.utime(path, None)
        except OSError:
            pass


def _remove_session_marker(path: str) -> None:
    if not path:
        return
    try:
        os.unlink(path)
    except OSError:
        pass


async def _acquire_launch_lock(profile_dir: str, timeout: float = 60.0):
    """Atomically claim the right to launch (vs attach) this profile's Chrome.
    Returns an ``(fd, path)`` handle for ``_release_launch_lock``, or None if it
    timed out (caller proceeds best-effort — Chrome's own SingletonLock is the
    final backstop). A lock whose owner PID is dead is broken."""
    path = os.path.join(profile_dir, ".collimate-launch.lock")
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout
    while True:
        try:
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            try:
                os.write(fd, str(os.getpid()).encode())
            except OSError:
                pass
            return (fd, path)
        except FileExistsError:
            owner = 0
            try:
                with open(path, encoding="utf-8") as f:
                    owner = int(f.readline().strip() or 0)
            except (OSError, ValueError):
                owner = 0
            if owner and not _pid_alive(owner):
                try:
                    os.unlink(path)
                except OSError:
                    pass
                continue
            if loop.time() >= deadline:
                return None
            await asyncio.sleep(0.2)


def _release_launch_lock(handle) -> None:
    if not handle:
        return
    fd, path = handle
    try:
        os.unlink(path)
    except OSError:
        pass
    try:
        os.close(fd)
    except OSError:
        pass


async def _browser_ws_url(http: aiohttp.ClientSession, port: int) -> str:
    """The browser-level DevTools WebSocket (used to open new tabs). Timed so a
    wedged browser can't hang attach or teardown (this runs in _close_own_tab)."""
    async with http.get(f"http://127.0.0.1:{port}/json/version",
                        timeout=aiohttp.ClientTimeout(total=5.0)) as resp:
        data = await resp.json()
    url = data.get("webSocketDebuggerUrl")
    if not url:
        raise RuntimeError(f"no browser webSocketDebuggerUrl on port {port}")
    return url


async def _reap_orphan_browsers(
    http: aiohttp.ClientSession, chrome_bin: str, skip_dir: str,
) -> None:
    """Startup sweep: close Chromes whose owning cells are all gone.

    A Force Stop / crash / SIGKILL skips the run loop's teardown, and the
    browser lives in its OWN session (start_new_session) with no container
    label — no process-group kill or docker reaper ever reaches it. Its only
    scheduled cleanup was "adoption on the next same-profile launch", which
    may never come. So every CDP daemon startup sweeps ALL profiles under
    this browser's root: any profile with a live DevTools endpoint but zero
    live cell markers is an orphan, and gets a clean ``Browser.close``.
    Requires nothing from generator authors. Best-effort — a wedged browser
    that ignores Browser.close is left alone (we hold no PID for it).
    """
    root = _profile_root_for(chrome_bin)
    candidates: list[str] = []
    try:
        for entry in os.listdir(root):
            path = os.path.join(root, entry)
            if not os.path.isdir(path):
                continue
            if entry == "_named":
                try:
                    for name in os.listdir(path):
                        named = os.path.join(path, name)
                        if not os.path.isdir(named):
                            continue
                        for host in os.listdir(named):
                            candidates.append(os.path.join(named, host))
                except OSError:
                    pass
            else:
                candidates.append(path)
    except OSError:
        return
    skip = os.path.abspath(skip_dir)
    for profile_dir in candidates:
        if os.path.abspath(profile_dir) == skip:
            continue  # our own profile — owned by the normal run lifecycle
        try:
            await _reap_orphan_browser(http, profile_dir)
        except Exception:
            pass  # sweep is best-effort; never disturb the actual run


async def _reap_orphan_browser(
    http: aiohttp.ClientSession, profile_dir: str,
) -> None:
    """Close the browser on ``profile_dir`` iff nothing owns it. Both checks
    are re-run under the profile's launch lock so we can't race a cell that
    is attaching or launching on this profile right now."""
    if _live_session_cells(profile_dir):
        return
    if not await _devtools_port_if_live(profile_dir, http):
        return
    lock = await _acquire_launch_lock(profile_dir, timeout=5.0)
    if lock is None:
        return  # someone is actively launching/attaching — not an orphan
    try:
        if _live_session_cells(profile_dir):
            return
        port = await _devtools_port_if_live(profile_dir, http)
        if not port:
            return
        gen.log(f"[reap] closing orphaned browser on "
                f"{os.path.basename(profile_dir)} (port {port})")
        ws = await asyncio.wait_for(
            http.ws_connect(await _browser_ws_url(http, port), max_msg_size=0),
            timeout=5.0,
        )
        cdp = CDP(ws)
        reader = asyncio.get_running_loop().create_task(cdp.read_loop())
        try:
            await cdp.send("Browser.close", timeout=5.0)
        finally:
            reader.cancel()
            await cdp.close()
    finally:
        _release_launch_lock(lock)


async def _open_tab(http: aiohttp.ClientSession, port: int, url: str) -> str:
    """Open a new tab in an already-running Chrome (via Target.createTarget on
    the browser endpoint) and return its page DevTools WebSocket URL."""
    ws = await http.ws_connect(await _browser_ws_url(http, port), max_msg_size=0)
    cdp = CDP(ws)
    reader = asyncio.get_running_loop().create_task(cdp.read_loop())
    try:
        res = await cdp.send("Target.createTarget", {"url": url})
        target_id = res.get("targetId")
        if not target_id:
            raise RuntimeError("Target.createTarget returned no targetId")
        return f"ws://127.0.0.1:{port}/devtools/page/{target_id}"
    finally:
        reader.cancel()
        await cdp.close()


def _target_id_from_ws(page_ws: str) -> str:
    """The target id is the last path segment of a page DevTools WS URL."""
    return page_ws.rstrip("/").rsplit("/", 1)[-1]


async def _launch_chrome(
    chrome_bin: str,
    *,
    profile_dir: str,
    url: str,
    viewport: tuple[int, int],
    headful: bool = False,
    xvfb: bool = False,
) -> _Chrome:
    """Spawn Chrome with an ephemeral DevTools port and wait for the
    profile's ``DevToolsActivePort`` file to announce it.

    ``headful`` runs a real, visible window (no ``--headless=new``) so
    the user can clear a bot challenge by hand; the default hidden mode
    only ever shows through the cell. Either way the same profile dir is
    used, so cookies — including a Cloudflare clearance — carry across a
    mode switch.

    ``xvfb`` (Linux only) runs the *hidden* mode as a real, non-headless
    browser on an Xvfb virtual display via ``xvfb-run`` — invisible to the
    user, but a real display, so display-gated bot checks (Cloudflare
    Turnstile) treat it like a normal window instead of headless. Ignored
    (falls back to ``--headless=new``) when not on Linux, when ``xvfb-run``
    isn't installed, or in headful mode (which wants a real visible window)."""
    port_file = os.path.join(profile_dir, "DevToolsActivePort")
    # Chrome's profile lock embeds hostname+PID; after a crash it reads
    # as held forever. A live second instance on the same profile would
    # exit instead of serving DevTools, which the port-file wait below
    # surfaces — so any lock present now is presumed stale. Same for a
    # leftover port file, which would otherwise feed us a dead port.
    for stale in ("SingletonLock", "SingletonSocket", "SingletonCookie"):
        try:
            os.unlink(os.path.join(profile_dir, stale))
        except OSError:
            pass
    try:
        os.unlink(port_file)
    except OSError:
        pass

    use_xvfb = (not headful and xvfb and sys.platform.startswith("linux")
                and shutil.which("xvfb-run") is not None)
    # Off Xvfb the OS window size is cosmetic — device metrics drive the
    # captured frame. On Xvfb (a real headful window) it must cover the
    # screencast's device-pixel ceiling, or HiDPI renders larger than the
    # window leave un-painted (blank) regions in the captured frame.
    win_w, win_h = (_SCREENCAST_MAX_W, _SCREENCAST_MAX_H) if use_xvfb else viewport
    args = [
        chrome_bin,
        "--remote-debugging-port=0",
        f"--user-data-dir={profile_dir}",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-blink-features=AutomationControlled",
        f"--window-size={win_w},{win_h}",
    ]
    if headful:
        # Real visible window on the desktop display (manual challenge-solving).
        pass
    elif use_xvfb:
        # Real rendering on a hidden virtual display — keep the (non-foreground)
        # window painting so the screencast doesn't freeze.
        args += ["--disable-features=CalculateNativeWinOcclusion",
                 "--disable-backgrounding-occluded-windows",
                 "--disable-renderer-backgrounding"]
    else:
        # Xvfb is on by default but only applies on Linux with xvfb-run
        # present. Off Linux that's expected — stay quiet. On Linux without
        # the package, spell out the install so the user can actually act on
        # it; either way fall back to plain headless.
        if xvfb and sys.platform.startswith("linux"):
            gen.log(
                "[xvfb] `xvfb-run` not found — falling back to headless, which "
                "Cloudflare's checkbox and other display-gated bot checks will "
                "block. Install the Xvfb package to render on a hidden virtual "
                "display (a real, non-headless window): `sudo apt install xvfb` "
                "on Debian/Ubuntu, `sudo dnf install xorg-x11-server-Xvfb` on "
                "Fedora/RHEL, `sudo pacman -S xorg-server-xvfb` on Arch. It is "
                "then detected and used automatically — just re-run this cell."
            )
        # Hidden mode: the live page is only ever seen through the cell's
        # renderer.
        args.append("--headless=new")
    args.append(url)
    # Wrap in xvfb-run: it picks a free display, exports DISPLAY for Chrome, and
    # tears the virtual display down when Chrome exits — so the shared-browser
    # lifecycle stays correct with no extra process to track.
    if use_xvfb:
        # The virtual display matches the screencast's max device-pixel frame
        # (_SCREENCAST_MAX_W/H) — the largest surface the screencast ever
        # emits. The renderer drives the live viewport dynamically, so the
        # screen can't track it (Xvfb can't live-resize); sizing to the frame
        # ceiling holds any cell at any DPR without clipping, and a cell that
        # would render larger is clamped by the screencast anyway.
        sw, sh = _SCREENCAST_MAX_W, _SCREENCAST_MAX_H
        args = [
            "xvfb-run", "--auto-servernum",
            f"--server-args=-screen 0 {sw}x{sh}x24 -nolisten tcp",
        ] + args
        gen.log(f"[xvfb] {os.path.basename(chrome_bin)} on a {sw}x{sh} virtual "
                "display (hidden, real rendering — passes display-gated bot checks)")

    # Flatpak/Snap browsers run via their export-bin / /snap/bin wrapper,
    # which launches the sandboxed Chrome. ``profile_dir`` is chosen by
    # ``_profile_root_for`` to live inside that sandbox's writable data
    # area, so DevToolsActivePort lands on a host path we can poll — no
    # ``--filesystem`` override needed.
    # start_new_session detaches Chrome into its OWN process group so it
    # survives the launching cell's exit — the host stops a cell with
    # os.killpg(), which would otherwise take the shared browser (and every
    # other cell's tab) down with the launcher. Lifetime is then governed by
    # the refcounted teardown (last cell calls Browser.close) and adoption of
    # any orphan on the next same-session launch. (POSIX only; on Windows the
    # browser stays in-group and sharing degrades to one cell at a time.)
    proc = await asyncio.create_subprocess_exec(
        *args,
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.PIPE,
        start_new_session=(os.name != "nt"),
    )

    # Keep the last stderr lines around — they're the only diagnostics
    # when Chrome dies before DevTools comes up.
    tail: deque = deque(maxlen=40)

    async def _drain() -> None:
        assert proc.stderr is not None
        async for raw in proc.stderr:
            tail.append(raw.decode("utf-8", "replace").rstrip())

    asyncio.get_running_loop().create_task(_drain())

    # Anything that unwinds past this point without returning a _Chrome —
    # the DevToolsActivePort timeout below, or a CancelledError landing in
    # the poll loop — must kill the tree it spawned: the caller never got a
    # handle, and the detached-session Chrome is unreachable by any other
    # teardown (no process-group kill hits it, no container label reaps it).
    try:
        deadline = asyncio.get_running_loop().time() + 30.0
        while asyncio.get_running_loop().time() < deadline:
            if proc.returncode is not None:
                raise RuntimeError(
                    f"Chrome exited (rc={proc.returncode}) before DevTools came "
                    "up. Last output:\n" + "\n".join(tail)
                )
            try:
                with open(port_file, encoding="utf-8") as f:
                    port = int(f.readline().strip())
                if port > 0:
                    return _Chrome(proc=proc, port=port, stderr_tail=tail)
            except (OSError, ValueError):
                pass
            await asyncio.sleep(0.25)

        raise RuntimeError(
            "Chrome started but never wrote DevToolsActivePort within 30s. "
            "Last output:\n" + "\n".join(tail)
        )
    except BaseException:
        await _kill_chrome_proc_tree(proc)
        raise


async def _kill_chrome_proc_tree(proc, *, grace: float = 3.0) -> None:
    """Best-effort teardown of a Chrome (or xvfb-run wrapper) we spawned.

    The process was started with ``start_new_session=True``, so it leads its
    own process group: signal the WHOLE group so the xvfb-run wrapper, the
    Xvfb server and Chrome itself all go down together — ``proc.terminate()``
    alone only hits the wrapper and orphans its children. SIGTERM first,
    escalate to SIGKILL after ``grace``.
    """
    if proc is None or proc.returncode is not None:
        return

    def _signal(force: bool) -> None:
        if os.name == "nt":
            try:
                (proc.kill if force else proc.terminate)()
            except (ProcessLookupError, OSError):
                pass
            return
        sig = signal.SIGKILL if force else signal.SIGTERM
        try:
            os.killpg(os.getpgid(proc.pid), sig)
        except (ProcessLookupError, PermissionError, OSError):
            try:
                proc.send_signal(sig)
            except (ProcessLookupError, OSError):
                pass

    _signal(force=False)
    try:
        await asyncio.wait_for(proc.wait(), timeout=grace)
        return
    except asyncio.TimeoutError:
        pass
    except asyncio.CancelledError:
        # Being torn down ourselves — make sure the group still dies.
        _signal(force=True)
        raise
    _signal(force=True)
    try:
        await asyncio.wait_for(proc.wait(), timeout=grace)
    except asyncio.TimeoutError:
        pass


async def _page_ws_url(http: aiohttp.ClientSession, port: int) -> str:
    """Poll ``/json/list`` until the first page target shows up and
    return its DevTools WebSocket URL."""
    deadline = asyncio.get_running_loop().time() + 15.0
    last_exc: Optional[Exception] = None
    while asyncio.get_running_loop().time() < deadline:
        try:
            async with http.get(f"http://127.0.0.1:{port}/json/list") as resp:
                targets = await resp.json()
            for t in targets or []:
                if t.get("type") == "page" and t.get("webSocketDebuggerUrl"):
                    return t["webSocketDebuggerUrl"]
        except Exception as exc:
            last_exc = exc
        await asyncio.sleep(0.25)
    raise RuntimeError(f"No DevTools page target on port {port} ({last_exc})")


async def run_cdp_daemon(
    *,
    url: str,
    cell_name: str = "Live Browser",
    cell_summary: Optional[str] = None,
    viewport: tuple[int, int] = (1280, 800),
    user_agent: Optional[str] = None,
    page_inject_js: str = "",
    on_capture: Optional[Callable[[CaptureContext], Awaitable[None]]] = None,
    capture_button_label: str = "",
    artifact_filename: str = "session.webview",
    profile_dir: Optional[str] = None,
    chrome_path: Optional[str] = None,
    render_mode: str = "image",
    profile_name: str = "default",
    xvfb: bool = False,
) -> None:
    """Run a live-browser daemon over raw CDP. Daemon-shaped: returns
    only when the user hits Stop (or an exception escapes the run loop).

    Parameters
    ----------
    url : the URL to load. ``http://`` / ``https://`` prefix optional;
        added automatically when missing.
    cell_name / cell_summary : initial cell display fields.
    viewport : (width, height) tuple for both the browser and the
        renderer's playback canvas.
    user_agent : optional override, applied via
        ``Emulation.setUserAgentOverride``. ``None`` = Chrome's default.
    page_inject_js : extra JavaScript injected on every navigation
        before page scripts run (``Page.addScriptToEvaluateOnNewDocument``).
    on_capture : optional async callback. When supplied, a "capture"
        action from the renderer triggers ``await on_capture(ctx)`` —
        the callback uses ``ctx.evaluate(...)`` / ``ctx.html()`` /
        ``ctx.screenshot_png()`` to scrape page state and emits new
        cells via ``gen.create_stack_cell``.
    capture_button_label : shown on the renderer's top-bar button. The
        renderer only renders the button when this is non-empty.
    artifact_filename : the staged file the renderer reads. The default
        ``session.webview`` is what the webview renderer claims.
    profile_dir : browser user-data dir for persistent cookies + storage.
        ``None`` (default) derives one from ``profile_name`` + the URL's
        host (root depends on the browser's packaging — native vs
        Flatpak/Snap sandbox).
    chrome_path : explicit browser binary; ``None`` picks the same browser
        the desktop app opens — the OS default if Chromium-family, else
        the first Chromium-family browser found (PATH / Flatpak / Snap).
    profile_name : names the login bucket. Cells sharing a name AND a
        domain resume the same session; a different name is an
        independent session (so two cells with different names run
        concurrently without fighting over the profile lock). ``default``
        maps to the legacy per-host path so pre-existing logins survive.
        Two cells with the SAME name and domain can't run at once (one
        Chrome per user-data dir) — the second exits early with a note
        telling the user to pick a different name.
    render_mode : ``"image"`` (default) streams CDP screencast JPEGs and
        forwards renderer input back over CDP. ``"live"`` runs the real
        page in a native iframe served by this server's reverse proxy (on
        the cell's subdomain): no screencast, no input forwarding
        (interaction is native). The proxy makes each outbound request
        carrying the live browser's cookies and strips ``X-Frame-Options``
        / CSP ``frame-ancestors`` so the page embeds and stays logged in.
        Unknown values fall back to ``"image"``.

    The browser starts hidden (``--headless=new``) — the session is
    seen and driven through the cell's renderer, with the UA / Client
    Hints / WebGL tells scrubbed so headless reads as a normal desktop
    browser. If a bot check still loops, a renderer "Open window"
    message relaunches the SAME profile as a real visible window for
    manual solving; the earned clearance cookie carries back when the
    window is closed and the session returns to hidden mode.
    """
    mode = render_mode if render_mode in ("image", "live") else "image"
    state = _SessionState(viewport=(viewport[0], viewport[1]), render_mode=mode)
    full_url = _normalise_url(url)

    # Identity first — the cell shows what it is while the browser warms up.
    await gen.update(name=cell_name, summary=cell_summary or f"Opening {full_url}…")
    gen.phase("spinning_up", "launching browser")

    port = _find_free_port(9100)
    # The host-relative path the renderer reaches this server through (the
    # app reverse-proxies it to 127.0.0.1:port). The renderer opens the
    # control WebSocket (/__collimate/ws) off this base in both render modes.
    channel = os.environ.get("COLLIMATE_CHANNEL", "")
    run_id = os.environ.get("COLLIMATE_RUN_ID", "")
    proxy_base = f"/proxy/{channel}/{run_id}/{port}/"
    runner = await _start_aiohttp(port, state)

    # Resolve the binary first — the profile root depends on the
    # browser's packaging (Flatpak/Snap profiles must live in-sandbox).
    chrome_bin = _find_chrome(chrome_path)
    gen.log(f"Using browser: {chrome_bin}")
    effective_profile_dir = (
        profile_dir or _profile_dir_for(full_url, chrome_bin, profile_name)
    )
    gen.log(f"Using profile '{profile_name}': {effective_profile_dir}")

    # DummyCookieJar: the live-mode Bare proxy injects per-request cookies from
    # the real browser session, so the shared client must never accumulate or
    # replay cookies of its own (that would cross-contaminate remotes). The CDP
    # localhost calls that also use this session carry no cookies anyway.
    http = aiohttp.ClientSession(cookie_jar=aiohttp.DummyCookieJar())
    state.http = http

    # Off the critical path: sweep browsers a Force Stop / crash orphaned on
    # OTHER profiles (ours is handled by the attach-or-launch flow below).
    # Fire-and-forget — the task dies with this process at worst.
    reap_task = asyncio.get_running_loop().create_task(
        _reap_orphan_browsers(http, chrome_bin, effective_profile_dir)
    )

    # Shared-browser session. Cells with the same profile name + host share one
    # Chrome and each drives its own TAB (multi-tab); a different profile name
    # is an independent browser. If a Chrome is already live for this profile we
    # attach and open a new tab; otherwise we launch it. The per-profile launch
    # lock serializes that decision so a startup race can't spawn two Chromes on
    # one user-data dir. Lifetime is refcounted by PID markers (below): the last
    # cell out closes the browser.
    gen.status("Connecting to browser…")
    marker_path = ""
    is_launcher = False
    chrome: Optional[_Chrome] = None
    launch_lock = await _acquire_launch_lock(effective_profile_dir)
    try:
        try:
            existing_port = await _devtools_port_if_live(effective_profile_dir, http)
            if existing_port:
                gen.log(f"attaching to the shared '{profile_name}' browser on "
                        f"127.0.0.1:{existing_port} — opening a new tab")
                target_ws = await _open_tab(http, existing_port, full_url)
                chrome = _Chrome(proc=None, port=existing_port, stderr_tail=deque())
            else:
                chrome = await _launch_chrome(
                    chrome_bin,
                    profile_dir=effective_profile_dir,
                    url=full_url,
                    viewport=viewport,
                    xvfb=xvfb,
                )
                is_launcher = True
                target_ws = await _page_ws_url(http, chrome.port)
                gen.log(f"{os.path.basename(chrome_bin)} (pid {chrome.proc.pid}) "
                        f"DevTools on 127.0.0.1:{chrome.port}")
            marker_path = _register_session_cell(effective_profile_dir)
        finally:
            _release_launch_lock(launch_lock)
        target_id = _target_id_from_ws(target_ws)
    except BaseException:
        # We may have LAUNCHED a browser but failed before the teardown
        # block below took ownership of it (e.g. _page_ws_url timed out).
        # It is detached in its own session — no process-group kill will
        # ever reach it — so kill it here or it leaks indefinitely. Mirrors
        # the refcounted teardown: only close the browser when no other
        # cell shares it.
        if marker_path:
            _release_session_cell(marker_path)
        if chrome is not None and chrome.proc is not None \
                and not _live_session_cells(effective_profile_dir):
            await _kill_chrome_proc_tree(chrome.proc)
        raise

    loop = asyncio.get_running_loop()
    reader_task: Optional[asyncio.Task] = None

    def _push_url(new_url: str) -> None:
        state.current_url = new_url
        loop.create_task(
            _broadcast_json(state, {"kind": "url", "url": new_url})
        )

    # Surface page-side errors into the cell log so script failures
    # in the live page are visible without remote DevTools.
    def _on_log_entry(params: dict) -> None:
        entry = params.get("entry") or {}
        if entry.get("level") == "error":
            gen.log(f"[page.error] {entry.get('text', '')}")

    # Track main-frame navigations (link clicks, redirects, renderer
    # nav messages) and broadcast them so address-bar renderers can
    # follow the live URL. Sub-frame navigations are ignored.
    def _on_frame_navigated(params: dict) -> None:
        frame = params.get("frame") or {}
        if frame.get("parentId"):
            return
        state.main_frame_id = frame.get("id", state.main_frame_id)
        _push_url(frame.get("url", ""))

    def _on_navigated_within(params: dict) -> None:
        if params.get("frameId") == state.main_frame_id:
            _push_url(params.get("url", ""))

    async def _attach() -> tuple[CDP, asyncio.Task]:
        """Connect to THIS cell's page target (its own tab in the shared
        browser) and arm domains, overrides, event handlers, and the
        screencast. Called at startup and again whenever the connection drops —
        Chrome closes the page WS on bfcache restores and cross-process target
        swaps, so a dropped socket usually means "same page, new target".

        Reattaches to our stored tab. If that tab is gone but we're the only
        cell on the session, fall back to whatever the first page target is (a
        cross-process swap replaced our target id) — safe because there's no
        other tab to confuse it with."""
        nonlocal target_ws
        try:
            ws = await http.ws_connect(target_ws, max_msg_size=0)
        except Exception:
            if is_launcher and len(_live_session_cells(effective_profile_dir)) <= 1:
                target_ws = await _page_ws_url(http, chrome.port)
                ws = await http.ws_connect(target_ws, max_msg_size=0)
            else:
                raise
        # max_msg_size=0: screencast frames and captureScreenshot
        # responses can exceed aiohttp's 4 MB default.
        cdp = CDP(ws)
        reader = loop.create_task(cdp.read_loop())

        await cdp.send("Page.enable")
        await cdp.send("Runtime.enable")
        # Pin the viewport exactly — --window-size puts headless in the
        # right ballpark but includes no guarantee. deviceScaleFactor
        # follows the renderer-reported DPR (1.0 until the first
        # viewport message) so reattaches keep HiDPI frames.
        vw, vh = state.viewport
        await cdp.send("Emulation.setDeviceMetricsOverride", {
            "width": vw, "height": vh,
            "deviceScaleFactor": state.dpr, "mobile": False,
        })
        # Anti-detection. Headless brands itself in the UA string +
        # Client Hints; override both with the same browser's de-Headless'd
        # version (or the caller's user_agent) so Cloudflare/Google stop
        # looping the challenge. Read the live UA from the browser so the
        # override never drifts from the real Chrome build.
        try:
            ver = await cdp.send("Browser.getVersion")
        except Exception:
            ver = {}
        ua_override, ua_metadata = _stealth_ua_override(
            ver.get("userAgent", ""), user_agent
        )
        # Remember the effective UA for /res fallback fetches, so a
        # plain-HTTP asset load presents the same identity as the page.
        state.ua = ua_override or ver.get("userAgent", "")
        if ua_override:
            ua_params: dict[str, Any] = {"userAgent": ua_override}
            if ua_metadata:
                ua_params["userAgentMetadata"] = ua_metadata
            await cdp.send("Emulation.setUserAgentOverride", ua_params)

        # WebGL SwiftShader spoof + chrome-object shim. As an on-new-document
        # script it covers every future navigation (the challenge usually
        # reloads), and a one-shot evaluate patches the already-loaded page.
        stealth_js = _stealth_init_js()
        await cdp.send(
            "Page.addScriptToEvaluateOnNewDocument", {"source": stealth_js}
        )
        await _swallow(cdp.send("Runtime.evaluate", {"expression": stealth_js}))
        if page_inject_js:
            await cdp.send(
                "Page.addScriptToEvaluateOnNewDocument", {"source": page_inject_js}
            )

        # alert()/confirm() block the renderer-less page forever in
        # headless — auto-accept so the session can't wedge on one.
        cdp.on(
            "Page.javascriptDialogOpening",
            lambda _p: loop.create_task(
                _swallow(cdp.send("Page.handleJavaScriptDialog", {"accept": True}))
            ),
        )

        await cdp.send("Log.enable")
        cdp.on("Log.entryAdded", _on_log_entry)

        tree = await cdp.send("Page.getFrameTree")
        main_frame = (tree.get("frameTree") or {}).get("frame") or {}
        state.main_frame_id = main_frame.get("id", "")
        _push_url(main_frame.get("url") or full_url)
        cdp.on("Page.frameNavigated", _on_frame_navigated)
        cdp.on("Page.navigatedWithinDocument", _on_navigated_within)

        # CDP screencast — Chrome ships JPEG frames at ~native paint
        # rate. Forward each one to connected renderers and ack it so
        # the next frame arrives; without the ack, Chrome pauses the
        # screencast after one frame. Image mode only — dom mode's
        # snapshot pump polls via state.cdp and needs no per-attach
        # wiring.
        if state.render_mode == "image":
            # Clipboard + focus bridge: a CDP binding the injected page script
            # calls, forwarded to the renderer (copy text, live selection, the
            # focused field for the typing overlay). Re-armed each attach.
            await _swallow(cdp.send("Runtime.addBinding", {"name": "__collimateBridge"}))
            await _swallow(cdp.send(
                "Page.addScriptToEvaluateOnNewDocument", {"source": _INPUT_BRIDGE_JS}))
            await _swallow(cdp.send("Runtime.evaluate", {"expression": _INPUT_BRIDGE_JS}))

            def _on_binding_called(params: dict) -> None:
                if params.get("name") != "__collimateBridge":
                    return
                try:
                    msg = json.loads(params.get("payload") or "{}")
                except Exception:
                    return
                t = msg.get("t")
                if t == "copy" and msg.get("text"):
                    loop.create_task(_broadcast_json(
                        state, {"kind": "clipboard", "text": msg["text"]}))
                elif t == "sel":
                    loop.create_task(_broadcast_json(
                        state, {"kind": "selection", "text": msg.get("text") or ""}))
                elif t == "focus":
                    loop.create_task(_broadcast_json(
                        state, {"kind": "focus", "info": msg.get("info")}))
                elif t == "cursor":
                    loop.create_task(_broadcast_json(
                        state, {"kind": "cursor", "cursor": msg.get("cursor") or "default"}))
                elif t == "blocked":
                    loop.create_task(_broadcast_json(
                        state, {"kind": "blocked", "url": msg.get("url") or ""}))

            cdp.on("Runtime.bindingCalled", _on_binding_called)

            # Safety net for popups the page-level block misses (forms, named
            # targets, scripted opens): auto-attach catches any target THIS page
            # opens — close it and refocus ours so the screencast never freezes
            # on a backgrounded tab. Scoped to our page's children, so other
            # cells' tabs are untouched.
            await _swallow(cdp.send("Target.setAutoAttach", {
                "autoAttach": True, "waitForDebuggerOnStart": False, "flatten": True}))

            def _on_attached(params: dict) -> None:
                info = params.get("targetInfo") or {}
                if info.get("type") != "page":
                    return
                tid = info.get("targetId")

                async def _close() -> None:
                    await _swallow(cdp.send("Target.closeTarget", {"targetId": tid}))
                    await _swallow(cdp.send("Page.bringToFront"))
                    await _broadcast_json(state, {"kind": "blocked", "url": info.get("url") or ""})

                loop.create_task(_close())

            cdp.on("Target.attachedToTarget", _on_attached)

            def _on_screencast_frame(params: dict) -> None:
                data = params.get("data")
                session_id = params.get("sessionId")
                if not isinstance(data, str) or session_id is None:
                    return

                async def _forward() -> None:
                    try:
                        await _broadcast_frame(state, data)
                    finally:
                        try:
                            await cdp.send(
                                "Page.screencastFrameAck", {"sessionId": session_id}
                            )
                        except Exception:
                            # ack failures during teardown are expected;
                            # only the next-frame pump cares about them.
                            pass

                loop.create_task(_forward())

            cdp.on("Page.screencastFrame", _on_screencast_frame)
            await cdp.send("Page.startScreencast", _SCREENCAST_PARAMS)

        state.cdp = cdp
        return cdp, reader

    live_token = ""
    live_marker = ""
    hb_task: Optional[asyncio.Task] = None
    try:
        cdp, reader_task = await _attach()

        await gen.serve_port(port, name="page stream")

        if state.render_mode == "live":
            # Give this cell its own subdomain origin (clean origin for the
            # reverse-proxied page) and seed the proxy's target from the initial
            # URL so subresource requests resolve even before the nav bootstrap.
            state.live_target_origin = _origin_of(full_url)
            live_token = _live_token(run_id, port)
            state.live_token = live_token
            live_marker = _write_session_marker(live_token, port)
            hb_task = loop.create_task(_heartbeat_session_marker(live_marker))

        artifact: dict[str, Any] = {
            "url": full_url,
            "proxyBase": proxy_base,
            "renderMode": state.render_mode,
            "viewport": {"width": viewport[0], "height": viewport[1]},
            # Tells the renderer to offer the Open-window / Hide-window
            # control (driven by `kind:"window"` WS messages, not the
            # action button — so it works without an on_capture).
            "window": True,
        }
        if capture_button_label and on_capture is not None:
            artifact["actions"] = [
                {"id": "capture", "label": capture_button_label},
            ]
        if live_token:
            # The renderer builds the live iframe origin as
            # <scheme>//<liveToken>.<apphost> (routed to this daemon by the
            # host's session_proxy middleware).
            artifact["liveToken"] = live_token
        gen.update_file(artifact_filename, json.dumps(artifact))
        await gen.update(
            name=cell_name,
            summary=cell_summary or f"Live: {full_url}",
            pinned=artifact_filename,
        )
        gen.phase("running", "live")
        gen.status(f"Streaming {full_url}")

        async def _broadcast_window_state() -> None:
            await _broadcast_json(state, {"kind": "window", "headful": state.headful})

        async def _switch_mode(target_headful: bool) -> bool:
            """Close the running browser and relaunch the SAME profile in
            the requested visibility, then reattach. Returns True on
            success. The profile (cookies, Cloudflare clearance) carries
            across because both modes share the user-data dir."""
            nonlocal chrome, cdp, reader_task, target_ws, target_id
            gen.status("Opening a browser window…" if target_headful
                       else "Returning to hidden mode…")
            await _shutdown_browser(state, chrome, reader_task)
            try:
                chrome = await _launch_chrome(
                    chrome_bin,
                    profile_dir=effective_profile_dir,
                    url=state.current_url or full_url,
                    viewport=state.viewport,
                    headful=target_headful,
                    xvfb=xvfb,
                )
            except Exception as exc:
                gen.log(f"relaunch ({'window' if target_headful else 'hidden'}) "
                        f"failed: {exc}")
                return False
            state.headful = target_headful
            # Fresh browser → fresh tab; re-point our target before reattaching.
            # (Only reachable for the sole-cell launcher — see the toggle gate.)
            target_ws = await _page_ws_url(http, chrome.port)
            target_id = _target_id_from_ws(target_ws)
            cdp, reader_task = await _attach()
            await _broadcast_window_state()
            gen.status(f"Streaming {full_url}"
                       + (" (window open)" if target_headful else ""))
            return True

        capture_count = 0
        while not gen.cancelled:
            # Renderer asked to open/hide the visible window. The toggle
            # relaunches the SHARED Chrome, so only honour it for the launcher
            # when it's the sole cell on the session — otherwise it would yank
            # the tabs out from under other same-session cells. Cancel the
            # request with a note in that case.
            if state.want_headful != state.headful:
                sole = (is_launcher
                        and len(_live_session_cells(effective_profile_dir)) <= 1)
                if not sole:
                    gen.log("Open-window is unavailable while other cells share "
                            "this browser session — close them first.")
                    state.want_headful = state.headful
                    await _broadcast_window_state()
                elif not await _switch_mode(state.want_headful):
                    break
                else:
                    continue
            # proc is None when we attached to a shared browser another cell
            # launched — that cell (or the refcount) owns the process; we detect
            # its death via the dropped CDP connection + failed reattach below.
            if chrome.proc is not None and chrome.proc.returncode is not None:
                # A headful window that exits = the user closed it. Drop
                # back to hidden mode (keeping the now-cleared session)
                # via the mismatch handler above, rather than ending the
                # whole cell.
                if state.headful:
                    gen.log("Browser window closed — returning to hidden mode")
                    state.want_headful = False
                    continue
                gen.log(f"Chrome exited (rc={chrome.proc.returncode}) — stopping")
                break
            if reader_task.done():
                gen.log("CDP connection dropped — reattaching to page target")
                try:
                    cdp, reader_task = await _attach()
                except Exception as exc:
                    gen.log(f"reattach failed: {exc} — stopping")
                    break
                continue
            # When capture is wired up, poll for actions cooperatively;
            # otherwise just idle until cancellation. The 0.5s sleep
            # keeps cancel responsive without burning CPU.
            if on_capture is not None:
                action = await gen.wait_for_action(timeout=0.5)
                if action == "capture":
                    capture_count += 1
                    gen.status(f"Capturing #{capture_count}…")
                    try:
                        await on_capture(
                            CaptureContext(
                                cdp=cdp, url=state.current_url or full_url,
                                capture_count=capture_count,
                                screencast=(state.render_mode == "image"),
                            )
                        )
                    except Exception as exc:
                        gen.log(f"capture #{capture_count} failed: {exc}")
                    gen.status(f"Streaming {full_url}")
            else:
                await asyncio.sleep(0.5)
    finally:
        # The orphan sweep must not outlive the http session closed below.
        reap_task.cancel()
        # Stop advertising our subdomain so the host stops routing to us.
        if hb_task is not None:
            hb_task.cancel()
        _remove_session_marker(live_marker)
        # Refcounted teardown: drop our session marker, then close the SHARED
        # browser only if we were the last cell using it; otherwise close just
        # our own tab and leave the browser (and other cells' tabs) running.
        _release_session_cell(marker_path)
        remaining = _live_session_cells(effective_profile_dir)
        if remaining:
            gen.log(f"Tearing down server; {len(remaining)} cell(s) still share "
                    "this browser — closing our tab, leaving the browser up")
            await _close_own_tab(state, http, chrome.port, reader_task, target_id)
        else:
            gen.log("Tearing down Chrome + server (last cell on this session)")
            await _shutdown_browser(state, chrome, reader_task)
        for ws in list(state.clients):
            try:
                await ws.close()
            except Exception:
                pass
        try:
            await http.close()
        except Exception:
            pass
        await runner.cleanup()


async def _shutdown_browser(
    state: _SessionState,
    chrome: _Chrome,
    reader_task: Optional[asyncio.Task],
) -> None:
    """Close one browser + its CDP connection cleanly, releasing the
    profile lock so the same user-data dir can be relaunched (a window
    open/hide switch) or the daemon can exit. Tolerant of an already-dead
    process — the relaunch path calls it after the user closed the
    window."""
    if state.cdp is not None:
        try:
            await state.cdp.send("Page.stopScreencast", timeout=5.0)
        except Exception:
            pass
        # Exit via the protocol, not signals: Flatpak/Snap wrapper
        # supervisors don't forward SIGTERM to the sandboxed Chrome,
        # and Browser.close also flushes the profile cleanly.
        try:
            await state.cdp.send("Browser.close", timeout=5.0)
        except Exception:
            pass
    if reader_task is not None:
        reader_task.cancel()
    if state.cdp is not None:
        await state.cdp.close()
        state.cdp = None
    # Escalate if the process (or its wrapper) lingers anyway. proc is None when
    # this (last) cell only ATTACHED to a shared browser — Browser.close above
    # already asked it to exit; there's no local handle to signal.
    if chrome.proc is None:
        return
    try:
        await asyncio.wait_for(chrome.proc.wait(), timeout=5.0)
    except asyncio.TimeoutError:
        # Signal the PROCESS GROUP, not just the direct pid: under xvfb-run
        # the handle is the wrapper shell, and terminate()/kill() on it
        # alone orphans the Xvfb server and the real Chrome underneath.
        await _kill_chrome_proc_tree(chrome.proc)


async def _close_own_tab(
    state: _SessionState,
    http: aiohttp.ClientSession,
    port: int,
    reader_task: Optional[asyncio.Task],
    target_id: str,
) -> None:
    """Tear down just THIS cell's tab + CDP connection, leaving the shared
    browser (and other same-session cells' tabs) running. Used when this cell
    is NOT the last one out. ``Target.closeTarget`` is a browser-level command,
    so it goes over a transient browser connection."""
    if state.cdp is not None:
        try:
            await state.cdp.send("Page.stopScreencast", timeout=5.0)
        except Exception:
            pass
    if reader_task is not None:
        reader_task.cancel()
    if state.cdp is not None:
        await state.cdp.close()
        state.cdp = None
    try:
        ws = await asyncio.wait_for(
            http.ws_connect(await _browser_ws_url(http, port), max_msg_size=0),
            timeout=5.0,
        )
        cdp = CDP(ws)
        reader = asyncio.get_running_loop().create_task(cdp.read_loop())
        try:
            await cdp.send("Target.closeTarget", {"targetId": target_id}, timeout=5.0)
        finally:
            reader.cancel()
            await cdp.close()
    except Exception:
        pass


async def _swallow(coro: Awaitable) -> None:
    try:
        await coro
    except Exception:
        pass


# ---------------------------------------------------------------------------
# WS broadcast — small enough to keep inline rather than its own module
# ---------------------------------------------------------------------------


async def _broadcast_json(state: _SessionState, payload: dict[str, Any]) -> None:
    """Send one JSON payload to every connected renderer, dropping
    clients whose sockets have gone away."""
    data = json.dumps(payload)
    dead: list[web.WebSocketResponse] = []
    for ws in state.clients:
        if ws.closed:
            dead.append(ws)
            continue
        try:
            await ws.send_str(data)
        except Exception:
            dead.append(ws)
    for ws in dead:
        state.clients.discard(ws)


async def _broadcast_frame(state: _SessionState, b64_jpeg: str) -> None:
    """Push a single screencast frame to every connected renderer.
    The frame is cached on ``state`` so a new client connecting
    mid-session gets a non-blank initial paint."""
    async with state.lock:
        state.last_frame = b64_jpeg
    await _broadcast_json(state, {"kind": "frame", "data": b64_jpeg})


# ---------------------------------------------------------------------------
# Live render mode — native reverse proxy behind the iframe.
#
# The cell's subdomain (<token>.<apphost>, routed here by the host's
# session_proxy) is served by the reverse proxy below. It fetches the real
# target page carrying the live browser's cookies (so it's logged in), strips
# the headers that forbid framing (X-Frame-Options, CSP frame-ancestors), and
# rewrites only the target's own origin string onto the subdomain — so the page
# runs NATIVELY in the iframe (no in-browser JS rewriting). The page's relative
# /api calls and origin-relative WebSockets resolve back to the subdomain and
# come through this proxy; public cross-origin assets (CDN bundles) load direct.
# A small nav bridge is injected into HTML documents to report the current URL
# up to the renderer and accept back/forward/reload. The headless Chrome stays
# only the session/cookie authority + capture target.
# ---------------------------------------------------------------------------

# Daemon-internal endpoints live under this prefix so they never collide with a
# proxied site's own paths; everything else on the subdomain is reverse-proxied.
_COLLIMATE_PREFIX = "/__collimate/"
_CONTROL_WS_PATH = "/__collimate/ws"   # renderer input / frame channel (image + live)
_GO_PATH = "/__collimate/go"           # live nav bootstrap: registers the SW, then loads the target
_SW_PATH = "/__collimate/sw.js"        # cross-origin reroute service worker
_X_PATH = "/__collimate/x"             # generic cross-origin proxy (the SW reroutes here)

# Anti-framing / isolation headers stripped so a framebusting page embeds.
_FRAMEBUST_HEADERS = frozenset({
    "x-frame-options", "content-security-policy",
    "content-security-policy-report-only", "cross-origin-opener-policy",
    "cross-origin-embedder-policy", "cross-origin-resource-policy",
})
# Response headers we must not echo: the body is delivered decompressed and
# re-framed, so length/encoding/hop-by-hop would be wrong.
_DROP_RESPONSE_HEADERS = frozenset({
    "content-length", "content-encoding", "transfer-encoding", "connection",
    "keep-alive", "trailer", "upgrade", "alt-svc",
})
# Request headers we strip before forwarding upstream (host/hop-by-hop, the
# forwarded-origin hints, and the browser-side cookie which we override with the
# real session jar).
_DROP_REQUEST_HEADERS = frozenset({
    "host", "connection", "keep-alive", "transfer-encoding", "upgrade",
    "content-length", "accept-encoding", "cookie", "origin", "referer",
    "x-forwarded-host", "x-forwarded-proto", "x-forwarded-for",
})
# Only these get the origin-string rewrite + (for HTML) the nav bridge. JSON /
# event-stream / binary are passed through untouched so SSE chat streams and API
# payloads aren't buffered or mangled.
_REWRITE_CONTENT_TYPES = ("text/html", "text/css")

# Injected into proxied HTML so the iframe (cross-origin to the renderer) can
# report navigation up and take back/forward/reload down — the postMessage
# protocol the renderer already speaks. `{TARGET}` is the real upstream origin;
# the bridge maps the subdomain path back to it for the address bar.
_BRIDGE_JS_TMPL = """<script>(function(){
var T=__T__;    // this page's REAL origin
var P=__P__;    // the session's PRIMARY real origin (served at the plain subdomain)
var TOK=__TOK__; // this session's subdomain token (BASE label of every proxy host)
// Keep OUR reroute SW the sole controller: block the proxied site from
// registering its own SW (would fight ours for scope "/" and break rerouting),
// protect ours from the site's unregister sweep, hide it from the site's
// enumeration, clean up any leftover site SWs, and ensure ours is registered.
try{var s=navigator.serviceWorker;if(s){var R=s.register.bind(s);
function isOurReg(r){try{var u=((r&&(r.active||r.waiting||r.installing))||{}).scriptURL||"";return u.indexOf("/__collimate/sw.js")!==-1;}catch(e){return false;}}
s.register=function(u,o){return String(u).indexOf("/__collimate/sw.js")!==-1?R(u,o):Promise.reject(new Error("sw disabled by proxy"));};
var SWR=window.ServiceWorkerRegistration;
if(SWR&&SWR.prototype&&SWR.prototype.unregister){var UN=SWR.prototype.unregister;SWR.prototype.unregister=function(){return isOurReg(this)?Promise.resolve(false):UN.apply(this,arguments);};}
if(s.getRegistrations){var GR=s.getRegistrations.bind(s);GR().then(function(rs){rs.forEach(function(r){if(!isOurReg(r))try{r.unregister();}catch(e){}});});s.getRegistrations=function(){return Promise.resolve([]);};}
if(s.getRegistration){s.getRegistration=function(){return Promise.resolve(undefined);};}
R("/__collimate/sw.js",{scope:"/"}).catch(function(){});}}catch(e){}
// Cross-origin sub-frames (e.g. claude's a.claude.ai artifact sandbox) can't be
// caught by a same-origin SW, and their CSP frame-ancestors would block our
// origin. So load each cross-origin iframe through its OWN proxy subdomain and
// remap the sandbox-handshake postMessage's targetOrigin to that subdomain so
// the real-origin target the app sends still reaches the (now proxied) frame.
// Sub-resources that are subdomains of the primary (a.claude.ai) keep their
// structure (a.<token>.<app>) so the app's host-based origin checks still pass;
// unrelated origins are b32-encoded. Ongoing comms ride the handshake's
// MessageChannel port (origin-agnostic), so this one remap is enough.
try{
var LH=location.host.split("."),ti=LH.indexOf(TOK),BASE=TOK,APP=(ti>=0?LH.slice(ti+1):LH.slice(1)).join("."),PRO=location.protocol;
var PH="";try{PH=new URL(P).hostname;}catch(e){}
function b32(x){var A="abcdefghijklmnopqrstuvwxyz234567",b=0,v=0,o="";for(var i=0;i<x.length;i++){v=(v<<8)|x.charCodeAt(i);b+=8;while(b>=5){o+=A[(v>>>(b-5))&31];b-=5;}}if(b>0)o+=A[(v<<(5-b))&31];return o;}
function px(real){if(real===P)return PRO+"//"+BASE+"."+APP;var rh="";try{rh=new URL(real).hostname;}catch(e){}
 if(PH&&rh&&rh.endsWith("."+PH))return PRO+"//"+rh.slice(0,rh.length-PH.length-1)+"."+BASE+"."+APP;
 return PRO+"//"+BASE+"--"+b32(real)+"."+APP;}
function ours(host){var h=host.split(".");for(var i=0;i<h.length;i++){if(h[i].split("--")[0]===BASE&&h.slice(i+1).join(".")===APP)return true;}return false;}
function rw(u){if(!u)return u;if(/^(about:|data:|blob:|javascript:|mailto:|#)/i.test(u))return u;
 try{var z=new URL(u,T);if(z.protocol!=="http:"&&z.protocol!=="https:")return u;if(ours(z.host))return u;return px(z.origin)+z.pathname+z.search+z.hash;}catch(e){return u;}}
var sd=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,"src");
if(sd&&sd.set){Object.defineProperty(HTMLIFrameElement.prototype,"src",{configurable:true,enumerable:sd.enumerable,get:function(){return sd.get.call(this);},set:function(v){sd.set.call(this,rw(v));}});}
var SA=Element.prototype.setAttribute;
Element.prototype.setAttribute=function(n,v){if(this.tagName==="IFRAME"&&String(n).toLowerCase()==="src")v=rw(v);return SA.call(this,n,v);};
var cd=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,"contentWindow");
if(cd&&cd.get){Object.defineProperty(HTMLIFrameElement.prototype,"contentWindow",{configurable:true,enumerable:cd.enumerable,get:function(){
 var w=cd.get.call(this);if(!w)return w;
 try{return new Proxy(w,{get:function(t,p){if(p==="postMessage")return function(m,o,tr){var no=(typeof o==="string"&&/^https?:\\/\\//i.test(o))?px(o):o;return t.postMessage(m,no,tr);};var val=Reflect.get(t,p);return typeof val==="function"?val.bind(t):val;}});}catch(e){return w;}
}});}
if(sd&&sd.set){new MutationObserver(function(ms){for(var i=0;i<ms.length;i++){var an=ms[i].addedNodes||[];for(var j=0;j<an.length;j++){var nd=an[j];if(nd&&nd.tagName==="IFRAME"&&nd.getAttribute){var s0=nd.getAttribute("src");if(s0){var r0=rw(s0);if(r0!==s0)sd.set.call(nd,r0);}}}}}).observe(document.documentElement||document,{childList:true,subtree:true});}
}catch(e){}
function up(){try{parent.postMessage({collimateLive:"url",url:T+location.pathname+location.search},"*");}catch(e){}}
function h(n){try{var o=history[n];history[n]=function(){var r=o.apply(this,arguments);setTimeout(up,0);return r;};}catch(e){}}
h("pushState");h("replaceState");
addEventListener("popstate",up);
addEventListener("message",function(e){var d=(e&&e.data)||{};
if(d.collimateLiveNav==="back")history.back();
else if(d.collimateLiveNav==="forward")history.forward();
else if(d.collimateLiveNav==="reload")location.reload();});
addEventListener("load",function(){up();try{parent.postMessage({collimateLive:"ready"},"*");}catch(e){}});
up();
})();</script>"""

# Hosts whose APIs authenticate with an origin-signed SAPISIDHASH (Google). For
# these, the reverse proxy recomputes the Authorization header server-side signed
# over the REAL app origin, using the profile's SAPISID — so AI Studio (and other
# Google-origin apps) authenticate even though the page runs on our subdomain.
_GOOGLE_AUTH_SUFFIXES = ("googleapis.com", "clients6.google.com")

# The cross-origin reroute service worker. It does NOT touch the app's code or
# environment — it only intercepts the page's outbound DATA requests (fetch/XHR)
# and reroutes CROSS-origin ones through /__collimate/x, so they carry the live
# session (cookies + Google origin-signed auth) and aren't CORS-blocked. Static
# subresources and same-origin requests are left alone (the latter already proxy
# server-side); cross-origin sub-iframes can't be caught by a same-origin SW.
_REROUTE_SW_JS = """\
var SELF = self.location.origin;
self.addEventListener("install", function(){ self.skipWaiting(); });
self.addEventListener("activate", function(e){ e.waitUntil(self.clients.claim()); });
self.addEventListener("fetch", function(event){
  var req = event.request;
  var url;
  try { url = new URL(req.url); } catch (e) { return; }
  if (url.origin === SELF) return;                       // same-origin: server proxy handles it
  var dest = req.destination;
  if (dest !== "" && dest !== "empty") return;           // only fetch/XHR; assets load direct
  event.respondWith((async function(){
    var init = { method: req.method, headers: req.headers,
                 mode: "same-origin", credentials: "same-origin", redirect: "manual" };
    if (req.method !== "GET" && req.method !== "HEAD") { init.body = await req.arrayBuffer(); }
    try { return await fetch(SELF + "/__collimate/x?u=" + encodeURIComponent(req.url), init); }
    catch (e) { return new Response("reroute failed: " + e, { status: 502 }); }
  })());
});
"""

# The /__collimate/go bootstrap page. Returned (instead of a redirect) so the
# reroute SW is registered and ACTIVE before the real page loads — guaranteeing
# the SW controls it from the first byte, so even early API calls are caught.
_GO_BOOTSTRAP_HTML = """\
<!doctype html><meta charset="utf-8"><title>loading</title>
<body style="margin:0;background:#fff"><script>
(async function(){
  var dest = __DEST__;
  try {
    await navigator.serviceWorker.register("__SW__", { scope: "/" });
    await navigator.serviceWorker.ready;
    if (!navigator.serviceWorker.controller) {
      await new Promise(function(r){
        var t = setTimeout(r, 1500);
        navigator.serviceWorker.addEventListener("controllerchange",
          function(){ clearTimeout(t); r(); }, { once: true });
      });
    }
  } catch (e) {}
  location.replace(dest);
})();
</script></body>"""


def _origin_of(url: str) -> str:
    """``scheme://host[:port]`` for a URL, or "" if it isn't absolute http(s)."""
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.hostname:
        return ""
    netloc = p.hostname + (f":{p.port}" if p.port else "")
    return f"{p.scheme}://{netloc}"


def _self_origin(request: web.Request) -> str:
    """This proxy's own public origin (the subdomain), from the forwarded-host
    hints session_proxy stamps. "" when unknown (direct/loopback access), which
    just disables origin rewriting — the page still runs."""
    host = request.headers.get("X-Forwarded-Host")
    if not host:
        return ""
    proto = request.headers.get("X-Forwarded-Proto", "https")
    return f"{proto}://{host}"


def _frame_decode_origin(label: str) -> str:
    """A frame subdomain label ``<token>--<b32(origin)>`` -> the real origin it
    proxies, or "" if the label is the plain session token (the primary). The
    encoding is lowercase base32 (DNS-label-safe) of the origin string, matching
    the ``b32`` the injected bridge uses to build frame subdomains."""
    _, sep, enc = label.partition("--")
    if not sep or not enc:
        return ""
    try:
        pad = enc.upper() + "=" * (-len(enc) % 8)
        origin = base64.b32decode(pad).decode("ascii")
    except Exception:
        return ""
    return origin if _origin_of(origin) == origin else ""


def _target_origin_for(request: web.Request, state: _SessionState) -> str:
    """Which real origin this request proxies. The plain session subdomain
    proxies the session's primary target (the live URL). A frame subdomain
    proxies a cross-origin sub-resource, in one of two shapes:

    * ``<extra>.<token>.<app>`` — a sub-resource that is a *subdomain of the
      primary* (e.g. claude's ``a.claude.ai``): the real origin is
      ``<extra>.<primary-host>`` on the primary's scheme. This preserves the
      subdomain structure so the embedded app's host-based origin checks (which
      e.g. strip an ``a.`` prefix and compare) still pass.
    * ``<token>--<b32(origin)>.<app>`` — any other cross-origin host, encoded.
    """
    host = request.headers.get("X-Forwarded-Host", "").split(":")[0]
    labels = host.split(".")
    first = labels[0]
    if "--" in first:
        dec = _frame_decode_origin(first)
        if dec:
            return dec
    tok = state.live_token
    primary = state.live_target_origin
    if tok and primary and tok in labels:
        extra = labels[:labels.index(tok)]
        if extra:
            p = urlparse(primary)
            netloc = ".".join(extra) + "." + (p.hostname or "")
            if p.port:
                netloc += f":{p.port}"
            return f"{p.scheme}://{netloc}"
    return primary


def _rewrite_origin_refs(data: bytes, target_origin: str, self_origin: str) -> bytes:
    """Rewrite the TARGET site's own origin references onto our subdomain so its
    same-origin-intended links/resources stay on the proxy. Other origins (public
    CDNs) are left alone — they load direct. Covers the plain origin, the
    JSON/JS backslash-escaped form, and the protocol-relative //host form."""
    if not self_origin or target_origin == self_origin:
        return data
    th = target_origin.split("://", 1)[1]
    sh = self_origin.split("://", 1)[1]
    data = data.replace(target_origin.encode(), self_origin.encode())
    data = data.replace(target_origin.replace("/", r"\/").encode(),
                        self_origin.replace("/", r"\/").encode())
    data = data.replace(("//" + th).encode(), ("//" + sh).encode())
    return data


def _redomain_cookie(raw: str, self_origin: str) -> str:
    """Re-scope a proxied Set-Cookie to our subdomain (drop Domain=) so any
    client-side `document.cookie` read works; drop Secure over plain http (local
    *.localhost) so the cookie is still stored. Upstream auth doesn't rely on
    this — the proxy injects the real session jar — so best-effort is fine."""
    parts = [p for p in raw.split(";") if not p.strip().lower().startswith("domain=")]
    if self_origin.startswith("http://"):
        parts = [p for p in parts if p.strip().lower() != "secure"]
    return ";".join(parts)


def _inject_bridge(html: bytes, target_origin: str, primary_origin: str = "",
                   token: str = "") -> bytes:
    """Insert the nav bridge right after <head> (or at the top) of an HTML doc.
    ``primary_origin`` is the session's main target (the plain subdomain); it
    differs from ``target_origin`` only on a frame subdomain. ``token`` is the
    session's subdomain label, so the bridge derives the proxy-host structure
    consistently on both the primary and frame subdomains."""
    script = (_BRIDGE_JS_TMPL
              .replace("__T__", json.dumps(target_origin))
              .replace("__P__", json.dumps(primary_origin or target_origin))
              .replace("__TOK__", json.dumps(token))).encode("utf-8")
    m = re.search(rb"<head[^>]*>", html, re.IGNORECASE)
    if m:
        return html[:m.end()] + script + html[m.end():]
    return script + html

async def _cookies_for(state: _SessionState, url: str) -> dict[str, str]:
    """The live browser's cookies that would be sent to ``url`` (name→value),
    read fresh from the real session. Empty while CDP is mid-reattach."""
    cdp = state.cdp
    if cdp is None:
        return {}
    try:
        res = await cdp.send("Network.getCookies", {"urls": [url]})
    except Exception:
        return {}
    out: dict[str, str] = {}
    for c in (res.get("cookies") or []):
        name = c.get("name")
        if name:
            out[name] = c.get("value", "")
    return out


async def _session_cookie_header(state: _SessionState, url: str) -> str:
    """The live browser's cookies for ``url`` as a Cookie header value, so a
    framed request presents the logged-in identity."""
    return "; ".join(f"{n}={v}" for n, v in (await _cookies_for(state, url)).items())


def _maybe_google_auth(target: str, origin: str, cookies: dict[str, str],
                       headers: dict[str, str]) -> None:
    """For Google APIs, recompute the ``Authorization: SAPISIDHASH`` header
    server-side, signed over the app's REAL origin (e.g. https://aistudio.google.com)
    using the profile's SAPISID — the app signed it with our subdomain, which
    Google rejects. Also set Origin/X-Origin to that origin so the signature
    matches. No-op for non-Google hosts or when not logged in."""
    host = (urlparse(target).hostname or "").lower()
    if not any(host == s or host.endswith("." + s) for s in _GOOGLE_AUTH_SUFFIXES):
        return
    if not origin:
        return
    now = int(time.time())

    def _sign(value: str) -> str:
        return hashlib.sha1(f"{now} {value} {origin}".encode()).hexdigest()

    parts = []
    sapisid = cookies.get("SAPISID") or cookies.get("__Secure-3PAPISID")
    if sapisid:
        parts.append(f"SAPISIDHASH {now}_{_sign(sapisid)}")
    if cookies.get("__Secure-1PAPISID"):
        parts.append(f"SAPISID1PHASH {now}_{_sign(cookies['__Secure-1PAPISID'])}")
    if cookies.get("__Secure-3PAPISID"):
        parts.append(f"SAPISID3PHASH {now}_{_sign(cookies['__Secure-3PAPISID'])}")
    if not parts:
        return
    headers["Authorization"] = " ".join(parts)
    # These endpoints accept a cross-origin `Origin` (a real browser sends it),
    # but only when the request looks like a genuine first-party browser call.
    # The tell a plain server client omits is the Sec-Fetch-* set — and since
    # the API host shares google.com with the app origin, that's a *same-site*
    # request. A server (unlike browser JS) may set these "forbidden" headers.
    headers.pop("X-Origin", None)
    headers.pop("x-origin", None)
    o_host = (urlparse(origin).hostname or "").lower()
    a, b = o_host.split(".")[-2:], host.split(".")[-2:]
    headers["Sec-Fetch-Site"] = "same-site" if (len(a) == 2 and a == b) else "cross-site"
    headers["Sec-Fetch-Mode"] = "cors"
    headers["Sec-Fetch-Dest"] = "empty"


def _parse_set_cookie(raw: str, url: str) -> dict[str, Any]:
    """A minimal Set-Cookie → Network.setCookie params parse. Domain/path
    default from ``url`` when the header omits them; unknown attributes are
    ignored. Enough to carry an iframe login back into the profile."""
    parts = [p.strip() for p in raw.split(";")]
    name, _, value = parts[0].partition("=")
    params: dict[str, Any] = {"name": name.strip(), "value": value.strip(), "url": url}
    for attr in parts[1:]:
        k, _, v = attr.partition("=")
        k, v = k.strip().lower(), v.strip()
        if k == "domain" and v:
            params["domain"] = v.lstrip(".")
        elif k == "path" and v:
            params["path"] = v
        elif k == "secure":
            params["secure"] = True
        elif k == "httponly":
            params["httpOnly"] = True
        elif k == "samesite" and v:
            params["sameSite"] = v.capitalize()
    return params


async def _sync_set_cookies(state: _SessionState, url: str, set_cookies: list[str]) -> None:
    """Push a proxied response's Set-Cookie values into the live browser so an
    in-iframe login persists in the profile (and stays visible to capture)."""
    cdp = state.cdp
    if cdp is None:
        return
    for raw in set_cookies:
        try:
            await cdp.send("Network.setCookie", _parse_set_cookie(raw, url))
        except Exception:
            pass


def _native_proxy_factory(state: _SessionState):
    """The live reverse proxy (catch-all). Serves the real target page on the
    cell's subdomain: inject the session cookies/UA, strip anti-framing headers,
    rewrite the target's own origin onto the subdomain, and stamp the nav bridge
    into HTML. Reserved /__collimate/* paths are matched before this; everything
    else on the subdomain lands here. In image mode the renderer never reaches
    it, so a stray request just falls through to the index."""

    async def _http(request: web.Request) -> web.StreamResponse:
        http = state.http
        target_origin = _target_origin_for(request, state)
        if http is None or not target_origin:
            return web.Response(status=502, text="live session not ready")
        upstream_url = target_origin + request.raw_path
        self_origin = _self_origin(request)

        # Forward the browser's headers minus host/hop-by-hop/forwarded hints,
        # then inject the live session over the top (Cookie/UA/Origin are ours).
        req_headers = {k: v for k, v in request.headers.items()
                       if k.lower() not in _DROP_REQUEST_HEADERS}
        req_headers["Accept-Encoding"] = "identity"
        req_headers["Origin"] = target_origin
        ref = request.headers.get("Referer")
        if ref and self_origin and ref.startswith(self_origin):
            req_headers["Referer"] = target_origin + ref[len(self_origin):]
        elif ref:
            req_headers["Referer"] = target_origin + "/"
        jar = await _session_cookie_header(state, upstream_url)
        if jar:
            req_headers["Cookie"] = jar
        if state.ua:
            req_headers.setdefault("User-Agent", state.ua)

        body = await request.read()
        try:
            upstream = await http.request(
                request.method, upstream_url,
                headers=req_headers,
                data=body or None,
                allow_redirects=False,
                timeout=aiohttp.ClientTimeout(total=None, sock_connect=30, sock_read=None),
            )
        except Exception as exc:
            return web.Response(status=502, text=f"live fetch failed: {exc}")

        # Diagnostic: surface notable responses (documents, redirects, errors,
        # Cloudflare challenges) so a blank live view is explainable from the
        # cell log — including which cookies we injected (names only).
        ctype = upstream.headers.get("Content-Type", "").split(";")[0].lower()
        is_cf = bool(upstream.headers.get("cf-mitigated")) or (
            upstream.status in (403, 503)
            and "cloudflare" in upstream.headers.get("Server", "").lower())
        if is_cf or upstream.status >= 300 or "text/html" in ctype:
            names = [c.split("=", 1)[0] for c in jar.split("; ")] if jar else []
            gen.log(f"[live] {request.method} {upstream_url[:80]} -> {upstream.status} "
                    f"{ctype or '?'} cookies={names or 'NONE'}"
                    f"{'  CLOUDFLARE-CHALLENGE' if is_cf else ''}")

        # Carry an in-iframe login back into the profile (best-effort, async).
        set_cookies = upstream.headers.getall("Set-Cookie", [])
        if set_cookies:
            asyncio.get_running_loop().create_task(
                _sync_set_cookies(state, upstream_url, set_cookies))

        out_headers: dict[str, str] = {}
        for k, v in upstream.headers.items():
            lk = k.lower()
            if lk in _FRAMEBUST_HEADERS or lk in _DROP_RESPONSE_HEADERS or lk == "set-cookie":
                continue
            if lk == "location":
                v = _rewrite_origin_refs(v.encode(), target_origin, self_origin).decode("latin-1")
            out_headers[k] = v
        out_headers.setdefault("Cache-Control", "no-store")

        # HTML/CSS get the origin rewrite (+ bridge for HTML), buffered. Anything
        # else — including SSE chat streams and API JSON — is passed through
        # untouched and streamed, so long-lived bodies aren't held back.
        if self_origin and any(t in ctype for t in _REWRITE_CONTENT_TYPES):
            raw = await upstream.read()
            upstream.release()
            raw = _rewrite_origin_refs(raw, target_origin, self_origin)
            if "text/html" in ctype:
                raw = _inject_bridge(raw, target_origin, state.live_target_origin,
                                     state.live_token)
            resp = web.Response(status=upstream.status, body=raw, headers=out_headers)
            for c in set_cookies:
                resp.headers.add("Set-Cookie", _redomain_cookie(c, self_origin))
            return resp

        out = web.StreamResponse(status=upstream.status, headers=out_headers)
        for c in set_cookies:
            out.headers.add("Set-Cookie", _redomain_cookie(c, self_origin))
        await out.prepare(request)
        try:
            async for chunk in upstream.content.iter_chunked(1 << 16):
                await out.write(chunk)
        except Exception:
            pass
        finally:
            upstream.release()
        await out.write_eof()
        return out

    async def _ws(request: web.Request) -> web.WebSocketResponse:
        ws = web.WebSocketResponse(max_msg_size=0)
        await ws.prepare(request)
        http = state.http
        target_origin = _target_origin_for(request, state)
        if http is None or not target_origin:
            await _swallow(ws.close())
            return ws
        remote = re.sub(r"^http", "ws", target_origin, count=1) + request.raw_path
        headers: dict[str, str] = {}
        jar = await _session_cookie_header(state, target_origin + request.raw_path)
        if jar:
            headers["Cookie"] = jar
        if state.ua:
            headers["User-Agent"] = state.ua
        protocols = [p.strip() for p in
                     (request.headers.get("Sec-WebSocket-Protocol") or "").split(",") if p.strip()]
        try:
            upstream = await http.ws_connect(
                remote, protocols=protocols or (), headers=headers, max_msg_size=0)
        except Exception:
            await _swallow(ws.close())
            return ws

        async def _c2u() -> None:
            async for m in ws:
                if m.type == web.WSMsgType.TEXT:
                    await upstream.send_str(m.data)
                elif m.type == web.WSMsgType.BINARY:
                    await upstream.send_bytes(m.data)
                else:
                    break

        async def _u2c() -> None:
            async for m in upstream:
                if m.type == aiohttp.WSMsgType.TEXT:
                    await ws.send_str(m.data)
                elif m.type == aiohttp.WSMsgType.BINARY:
                    await ws.send_bytes(m.data)
                else:
                    break

        _done, pending = await asyncio.wait(
            {asyncio.create_task(_c2u()), asyncio.create_task(_u2c())},
            return_when=asyncio.FIRST_COMPLETED,
        )
        for t in pending:
            t.cancel()
        await _swallow(upstream.close())
        await _swallow(ws.close())
        return ws

    async def _handler(request: web.Request):
        if request.headers.get("Upgrade", "").lower() == "websocket":
            return await _ws(request)
        if state.render_mode != "live":
            return await _index(request)
        return await _http(request)

    return _handler


def _collimate_go_factory(state: _SessionState):
    """Live nav bootstrap. The iframe loads ``<subdomain>/__collimate/go?url=…``;
    we record the session's target origin, point the headless capture browser at
    it, and return a tiny page that registers the reroute service worker, waits
    for it to control, then loads the target's path from the subdomain root. The
    SW-first hop guarantees the real page's cross-origin API calls are caught
    from the very first request."""

    async def _go(request: web.Request) -> web.Response:
        raw = (request.query.get("url") or "").strip()
        if not raw:
            return web.Response(status=400, text="missing url")
        try:
            target = _normalise_url(raw)
        except Exception as exc:
            return web.Response(status=400, text=str(exc))
        state.live_target_origin = _origin_of(target)
        state.current_url = target
        cdp = state.cdp
        if cdp is not None:
            asyncio.get_running_loop().create_task(
                _swallow(cdp.send("Page.navigate", {"url": target})))
        p = urlparse(target)
        dest = p.path or "/"
        if p.query:
            dest += "?" + p.query
        html = (_GO_BOOTSTRAP_HTML
                .replace("__DEST__", json.dumps(dest))
                .replace("__SW__", _SW_PATH))
        return web.Response(text=html, content_type="text/html",
                            headers={"Cache-Control": "no-store"})

    return _go


async def _sw_handler(_request: web.Request) -> web.Response:
    """Serve the cross-origin reroute service worker with a root scope."""
    return web.Response(text=_REROUTE_SW_JS, headers={
        "Content-Type": "text/javascript; charset=utf-8",
        "Service-Worker-Allowed": "/",
        "Cache-Control": "no-store",
    })


def _xorigin_proxy_factory(state: _SessionState):
    """Generic cross-origin proxy (the reroute SW sends every cross-origin
    fetch/XHR here as ``/__collimate/x?u=<url>``). Fetch the real target
    carrying the session: inject its cookies, recompute Google origin-signed
    auth, present the app's real origin, strip framebusting + the upstream's
    own CORS headers, and stream it back same-origin to the page."""

    async def _handler(request: web.Request) -> web.StreamResponse:
        http = state.http
        target = (request.query.get("u") or "").strip()
        if not target.lower().startswith(("http://", "https://")):
            return web.Response(status=400, text="bad target")
        if http is None:
            return web.Response(status=502, text="live session not ready")

        req_headers = {k: v for k, v in request.headers.items()
                       if k.lower() not in _DROP_REQUEST_HEADERS}
        req_headers["Accept-Encoding"] = "identity"
        cookies = await _cookies_for(state, target)
        jar = "; ".join(f"{n}={v}" for n, v in cookies.items())
        if jar:
            req_headers["Cookie"] = jar
        if state.ua:
            req_headers.setdefault("User-Agent", state.ua)
        # Present as the app's real origin so same-origin checks + signed auth pass.
        origin = state.live_target_origin or _origin_of(target)
        if origin:
            req_headers["Origin"] = origin
            req_headers["Referer"] = origin + "/"
        _maybe_google_auth(target, origin, cookies, req_headers)

        body = await request.read()
        try:
            upstream = await http.request(
                request.method, target, headers=req_headers,
                data=body or None, allow_redirects=False,
                timeout=aiohttp.ClientTimeout(total=None, sock_connect=30, sock_read=None))
        except Exception as exc:
            return web.Response(status=502, text=f"xproxy failed: {exc}")

        if upstream.status >= 400:
            gen.log(f"[x] {request.method} {target[:90]} -> {upstream.status}")
        set_cookies = upstream.headers.getall("Set-Cookie", [])
        if set_cookies:
            asyncio.get_running_loop().create_task(
                _sync_set_cookies(state, target, set_cookies))

        self_origin = _self_origin(request)
        out_headers: dict[str, str] = {}
        for k, v in upstream.headers.items():
            lk = k.lower()
            if (lk in _FRAMEBUST_HEADERS or lk in _DROP_RESPONSE_HEADERS
                    or lk == "set-cookie" or lk.startswith("access-control-")):
                continue
            out_headers[k] = v
        out_headers["Cache-Control"] = "no-store"
        # The SW fetches us same-origin, so the page gets a basic response — no
        # CORS needed — but reflect the origin anyway for any direct callers.
        if self_origin:
            out_headers["Access-Control-Allow-Origin"] = self_origin
            out_headers["Access-Control-Allow-Credentials"] = "true"

        out = web.StreamResponse(status=upstream.status, headers=out_headers)
        for c in set_cookies:
            out.headers.add("Set-Cookie", _redomain_cookie(c, self_origin))
        await out.prepare(request)
        try:
            async for chunk in upstream.content.iter_chunked(1 << 16):
                await out.write(chunk)
        except Exception:
            pass
        finally:
            upstream.release()
        await out.write_eof()
        return out

    return _handler


async def _handle_client_message(state: _SessionState, payload: dict[str, Any]) -> None:
    """Route a renderer→generator message into the live page as CDP
    commands. Each branch is best-effort: a misbehaving page or a dead
    connection shouldn't take down the WS handler — log and move on so
    the next message gets a fresh shot."""
    kind = payload.get("kind")
    # Window open/hide doesn't touch CDP — record it even mid-relaunch,
    # when state.cdp is briefly None.
    if kind == "window":
        state.want_headful = (str(payload.get("action") or "") == "open")
        return
    cdp = state.cdp
    if cdp is None:
        return
    try:
        if kind == "pointer":
            x = float(payload.get("x", 0))
            y = float(payload.get("y", 0))
            t = payload.get("type")
            button = str(payload.get("button") or "left")
            bit = _BUTTON_BITS.get(button, 1)
            if t == "move":
                await cdp.send("Input.dispatchMouseEvent", {
                    "type": "mouseMoved", "x": x, "y": y,
                    "buttons": state.buttons, "modifiers": state.modifiers,
                })
            elif t == "down":
                state.buttons |= bit
                await cdp.send("Input.dispatchMouseEvent", {
                    "type": "mousePressed", "x": x, "y": y,
                    "button": button, "buttons": state.buttons,
                    "clickCount": 1, "modifiers": state.modifiers,
                })
            elif t == "up":
                state.buttons &= ~bit
                await cdp.send("Input.dispatchMouseEvent", {
                    "type": "mouseReleased", "x": x, "y": y,
                    "button": button, "buttons": state.buttons,
                    "clickCount": 1, "modifiers": state.modifiers,
                })
        elif kind == "wheel":
            await cdp.send("Input.dispatchMouseEvent", {
                "type": "mouseWheel",
                "x": float(payload.get("x", 0)),
                "y": float(payload.get("y", 0)),
                "deltaX": float(payload.get("deltaX", 0)),
                "deltaY": float(payload.get("deltaY", 0)),
                "modifiers": state.modifiers,
            })
        elif kind == "key":
            t = str(payload.get("type") or "")
            key = str(payload.get("key", ""))
            if not key:
                return
            # The renderer reports the event's live modifier mask (Alt1/Ctrl2/
            # Meta4/Shift8) — authoritative, so combos like Ctrl+A resolve even
            # if a modifier keydown was missed. Fall back to tracking the
            # modifier keys themselves for older messages without it.
            mods = payload.get("mods")
            if mods is not None:
                try:
                    state.modifiers = int(mods)
                except (TypeError, ValueError):
                    pass
            elif key in _MODIFIER_BITS:
                if t == "down":
                    state.modifiers |= _MODIFIER_BITS[key]
                elif t == "up":
                    state.modifiers &= ~_MODIFIER_BITS[key]
            if t == "press":
                await _dispatch_key(state, "down", key)
                await _dispatch_key(state, "up", key)
            else:
                await _dispatch_key(state, t, key)
        elif kind == "text":
            text = str(payload.get("text", ""))
            if text:
                await cdp.send("Input.insertText", {"text": text})
        elif kind == "paste":
            # The user's clipboard text, forwarded from the renderer. insertText
            # drops it into the focused field firing the usual input events.
            text = str(payload.get("text", ""))
            if text:
                await cdp.send("Input.insertText", {"text": text})
        elif kind == "viewport":
            w = int(payload.get("width", 0))
            h = int(payload.get("height", 0))
            w = max(_MIN_VIEWPORT[0], min(_MAX_VIEWPORT[0], w))
            h = max(_MIN_VIEWPORT[1], min(_MAX_VIEWPORT[1], h))
            try:
                dpr = float(payload.get("dpr") or state.dpr)
            except (TypeError, ValueError):
                dpr = state.dpr
            dpr = max(_MIN_DPR, min(_MAX_DPR, dpr))
            if state.viewport == (w, h) and state.dpr == dpr:
                return
            # Reflow the page to the new aspect, rendered at the
            # client's pixel density. Frames automatically follow the
            # new metrics because the screencast was started with
            # maxWidth/maxHeight large enough that Chrome doesn't
            # scale down for any sane cell size — no restart needed.
            await cdp.send("Emulation.setDeviceMetricsOverride", {
                "width": w, "height": h, "deviceScaleFactor": dpr, "mobile": False,
            })
            state.viewport = (w, h)
            state.dpr = dpr
            await _broadcast_json(state, {"kind": "viewport", "width": w, "height": h})
        elif kind == "nav":
            action = str(payload.get("action") or "go")
            if action == "go":
                raw = str(payload.get("url") or "").strip()
                if raw:
                    # Page.navigate resolves when navigation is accepted,
                    # not when the page loads — no need to detach.
                    await cdp.send("Page.navigate", {"url": _normalise_url(raw)})
            elif action in ("back", "forward"):
                history = await cdp.send("Page.getNavigationHistory")
                entries = history.get("entries") or []
                idx = history.get("currentIndex", 0) + (1 if action == "forward" else -1)
                if 0 <= idx < len(entries):
                    await cdp.send(
                        "Page.navigateToHistoryEntry",
                        {"entryId": entries[idx]["id"]},
                    )
            elif action == "reload":
                await cdp.send("Page.reload")
    except Exception as exc:
        gen.log(f"client message ({kind}) failed: {exc}")


def _char_vk(c: str) -> tuple[int, str]:
    """(windowsVirtualKeyCode, ``code``) for a single character so a
    command-modifier shortcut (Ctrl+A, Ctrl+Z) resolves in Chrome; 0/"" for
    anything that isn't a plain ASCII letter or digit."""
    if len(c) != 1:
        return 0, ""
    if c.isalpha() and c.isascii():
        u = c.upper()
        return ord(u), "Key" + u
    if c.isdigit() and c.isascii():
        return ord(c), "Digit" + c
    return 0, ""


async def _dispatch_key(state: _SessionState, t: str, key: str) -> None:
    """Translate one renderer key event into ``Input.dispatchKeyEvent``.

    Printable single chars ride a ``keyDown`` + ``text`` (which both
    fires the DOM event and inserts the character); special keys come
    from the VK table so Chrome's default actions (caret movement,
    deletion, Enter-submits) trigger. The puppeteer convention: a
    keyDown without text must be sent as ``rawKeyDown``."""
    cdp = state.cdp
    if cdp is None or t not in ("down", "up"):
        return
    # A command modifier (Alt/Ctrl/Meta — not Shift) means this is a shortcut,
    # not text: Ctrl+A must select-all, not type "a". So drop ``text`` and send
    # the virtual-key code/VK that lets Chrome resolve the shortcut.
    cmd_mod = bool(state.modifiers & 0b111)  # Alt|Ctrl|Meta
    if len(key) == 1 and key not in _KEY_VK:
        if t == "down":
            params: dict[str, Any] = {"type": "keyDown", "key": key}
            if cmd_mod:
                params["type"] = "rawKeyDown"
                vk, code = _char_vk(key)
                if vk:
                    params["windowsVirtualKeyCode"] = vk
                    params["nativeVirtualKeyCode"] = vk
                if code:
                    params["code"] = code
            else:
                params["text"] = key
        else:
            params = {"type": "keyUp", "key": key}
            if cmd_mod:
                vk, code = _char_vk(key)
                if vk:
                    params["windowsVirtualKeyCode"] = vk
                    params["nativeVirtualKeyCode"] = vk
                if code:
                    params["code"] = code
        params["modifiers"] = state.modifiers
        await cdp.send("Input.dispatchKeyEvent", params)
        return
    vk, code, text = _KEY_VK.get(key, (0, key, None))
    params = {
        "key": key,
        "code": code,
        "windowsVirtualKeyCode": vk,
        "nativeVirtualKeyCode": vk,
        "modifiers": state.modifiers,
    }
    if t == "down":
        params["type"] = "keyDown" if text else "rawKeyDown"
        if text:
            params["text"] = text
    else:
        params["type"] = "keyUp"
    await cdp.send("Input.dispatchKeyEvent", params)


def _ws_handler_factory(state: _SessionState):
    async def _handler(request: web.Request) -> web.WebSocketResponse:
        ws = web.WebSocketResponse(heartbeat=20)
        await ws.prepare(request)
        async with state.lock:
            vw, vh = state.viewport
            last_frame = state.last_frame
        try:
            init: dict[str, Any] = {
                "kind": "init",
                "mode": state.render_mode,
                "viewport": {"width": vw, "height": vh},
                "url": state.current_url,
                "frame": last_frame,  # may be None until the first paint (image mode)
                "headful": state.headful,
            }
            await ws.send_str(json.dumps(init))
        except Exception:
            return ws
        state.clients.add(ws)
        try:
            async for msg in ws:
                if msg.type != web.WSMsgType.TEXT:
                    continue
                try:
                    payload = json.loads(msg.data)
                except Exception:
                    continue
                if isinstance(payload, dict):
                    await _handle_client_message(state, payload)
        finally:
            state.clients.discard(ws)
        return ws
    return _handler


async def _index(_request: web.Request) -> web.Response:
    return web.Response(
        text=(
            "<!doctype html><meta charset=utf-8>"
            "<title>cdp live screencast</title>"
            "<p>Live CDP screencast + input WebSocket. Connect to "
            "<code>/__collimate/ws</code> to consume frames, or open the cell's renderer.</p>"
        ),
        content_type="text/html",
    )


async def _start_aiohttp(port: int, state: _SessionState) -> web.AppRunner:
    app = web.Application()
    # Daemon-internal endpoints under the reserved /__collimate/ prefix, matched
    # before the catch-all so they never collide with a proxied site's paths:
    #  - ws : renderer input + frame channel (both render modes; reached via the
    #         host's /proxy path, not the subdomain).
    #  - go : live nav bootstrap (registers the reroute SW, then loads the target).
    #  - sw.js / x : the cross-origin reroute service worker + the endpoint it
    #         sends every cross-origin fetch/XHR to (carries the session there).
    app.router.add_get(_CONTROL_WS_PATH, _ws_handler_factory(state))
    app.router.add_route("*", _GO_PATH, _collimate_go_factory(state))
    app.router.add_get(_SW_PATH, _sw_handler)
    app.router.add_route("*", _X_PATH, _xorigin_proxy_factory(state))
    # Catch-all: in live mode the subdomain reverse-proxies the real target page
    # (HTTP + WebSocket); otherwise it's the index. Registered last so the
    # reserved routes above win.
    app.router.add_route("*", "/{tail:.*}", _native_proxy_factory(state))
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", port)
    await site.start()
    gen.log(f"page-stream broadcaster listening on 127.0.0.1:{port}")
    return runner


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _normalise_url(raw: str) -> str:
    s = (raw or "").strip()
    if not s:
        raise RuntimeError(
            "Provide a URL as the picker prompt (e.g. https://example.com)."
        )
    # Repair hand-typed scheme mangling (https:/site, HTTP:site) instead
    # of just prefix-checking — urlparse would otherwise read "https" as
    # the hostname and the per-domain profile would key on "https_".
    m = re.match(r"^(https?):/{0,2}(.+)$", s, re.IGNORECASE)
    if m:
        s = f"{m.group(1).lower()}://{m.group(2)}"
    else:
        s = "https://" + s
    host = urlparse(s).hostname
    if not host or host in ("http", "https"):
        raise RuntimeError(
            f"{raw!r} doesn't look like a URL — try e.g. https://example.com"
        )
    return s


def _find_free_port(start: int = 9100) -> int:
    port = start
    while port < start + 1000:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                port += 1
    raise RuntimeError(f"No free port found in range {start}-{start + 1000}")
