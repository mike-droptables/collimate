# SPDX-License-Identifier: Apache-2.0
"""``_env_shared`` — shared helper for Docker-backed generators.

This is **generator code, not part of the SDK**: the ``collimate`` runtime stays
100% Docker-free (its environment surface — ``gen.serve_environment`` + the
``GeneratorHandle`` verbs — is Docker-agnostic). :class:`DockerEnvironment`
consolidates the container boilerplate that used to be re-embedded in every
Docker generator (``vscode_env`` / ``claude_cli`` / ``linux_env``): build the
image if missing, ``docker run`` with the cell workspace bind-mounted, exec /
background-process / port-exposure / terminal handlers, and teardown. Its
:meth:`~DockerEnvironment.serve` wires those into :func:`gen.serve_environment`
so an *environment* generator (an image used by multiple generators, e.g.
``linux_env``) is a few lines.

Import it as a ``_*`` sibling (copied alongside the generator at spawn, the same
way ``_cdp_shared`` is)::

    import os, sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from _env_shared import DockerEnvironment

A single-image, human-facing generator (``vscode_env`` / ``claude_cli``) uses
the lifecycle + ``exec`` / ``expose_port`` directly; an environment generator
calls :meth:`serve` to field a parent's requests.
"""
from __future__ import annotations

import os
import shlex
import socket
import threading
import time
import uuid
from pathlib import Path
from typing import Optional

__all__ = ["DockerEnvironment"]


def _free_port(start: int = 8000, end: int = 9999) -> int:
    for port in range(start, end):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError(f"no free port in [{start}, {end})")


def _quote(command) -> str:
    if isinstance(command, (list, tuple)):
        return " ".join(shlex.quote(str(c)) for c in command)
    return str(command)


class DockerEnvironment:
    """A container that backs a Docker generator.

    Owns the full container lifecycle. The cell workspace is bind-mounted
    (read-write by default) at ``mount`` so files a parent ``put_files`` lands
    are visible to ``exec``'d processes and their writes flow back (the host
    services the workspace plane against that same directory)."""

    def __init__(
        self,
        *,
        image: str,
        mount: str = "/work",
        mount_mode: str = "rw",
        workspace: Optional[str] = None,
        build_context: Optional[str] = None,
        environment: Optional[dict] = None,
        ports: Optional[dict] = None,
        volumes: Optional[dict] = None,
        command="sleep infinity",
        working_dir: Optional[str] = None,
        name_prefix: str = "collimate-env",
        kind: str = "environment",
    ) -> None:
        import docker  # generator-side dependency (PEP 723), never the SDK's

        import gen

        self.image = image
        self.mount = mount or ""
        self.workspace = os.path.abspath(workspace or gen.workspace_path())
        self._procs: dict[str, dict] = {}
        self._proc_seq = 0
        self._forwarders: list = []

        gen.status("Checking Docker…")
        self._client = docker.from_env()
        self._client.ping()
        self._ensure_image(build_context)
        self._relax_perms(self.workspace)

        # The cell workspace is bind-mounted (read-write by default) so a parent
        # can push files the container sees. Extra ``volumes`` merge in.
        vols: dict = {}
        if self.mount:
            vols[self.workspace] = {"bind": self.mount, "mode": mount_mode}
        vols.update(volumes or {})

        run: dict = {
            "labels": {
                "com.collimate.run_id": os.environ.get("COLLIMATE_RUN_ID", ""),
                "com.collimate.kind": kind,
            },
        }
        # command=None runs the image's own ENTRYPOINT/CMD (used by single-image
        # generators like vscode_env whose entrypoint launches the real process).
        if command is not None:
            run["command"] = command
        if ports:
            run["ports"] = ports
        wd = working_dir or (self.mount or None)
        if wd:
            run["working_dir"] = wd

        name = f"{name_prefix}-{uuid.uuid4().hex[:8]}"
        gen.status(f"Starting container {name}…")
        self._container = self._client.containers.run(
            image, detach=True, name=name, volumes=vols,
            environment=dict(environment or {}), **run,
        )

    @property
    def container(self):
        """The underlying docker-py ``Container`` (for direct ``exec_run`` /
        ``get_archive`` when a generator needs them)."""
        return self._container

    @property
    def container_id(self) -> str:
        return self._container.id if self._container is not None else ""

    # ── image / fs setup ────────────────────────────────────────────

    def _ensure_image(self, build_context: Optional[str]) -> None:
        import docker.errors

        import gen

        try:
            self._client.images.get(self.image)
            return
        except docker.errors.ImageNotFound:
            pass
        if not build_context:
            raise RuntimeError(
                f"image {self.image!r} not present and no build_context given"
            )
        gen.status("Building Docker image (first run — may take a few minutes)…")
        try:
            _, logs = self._client.images.build(
                path=str(Path(build_context).resolve()), tag=self.image, rm=True
            )
            for chunk in logs:
                if chunk.get("error"):
                    detail = chunk.get("errorDetail", {}).get("message") or chunk["error"]
                    raise RuntimeError(f"Docker build failed: {detail}")
                line = (chunk.get("stream") or "").rstrip()
                if line:
                    gen.log(line)
                    if line.startswith("Step "):
                        gen.status(f"Building image — {line.split(':', 1)[0].strip()}")
        except docker.errors.BuildError as e:
            raise RuntimeError(f"Docker build failed: {e}")

    @staticmethod
    def _relax_perms(root: str) -> None:
        # tempfile.mkdtemp creates 0700 dirs the container user can't traverse.
        try:
            os.chmod(root, 0o755)
            for dirpath, dirnames, filenames in os.walk(root):
                for d in dirnames:
                    try:
                        os.chmod(os.path.join(dirpath, d), 0o755)
                    except OSError:
                        pass
                for f in filenames:
                    try:
                        os.chmod(os.path.join(dirpath, f), 0o644)
                    except OSError:
                        pass
        except OSError as e:
            import gen
            gen.log(f"Could not relax workspace permissions: {e}")

    # ── execution plane ─────────────────────────────────────────────

    def exec(self, command, *, cwd: Optional[str] = None,
             env: Optional[dict] = None, timeout: Optional[float] = None) -> tuple:
        """Run ``command`` to completion; return ``(rc, output)``.

        When ``timeout`` is set the command is bounded with coreutils
        ``timeout`` (rc 124 on expiry) so a runaway command can't block the
        exec indefinitely — without it ``docker exec`` would never return."""
        # A string command is shell-interpreted (pipes/redirects), like
        # exec_background — a list is argv as given.
        cmd = list(command) if isinstance(command, (list, tuple)) else ["sh", "-c", str(command)]
        if timeout is not None:
            cmd = ["timeout", str(max(1, int(timeout))), *[str(c) for c in cmd]]
        res = self._container.exec_run(
            cmd, workdir=cwd or self.mount, environment=env or None, demux=False,
        )
        out = res.output
        if isinstance(out, (bytes, bytearray)):
            out = out.decode("utf-8", errors="replace")
        return (res.exit_code if res.exit_code is not None else -1, out or "")

    def exec_background(self, command, *, cwd: Optional[str] = None,
                        env: Optional[dict] = None) -> str:
        """Start a long-running process; return a process id (for
        :meth:`wait_process` / :meth:`stop_process`)."""
        self._proc_seq += 1
        token = f"colproc-{self._proc_seq}"
        pidfile, rcfile = f"/tmp/{token}.pid", f"/tmp/{token}.rc"
        # Run the command in a new session (so stop can signal the whole group)
        # and record its session-leader pid + exit code. The inner script is
        # shlex.quote'd as a single arg so the user command's own quoting can't
        # collide with the wrapper's.
        inner = f"{_quote(command)}; echo $? > {rcfile}"
        launcher = (
            f"setsid sh -c {shlex.quote(inner)} </dev/null >/dev/null 2>&1 & "
            f"echo $! > {pidfile}"
        )
        self._container.exec_run(
            ["sh", "-c", launcher], workdir=cwd or self.mount,
            environment=env or None, detach=True,
        )
        self._procs[token] = {"pidfile": pidfile, "rcfile": rcfile}
        return token

    def wait_process(self, process_id: str, *, timeout: Optional[float] = None) -> int:
        """Block until the background process exits; return its return code."""
        info = self._procs.get(process_id)
        if not info:
            return -1
        deadline = None if timeout is None else time.monotonic() + timeout
        while True:
            _rc, rc_out = self.exec(["sh", "-c", f"cat {info['rcfile']} 2>/dev/null"])
            if rc_out.strip().isdigit():
                return int(rc_out.strip())
            if deadline is not None and time.monotonic() >= deadline:
                return -1
            time.sleep(0.5)

    def stop_process(self, process_id: str) -> None:
        """Terminate the background process (its whole group)."""
        info = self._procs.pop(process_id, None)
        if not info:
            return
        self.exec(["sh", "-c",
                   f"kill -- -$(cat {info['pidfile']} 2>/dev/null) 2>/dev/null; "
                   f"rm -f {info['pidfile']} {info['rcfile']}"])

    def expose_port(self, port: int):
        """Forward a container port to a host port and return its
        :class:`~collimate._results.Endpoint` (a proxy URL the cell can iframe)."""
        import gen
        from collimate._results import Endpoint

        host_port = _free_port()
        container_ip = self._container_ip()
        self._start_forwarder(host_port, container_ip, int(port))
        # Register the host port so the cell host's proxy serves it. (serve_port
        # is the async gen.* wrapper; the bridge method is the sync core.)
        gen._require_bridge().serve_port(host_port, name=f"port-{port}")
        channel = os.environ.get("COLLIMATE_CHANNEL", "")
        run_id = os.environ.get("COLLIMATE_RUN_ID", "")
        url = f"/proxy/{channel}/{run_id}/{host_port}/"
        return Endpoint(kind="http", name=f"port-{port}", url=url, port=host_port)

    def _container_ip(self) -> str:
        """The container's bridge IP (reachable from the host on Linux).
        ``attrs`` is cached from creation, so reload first; fall back to the
        per-network address when the legacy top-level field is empty."""
        self._container.reload()
        ns = self._container.attrs.get("NetworkSettings", {}) or {}
        if ns.get("IPAddress"):
            return ns["IPAddress"]
        for net in (ns.get("Networks") or {}).values():
            if net.get("IPAddress"):
                return net["IPAddress"]
        raise RuntimeError("container has no reachable IP address")

    def _start_forwarder(self, host_port: int, target_ip: str, target_port: int) -> None:
        import select

        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(("127.0.0.1", host_port))
        srv.listen(64)
        srv.setblocking(False)
        stop = threading.Event()
        self._forwarders.append((srv, stop))

        def _pump(a, b):
            try:
                while not stop.is_set():
                    r, _, _ = select.select([a, b], [], [], 0.5)
                    for s in r:
                        data = s.recv(65536)
                        if not data:
                            return
                        (b if s is a else a).sendall(data)
            except OSError:
                pass
            finally:
                for s in (a, b):
                    try:
                        s.close()
                    except OSError:
                        pass

        def _accept():
            while not stop.is_set():
                try:
                    r, _, _ = select.select([srv], [], [], 0.5)
                    if not r:
                        continue
                    client, _ = srv.accept()
                except OSError:
                    break  # listener gone — stop accepting
                # A failed upstream connect (service not up yet / refused) must
                # NOT kill the listener or leak the accepted client.
                try:
                    up = socket.create_connection((target_ip, target_port))
                except OSError:
                    try:
                        client.close()
                    except OSError:
                        pass
                    continue
                threading.Thread(target=_pump, args=(client, up), daemon=True).start()

        threading.Thread(target=_accept, daemon=True).start()

    # ── terminals (human-watchable PTYs) ────────────────────────────

    def open_terminal(self, command=None, *, cwd: Optional[str] = None,
                      env: Optional[dict] = None) -> dict:
        """Allocate a PTY in the container; return ``{session_id, ws_path, token}``."""
        import gen

        return gen._require_bridge().start_terminal(
            container_id=self._container.id,
            command=command or ["bash"], cwd=cwd or self.mount, env=env,
        )

    def surface_terminal(self, *, label: str = "Shell", name: str = "shell.terminal") -> dict:
        """Open a PTY and write its ``.terminal`` pointer so the cell renders a
        live shell for a human running this environment directly."""
        import json

        import gen
        from collimate.pointers import terminal_pointer

        sess = self.open_terminal(["bash"])
        gen.update_file(name, json.dumps(terminal_pointer(sess, label=label)))
        return sess

    # ── lifecycle + serve wiring ────────────────────────────────────

    def close(self) -> None:
        """Stop forwarders and remove the container. Idempotent."""
        for srv, stop in self._forwarders:
            stop.set()
            try:
                srv.close()
            except OSError:
                pass
        self._forwarders.clear()
        container = getattr(self, "_container", None)
        if container is not None:
            # Graceful stop first (SIGTERM + 2s) so a process writing to a
            # mounted host dir — e.g. claude_cli's transcript under ~/.claude —
            # isn't SIGKILL'd mid-write; then force-remove.
            try:
                container.stop(timeout=2)
            except Exception:
                pass
            try:
                container.remove(force=True)
            except Exception:
                pass
            self._container = None

    async def serve(self, *, max_concurrency: int = 1) -> None:
        """Serve a parent's requests against this container until Stop, then
        tear the container down. Wires every handler :func:`gen.serve_environment`
        understands to this container."""
        import gen

        try:
            await gen.serve_environment(
                on_exec=lambda r: self.exec(r.command, cwd=r.cwd or None, env=r.env, timeout=r.timeout),
                on_exec_background=lambda r: self.exec_background(r.command, cwd=r.cwd or None, env=r.env),
                on_wait_process=lambda r: self.wait_process(r.process_id, timeout=r.timeout),
                on_stop_process=lambda r: self.stop_process(r.process_id),
                on_expose_port=lambda r: self.expose_port(r.port),
                on_terminal=lambda r: self.open_terminal(r.command, cwd=r.cwd or None, env=r.env),
                max_concurrency=max_concurrency,
            )
        finally:
            self.close()
