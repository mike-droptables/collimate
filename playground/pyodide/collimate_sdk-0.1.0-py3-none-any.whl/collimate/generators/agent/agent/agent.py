# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic-ai", "claude-agent-sdk", "docker", "mcp", "uvicorn", "starlette"]
# ///
"""Agent — the unified LLM agent generator.

One generator, four interaction modes (``agent-config.set_yaml`` ``mode``):

  * ``oneshot``          — a single turn; the composition default every other
    generator reaches via ``gen.call("agent", ...)``. Writes ``_agent/output.md``
    and (with an ``output_schema``) ``_agent/output.json``.
  * ``chat``             — interactive multi-thread streaming chat
    (``gen.serve_chat``, rendered by assistant-ui); the engine runs INLINE per
    turn on the cell's own files. Durable open-format transcripts, one per
    thread (``chats/<id>.json``).
  * ``claude-terminal``  — a live ``claude`` TTY in a container surfaced through
    the ``.terminal`` renderer. Requires a Claude model. Writes an open-format
    transcript (``chats/main.json``) from the CLI transcript at the end.
  * ``opencode``         — opencode's OWN web UI in a container surfaced through
    the ``.website`` renderer. Writes an open-format transcript
    (``chats/main.json``) from opencode's session storage at the end.

Backends (oneshot/chat): pydantic-ai / claude-agent-sdk / gemini.

File access is the norm, not a toggle: every mode works on the cell's own
files, and the interactive modes (chat / claude-terminal / opencode) keep them
in LIVE bidirectional sync with the Files tab via ``gen.live_files()`` — the
agent's writes appear as they happen, the user's edits reach the agent
mid-session. ``enable_file_tools`` still exists for composition callers
(``gen.call``) that want a text-only turn; it defaults to on. The python
toggle and the composition tools — via the single ``exposure`` dropdown
(``none`` / ``create_cell`` / ``run_generators`` — discover, read, and run
generators incl. standing up a live modify cell / ``modify_and_run`` — the full
builder that adds editing and committing generators & renderers) — remain
opt-in. The multi-backend engine + the tool definitions live in the sibling
``_agent_shared`` cell.

**Assumptions ledger** (``ledger``, default on): every mode also runs the
companion extraction pass from ``_agent_shared.ledger`` — the full-fidelity
trace persists as ``_agent/trace.json`` and the claimed/enacted/linked
commitment record as ``_agent/assumptions.ledger`` + ``_agent/assumptions.md``,
distinct outputs alongside ``_agent/output.*``. Composition callers promote
the ledger into whatever cell the call's output becomes.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys

import gen

# Own dir (for the sibling mode modules) + parent (for the _agent_shared /
# _env_shared sibling cell folders).
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
# The shared _* cell-folders are SIBLINGS at run time (materialised into
# the cell); in the repo/tests they live at the asset root, one level above
# this generator's cell parent folder. Insert both.
_here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(_here))
sys.path.insert(0, os.path.dirname(os.path.dirname(_here)))
from _agent_shared import (  # noqa: E402
    parse_agent_config,
    run_agent,
)
from _agent_shared import ledger as ledger_mod  # noqa: E402

_HISTORY_CHAR_BUDGET = 24000


async def run() -> None:
    cfg = parse_agent_config(gen.config("agent-config.set_yaml"))
    for w in cfg["warnings"]:
        gen.log(f"config: {w}")
    mode = cfg["mode"]

    if mode == "chat":
        await _run_chat(cfg)
    elif mode == "claude-terminal":
        from _agent_shared.claude_terminal import run_claude_terminal
        await run_claude_terminal(cfg, extra_system=cfg["system_prompt"])
    elif mode == "opencode":
        from _agent_shared.opencode import run_opencode
        await run_opencode(cfg, extra_system=cfg["system_prompt"])
    else:
        await _run_oneshot(cfg)


# ──────────────────────────────────────────────────────────────────────
# oneshot — the composition default
# ──────────────────────────────────────────────────────────────────────


async def _run_oneshot(cfg: dict) -> None:
    prompt = (gen.prompt or "").strip()
    gen.phase("running", f"{cfg['backend']} · {cfg['model']}")
    gen.log(
        f"backend={cfg['backend']} model={cfg['model']} "
        f"tools={'F' if cfg['enable_file_tools'] else ''}"
        f"{'P' if cfg['enable_python_tool'] else ''}"
        # composition ladder, low → high: C(reate_cell) · R(un_generators) · X(cross_cell)
        f"{'C' if cfg['enable_create_cell'] else ''}"
        f"{'R' if cfg['enable_run_generators'] else ''}"
        f"{'X' if cfg['enable_cross_cell'] else ''} "
        f"schema={'yes' if cfg['output_schema'] else 'no'} stream={cfg['stream']}"
    )

    def emit(ev: dict) -> None:
        gen.emit_event(ev)
        # Life signs in the run log — tool-heavy turns otherwise sit silent
        # (especially with stream=False) and look hung from the outside.
        if ev.get("type") == "tool" and ev.get("name"):
            gen.status(f"tool: {ev['name']}…")

    result = await run_agent(
        prompt=prompt,
        backend=cfg["backend"], auth=cfg["auth"], provider=cfg["provider"],
        model=cfg["model"], max_tokens=cfg["max_tokens"],
        system_prompt=cfg["system_prompt"],
        enable_file_tools=cfg["enable_file_tools"],
        enable_python_tool=cfg["enable_python_tool"],
        enable_run_generators=cfg["enable_run_generators"],
        enable_cross_cell=cfg["enable_cross_cell"],
        enable_create_cell=cfg["enable_create_cell"],
        output_schema=cfg["output_schema"],
        stream=cfg["stream"],
        thinking=cfg["thinking"],
        on_event=emit,
    )

    gen.update_file("_agent/output.md", result.text or "")
    if result.structured is not None:
        gen.update_file("_agent/output.json", json.dumps(result.structured, indent=2))
    # The trace is reproduction evidence, not ledger bookkeeping — a local file
    # write that costs no LLM call, so persist it even when the ledger pass is
    # off (composition callers that promote it, e.g. challenge probes, need it).
    gen.update_file(ledger_mod.TRACE_FILE, json.dumps(result.trace, indent=2, default=str))
    if cfg["ledger"]:
        gen.status("Extracting assumptions ledger…")
        await _write_ledger(cfg, result.trace, context=prompt)
    gen.emit_event({"type": "done", "backend": result.backend})

    summary = (
        (result.text or "").strip().splitlines()[0][:80]
        if result.text else f"agent · {result.backend}"
    )
    await gen.update(name=f"agent · {result.backend}", summary=summary)


async def _write_ledger(cfg: dict, trace: list, *, context: str = "") -> None:
    """Run the ledger extraction over the trace + the run's produced files
    (the trace itself is persisted by the caller, unconditionally). Best-effort
    by contract: a failed companion pass logs and leaves a degraded ledger,
    never fails the run."""
    try:
        artifacts = {
            p: gen.read_file(p) for p in gen.list_files() if not p.startswith("_agent/")
        }
        doc = await ledger_mod.extract_ledger(
            trace=trace, artifact_files=artifacts, cfg=cfg, context=context,
        )
        gen.update_file(ledger_mod.LEDGER_FILE, ledger_mod.dumps_ledger(doc))
        gen.update_file(ledger_mod.LEDGER_MD_FILE, ledger_mod.ledger_to_md(doc))
    except Exception as e:  # noqa: BLE001
        gen.log(f"[ledger] companion pass failed: {e}")


# ──────────────────────────────────────────────────────────────────────
# chat — interactive streaming, engine runs inline per turn
# ──────────────────────────────────────────────────────────────────────


_ROLE_LABELS = {"user": "User", "assistant": "Assistant", "system": "System"}


def _compose_prompt(messages: list, budget: int) -> str:
    """Fold the conversation so far into one prompt. The engine is stateless
    per turn (no message_history on any backend), so prior turns are serialized
    ahead of the latest user message; oldest turns past ``budget`` chars are
    dropped (most-recent-first)."""
    if len(messages) <= 1:
        return messages[-1].content if messages else ""
    current, prior = messages[-1], messages[:-1]
    kept: list = []
    used = 0
    truncated = False
    for m in reversed(prior):
        cost = len(m.content or "") + 16
        if kept and used + cost > budget:
            truncated = True
            break
        kept.append(m)
        used += cost
    kept.reverse()
    lines = ["You are continuing an ongoing chat conversation. "
             "Here is the transcript so far:", ""]
    if truncated:
        lines += ["[earlier messages omitted]", ""]
    for m in kept:
        lines.append(f"{_ROLE_LABELS.get((m.role or '').lower(), 'User')}: {m.content}")
        lines.append("")
    lines += ["Reply to the latest user message:", "", current.content]
    return "\n".join(lines)


async def _run_chat(cfg: dict) -> None:
    budget = cfg["history_char_budget"] or _HISTORY_CHAR_BUDGET

    # Ledger state across turns: the accumulated conversation trace, a turn
    # counter for the cadence, and an in-flight guard so a slow extraction
    # never stacks (the next cadence tick just picks up the newer trace).
    trace_acc: list = []
    turn_count = 0
    ledger_task: asyncio.Task | None = None

    def _schedule_ledger() -> None:
        nonlocal ledger_task
        if ledger_task and not ledger_task.done():
            return
        ledger_task = asyncio.create_task(
            _write_ledger(cfg, list(trace_acc))
        )

    async def on_turn(turn: gen.ChatTurn) -> None:
        nonlocal turn_count
        turn.append("user", turn.user_msg)   # bound to this turn's thread
        await gen.update()  # surface the user bubble immediately

        prompt = _compose_prompt(turn.messages, budget)
        chunks: list[str] = []
        think_chunks: list[str] = []

        def emit(ev: dict) -> None:
            if turn.cancelled or not ev.get("text"):
                return
            if ev.get("type") == "text_delta":
                chunks.append(ev["text"])
                turn.delta(ev["text"])
            elif ev.get("type") == "thinking_delta":
                think_chunks.append(ev["text"])
                turn.thinking_delta(ev["text"])

        reply = ""
        thinking = ""
        turn_trace: list | None = None
        try:
            result = await run_agent(
                prompt=prompt, stream=True, on_event=emit,
                should_stop=lambda: turn.cancelled,
                backend=cfg["backend"], auth=cfg["auth"], provider=cfg["provider"],
                model=cfg["model"], max_tokens=cfg["max_tokens"],
                system_prompt=cfg["system_prompt"],
                enable_file_tools=cfg["enable_file_tools"],
                enable_python_tool=cfg["enable_python_tool"],
                enable_run_generators=cfg["enable_run_generators"],
                enable_cross_cell=cfg["enable_cross_cell"],
                enable_create_cell=cfg["enable_create_cell"],
                thinking=cfg["thinking"],
            )
            # The engine's user events carry the whole folded history prompt —
            # accumulate a clean per-turn record instead: this turn's actual
            # user message + everything the model did with it.
            turn_trace = [{"type": "user", "text": turn.user_msg}] + [
                ev for ev in result.trace if ev.get("type") != "user"
            ]
            # Once interrupted, keep only what actually streamed — never resurrect
            # the full background answer for a turn the user stopped.
            if turn.cancelled:
                reply = "".join(chunks).strip()
                thinking = "".join(think_chunks).strip()
            else:
                reply = "".join(chunks).strip() or (result.text or "").strip()
                # The trace holds the authoritative full thinking (pydantic-ai
                # exposes it only there); streamed chunks are the fallback.
                thinking = "\n\n".join(
                    ev.get("text", "") for ev in result.trace
                    if ev.get("type") == "thinking" and ev.get("text")
                ).strip() or "".join(think_chunks).strip()
        except gen.Cancelled:
            if gen.cancelled:      # real run teardown — let serve_chat unwind
                raise
            # A per-turn modal cancel (e.g. the user dismissed the API-key
            # dialog). Pair the turn instead of leaving a dangling user bubble.
            reply = "".join(chunks).strip() or "_(no API key provided)_"
            thinking = "".join(think_chunks).strip()
        except Exception as e:  # noqa: BLE001
            reply = f"_(error: {e})_"
            thinking = "".join(think_chunks).strip()
            # A failed turn must not vanish from the ledger record — keep the
            # user message, whatever streamed, and the failure itself.
            turn_trace = [{"type": "user", "text": turn.user_msg}]
            if chunks:
                turn_trace.append({"type": "text", "text": "".join(chunks)})
            turn_trace.append({"type": "system_note", "text": f"turn failed: {e}"})

        if turn.cancelled and not reply:
            reply = "_(stopped by user)_"
        turn.append("assistant", reply or "_(empty response)_", thinking=thinking)
        await gen.update(summary=turn.user_msg[:80].replace("\n", " "))

        if turn_trace is not None:
            if turn.cancelled:
                turn_trace.append({
                    "type": "system_note", "text": "turn interrupted by user",
                })
            trace_acc.extend(turn_trace)
            # Persist the trace every turn regardless of the ledger cadence —
            # it's the reproduction record ("every mode records it") and a local
            # write, decoupled from the (LLM-costed) extraction pass below.
            gen.update_file(ledger_mod.TRACE_FILE, json.dumps(trace_acc, indent=2, default=str))
            turn_count += 1
            if cfg["ledger"] and turn_count % cfg["ledger_every_turns"] == 0:
                _schedule_ledger()

    # In-process backends have no direct assistant-ui integration, so the chat
    # is always rendered via the native ExternalStore runtime; the renderer
    # streams from this WebSocket (pointer integration=None).
    #
    # live_files: the engine's file tools work on this run's workspace — the
    # mirror makes those writes appear in the cell's Files tab as they happen
    # and pushes the user's Files-tab edits back into the workspace mid-run
    # (the manifest's live_files_mode: manual keeps the tab editable).
    #
    # initial_message: the run prompt seeds the first turn (only into a
    # virgin thread — serve_chat skips it on a resumed cell).
    try:
        async with gen.live_files():
            await gen.serve_chat(
                on_turn, label="Agent", resume=True,
                initial_message=(gen.prompt or "").strip(),
            )
    finally:
        # Don't let run teardown kill an in-flight ledger write mid-file —
        # bounded so shutdown can't hang on a slow extraction call.
        if ledger_task is not None and not ledger_task.done():
            try:
                await asyncio.wait_for(asyncio.shield(ledger_task), timeout=10)
            except Exception:  # noqa: BLE001 — best-effort by contract
                pass


if __name__ == "__main__":
    gen.main(run)
