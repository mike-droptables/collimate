# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic", "pydantic-ai", "claude-agent-sdk"]
# ///
"""Modify Files — an LLM agent edits cell files.

  * 1 input cell  → single agent run; mutates the running cell.
  * 2+ input cells → fan out (n → n): one agent per input, in parallel,
    each emitted as its own stack cell.

The agent is the hidden installed ``agent`` generator, called via
``gen.call("agent", ...)`` with the candidate's files as inputs and the
file + python tools enabled. Each call is an independent sub-run with its
own workspace, so parallel candidates never collide. The edited files come
back in ``result.files`` (the inputs, possibly mutated, plus anything the
agent created); the assistant text is ``result.files["_agent/output.md"]``.

The fan-out uses the shared ``gather_agent_calls`` helper (spawn-all-first,
poll, collect): a plain ``asyncio.gather`` over ``gen.call`` serializes on
the bridge's single IPC transaction lock and can freeze the event loop, and
it swallows a user stop. The child config is folded via ``oneshot_tag_values``
so the EXACT config the child receives is validated parent-side — a tag that
would blow up every sub-run fails here, once, before spending a call.
"""
from __future__ import annotations

import json
import os
import sys

import gen

# The shared _* cell-folders are SIBLINGS at run time (materialised into
# the cell); in the repo/tests they live at the asset root, one level above
# this generator's cell parent folder. Insert both.
_here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(_here))
sys.path.insert(0, os.path.dirname(os.path.dirname(_here)))
from _agent_shared import (  # noqa: E402
    gather_agent_calls,
    oneshot_tag_values,
    parse_agent_config,
)
from _agent_shared import ledger as ledger_mod  # noqa: E402


async def run() -> None:
    raw = gen.config("config.set_yaml")
    # The parent-generator convention: agent settings come from ONE named
    # config tag on the agent generator (blank → its defaults); this
    # generator overrides only what it has opinions about below.
    tag_values = gen.tag_config("agent", raw.get("agent_config_tag")).get(
        "agent-config.set_yaml", {})
    cfg = parse_agent_config(tag_values)
    prompt = (gen.prompt or "").strip()
    if not prompt:
        reason = "no task prompt provided"
        gen.log(reason)
        gen.update_file(
            "error.md",
            "# No task\n\nDescribe the task in the picker prompt.\n",
        )
        await gen.update(name="Modify Files", summary=f"Failed: {reason}")
        return

    # Identity first — the cell shows what it is while it works.
    await gen.update(name="Modify Files", summary="Editing cell files with an agent…")

    groups = gen.input_groups()

    # 1 input → mutate the running cell in place. Multi-input → n→n
    # fan-out. The manifest enforces min=1 so an empty groups dict is
    # unreachable here.
    if len(groups) == 1:
        label, files = next(iter(groups.items()))
        gen.phase("running", "Editing cell files…")
        spec = _build_spec(label, files, prompt, tag_values)
        # A single child, but still through gather_agent_calls so a user
        # stop unwinds cleanly (raises gen.Cancelled) instead of blocking
        # the event loop inside a bare gen.call wait.
        result = next(iter(await gather_agent_calls([spec], timeout=300)))
        await _commit_one(
            label=label,
            files=files,
            result=result,
            cfg=cfg,
            as_stack_cell=False,
        )
        return

    gen.phase("running", f"Modifying {len(groups)} cells in parallel…")
    # Fan out CONCURRENTLY. gather_agent_calls spawns every child first,
    # polls to completion, and collects — a plain asyncio.gather over
    # gen.call would serialize on the bridge's single IPC lock and can
    # freeze the loop. Per-candidate failures come back as ok=False results
    # (never a raised batch); a user stop raises gen.Cancelled and stops the
    # remaining children. The child config is folded/validated once inside
    # _build_spec, so a bad tag fails before the fan-out spends a call.
    labels = list(groups)
    specs = [_build_spec(lb, files, prompt, tag_values)
             for lb, files in groups.items()]
    results = await gather_agent_calls(specs, timeout=600)

    # Emit the per-candidate stack cells SEQUENTIALLY. create_stack_cell
    # stages its files into the shared parent workspace before emitting its
    # IPC op, so two concurrent commits with colliding filenames
    # (assumptions.ledger, output.md, sibling seed_ideas outputs) would race
    # the wrong content into a cell — one at a time closes that window.
    ledgers: dict[str, dict] = {}
    succeeded = 0
    for label, files, result in zip(labels, list(groups.values()), results):
        promoted = await _commit_one(
            label=label,
            files=files,
            result=result,
            cfg=cfg,
            as_stack_cell=True,
        )
        if result.ok:
            succeeded += 1
        if promoted is not None:
            ledgers[label] = promoted

    # Drop the workspace-level inputs/ files from the placeholder; the
    # n stack cells own the per-candidate output now.
    for inp in list(gen.list_files()):
        gen.delete_file(inp)

    # Turn the bare placeholder into a cross-candidate index + the merged
    # assumptions ledger. The differential marks the seams where the same
    # task, applied to N candidates, drove them apart — the whole point of
    # a fan-out is to make those seams visible.
    if ledgers:
        gen.status("Merging assumptions ledgers…")
        try:
            merged = ledger_mod.merge_ledgers(ledgers)
            if len(ledgers) >= 2:
                merged = await ledger_mod.compute_differential(merged, cfg)
            gen.update_file(ledger_mod.LEDGER_PROMOTED, ledger_mod.dumps_ledger(merged))
            gen.update_file("assumptions.md", ledger_mod.ledger_to_md(merged))
        except gen.Cancelled:
            raise
        except Exception as e:  # noqa: BLE001
            gen.log(f"[ledger] differential merge failed: {e}")

    gen.update_file("index.md", _fanout_index(labels, results, prompt))
    failed = len(groups) - succeeded
    summary = (
        f"Modified {succeeded} of {len(groups)} cells" + (f"; {failed} failed" if failed else "")
        if failed else f"Modified {len(groups)} cells in parallel"
    )
    await gen.update(
        name=f"modify-files × {len(groups)}",
        summary=summary,
        pinned="index.md",
    )


def _build_spec(label: str, files: dict, prompt: str, tag_values: dict) -> dict:
    """The ``gen.spawn`` kwargs for ONE candidate's agent sub-run.

    ``oneshot_tag_values`` folds the tag into a one-shot call config and
    VALIDATES it parent-side (raising before any call is spent), reconciles a
    ``claude-terminal`` tag to the equivalent oneshot backend, and forces the
    neutral values for keys that must not leak from the tag into this
    file-editing call: ``output_schema`` empty (a JSON-only reply would
    contradict the file-editing instructions and be committed verbatim) and
    ``stream`` off (gen.call never polls token deltas)."""
    user_msg = (
        f"Candidate: `{label}`\n\n"
        f"User task:\n\n{prompt}\n\n"
        "Use the file tools (list/read/write/edit) to mutate this "
        "candidate's files. You may run Python to compute or generate "
        "artifacts (charts, tables, …)."
    )

    # Feed forward what the user KNOWS (verified facts from the cell's
    # assumptions ledger) — never what the user prefers. Re-eliciting known
    # facts is waste; pre-filtering to predicted preferences is the oracle
    # failure state.
    effective_system = (tag_values.get("system_prompt") or "").strip()
    facts = ledger_mod.verified_facts_from_files(files)
    if facts:
        effective_system = (
            (effective_system + "\n\n" if effective_system else "")
            + "## Established constraints (user-verified facts)\n\n"
            + "\n".join(f"- {f}" for f in facts)
            + "\n\nTreat these as ground truth. If the task contradicts one "
            "of them, say so explicitly in your reply instead of silently "
            "complying."
        )

    return {
        "inputs": dict(files),
        "prompt": user_msg,
        "config": {"agent-config.set_yaml": oneshot_tag_values(
            tag_values,
            system_prompt=effective_system,
            enable_file_tools=True,
            enable_python_tool=True,
            output_schema="",
            stream=False,
            ledger=True,   # this candidate's ledger is PROMOTED into its cell
        )},
    }


async def _commit_one(
    *,
    label: str,
    files: dict,
    result,
    cfg: dict,
    as_stack_cell: bool,
) -> dict | None:
    """Commit ONE candidate's collected agent result.

    The agent already ran (via ``gather_agent_calls``); this stages the
    edited files back into either the placeholder cell (single-input) or a
    fresh stack cell (multi), and returns the promoted assumptions-ledger
    doc (parsed) so the fan-out can merge them — or ``None`` when there is no
    fresh ledger to promote.
    """
    original = dict(files)
    gen.log(f"{label}: {cfg['backend']} · {cfg['model'] or '(auto)'} · {len(original)} input files")

    if not result.ok:
        # Surface the failure into this candidate's output rather than
        # letting a paid-for sub-run vanish. SALVAGE any work the child
        # finished before it failed/timed out: a timeout ack still carries
        # the collected workspace, so committing the changed non-_agent
        # files (plus a loud error note) beats reverting to the input.
        err = result.error or "agent run failed"
        gen.log(f"{label}: agent run failed: {err}")
        salvaged = {
            p: c for p, c in (result.files or {}).items()
            if not p.startswith("_agent/") and original.get(p) != c
        }
        stage = dict(original)
        stage.update(salvaged)
        stage["output.md"] = f"# Agent run FAILED\n\n{err}\n"
        await _flush(
            label=label, stage=stage, original=original,
            cfg=cfg, as_stack_cell=as_stack_cell, failed=err,
        )
        return None

    # The edited candidate files = the child workspace minus the agent's
    # own scratch dir. These already include any files the agent created
    # via the python tool.
    stage = {p: c for p, c in result.files.items() if not p.startswith("_agent/")}
    text = result.files.get("_agent/output.md", "")

    # Prose-only fallback: agent answered in chat instead of editing files.
    if _stage_unchanged(stage, original) and text:
        stage["output.md"] = text

    # Promote the agent's assumptions ledger — the record of what this
    # modification claimed and enacted travels with the modified cell. But a
    # fresh extraction has NO user 'verified' verdicts: if the candidate
    # already carried a verdict-bearing ledger (the very file we read facts
    # forward from), clobbering it would erase those verdicts and break this
    # generator's own feed-forward loop. Union instead, so user marks survive.
    promoted: dict | None = None
    raw_ledger = result.files.get(ledger_mod.LEDGER_FILE)
    if raw_ledger:
        promoted = _merge_carried_ledger(original.get("assumptions.ledger"), raw_ledger)
        stage["assumptions.ledger"] = ledger_mod.dumps_ledger(promoted)

    await _flush(
        label=label, stage=stage, original=original,
        cfg=cfg, as_stack_cell=as_stack_cell, failed=None,
    )
    return promoted


async def _flush(
    *,
    label: str,
    stage: dict,
    original: dict,
    cfg: dict,
    as_stack_cell: bool,
    failed: str | None,
) -> None:
    """Commit ``stage`` as either the placeholder cell or a stack cell.

    ``failed`` (the error text) is threaded through so a failed run is
    committed as an UNAMBIGUOUS failure cell — never the "→ `file`" summary a
    success would get — while still leaving a visible cell (with any salvaged
    edits) rather than nothing."""
    if failed is not None:
        name = f"{label} · FAILED" if as_stack_cell else "modify-files · FAILED"
        summary = f"Failed: {_first_line(failed)}"
        pinned = "output.md"
    else:
        picked = _best_guess_summary(stage, original)
        changed = _changed_count(stage, original)
        if picked:
            summary = f"→ `{picked}`"
        elif changed:
            summary = f"Modified {changed} file(s)"
        else:
            # ok=True but nothing changed (empty reply, interrupted turn):
            # a paid-for run that did nothing must not read as a normal edit.
            summary = "No changes made"
        pinned = picked or None
        name = (f"{label} · {cfg['model']}" if as_stack_cell
                else f"modify-files · {cfg['backend']} · {cfg['model']}")

    if as_stack_cell:
        await gen.create_stack_cell(
            name=name,
            summary=summary,
            pinned=pinned,
            files=stage,
        )
    else:
        # Propagate DELETIONS: a file the agent removed is simply absent from
        # stage. The host re-inherits every input file on each placeholder
        # update, so without an explicit delete the removed file persists —
        # and _changed_count already counts it as a deletion, so the summary
        # would otherwise claim a deletion that never landed.
        for path in original:
            if path not in stage:
                gen.delete_file(path)
        for path, content in stage.items():
            gen.update_file(path, content)
        await gen.update(
            name=name,
            summary=summary,
            pinned=pinned,
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _stage_unchanged(stage: dict, original: dict) -> bool:
    return stage == original


def _changed_count(stage: dict, original: dict) -> int:
    # The promoted assumptions.ledger is bookkeeping the agent always writes;
    # counting it would report "Modified 1 file(s)" for a run whose only
    # delta is the ledger — a no-op dressed as an edit. Exclude it here to
    # match _best_guess_summary (which already skips it).
    changed = sum(1 for p, c in stage.items()
                  if original.get(p) != c and p != "assumptions.ledger")
    changed += sum(1 for p in original if p not in stage)
    return changed


def _best_guess_summary(stage: dict, original: dict) -> str:
    # The promoted ledger is a companion record, never "the modification".
    changed = [p for p, c in stage.items()
               if original.get(p) != c and p != "assumptions.ledger"]
    if not changed:
        return ""
    md = [p for p in changed if p.lower().endswith(".md")]
    return md[0] if md else changed[0]


def _merge_carried_ledger(carried, raw_fresh: str) -> dict:
    """Union the candidate's carried assumptions.ledger (verdict-bearing) with
    the child's freshly extracted one, so a modify pass never erases the
    user's 'verified' marks. Falls back to the fresh doc when there is no
    parseable carried ledger to preserve."""
    try:
        fresh = json.loads(raw_fresh)
    except Exception:  # noqa: BLE001 — an unparseable fresh ledger isn't promotable
        fresh = None
    old = None
    if isinstance(carried, str):
        try:
            old = json.loads(carried)
        except Exception:  # noqa: BLE001
            old = None
    if not isinstance(fresh, dict):
        # Nothing parseable to promote as a doc; keep the raw string's intent
        # by wrapping the old doc through unchanged when present.
        return old if isinstance(old, dict) else {}
    if not isinstance(old, dict):
        return fresh
    # merge_ledgers unions rows verbatim (keeping the old doc's user fields),
    # exactly the codebase's colliding-ledger convention.
    return ledger_mod.merge_ledgers({"before": old, "after": fresh})


def _fanout_index(labels: list, results: list, prompt: str) -> str:
    """A cross-candidate index for the placeholder: each candidate as its own
    side cell, marked ok/failed so a swallowed candidate can never masquerade
    as a silent success."""
    lines = [f"# Modified {len(labels)} cells", "", f"**Task:** {prompt}", "",
             "## Candidates", ""]
    for label, result in zip(labels, results):
        if result.ok:
            lines.append(f"- ✅ **{label}**")
        else:
            lines.append(f"- ⚠️ **{label}** — {_first_line(result.error or 'agent run failed')}")
    lines += ["", "_Each candidate above is its own side cell to the right of this one._"]
    return "\n".join(lines) + "\n"


def _first_line(text: str, limit: int = 120) -> str:
    text = (text or "").strip()
    if not text:
        return ""
    first = text.splitlines()[0]
    return first[:limit] + ("…" if len(first) > limit else "")


if __name__ == "__main__":
    gen.main(run)
