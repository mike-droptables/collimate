# /// script
# requires-python = ">=3.11"
# dependencies = ["aiohttp", "pyyaml"]
# ///
"""Browser Live — daemon-shaped browser session for any URL, raw CDP.

Launches the host's own Chrome with a DevTools port (no Playwright, no
Docker — see ``_cdp_shared/runtime.py``), streams the page into the
cell, and routes renderer input (pointer / keys / wheel / address-bar
navigation) back into the live page. Stages a ``session.webview``
artifact so the webview renderer (address bar + page canvas) picks the
cell up.

The ``render_mode`` setting picks the visual transport: ``live``
(default) runs the real page natively in a reverse-proxied iframe
(instant native interaction, logged in through this browser's session),
falling back to ``image`` for pages the proxy can't embed; ``image``
streams CDP screencast JPEG frames with input forwarded over the wire.

The capture button on the renderer's top bar adapts to the URL's host:

  - **claude.ai** / **aistudio.google.com** — ``Capture cell`` scrapes
    the conversation DOM (layered selector strategies; both UIs churn
    their markup every few months) and emits a sibling cell with
    ``conversation.md``, ``messages.json``, and one ``artifact_*.<ext>``
    per inline code block.
  - **anywhere else** — ``Capture page`` snapshots the current page
    into a sibling cell: ``page.md`` (title, URL, readable text,
    links), ``page.html`` (serialized DOM), ``screenshot.png``.

Chat hosts run hidden against a dedicated per-domain profile — sign in
once through the cell and the profile keeps the login across runs. The
headless tells (UA / Client Hints / WebGL) are scrubbed so Cloudflare
usually passes; if a challenge still loops, the renderer's "Open
window" button pops a real browser window to solve it by hand.
"""
from __future__ import annotations

import json
import os
import re
import sys
from typing import Any, Awaitable, Callable
from urllib.parse import urlsplit

# Pull the shared CDP runtime in from the private sibling dir.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from _cdp_shared.runtime import (  # noqa: E402
    CaptureContext,
    run_cdp_daemon,
)

import gen  # noqa: E402


# ── Generic page capture ────────────────────────────────────────────────

# Page-scrape JS. Runs inside the page via ``ctx.evaluate(...)``. Site-
# agnostic on purpose — innerText + anchors works everywhere, unlike the
# per-site selector walks of the chat captures below.
_PAGE_SCRAPE_JS = r"""
() => {
  const meta = document.querySelector('meta[name="description"]');
  const links = Array.from(document.querySelectorAll('a[href]'))
    .map((a) => ({
      text: (a.innerText || '').trim().replace(/\s+/g, ' ').slice(0, 120),
      href: a.href,
    }))
    .filter((l) => l.text && /^https?:/.test(l.href))
    .slice(0, 100);
  return {
    url: location.href,
    title: document.title,
    description: meta ? meta.content : '',
    capturedAt: new Date().toISOString(),
    text: document.body ? document.body.innerText : '',
    links,
  };
}
"""


def _format_page(scrape: dict[str, Any]) -> str:
    lines: list[str] = [
        f"# {scrape.get('title') or 'Untitled page'}",
        "",
        f"- **URL:** {scrape.get('url', '')}",
        f"- **Captured:** {scrape.get('capturedAt', '')}",
    ]
    if scrape.get("description"):
        lines.append(f"- **Description:** {scrape['description']}")
    lines += ["", "## Text", "", scrape.get("text") or "(no text content)"]
    links = scrape.get("links") or []
    if links:
        lines += ["", "## Links", ""]
        lines += [f"- [{l.get('text')}]({l.get('href')})" for l in links]
    lines.append("")
    return "\n".join(lines)


async def _capture_page(ctx: CaptureContext) -> None:
    scrape = await ctx.evaluate(_PAGE_SCRAPE_JS)
    if not isinstance(scrape, dict):
        gen.log(f"capture {ctx.capture_count}: scrape returned {type(scrape).__name__}")
        return
    # A capture is a full page snapshot: readable page.md plus the raw
    # DOM and a screenshot. Each heavy artifact is best-effort — a
    # failure logs and is skipped rather than losing the whole capture.
    files: dict[str, Any] = {"page.md": _format_page(scrape)}
    try:
        files["page.html"] = await ctx.html()
    except Exception as exc:
        gen.log(f"capture {ctx.capture_count}: html snapshot failed: {exc}")
    try:
        files["screenshot.png"] = await ctx.screenshot_png()
    except Exception as exc:
        gen.log(f"capture {ctx.capture_count}: screenshot failed: {exc}")
    title = (scrape.get("title") or scrape.get("url") or "page").strip()
    name = f"Page — {title[:60]}".strip()
    await gen.create_stack_cell(
        name=name,
        summary=f"captured {scrape.get('url', '')}",
        pinned="page.md",
        files=files,
    )
    gen.log(f"capture {ctx.capture_count}: emitted '{name}'")


# ── claude.ai conversation capture ──────────────────────────────────────

# DOM-scrape JS. Runs inside the page via ``ctx.evaluate(...)``. Returns
# JSON-safe data the Python side renders into cell files.
#
# Tries multiple selector strategies in priority order and uses whichever
# matched the most messages — claude.ai's markup churns every few months
# and the older class-name shape sticks around for a while alongside the
# new one.
_CLAUDE_SCRAPE_JS = r"""
() => {
  const tryStrategies = [
    // 1. Modern: explicit role-tagged data-testid attributes.
    () => {
      const els = document.querySelectorAll(
        '[data-testid="user-message"], [data-testid="assistant-message"]'
      );
      return Array.from(els).map((el) => ({
        role: (el.getAttribute('data-testid') || '').includes('user')
          ? 'user' : 'assistant',
        el,
      }));
    },
    // 2. 2024-vintage: claude.ai uses CSS classes for role tagging.
    () => {
      const out = [];
      document.querySelectorAll(
        '.font-user-message, .font-claude-message'
      ).forEach((el) => {
        out.push({
          role: el.classList.contains('font-user-message')
            ? 'user' : 'assistant',
          el,
        });
      });
      return out;
    },
    // 3. Last-ditch fallback: walk every `[role="presentation"]` block
    //    looking for sibling-pair text content. Marks role as 'unknown'.
    () => {
      const blocks = document.querySelectorAll('[data-test-render-count]');
      return Array.from(blocks).map((el) => ({ role: 'unknown', el }));
    },
  ];

  let messages = [];
  for (const strat of tryStrategies) {
    try {
      const result = strat();
      if (result.length > messages.length) messages = result;
    } catch (_) { /* try next */ }
  }

  // Resolve each message into transcribed text + inline artifacts.
  const out = messages.map((m) => {
    const text = (m.el.innerText || '').trim();
    const artifacts = [];
    m.el.querySelectorAll('pre code').forEach((code) => {
      const cls = code.className || '';
      const match = cls.match(/language-(\S+)/);
      const language = match ? match[1] : 'text';
      const content = code.innerText || '';
      if (content.trim()) {
        artifacts.push({ kind: 'code', language, content });
      }
    });
    return { role: m.role, text, artifacts };
  });

  return {
    url: location.href,
    title: document.title,
    capturedAt: new Date().toISOString(),
    messages: out,
  };
}
"""


# ── Google AI Studio conversation capture ───────────────────────────────

# AI Studio's chat UI is built on Angular web components — turn blocks
# are ``<ms-chat-turn>``, user text lives in ``<ms-text-chunk>`` slots,
# and model output renders through ``<ms-cmark-node>``. Selectors are
# brittle by nature (Google has rewritten the Studio UI three times in
# the last two years), so the scrape tries layered strategies and falls
# through to plain ``innerText`` when nothing more structured matches.
_AISTUDIO_SCRAPE_JS = r"""
() => {
  const tryStrategies = [
    // 1. Modern AI Studio: each turn is an <ms-chat-turn> custom element
    //    with a [data-turn-role] or `.user-prompt` / `.model-prompt`
    //    class signal.
    () => {
      const turns = document.querySelectorAll('ms-chat-turn');
      return Array.from(turns).map((el) => {
        let role = 'unknown';
        if (el.classList.contains('user-prompt-container')
            || el.querySelector('.user-prompt')) role = 'user';
        else if (el.classList.contains('model-prompt-container')
            || el.querySelector('.model-prompt')) role = 'assistant';
        // Some builds drop a data attribute that resolves cleanly:
        const attr = el.getAttribute('data-turn-role');
        if (attr) role = attr.toLowerCase().includes('user') ? 'user' : 'assistant';
        return { role, el };
      });
    },
    // 2. Older AI Studio: alternating .user-prompt-container / .model-prompt-container
    () => {
      const blocks = document.querySelectorAll(
        '.user-prompt-container, .model-prompt-container'
      );
      return Array.from(blocks).map((el) => ({
        role: el.classList.contains('user-prompt-container') ? 'user' : 'assistant',
        el,
      }));
    },
    // 3. Generic fallback: every <ms-cmark-node> is one assistant turn,
    //    and the immediately-preceding <ms-text-chunk> with class
    //    ``user-prompt-text`` is its user turn.
    () => {
      const out = [];
      document.querySelectorAll('ms-cmark-node, ms-text-chunk').forEach((el) => {
        const role = el.tagName.toLowerCase() === 'ms-text-chunk'
          ? 'user' : 'assistant';
        out.push({ role, el });
      });
      return out;
    },
  ];

  let messages = [];
  for (const strat of tryStrategies) {
    try {
      const result = strat();
      if (result.length > messages.length) messages = result;
    } catch (_) { /* try next */ }
  }

  const out = messages.map((m) => {
    const text = (m.el.innerText || '').trim();
    const artifacts = [];
    m.el.querySelectorAll('pre code, code-block').forEach((code) => {
      const cls = code.className || '';
      const langMatch = cls.match(/language-(\S+)/);
      let language = langMatch ? langMatch[1] : '';
      if (!language) {
        // AI Studio sometimes labels the language on a sibling header.
        const header = code.closest('code-block')
          ?.querySelector('.code-block-decoration-header, .code-block-language')
          ?.innerText || '';
        language = header.trim().toLowerCase() || 'text';
      }
      const content = code.innerText || '';
      if (content.trim()) {
        artifacts.push({ kind: 'code', language, content });
      }
    });
    return { role: m.role, text, artifacts };
  });

  return {
    url: location.href,
    title: document.title,
    capturedAt: new Date().toISOString(),
    messages: out,
  };
}
"""


# ── Shared conversation-capture helpers ─────────────────────────────────

# Roughly-conventional extensions per language slug. The list is short
# on purpose — anything not here writes as ``.txt`` so a renderer can
# still pick it up. Add entries when an actual user need surfaces.
_LANG_EXT = {
    "python": "py",
    "py": "py",
    "javascript": "js",
    "js": "js",
    "typescript": "ts",
    "ts": "ts",
    "tsx": "tsx",
    "jsx": "jsx",
    "html": "html",
    "css": "css",
    "json": "json",
    "yaml": "yaml",
    "yml": "yaml",
    "bash": "sh",
    "sh": "sh",
    "shell": "sh",
    "markdown": "md",
    "md": "md",
    "sql": "sql",
    "go": "go",
    "rust": "rs",
    "rs": "rs",
    "java": "java",
    "kotlin": "kt",
    "swift": "swift",
    "c": "c",
    "cpp": "cpp",
    "csharp": "cs",
    "ruby": "rb",
    "php": "php",
}


def _safe_slug(text: str, max_len: int = 40) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9]+", "-", text).strip("-").lower()
    return cleaned[:max_len] or "untitled"


def _format_transcript(scrape: dict[str, Any], heading: str) -> str:
    lines: list[str] = [
        f"# {heading}",
        "",
        f"- **URL:** {scrape.get('url', '')}",
        f"- **Captured:** {scrape.get('capturedAt', '')}",
        "",
    ]
    for i, msg in enumerate(scrape.get("messages") or [], start=1):
        role = (msg.get("role") or "unknown").title()
        text = msg.get("text") or ""
        lines.append(f"## {i}. {role}")
        lines.append("")
        lines.append(text)
        lines.append("")
        for art in msg.get("artifacts") or []:
            if art.get("kind") != "code":
                continue
            lang = art.get("language") or "text"
            content = art.get("content") or ""
            lines.append(f"```{lang}")
            lines.append(content)
            lines.append("```")
            lines.append("")
    return "\n".join(lines)


def _emit_capture(scrape: dict[str, Any], heading: str) -> dict[str, str]:
    """Build the file map for one captured-conversation snapshot.

    Conversation captures always include each code block as its own file
    alongside the transcript."""
    files: dict[str, str] = {
        "conversation.md": _format_transcript(scrape, heading),
        "messages.json": json.dumps(scrape, indent=2, ensure_ascii=False),
    }
    seen: dict[str, int] = {}
    for msg in scrape.get("messages") or []:
        for art in msg.get("artifacts") or []:
            if art.get("kind") != "code":
                continue
            lang = (art.get("language") or "text").lower()
            ext = _LANG_EXT.get(lang, "txt")
            base = f"artifact_{seen.get(ext, 0) + 1}.{ext}"
            seen[ext] = seen.get(ext, 0) + 1
            files[base] = art.get("content") or ""
    return files


def _make_chat_capture(
    scrape_js: str,
    *,
    heading: str,
    name_prefix: str,
    fallback_title: str,
    source: str,
) -> Callable[[CaptureContext], Awaitable[None]]:
    async def _on_capture(ctx: CaptureContext) -> None:
        scrape = await ctx.evaluate(scrape_js)
        if not isinstance(scrape, dict):
            gen.log(f"capture {ctx.capture_count}: scrape returned {type(scrape).__name__}")
            return
        msgs = scrape.get("messages") or []
        files = _emit_capture(scrape, heading)
        title = scrape.get("title") or fallback_title
        slug = _safe_slug(title)
        name = f"{name_prefix} — {title[:60]}".strip()
        summary = (
            f"{len(msgs)} message{'' if len(msgs) == 1 else 's'} captured "
            f"from {source}"
        )
        await gen.create_stack_cell(
            name=name,
            summary=summary,
            pinned="conversation.md",
            files=files,
        )
        gen.log(f"capture {ctx.capture_count}: emitted '{name}' ({slug})")

    return _on_capture


# ── URL-host dispatch ───────────────────────────────────────────────────

def _hostname(url: str) -> str:
    # run_cdp_daemon adds the missing scheme itself; mirror that here so
    # "claude.ai/new" still dispatches to the claude strategy.
    raw = url if "://" in url else f"https://{url}"
    try:
        return (urlsplit(raw).hostname or "").lower()
    except ValueError:
        return ""


def _host_matches(host: str, domain: str) -> bool:
    return host == domain or host.endswith("." + domain)


async def run() -> None:
    cfg = gen.config("settings.set_yaml")
    render_mode = (cfg.get("render_mode") or "live").strip()
    profile_name = (cfg.get("profile") or "default").strip() or "default"
    chrome_path = (cfg.get("chrome_path") or "").strip() or None
    xvfb = bool(cfg.get("xvfb", True))

    url = (gen.prompt or "").strip()
    if not url:
        gen.update_file(
            "error.md",
            "# No URL\n\nType the URL to open (e.g. `https://example.com`) "
            "into the picker prompt.\n",
        )
        return

    host = _hostname(url)
    if _host_matches(host, "claude.ai"):
        capture_button_label = "Capture cell"
        on_capture = _make_chat_capture(
            _CLAUDE_SCRAPE_JS,
            heading="Claude.ai conversation",
            name_prefix="Claude",
            fallback_title="Claude conversation",
            source="claude.ai",
        )
    elif _host_matches(host, "aistudio.google.com"):
        capture_button_label = "Capture cell"
        on_capture = _make_chat_capture(
            _AISTUDIO_SCRAPE_JS,
            heading="Google AI Studio conversation",
            name_prefix="AI Studio",
            fallback_title="AI Studio conversation",
            source="aistudio.google.com",
        )
    else:
        capture_button_label = "Capture page"
        on_capture = _capture_page

    await run_cdp_daemon(
        url=url,
        cell_name="Browser Live",
        cell_summary=f"Live: {url}",
        on_capture=on_capture,
        capture_button_label=capture_button_label,
        artifact_filename="session.webview",
        chrome_path=chrome_path,
        render_mode=render_mode,
        profile_name=profile_name,
        xvfb=xvfb,
    )


if __name__ == "__main__":
    gen.main(run)
