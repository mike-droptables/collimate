# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "anthropic"]
# ///
"""Anthropic Chat generator — in-process Messages API with unlocked history.

Runs the entire turn loop in-process using anthropic.messages.stream(...)
with three hand-rolled tools (read_file, write_file, edit_file). Streams
its own events to the frontend via gen.chat.emit_stream_event.

Chat history is unlocked during running (user can edit/delete old messages).
Files are live-editable.
"""

from __future__ import annotations

import os
import uuid

from collimate.sdk import Generator

gen = Generator()


def _run_anthropic_turn(
    *,
    latest_user: str,
    history: list,
    model: str,
    system_prompt: str,
    api_key: str,
) -> str:
    """Run one chat turn via the Anthropic Messages API with three
    hand-rolled tools. Streams text deltas as chat_stream events."""
    try:
        import anthropic
    except ImportError as exc:
        raise RuntimeError(
            "anthropic_chat requires the 'anthropic' package"
        ) from exc

    model_map = {
        "haiku": "claude-haiku-4-5-20251001",
        "sonnet": "claude-sonnet-4-6",
        "opus": "claude-opus-4-6",
    }
    resolved_model = model_map.get(model, model)

    client = anthropic.Anthropic(api_key=api_key or None)

    tools = [
        {
            "name": "read_file",
            "description": "Read the contents of a file in the workspace.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Relative file path"},
                },
                "required": ["path"],
            },
        },
        {
            "name": "write_file",
            "description": "Write (or overwrite) a file in the workspace.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "path": {"type": "string"},
                    "content": {"type": "string"},
                },
                "required": ["path", "content"],
            },
        },
        {
            "name": "edit_file",
            "description": "Replace the first occurrence of 'old' with 'new' in a file.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "path": {"type": "string"},
                    "old": {"type": "string"},
                    "new": {"type": "string"},
                },
                "required": ["path", "old", "new"],
            },
        },
    ]

    def _run_tool(name: str, tool_input: dict) -> str:
        if name == "read_file":
            path = tool_input.get("path", "")
            try:
                return gen.fs.read(path)
            except FileNotFoundError:
                return f"(file not found: {path})"
        if name == "write_file":
            path = tool_input.get("path", "")
            content = tool_input.get("content", "")
            gen.fs.write(path, content)
            return f"(wrote {len(content)} bytes to {path})"
        if name == "edit_file":
            path = tool_input.get("path", "")
            old = tool_input.get("old", "")
            new = tool_input.get("new", "")
            try:
                current = gen.fs.read(path)
            except FileNotFoundError:
                return f"(file not found: {path})"
            if old not in current:
                return "(old string not found in file)"
            updated = current.replace(old, new, 1)
            gen.fs.write(path, updated)
            return f"(edited {path})"
        return f"(unknown tool: {name})"

    prior = [
        {"role": m.role, "content": m.content}
        for m in history
        if m.role in ("user", "assistant")
    ]
    if prior and prior[-1]["role"] == "user":
        prior = prior[:-1]
    prior.append({"role": "user", "content": latest_user})

    turn_id = uuid.uuid4().hex
    gen.chat.emit_stream_event(turn_id, {"type": "turn_start", "turn_id": turn_id})

    assistant_text_parts: list[str] = []
    messages = list(prior)

    while True:
        create_kwargs = {
            "model": resolved_model,
            "max_tokens": 4096,
            "messages": messages,
            "tools": tools,
        }
        if system_prompt:
            create_kwargs["system"] = system_prompt

        text_for_this_round: list[str] = []
        tool_use_blocks: list = []
        stop_reason = None
        final_content_blocks = []

        with client.messages.stream(**create_kwargs) as stream:
            for event in stream.text_stream:
                gen.chat.emit_stream_event(turn_id, {
                    "type": "text_delta",
                    "turn_id": turn_id,
                    "text": event,
                })
                text_for_this_round.append(event)
            final_message = stream.get_final_message()

        stop_reason = final_message.stop_reason
        final_content_blocks = final_message.content
        assistant_text_parts.append("".join(text_for_this_round))

        for block in final_content_blocks:
            if getattr(block, "type", None) == "tool_use":
                tool_use_blocks.append(block)

        if not tool_use_blocks or stop_reason == "end_turn":
            break

        messages.append({"role": "assistant", "content": final_content_blocks})
        tool_results = []
        for tu in tool_use_blocks:
            gen.chat.emit_stream_event(turn_id, {
                "type": "tool_start",
                "turn_id": turn_id,
                "name": tu.name,
                "input": tu.input,
                "tool_use_id": tu.id,
            })
            result = _run_tool(tu.name, tu.input)
            gen.chat.emit_stream_event(turn_id, {
                "type": "tool_end",
                "turn_id": turn_id,
                "name": tu.name,
                "tool_use_id": tu.id,
            })
            if tu.name in ("write_file", "edit_file"):
                path = tu.input.get("path", "")
                if path:
                    try:
                        new_content = gen.fs.read(path)
                        gen.chat.emit_stream_event(turn_id, {
                            "type": "file_changed",
                            "turn_id": turn_id,
                            "path": path,
                            "content": new_content,
                        })
                    except Exception:
                        pass
            tool_results.append({
                "type": "tool_result",
                "tool_use_id": tu.id,
                "content": result,
            })
        messages.append({"role": "user", "content": tool_results})

    gen.chat.emit_stream_event(turn_id, {"type": "turn_end", "turn_id": turn_id, "usage": {}})
    return "".join(assistant_text_parts)


@gen.run(name="Anthropic Chat")
def main() -> None:
    settings = gen.config.read_schema_values("settings.set_yaml")
    model = settings.get("model", "sonnet")
    system_prompt = settings.get("system_prompt", "") or ""
    api_key = settings.get("api_key", "") or os.environ.get("ANTHROPIC_API_KEY", "")

    if not api_key:
        raise RuntimeError(
            "Anthropic Chat requires an API key in settings or ANTHROPIC_API_KEY in the environment"
        )

    latest_user = (gen.params.get("user_message") or "").strip()
    if not latest_user:
        user_msgs = [m for m in gen.chat.history if m.role == "user"]
        if user_msgs:
            latest_user = user_msgs[-1].content

    # Initial update to populate the placeholder cell
    gen.update_cell(name="Chat", summary="Starting...")

    if latest_user:
        try:
            gen.status = "Calling Anthropic API..."
            assistant_text = _run_anthropic_turn(
                latest_user=latest_user,
                history=gen.chat.history,
                model=model,
                system_prompt=system_prompt,
                api_key=api_key,
            )
            gen.chat.append("assistant", assistant_text)
            summary = latest_user[:80].replace("\n", " ")
            gen.update_cell(name="Chat", summary=summary)
        except Exception as e:
            gen.log.exception("Initial turn failed")
            gen.chat.append("assistant", f"Error: {e}")
            gen.update_cell(name="Chat", summary=f"Error: {str(e)[:60]}")

    # Enter the wait loop for subsequent messages
    gen.status = "Ready \u2014 type your message below"
    while True:
        msg = gen.chat.wait_for_message()
        if msg is None:
            break
        # Don't append the user message — the frontend already wrote it
        # to .collimate_messages.json via the draft mechanism and the
        # push_message endpoint flushed it to the workspace.
        try:
            gen.status = "Calling Anthropic API..."
            assistant_text = _run_anthropic_turn(
                latest_user=msg,
                history=gen.chat.history,
                model=model,
                system_prompt=system_prompt,
                api_key=api_key,
            )
            gen.chat.append("assistant", assistant_text)
            summary = msg[:80].replace("\n", " ")
            gen.update_cell(name="Chat", summary=summary)
        except Exception as e:
            gen.log.exception("Turn failed")
            gen.chat.append("assistant", f"Error: {e}")
            gen.update_cell(name="Chat", summary=f"Error: {str(e)[:60]}")
        gen.status = "Ready \u2014 type your message below"


main()
