# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Claude Code Chat generator — persistent container session with locked history.

Uses the claude_code_session backend for warm-container streaming. Chat
history is locked during running (new messages only at the bottom via
quick-send). Files are live-editable.
"""

from __future__ import annotations

from collimate.sdk import Generator

gen = Generator()


def _run_turn(latest_user: str, model: str, system_prompt: str):
    """Execute a single chat turn via the claude_code_session backend."""
    gen.status = "Opening chat session..."
    gen.chat.start_session(
        image="collimate-chat-worker",
        dockerfile_dir=gen.shared(),
        shared=True,
        backend="claude_code_session",
        model=model,
        system_prompt=system_prompt,
    )
    gen.status = "Sending turn..."
    res = gen.chat.send_turn(content=latest_user)
    ast_text = res.get("assistant_text")
    if ast_text:
        gen.chat.append("assistant", ast_text)

    summary = latest_user[:80].replace("\n", " ")
    gen.update_cell(name="Chat", summary=summary)


@gen.run(name="Claude Code Chat")
def main() -> None:
    settings = gen.config.read_schema_values("settings.set_yaml")
    model = settings.get("model", "sonnet")
    system_prompt = settings.get("system_prompt", "") or ""

    latest_user = (gen.params.get("user_message") or "").strip()
    if not latest_user:
        user_msgs = [m for m in gen.chat.history if m.role == "user"]
        if user_msgs:
            latest_user = user_msgs[-1].content

    # Initial update to populate the placeholder cell
    gen.update_cell(name="Chat", summary="Starting...")

    if latest_user:
        try:
            _run_turn(latest_user, model, system_prompt)
        except Exception as e:
            gen.log.exception("Initial turn failed")
            gen.chat.append("assistant", f"Error: {e}")
            gen.update_cell(name="Chat", summary=f"Error: {str(e)[:60]}")

    # Enter the wait loop for subsequent messages
    gen.status = "Ready \u2014 type your message below"
    while True:
        msg = gen.chat.wait_for_message()
        if msg is None:
            break
        # Don't append the user message — the frontend already wrote it
        # to .collimate_messages.json via the draft mechanism and the
        # push_message endpoint flushed it to the workspace.
        try:
            _run_turn(msg, model, system_prompt)
        except Exception as e:
            gen.log.exception("Turn failed")
            gen.chat.append("assistant", f"Error: {e}")
            gen.update_cell(name="Chat", summary=f"Error: {str(e)[:60]}")
        gen.status = "Ready \u2014 type your message below"


main()
