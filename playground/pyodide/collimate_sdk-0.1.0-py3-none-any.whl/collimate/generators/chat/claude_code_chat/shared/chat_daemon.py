"""Multi-session chat worker daemon. Runs as PID 1 inside the chat-worker
container.

One daemon hosts N concurrent ClaudeSDKClient sessions, each scoped to its
own /workspace/<session_id>/ directory. Sessions are reference-counted by
the host: when the last session closes, the host shuts the container down.

Reads newline-delimited JSON ops on stdin, emits newline-delimited JSON
events on stdout (every event tagged with session_id so the host can
route it back to the right cell).

Ops accepted on stdin:
  {"op": "open_session", "session_id": "...", "model": "...",
   "system_prompt": "..."}
  {"op": "sync_workspace", "session_id": "...",
   "files": {"<rel>": "<utf8>"}, "turn_id": "..."}
  {"op": "user_turn", "session_id": "...", "content": "...",
   "turn_id": "...", "model": "...", "system_prompt": "..."}
  {"op": "interrupt", "session_id": "..."}
  {"op": "close_session", "session_id": "..."}
  {"op": "shutdown"}

Events emitted on stdout:
  {"type": "ready"}                                  -- daemon-level only
  {"type": "session_opened", "session_id": "..."}
  {"type": "session_closed", "session_id": "..."}
  {"type": "turn_start", "session_id": "...", "turn_id": "..."}
  {"type": "text_delta", "session_id": "...", "turn_id": "...", "text": "..."}
  {"type": "thinking_delta", "session_id": "...", "turn_id": "...", "text": "..."}
  {"type": "tool_start", "session_id": "...", "turn_id": "...", ...}
  {"type": "tool_end", "session_id": "...", "turn_id": "...", ...}
  {"type": "file_changed", "session_id": "...", "turn_id": "...",
   "path": "...", "content": "..."}
  {"type": "file_deleted", "session_id": "...", "turn_id": "...", "path": "..."}
  {"type": "bash_stdout", "session_id": "...", "turn_id": "...", "text": "..."}
  {"type": "turn_interrupted", "session_id": "...", "turn_id": "..."}
  {"type": "turn_end", "session_id": "...", "turn_id": "...", "usage": {...}}
  {"type": "error", "session_id": "...", "turn_id": "...", "message": "..."}

Flushing is mandatory on every emit — block-buffered stdout would swallow
token streaming.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import sys
import traceback
from typing import Any, Optional

WORKSPACE_ROOT = "/workspace"


def _session_workspace(session_id: str) -> str:
    return os.path.join(WORKSPACE_ROOT, session_id)


def emit(event: dict) -> None:
    sys.stdout.write(json.dumps(event, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def _log_stderr(msg: str) -> None:
    sys.stderr.write(f"[chat_daemon] {msg}\n")
    sys.stderr.flush()


# ---------------------------------------------------------------------------
# Workspace sync (per session)
# ---------------------------------------------------------------------------

def _clear_workspace(workspace: str) -> None:
    if not os.path.isdir(workspace):
        os.makedirs(workspace, exist_ok=True)
        return
    for root, dirs, files in os.walk(workspace, topdown=False):
        for f in files:
            try:
                os.remove(os.path.join(root, f))
            except OSError:
                pass
        for d in dirs:
            try:
                os.rmdir(os.path.join(root, d))
            except OSError:
                pass


def _sync_workspace(workspace: str, files: dict[str, str]) -> None:
    _clear_workspace(workspace)
    os.makedirs(workspace, exist_ok=True)
    for rel, content in files.items():
        norm = rel.replace("\\", "/").lstrip("/")
        if ".." in norm.split("/"):
            continue
        abs_path = os.path.join(workspace, norm)
        os.makedirs(os.path.dirname(abs_path) or workspace, exist_ok=True)
        with open(abs_path, "w", encoding="utf-8") as fh:
            fh.write(content)


def _read_workspace_file(workspace: str, rel: str) -> str | None:
    norm = rel.replace("\\", "/").lstrip("/")
    abs_path = os.path.join(workspace, norm)
    if not os.path.isfile(abs_path):
        return None
    try:
        with open(abs_path, "r", encoding="utf-8", errors="replace") as fh:
            return fh.read()
    except OSError:
        return None


def _snapshot_workspace_hashes(workspace: str) -> dict[str, str]:
    result: dict[str, str] = {}
    if not os.path.isdir(workspace):
        return result
    for root, _dirs, files in os.walk(workspace):
        for f in files:
            abs_path = os.path.join(root, f)
            rel = os.path.relpath(abs_path, workspace).replace("\\", "/")
            if rel.startswith(".colreserved/") or rel == ".colreserved":
                continue
            try:
                with open(abs_path, "rb") as fh:
                    result[rel] = hashlib.sha256(fh.read()).hexdigest()
            except OSError:
                pass
    return result


def _emit_workspace_diff(session: "_Session", turn_id: str) -> None:
    current = _snapshot_workspace_hashes(session.workspace)
    before = session.workspace_hashes

    for path, h in current.items():
        if h != before.get(path):
            content = _read_workspace_file(session.workspace, path)
            if content is not None:
                emit({
                    "type": "file_changed",
                    "session_id": session.session_id,
                    "turn_id": turn_id,
                    "path": path,
                    "content": content,
                })

    for path in before:
        if path not in current:
            emit({
                "type": "file_deleted",
                "session_id": session.session_id,
                "turn_id": turn_id,
                "path": path,
            })

    session.workspace_hashes = current


# ---------------------------------------------------------------------------
# Streaming Bash tool — captured per session via closure so each session's
# Bash invocations run in its own /workspace/<session_id>/ and emit events
# tagged with the right session_id and current turn_id.
# ---------------------------------------------------------------------------

async def _run_streaming_bash(session: "_Session", args: dict) -> dict:
    command = args.get("command", "") if isinstance(args, dict) else ""
    timeout_raw = args.get("timeout", 120) if isinstance(args, dict) else 120
    try:
        timeout = max(1, int(timeout_raw))
    except (TypeError, ValueError):
        timeout = 120

    if not command:
        return {
            "content": [{"type": "text", "text": "(empty command)"}],
            "isError": True,
        }

    turn_id = session.current_turn_id or ""

    proc: Optional[asyncio.subprocess.Process] = None
    collected: list[str] = []
    exit_code: Optional[int] = None

    try:
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            cwd=session.workspace,
        )
        assert proc.stdout is not None

        async def _reader() -> None:
            async for raw in proc.stdout:  # type: ignore[union-attr]
                line = raw.decode("utf-8", errors="replace").rstrip("\n")
                collected.append(line)
                emit({
                    "type": "bash_stdout",
                    "session_id": session.session_id,
                    "turn_id": turn_id,
                    "text": line,
                })

        reader_task = asyncio.create_task(_reader())
        try:
            exit_code = await asyncio.wait_for(proc.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            try:
                proc.kill()
            except ProcessLookupError:
                pass
            await proc.wait()
            exit_code = proc.returncode
            emit({
                "type": "bash_stdout",
                "session_id": session.session_id,
                "turn_id": turn_id,
                "text": f"(command timed out after {timeout}s, killed)",
            })
        finally:
            try:
                await reader_task
            except Exception:
                pass

    except Exception as exc:
        _log_stderr(f"streaming_bash error: {exc}")
        return {
            "content": [{"type": "text", "text": f"(bash error: {exc})"}],
            "isError": True,
        }

    final = "\n".join(collected)
    if exit_code is not None and exit_code != 0:
        final += f"\n(exit code: {exit_code})"
    return {
        "content": [{"type": "text", "text": final or "(no output)"}],
    }


# ---------------------------------------------------------------------------
# Per-session SDK wrapper
# ---------------------------------------------------------------------------

class _Session:
    def __init__(self, session_id: str, model: str, system_prompt: str) -> None:
        self.session_id = session_id
        self.workspace = _session_workspace(session_id)
        os.makedirs(self.workspace, exist_ok=True)
        self.model = model
        self.system_prompt = system_prompt
        self._client = None
        self._client_model: str | None = None
        self._client_system_prompt: str | None = None
        self.current_turn_task: Optional[asyncio.Task] = None
        self.current_turn_id: Optional[str] = None
        self.workspace_hashes: dict[str, str] = {}

    async def ensure_client(self, model: str, system_prompt: str) -> Any:
        if (
            self._client is not None
            and model == self._client_model
            and system_prompt == self._client_system_prompt
        ):
            return self._client

        if self._client is not None:
            try:
                await self._client.disconnect()
            except Exception:
                pass

        from claude_agent_sdk import ClaudeSDKClient, ClaudeAgentOptions

        mcp_servers: dict = {}
        disallowed_tools: list[str] = []
        try:
            from claude_agent_sdk import tool, create_sdk_mcp_server

            session_ref = self

            @tool(
                "Bash",
                "Execute a bash command in the session workspace with live "
                "streaming stdout. Prefer this tool over any other Bash "
                "implementation — it streams output so the user sees "
                "progress in real time.",
                {"command": str, "timeout": int},
            )
            async def streaming_bash(args: dict) -> dict:
                return await _run_streaming_bash(session_ref, args)

            mcp_servers["chat_daemon_tools"] = create_sdk_mcp_server(
                "chat_daemon_tools", "1.0.0", [streaming_bash],
            )
            disallowed_tools = ["Bash"]
        except Exception as exc:
            _log_stderr(
                f"streaming Bash tool registration failed for session "
                f"{self.session_id}: {exc}"
            )

        options_kwargs: dict = dict(
            cwd=self.workspace,
            include_partial_messages=True,
            system_prompt=system_prompt or None,
            permission_mode="bypassPermissions",
        )
        if mcp_servers:
            options_kwargs["mcp_servers"] = mcp_servers
        if disallowed_tools:
            options_kwargs["disallowed_tools"] = disallowed_tools

        options = ClaudeAgentOptions(**options_kwargs)
        self._client = ClaudeSDKClient(options=options)
        await self._client.connect()
        self._client_model = model
        self._client_system_prompt = system_prompt
        self.model = model
        self.system_prompt = system_prompt
        return self._client

    async def close(self) -> None:
        if self.current_turn_task and not self.current_turn_task.done():
            self.current_turn_task.cancel()
            try:
                await self.current_turn_task
            except (asyncio.CancelledError, Exception):
                pass
        if self._client is not None:
            try:
                await self._client.disconnect()
            except Exception:
                pass
            self._client = None
        # Best-effort workspace cleanup.
        try:
            _clear_workspace(self.workspace)
            os.rmdir(self.workspace)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Turn handling
# ---------------------------------------------------------------------------

def _extract_text_delta(event: Any) -> str | None:
    raw = getattr(event, "event", None) or getattr(event, "data", None)
    if isinstance(raw, dict):
        delta = raw.get("delta") or {}
        if isinstance(delta, dict) and delta.get("type") == "text_delta":
            text = delta.get("text")
            if isinstance(text, str) and text:
                return text
    return None


def _extract_thinking_delta(event: Any) -> str | None:
    raw = getattr(event, "event", None) or getattr(event, "data", None)
    if isinstance(raw, dict):
        delta = raw.get("delta") or {}
        if isinstance(delta, dict) and delta.get("type") == "thinking_delta":
            text = delta.get("thinking") or delta.get("text")
            if isinstance(text, str) and text:
                return text
    return None


def _tool_input_path(tool_input: Any) -> str | None:
    if not isinstance(tool_input, dict):
        return None
    for key in ("file_path", "path", "filename"):
        val = tool_input.get(key)
        if isinstance(val, str) and val:
            return val
    return None


async def _run_turn(
    session: _Session,
    turn_id: str,
    content: str,
    model: str,
    system_prompt: str,
) -> None:
    session.current_turn_id = turn_id
    session.workspace_hashes = _snapshot_workspace_hashes(session.workspace)
    sid = session.session_id

    emit({"type": "turn_start", "session_id": sid, "turn_id": turn_id})

    try:
        client = await session.ensure_client(model, system_prompt)
        pending_tools: dict[str, tuple[str, Any]] = {}

        await client.query(content)
        usage: dict[str, Any] = {}

        async for message in client.receive_response():
            text = _extract_text_delta(message)
            if text is not None:
                emit({
                    "type": "text_delta",
                    "session_id": sid,
                    "turn_id": turn_id,
                    "text": text,
                })
                continue

            thinking = _extract_thinking_delta(message)
            if thinking is not None:
                emit({
                    "type": "thinking_delta",
                    "session_id": sid,
                    "turn_id": turn_id,
                    "text": thinking,
                })
                continue

            content_blocks = getattr(message, "content", None)
            if isinstance(content_blocks, list):
                for block in content_blocks:
                    block_type = getattr(block, "type", None) or (
                        block.get("type") if isinstance(block, dict) else None
                    )

                    if block_type == "tool_use":
                        tool_use_id = (
                            getattr(block, "id", None)
                            or (block.get("id") if isinstance(block, dict) else None)
                        )
                        tool_name = (
                            getattr(block, "name", None)
                            or (block.get("name") if isinstance(block, dict) else None)
                        )
                        tool_input = (
                            getattr(block, "input", None)
                            or (block.get("input") if isinstance(block, dict) else None)
                        )
                        display_name = tool_name
                        if display_name and "__" in display_name:
                            display_name = display_name.rsplit("__", 1)[-1]
                        if tool_use_id and tool_name:
                            pending_tools[tool_use_id] = (display_name, tool_input)
                            emit({
                                "type": "tool_start",
                                "session_id": sid,
                                "turn_id": turn_id,
                                "name": display_name,
                                "input": tool_input if isinstance(tool_input, dict) else {},
                                "tool_use_id": tool_use_id,
                            })

                    elif block_type == "tool_result":
                        tool_use_id = (
                            getattr(block, "tool_use_id", None)
                            or (block.get("tool_use_id") if isinstance(block, dict) else None)
                        )
                        if not tool_use_id or tool_use_id not in pending_tools:
                            continue
                        tool_name, tool_input = pending_tools.pop(tool_use_id)
                        emit({
                            "type": "tool_end",
                            "session_id": sid,
                            "turn_id": turn_id,
                            "name": tool_name,
                            "tool_use_id": tool_use_id,
                        })
                        if tool_name in ("Write", "Edit", "MultiEdit"):
                            path = _tool_input_path(tool_input)
                            if path:
                                new_content = _read_workspace_file(session.workspace, path)
                                if new_content is not None:
                                    emit({
                                        "type": "file_changed",
                                        "session_id": sid,
                                        "turn_id": turn_id,
                                        "path": path,
                                        "content": new_content,
                                    })

            if type(message).__name__ == "ResultMessage":
                u = getattr(message, "usage", None)
                if isinstance(u, dict):
                    usage = u

        _emit_workspace_diff(session, turn_id)
        emit({
            "type": "turn_end",
            "session_id": sid,
            "turn_id": turn_id,
            "usage": usage,
        })

    except asyncio.CancelledError:
        _log_stderr(f"turn {turn_id} (session {sid}) interrupted")
        try:
            emit({"type": "turn_interrupted", "session_id": sid, "turn_id": turn_id})
            emit({"type": "turn_end", "session_id": sid, "turn_id": turn_id, "usage": {}})
        except Exception:
            pass
        if session._client is not None:
            try:
                interrupt_fn = getattr(session._client, "interrupt", None)
                if interrupt_fn is not None:
                    maybe = interrupt_fn()
                    if hasattr(maybe, "__await__"):
                        await maybe
            except Exception as exc:
                _log_stderr(f"SDK interrupt call failed for session {sid}: {exc}")
        raise

    except Exception as exc:
        _log_stderr(f"turn error (session {sid}): {exc}\n{traceback.format_exc()}")
        emit({
            "type": "error",
            "session_id": sid,
            "turn_id": turn_id,
            "message": f"{type(exc).__name__}: {exc}",
        })
        emit({
            "type": "turn_end",
            "session_id": sid,
            "turn_id": turn_id,
            "usage": {},
        })


# ---------------------------------------------------------------------------
# Stdin loop
# ---------------------------------------------------------------------------

async def _read_line_async(loop: asyncio.AbstractEventLoop) -> str | None:
    line = await loop.run_in_executor(None, sys.stdin.readline)
    if line == "":
        return None
    return line.rstrip("\n")


async def _main_loop() -> int:
    emit({"type": "ready"})

    sessions: dict[str, _Session] = {}
    loop = asyncio.get_running_loop()

    try:
        while True:
            line = await _read_line_async(loop)
            if line is None:
                _log_stderr("stdin EOF; shutting down")
                break
            if not line.strip():
                continue
            try:
                msg = json.loads(line)
            except json.JSONDecodeError as exc:
                _log_stderr(f"bad json on stdin: {exc}: {line!r}")
                continue

            op = msg.get("op")

            if op == "shutdown":
                break

            if op == "open_session":
                sid = msg.get("session_id") or ""
                if not sid:
                    _log_stderr("open_session without session_id; ignoring")
                    continue
                if sid in sessions:
                    emit({"type": "session_opened", "session_id": sid, "reused": True})
                    continue
                sessions[sid] = _Session(
                    session_id=sid,
                    model=msg.get("model", "sonnet"),
                    system_prompt=msg.get("system_prompt", "") or "",
                )
                emit({"type": "session_opened", "session_id": sid, "reused": False})
                continue

            sid = msg.get("session_id") or ""
            session = sessions.get(sid)

            if op == "close_session":
                if session is None:
                    emit({"type": "session_closed", "session_id": sid})
                    continue
                await session.close()
                sessions.pop(sid, None)
                emit({"type": "session_closed", "session_id": sid})
                continue

            if session is None:
                _log_stderr(f"op {op!r} for unknown session {sid!r}; ignoring")
                emit({
                    "type": "error",
                    "session_id": sid,
                    "turn_id": msg.get("turn_id", ""),
                    "message": f"unknown session_id {sid!r}",
                })
                continue

            if op == "sync_workspace":
                try:
                    _sync_workspace(session.workspace, msg.get("files") or {})
                except Exception as exc:
                    _log_stderr(f"sync_workspace failed (session {sid}): {exc}")
                    emit({
                        "type": "error",
                        "session_id": sid,
                        "turn_id": msg.get("turn_id", ""),
                        "message": f"sync_workspace: {exc}",
                    })

            elif op == "user_turn":
                if session.current_turn_task and not session.current_turn_task.done():
                    _log_stderr(
                        f"user_turn arrived for session {sid} while previous "
                        f"turn still in flight; ignoring"
                    )
                    continue
                turn_id = msg.get("turn_id", "")
                content_arg = msg.get("content", "")
                model_arg = msg.get("model", session.model)
                sysprompt_arg = msg.get("system_prompt", session.system_prompt) or ""

                async def _turn_runner(
                    _session=session,
                    _turn_id=turn_id,
                    _content=content_arg,
                    _model=model_arg,
                    _sysprompt=sysprompt_arg,
                ) -> None:
                    try:
                        await _run_turn(
                            session=_session,
                            turn_id=_turn_id,
                            content=_content,
                            model=_model,
                            system_prompt=_sysprompt,
                        )
                    except asyncio.CancelledError:
                        pass
                    except Exception as exc:
                        _log_stderr(f"_turn_runner unexpected error: {exc}")
                    finally:
                        _session.current_turn_task = None
                        _session.current_turn_id = None

                session.current_turn_task = asyncio.create_task(_turn_runner())

            elif op == "interrupt":
                if session.current_turn_task and not session.current_turn_task.done():
                    session.current_turn_task.cancel()
                else:
                    emit({
                        "type": "turn_interrupted",
                        "session_id": sid,
                        "turn_id": session.current_turn_id or msg.get("turn_id", ""),
                    })

            else:
                _log_stderr(f"unknown op for session {sid}: {op!r}")

    finally:
        for s in list(sessions.values()):
            try:
                await s.close()
            except Exception:
                pass

    return 0


def main() -> None:
    try:
        rc = asyncio.run(_main_loop())
    except KeyboardInterrupt:
        rc = 0
    except Exception as exc:
        _log_stderr(f"fatal: {exc}\n{traceback.format_exc()}")
        rc = 1
    sys.exit(rc)


if __name__ == "__main__":
    main()
