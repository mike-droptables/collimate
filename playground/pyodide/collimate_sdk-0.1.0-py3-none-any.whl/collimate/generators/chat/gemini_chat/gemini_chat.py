# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "google-genai"]
# ///
"""Gemini Chat — in-process streaming chat generator backed by google-genai.

Gives the same canvas UX as the `chat` generator (streaming tokens, tool
status lines, live file edits, Bash output streamed to both the chat card
and the run-log panel, interrupt via Escape, automatic history scrubbing)
but with Google Gemini instead of Claude Code. Runs entirely inside the
generator subprocess — no chat worker container, no warm pool.

Architecture
------------
- Manifest declares output_mode: in_place so every turn mutates the same
  canvas cell, with the DB chain of internal versions growing via
  cell_edges(parent_key='previous_version').
- Streaming events are pushed to the frontend via gen.chat.emit_stream_event,
  which sends a fire-and-forget chat_stream_event IPC op that the API
  process unwraps and broadcasts to SSE. Same wire protocol the daemon-
  backed chat generator uses, so MessageList / Files tab / log panel
  just work.
- File edits go through gen.fs.write (which auto-tracks for the implicit
  update_cell commit at the end). The file_changed events we emit are
  *in addition* to the tracked write — one for live UI updates, one for
  the version-chain persist.
- Bash runs are wrapped with a streaming subprocess that reads stdout
  line by line and emits bash_stdout events AND prints to stdout so the
  log panel (via run_events) picks them up. Same dual-destination pattern
  the daemon's custom Bash tool uses, but done in-process.
- Interrupt via gen.stop_requested() polled at every natural checkpoint:
  between tool-loop iterations, inside the streaming for-chunk loop, and
  on every line of bash output. On interrupt we emit turn_interrupted +
  turn_end, append the partial assistant text with an interruption
  marker, and fall through to update_cell so the partial state lands
  in the version chain for scrubber access.

Limitations vs the daemon-backed chat generator
-----------------------------------------------
- Redirect (mid-turn ⌘Enter to cancel + replace) is NOT supported. It
  would need an IPC op from the API process into the running generator
  subprocess, which doesn't exist yet. Interrupt (Escape) works via
  signal-based stop polling.
- Tool surface is the four hand-rolled tools (read_file, write_file,
  edit_file, run_bash) — no Grep/Glob/MultiEdit/TodoWrite/etc. that
  Claude Code ships with.
- ~/.claude and per-cell .claude/ customizations are Claude-Code-specific
  and don't apply to Gemini.
"""

from __future__ import annotations

import os
import subprocess
import sys
import time
import uuid
from typing import Any

from collimate.sdk import Generator

gen = Generator()

# Short name → official model id. Users pick the short name in settings;
# the script resolves to the real id so changing Google's version naming
# doesn't force every user to re-edit their settings.
MODEL_MAP = {
    "flash": "gemini-2.5-flash",
    "pro": "gemini-2.5-pro",
    "flash-lite": "gemini-2.0-flash-lite",
}

# Cap on tool-call turns to defend against runaway loops.
MAX_TOOL_TURNS = 25


def _run_bash_streaming(command: str, turn_id: str, timeout: int = 120) -> str:
    """Run a shell command inside gen.workspace, streaming every output line
    as a bash_stdout event AND to generator stdout (which flows into the
    run_events log pipeline). Returns the full combined output for the
    model's tool result.
    """
    collected: list[str] = []
    if not command.strip():
        return "(empty command)"

    start_ts = time.time()
    proc: subprocess.Popen | None = None
    try:
        proc = subprocess.Popen(
            command,
            shell=True,
            cwd=gen.workspace,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        assert proc.stdout is not None
        for raw in proc.stdout:
            line = raw.rstrip("\n")
            collected.append(line)
            # Streaming UI event — shows in the in-progress assistant card.
            try:
                gen.chat.emit_stream_event(turn_id, {
                    "type": "bash_stdout",
                    "turn_id": turn_id,
                    "text": line,
                })
            except Exception:
                pass
            # Also print so the standard run-log panel renders it via
            # the existing run_events pipeline.
            print(line, flush=True)
            if gen.stop_requested():
                try:
                    proc.terminate()
                except ProcessLookupError:
                    pass
                collected.append("(interrupted by user)")
                break
            if time.time() - start_ts > timeout:
                try:
                    proc.kill()
                except ProcessLookupError:
                    pass
                collected.append(f"(timed out after {timeout}s)")
                break
    except Exception as exc:
        collected.append(f"(bash error: {exc})")
    finally:
        if proc is not None and proc.poll() is None:
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                try:
                    proc.kill()
                except ProcessLookupError:
                    pass

    rc = proc.returncode if proc is not None else -1
    if rc not in (0, None):
        collected.append(f"(exit code: {rc})")
    return "\n".join(collected) or "(no output)"


@gen.run(name="Gemini Chat")
def main() -> None:
    settings = gen.config.read_schema_values("settings.set_yaml")
    api_key = (
        settings.get("api_key")
        or gen.params.get("api_key")
        or os.environ.get("GEMINI_API_KEY", "")
    )
    if not api_key:
        raise RuntimeError(
            "GEMINI_API_KEY not set. Provide it in Settings or the environment."
        )

    model_short = settings.get("model", "flash")
    resolved_model = MODEL_MAP.get(model_short, model_short)
    system_prompt = settings.get("system_prompt", "") or ""

    # Prefer user_message from run params (passed by the frontend's
    # Cmd-Enter quick-send) so we don't depend on the workspace
    # .collimate_messages.json being correctly hydrated.
    latest_user = (gen.params.get("user_message") or "").strip()
    if not latest_user:
        user_msgs = [m for m in gen.chat.history if m.role == "user"]
        if user_msgs:
            latest_user = user_msgs[-1].content

    try:
        from google import genai
        from google.genai import types
    except ImportError as exc:
        raise RuntimeError(
            "gemini_chat requires the google-genai package"
        ) from exc

    client = genai.Client(api_key=api_key)

    # --- Tool definitions ---------------------------------------------------
    # Four hand-rolled tools that mirror what the daemon's Claude Code surface
    # gives us: file reads, writes, edits, and streaming shell. Keep the
    # schemas simple — Gemini's schema parser is fussier about unknown keys
    # than Anthropic's.
    tools = [
        types.Tool(function_declarations=[
            types.FunctionDeclaration(
                name="read_file",
                description="Read a UTF-8 text file from the cell's workspace.",
                parameters=types.Schema(
                    type=types.Type.OBJECT,
                    properties={
                        "path": types.Schema(
                            type=types.Type.STRING,
                            description="Relative path inside the workspace",
                        ),
                    },
                    required=["path"],
                ),
            ),
            types.FunctionDeclaration(
                name="write_file",
                description="Write or overwrite a UTF-8 text file in the workspace.",
                parameters=types.Schema(
                    type=types.Type.OBJECT,
                    properties={
                        "path": types.Schema(type=types.Type.STRING),
                        "content": types.Schema(type=types.Type.STRING),
                    },
                    required=["path", "content"],
                ),
            ),
            types.FunctionDeclaration(
                name="edit_file",
                description=(
                    "Replace the first occurrence of `old` with `new` in a "
                    "file. Fails if `old` is not present."
                ),
                parameters=types.Schema(
                    type=types.Type.OBJECT,
                    properties={
                        "path": types.Schema(type=types.Type.STRING),
                        "old": types.Schema(type=types.Type.STRING),
                        "new": types.Schema(type=types.Type.STRING),
                    },
                    required=["path", "old", "new"],
                ),
            ),
            types.FunctionDeclaration(
                name="run_bash",
                description=(
                    "Run a shell command in the cell's workspace. Returns the "
                    "full combined stdout+stderr. Output also streams live "
                    "into the UI and the run log panel."
                ),
                parameters=types.Schema(
                    type=types.Type.OBJECT,
                    properties={
                        "command": types.Schema(type=types.Type.STRING),
                    },
                    required=["command"],
                ),
            ),
        ]),
    ]

    # --- Tool dispatch ------------------------------------------------------
    # Display names keyed off the tool name so the existing MessageList
    # status-line labels ("Reading foo.md...", "Running bash: ...") work
    # unchanged.
    DISPLAY = {
        "read_file": "Read",
        "write_file": "Write",
        "edit_file": "Edit",
        "run_bash": "Bash",
    }

    def _tool_display_input(name: str, args: dict) -> dict:
        if name == "run_bash":
            return {"command": args.get("command", "")}
        if name in ("read_file", "write_file", "edit_file"):
            return {"file_path": args.get("path", "")}
        return args

    def _run_tool(name: str, args: dict, turn_id: str) -> str:
        if name == "read_file":
            path = args.get("path", "")
            try:
                return gen.fs.read(path)
            except FileNotFoundError:
                return f"(file not found: {path})"
            except Exception as exc:
                return f"(read error: {exc})"
        if name == "write_file":
            path = args.get("path", "")
            content = args.get("content", "")
            try:
                gen.fs.write(path, content)
            except Exception as exc:
                return f"(write error: {exc})"
            # Live UI event — update the Files tab mid-turn.
            try:
                gen.chat.emit_stream_event(turn_id, {
                    "type": "file_changed",
                    "turn_id": turn_id,
                    "path": path,
                    "content": content,
                })
            except Exception:
                pass
            return f"(wrote {len(content)} bytes to {path})"
        if name == "edit_file":
            path = args.get("path", "")
            old = args.get("old", "")
            new = args.get("new", "")
            try:
                current = gen.fs.read(path)
            except FileNotFoundError:
                return f"(file not found: {path})"
            if old not in current:
                return "(old string not found in file)"
            updated = current.replace(old, new, 1)
            try:
                gen.fs.write(path, updated)
            except Exception as exc:
                return f"(write error: {exc})"
            try:
                gen.chat.emit_stream_event(turn_id, {
                    "type": "file_changed",
                    "turn_id": turn_id,
                    "path": path,
                    "content": updated,
                })
            except Exception:
                pass
            return f"(edited {path})"
        if name == "run_bash":
            return _run_bash_streaming(args.get("command", ""), turn_id)
        return f"(unknown tool: {name})"

    # --- Reusable config (lives across turns) --------------------------------
    config = types.GenerateContentConfig(
        tools=tools,
        system_instruction=system_prompt or None,
    )

    def _to_content(role: str, text: str):
        return types.Content(
            role=("model" if role == "assistant" else "user"),
            parts=[types.Part(text=text)],
        )

    # --- Single-turn executor ------------------------------------------------
    def _run_gemini_turn(user_msg: str) -> None:
        """Run one Gemini chat turn: stream, tool-loop, persist, commit."""
        history = gen.chat.history
        contents: list = []
        for m in history:
            if m.role in ("user", "assistant"):
                contents.append(_to_content(m.role, m.content))
        if not contents:
            contents.append(_to_content("user", user_msg))

        turn_id = uuid.uuid4().hex
        gen.chat.emit_stream_event(turn_id, {"type": "turn_start", "turn_id": turn_id})

        assistant_text_parts: list[str] = []
        was_interrupted = False

        try:
            for iter_count in range(MAX_TOOL_TURNS):
                if gen.stop_requested():
                    was_interrupted = True
                    break

                round_text_parts: list[str] = []
                round_function_calls: list[Any] = []

                try:
                    stream = client.models.generate_content_stream(
                        model=resolved_model,
                        contents=contents,
                        config=config,
                    )
                except Exception as exc:
                    gen.chat.emit_stream_event(turn_id, {
                        "type": "error",
                        "turn_id": turn_id,
                        "message": f"gemini stream error: {exc}",
                    })
                    raise

                for chunk in stream:
                    if gen.stop_requested():
                        was_interrupted = True
                        break
                    try:
                        candidate = chunk.candidates[0]
                        parts = candidate.content.parts or []
                    except (AttributeError, IndexError, TypeError):
                        parts = []
                    for part in parts:
                        text = getattr(part, "text", None)
                        if text:
                            round_text_parts.append(text)
                            try:
                                gen.chat.emit_stream_event(turn_id, {
                                    "type": "text_delta",
                                    "turn_id": turn_id,
                                    "text": text,
                                })
                            except Exception:
                                pass
                            continue
                        fc = getattr(part, "function_call", None)
                        if fc is not None:
                            round_function_calls.append(fc)

                assistant_text_parts.append("".join(round_text_parts))

                if was_interrupted:
                    break

                if not round_function_calls:
                    break

                model_parts: list = []
                if round_text_parts:
                    model_parts.append(types.Part(text="".join(round_text_parts)))
                for fc in round_function_calls:
                    try:
                        model_parts.append(types.Part(function_call=fc))
                    except Exception:
                        from_factory = getattr(types.Part, "from_function_call", None)
                        if callable(from_factory):
                            model_parts.append(from_factory(
                                name=getattr(fc, "name", ""),
                                args=dict(getattr(fc, "args", {}) or {}),
                            ))
                if model_parts:
                    contents.append(types.Content(role="model", parts=model_parts))

                tool_response_parts: list = []
                for fc in round_function_calls:
                    if gen.stop_requested():
                        was_interrupted = True
                        break
                    fc_name = getattr(fc, "name", "") or ""
                    try:
                        fc_args = dict(getattr(fc, "args", {}) or {})
                    except Exception:
                        fc_args = {}
                    tool_use_id = uuid.uuid4().hex[:12]
                    display_name = DISPLAY.get(fc_name, fc_name)
                    try:
                        gen.chat.emit_stream_event(turn_id, {
                            "type": "tool_start",
                            "turn_id": turn_id,
                            "name": display_name,
                            "input": _tool_display_input(fc_name, fc_args),
                            "tool_use_id": tool_use_id,
                        })
                    except Exception:
                        pass
                    result = _run_tool(fc_name, fc_args, turn_id)
                    try:
                        gen.chat.emit_stream_event(turn_id, {
                            "type": "tool_end",
                            "turn_id": turn_id,
                            "name": display_name,
                            "tool_use_id": tool_use_id,
                        })
                    except Exception:
                        pass
                    fr_part = None
                    from_fr = getattr(types.Part, "from_function_response", None)
                    if callable(from_fr):
                        try:
                            fr_part = from_fr(
                                name=fc_name,
                                response={"result": result},
                            )
                        except Exception:
                            fr_part = None
                    if fr_part is None:
                        try:
                            fr_part = types.Part(
                                function_response=types.FunctionResponse(
                                    name=fc_name,
                                    response={"result": result},
                                ),
                            )
                        except Exception:
                            fr_part = types.Part(
                                text=f"[tool {fc_name} result]\n{result}",
                            )
                    tool_response_parts.append(fr_part)

                if was_interrupted:
                    break
                if tool_response_parts:
                    contents.append(types.Content(
                        role="user",
                        parts=tool_response_parts,
                    ))
        finally:
            if was_interrupted:
                gen.chat.emit_stream_event(turn_id, {
                    "type": "turn_interrupted",
                    "turn_id": turn_id,
                })
            gen.chat.emit_stream_event(turn_id, {
                "type": "turn_end",
                "turn_id": turn_id,
                "usage": {},
            })

        final_text = "\n".join(t for t in assistant_text_parts if t).strip()
        if was_interrupted and final_text:
            final_text += "\n\n*[interrupted by user]*"
        elif was_interrupted:
            final_text = "*[interrupted by user]*"

        if final_text:
            gen.chat.append("assistant", final_text)

        summary = user_msg[:80].replace("\n", " ")
        gen.update_cell(name="Gemini Chat", summary=summary)

    # --- Main loop: process initial message then wait for more ---------------
    if latest_user:
        _run_gemini_turn(latest_user)

    gen.status = "Ready — type your message below"
    while True:
        msg = gen.chat.wait_for_message()
        if msg is None:
            break
        gen.chat.append("user", msg)
        _run_gemini_turn(msg)
        gen.status = "Ready — type your message below"


main()
