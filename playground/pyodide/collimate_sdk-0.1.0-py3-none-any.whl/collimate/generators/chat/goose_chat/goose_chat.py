# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Goose Chat — in-place generator that shells out to Block's goose CLI.

Wraps `goose run -t "<user prompt>"` (or user-configured equivalent) in
an in-place turn that streams goose's combined output line by line into
the cell's streaming chat card AND the run log panel, diffs the workspace
before/after to detect file edits, and commits the result as a new row
in the cell's version chain — same scrubber behaviour as every other
in-place generator on this branch.

Why this shape, not a tool-loop
-------------------------------
Goose has its own rich tool surface (shell, file editing, MCP servers,
extensions) and runs its own internal agent loop. Re-implementing tool
dispatch on top of goose would fight the grain — goose already decides
what to do and how to do it. The clean contract is "prompt in, streaming
output out, files on disk updated", which is exactly what a CLI process
in cwd=workspace gives us.

The downside is we don't get tool_start/tool_end events for each
individual thing goose does — we can't parse goose's output reliably
enough for that. What we do get:
- Everything goose prints streams into the chat card as bash_stdout
  events, so the user sees live progress.
- Everything also streams into the run log panel via the existing
  run_events pipeline (print() → ProcessManager.log_buffer).
- Before/after snapshots of the workspace detect file_changed events
  for anything goose wrote or modified, emitted once the process exits
  so the Files tab catches up even without structured tool events.
- Interrupt via gen.stop_requested() polled on every output line. On
  stop we SIGTERM goose, give it 5s to clean up, then SIGKILL.

Architecture
------------
- output_mode: in_place (same as chat and gemini_chat) so every run
  mutates the single input cell and the cell_edges chain grows.
- goose's credentials come from ~/.config/goose/ which the generator
  subprocess inherits from the host. The manifest declares no `keys:`
  because goose owns its own auth.
- Diff-based file tracking: we snapshot the workspace before and after
  the run, then call gen.fs.write() for every new/changed file so the
  implicit update_cell commit picks them up via tracked_writes. File
  removals are logged but not currently persisted (no file_removed
  event type yet — future extension).

Limitations vs the daemon-backed chat generator
-----------------------------------------------
- Redirect (mid-turn ⌘Enter replace) is NOT supported for in-process
  backends. Interrupt via Escape works.
- No per-tool status lines in the UI — goose's internal tool calls
  are opaque to us. The user sees goose's own human-readable output
  in real time, which is typically enough.
- Partial file writes mid-stream don't show up in the Files tab
  until after the process exits and the diff runs. Acceptable given
  goose's output is the primary feedback channel.
"""

from __future__ import annotations

import hashlib
import os
import shlex
import subprocess
import time
import uuid

from collimate.sdk import Generator

gen = Generator()


def _snapshot_workspace() -> dict[str, str]:
    """Return a dict of {relative_path: sha256_hex} for every file in the
    cell's workspace. Files under .colreserved/ are skipped because the
    SDK uses that namespace for internal state and we don't want goose
    edits to that path to show up as file_changed events for the user.
    """
    result: dict[str, str] = {}
    ws = gen.workspace
    if not os.path.isdir(ws):
        return result
    for root, dirs, files in os.walk(ws):
        # Prune hidden/reserved dirs.
        dirs[:] = [
            d for d in dirs
            if d not in (".colreserved", ".git", "node_modules", ".venv", "__pycache__")
        ]
        for name in files:
            if name.startswith(".collimate_messages"):
                continue
            abs_path = os.path.join(root, name)
            rel = os.path.relpath(abs_path, ws).replace("\\", "/")
            try:
                with open(abs_path, "rb") as fh:
                    result[rel] = hashlib.sha256(fh.read()).hexdigest()
            except OSError:
                continue
    return result


def _read_file_text(rel_path: str) -> str | None:
    """Read a workspace file as text with replacement for non-utf8 bytes."""
    abs_path = os.path.join(gen.workspace, rel_path)
    try:
        with open(abs_path, "r", encoding="utf-8", errors="replace") as fh:
            return fh.read()
    except OSError:
        return None


def _parse_timeout(raw: str | None) -> int:
    try:
        return max(10, int(raw or "600"))
    except (TypeError, ValueError):
        return 600


def _run_goose_turn(user_msg: str, goose_command: str, run_subcommand: str,
                    extra_args: str, timeout_secs: int) -> None:
    """Execute a single goose chat turn."""
    turn_id = uuid.uuid4().hex

    try:
        argv = shlex.split(goose_command) + shlex.split(run_subcommand)
        if extra_args:
            argv += shlex.split(extra_args)
        argv.append(user_msg)
    except ValueError as exc:
        raise RuntimeError(f"goose_chat: bad command shape: {exc}") from exc

    gen.status = "Snapshotting workspace..."
    before_snapshot = _snapshot_workspace()

    gen.chat.emit_stream_event(turn_id, {
        "type": "turn_start",
        "turn_id": turn_id,
    })

    # Emit a synthetic tool_start so the streaming UI shows a status line
    # labeled "Running goose..." while the subprocess runs. This reuses
    # the existing MessageList Bash status rendering — the user already
    # knows what the monospace output block means.
    tool_use_id = uuid.uuid4().hex[:12]
    gen.chat.emit_stream_event(turn_id, {
        "type": "tool_start",
        "turn_id": turn_id,
        "name": "Bash",
        "input": {"command": " ".join(shlex.quote(a) for a in argv)},
        "tool_use_id": tool_use_id,
    })

    collected_lines: list[str] = []
    was_interrupted = False
    rc: int | None = None
    proc: subprocess.Popen | None = None
    start_ts = time.time()

    gen.status = "Running goose..."
    try:
        proc = subprocess.Popen(
            argv,
            cwd=gen.workspace,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
    except FileNotFoundError as exc:
        gen.chat.emit_stream_event(turn_id, {
            "type": "error",
            "turn_id": turn_id,
            "message": (
                f"goose binary not found: {exc}. Install Goose from "
                f"https://block.github.io/goose/ or override goose_command "
                f"in settings."
            ),
        })
        gen.chat.emit_stream_event(turn_id, {
            "type": "tool_end",
            "turn_id": turn_id,
            "name": "Bash",
            "tool_use_id": tool_use_id,
        })
        gen.chat.emit_stream_event(turn_id, {
            "type": "turn_end",
            "turn_id": turn_id,
            "usage": {},
        })
        raise RuntimeError(str(exc)) from exc

    assert proc.stdout is not None
    try:
        for raw in proc.stdout:
            line = raw.rstrip("\n")
            collected_lines.append(line)
            # bash_stdout event — live monospace block in the streaming card.
            try:
                gen.chat.emit_stream_event(turn_id, {
                    "type": "bash_stdout",
                    "turn_id": turn_id,
                    "text": line,
                })
            except Exception:
                pass
            # Also emit as text_delta so the assistant reply in the message
            # list reflects the live output. The daemon-backed path gets
            # these from the model itself; here the goose output *is* the
            # assistant's voice, so mirror it.
            try:
                gen.chat.emit_stream_event(turn_id, {
                    "type": "text_delta",
                    "turn_id": turn_id,
                    "text": line + "\n",
                })
            except Exception:
                pass
            # print() goes to run_events via the microbatch writer, so the
            # standard run log panel renders it.
            print(line, flush=True)

            if gen.stop_requested():
                was_interrupted = True
                try:
                    proc.terminate()
                except ProcessLookupError:
                    pass
                collected_lines.append("(interrupted by user)")
                break
            if time.time() - start_ts > timeout_secs:
                try:
                    proc.kill()
                except ProcessLookupError:
                    pass
                collected_lines.append(f"(timed out after {timeout_secs}s)")
                break
    finally:
        if proc is not None and proc.poll() is None:
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                try:
                    proc.kill()
                except ProcessLookupError:
                    pass
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    pass
        rc = proc.returncode if proc is not None else -1

    gen.chat.emit_stream_event(turn_id, {
        "type": "tool_end",
        "turn_id": turn_id,
        "name": "Bash",
        "tool_use_id": tool_use_id,
    })

    # --- Diff the workspace and emit file_changed events -------------------
    gen.status = "Diffing workspace..."
    after_snapshot = _snapshot_workspace()

    changed_paths: list[str] = []
    for rel, after_hash in after_snapshot.items():
        before_hash = before_snapshot.get(rel)
        if before_hash == after_hash:
            continue
        content = _read_file_text(rel)
        if content is None:
            continue
        changed_paths.append(rel)
        # Live UI event so the Files tab refreshes.
        try:
            gen.chat.emit_stream_event(turn_id, {
                "type": "file_changed",
                "turn_id": turn_id,
                "path": rel,
                "content": content,
            })
        except Exception:
            pass
        # Track via gen.fs.write so the implicit update_cell commit
        # persists the new content into the version chain. gen.fs.write
        # is idempotent — writing the same content that's already on
        # disk is a no-op aside from the tracked_writes add.
        try:
            gen.fs.write(rel, content)
        except Exception as exc:
            print(f"[goose_chat] failed to track {rel}: {exc}", flush=True)

    removed_paths = [p for p in before_snapshot if p not in after_snapshot]
    if removed_paths:
        print(
            f"[goose_chat] note: {len(removed_paths)} file(s) removed during "
            f"the run (not currently captured in the version chain): "
            f"{', '.join(removed_paths[:5])}"
            + ("..." if len(removed_paths) > 5 else ""),
            flush=True,
        )

    if was_interrupted:
        gen.chat.emit_stream_event(turn_id, {
            "type": "turn_interrupted",
            "turn_id": turn_id,
        })
    gen.chat.emit_stream_event(turn_id, {
        "type": "turn_end",
        "turn_id": turn_id,
        "usage": {},
    })

    # --- Persist the assistant reply and commit ----------------------------
    final_text = "\n".join(collected_lines).strip()
    if was_interrupted and final_text:
        final_text += "\n\n*[interrupted by user]*"
    elif was_interrupted:
        final_text = "*[interrupted by user]*"
    if rc is not None and rc != 0 and not was_interrupted:
        final_text += f"\n\n*(goose exited with code {rc})*"

    if final_text:
        gen.chat.append("assistant", final_text)

    summary_bits = [user_msg[:60].replace("\n", " ")]
    if changed_paths:
        summary_bits.append(f"{len(changed_paths)} file(s) changed")
    summary = " — ".join(summary_bits)[:120]
    gen.update_cell(name="Goose Chat", summary=summary)


@gen.run(name="Goose Chat")
def main() -> None:
    settings = gen.config.read_schema_values("settings.set_yaml")
    goose_command = (settings.get("goose_command") or "goose").strip() or "goose"
    run_subcommand = (settings.get("run_subcommand") or "run -t").strip() or "run -t"
    extra_args = (settings.get("extra_args") or "").strip()
    timeout_secs = _parse_timeout(settings.get("timeout_secs"))

    latest_user = (gen.params.get("user_message") or "").strip()
    if not latest_user:
        user_msgs = [m for m in gen.chat.history if m.role == "user"]
        if user_msgs:
            latest_user = user_msgs[-1].content

    if latest_user:
        _run_goose_turn(latest_user, goose_command, run_subcommand, extra_args, timeout_secs)

    gen.status = "Ready — type your message below"
    while True:
        msg = gen.chat.wait_for_message()
        if msg is None:
            break
        gen.chat.append("user", msg)
        _run_goose_turn(msg, goose_command, run_subcommand, extra_args, timeout_secs)
        gen.status = "Ready — type your message below"


main()
