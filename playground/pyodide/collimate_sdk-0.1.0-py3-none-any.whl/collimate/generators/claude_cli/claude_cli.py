# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "docker"]
# ///
"""Claude CLI — live Claude Code TTY with a Capture Chat button.

Owns its own image (``collimate-claude-cli:latest``, single-consumer) and runs
it through the shared ``_env_shared.DockerEnvironment`` helper — no embedded
docker-py lifecycle. PID 1 is ``sleep infinity``; we attach a ``claude`` TTY via
``gen.terminal`` and, on the Capture Chat action, read the transcript + project
tree out of the live container.
"""
from __future__ import annotations

import io
import json
import os
import shlex
import sys
import tarfile
from pathlib import Path

import gen

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from _env_shared import DockerEnvironment  # noqa: E402

IMAGE_TAG = "collimate-claude-cli:latest"
_CAPTURE_MAX_FILE_BYTES = 1_000_000


async def run() -> None:
    cfg = gen.config("settings.set_yaml")
    auth_source = (cfg.get("auth_source") or "host_claude").strip().lower()
    model = (cfg.get("model") or "sonnet").strip()
    extra_args = (cfg.get("extra_args") or "").strip()
    first_message = (gen.prompt or "").strip()

    await gen.update(name="Claude CLI", summary="Starting…")

    volumes: dict = {}
    env_vars: dict = {}
    if auth_source == "host_claude":
        host_claude = os.path.expanduser("~/.claude")
        if os.path.isdir(host_claude):
            volumes[host_claude] = {"bind": "/home/coder/.claude", "mode": "rw"}
            gen.log("Mounting host ~/.claude into container")
        else:
            gen.log(
                f"auth_source=host_claude but {host_claude} does not exist — "
                "container will start unauthenticated"
            )
    elif auth_source == "api_key":
        env_vars["ANTHROPIC_API_KEY"] = await gen.api_key(
            "anthropic", description="Anthropic API key for Claude CLI",
        )

    env = DockerEnvironment(
        image=IMAGE_TAG,
        mount="/workspace", mount_mode="ro",
        build_context=str(Path(__file__).resolve().parent),
        volumes=volumes, environment=env_vars,
        name_prefix="collimate-claude-cli", kind="claude_cli",
    )
    container = env.container
    try:
        # Copy the (read-only) input workspace into the writable project dir.
        container.exec_run(
            ["bash", "-lc",
             "mkdir -p /home/coder/project && "
             "if compgen -G '/workspace/*' > /dev/null; then "
             "  cp -a /workspace/. /home/coder/project/ || true; fi; "
             "rm -rf /home/coder/project/.colreserved"],   # SDK-internal, never the user's project
            user="coder",
        )

        command = ["claude"]
        if extra_args:
            command += shlex.split(extra_args)
        term_env: dict[str, str] = {"TERM": "xterm-256color"}
        if model:
            term_env["ANTHROPIC_MODEL"] = _full_model_id(model)

        gen.status("Registering terminal session…")
        term = await gen.terminal(
            container_id=env.container_id, command=command,
            cwd="/home/coder/project", env=term_env,
        )
        try:
            gen.update_file(
                "claude.terminal",
                json.dumps(
                    {
                        **term,
                        "label": f"Claude CLI · {model}",
                        "buttons": [{"id": "capture_chat", "label": "Capture Chat"}],
                        "auth_source": auth_source,
                    },
                    indent=2,
                ),
            )
            if first_message:
                gen.history.append("user", first_message)
                _prime_first_message(container, first_message)

            await gen.update(
                name="Claude CLI", summary=f"live · {model}",
                pinned="claude.terminal",
            )
            gen.status("Terminal ready — open the cell to attach.")

            while not gen.cancelled:
                action = await gen.wait_for_action(timeout=1.0)
                if action == "capture_chat":
                    try:
                        await _capture_chat(container)
                    except Exception as e:
                        gen.log(f"capture_chat failed: {e}")
                        gen.status(f"Capture failed: {e}")
                elif action:
                    gen.log(f"Unknown renderer action: {action}")
        finally:
            try:
                gen.stop_terminal(term.get("session_id", ""))
            except Exception as e:
                gen.log(f"stop_terminal failed: {e}")
    finally:
        env.close()


def _prime_first_message(container, message: str) -> None:
    """Run ``claude -p <msg>`` in the background so the transcript contains the
    first turn by the time the user attaches the terminal."""
    try:
        container.exec_run(
            ["bash", "-lc",
             f"nohup claude -p {shlex.quote(message)} "
             "--dangerously-skip-permissions >/dev/null 2>&1 &"],
            user="coder", workdir="/home/coder/project", detach=True,
        )
    except Exception as e:
        gen.log(f"could not prime first message: {e}")


def _full_model_id(short: str) -> str:
    table = {
        "haiku": "claude-haiku-4-5-20251001",
        "sonnet": "claude-sonnet-4-6",
        "opus": "claude-opus-4-7",
    }
    return table.get(short, short)


# ---------------------------------------------------------------------------
# Capture Chat — snapshot messages + files into a new side cell
# ---------------------------------------------------------------------------

async def _capture_chat(container) -> None:
    gen.status("Capturing chat + files…")
    messages, raw_jsonl = _pull_claude_transcript(container)
    files = _pull_project_files(container, "/home/coder/project")

    snapshot: dict[str, str] = {}
    for rel, text in files:
        if rel == "claude_session.jsonl":
            continue
        snapshot[rel] = text
    if raw_jsonl:
        snapshot["claude_session.jsonl"] = raw_jsonl

    cell_id = await gen.create_stack_cell(
        "Claude CLI capture",
        summary=f"{len(messages)} messages · {len(files)} files",
        files=snapshot,
    )
    gen.log(
        f"Captured Claude CLI session into cell {cell_id} "
        f"({len(messages)} messages, {len(files)} files)"
    )
    gen.status("Terminal ready — open the cell to attach.")


def _pull_claude_transcript(container) -> tuple[list[dict], str | None]:
    ls = container.exec_run(
        ["bash", "-lc", "ls -t /home/coder/.claude/projects/*/*.jsonl 2>/dev/null | head -1"]
    )
    if ls.exit_code != 0:
        return [], None
    latest = ls.output.decode("utf-8", errors="replace").strip()
    if not latest:
        return [], None

    cat = container.exec_run(["cat", latest])
    if cat.exit_code != 0:
        return [], None
    raw = cat.output.decode("utf-8", errors="replace")

    messages: list[dict] = []
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue
        if entry.get("type") not in ("user", "assistant"):
            continue
        msg = entry.get("message") or {}
        role = msg.get("role") or entry.get("type")
        text = _extract_text(msg.get("content"))
        if not text:
            continue
        messages.append({"role": role, "content": text})
    return messages, raw


def _extract_text(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                t = block.get("text") or ""
                if t:
                    parts.append(t)
        return "\n".join(parts)
    return ""


def _pull_project_files(container, project_dir: str) -> list[tuple[str, str]]:
    allowed: set[str] | None = None
    if container.exec_run(["test", "-d", os.path.join(project_dir, ".git")]).exit_code == 0:
        ls = container.exec_run(
            ["git", "-C", project_dir, "ls-files", "--cached", "--others", "--exclude-standard"]
        )
        if ls.exit_code == 0:
            raw = ls.output.decode("utf-8", errors="replace")
            allowed = {line for line in raw.splitlines() if line.strip()}

    bits, _ = container.get_archive(project_dir)
    buf = io.BytesIO()
    for chunk in bits:
        buf.write(chunk)
    buf.seek(0)

    out: list[tuple[str, str]] = []
    with tarfile.open(fileobj=buf, mode="r") as tar:
        for member in tar.getmembers():
            if not member.isfile():
                continue
            parts = member.name.split("/", 1)
            if len(parts) < 2:
                continue
            rel = parts[1]
            if rel == ".git" or rel.startswith(".git/"):
                continue
            if rel == ".colreserved" or rel.startswith(".colreserved/"):
                continue  # SDK-internal config/prompt — never capture it (reserved path)
            if allowed is not None and rel not in allowed:
                continue
            if member.size > _CAPTURE_MAX_FILE_BYTES:
                continue
            f = tar.extractfile(member)
            if f is None:
                continue
            try:
                text = f.read().decode("utf-8")
            except UnicodeDecodeError:
                continue
            out.append((rel, text))
    return out


if __name__ == "__main__":
    gen.main(run)
