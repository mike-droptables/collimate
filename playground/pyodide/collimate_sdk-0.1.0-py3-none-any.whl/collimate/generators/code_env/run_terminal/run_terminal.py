# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "docker"]
# ///
"""Run Terminal — a live terminal app on a cell's files, inside a Linux image.

A generic, ``modify``-only terminal runner. Owns its own image
(``collimate-run-terminal:latest``, single-consumer) and runs it through the
shared ``_env_shared.DockerEnvironment`` helper — the same shape as
``claude_cli`` / ``vscode_env``. PID 1 is ``sleep infinity``.

The cell workspace is bind-mounted **read-write** at ``/workspace`` and the
configured app runs in it directly. The manifest's ``live_files_mode: "auto"``
makes the SDK runtime keep ``/workspace`` and the cell in **live, bidirectional
sync** for the whole run (``gen.live_files``) — zero sync code here.

What runs is the ``command`` setting: the default is a live ``bash`` shell, and
the bundled image also ships ``git`` + ``gh`` + ``lazygit`` so git tooling works
out of the box. The ``lazygit`` config tag flips ``command`` to ``lazygit`` and
turns on GitHub HTTPS auto-auth; point ``command`` (and, for anything not in the
bundled image, ``image``) at any other terminal app to run it instead. An
optional ``startup_commands`` snippet runs visibly when the terminal opens
(``cd``, ``export``, installs, a server) and then we ``exec`` into the app.
"""
from __future__ import annotations

import os
import shlex
import sys
from pathlib import Path
from urllib.parse import quote

import gen

# The shared _* cell-folders are SIBLINGS at run time (materialised into
# the cell); in the repo/tests they live at the asset root, one level above
# this generator's cell parent folder. Insert both.
_here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(_here))
sys.path.insert(0, os.path.dirname(os.path.dirname(_here)))
from _env_shared import DockerEnvironment  # noqa: E402

# The image built from this generator's Dockerfile (bash + git + gh + lazygit).
# A custom `image` setting names a tag that must already exist on the host.
BUNDLED_IMAGE = "collimate-run-terminal:latest"


async def run() -> None:
    cfg = gen.config("settings.set_yaml")
    raw_command = (cfg.get("command") or "").strip() or "bash"
    startup_commands = (cfg.get("startup_commands") or "").strip()
    image = (cfg.get("image") or "").strip() or BUNDLED_IMAGE
    sudo_enabled = bool(cfg.get("sudo", False))
    use_github_login = bool(cfg.get("use_github_login", False))
    git_user_name = (cfg.get("git_user_name") or "").strip()
    git_user_email = (cfg.get("git_user_email") or "").strip()

    command = shlex.split(raw_command) or ["bash"]
    label = command[0] or "terminal"

    # Optional startup commands run once when the terminal opens, visible in the
    # session, then we ``exec`` into the app so it becomes the PTY's leader. exec
    # carries the startup login shell's exported env + cwd into the app, so `cd`,
    # `export`, installs, `git checkout`, a started server, etc. all stick.
    if startup_commands:
        launch = ["bash", "-lc", f"{startup_commands}\nexec {shlex.join(command)}"]
    else:
        launch = command

    await gen.update(name="Run Terminal", summary="Starting…")

    # Only the bundled image builds from our Dockerfile on first use; a custom
    # `image` tag must already be built/pulled on the host (clear error if not).
    build_context = (
        str(Path(__file__).resolve().parent) if image == BUNDLED_IMAGE else None
    )

    env = DockerEnvironment(
        image=image,
        mount="/workspace", mount_mode="rw",
        build_context=build_context,
        name_prefix="collimate-run-terminal", kind="run_terminal",
    )
    container = env.container
    try:
        # The workspace is mounted READ-WRITE and the app runs in it in place, so
        # its writes land in the cell's own workspace dir (auto live_files
        # re-emits them). Make sure it's a git repo so git tools (lazygit, tig,
        # …) have something to drive, and hide the SDK-internal `.colreserved`
        # from git WITHOUT deleting it — the file lives in the real cell
        # workspace here, so `rm` would drop it from the cell.
        gen.status("Preparing workspace…")
        container.exec_run(
            ["bash", "-lc",
             "git -C /workspace rev-parse --git-dir >/dev/null 2>&1 || "
             "git -C /workspace init -q; "
             "grep -qxF '.colreserved' /workspace/.git/info/exclude 2>/dev/null || "
             "printf '%s\\n' '.colreserved' '.colreserved/' "
             ">> /workspace/.git/info/exclude"],
            user="coder",
        )

        if sudo_enabled:
            _enable_sudo(container)

        await _configure_git(container, use_github_login, git_user_name, git_user_email)

        gen.status("Registering terminal session…")
        async with gen.serve_terminal(
            env.container_id, launch,
            cwd="/workspace", env={"TERM": "xterm-256color"},
            label=label, pointer="app.terminal",
            name="Run Terminal", summary=f"live · {label}",
        ):
            gen.status(f"{label} ready — open the cell to attach. Edits sync to the cell live.")

            # Bidirectional cell <-> workspace file sync is handled by the SDK
            # runtime: the manifest's `live_files_mode: auto` makes gen.main wrap
            # the whole run in gen.live_files(), so the app's edits to the
            # bind-mounted /workspace flow to the cell and the user's Files-tab
            # edits flow back into /workspace — no loop here. Just stay alive.
            await gen.wait_until_cancelled()
    finally:
        env.close()


def _enable_sudo(container) -> None:
    """Grant the container's ``coder`` user passwordless sudo by dropping a
    sudoers file as root (``exec`` overrides the image's non-root USER). ``sudo``
    ships in the bundled image; a custom image must provide it for this to take
    effect — we surface a clear log line either way."""
    res = container.exec_run(
        ["bash", "-lc",
         "if command -v sudo >/dev/null 2>&1; then "
         "  echo 'coder ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/collimate && "
         "  chmod 440 /etc/sudoers.d/collimate && echo OK; "
         "else echo NOSUDO; fi"],
        user="root",
    )
    out = res.output
    if isinstance(out, (bytes, bytearray)):
        out = out.decode("utf-8", errors="replace")
    if "OK" in (out or ""):
        gen.log("Enabled passwordless sudo for the terminal user (coder)")
    else:
        gen.log("sudo requested but not installed in the image — use the bundled "
                "image or add `sudo` to your custom image")


async def _configure_git(container, use_github_login: bool, name: str, email: str) -> None:
    """Set a commit identity and, when enabled and present in the keystore,
    wire GitHub HTTPS credentials into the container's git so fetch/pull/push
    authenticate without an interactive prompt.

    The token is handed to git via the exec's *environment* (sent over the
    Docker API, never on a host argv), so it never lands in ``ps`` output or
    the run log — only a redacted "configured credentials" line is logged.
    """
    # Sane git defaults for a throwaway repo in a fresh container.
    container.exec_run(
        ["bash", "-lc",
         "git config --global init.defaultBranch main; "
         "git config --global --add safe.directory '*'; "
         "git config --global pull.rebase false"],
        user="coder",
    )

    gh_user = ""
    gh_pw = ""
    if use_github_login:
        gh_user = await gen.secret(
            "githubuser", prompt_if_missing=True,
            description="GitHub username for HTTPS git auth in the terminal",
        )
        gh_pw = await gen.secret(
            "githubpassword", prompt_if_missing=True,
            description="GitHub personal-access token (used as the HTTPS password)",
        )

    # Commit identity: explicit config wins, else fall back to the GitHub
    # username + a noreply email so commits aren't authored by "coder@<host>".
    name = name or gh_user
    email = email or (f"{gh_user}@users.noreply.github.com" if gh_user else "")
    if name:
        container.exec_run(["git", "config", "--global", "user.name", name], user="coder")
    if email:
        container.exec_run(["git", "config", "--global", "user.email", email], user="coder")

    if use_github_login and gh_user and gh_pw:
        # credential.helper=store reads $HOME/.git-credentials; one line of
        # https://user:token@github.com authenticates every github.com remote.
        cred = f"https://{quote(gh_user, safe='')}:{quote(gh_pw, safe='')}@github.com"
        container.exec_run(
            ["bash", "-lc",
             "git config --global credential.helper store && "
             "umask 077 && printf '%s\\n' \"$COLLIMATE_GH_CRED\" > \"$HOME/.git-credentials\""],
            user="coder",
            environment={"COLLIMATE_GH_CRED": cred},
        )
        gen.log("Configured GitHub keystore credentials for HTTPS git")
    elif use_github_login:
        gen.log("GitHub login requested but githubuser/githubpassword not set — "
                "git works on local repos but HTTPS push/pull will prompt")


if __name__ == "__main__":
    gen.main(run)
