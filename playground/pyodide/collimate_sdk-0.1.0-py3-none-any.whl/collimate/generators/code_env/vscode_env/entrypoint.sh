#!/usr/bin/env bash
set -euo pipefail

echo "[entrypoint] starting"
echo "[entrypoint] PORT=${PORT:-unset}"

# Open the cell workspace IN PLACE. /workspace is the cell's own workspace
# directory bind-mounted read-write, so every edit code-server makes lands
# in the cell and syncs back live — no copy, no manual snapshot. (We used to
# copy /workspace into a private project dir behind a read-only mount, which
# made the files one-way and locked.)
PROJECT_DIR=/workspace
mkdir -p "${PROJECT_DIR}"

# Claude Code startup marker. The generator passes COLLIMATE_START_CLAUDE
# (1/0); the builtin bootstrap extension reads it — and this marker file as a
# fallback — to decide whether to open Claude Code on first paint.
if [[ "${COLLIMATE_START_CLAUDE:-1}" == "1" ]]; then
    mkdir -p /home/coder/.collimate && touch /home/coder/.collimate/open-claude
    echo "[entrypoint] Claude Code will open on startup"
else
    rm -f /home/coder/.collimate/open-claude 2>/dev/null || true
    echo "[entrypoint] starting a plain VS Code window"
fi

# Configure git author identity if provided.
if [[ -n "${GIT_USER_NAME:-}" ]]; then
    git config --global user.name "${GIT_USER_NAME}"
    echo "[entrypoint] git user.name = ${GIT_USER_NAME}"
fi
if [[ -n "${GIT_USER_EMAIL:-}" ]]; then
    git config --global user.email "${GIT_USER_EMAIL}"
    echo "[entrypoint] git user.email = ${GIT_USER_EMAIL}"
fi

# Seed git credentials for github.com if provided.
if [[ -n "${GITHUB_USER:-}" && -n "${GITHUB_PASSWORD:-}" ]]; then
    git config --global credential.helper store
    # URL-encode user + password in case they contain special chars.
    enc_user=$(python3 -c 'import os, urllib.parse; print(urllib.parse.quote(os.environ["GITHUB_USER"], safe=""))')
    enc_pw=$(python3 -c 'import os, urllib.parse; print(urllib.parse.quote(os.environ["GITHUB_PASSWORD"], safe=""))')
    {
        echo "https://${enc_user}:${enc_pw}@github.com"
    } > /home/coder/.git-credentials
    chmod 600 /home/coder/.git-credentials
    echo "[entrypoint] git credentials configured for github.com"
fi

# (Extensions are baked into the image at build time — see the Dockerfile's
# EXTENSIONS RUN block. The previous runtime install path was unreliable.)

# Run startup commands in background, in parallel with code-server.
if [[ -n "${STARTUP_COMMANDS:-}" ]]; then
    echo "[entrypoint] launching startup commands in background"
    (
        cd "${PROJECT_DIR}"
        python3 - <<'PYEOF'
import json, os, subprocess, sys
cmds = json.loads(os.environ.get("STARTUP_COMMANDS", "[]"))
for c in cmds:
    print(f"[startup] running: {c}", flush=True)
    rc = subprocess.call(c, shell=True)
    if rc != 0:
        print(f"[startup] command failed with exit {rc}: {c}", flush=True)
        sys.exit(rc)
print("[startup] all commands completed", flush=True)
PYEOF
    ) &
    echo "[entrypoint] startup pid: $!"
fi

# Wipe per-workspace editor state so the workbench never reopens stale file
# tabs from a previous run. code-server keys this state by workspace hash
# under ~/.local/share/code-server/User/workspaceStorage/; the image's
# persistent layer can carry it across rebuilds when cached. (Combined with
# the bootstrap extension's closeAllEditors, this guarantees the user lands
# on Claude Code alone.)
WORKSPACE_STORAGE="/home/coder/.local/share/code-server/User/workspaceStorage"
if [[ -d "${WORKSPACE_STORAGE}" ]]; then
    rm -rf "${WORKSPACE_STORAGE}"/* 2>/dev/null || true
    echo "[entrypoint] cleared workspaceStorage"
fi

# Launch code-server on the mounted workspace. Background startup commands
# keep running as children of code-server (PID-stable thanks to exec).
echo "[entrypoint] launching code-server on 0.0.0.0:${PORT} for ${PROJECT_DIR}"
exec code-server \
    --bind-addr "0.0.0.0:${PORT}" \
    "${PROJECT_DIR}"
