# /// script
# dependencies = ["google-genai", "pyyaml"]
# ///
"""
Commit — pick a winner from 2+ candidate cells.

INPUT ORDER IS SEMANTIC. The first selected cell is the ANCHOR; later
cells are CHALLENGERS. The anchor wins ties. A challenger only wins if
it clearly beats the anchor on the criteria.

This is stated in the manifest summary, in the prompt, and at the top of
decision.md so the user sees it in multiple places.

Multiple input cells land in `inputs/<NN>_<slug>/` subdirectories —
candidates are grouped by that namespace, preserving the selection order
via the numeric prefix.
"""

import os
import re

from google import genai
from google.genai import types

from collimate.sdk import Generator

gen = Generator()

PROMPT = """You are committing to ONE candidate from the set below, or a tight synthesis that picks the anchor's spine and borrows named pieces from challengers.

RULES:
- INPUT ORDER IS SEMANTIC. Candidate 1 is the ANCHOR. Others are CHALLENGERS.
- The anchor wins ties. A challenger only wins if it clearly beats the anchor.
- Name what you keep and what you deliberately drop. Do not hedge.

{criteria_block}CANDIDATES (in selection order):
{candidates_block}

Write decision.md with these sections:

> **How this was decided:** Input order is semantic — candidate 1 is the anchor; the others are challengers the anchor must beat on the criteria.

## Pick
One sentence stating which candidate (by number + title) wins, and whether the winner is a straight pick or an anchor-plus-borrow synthesis.

## Why
2–4 bullets tying the pick to concrete differences against the non-winners.

## What we're keeping
Bullet list of specific pieces we carry forward (quote/name them).

## What we're dropping
Bullet list of specific pieces we explicitly leave out, and why.

## Open sub-problems
3–6 concrete follow-ups that the pick creates but doesn't solve.

Return ONLY the markdown. No fence."""


def _group_inputs() -> list[tuple[str, dict[str, str]]]:
    """Return [(group_name, {path: content})] in sorted group-name order, which
    preserves the NN_<slug> numeric prefix that runs land input cells under —
    so the first selected cell is always the anchor."""
    by_group: dict[str, dict[str, str]] = {}
    for p in gen.fs.list():
        if p.startswith(".colreserved"):
            continue
        if p.startswith("inputs/"):
            parts = p.split("/", 2)
            if len(parts) >= 2:
                group = parts[1]
                rel = parts[2] if len(parts) == 3 else parts[1]
                by_group.setdefault(group, {})[rel] = gen.fs.read(p)
                continue
        by_group.setdefault("(ungrouped)", {})[p] = gen.fs.read(p)
    if len(by_group) > 1 and "(ungrouped)" in by_group:
        del by_group["(ungrouped)"]
    return sorted(by_group.items())


def _candidate_title(group: str, files: dict[str, str]) -> str:
    """Prefer the brief.md's first H1, fall back to slug."""
    brief = files.get("brief.md")
    if brief:
        m = re.search(r"^\s*#\s+(.+)", brief, re.MULTILINE)
        if m:
            return m.group(1).strip()[:80]
    # Strip NN_ prefix from slug.
    slug = re.sub(r"^\d+_", "", group)
    return slug.replace("-", " ").replace("_", " ")[:80]


@gen.run(name="Commit")
def main():
    settings = gen.config.read_schema_values("settings.set_yaml")
    api_key = settings.get("api_key") or os.environ.get("GEMINI_API_KEY", "")
    if not api_key:
        raise Exception("GEMINI_API_KEY not set.")
    model = settings.get("model", "gemini-2.5-flash")
    criteria = (settings.get("criteria", "") or "").strip()

    groups = _group_inputs()
    if len(groups) < 2:
        raise Exception(
            "Commit needs at least 2 input cells. The first cell you select "
            "is the ANCHOR; later cells are challengers it must beat."
        )

    blocks = []
    candidate_index = []
    for i, (group, files) in enumerate(groups, start=1):
        tag = "ANCHOR" if i == 1 else f"CHALLENGER {i}"
        title = _candidate_title(group, files)
        candidate_index.append((i, title))
        header = f"=== CANDIDATE {i} [{tag}] — {title} (source: {group}) ==="
        # Trim huge files to avoid context blowouts.
        body_parts = []
        for p, c in files.items():
            if len(c) > 4000:
                c = c[:4000] + "\n\n...(truncated)..."
            body_parts.append(f"--- {p} ---\n{c}")
        body = "\n\n".join(body_parts)
        blocks.append(f"{header}\n{body}")
    candidates_block = "\n\n".join(blocks)

    criteria_block = f"CRITERIA:\n{criteria}\n\n" if criteria else ""

    prompt = PROMPT.format(criteria_block=criteria_block, candidates_block=candidates_block)

    gen.status = f"Committing across {len(groups)} candidate(s) with {model}..."
    client = genai.Client(api_key=api_key)
    resp = client.models.generate_content(
        model=model, contents=prompt,
        config=types.GenerateContentConfig(temperature=0.3),
    )
    text = (resp.text or "").strip()
    if not text:
        raise Exception("Commit: model returned empty output.")

    # Build a short candidate index header to sit above the LLM output so the
    # numbering in the Pick section is interpretable.
    idx_lines = ["## Candidates considered", ""]
    for i, title in candidate_index:
        tag = "anchor" if i == 1 else "challenger"
        idx_lines.append(f"{i}. **{title}** — {tag}")
    idx_block = "\n".join(idx_lines)

    final = f"{text}\n\n---\n\n{idx_block}\n"
    gen.fs.write("decision.md", final)
    gen.chat.append(role="assistant", content=f"**Decision**\n\n{text[:500]}{'...' if len(text) > 500 else ''}")
    anchor_title = candidate_index[0][1] if candidate_index else "anchor"
    gen.update_cell(
        name=f"Commit: {anchor_title}"[:60],
        summary=f"Committed across {len(groups)} candidates (anchor: {anchor_title})",
        metadata={"operator": "commit", "candidate_count": len(groups), "anchor_title": anchor_title},
    )


if __name__ == "__main__":
    main()
