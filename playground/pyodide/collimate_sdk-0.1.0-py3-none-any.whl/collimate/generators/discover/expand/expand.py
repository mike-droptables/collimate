# /// script
# dependencies = ["google-genai", "pyyaml"]
# ///
"""
Expand — fan out N alternative next-moves as sibling cells.

Each new cell gets:
  - brief.md  : a refined brief tailored to the variant
  - seed.md   : short prose describing how the variant diverges and what to
                explore next; summary_artifact for the cell preview.

The user picks a variant they like and applies a starter or another move
to materialise it. Expand does NOT try to produce the full artifact in
each variant — that would lock the divergence prematurely.
"""

import json
import os
import re

from google import genai
from google.genai import types

from collimate.sdk import Generator

gen = Generator()

PROMPT = """You are producing {count} GENUINELY DISTINCT next-moves from the cell below. Different in KIND, not stylistic restatements.

{lens_block}SOURCE BRIEF:
{brief}

SOURCE ARTIFACTS:
{artifacts_block}

For each alternative, write:
- a refined brief (Audience / How / Value) tuned to the variant
- a short seed.md: 2–4 sentences naming what's distinct about this variant and the first concrete move a user would try next.

Return STRICTLY a JSON array of {count} objects with keys:
- "title"  : short noun phrase (<60 chars)
- "brief"  : full markdown for brief.md (with Audience / How / Value sections)
- "seed"   : full markdown for seed.md

Return ONLY the JSON array. No fence."""


def _strip_fence(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def _read_brief() -> str:
    if gen.fs.exists("brief.md"):
        return gen.fs.read("brief.md")
    return "(no brief.md in source cell — infer from artifacts)"


def _artifacts_block() -> str:
    files = [p for p in gen.fs.list() if p != "brief.md" and not p.startswith(".colreserved")]
    if not files:
        return "(no other artifacts)"
    blocks = []
    for p in files:
        try:
            content = gen.fs.read(p)
            if len(content) > 4000:
                content = content[:4000] + "\n\n...(truncated)..."
            blocks.append(f"--- {p} ---\n{content}")
        except Exception:
            pass
    return "\n\n".join(blocks) if blocks else "(no readable artifacts)"


@gen.run(name="Expand")
def main():
    settings = gen.config.read_schema_values("settings.set_yaml")
    api_key = settings.get("api_key") or os.environ.get("GEMINI_API_KEY", "")
    if not api_key:
        raise Exception("GEMINI_API_KEY not set.")
    model = settings.get("model", "gemini-2.5-flash")
    count = int(settings.get("count", 4) or 4)
    lens = (settings.get("lens", "") or "").strip()

    brief = _read_brief()
    artifacts_block = _artifacts_block()
    lens_block = f"LENS: {lens}\n\n" if lens else ""

    prompt = PROMPT.format(
        count=count, lens_block=lens_block, brief=brief, artifacts_block=artifacts_block,
    )

    gen.status = f"Expanding into {count} alternatives with {model}..."
    client = genai.Client(api_key=api_key)
    resp = client.models.generate_content(
        model=model, contents=prompt,
        config=types.GenerateContentConfig(temperature=0.9, response_mime_type="application/json"),
    )
    raw = _strip_fence(resp.text or "")
    try:
        items = json.loads(raw)
    except Exception as e:
        raise Exception(f"Expand: invalid JSON ({e}). Raw: {raw[:300]}")
    if not isinstance(items, list) or not items:
        raise Exception("Expand: model returned empty or non-list response.")

    gen.progress(0, len(items))
    for i, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        title = (item.get("title") or f"Alternative {i+1}").strip()[:60]
        variant_brief = (item.get("brief") or "").strip()
        seed = (item.get("seed") or "").strip()
        if not seed:
            continue

        # Each variant overwrites the same workspace files; update_cell/create_cell
        # snapshot the current state per call. Use deleted_files to drop the
        # previous variant's carried-forward artifacts so each new cell is clean.
        gen.fs.write("brief.md", variant_brief + "\n")
        gen.fs.write("seed.md", seed + "\n")
        gen.chat.append(role="assistant", content=f"**{title}**\n\n{seed[:300]}")

        carry_artifacts = [p for p in gen.fs.list() if p not in ("brief.md", "seed.md") and not p.startswith(".colreserved")]

        if i == 0:
            gen.update_cell(
                name=title, summary=title,
                metadata={"operator": "expand", "index": i, "total": len(items)},
                deleted_files=carry_artifacts,
            )
        else:
            gen.create_cell(
                name=title, summary=title,
                metadata={"operator": "expand", "index": i, "total": len(items)},
            )
        gen.progress(i + 1, len(items))


if __name__ == "__main__":
    main()
