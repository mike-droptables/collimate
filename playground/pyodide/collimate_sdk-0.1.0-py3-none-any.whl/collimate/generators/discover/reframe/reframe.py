# /// script
# dependencies = ["google-genai", "pyyaml"]
# ///
"""
Reframe — rewrite brief.md based on what's been learned.

Reads current brief, all non-brief artifacts (run outputs, decisions,
drafts, etc.), and chat history. Produces:

  - brief.md         : the NEW brief. Overwrites the prior version.
  - reframe-diff.md  : what changed, why, and what it invalidates.

This is Schön's reframing / Dorst's frame innovation at the cell scale.
Every move after the reframe reads the new brief.
"""

import json
import os
import re

from google import genai
from google.genai import types

from collimate.sdk import Generator

gen = Generator()

PROMPT = """You are rewriting the brief for a cell based on what's been learned since the original brief was written.

RULES:
- The new brief MUST still carry **Audience**, **How**, **Value** sections.
- Surface what shifted: the original framing was wrong/incomplete in a specific way. Say so.
- Do not smooth over tensions. If a constraint conflicts with the value, name the tension.
- If nothing learned warrants a reframe, say so and produce only a minor-polish revision.

{trigger_block}CURRENT brief.md:
{brief}

ARTIFACTS AND RUN OUTPUTS IN THE CELL:
{artifacts_block}

RECENT CHAT (most recent last):
{chat_tail}

Return STRICTLY a JSON object with keys:
- "brief"   : the NEW brief.md contents (three sections + optional Notes).
- "diff_md" : reframe-diff.md contents: 3 sections — "## What changed", "## Why", "## What this invalidates" (list anything downstream that now needs rework).

Return ONLY the JSON object. No fence."""


def _strip_fence(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def _read_brief() -> str:
    if gen.fs.exists("brief.md"):
        return gen.fs.read("brief.md")
    return "(no brief.md — infer from artifacts)"


def _artifacts_block() -> str:
    files = [p for p in gen.fs.list() if p != "brief.md" and not p.startswith(".colreserved")]
    if not files:
        return "(no other artifacts)"
    blocks = []
    for p in files:
        try:
            content = gen.fs.read(p)
        except Exception:
            continue
        if len(content) > 4000:
            content = content[:4000] + "\n\n...(truncated)..."
        blocks.append(f"--- {p} ---\n{content}")
    return "\n\n".join(blocks) if blocks else "(no readable artifacts)"


def _chat_tail(limit: int = 10) -> str:
    msgs = gen.chat.history[-limit:]
    if not msgs:
        return "(no chat)"
    return "\n\n".join(f"{m.role}: {m.content}" for m in msgs)


@gen.run(name="Reframe")
def main():
    settings = gen.config.read_schema_values("settings.set_yaml")
    api_key = settings.get("api_key") or os.environ.get("GEMINI_API_KEY", "")
    if not api_key:
        raise Exception("GEMINI_API_KEY not set.")
    model = settings.get("model", "gemini-2.5-flash")
    trigger = (settings.get("trigger", "") or "").strip()
    trigger_block = f"TRIGGER: {trigger}\n\n" if trigger else ""

    prompt = PROMPT.format(
        trigger_block=trigger_block,
        brief=_read_brief(),
        artifacts_block=_artifacts_block(),
        chat_tail=_chat_tail(),
    )

    gen.status = f"Reframing with {model}..."
    client = genai.Client(api_key=api_key)
    resp = client.models.generate_content(
        model=model, contents=prompt,
        config=types.GenerateContentConfig(temperature=0.5, response_mime_type="application/json"),
    )
    raw = _strip_fence(resp.text or "")
    try:
        data = json.loads(raw)
    except Exception as e:
        raise Exception(f"Reframe: invalid JSON ({e}). Raw: {raw[:300]}")

    new_brief = (data.get("brief") or "").strip()
    diff_md = (data.get("diff_md") or "").strip()
    if not new_brief:
        raise Exception("Reframe: model returned empty brief.")

    gen.fs.write("brief.md", new_brief + "\n")
    gen.fs.write("reframe-diff.md", diff_md + "\n")
    gen.chat.append(role="assistant", content=f"**Reframe**\n\n{diff_md[:500]}{'...' if len(diff_md) > 500 else ''}")

    # Pull a short title from the first H1 in the new brief, if present.
    m = re.search(r"^\s*#\s+(.+)", new_brief, re.MULTILINE)
    title = m.group(1).strip()[:60] if m else "Reframed"
    gen.update_cell(
        name=title, summary="Reframed brief",
        metadata={"operator": "reframe", "trigger": trigger[:200]},
    )


if __name__ == "__main__":
    main()
