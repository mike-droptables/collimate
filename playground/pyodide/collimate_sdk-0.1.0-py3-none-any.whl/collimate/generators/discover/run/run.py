# /// script
# dependencies = ["pyyaml"]
# ///
"""
Run — execute the cell's core artifact natively (no Docker).

Detection order:
  1. `entry_override` setting, if non-empty
  2. notebook.py
  3. src/main.py
  4. src/run.sh
  5. the first *.py found at any depth

Python files run via `uv run <file>`; shell files via `bash <file>`. For
Python runs, any NEW `fig_*.png` produced is embedded (as markdown image
references) into run.md and into a refreshed notebook.md when notebook.py
was the entry.
"""

import os
import subprocess
import time

from collimate.sdk import Generator

gen = Generator()


def _detect_entry(override: str) -> str | None:
    if override:
        return override if gen.fs.exists(override) else None
    candidates = ["notebook.py", "src/main.py", "src/run.sh"]
    for c in candidates:
        if gen.fs.exists(c):
            return c
    # Fallback: first .py anywhere (skip config files).
    for p in sorted(gen.fs.list()):
        if p.endswith(".py") and not p.endswith(("setup.py", "conftest.py")):
            return p
    return None


def _snapshot_files() -> set[str]:
    return set(gen.fs.list())


@gen.run(name="Run")
def main():
    settings = gen.config.read_schema_values("settings.set_yaml")
    timeout_s = int(settings.get("timeout_s", 120) or 120)
    entry_override = (settings.get("entry_override", "") or "").strip()

    entry = _detect_entry(entry_override)
    if not entry:
        raise Exception(
            "Run: could not detect an entry file. Provide one in settings "
            "(e.g. 'notebook.py' or 'src/main.py')."
        )

    if entry.endswith(".py"):
        cmd = ["uv", "run", entry]
        kind = "python"
    elif entry.endswith(".sh"):
        cmd = ["bash", entry]
        kind = "bash"
    else:
        raise Exception(f"Run: unsupported entry file type: {entry}")

    pre_files = _snapshot_files()

    gen.status = f"Executing {entry} ({kind}, timeout {timeout_s}s)..."
    t0 = time.time()
    try:
        proc = subprocess.run(
            cmd, cwd=gen.workspace,
            capture_output=True, text=True, timeout=timeout_s,
        )
        timed_out = False
        returncode = proc.returncode
        stdout = proc.stdout or ""
        stderr = proc.stderr or ""
    except subprocess.TimeoutExpired as e:
        timed_out = True
        returncode = -1
        stdout = (e.stdout or b"").decode("utf-8", errors="replace") if isinstance(e.stdout, (bytes, bytearray)) else (e.stdout or "")
        stderr = (e.stderr or b"").decode("utf-8", errors="replace") if isinstance(e.stderr, (bytes, bytearray)) else (e.stderr or "")

    elapsed = time.time() - t0

    post_files = _snapshot_files()
    new_files = sorted(post_files - pre_files)
    new_plots = [p for p in new_files if p.startswith("fig_") and p.endswith(".png")]

    # --- Build run.md ---
    status_line = (
        "**TIMED OUT**" if timed_out
        else f"**Exit code:** {returncode}"
    )
    sections = [
        f"# Run — {entry}",
        "",
        f"- **Command:** `{' '.join(cmd)}`",
        f"- **Elapsed:** {elapsed:.1f}s",
        f"- {status_line}",
    ]
    if new_files:
        sections.append(f"- **New files:** {len(new_files)}")
        for p in new_files:
            sections.append(f"  - `{p}`")

    if new_plots:
        sections += ["", "## Plots", ""]
        for p in new_plots:
            sections.append(f"![{p}]({p})")

    if stdout.strip():
        sections += ["", "## stdout", "", "```", stdout.rstrip(), "```"]
    if stderr.strip():
        sections += ["", "## stderr", "", "```", stderr.rstrip(), "```"]

    gen.fs.write("run.md", "\n".join(sections) + "\n")

    # --- If the entry was notebook.py, refresh notebook.md with the plots ---
    if entry == "notebook.py" and new_plots:
        prior = gen.fs.read("notebook.md") if gen.fs.exists("notebook.md") else ""
        # Drop any previous "## Results" section and replace.
        marker = "\n## Results\n"
        base = prior.split(marker)[0].rstrip() if marker in prior else prior.rstrip()
        results = ["## Results", ""]
        if stdout.strip():
            results += ["```", stdout.rstrip(), "```", ""]
        for p in new_plots:
            results.append(f"![{p}]({p})")
        gen.fs.write("notebook.md", base + "\n\n" + "\n".join(results) + "\n")

    summary = (
        f"Timed out after {timeout_s}s" if timed_out
        else (f"Exit {returncode}" + (f", {len(new_plots)} plot(s)" if new_plots else ""))
    )
    gen.chat.append(
        role="assistant",
        content=f"**Run** — {entry}\n\n{summary}\n\nstdout: {stdout[:500]}{'...' if len(stdout) > 500 else ''}",
    )
    gen.update_cell(
        name=f"Run: {entry}"[:60], summary=summary,
        metadata={"operator": "run", "entry": entry, "kind": kind, "exit_code": returncode, "timed_out": timed_out},
    )

    if timed_out or returncode != 0:
        # Don't raise — a failing run is still a committable cell with run.md
        # explaining what happened. But flag it in the chat.
        gen.log.warning("[run] non-zero / timeout (returncode=%s, timed_out=%s)", returncode, timed_out)


if __name__ == "__main__":
    main()
