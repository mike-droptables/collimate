# /// script
# dependencies = ["google-genai", "pyyaml"]
# ///
"""
Start a code cell.

Writes brief.md + README.md + a minimal src/ skeleton for the picked language.
The Run move executes the cell's main entry point natively (via `uv run` for
Python, `node`/`bash` for others).
"""

import json
import os
import re

from google import genai
from google.genai import types

from collimate.sdk import Generator

gen = Generator()

PROMPT = """You are scaffolding a small codebase in language "{language}".

Produce:
1) brief.md — **Audience**, **How**, **Value** sections.
2) README.md — title, one-paragraph description, "How to run" section matching the language, "Next steps" section (3 bullets).
3) A minimal src/ skeleton with enough to run a "hello world"–level smoke test. Keep it under 4 files total.

Language-specific requirements:
- python  : include `src/main.py` using the `# /// script` inline deps header (empty deps list). README shows `uv run src/main.py`.
- node    : include `package.json` (minimal, with a `start` script), `tsconfig.json`, `src/index.ts`. README shows `npm install && npm start`.
- bash    : include `src/run.sh` (set -e, #!/usr/bin/env bash, chmod noted in README). README shows `bash src/run.sh`.
- other   : infer language from chat; produce 1–3 idiomatic starter files. README shows exact run command.

{source_clause}CHAT SEED:
{chat_seed}

Return STRICTLY a JSON object with keys:
- "title": short title (<60 chars)
- "brief": brief.md contents
- "readme": README.md contents
- "files": object mapping relative-file-path → file contents (e.g. {{"src/main.py": "...", "pyproject.toml": "..."}})

Return ONLY the JSON object. No fence."""


def _strip_fence(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def _source_block() -> str:
    files = [p for p in gen.fs.list() if not p.startswith(".colreserved")]
    if not files:
        return ""
    parts = []
    for p in files:
        try:
            parts.append(f"--- {p} ---\n{gen.fs.read(p)}")
        except Exception:
            pass
    return "SOURCE CELL (derive the scaffold from this — e.g. a requirements doc):\n" + "\n\n".join(parts) + "\n\n" if parts else ""


def _chat_seed() -> str:
    msgs = [m.content for m in gen.chat.history if m.role == "user"]
    return "\n\n".join(msgs).strip() or "(no chat seed)"


@gen.run(name="Start Code")
def main():
    settings = gen.config.read_schema_values("settings.set_yaml")
    api_key = settings.get("api_key") or os.environ.get("GEMINI_API_KEY", "")
    if not api_key:
        raise Exception("GEMINI_API_KEY not set.")
    model = settings.get("model", "gemini-2.5-flash")
    pickpath = gen.config.get_pickoptions()
    language = str(pickpath[0]) if pickpath else "python"

    source_clause = _source_block()
    chat_seed = _chat_seed()
    if not source_clause and chat_seed == "(no chat seed)":
        raise Exception("Type a chat seed or attach a source cell.")

    prompt = PROMPT.format(language=language, source_clause=source_clause, chat_seed=chat_seed)

    gen.status = f"Scaffolding {language} codebase with {model}..."
    client = genai.Client(api_key=api_key)
    resp = client.models.generate_content(
        model=model, contents=prompt,
        config=types.GenerateContentConfig(temperature=0.4, response_mime_type="application/json"),
    )
    raw = _strip_fence(resp.text or "")
    try:
        data = json.loads(raw)
    except Exception as e:
        raise Exception(f"Start Code: invalid JSON ({e}). Raw: {raw[:300]}")

    title = (data.get("title") or f"New {language} project").strip()[:60]
    brief = (data.get("brief") or "").strip()
    readme = (data.get("readme") or "").strip()
    files = data.get("files") or {}
    if not readme:
        raise Exception("Start Code: model returned empty README.md.")
    if not isinstance(files, dict) or not files:
        raise Exception("Start Code: model returned no source files.")

    gen.fs.write("brief.md", brief + "\n")
    gen.fs.write("README.md", readme + "\n")
    for path, content in files.items():
        if not isinstance(path, str) or not isinstance(content, str):
            continue
        gen.fs.write(path, content if content.endswith("\n") else content + "\n")

    gen.chat.append(role="assistant", content=f"**{title}** — scaffold ready ({len(files)} file(s)). Pick **Run** to execute.")
    gen.update_cell(name=title, summary=f"Code ({language}): {title}", metadata={"operator": "start-code", "language": language})


if __name__ == "__main__":
    main()
