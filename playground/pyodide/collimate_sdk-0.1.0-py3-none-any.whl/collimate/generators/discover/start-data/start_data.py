# /// script
# dependencies = ["google-genai", "pyyaml"]
# ///
"""
Start a data exploration.

Writes brief.md + notebook.py (with `# /// script` deps for pandas / seaborn /
matplotlib) + placeholder notebook.md. The user runs `run` next, which executes
notebook.py via `uv run` natively (no Docker) and embeds any saved fig_*.png
plots into a refreshed notebook.md.
"""

import json
import os
import re

from google import genai
from google.genai import types

from collimate.sdk import Generator

gen = Generator()

PROMPT = """You are opening a new data exploration for the user.

Produce:
1) brief.md — **Audience**, **How**, **Value** sections.
2) notebook.py — a single Python file that loads/synthesises a dataset, answers 2–4 specific questions, and saves 1–3 plots as `fig_01.png`, `fig_02.png`, etc. Requirements:
   - Start with an inline-deps header exactly as:
     # /// script
     # dependencies = ["pandas", "seaborn", "matplotlib", "numpy"]
     # ///
   - Use matplotlib's Agg backend (non-interactive): `import matplotlib; matplotlib.use("Agg")`
   - Save each figure via `fig.savefig("fig_0X.png", bbox_inches="tight")`, then `plt.close(fig)`
   - Print a short summary of findings to stdout.
   - If real data isn't available (or path unclear), generate a plausible synthetic dataset and clearly label it as such.
3) notebook.md — a placeholder: one-paragraph intro + a "Results will appear here after running" note.

{source_clause}DATASET HINT: {dataset_hint}

CHAT SEED:
{chat_seed}

Return STRICTLY a JSON object with keys:
- "title": short title (<60 chars)
- "brief": brief.md contents
- "notebook_py": notebook.py contents (exact Python source)
- "notebook_md": notebook.md placeholder contents

Return ONLY the JSON object. No fence."""


def _strip_fence(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def _source_block() -> str:
    files = [p for p in gen.fs.list() if not p.startswith(".colreserved")]
    if not files:
        return ""
    parts = []
    for p in files:
        try:
            parts.append(f"--- {p} ---\n{gen.fs.read(p)}")
        except Exception:
            pass
    return "SOURCE CELL (derive the exploration from this):\n" + "\n\n".join(parts) + "\n\n" if parts else ""


def _chat_seed() -> str:
    msgs = [m.content for m in gen.chat.history if m.role == "user"]
    return "\n\n".join(msgs).strip() or "(no chat seed)"


@gen.run(name="Start Data")
def main():
    settings = gen.config.read_schema_values("settings.set_yaml")
    api_key = settings.get("api_key") or os.environ.get("GEMINI_API_KEY", "")
    if not api_key:
        raise Exception("GEMINI_API_KEY not set.")
    model = settings.get("model", "gemini-2.5-flash")
    dataset_hint = (settings.get("dataset_hint", "") or "").strip() or "(none)"

    source_clause = _source_block()
    chat_seed = _chat_seed()
    if not source_clause and chat_seed == "(no chat seed)" and dataset_hint == "(none)":
        raise Exception("Type a chat seed, fill in the dataset hint, or attach a source cell.")

    prompt = PROMPT.format(source_clause=source_clause, dataset_hint=dataset_hint, chat_seed=chat_seed)

    gen.status = f"Planning exploration with {model}..."
    client = genai.Client(api_key=api_key)
    resp = client.models.generate_content(
        model=model, contents=prompt,
        config=types.GenerateContentConfig(temperature=0.5, response_mime_type="application/json"),
    )
    raw = _strip_fence(resp.text or "")
    try:
        data = json.loads(raw)
    except Exception as e:
        raise Exception(f"Start Data: invalid JSON ({e}). Raw: {raw[:300]}")

    title = (data.get("title") or "Data exploration").strip()[:60]
    brief = (data.get("brief") or "").strip()
    notebook_py = (data.get("notebook_py") or "").strip()
    notebook_md = (data.get("notebook_md") or "").strip()
    if not notebook_py:
        raise Exception("Start Data: model returned empty notebook.py.")

    gen.fs.write("brief.md", brief + "\n")
    gen.fs.write("notebook.py", notebook_py + "\n")
    gen.fs.write("notebook.md", notebook_md + "\n\n> Run this cell (pick **Run** in the picker) to execute `notebook.py` and render plots inline.\n")
    gen.chat.append(role="assistant", content=f"**{title}** — notebook ready. Pick **Run** to execute.")
    gen.update_cell(name=title, summary=f"Data: {title}", metadata={"operator": "start-data"})


if __name__ == "__main__":
    main()
