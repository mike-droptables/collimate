# /// script
# dependencies = ["google-genai", "pyyaml"]
# ///
"""
Start a diagram cell.

Pickoption determines output format:
  - "mermaid"    → LLM-generated diagram.mmd + brief.md
  - "excalidraw" → blank diagram.excalidraw scaffold + brief.md (user draws it)
"""

import json
import os
import re

from google import genai
from google.genai import types

from collimate.sdk import Generator

gen = Generator()

MERMAID_PROMPT = """You are drafting a Mermaid diagram for the user.

Produce:
1) brief.md — **Audience**, **How**, **Value** sections.
2) diagram.mmd — valid Mermaid syntax, kind: {kind}. Readable, 5–20 nodes, clear edge labels where helpful.

{source_clause}CHAT SEED:
{chat_seed}

Return STRICTLY a JSON object with keys:
- "title": short title (<60 chars)
- "brief": brief.md contents
- "mmd": diagram.mmd contents (pure Mermaid, no fence)

Return ONLY the JSON object. No fence, no prose."""

EXCALIDRAW_SCAFFOLD = {
    "type": "excalidraw",
    "version": 2,
    "source": "https://excalidraw.com",
    "elements": [
        {
            "type": "text",
            "version": 1,
            "versionNonce": 1,
            "isDeleted": False,
            "id": "seed-text",
            "x": 100,
            "y": 100,
            "width": 400,
            "height": 60,
            "angle": 0,
            "strokeColor": "#1e1e1e",
            "backgroundColor": "transparent",
            "fillStyle": "solid",
            "strokeWidth": 2,
            "strokeStyle": "solid",
            "roughness": 1,
            "opacity": 100,
            "groupIds": [],
            "frameId": None,
            "roundness": None,
            "seed": 1,
            "updated": 1,
            "link": None,
            "locked": False,
            "fontSize": 20,
            "fontFamily": 1,
            "text": "Draft your diagram here",
            "textAlign": "left",
            "verticalAlign": "top",
            "containerId": None,
            "originalText": "Draft your diagram here",
            "lineHeight": 1.25,
            "baseline": 18,
        }
    ],
    "appState": {"gridSize": None, "viewBackgroundColor": "#ffffff"},
    "files": {},
}


def _strip_fence(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def _source_block() -> str:
    files = [p for p in gen.fs.list() if not p.startswith(".colreserved")]
    if not files:
        return ""
    parts = []
    for p in files:
        try:
            parts.append(f"--- {p} ---\n{gen.fs.read(p)}")
        except Exception:
            pass
    return "SOURCE CELL (derive the diagram from this):\n" + "\n\n".join(parts) + "\n\n" if parts else ""


def _chat_seed() -> str:
    msgs = [m.content for m in gen.chat.history if m.role == "user"]
    return "\n\n".join(msgs).strip() or "(no chat seed)"


def _run_mermaid(settings):
    api_key = settings.get("api_key") or os.environ.get("GEMINI_API_KEY", "")
    if not api_key:
        raise Exception("GEMINI_API_KEY not set.")
    model = settings.get("model", "gemini-2.5-flash")
    kind = settings.get("diagram_kind", "flowchart")

    source_clause = _source_block()
    chat_seed = _chat_seed()
    if not source_clause and chat_seed == "(no chat seed)":
        raise Exception("Type a chat seed or attach a source cell.")

    prompt = MERMAID_PROMPT.format(kind=kind, source_clause=source_clause, chat_seed=chat_seed)

    gen.status = f"Drafting {kind} diagram with {model}..."
    client = genai.Client(api_key=api_key)
    resp = client.models.generate_content(
        model=model, contents=prompt,
        config=types.GenerateContentConfig(temperature=0.4, response_mime_type="application/json"),
    )
    raw = _strip_fence(resp.text or "")
    try:
        data = json.loads(raw)
    except Exception as e:
        raise Exception(f"Start Diagram: invalid JSON ({e}). Raw: {raw[:300]}")

    title = (data.get("title") or f"New {kind}").strip()[:60]
    brief = (data.get("brief") or "").strip()
    mmd = (data.get("mmd") or "").strip()
    if not mmd:
        raise Exception("Start Diagram (mermaid): model returned empty diagram.")

    gen.fs.write("brief.md", brief + "\n")
    gen.fs.write("diagram.mmd", mmd + "\n")
    gen.chat.append(role="assistant", content=f"**{title}**\n\n```mermaid\n{mmd[:400]}\n```")
    # Set summary_artifact dynamically so the cell preview shows the diagram.
    gen.update_cell(
        name=title, summary=f"Diagram ({kind}): {title}",
        metadata={"operator": "start-diagram", "format": "mermaid", "kind": kind, "summary_artifact": "diagram.mmd"},
    )


def _run_excalidraw():
    title = "New excalidraw diagram"
    brief = (
        "**Audience:** the person iterating on this diagram.\n\n"
        "**How:** hand-drawn on the excalidraw canvas. Fill in once the scaffold opens.\n\n"
        "**Value:** a visual sketch that's easy to reshape as understanding grows.\n"
    )
    gen.fs.write("brief.md", brief)
    gen.fs.write("diagram.excalidraw", json.dumps(EXCALIDRAW_SCAFFOLD, indent=2) + "\n")
    gen.chat.append(role="assistant", content="Excalidraw scaffold ready — open the canvas and draw.")
    gen.update_cell(
        name=title, summary="Excalidraw scaffold",
        metadata={"operator": "start-diagram", "format": "excalidraw", "summary_artifact": "diagram.excalidraw"},
    )


@gen.run(name="Start Diagram")
def main():
    settings = gen.config.read_schema_values("settings.set_yaml")
    pickpath = gen.config.get_pickoptions()
    fmt = str(pickpath[0]) if pickpath else "mermaid"

    if fmt == "mermaid":
        _run_mermaid(settings)
    elif fmt == "excalidraw":
        _run_excalidraw()
    else:
        raise Exception(f"Start Diagram: unknown format '{fmt}'")


if __name__ == "__main__":
    main()
