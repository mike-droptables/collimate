# /// script
# dependencies = ["google-genai", "pyyaml"]
# ///
"""
Start a markdown document.

0 inputs: seed brief.md + draft.md from chat.
1 input: read source cell's brief + artifacts, translate into a written doc.
"""

import json
import os
import re

from google import genai
from google.genai import types

from collimate.sdk import Generator

gen = Generator()

PROMPT = """You are opening a new markdown document for the user. Produce two artifacts together:

1) brief.md — a short frame carrying three sections: **Audience**, **How**, **Value**. One or two sentences each.
2) draft.md — the first draft of the document itself in SHAPE "{shape}". Full prose, ready to read.

{source_clause}CHAT SEED:
{chat_seed}

Return STRICTLY a JSON object with exactly these keys:
- "title": short title for the cell (<60 chars)
- "brief": the full markdown content of brief.md (including its three headed sections)
- "draft": the full markdown content of draft.md

Return ONLY the JSON object. No fence, no prose."""


def _strip_fence(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def _source_block() -> str:
    files = [p for p in gen.fs.list() if not p.startswith(".colreserved")]
    if not files:
        return ""
    parts = []
    for p in files:
        try:
            parts.append(f"--- {p} ---\n{gen.fs.read(p)}")
        except Exception:
            pass
    if not parts:
        return ""
    return "SOURCE CELL (translate this into the new doc; its brief, if any, is in brief.md):\n" + "\n\n".join(parts) + "\n\n"


def _chat_seed() -> str:
    msgs = [m.content for m in gen.chat.history if m.role == "user"]
    return "\n\n".join(msgs).strip() or "(no chat seed)"


@gen.run(name="Start Doc")
def main():
    settings = gen.config.read_schema_values("settings.set_yaml")
    api_key = settings.get("api_key") or os.environ.get("GEMINI_API_KEY", "")
    if not api_key:
        raise Exception("GEMINI_API_KEY not set.")
    model = settings.get("model", "gemini-2.5-flash")
    shape = settings.get("shape", "prose")

    source_clause = _source_block()
    chat_seed = _chat_seed()
    if not source_clause and chat_seed == "(no chat seed)":
        raise Exception("Type a seed prompt in chat, or attach a source cell to translate.")

    prompt = PROMPT.format(shape=shape, source_clause=source_clause, chat_seed=chat_seed)

    gen.status = f"Drafting doc with {model}..."
    client = genai.Client(api_key=api_key)
    resp = client.models.generate_content(
        model=model, contents=prompt,
        config=types.GenerateContentConfig(temperature=0.6, response_mime_type="application/json"),
    )
    raw = _strip_fence(resp.text or "")
    try:
        data = json.loads(raw)
    except Exception as e:
        raise Exception(f"Start Doc: invalid JSON ({e}). Raw: {raw[:300]}")

    title = (data.get("title") or "New doc").strip()[:60]
    brief = (data.get("brief") or "").strip()
    draft = (data.get("draft") or "").strip()
    if not draft:
        raise Exception("Start Doc: model returned empty draft.")

    gen.fs.write("brief.md", brief + "\n")
    gen.fs.write("draft.md", draft + "\n")
    gen.chat.append(role="assistant", content=f"**{title}**\n\n{draft[:300]}{'...' if len(draft) > 300 else ''}")
    gen.update_cell(name=title, summary=f"Doc: {title}", metadata={"operator": "start-doc", "shape": shape})


if __name__ == "__main__":
    main()
