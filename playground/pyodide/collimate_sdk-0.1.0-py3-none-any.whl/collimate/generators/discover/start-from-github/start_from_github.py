# /// script
# dependencies = ["google-genai", "pyyaml"]
# ///
"""
Start from a GitHub (or GitLab) clone.

Clones the repo, copies every file into the cell, then reads up to ~20
priority files (README, package manifests, top-level entry points) and
asks the LLM to infer an Audience / How / Value brief. Writes brief.md.
"""

import os
import subprocess
import tempfile
from urllib.parse import quote

from google import genai
from google.genai import types

from collimate.sdk import Generator

gen = Generator()

BRIEF_PROMPT = """You are writing a short brief for a codebase the user has just cloned.

Read the priority files below and produce brief.md with three sections:

**Audience:** Who reads / uses / maintains this codebase. (1–2 sentences.)
**How:** The approach / architecture / main abstractions in use. (2–3 sentences.)
**Value:** What this codebase is good for; the success test. (1–2 sentences.)

Then a "## Notes" section with 3–6 bullets covering: entry points, build/run commands, any notable files the user should look at first, and open questions.

REPOSITORY: {repo_url}

PRIORITY FILES:
{files_block}

Return ONLY the markdown. No fence."""

# File-name patterns to prioritise when sampling the repo for the brief.
# Earlier entries weigh more. Limit total to ~20 files.
PRIORITY_PATTERNS = [
    "README.md", "README.rst", "README.txt", "README",
    "readme.md",
    "pyproject.toml", "package.json", "Cargo.toml", "go.mod", "pom.xml",
    "requirements.txt", "setup.py", "setup.cfg",
    "Makefile", "Dockerfile", "docker-compose.yml", "docker-compose.yaml",
    "tsconfig.json", ".github/workflows",
    "CLAUDE.md", "CONTRIBUTING.md", "ARCHITECTURE.md",
]

TOP_LEVEL_CODE_EXTS = (".py", ".ts", ".tsx", ".js", ".jsx", ".go", ".rs", ".rb", ".java", ".kt", ".swift")


def _build_auth_url(repo_url: str, user: str, password: str) -> str:
    if not user and not password:
        return repo_url
    if not repo_url.startswith("https://"):
        return repo_url
    return f"https://{quote(user, safe='')}:{quote(password, safe='')}@{repo_url[len('https://'):]}"


def _walk_all_files(root: str) -> list[str]:
    out = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d != ".git"]
        for fname in filenames:
            abs_path = os.path.join(dirpath, fname)
            rel = os.path.relpath(abs_path, root)
            out.append(rel)
    return out


def _pick_priority_files(rel_paths: list[str], limit: int = 20) -> list[str]:
    """Pick up to `limit` priority files for LLM sampling."""
    picked: list[str] = []
    seen: set[str] = set()

    # Pass 1: exact named priorities (any depth).
    rel_lower = {p: p.lower() for p in rel_paths}
    for pat in PRIORITY_PATTERNS:
        pat_l = pat.lower()
        for p, pl in rel_lower.items():
            if p in seen:
                continue
            if pl == pat_l or pl.endswith("/" + pat_l) or pl.startswith(pat_l + "/"):
                picked.append(p)
                seen.add(p)
                if len(picked) >= limit:
                    return picked

    # Pass 2: top-level code files by common extensions.
    for p in sorted(rel_paths):
        if p in seen:
            continue
        if "/" not in p and p.endswith(TOP_LEVEL_CODE_EXTS):
            picked.append(p)
            seen.add(p)
            if len(picked) >= limit:
                return picked

    # Pass 3: src/*.{ext} top-level entries.
    for p in sorted(rel_paths):
        if p in seen:
            continue
        parts = p.split("/")
        if len(parts) == 2 and parts[0] in ("src", "lib", "app") and p.endswith(TOP_LEVEL_CODE_EXTS):
            picked.append(p)
            seen.add(p)
            if len(picked) >= limit:
                return picked

    return picked


def _read_capped(path: str, max_bytes: int = 8000) -> str:
    try:
        with open(path, "rb") as f:
            data = f.read(max_bytes + 1)
    except OSError:
        return "(unreadable)"
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        return "(binary)"
    if len(data) > max_bytes:
        text = text[:max_bytes] + "\n\n...(truncated)..."
    return text


@gen.run(name="Start from GitHub")
def main():
    settings = gen.config.read_schema_values("settings.set_yaml")
    repo_url = (settings.get("repo_url") or "").strip()
    if not repo_url:
        raise Exception("repo_url is required.")
    github_user = settings.get("github_user", "") or ""
    github_password = settings.get("github_password", "") or ""
    api_key = settings.get("api_key") or os.environ.get("GEMINI_API_KEY", "")
    if not api_key:
        raise Exception("GEMINI_API_KEY not set.")
    model = settings.get("model", "gemini-2.5-flash")

    gen.status = f"Cloning {repo_url}..."
    clone_url = _build_auth_url(repo_url, github_user, github_password)

    with tempfile.TemporaryDirectory() as tmp_dir:
        clone_dest = os.path.join(tmp_dir, "repo")
        result = subprocess.run(
            ["git", "clone", "--depth", "1", clone_url, clone_dest],
            capture_output=True, text=True, timeout=300,
        )
        if result.returncode != 0:
            stderr = result.stderr.strip()
            if github_password:
                stderr = stderr.replace(github_password, "***")
            if github_user:
                stderr = stderr.replace(github_user, "***")
            raise RuntimeError(f"git clone failed:\n{stderr}")

        gen.status = "Copying files into the cell..."
        rel_paths = _walk_all_files(clone_dest)
        copied = 0
        for rel in rel_paths:
            abs_path = os.path.join(clone_dest, rel)
            try:
                with open(abs_path, "rb") as f:
                    data = f.read()
            except OSError:
                continue
            try:
                gen.fs.write(rel, data.decode("utf-8"))
            except UnicodeDecodeError:
                gen.fs.write_bytes(rel, data)
            copied += 1

        gen.status = "Sampling priority files for the brief..."
        priority = _pick_priority_files(rel_paths, limit=20)
        blocks = []
        for rel in priority:
            abs_path = os.path.join(clone_dest, rel)
            blocks.append(f"--- {rel} ---\n{_read_capped(abs_path)}")
        files_block = "\n\n".join(blocks) if blocks else "(no priority files found — relying on file names alone)"

        gen.status = f"Inferring brief with {model}..."
        client = genai.Client(api_key=api_key)
        resp = client.models.generate_content(
            model=model,
            contents=BRIEF_PROMPT.format(repo_url=repo_url, files_block=files_block),
            config=types.GenerateContentConfig(temperature=0.3),
        )
        brief = (resp.text or "").strip()
        if not brief:
            raise Exception("Start from GitHub: brief inference returned empty output.")

    gen.fs.write("brief.md", brief + "\n")
    gen.chat.append(role="assistant", content=f"Cloned {repo_url} ({copied} file(s)). Brief inferred.\n\n{brief[:500]}")
    title = repo_url.rstrip("/").split("/")[-1].removesuffix(".git") or "Cloned repo"
    gen.update_cell(
        name=title[:60], summary=f"Cloned {repo_url}",
        metadata={"operator": "start-from-github", "repo_url": repo_url, "priority_files_sampled": len(priority)},
    )


if __name__ == "__main__":
    main()
