# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Git Clone — fetch a repo into a fresh cell.

Reads the URL from ``gen.prompt`` (the picker's primary prompt). Chooses
auth by URL shape:

  * https://... + ``use_github_login`` + keystore has ``githubuser`` /
    ``githubpassword`` → inline basic auth in the URL (credentials are
    scrubbed from any error output before we re-raise).
  * git@... or ssh://... + ``use_ssh_agent`` → forward ``SSH_AUTH_SOCK``
    into the clone subprocess. ``ssh_key_path`` overrides ssh's default
    identity resolution via ``GIT_SSH_COMMAND``.
  * Anything else falls through to anonymous / default behaviour.

Files from the resulting checkout (except ``.git``) land in the cell
via ``gen.update_file``. Binary files are skipped (a follow-up could
extend ``gen.update_file`` with a bytes path; today the API is text-only).
"""
from __future__ import annotations

import os
import tempfile
from urllib.parse import quote

import gen


async def run() -> None:
    cfg = gen.config("settings.set_yaml")
    use_github_login = bool(cfg.get("use_github_login", True))
    use_ssh_agent = bool(cfg.get("use_ssh_agent", True))
    ssh_key_path = (cfg.get("ssh_key_path") or "").strip()
    depth = _int(cfg.get("depth"), default=1)
    branch = (cfg.get("branch") or "").strip()
    submodules = bool(cfg.get("submodules", False))

    repo_url = (gen.prompt or "").strip()
    if not repo_url:
        gen.log("no repository URL provided")
        gen.update_file(
            "error.md",
            "# No repository URL\n\nPaste a repo URL into the picker's prompt.\n",
        )
        await gen.update(name="Git Clone", summary="Failed: no repository URL")
        return

    # Identity first — the cell shows what it is while it works.
    await gen.update(name="Git Clone", summary=f"Cloning {_scrub(repo_url)}…")

    scheme = _scheme(repo_url)
    gen.log(f"cloning {_scrub(repo_url)} (scheme={scheme})")

    clone_url = repo_url
    subprocess_env = {**os.environ}
    scrub_values: list[str] = []

    if scheme == "https" and use_github_login and "github.com" in repo_url:
        gh_user = await gen.secret(
            "githubuser",
            prompt_if_missing=True,
            description="GitHub username for HTTPS clone",
        )
        gh_pw = await gen.secret(
            "githubpassword",
            prompt_if_missing=True,
            description="GitHub personal-access token (used as HTTPS password)",
        )
        clone_url = _inject_https_auth(repo_url, gh_user, gh_pw)
        scrub_values += [gh_user, gh_pw]
        gen.log("using GitHub keystore credentials")

    if scheme == "ssh":
        if use_ssh_agent and "SSH_AUTH_SOCK" in os.environ:
            gen.log("forwarding SSH agent socket")
        if ssh_key_path:
            if not os.path.isfile(ssh_key_path):
                gen.log(f"ssh_key_path {ssh_key_path!r} does not exist")
                gen.update_file(
                    "error.md",
                    f"# Bad ssh_key_path\n\n`{ssh_key_path}` does not exist.\n",
                )
                await gen.update(name="Git Clone", summary="Failed: ssh_key_path does not exist")
                return
            subprocess_env["GIT_SSH_COMMAND"] = f'ssh -i {_shell_quote(ssh_key_path)}'
            gen.log(f"using ssh identity {ssh_key_path}")

    cmd: list[str] = ["git", "clone"]
    if depth and depth > 0:
        cmd += ["--depth", str(depth)]
    if branch:
        cmd += ["--branch", branch]
    if submodules:
        cmd += ["--recurse-submodules"]

    gen.phase("spinning_up", "cloning")
    with tempfile.TemporaryDirectory() as tmp_dir:
        dest = os.path.join(tmp_dir, "repo")
        cmd += [clone_url, dest]

        # Stream into the run log; capture full output for error scrubbing.
        # gen.run_subprocess merges stderr into stdout.
        original_env = dict(os.environ)
        try:
            os.environ.update(subprocess_env)
            rc, output = await gen.run_subprocess(cmd, timeout=600)
        finally:
            os.environ.clear()
            os.environ.update(original_env)

        if rc != 0:
            stderr = _scrub_all(output.strip(), scrub_values)
            reason = f"clone failed (rc={rc})"
            gen.log(reason)
            gen.update_file("error.md", f"# Clone failed\n\n```\n{stderr}\n```\n")
            await gen.update(name="Git Clone", summary=f"Failed: {reason}")
            return

        gen.phase("running", "copying files")
        files = _collect_files(dest)
        for rel, data in files:
            try:
                gen.update_file(rel, data.decode("utf-8"))
            except UnicodeDecodeError:
                # Binary files skipped — gen.update_file is text-only today.
                gen.log(f"skipped binary file: {rel}")

    gen.update_file(
        "clone_summary.md",
        _summary_md(repo_url, len(files), branch, depth, submodules),
    )
    await gen.update(
        name="Git Clone",
        summary=f"Cloned {_scrub(repo_url)} · {len(files)} files",
        pinned="clone_summary.md",
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _scheme(url: str) -> str:
    if url.startswith(("https://", "http://")):
        return "https"
    if url.startswith("ssh://") or url.startswith("git@"):
        return "ssh"
    if url.startswith("git://"):
        return "git"
    return "other"


def _inject_https_auth(url: str, user: str, password: str) -> str:
    if not url.startswith("https://"):
        return url
    return f"https://{quote(user, safe='')}:{quote(password, safe='')}@{url[len('https://'):]}"


def _collect_files(root: str) -> list[tuple[str, bytes]]:
    out: list[tuple[str, bytes]] = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d != ".git"]
        for fname in filenames:
            abs_path = os.path.join(dirpath, fname)
            rel_path = os.path.relpath(abs_path, root)
            try:
                with open(abs_path, "rb") as f:
                    out.append((rel_path, f.read()))
            except (OSError, PermissionError):
                gen.log(f"Skipping unreadable file: {rel_path}")
    return out


def _summary_md(repo_url: str, file_count: int, branch: str, depth: int, submodules: bool) -> str:
    lines = [
        "# Git Clone",
        "",
        f"**Repository:** {_scrub(repo_url)}",
        f"**Files:** {file_count}",
    ]
    if branch:
        lines.append(f"**Branch:** {branch}")
    if depth:
        lines.append(f"**Depth:** {depth}")
    if submodules:
        lines.append("**Submodules:** recursive")
    lines.append("")
    return "\n".join(lines) + "\n"


def _scrub(url: str) -> str:
    if not url.startswith("https://"):
        return url
    rest = url[len("https://"):]
    at = rest.find("@")
    slash = rest.find("/")
    if at == -1 or (slash != -1 and slash < at):
        return url
    return f"https://{rest[at + 1:]}"


def _scrub_all(text: str, values: list[str]) -> str:
    for v in values:
        if v:
            text = text.replace(v, "***")
    return text


def _shell_quote(s: str) -> str:
    return "'" + s.replace("'", "'\\''") + "'"


def _int(raw, default: int) -> int:
    try:
        n = int(raw)
        return n if n >= 0 else default
    except (TypeError, ValueError):
        return default


if __name__ == "__main__":
    gen.main(run)
