# /// script
# dependencies = ["docker", "pyyaml"]
# ///
"""
Claude Code Generator — runs Claude Code headless inside the
collimate-vscode Docker image against the input cell's files.

Flow:
  1. Copy every file from the input cell into a host temp directory.
  2. Mount that directory rw at /home/coder/output in the container.
  3. Build the prompt from the cell's chat history (the messages field).
  4. Launch `claude -p <prompt> --output-format stream-json --verbose
     --dangerously-skip-permissions` in that working directory.
  5. Stream the container's stdout, parse stream-json events, and pretty-print
     each one (text, tool_use, tool_result, thinking, system, result) to the
     run log so the user sees what Claude is doing in real time.
  6. After the container exits cleanly, walk the working directory and write
     every file (including new files Claude created and existing files Claude
     modified) back into the workspace via gen.fs.write_bytes.
  7. Append Claude's accumulated assistant text to the chat history.
  8. Explicitly commit the cell with a clear name/summary.
"""

import json
import os
import shutil
import tempfile
import uuid
from pathlib import Path

from collimate.sdk import Generator

gen = Generator()

VSCODE_IMAGE = "collimate-vscode:latest"

# Accumulator for assistant text blocks Claude emits during the run, so we
# can append them to the chat history at the end.
_assistant_text: list[str] = []


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _chmod_world_writable(path: str) -> None:
    """tempfile.mkdtemp creates 0700; the container's `coder` user (uid 1000)
    can't traverse or write into that. Open it up just enough."""
    try:
        os.chmod(path, 0o777)
        for root, dirs, files in os.walk(path):
            for d in dirs:
                try:
                    os.chmod(os.path.join(root, d), 0o777)
                except OSError:
                    pass
            for f in files:
                try:
                    os.chmod(os.path.join(root, f), 0o666)
                except OSError:
                    pass
    except OSError as e:
        gen.log.warning("Could not relax temp dir perms on %s: %s", path, e)


def _build_prompt(include_assistant: bool) -> str:
    history = gen.chat.history
    if not history:
        raise Exception(
            "This cell has no chat messages. Type a prompt into the cell's "
            "chat before running the Claude Code generator."
        )

    parts: list[str] = []
    for m in history:
        role = (m.role or "user").lower()
        if role == "assistant" and not include_assistant:
            continue
        content = (m.content or "").strip()
        if not content:
            continue
        parts.append(f"[{role.upper()}]\n{content}")

    if not parts:
        raise Exception("Chat history has no usable messages to send to Claude.")

    return "\n\n".join(parts)


def _copy_workspace_into(dest: str) -> int:
    """Copy every input cell file from gen.workspace into dest, preserving
    relative paths. Returns the count copied."""
    count = 0
    for rel in gen.fs.list():
        src = os.path.join(gen.workspace, rel)
        if not os.path.isfile(src):
            continue
        dst = os.path.join(dest, rel)
        os.makedirs(os.path.dirname(dst) or dest, exist_ok=True)
        shutil.copy2(src, dst)
        count += 1
    return count


def _commit_files_from(dir_path: str) -> int:
    """Walk the post-claude working directory and write every file back into
    gen.workspace via gen.fs.write_bytes so it's tracked for the commit."""
    count = 0
    root_p = Path(dir_path)
    for path in sorted(root_p.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root_p).as_posix()
        # Skip anything Claude might have written into a hidden ./.claude/
        # directory inside the working dir — that's tooling state, not output.
        if rel.startswith(".claude/") or rel == ".claude":
            continue
        try:
            data = path.read_bytes()
        except OSError as e:
            gen.log.warning("[claude] could not read %s: %s", rel, e)
            continue
        gen.fs.write_bytes(rel, data)
        gen.log.info("[claude] committing %s (%d bytes)", rel, len(data))
        count += 1
    return count


# ---------------------------------------------------------------------------
# Stream-json log pretty-printer
# ---------------------------------------------------------------------------

def _log_event(line: str) -> None:
    line = line.rstrip()
    if not line:
        return
    try:
        evt = json.loads(line)
    except json.JSONDecodeError:
        gen.log.info("[claude] %s", line[:1000])
        return
    if not isinstance(evt, dict):
        gen.log.info("[claude] %s", line[:1000])
        return

    evt_type = evt.get("type", "?")

    if evt_type == "system":
        subtype = evt.get("subtype", "")
        rest = {k: v for k, v in evt.items() if k not in ("type", "subtype")}
        gen.log.info("[claude:system:%s] %s", subtype, json.dumps(rest)[:500])
        return

    if evt_type == "assistant":
        msg = evt.get("message")
        if isinstance(msg, dict):
            for block in msg.get("content", []) or []:
                if not isinstance(block, dict):
                    continue
                btype = block.get("type")
                if btype == "text":
                    text = (block.get("text") or "").strip()
                    if text:
                        _assistant_text.append(text)
                        for ln in text.splitlines():
                            gen.log.info("[claude:text] %s", ln)
                elif btype == "tool_use":
                    name = block.get("name", "?")
                    inp = block.get("input", {})
                    inp_str = json.dumps(inp)[:600]
                    gen.log.info("[claude:tool_use] %s %s", name, inp_str)
                elif btype == "thinking":
                    th = (block.get("thinking") or "").strip()
                    if th:
                        gen.log.info("[claude:thinking] %s", th[:500])
                else:
                    gen.log.info("[claude:assistant:%s] %s", btype, json.dumps(block)[:500])
        return

    if evt_type == "user":
        msg = evt.get("message")
        if isinstance(msg, dict):
            for block in msg.get("content", []) or []:
                if isinstance(block, dict) and block.get("type") == "tool_result":
                    content = block.get("content", "")
                    if isinstance(content, list):
                        content = " ".join(
                            (c.get("text", "") if isinstance(c, dict) else str(c))
                            for c in content
                        )
                    is_error = block.get("is_error", False)
                    tag = "tool_result_error" if is_error else "tool_result"
                    gen.log.info("[claude:%s] %s", tag, str(content)[:600])
        return

    if evt_type == "result":
        gen.log.info(
            "[claude:result] success=%s duration_ms=%s num_turns=%s total_cost_usd=%s",
            evt.get("subtype") == "success",
            evt.get("duration_ms"),
            evt.get("num_turns"),
            evt.get("total_cost_usd"),
        )
        return

    gen.log.info("[claude:%s] %s", evt_type, line[:600])


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

@gen.run(name="Claude Code")
def main():
    settings = gen.config.read_schema_values("settings.set_yaml")
    import docker
    import docker.errors

    mount_host_claude = bool(settings.get("mount_host_claude", True))
    include_assistant = bool(settings.get("include_assistant_history", True))

    try:
        client = docker.from_env()
        client.ping()
    except docker.errors.DockerException as e:
        raise Exception(
            f"Cannot connect to Docker: {e}. Make sure Docker is running."
        )

    try:
        client.images.get(VSCODE_IMAGE)
    except docker.errors.ImageNotFound:
        raise Exception(
            f"Docker image '{VSCODE_IMAGE}' not found. Run the 'VS Code "
            f"Docker' generator once to build it (or rebuild it after the "
            f"recent Dockerfile change that added the claude CLI), then "
            f"retry."
        )

    prompt = _build_prompt(include_assistant)
    gen.log.info(
        "[claude] prompt is %d chars across %d message(s); include_assistant_history=%s",
        len(prompt), len(gen.chat.history), include_assistant,
    )

    work_host = tempfile.mkdtemp(prefix="collimate-claude-work-")
    try:
        gen.status = "Copying input files into Claude's working directory..."
        n_copied = _copy_workspace_into(work_host)
        _chmod_world_writable(work_host)
        gen.log.info("[claude] copied %d input file(s) into %s", n_copied, work_host)

        volumes: dict = {
            work_host: {"bind": "/home/coder/output", "mode": "rw"},
        }
        if mount_host_claude:
            host_claude = os.path.expanduser("~/.claude")
            if os.path.isdir(host_claude):
                volumes[host_claude] = {"bind": "/home/coder/.claude", "mode": "rw"}
                gen.log.info("[claude] mounting host ~/.claude into container")
            else:
                gen.log.warning(
                    "mount_host_claude is on but %s does not exist; "
                    "container will start unauthenticated", host_claude
                )

        container_name = f"collimate-claude-{uuid.uuid4().hex[:8]}"
        gen.status = "Starting Claude Code container..."
        gen.log.info("[claude] launching container %s", container_name)
        container = client.containers.run(
            VSCODE_IMAGE,
            entrypoint=["claude"],
            command=[
                "-p", prompt,
                "--output-format", "stream-json",
                "--verbose",
                "--dangerously-skip-permissions",
            ],
            working_dir="/home/coder/output",
            volumes=volumes,
            name=container_name,
            detach=True,
            stdout=True,
            stderr=True,
        )

        try:
            gen.status = "Claude Code is running..."
            buf = b""
            for chunk in container.logs(stream=True, follow=True, stdout=True, stderr=True):
                buf += chunk
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    _log_event(line.decode("utf-8", errors="replace"))
            if buf:
                _log_event(buf.decode("utf-8", errors="replace"))

            result = container.wait()
            exit_code = result.get("StatusCode", 0) if isinstance(result, dict) else 0
            gen.log.info("[claude] container exited with code %s", exit_code)
            if exit_code != 0:
                raise Exception(
                    f"Claude Code container exited non-zero ({exit_code}). "
                    f"See run log above for details."
                )
        finally:
            try:
                container.remove(force=True)
            except docker.errors.NotFound:
                pass
            except Exception as e:
                gen.log.warning("Failed to remove container %s: %s", container_name, e)

        gen.status = "Committing final file state to cell..."
        n_committed = _commit_files_from(work_host)
        gen.log.info("[claude] committed %d total file(s)", n_committed)

        if _assistant_text:
            response_text = "\n\n".join(_assistant_text).strip()
        else:
            response_text = "(Claude returned no text response — see run log for tool calls.)"
        gen.chat.append(role="assistant", content=response_text)

        gen.status = f"Done — {n_committed} file(s), {len(_assistant_text)} reply block(s)."

        gen.update_cell(
            name="Claude Code",
            summary=f"Claude edited {n_committed} file(s) across {len(gen.chat.history)} message(s).",
        )

    finally:
        shutil.rmtree(work_host, ignore_errors=True)


if __name__ == "__main__":
    main()
