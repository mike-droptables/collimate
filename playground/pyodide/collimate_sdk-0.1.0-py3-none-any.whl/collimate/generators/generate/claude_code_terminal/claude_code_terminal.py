# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Claude Code Terminal — attach a live Claude TTY to a cell.

Holds the cell run open (wait_until_stopped) so the shared
claude_code_session container's refcount stays up for the duration of
the terminal session.
"""

from __future__ import annotations

import json
import shlex

from collimate.sdk import Generator

gen = Generator()


@gen.run(name="Claude Code Terminal")
def main() -> None:
    settings = gen.config.read_schema_values("settings.set_yaml")
    model = settings.get("model", "sonnet")
    system_prompt = settings.get("system_prompt", "") or ""
    extra_args = settings.get("extra_args", "") or ""

    gen.update_cell(name="Claude Terminal", summary="Starting...")

    gen.status = "Opening session container..."
    session = gen.chat.start_session(
        image="collimate-chat-worker",
        dockerfile_dir=gen.shared("chat/claude_code_chat"),
        shared=True,
        backend="claude_code_session",
        model=model,
        system_prompt=system_prompt,
    )
    container_id = session.get("container_id", "")
    if not container_id:
        raise RuntimeError("chat.start_session did not return a container_id")

    command = ["claude"]
    if extra_args.strip():
        command += shlex.split(extra_args)

    gen.status = "Registering terminal session..."
    term = gen.start_terminal(
        container_id=container_id,
        command=command,
        cwd="/home/coder/project",
        env={"TERM": "xterm-256color"},
    )

    try:
        gen.fs.write("claude.terminal", json.dumps({
            **term,
            "label": f"Claude Code · {model}",
        }, indent=2))
        gen.update_cell(
            name="Claude Terminal",
            summary=f"live · {model}",
        )
        gen.status = "Terminal ready — open the cell to attach."
        gen.wait_until_stopped()
    finally:
        gen.stop_terminal(term.get("session_id", ""))


main()
