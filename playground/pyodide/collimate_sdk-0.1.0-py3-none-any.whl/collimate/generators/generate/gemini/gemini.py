# /// script
# dependencies = ["google-genai", "pyyaml"]
# ///
"""
Gemini Generator — calls Google Gemini using the pristine SDK.
"""

import os
from google import genai
from collimate.sdk import Generator

gen = Generator()

@gen.run(name="Gemini")
def main():
    settings = gen.config.read_schema_values("settings.set_yaml")
    api_key = settings.get("api_key") or gen.params.get("api_key") or os.environ.get("GEMINI_API_KEY", "")
    if not api_key:
        raise Exception("GEMINI_API_KEY not set. Provide it in Settings or environment.")

    if not gen.chat.history:
        raise Exception("No input messages found. Please type a prompt.")

    model_id = settings.get("model") or gen.params.get("model", "gemini-2.0-flash")
    gen.status = f"Calling {model_id}..."

    # Build prompt from message history
    parts = []
    for m in gen.chat.history:
        parts.append(f"[{m.role.upper()}]\n{m.content}")
    prompt = "\n\n".join(parts)

    client = genai.Client(api_key=api_key)
    response = client.models.generate_content(model=model_id, contents=prompt)
    reply = response.text

    gen.fs.write("response.md", reply)
    gen.chat.append(role="assistant", content=reply)
    gen.update_cell(name="Gemini", summary=f"{model_id} response")

if __name__ == "__main__":
    main()
