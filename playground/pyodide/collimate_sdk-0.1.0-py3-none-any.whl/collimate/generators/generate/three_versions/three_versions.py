# /// script
# dependencies = ["google-genai", "pyyaml"]
# ///
"""
Three Versions Generator — generates 3 parallel stylistic variations via Gemini.
"""

import concurrent.futures
import json
import os
import re
from google import genai
from google.genai import types
from collimate.sdk import Generator

gen = Generator()


def parse_llm_response(text):
    files = []
    messages = []
    file_pattern = re.compile(r"--- START FILE: (.+?) ---\n(.*?)--- END FILE: \1 ---", re.DOTALL)
    msg_pattern = re.compile(r"--- START MESSAGE: (.+?) ---\n(.*?)--- END MESSAGE ---", re.DOTALL)

    for match in file_pattern.finditer(text):
        files.append({"name": match.group(1).strip(), "content": match.group(2)})

    for match in msg_pattern.finditer(text):
        role = match.group(1).strip().lower()
        if role not in ("user", "assistant", "system"): role = "assistant"
        messages.append({"role": role, "content": match.group(2).strip()})

    return files, messages


def generate_styles(client, model_id, context_str):
    style_prompt = """Determine 3 distinct, valid visual approaches to solve the problem.
Return STRICTLY a JSON list of 3 strings. Return ONLY the JSON string."""
    try:
        response = client.models.generate_content(
            model=model_id, contents=context_str,
            config=types.GenerateContentConfig(system_instruction=style_prompt, temperature=0.7, response_mime_type="application/json")
        )
        styles = json.loads(response.text)
        if isinstance(styles, list) and len(styles) >= 3:
            return styles[:3]
    except Exception:
        pass
    return ["Standard Implementation", "Object-Oriented", "Concise"]


def run_variant(client, model_id, system_prompt, base_context, style_name):
    variant_prompt = f"{base_context}\n\n--- SYSTEM INSTRUCTION ---\nImplement using:\n**{style_name}**"
    try:
        response = client.models.generate_content(
            model=model_id, contents=variant_prompt,
            config=types.GenerateContentConfig(system_instruction=system_prompt, temperature=0.7)
        )
        return style_name, response.text
    except Exception as e:
        return style_name, f"ERROR: {e}"


@gen.run(name="Three Versions")
def main():
    settings = gen.config.read_schema_values("settings.set_yaml")
    api_key = settings.get("api_key") or gen.params.get("api_key") or os.environ.get("GEMINI_API_KEY", "")
    if not api_key: raise Exception("GEMINI_API_KEY not set.")

    model_id = settings.get("model") or gen.params.get("model", "gemini-3-flash-preview")

    # Read workspace context easily
    context_parts = []
    for rel_path in gen.fs.list():
        context_parts.append(f"--- FILE: {rel_path} ---\n{gen.fs.read(rel_path)}")

    msg_parts = [f"[{m.role.upper()}]\n{m.content}" for m in gen.chat.history]
    full_context = "\n\n".join(context_parts + msg_parts)

    gen.status = "Analyzing context for approaches..."
    client = genai.Client(api_key=api_key)
    styles = generate_styles(client, model_id, full_context)
    gen.progress(0, len(styles))

    # Safely construct the prompt to avoid triggering the LLM output parser
    dashes = "-" * 3
    code_system_prompt = (
        "You are a coding assistant.\n"
        "To write a file:\n"
        f"{dashes} START FILE: filename {dashes}\n"
        "contents\n"
        f"{dashes} END FILE: filename {dashes}\n\n"
        "To write a message:\n"
        f"{dashes} START MESSAGE: role {dashes}\n"
        "message\n"
        f"{dashes} END MESSAGE {dashes}\n"
    )

    gen.status = "Starting parallel generations..."
    completed = 0
    is_first = True

    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        futures = {executor.submit(run_variant, client, model_id, code_system_prompt, full_context, s): s for s in styles}

        for future in concurrent.futures.as_completed(futures):
            style_name = futures[future]
            style_name, raw_text = future.result()

            if raw_text.startswith("ERROR:"):
                gen.log.warning(f"Failed {style_name}: {raw_text}")
                continue

            files, file_messages = parse_llm_response(raw_text)
            if not files and not file_messages:
                file_messages.append({"role": "assistant", "content": raw_text})

            # Use gen.fs and gen.chat to queue up the cell
            for file_info in files:
                gen.fs.write(file_info["name"], file_info["content"])
            for m in file_messages:
                gen.chat.append(role=m["role"], content=m["content"])

            short_style = " ".join(style_name.split()[:3])

            if is_first:
                gen.update_cell(
                    name=f"Gemini: {short_style}",
                    summary=f"Approach: {style_name}",
                    metadata={"style": style_name},
                )
                is_first = False
            else:
                gen.create_cell(
                    name=f"Gemini: {short_style}",
                    summary=f"Approach: {style_name}",
                    metadata={"style": style_name},
                )

            completed += 1
            gen.progress(completed, len(styles))

if __name__ == "__main__":
    main()
