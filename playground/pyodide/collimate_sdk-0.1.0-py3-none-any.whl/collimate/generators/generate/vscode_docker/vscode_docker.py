# /// script
# dependencies = ["docker", "pyyaml"]
# ///
"""
VS Code Docker Generator — opens the contents of the input cell in VS Code
Server inside a Docker container.

The input cell's files are already hydrated into `gen.workspace` by the
backend (with `.colreserved/` filtered out). This generator bind-mounts that
workspace into the container, the entrypoint copies it into the code-server
project directory, and code-server opens that directory as the workspace.

Settings keys (declared in settings.set_yaml, read via gen.config.read_schema_values):
  startup_commands         - list of shell commands to run inside the
                             container after files are copied
  git_user_name            - git author name
  git_user_email           - git author email
  use_keystore_git_creds   - if true, pass githubuser/githubpassword from
                             the host keystore into the container
  git_init                 - if true, overlay a fresh upstream history
  git_init_repo_url        - the upstream URL to clone for git_init
  mount_host_claude        - if true, bind-mount ~/.claude into the container
"""

import io
import json
import os
import socket
import tarfile
import time
import urllib.request
import uuid

import docker
import docker.errors

from collimate.sdk import Generator

gen = Generator()


def _find_free_port(start: int = 8080) -> int:
    port = start
    while port < 9000:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                port += 1
    raise RuntimeError("No free port found in range 8080-8999")


def _wait_for_ready(port: int, timeout: int = 120) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=2)
            return True
        except Exception:
            time.sleep(2)
    return False


_CAPTURE_MAX_FILE_BYTES = 1_000_000


def _extract_text_from_content(content) -> str:
    """Claude transcript content may be a plain string or a list of blocks
    (text / tool_use / tool_result). Flatten text blocks only; ignore the
    rest so the captured chat stays human-readable."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                t = block.get("text") or ""
                if t:
                    parts.append(t)
        return "\n".join(parts)
    return ""


def _capture_claude_transcript(container) -> tuple[list[dict], str | None]:
    """Find the most recent Claude Code session transcript inside the
    container and return (parsed_messages, raw_jsonl).

    parsed_messages is a list of {"role", "content"} dicts — only entries
    with extractable text from user/assistant messages are kept. raw_jsonl
    is the full transcript bytes as a decoded string, preserved so the
    caller can archive it as an artifact.
    """
    ls = container.exec_run(
        ["bash", "-lc", "ls -t /home/coder/.claude/projects/*/*.jsonl 2>/dev/null | head -1"]
    )
    if ls.exit_code != 0:
        return [], None
    latest = ls.output.decode("utf-8", errors="replace").strip()
    if not latest:
        return [], None

    cat = container.exec_run(["cat", latest])
    if cat.exit_code != 0:
        return [], None
    raw = cat.output.decode("utf-8", errors="replace")

    messages: list[dict] = []
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue
        if entry.get("type") not in ("user", "assistant"):
            continue
        msg = entry.get("message") or {}
        role = msg.get("role") or entry.get("type")
        text = _extract_text_from_content(msg.get("content"))
        if not text:
            continue
        messages.append({"role": role, "content": text})
    return messages, raw


def _pull_container_files(container, project_dir: str) -> list[tuple[str, str]]:
    """Pull text files out of ``project_dir`` inside the container.

    If the directory is a git checkout, honour .gitignore via
    ``git ls-files --cached --others --exclude-standard``; otherwise take
    every file (still skipping ``.git/`` and binary/oversized files).

    Returns a list of ``(relpath, text_content)`` tuples.
    """
    allowed: set[str] | None = None
    git_check = container.exec_run(["test", "-d", os.path.join(project_dir, ".git")])
    if git_check.exit_code == 0:
        ls = container.exec_run(
            ["git", "-C", project_dir, "ls-files", "--cached", "--others", "--exclude-standard"]
        )
        if ls.exit_code == 0:
            raw = ls.output.decode("utf-8", errors="replace")
            allowed = {line for line in raw.splitlines() if line.strip()}

    bits, _ = container.get_archive(project_dir)
    buf = io.BytesIO()
    for chunk in bits:
        buf.write(chunk)
    buf.seek(0)

    out: list[tuple[str, str]] = []
    with tarfile.open(fileobj=buf, mode="r") as tar:
        for member in tar.getmembers():
            if not member.isfile():
                continue
            parts = member.name.split("/", 1)
            if len(parts) < 2:
                continue
            rel = parts[1]
            if rel == ".git" or rel.startswith(".git/"):
                continue
            if allowed is not None and rel not in allowed:
                continue
            if member.size > _CAPTURE_MAX_FILE_BYTES:
                continue
            f = tar.extractfile(member)
            if f is None:
                continue
            data = f.read()
            try:
                text = data.decode("utf-8")
            except UnicodeDecodeError:
                continue
            out.append((rel, text))
    return out


def _capture_session(container, project_dir: str) -> None:
    """Handle a ``capture_session`` renderer action: read the Claude
    transcript + workspace files out of the container, populate gen.chat
    and gen.fs, and create a new side-cell."""
    gen.status = "Capturing VS Code session..."
    messages, raw_jsonl = _capture_claude_transcript(container)
    for m in messages:
        gen.chat.append(role=m["role"], content=m["content"])

    if raw_jsonl:
        gen.fs.write("claude_session.jsonl", raw_jsonl)

    files = _pull_container_files(container, project_dir)
    for rel, text in files:
        # Don't clobber the capture transcript with a repo file of the
        # same name — extremely unlikely, but cheap to guard.
        if rel == "claude_session.jsonl":
            continue
        gen.fs.write(rel, text)

    cell_id = gen.create_cell(
        name="VS Code session capture",
        summary=f"{len(messages)} messages, {len(files)} files",
    )
    gen.log.info("Captured session into cell %s (%d messages, %d files)",
                 cell_id, len(messages), len(files))
    gen.status = "VS Code Server is running."


def _relax_workspace_perms(root: str) -> None:
    """tempfile.mkdtemp creates 0700 dirs by default, which the container's
    coder user can't traverse. Open it up just enough for read access."""
    try:
        os.chmod(root, 0o755)
        for dirpath, dirnames, filenames in os.walk(root):
            for d in dirnames:
                try:
                    os.chmod(os.path.join(dirpath, d), 0o755)
                except OSError:
                    pass
            for f in filenames:
                try:
                    os.chmod(os.path.join(dirpath, f), 0o644)
                except OSError:
                    pass
    except OSError as e:
        gen.log.warning("Could not relax workspace permissions: %s", e)


@gen.run(name="VS Code Docker")
def main():
    settings = gen.config.read_schema_values("settings.set_yaml")
    # 1. Load settings
    startup_commands = settings.get("startup_commands") or []
    git_user_name = (settings.get("git_user_name") or "").strip()
    git_user_email = (settings.get("git_user_email") or "").strip()
    use_keystore_git_creds = bool(settings.get("use_keystore_git_creds", True))
    mount_host_claude = bool(settings.get("mount_host_claude", True))
    git_init = bool(settings.get("git_init", False))
    git_init_repo_url = (settings.get("git_init_repo_url") or "").strip()

    if startup_commands and not isinstance(startup_commands, list):
        raise RuntimeError("startup_commands must be a list of strings")

    if git_init and not git_init_repo_url:
        raise RuntimeError(
            "git_init is on but git_init_repo_url is empty — set the upstream "
            "repo URL in the generator's settings form so the container has "
            "something to clone for history."
        )

    # 2. Connect to Docker daemon
    try:
        client = docker.from_env()
        client.ping()
    except docker.errors.DockerException as e:
        raise RuntimeError(
            f"Cannot connect to Docker: {e}. "
            "Please ensure Docker is running and retry."
        )

    # 3. Find a free port
    port = _find_free_port(8080)
    gen.log.info("Using port %d", port)

    # 4. Build image if not already present
    image_tag = "collimate-vscode:latest"
    app_dir = os.path.dirname(os.path.abspath(__file__))
    try:
        client.images.get(image_tag)
    except docker.errors.ImageNotFound:
        gen.status = "Building Docker image (first run only, may take a few minutes)..."
        gen.log.info(
            "Building Docker image %s from %s — first run, may take a few minutes...",
            image_tag, app_dir,
        )
        build_started = time.monotonic()
        layer_status: dict[str, str] = {}
        image_id: str | None = None
        try:
            _, build_logs = client.images.build(path=app_dir, tag=image_tag, rm=True)
            for chunk in build_logs:
                if chunk.get("error"):
                    detail = chunk.get("errorDetail", {}).get("message") or chunk["error"]
                    gen.log.error("Docker build error: %s", detail)
                    raise RuntimeError(f"Docker build failed: {detail}")
                line = (chunk.get("stream") or "").rstrip()
                if line:
                    gen.log.info(line)
                    # Surface "Step N/M : ..." headers as live status so the
                    # user sees progress without scrolling the log.
                    if line.startswith("Step "):
                        gen.status = f"Building Docker image — {line.split(':', 1)[0].strip()}"
                    continue
                # Layer pull / extract progress from the FROM line. Only log
                # when a layer's status text changes, so we don't spam the log
                # with per-byte download ticks.
                status = chunk.get("status")
                lid = chunk.get("id")
                if status and lid:
                    if layer_status.get(lid) != status:
                        layer_status[lid] = status
                        gen.log.info("[layer %s] %s", lid, status)
                elif status:
                    gen.log.info(status)
                aux_id = (chunk.get("aux") or {}).get("ID")
                if aux_id:
                    image_id = aux_id
        except docker.errors.BuildError as e:
            gen.log.error("Docker build failed: %s", e)
            raise
        elapsed = time.monotonic() - build_started
        gen.log.info(
            "Docker image %s built in %.1fs%s",
            image_tag, elapsed, f" ({image_id})" if image_id else "",
        )
        gen.status = "Docker image built."

    # 5. Make the workspace readable by the container's coder user.
    _relax_workspace_perms(gen.workspace)

    # Guard: refuse to start if there are no project files. The most common
    # cause is running this generator on a cell that hasn't been populated
    # by a previous generator (typically git_clone). The .colreserved/ dir
    # and any files this generator may write don't count.
    project_files = []
    for dirpath, dirnames, filenames in os.walk(gen.workspace):
        rel_dir = os.path.relpath(dirpath, gen.workspace)
        if rel_dir == ".colreserved" or rel_dir.startswith(".colreserved" + os.sep):
            continue
        for fn in filenames:
            project_files.append(os.path.join(rel_dir, fn))
    if not project_files:
        raise RuntimeError(
            "Input cell is empty — vscode_docker needs project files to open. "
            "Run a generator that produces files (e.g. git_clone) first, then "
            "run this generator on its output cell."
        )
    gen.log.info("Workspace has %d project file(s); first few: %s",
                 len(project_files), project_files[:5])

    # 6. Build the env and volume map for the container.
    env: dict[str, str] = {"PORT": str(port)}

    if git_user_name:
        env["GIT_USER_NAME"] = git_user_name
    if git_user_email:
        env["GIT_USER_EMAIL"] = git_user_email

    if use_keystore_git_creds:
        gh_user = os.environ.get("githubuser", "")
        gh_pw = os.environ.get("githubpassword", "")
        if gh_user and gh_pw:
            env["GITHUB_USER"] = gh_user
            env["GITHUB_PASSWORD"] = gh_pw
            gen.log.info("Passing keystore git credentials into container")
        else:
            gen.log.warning(
                "use_keystore_git_creds=true but githubuser/githubpassword "
                "are not set in the host environment — git tab will be "
                "anonymous (run `gh auth login` in the terminal to fix)"
            )

    if startup_commands:
        env["STARTUP_COMMANDS"] = json.dumps(startup_commands)

    if git_init:
        env["GIT_INIT_REPO_URL"] = git_init_repo_url

    volumes: dict = {
        gen.workspace: {"bind": "/workspace", "mode": "ro"},
    }

    if mount_host_claude:
        host_claude = os.path.expanduser("~/.claude")
        if os.path.isdir(host_claude):
            volumes[host_claude] = {"bind": "/home/coder/.claude", "mode": "rw"}
            gen.log.info("Mounting host ~/.claude into container")
        else:
            gen.log.warning(
                "mount_host_claude=true but %s does not exist — Claude Code "
                "will start unauthenticated", host_claude
            )

    # 7. Start the container
    container_name = f"collimate-vscode-{uuid.uuid4().hex[:8]}"
    run_id_env = os.environ.get("COLLIMATE_RUN_ID", "")
    gen.status = f"Starting container {container_name}..."
    container = client.containers.run(
        image_tag,
        detach=True,
        name=container_name,
        ports={f"{port}/tcp": ("127.0.0.1", port)},
        volumes=volumes,
        environment=env,
        labels={
            "com.collimate.run_id": run_id_env,
            "com.collimate.kind": "vscode_docker",
        },
    )
    project_dir = "/home/coder/project"

    try:
        # 8. Poll until code-server is ready
        gen.status = "Waiting for VS Code Server to start..."
        if not _wait_for_ready(port, timeout=120):
            raise RuntimeError("VS Code Server did not become ready within 120 seconds.")

        # 9. Announce the live port so the UI can open an iframe immediately.
        # `path` is appended to the proxy URL the iframe loads — we use the
        # `?command=` query string to ask the workbench to focus the Claude
        # Code chat view on first paint, so the user lands on Claude with
        # no stale editor tabs.
        # `snapshot_source` enables the Snapshot / Snapshot & Stop buttons
        # above the iframe — the backend uses these fields to pull the
        # user's edits out of the running container on demand.
        iframe_path = "?command=claude-code.chat.focus"
        gen.serve_port(
            port,
            name="VS Code",
            path=iframe_path,
            snapshot_source={
                "container_name": container_name,
                "project_dir": project_dir,
            },
        )

        # 10. Write the summary .website file and commit it implicitly.
        channel = os.environ.get("COLLIMATE_CHANNEL", "")
        run_id = os.environ.get("COLLIMATE_RUN_ID", "")
        proxy_url = f"/proxy/{channel}/{run_id}/{port}/{iframe_path}"
        # JSON form of the .website artifact adds a top-bar button to the
        # renderer. Clicks arrive via gen.wait_for_action() below.
        gen.fs.write(
            "vscode-server.website",
            json.dumps({
                "url": proxy_url,
                "buttons": [
                    {"id": "capture_session", "label": "Capture Session"},
                ],
            }),
        )

        gen.update_cell(
            name="VS Code Dev Environment",
            summary=f"VS Code Server running on port {port}",
        )

        gen.status = "VS Code Server is running."

        # 11. Stream container logs (entrypoint + startup commands +
        # code-server output) into the run log so the user can see what's
        # happening inside the container.
        def _tail_logs():
            try:
                for chunk in container.logs(stream=True, follow=True):
                    line = chunk.decode("utf-8", errors="replace").rstrip()
                    if line:
                        gen.log.info("[container] %s", line)
            except Exception as e:
                gen.log.debug("log tail ended: %s", e)

        import threading
        threading.Thread(target=_tail_logs, daemon=True).start()

        # 12. Loop until Stop, handling top-bar button actions from the
        # .website renderer. wait_for_action returns None on Stop or when
        # the poll times out — in either case we just re-check and keep
        # going (or exit the outer loop once stop_requested() flips).
        while not gen.stop_requested():
            action = gen.wait_for_action(timeout=1.0)
            if action == "capture_session":
                try:
                    _capture_session(container, project_dir)
                except Exception as e:
                    gen.log.exception("capture_session failed: %s", e)
                    gen.status = f"Capture failed: {e}"
            elif action:
                gen.log.warning("Unknown renderer action: %s", action)
        # Stop requested — preserve the "gracefully stopped" finish path.
        raise gen.StopSignal()

    finally:
        # 13. Always clean up the container on exit. Use a short stop
        # timeout because code-server is stateless — there's nothing to
        # gracefully save, so SIGKILL after 2s is fine. The API supervisor
        # gives the generator process ~15s after sending SIGTERM before it
        # SIGKILLs us, so the container cleanup must fit comfortably inside
        # that budget or we'll leak containers on stop.
        gen.log.info("Stopping container %s...", container_name)
        try:
            container.stop(timeout=2)
            container.remove(force=True)
            gen.log.info("Container removed.")
        except docker.errors.NotFound:
            gen.log.info("Container already gone.")
        except Exception as e:
            # Last-ditch: try a force remove without going through stop
            gen.log.warning("container.stop failed (%s); force removing", e)
            try:
                container.remove(force=True)
            except Exception as e2:
                gen.log.error("Failed to remove container %s: %s", container_name, e2)


if __name__ == "__main__":
    main()
