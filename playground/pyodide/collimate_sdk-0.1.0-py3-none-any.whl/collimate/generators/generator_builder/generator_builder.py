# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic-ai"]
# ///
"""Generator Builder — pydantic-ai scaffold of a new generator.

Reads the ``how-to-write-a-generator.md`` guide from the cell-local
``_shared_docs/`` sibling (seeded into the Builder cell from the SDK's
``shared/docs/``) via ``collimate.shared.shared_doc`` and passes it as the
system prompt. The
agent uses ``write_file`` tool calls to emit files into a staging dict;
after the run, each staged file is written to the output cell.

Input files (if any) are exposed as read-only guidance via
``read_guidance`` and are explicitly dropped from the output cell —
only files the agent writes survive.

After the agent finishes, the staged ``manifest.gen_yaml`` is linted via
``collimate.lint.lint_generator_manifest_data`` and (optionally) the
candidate is dry-run. The agent gets one retry with any errors fed back.
If problems persist, the scaffold is still committed — the agent's work
is never discarded — but the guidance files are preserved and the cell
summary states plainly that validation failed and lists the unresolved
problems, so it is unmistakably not ready to use.
"""
from __future__ import annotations

import yaml
from collimate.lint import Level, lint_generator_manifest_data
from collimate.shared import shared_doc
import gen


async def run() -> None:
    cfg = gen.config("pydantic-config.set_yaml")
    provider = (cfg.get("provider") or "anthropic").strip().lower()
    model = (cfg.get("model") or "claude-sonnet-4-6").strip()
    max_tokens = _int(cfg.get("max_tokens"), default=8192)
    prompt = (gen.prompt or "").strip()
    if not prompt:
        raise Exception("Describe the generator you want to build in the picker prompt.")

    try:
        guide = shared_doc(
            "how-to-write-a-generator.md", near=__file__
        ).read_text(encoding="utf-8")
    except FileNotFoundError as e:
        raise Exception(
            "Reference guide 'how-to-write-a-generator.md' was not seeded "
            f"into this cell's _shared_docs/. Details: {e}"
        )

    # Guidance is the input cell's files; surface them as a tool, not a carry-through.
    guidance = {p: gen.read_file(p) for p in gen.list_files()}
    stage: dict[str, str] = {}

    from pydantic_ai import Tool

    async def list_guidance() -> list[str]:
        """List any reference files attached via the input cell. These
        are for reading only — do NOT copy them into the output."""
        return sorted(guidance.keys())

    async def read_guidance(path: str) -> str:
        """Read a guidance file attached via the input cell."""
        return guidance.get(path, f"ERROR: file not found: {path}")

    async def write_file(path: str, content: str) -> str:
        """Write a file into the new scaffold. Path is relative to the
        new cell root (e.g. ``manifest.gen_yaml``, ``my_gen.py``)."""
        stage[path] = content
        return f"wrote {len(content)} bytes to {path}"

    async def list_written() -> list[str]:
        """List what you've written so far."""
        return sorted(stage.keys())

    required = (
        "Required files for a generator:\n"
        "  - manifest.gen_yaml (MUST declare a `type` — a list of 1-2 of "
        "{\"modify\", \"create\"}: `modify` rewrites the current cell, "
        "`create` produces fresh cells with the input shape set by "
        "`inputs.cells`; do NOT add a `runtime:` field — runtime is "
        "determined by the folder the generator lives in, and `runtime` is "
        "an unknown manifest field that lints as a warning)\n"
        "  - <id>.py  (the entrypoint; filename must match 'entrypoint' in the manifest)\n"
        "  - settings.set_yaml or any other draft files if the manifest declares them\n"
    )

    system_prompt = (
        "You are scaffolding a complete, working Collimate generator from a "
        "user description. Follow the reference guide below exactly — it is "
        "the authoritative spec for the manifest schema, the SDK API, and "
        "the file layout.\n\n"
        f"{required}\n"
        "Use the write_file tool to emit every file in full. Do not "
        "abbreviate, do not use placeholders. When you're done, stop — do "
        "not describe the files in prose.\n\n"
        f"--- BEGIN REFERENCE GUIDE ---\n{guide}\n--- END REFERENCE GUIDE ---\n"
    )

    gen.status(f"Scaffolding generator with {provider} · {model}…")
    gen.log(f"[generator-builder] {provider} · {model} · guide={len(guide)} chars")

    tools = [
        Tool(list_guidance),
        Tool(read_guidance),
        Tool(write_file),
        Tool(list_written),
        # Python execution: lets the agent sanity-check or generate
        # auxiliary content (test the scaffolded entrypoint, render a
        # diagram, exercise an example) before claiming done.
        gen.python_tool(),
    ]
    user_msg = (
        f"Build a generator that does the following:\n\n{prompt}\n\n"
        "Write every required file via write_file. Do not write README.md "
        "or any extra files — only the files the generator needs to run."
    )

    agent = await gen.agent(
        system_prompt=system_prompt,
        tools=tools,
        provider=provider,
        model=model,
        max_tokens=max_tokens,
    )
    await agent.run(user_msg)  # auto-retries on auth failure

    if not stage:
        raise Exception("The agent returned without writing any files.")

    # Validate the agent's manifest. One retry with errors fed back. If
    # problems persist we still COMMIT the scaffold (never discard the
    # agent's work) but mark it clearly as failed-validation — see _commit.
    errors = _lint_stage(stage)
    if errors:
        gen.log(f"[generator-builder] lint errors after first agent run: {len(errors)}")
        await agent.run(_fix_prompt(errors))
        errors = _lint_stage(stage)
    if errors:
        gen.log(f"[generator-builder] committing scaffold that failed lint: {len(errors)} error(s)")
        await _commit(stage, guidance, provider=provider, errors=errors)
        return

    # Functional dry-run gate: actually RUN the candidate as an inline
    # sub-run and feed any failure back for one retry. Host-backed via
    # gen.spawn/gen.call — degrades to a no-op (manifest-lint-only) when no
    # host is available (CI/dev). This is a public capability, not a
    # builder-private power.
    if cfg.get("validate_run", True):
        run_err = await _validate_run(stage)
        if run_err:
            gen.log(f"[generator-builder] candidate failed its dry-run: {run_err[:200]}")
            await agent.run(_run_fix_prompt(run_err))
            errors = _lint_stage(stage)
            if errors:
                gen.log("[generator-builder] committing scaffold (lint failed after dry-run fix)")
                await _commit(stage, guidance, provider=provider, errors=errors)
                return
            run_err = await _validate_run(stage)
            if run_err:
                gen.log("[generator-builder] committing scaffold (dry-run still failing)")
                await _commit(stage, guidance, provider=provider, errors=[run_err])
                return

    await _commit(stage, guidance, provider=provider)


async def _commit(stage: dict[str, str], guidance: dict, *, provider: str,
                  errors: list[str] | None = None) -> None:
    """Write the staged scaffold into the output cell.

    Clean build (no errors): drop the read-only guidance files and name the
    cell normally. Failed validation: still commit the agent's work — it is
    never discarded — but PRESERVE the guidance files (so the user can retry)
    and make the summary say plainly that validation failed, listing the
    unresolved problems, so the cell is unmistakably not ready to use.
    """
    entry = (
        "manifest.gen_yaml" if "manifest.gen_yaml" in stage
        else ("manifest.rend_yaml" if "manifest.rend_yaml" in stage else sorted(stage)[0])
    )
    if not errors:
        # Drop guidance files — they were read-only context — then commit.
        for guidance_path in guidance:
            gen.delete_file(guidance_path)
        for path, content in stage.items():
            gen.update_file(path, content)
        await gen.update(
            name=f"generator scaffold · {provider}",
            summary=f"{len(stage)} file(s) · entry: `{entry}`",
            pinned=entry,
        )
        return
    # Failed validation: keep the work AND the guidance, but say so loudly.
    for path, content in stage.items():
        gen.update_file(path, content)
    bullets = "\n".join(f"- {e}" for e in errors)
    await gen.update(
        name=f"generator scaffold (failed validation) · {provider}",
        summary=(
            "This scaffold did NOT pass validation and is not ready to use. "
            "The agent's work was kept so you can fix it by hand or re-run. "
            f"Unresolved problems:\n{bullets}"
        ),
        pinned=entry,
    )


def _lint_stage(stage: dict[str, str]) -> list[str]:
    """Lint the staged ``manifest.gen_yaml`` against the native runtime
    contract. Returns a list of human-readable error strings (empty when
    valid). Warnings are not surfaced — only hard errors block commit.
    """
    if "manifest.gen_yaml" not in stage:
        return ["manifest.gen_yaml was not written"]
    try:
        data = yaml.safe_load(stage["manifest.gen_yaml"])
    except yaml.YAMLError as e:
        return [f"manifest.gen_yaml is not valid YAML: {e}"]
    issues = lint_generator_manifest_data(
        data if isinstance(data, dict) else {},
        files_present=set(stage.keys()),
        file_contents=stage,
    )
    return [
        f"{i.field or '<root>'}: {i.message}"
        for i in issues
        if i.level == Level.ERROR
    ]


def _manifest_data(stage: dict) -> dict:
    try:
        data = yaml.safe_load(stage.get("manifest.gen_yaml", "")) or {}
    except yaml.YAMLError:
        data = {}
    return data if isinstance(data, dict) else {}


async def _validate_run(stage: dict):
    """Run the staged candidate as an inline sub-run. Returns an error string
    only on a genuine candidate run-failure; returns None when it ran cleanly,
    when no host is available, or on a transient host/capability error
    (degrade to manifest-lint-only rather than blame the candidate)."""
    data = _manifest_data(stage)
    entry = data.get("entrypoint")
    if not isinstance(entry, str) or entry not in stage:
        return None  # entrypoint presence is the linter's job; nothing to run
    types = data.get("type") if isinstance(data.get("type"), list) else []
    invocation = next((t for t in ("modify", "create") if t in types), "create")
    is_daemon = bool(data.get("daemon")) or bool(data.get("chat"))

    # Input-aware: a generator that requires input cells must get some, or the
    # smoke run fails for the wrong reason (no inputs) and the LLM is pushed to
    # "fix" a correct scaffold. Synthesize placeholder inputs to satisfy the
    # declared minimum. 'modify' always rewrites exactly one cell, so force a
    # single input even when bounds are absent; 'create' honours its declared
    # min (a no-input create legitimately takes 0).
    cells = (data.get("inputs") or {}).get("cells") or {}
    try:
        min_cells = int(cells.get("min", 0) or 0)
    except (TypeError, ValueError):
        min_cells = 0
    if min_cells == 0 and "modify" in types:
        min_cells = 1
    spawn_kw = {}
    if min_cells >= 1:
        spawn_kw["input_groups"] = {
            f"{i:02d}_smoke": {"input.txt": "smoke-test input"} for i in range(min_cells)
        }

    src = gen.inline(stage, entrypoint=entry)
    try:
        # Use spawn+wait (not gen.call) so an empty sub_run_id is the
        # unambiguous "no host" degrade signal — no brittle substring match.
        handle = gen.spawn(src, prompt="smoke test", invocation_type=invocation, **spawn_kw)
        if not handle.id:
            return None  # no host — degrade to manifest-lint-only
        try:
            if is_daemon:
                await handle.endpoints(timeout=20)
                if (await handle.status()) == "failed":
                    res = await handle.wait(timeout=5)
                    return res.traceback or res.error or "daemon failed to start"
                return None
            res = await handle.wait(timeout=90)
            if not res.ok:
                return res.traceback or res.error or "run failed with no detail"
            return None
        finally:
            await handle.stop()
    except gen.Cancelled:
        raise
    except gen.IPCError as e:
        gen.log(f"[generator-builder] dry-run skipped (host capability error): {e}")
        return None  # transient — don't attribute to the candidate
    except Exception as e:  # noqa: BLE001
        gen.log(f"[generator-builder] dry-run skipped (could not start: {e})")
        return None  # be conservative — never block on a harness-side error


def _run_fix_prompt(error: str) -> str:
    return (
        "Your generator was scaffolded but FAILED to run. Fix the code so it "
        "runs cleanly, re-emitting any changed files via write_file. Do not "
        "write README or explanation files. The run error was:\n\n"
        f"{error}\n"
    )


def _fix_prompt(errors: list[str]) -> str:
    bullets = "\n".join(f"  - {e}" for e in errors)
    return (
        "Your previous output has the following manifest problems. "
        "Fix EVERY one of them by re-emitting the corrected files via "
        "write_file. Do not write README.md or any explanation files — "
        "just the corrected manifest and any other files that need "
        f"updating.\n\n{bullets}\n"
    )


def _int(raw, default: int) -> int:
    try:
        n = int(raw)
        return n if n > 0 else default
    except (TypeError, ValueError):
        return default


if __name__ == "__main__":
    gen.main(run)
