# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "docker", "mcp", "uvicorn", "starlette"]
# ///
"""Guide — orientation, docs Q&A, reading material, and the builder surface.

The resident Collimate expert (formerly ``workshop``). One interactive chat
that (1) orients newcomers to the app and the ideas behind it, (2) answers
questions about Collimate — vision and philosophy as well as mechanics,
(3) produces reading material as real docs cells the user can keep, and
(4) builds, TESTS, and installs generators and renderers. Every turn spawns
the unified ``agent`` generator (one-shot, streaming) seeded with the
reference library and with the heavy tools turned ON:

  * file + python tools — draft and run code in the agent's scratch workspace;
  * the full composition ladder (``exposure: modify_and_run``) — discover, read,
    and RUN generators (``list_generators`` / ``list_exposed_cells`` /
    ``read_other_cell`` / ``call_generator``), stand up a live cell backed by a
    modify generator (``create_cell_with_generator``), edit exposed cells,
    add/compile generators & renderers, and ``commit_generator`` /
    ``commit_renderer`` to install a finished one into the stack
    (auto-exposed, so the agent can keep iterating on what it just made), plus
    ``create_cell`` for a NEW content cell beside the chat (a draft, an
    alternative) — ordinary content, distinct from committing a generator.

The reference library is seeded into this cell's ``_shared_docs/`` sibling
(releases.yaml) and handed to the agent as read-only workspace files, so
answers cite the real spec and scaffolds follow it. It spans both halves of
the job: ``collimate-overview.md`` (vision, philosophy, concepts, UI tour)
for the orient/answer side, and the authoring guides plus
``authoring-best-practices.md`` (the house style distilled from the packaged
generator/renderer set) for the builder side.

Docs-as-deliverables (in-process engine): anything the per-turn agent writes
under ``deliverable/`` in its workspace is published after the turn as a NEW
stack cell beside this chat, pinned to its first markdown file. That is how
"give me reading material" yields an artifact the user can keep, fork, and
edit — not a chat reply that scrolls away.

The durable transcript is the open-format ``chats/<id>.json`` (assistant-ui chat).
"""
from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

import gen

# Parent dir so the _agent_shared sibling cell folder (and its claude_terminal /
# opencode modes) resolves when the engine is claude-cli / opencode.
# The shared _* cell-folders are SIBLINGS at run time (materialised into
# the cell); in the repo/tests they live at the asset root, one level above
# this generator's cell parent folder. Insert both.
_here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(_here))
sys.path.insert(0, os.path.dirname(os.path.dirname(_here)))

_HISTORY_CHAR_BUDGET = 24000
_ROLE_LABELS = {"user": "User", "assistant": "Assistant", "system": "System"}
_DELIVERABLE_PREFIX = "deliverable/"

# Which seeded doc answers which kind of question — rendered into the system
# prompt so the per-turn agent opens the right file instead of guessing.
_DOC_ROUTES = [
    ("collimate-overview.md",
     "what Collimate is: the vision and philosophy (judgment over generation, "
     "the third story, explore/challenge/compare/keep), core concepts "
     "(channel/stack/cell/generator/renderer/views), and the UI tour. Read "
     "FIRST for any orientation, concept, why-is-it-built-this-way, or "
     "where-do-I-click question."),
    ("how-to-write-a-generator.md",
     "the full generator contract: manifest.gen_yaml fields, the run() "
     "lifecycle, the gen.* API, config/draft files, packaging. Read before "
     "scaffolding ANY generator."),
    ("how-to-write-a-renderer.md",
     "the full renderer contract: manifest.rend_yaml, the React hooks SDK, "
     "shadow-DOM styling rules, hosting modes, diff support, complete working "
     "examples. Read before scaffolding ANY renderer."),
    ("authoring-best-practices.md",
     "the house style distilled from the packaged generator/renderer set — "
     "apply it to EVERYTHING you scaffold, and lean on it when reviewing the "
     "user's own work."),
    ("api-reference.md",
     "the tabular gen.* / manifest cross-reference — exact signatures when "
     "you already know what you need."),
    ("testing-generators.md",
     "running generators host-free and compile-checking renderers, from a "
     "shell or CI."),
]


def _load_docs() -> dict:
    """The reference library seeded into this cell's ``_shared_docs/`` sibling,
    keyed by basename (the agent reads them as plain workspace files)."""
    docs_dir = Path(__file__).resolve().parent.parent / "_shared_docs"
    out: dict = {}
    if docs_dir.is_dir():
        for p in sorted(docs_dir.iterdir()):
            if p.is_file():
                try:
                    out[p.name] = p.read_text(encoding="utf-8")
                except OSError:
                    continue
    return out


def _system_prompt(doc_names: list[str], *, deliverables: bool) -> str:
    """The Guide persona. ``deliverables`` is True only for the in-process
    engine, where files the agent writes under ``deliverable/`` are harvested
    into a new stack cell after the turn (the container engines instead work
    directly on the cell's own files)."""
    lines = [
        "You are the Collimate Guide — the resident expert inside a Collimate "
        "channel. You have four jobs:",
        "",
        "  1. ORIENT — welcome people new to Collimate: what they are looking "
        "at, the ideas behind it, what to try first.",
        "  2. ANSWER — questions about Collimate and the SDK, from vision and "
        "philosophy down to manifest fields and gen.* signatures.",
        "  3. TEACH — produce reading material (short guides, concept notes, "
        "annotated examples) the user can keep.",
        "  4. BUILD — scaffold, TEST, and INSTALL generators and renderers.",
        "",
    ]

    if doc_names:
        routed = {name for name, _ in _DOC_ROUTES}
        lines += [
            "## Reference library",
            "",
            "The authoritative documentation is in your workspace as plain "
            "files. READ the relevant file(s) before answering or scaffolding "
            "— prefer the docs over your own recollection, and say which file "
            "(and section) the answer comes from:",
            "",
        ]
        lines += [f"  - `{name}` — {what}" for name, what in _DOC_ROUTES
                  if name in doc_names]
        lines += [f"  - `{name}`" for name in doc_names
                  if name not in routed and name != "README.md"]
        lines.append("")
    else:
        lines += [
            "No documentation files were seeded; answer from general "
            "knowledge and flag the uncertainty explicitly.",
            "",
        ]

    lines += [
        "## Tools",
        "",
        "  - Drafting: file + python tools in your scratch workspace — draft "
        "code, run it, check claims before making them.",
        "  - Showing content: `create_cell` drops a NEW content cell beside "
        "this chat — a draft, a side result, an alternative to compare. This "
        "is the cheap default 'new cell'. It is NOT how you add a generator "
        "or renderer.",
        "  - Committing (ADDING CAPABILITY to the system): when the user wants "
        "a new generator or renderer to actually exist, call "
        "`commit_generator` or `commit_renderer` with a "
        "files map containing a valid `manifest.gen_yaml` (generators) or "
        "`manifest.rend_yaml` (renderers) plus the entrypoint. A generator or "
        "renderer is a real contract, not just any cell — commit only after "
        "you have read the how-to and tested it. The new cell is exposed to "
        "you immediately — read it back and refine with `write_other_cell` / "
        "`add_generator` / `add_renderer`.",
        "  - Testing (BEFORE you commit): a generator is tested by RUNNING it — call "
        "`call_generator` with its id (and optional input files). A renderer "
        "is tested by COMPILING it — call `check_renderer` with its files "
        "and entrypoint. NEVER tell the user something is done until its "
        "test passes; on failure, fix and re-test. IMPORTANT: `check_renderer` "
        "only transpiles + checks the export shape — it does NOT run React, so "
        "Rules-of-Hooks violations, throwing effects, and layout bugs pass it "
        "and only crash when the cell is opened. A green compile means it "
        "compiles, not that it renders — after it passes, reason through mount "
        "behavior: are ALL hooks (useCollimateFile, useEffect) called at the "
        "top level of the component (never inside another hook's callback)? "
        "does every JSON.parse guard bad input?",
        "  - Editing existing work: `list_exposed_cells` to discover, "
        "`read_other_cell` to inspect, `write_other_cell` to edit. If a cell "
        "you need isn't listed, tell the user to toggle \"expose to "
        "generators\" on that cell.",
        "",
        "## Playbooks",
        "",
        "ORIENTING someone new: keep it short and concrete. What they are "
        "looking at (a channel of stacks; each stack a column of cells; each "
        "cell files shown by a renderer). The working loop (fork a result, "
        "challenge it, compare rivals side by side, keep what holds — "
        "nothing is lost). Two or three first moves: run the Agent chat, try "
        "a config tag, or build something tiny together. Point at Settings → "
        "Keys for API keys and Shift+? for the keyboard cheatsheet. Offer to "
        "go deeper on any thread; don't lecture.",
        "",
        "ANSWERING: read the routed doc first, answer directly, cite where "
        "the answer lives. Distinguish vision (why it's built this way — "
        "collimate-overview.md) from mechanics (how it works — the guides). "
        "When a question deserves more than a chat reply, offer to write it "
        "up as reading material.",
        "",
    ]

    if deliverables:
        lines += [
            "READING MATERIAL: write complete markdown files under "
            "`deliverable/` in your workspace (e.g. "
            "`deliverable/understanding-cells.md`). After your turn they are "
            "automatically published as a NEW cell beside this chat, pinned "
            "to the first markdown file — give the main file ONE clear "
            "`# H1` title (it names the cell). Self-contained prose, no "
            "placeholders; diagrams as fenced ```mermaid blocks are welcome "
            "(there is a mermaid renderer). Mention in your reply that the "
            "cell was created and what's in it. Use this whenever the user "
            "asks for a guide, notes, a reading list, or a comparison — a "
            "cell can be kept, forked, and edited; a chat reply can't.",
            "",
        ]
    else:
        lines += [
            "READING MATERIAL: when the user asks for a guide, notes, or "
            "anything worth keeping, write it as complete markdown files in "
            "the project — they persist in this cell's files.",
            "",
        ]

    lines += [
        "BUILDING A GENERATOR: (1) restate what it should do, its inputs "
        "(0/1/N cells? a prompt?) and its output shape — one line each. "
        "(2) Read `how-to-write-a-generator.md` and "
        "`authoring-best-practices.md`. (3) Draft the entrypoint + "
        "`manifest.gen_yaml` (+ a `.set_yaml` config with defaults that work "
        "unedited, when it takes config); sanity-run pure logic with the "
        "python tool. (4) Commit via `commit_generator`. (5) Test via "
        "`call_generator`; iterate with "
        "`write_other_cell` until it passes. (6) Report: what was made, how "
        "to run it, what the config knobs do. IF IT DRIVES THE AGENT "
        "(gen.call/gen.call_many): read the how-to's \"Driving a child agent\" "
        "section; `gen.call_many` and `result.output_text`/`.structured()` "
        "need no import; `oneshot_tag_values` is imported from the provided "
        "`_agent_shared` sibling — NEVER write your own `_agent_shared.py` "
        "(it collides with the real cell). Test the agent call by stubbing it "
        "(see testing-generators.md).",
        "",
        "BUILDING A RENDERER: same shape. Read `how-to-write-a-renderer.md` "
        "first — shadow-DOM styling (inline styles, no classes), "
        "`useCollimateFile`, theme tokens, native vs iframe hosting. Two "
        "native-renderer footguns to get right (the compile check will NOT "
        "catch either): (1) call hooks ONLY at the top level of the component — "
        "get `api`/`content` from `useCollimateFile()` at the top and call "
        "`api.injectStyle`/`useEffect` there, never a hook inside another "
        "hook's callback; (2) the shadow root has no CSS reset, so a padded "
        "full-width element needs a `box-sizing: border-box` reset via "
        "`api.injectStyle` or it overflows. Test via `check_renderer`, then "
        "commit via `commit_renderer`, and report which file "
        "extensions it claims.",
        "",
        "## Style",
        "",
        "Be concise and warm; short code/manifest snippets over walls of "
        "text. Write complete files — no placeholders, no TODOs. Follow the "
        "manifest and lifecycle rules from the guides exactly, and the house "
        "style from authoring-best-practices.md. When you scaffold: write, "
        "install, test, then summarize what you made, how to run it, and "
        "what you verified. When something fails, show the actual error and "
        "what you changed. If an ask is ambiguous between explain / document "
        "/ build, do the small thing and offer the big one.",
    ]
    return "\n".join(lines)


def _compose_prompt(messages: list, budget: int) -> str:
    if len(messages) <= 1:
        return messages[-1].content if messages else ""
    current, prior = messages[-1], messages[:-1]
    kept: list = []
    used = 0
    truncated = False
    for m in reversed(prior):
        cost = len(m.content or "") + 16
        if kept and used + cost > budget:
            truncated = True
            break
        kept.append(m)
        used += cost
    kept.reverse()
    lines = ["You are continuing an ongoing Guide session. Transcript so far:", ""]
    if truncated:
        lines += ["[earlier messages omitted]", ""]
    for m in kept:
        lines.append(f"{_ROLE_LABELS.get((m.role or '').lower(), 'User')}: {m.content}")
        lines.append("")
    lines += ["Reply to the latest user message:", "", current.content]
    return "\n".join(lines)


def _deliverable_files(files: dict) -> dict:
    """The agent's ``deliverable/`` subtree, keyed by path inside it."""
    out: dict = {}
    for path, content in files.items():
        if path.startswith(_DELIVERABLE_PREFIX):
            rel = path[len(_DELIVERABLE_PREFIX):]
            if rel:
                out[rel] = content
    return out


def _doc_title(files: dict, pinned: str | None) -> str:
    """Cell name for a published deliverable: the pinned markdown's first H1."""
    if pinned:
        content = files.get(pinned)
        if isinstance(content, str):
            for raw in content.splitlines():
                line = raw.strip()
                if line.startswith("# "):
                    return line[2:].strip()
                if line and not line.startswith("#"):
                    break
    return ""


async def _publish_deliverables(files: dict, fallback_name: str) -> str:
    """Publish the agent's ``deliverable/`` files as a new stack cell.
    Returns a note to append to the reply ('' when there was nothing)."""
    docs = _deliverable_files(files)
    if not docs:
        return ""
    pinned = next((p for p in sorted(docs) if p.lower().endswith(".md")), None)
    # The driving agent run's assumptions ledger rides with the published
    # deliverable — the record of what this document claimed and enacted.
    ledger = files.get("_agent/assumptions.ledger")
    if ledger:
        docs["assumptions.ledger"] = ledger
    title = (_doc_title(docs, pinned)
             or (fallback_name or "").strip().splitlines()[0][:60]
             or "Guide notes")
    try:
        await gen.create_stack_cell(
            title[:80],
            summary=f"Written by the Guide · {len(docs)} file(s)",
            pinned=pinned,
            files=docs,
        )
    except Exception as e:  # noqa: BLE001 — publishing must never kill the turn
        gen.log(f"[guide] could not publish deliverable cell: {e}")
        return ""
    names = ", ".join(f"`{p}`" for p in sorted(docs))
    return f"📄 Published **{title}** as a new cell in this stack ({names})."


async def run() -> None:
    cfg = gen.config("guide-config.set_yaml")
    docs = _load_docs()
    engine = (cfg.get("engine") or "in-process").strip().lower()
    # The parent-generator convention: agent settings come from ONE named
    # config tag on the agent generator (blank → its defaults); the Guide
    # overrides only what it has opinions about (persona, tools, streaming).
    tag_values = gen.tag_config("agent", cfg.get("agent_config_tag")).get(
        "agent-config.set_yaml", {})

    # claude-cli / opencode engines: hand the whole session to that surface
    # (the live claude terminal or opencode's web UI), seeded with the docs and
    # the orient/answer/build guidance, with the cross-cell + create-cell tools
    # bridged in. The Guide cell becomes that surface.
    if engine in ("claude-cli", "claude-terminal", "claude"):
        from _agent_shared.claude_terminal import run_claude_terminal
        await run_claude_terminal(
            _engine_cfg(tag_values, "claude-terminal"),
            extra_system=_system_prompt(sorted(docs), deliverables=False),
            docs=docs,
            label="Guide · Claude CLI",
        )
        return
    if engine == "opencode":
        from _agent_shared.opencode import run_opencode
        await run_opencode(
            _engine_cfg(tag_values, "opencode"),
            extra_system=_system_prompt(sorted(docs), deliverables=False),
            docs=docs,
            label="Guide · OpenCode",
        )
        return

    # Default: the in-process streaming chat (spawns the agent per turn).
    agent_config = {
        **tag_values,
        "mode": "oneshot",
        "system_prompt": _system_prompt(sorted(docs), deliverables=True),
        "enable_file_tools": True,
        "enable_python_tool": True,
        "exposure": "modify_and_run",
        "stream": True,
    }
    budget = _int(cfg.get("history_char_budget"), _HISTORY_CHAR_BUDGET)
    gen.log(f"[guide] {agent_config.get('backend', 'agent default')} · "
            f"{agent_config.get('model') or '(auto)'} · {len(docs)} doc(s)")

    async def on_turn(turn: gen.ChatTurn) -> None:
        turn.append("user", turn.user_msg)   # bound to this turn's thread
        await gen.update()

        reply = ""
        thinking = ""
        agent_files: dict = {}
        try:
            handle = gen.spawn(
                "agent",
                inputs=dict(docs),
                prompt=_compose_prompt(turn.messages, budget),
                config={"agent-config.set_yaml": dict(agent_config)},
            )
            try:
                async for ev in handle.events(should_stop=lambda: turn.cancelled):
                    if turn.cancelled:
                        break
                    text = ev.get("text") or ""
                    if ev.get("type") == "text_delta" and text:
                        reply += text
                        turn.delta(text)
                    elif ev.get("type") == "thinking_delta" and text:
                        thinking += text
                        turn.thinking_delta(text)
                if not turn.cancelled and not gen.cancelled:
                    # The event stream can end EARLY on a transient IPC blip
                    # (events() returns rather than raising) while the child
                    # is still mid-turn — never kill a working child and shrug
                    # "_(empty response)_". Poll it to completion (bounded AND
                    # cancellable — a single long handle.wait() would hold the
                    # shared IPC channel for its whole timeout, freezing the
                    # chat loop and making an interrupt undeliverable),
                    # surface a real failure, THEN harvest.
                    status = await handle.status()
                    waited = 0.0
                    while (status == "running" and waited < 600
                           and not turn.cancelled and not gen.cancelled):
                        await asyncio.sleep(0.5)
                        waited += 0.5
                        status = await handle.status()
                    if status == "failed" and not reply.strip():
                        reply = "_(agent turn failed — see the run log)_"
                    # One files() snapshot serves both the empty-reply fallback
                    # and the deliverable/ harvest below.
                    try:
                        agent_files = await handle.files()
                    except Exception:
                        agent_files = {}
                    if not reply.strip():
                        out = agent_files.get("_agent/output.md")
                        if isinstance(out, str):
                            reply = out
            finally:
                await handle.stop()
        except gen.Cancelled:
            if gen.cancelled:      # real run teardown
                raise
            reply = reply.strip() or "_(stopped)_"
        except Exception as e:  # noqa: BLE001 — pair the turn instead of dangling
            reply = reply.strip() or (
                f"_(could not reach the agent: {e}. Is the Agent source cell "
                "exposed to generators?)_"
            )

        reply = reply.strip()
        if not turn.cancelled and agent_files:
            note = await _publish_deliverables(agent_files, turn.user_msg)
            if note:
                turn.delta(f"\n\n{note}")
                reply = f"{reply}\n\n{note}".strip()
        if turn.cancelled and not reply:
            reply = "_(stopped by user)_"
        turn.append("assistant", reply or "_(empty response)_",
                    thinking=thinking.strip())
        await gen.update(summary=turn.user_msg[:80].replace("\n", " "))

    # Keep the cell's files (the seeded docs) live-editable during the session.
    # initial_message: a question typed into the run's prompt box seeds the
    # first turn (only into a virgin thread — never re-sent on a resumed cell).
    async with gen.live_files():
        await gen.serve_chat(
            on_turn, label="Guide", resume=True,
            initial_message=(gen.prompt or "").strip(),
        )


def _engine_cfg(tag_values: dict, mode: str) -> dict:
    """Config dict the claude-terminal / opencode modes read: the resolved
    agent config tag normalized for the chosen mode (the model family guard
    swaps a contradicting tag model for the mode's default), with the full
    composition ladder forced ON (``exposure: modify_and_run``) — that's the
    point of the Guide — so the MCP bridge exposes every tier to the chosen
    surface."""
    from _agent_shared import parse_agent_config

    return parse_agent_config({**tag_values, "mode": mode, "exposure": "modify_and_run"})


def _int(raw, default: int) -> int:
    try:
        n = int(raw)
        return n if n > 0 else default
    except (TypeError, ValueError):
        return default


if __name__ == "__main__":
    gen.main(run)
