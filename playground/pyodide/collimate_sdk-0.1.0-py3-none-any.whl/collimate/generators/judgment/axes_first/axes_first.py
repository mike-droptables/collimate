# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic", "pydantic-ai", "claude-agent-sdk"]
# ///
"""Axes First — set the frame before generating candidates.

When a model generates candidates directly, it has already chosen the
trade-off axes silently. This generator splits frame-setting from candidate
generation:

  1. **Research pass** — TWO independent agent runs each propose the
     decision's trade-off axes; a merge pass folds them together and marks
     where they DISAGREE (a contested frame is exactly where the user should
     spend attention). A standing slot — "what would make this whole framing
     wrong?" — is appended in code, never trusted to the LLM.
  2. **Frame review** — the proposed frame renders as ``frame.axes`` (the
     Axes renderer) before any candidates exist. The run pauses, open-ended,
     until the user strikes/adds/reweights axes and presses Continue
     (``pause_mode: settings-modal`` swaps in a schema-form modal for
     channels without the renderer). This is the highest residual-yield
     moment in the workflow: a wrong axis invalidates whole regions of
     candidate space before any generation cost is paid.
  3. **Fan-out** — one worker per accepted axis region, each pinned to
     "optimize for X" and told what it sacrifices elsewhere. Every candidate
     cell carries the accepted frame plus that worker's promoted
     ``assumptions.ledger``; the index cell gets the merged cross-candidate
     ledger with its differential — the seams where the candidates actually
     disagree.

The accepted frame persists as part of the decision record: it documents not
just what was chosen but what was considered choosable.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
from datetime import datetime, timezone
from typing import Literal, Optional

import yaml
from pydantic import BaseModel, Field

import gen

# The shared _* cell-folders are SIBLINGS at run time (materialised into
# the cell); in the repo/tests they live at the asset root, one level above
# this generator's cell parent folder. Insert both.
_here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(_here))
sys.path.insert(0, os.path.dirname(os.path.dirname(_here)))
from _agent_shared import (  # noqa: E402
    gather_agent_calls,
    oneshot_tag_values,
    parse_agent_config,
    to_int,
)
from _agent_shared import ledger as ledger_mod  # noqa: E402

FRAME_FORMAT = "collimate.axes-frame"
FRAME_VERSION = 1
FRAME_FILE = "frame.axes"
FRAME_MD = "axes.md"
REVIEW_SETTINGS = "axes-review.set_yaml"
ACCEPT_ACTION = "axes:accept"
STANDING_ID = "ax-framing"
STANDING_NAME = "What would make this whole framing wrong?"


class ProposedAxis(BaseModel):
    name: str = Field(description="Short axis name (2-6 words).")
    description: str = Field(description="What this axis trades off, one sentence.")
    weight: int = Field(ge=1, le=5, default=3, description="How much this axis matters here, 1-5.")


class AxesProposal(BaseModel):
    axes: list[ProposedAxis] = Field(description="4-8 genuinely distinct trade-off axes for this decision.")


class MergedAxis(BaseModel):
    name: str
    description: str
    weight: int = Field(ge=1, le=5, default=3)
    source: Literal["both", "pass_a", "pass_b"]
    disagreement: Optional[str] = Field(
        default=None,
        description="Set ONLY when the two passes cover the same territory but frame it differently — quote both framings.",
    )


class MergedFrame(BaseModel):
    axes: list[MergedAxis]


async def run() -> None:
    raw_cfg = gen.config("config.set_yaml")
    # The parent-generator convention: agent settings come from ONE named
    # config tag on the agent generator (blank → its defaults); this
    # generator overrides only what it has opinions about below.
    tag_values = gen.tag_config("agent", raw_cfg.get("agent_config_tag")).get(
        "agent-config.set_yaml", {})
    cfg = parse_agent_config(tag_values)
    for w in cfg["warnings"]:
        gen.log(f"config: {w}")
    num_workers = max(2, min(8, to_int(raw_cfg.get("num_workers"), 4)))
    pause_mode = (raw_cfg.get("pause_mode") or "frame-editor").strip().lower()
    review_timeout = to_int(raw_cfg.get("review_timeout"), 15)
    user_system = (tag_values.get("system_prompt") or "").strip()

    problem = (gen.prompt or "").strip()
    if not problem:
        raise Exception("Describe the decision/problem in the picker prompt.")

    carry = {p: gen.read_file(p) for p in gen.list_files()}

    def agent_config(*, system_prompt: str, **extra) -> dict:
        # oneshot_tag_values validates the FOLDED config parent-side (and
        # reconciles container-mode tags — claude-terminal → claude-agent-sdk),
        # so a tag the child would reject fails HERE, before the fan-out spends
        # a single call on it.
        return {"agent-config.set_yaml": oneshot_tag_values(
            tag_values, system_prompt=system_prompt, **extra)}

    # ── Phase 1: two independent research passes ─────────────────────────
    # Identical prompts by design: disagreement should reflect the problem's
    # genuinely contested frame, not injected persona differences.
    gen.phase("running", "proposing trade-off axes")
    gen.status("Proposing trade-off axes (two independent passes)…")

    propose_system = (
        (user_system + "\n\n" if user_system else "")
        + "You surface the trade-off axes of a decision BEFORE any solution is "
        "generated: the dimensions on which candidate solutions will genuinely "
        "differ and that determine what counts as a cost here. Propose axes, "
        "not solutions."
    )
    propose_prompt = f"## The decision\n\n{problem}"
    if carry:
        previews = "\n".join(f"- `{p}`" for p in sorted(carry))
        propose_prompt += f"\n\n## Context files\n\n{previews}"

    # Ledger off for the framing utility calls (propose ×2 + merge): their
    # output IS the frame artifact the user reviews line-by-line in the next
    # step — the review is direct, so a ledger over it is meta-noise. The
    # candidate workers below keep the default-on ledger.
    propose_config = agent_config(
        system_prompt=propose_system,
        output_schema=AxesProposal.model_json_schema(),
        enable_file_tools=bool(carry),
        ledger=False,
    )

    def _parse_proposal(result) -> tuple[AxesProposal | None, str]:
        """(proposal, error) — proposal None on any failure."""
        if not result.ok:
            return None, result.error or "axis proposal run failed"
        raw = result.files.get("_agent/output.json")
        if raw is None:
            return None, "axis proposal returned no structured output"
        try:
            return AxesProposal(**json.loads(raw)), ""
        except Exception as e:  # noqa: BLE001
            return None, f"axis proposal returned bad structure: {e}"

    # Two identical passes, fanned out CONCURRENTLY (a gather over gen.call
    # would serialize on the bridge's single IPC lock); raises gen.Cancelled
    # on a user stop.
    propose_spec = {
        "inputs": carry or None,
        "prompt": propose_prompt,
        "config": propose_config,
    }
    propose_runs = await gather_agent_calls([propose_spec, propose_spec], timeout=300)
    (pass_a, err_a), (pass_b, err_b) = (_parse_proposal(r) for r in propose_runs)
    if pass_a is None and pass_b is None:
        raise Exception(f"both axis-proposal passes failed: A: {err_a}; B: {err_b}")

    # ── Phase 2: merge, marking disagreements ────────────────────────────
    if pass_a is None or pass_b is None:
        # Label provenance by the pass that actually SURVIVED — mislabelling
        # a pass_b-only frame as pass_a would corrupt the decision record.
        ok, ok_source = (pass_b, "pass_b") if pass_a is None else (pass_a, "pass_a")
        failed_err = err_a if pass_a is None else err_b
        gen.log(f"one axis-proposal pass failed ({failed_err}) — single-pass frame")
        merged = [
            MergedAxis(name=a.name, description=a.description, weight=a.weight, source=ok_source)
            for a in ok.axes
        ]
    else:
        gen.status("Merging the two proposals…")
        merged = await _merge_passes(pass_a, pass_b, agent_config)

    frame = _postprocess_frame(merged, problem)

    # ── Phase 3: persist the proposed frame + pause for review ───────────
    _write_frame(frame)
    n_dis = sum(1 for a in frame["axes"] if a.get("disagreement"))
    await gen.update(
        name="Frame proposed — review & continue",
        summary=f"{len(frame['axes'])} axes · {n_dis} contested — edit the frame, then Continue",
        pinned=FRAME_FILE,
    )

    if pause_mode == "settings-modal":
        frame = await _review_via_settings(frame)
    else:
        frame = await _review_via_frame_editor(frame, review_timeout)

    frame["status"] = "accepted"
    frame["accepted_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    _write_frame(frame)
    kept = [a for a in frame["axes"] if not a.get("struck") and not a.get("standing")]
    await gen.update(
        name="Frame accepted — generating candidates",
        summary=" · ".join(a["name"] for a in kept)[:120],
        pinned=FRAME_FILE,
    )
    if not kept:
        gen.update_file("index.md", "# No axes kept\n\nEvery axis was struck — nothing to generate.\n")
        await gen.update(name="Axes First — empty frame", summary="every axis struck", pinned="index.md")
        return

    # ── Phase 4: fan out one worker per accepted axis region ─────────────
    regions = _worker_regions(kept, num_workers)
    gen.phase("running", f"{len(regions)} candidate workers")
    gen.status(f"Generating {len(regions)} candidates against the accepted frame…")

    accepted_md = _frame_to_md(frame)
    build_system = (
        (user_system + "\n\n" if user_system else "")
        + "You produce ONE candidate solution, pinned to a region of an accepted "
        "trade-off frame. Optimize hard for your region and be explicit about "
        "what the candidate sacrifices on the other axes — a candidate that "
        "pretends to win everywhere is a failed probe."
    )

    build_specs = [{
        "inputs": carry or None,
        "prompt": (
            f"## The decision\n\n{problem}\n\n"
            f"## Accepted trade-off frame\n\n{accepted_md}\n"
            f"## Your region\n\n{region['instruction']}\n\n"
            "Write the candidate as `Candidate.md` prose (you may also create "
            "supporting files; run_python is available). End with two short "
            "sections: **Sacrifices** — what this candidate gives up on the "
            f"other axes; **{STANDING_NAME}** — answered for this candidate."
        ),
        # ledger ON: each worker's ledger is PROMOTED into its candidate cell.
        "config": agent_config(system_prompt=build_system, enable_python_tool=True, ledger=True),
    } for region in regions]

    # Concurrent fan-out (a gather over gen.call would serialize on the
    # bridge lock); raises gen.Cancelled on a user stop instead of paying for
    # the remaining builds.
    outcomes = await gather_agent_calls(build_specs, timeout=600)

    ledgers: dict[str, dict] = {}
    lines_ok: list[str] = []
    lines_err: list[str] = []
    for region, result in zip(regions, outcomes):
        if not result.ok:
            lines_err.append(f"- ⚠️ **{region['name']}** — {result.error or 'candidate worker failed'}")
            continue
        body = result.files.get("_agent/output.md", "") or ""
        # This candidate's own files: everything outside the agent's _agent/
        # bookkeeping that is new OR that the worker EDITED (compare content,
        # not just path — a worker's edit to a carried file is its work, and a
        # stale carried `Candidate.md` must not shadow the generated one).
        artifacts = {
            p: v for p, v in result.files.items()
            if not p.startswith("_agent/") and (p not in carry or v != carry.get(p))
        }
        ledger_doc = None
        raw_ledger = result.files.get(ledger_mod.LEDGER_FILE)
        if raw_ledger:
            artifacts[ledger_mod.LEDGER_PROMOTED] = raw_ledger
            try:
                ledger_doc = json.loads(raw_ledger)
            except Exception:  # noqa: BLE001
                ledger_doc = None
        # An empty reply with no candidate artifacts is not a candidate —
        # record it as a failed worker rather than committing an empty cell.
        has_candidate = bool(body.strip()) or any(
            p != ledger_mod.LEDGER_PROMOTED for p in artifacts
        )
        if not has_candidate:
            lines_err.append(f"- ⚠️ **{region['name']}** — worker produced no reply and no artifacts")
            continue
        files = dict(carry)
        files.update(artifacts)
        if "Candidate.md" not in artifacts:
            files["Candidate.md"] = f"# {region['name']}\n\n{body}\n"
        files[FRAME_FILE] = json.dumps(frame, indent=2) + "\n"
        files[FRAME_MD] = accepted_md
        cell_name = f"Optimize: {region['name']}"[:80]
        await gen.create_stack_cell(
            cell_name,
            summary=_first_line(body) or region["instruction"][:120],
            pinned="Candidate.md",
            files=files,
        )
        if ledger_doc:
            # Keyed by the cell name so the merged ledger's per-candidate
            # columns match the candidate cells on the canvas.
            ledgers[cell_name] = ledger_doc
        lines_ok.append(f"- ✅ **{region['name']}** — {_first_line(body)}")

    # ── Phase 5: index cell = frame + cross-candidate differential ledger ─
    if ledgers:
        gen.status("Merging assumptions ledgers…")
        try:
            merged_ledger = ledger_mod.merge_ledgers(ledgers)
            merged_ledger = await ledger_mod.compute_differential(merged_ledger, cfg)
            gen.update_file(ledger_mod.LEDGER_PROMOTED, ledger_mod.dumps_ledger(merged_ledger))
            gen.update_file("assumptions.md", ledger_mod.ledger_to_md(merged_ledger))
        except gen.Cancelled:
            raise
        except Exception as e:  # noqa: BLE001
            gen.log(f"[ledger] differential merge failed: {e}")

    gen.update_file("index.md", _final_index(problem, frame, lines_ok, lines_err))
    await gen.update(
        name=f"{len(lines_ok)} candidates · axes-first",
        summary=" · ".join(r["name"] for r in regions)[:120],
        pinned="index.md",
    )


# ──────────────────────────────────────────────────────────────────────
# Merge + frame document
# ──────────────────────────────────────────────────────────────────────


async def _merge_passes(pass_a: AxesProposal, pass_b: AxesProposal, agent_config) -> list[MergedAxis]:
    merge_system = (
        "You merge two independently proposed trade-off-axis lists for the same "
        "decision. Axes covering the same territory merge into one with source "
        "'both' — but when the two passes FRAME that territory differently, keep "
        "the merged axis and record both framings verbatim in 'disagreement' "
        "(a contested frame deserves the user's attention). Axes unique to one "
        "pass keep source 'pass_a'/'pass_b'. Never invent axes."
    )
    dump = lambda p: json.dumps([a.model_dump() for a in p.axes], indent=2)  # noqa: E731
    result = await gen.call(
        "agent",
        prompt=f"## Pass A\n\n{dump(pass_a)}\n\n## Pass B\n\n{dump(pass_b)}\n\nMerge them.",
        config=agent_config(
            system_prompt=merge_system,
            output_schema=MergedFrame.model_json_schema(),
            enable_file_tools=False,
            ledger=False,
        ),
        timeout=300,
    )
    if result.ok:
        raw = result.files.get("_agent/output.json")
        if raw is not None:
            try:
                return MergedFrame(**json.loads(raw)).axes
            except Exception as e:  # noqa: BLE001
                gen.log(f"merge pass returned bad structure ({e}) — concatenating")
    else:
        gen.log(f"merge pass failed ({result.error}) — concatenating")
    return (
        [MergedAxis(**a.model_dump(), source="pass_a") for a in pass_a.axes]
        + [MergedAxis(**a.model_dump(), source="pass_b") for a in pass_b.axes]
    )


def _postprocess_frame(axes: list[MergedAxis], problem: str) -> dict:
    """Deterministic frame assembly: stable ids, weight clamp, name dedupe,
    and the standing framing-check axis appended in code."""
    seen: set[str] = set()
    rows: list[dict] = []
    for a in axes:
        key = " ".join((a.name or "").lower().split())
        if not key or key in seen:
            continue
        seen.add(key)
        rows.append({
            "id": f"ax-{len(rows) + 1}",
            "name": a.name.strip(),
            "description": (a.description or "").strip(),
            "weight": max(0, min(5, int(a.weight))),
            "source": a.source,
            "disagreement": (a.disagreement or "").strip() or None,
            "standing": False,
            "struck": False,
            "user_note": "",
        })
    rows.append({
        "id": STANDING_ID,
        "name": STANDING_NAME,
        "description": "The standing framing check: every candidate must answer it, "
                       "and striking it means accepting the frame unexamined.",
        "weight": 5,
        "source": "both",
        "disagreement": None,
        "standing": True,
        "struck": False,
        "user_note": "",
    })
    return {
        "format": FRAME_FORMAT,
        "version": FRAME_VERSION,
        "status": "proposed",
        "problem": problem,
        "axes": rows,
        "accepted_at": None,
    }


def _write_frame(frame: dict) -> None:
    gen.update_file(FRAME_FILE, json.dumps(frame, indent=2) + "\n")
    gen.update_file(FRAME_MD, _frame_to_md(frame))


def _axes_wellformed(axes) -> bool:
    """A read-back frame is only trustworthy if EVERY axis carries the fields
    the fan-out reads: a non-empty string ``name``, a string ``description``,
    and an int-coercible ``weight``. Guards the post-pause path against a
    valid-JSON-but-malformed edit crashing after the expensive review."""
    if not isinstance(axes, list) or not axes:
        return False
    for a in axes:
        if not isinstance(a, dict):
            return False
        if not isinstance(a.get("name"), str) or not a["name"].strip():
            return False
        if not isinstance(a.get("description"), str):
            return False
        try:
            int(a["weight"])
        except (KeyError, TypeError, ValueError):
            return False
    return True


_SOURCE_LABEL = {"both": "both passes", "pass_a": "pass A only", "pass_b": "pass B only", "user": "you"}


def _frame_to_md(frame: dict) -> str:
    accepted = frame.get("status") == "accepted"
    lines = [
        f"# Trade-off frame — {'accepted' if accepted else 'proposed'}",
        "",
        f"**Decision:** {frame.get('problem', '')}",
        "",
    ]
    for a in frame.get("axes", []):
        name = f"~~{a['name']}~~" if a.get("struck") else f"**{a['name']}**"
        badge = " · standing check" if a.get("standing") else f" · {_SOURCE_LABEL.get(a.get('source', ''), a.get('source', ''))}"
        lines.append(f"- {name} (weight {a.get('weight', 0)}{badge}) — {a.get('description', '')}")
        if a.get("disagreement"):
            lines.append(f"  - ⚠ **Contested frame:** {a['disagreement']}")
        if a.get("user_note"):
            lines.append(f"  - 📝 {a['user_note']}")
    lines.append("")
    if accepted:
        lines.append(f"_Accepted {frame.get('accepted_at', '')}. Struck axes remain in the record: "
                     "they document what was considered choosable._")
    else:
        lines.append("_Edit the frame (strike, add, reweight), then press Continue in the Axes renderer._")
    return "\n".join(lines) + "\n"


# ──────────────────────────────────────────────────────────────────────
# The two pause paths
# ──────────────────────────────────────────────────────────────────────


async def _review_via_frame_editor(frame: dict, review_timeout: int) -> dict:
    """Open-ended pause: mirror the cell for mid-run edits and wait for the
    Axes renderer's Continue action. The renderer flushes its save BEFORE
    emitting the action, but the draft path is asynchronous — poll the file
    until ``status: accepted`` lands (or the grace expires)."""
    async with gen.live_files():
        gen.status("Waiting for frame review — edit the axes, then press Continue.")
        accepted = False
        async for action in gen.actions():
            if action == ACCEPT_ACTION:
                accepted = True
                break
            gen.log(f"ignoring renderer action {action!r}")
        if not accepted:
            raise gen.Cancelled("frame review cancelled")

        deadline = asyncio.get_event_loop().time() + max(2, review_timeout)
        latest = frame
        saw_invalid = False
        while True:
            try:
                candidate = json.loads(gen.read_file(FRAME_FILE))
            except Exception:  # noqa: BLE001
                candidate = None
            # Only trust a read-back whose axes are well-formed: a
            # valid-JSON frame with an axis missing name/description/weight (or
            # of the wrong type) would sail past a truthiness check and crash
            # the fan-out AFTER the expensive pause. Fall back to the last
            # good frame with a log line instead.
            if isinstance(candidate, dict) and _axes_wellformed(candidate.get("axes")):
                latest = candidate
            elif isinstance(candidate, dict) and candidate.get("axes") and not saw_invalid:
                saw_invalid = True
                gen.log("frame read-back has malformed axes — keeping the last valid frame")
            if latest.get("status") == "accepted":
                return latest
            if asyncio.get_event_loop().time() >= deadline:
                gen.log("frame read-back grace expired — proceeding with the last readable frame")
                return latest
            await asyncio.sleep(0.5)


async def _review_via_settings(frame: dict) -> dict:
    """Fallback pause for channels without the Axes renderer: a schema-form
    modal built from the proposed frame (per-axis keep + weight, one textarea
    for additions). Hard 10-minute host budget."""
    fields: list[dict] = []
    for i, a in enumerate(frame["axes"]):
        desc = a.get("description", "")
        if a.get("disagreement"):
            desc += f"  ⚠ CONTESTED: {a['disagreement']}"
        if a.get("standing"):
            desc += "  (standing framing check)"
        fields.append({
            "key": f"axis_{i}_keep", "type": "checkbox",
            "label": f"Keep: {a['name']}", "description": desc, "default": True,
        })
        fields.append({
            "key": f"axis_{i}_weight", "type": "number",
            "label": f"Weight: {a['name']}", "default": a.get("weight", 3),
            "min": 0, "max": 5,
        })
    fields.append({
        "key": "added_axes", "type": "textarea",
        "label": "Add missing axes (one per line: name — description)",
        "default": "",
    })
    gen.update_file(REVIEW_SETTINGS, yaml.safe_dump({"fields": fields}, sort_keys=False))
    try:
        values = await gen.request_settings(REVIEW_SETTINGS)
    finally:
        gen.delete_file(REVIEW_SETTINGS)

    for i, a in enumerate(frame["axes"]):
        a["struck"] = not bool(values.get(f"axis_{i}_keep", True))
        try:
            a["weight"] = max(0, min(5, int(values.get(f"axis_{i}_weight", a["weight"]))))
        except (TypeError, ValueError):
            pass
    for line in str(values.get("added_axes") or "").splitlines():
        line = line.strip()
        if not line:
            continue
        name, _, desc = line.partition("—")
        if not desc:
            name, _, desc = line.partition(" - ")
        frame["axes"].append({
            "id": f"ax-user-{len(frame['axes'])}",
            "name": name.strip() or line,
            "description": desc.strip(),
            "weight": 3,
            "source": "user",
            "disagreement": None,
            "standing": False,
            "struck": False,
            "user_note": "",
        })
    return frame


# ──────────────────────────────────────────────────────────────────────
# Fan-out regions + index
# ──────────────────────────────────────────────────────────────────────


def _worker_regions(kept: list[dict], num_workers: int) -> list[dict]:
    """One region per kept axis (weight-descending). When there are more
    workers than axes, the extras probe pairwise combos — "optimize for X
    under a hard Y constraint" — which are designed probes, not retries.

    Regions are UNIQUE by name: with more workers than the axes+combos can
    fill, we emit each region once (no duplicate cost, no ledger-column
    clobbering) and let the effective worker count fall to the unique total.
    """
    axes = sorted(kept, key=lambda a: (-a.get("weight", 0), a.get("id", "")))
    regions: list[dict] = []
    used: set[str] = set()

    def _add(region: dict) -> None:
        if region["name"] not in used:
            used.add(region["name"])
            regions.append(region)

    for a in axes[:num_workers]:
        _add({
            "name": a["name"],
            "instruction": f"Optimize for **{a['name']}** ({a['description']}).",
        })
    # Ordered pairs (p ≠ q), most-weighted first — the same enumeration order
    # as before, but each unique combo is added at most once.
    for p in axes:
        if len(regions) >= num_workers:
            break
        for q in axes:
            if len(regions) >= num_workers or p is q:
                continue
            _add({
                "name": f"{p['name']} ⨯ {q['name']}",
                "instruction": (
                    f"Optimize for **{p['name']}** ({p['description']}) under a hard "
                    f"**{q['name']}** constraint ({q['description']})."
                ),
            })
    if len(regions) < num_workers:
        gen.log(f"[axes-first] {num_workers} workers requested but only "
                f"{len(regions)} distinct regions for {len(axes)} kept axes — "
                "running one worker per region")
    return regions


def _final_index(problem: str, frame: dict, ok: list[str], err: list[str]) -> str:
    kept = [a for a in frame["axes"] if not a.get("struck") and not a.get("standing")]
    struck = [a for a in frame["axes"] if a.get("struck")]
    lines = [
        f"# Axes-first: {_first_line(problem, 100)}",
        "",
        "## Accepted frame",
        "",
    ]
    lines += [f"- **{a['name']}** (weight {a['weight']})" for a in kept]
    if struck:
        lines.append("")
        lines += [f"- ~~{a['name']}~~ (struck)" for a in struck]
    lines += ["", "## Candidates", ""]
    lines += ok or ["_(none succeeded)_"]
    if err:
        lines += ["", "### Failed workers", ""] + err
    lines += [
        "",
        "_Each candidate is its own side cell, carrying the accepted frame "
        "(`frame.axes`) and its worker's `assumptions.ledger`. This cell's "
        "`assumptions.ledger` is the cross-candidate differential — the seams "
        "where the candidates genuinely disagree._",
    ]
    return "\n".join(lines) + "\n"


def _first_line(text: str, limit: int = 120) -> str:
    text = (text or "").strip()
    if not text:
        return ""
    first = next((ln.strip().lstrip("# ") for ln in text.splitlines() if ln.strip()), "")
    return first[:limit] + ("…" if len(first) > limit else "")


if __name__ == "__main__":
    gen.main(run)
