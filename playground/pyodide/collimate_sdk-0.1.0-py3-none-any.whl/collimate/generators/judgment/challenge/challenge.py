# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic"]
# ///
"""Challenge — throw one objection at every candidate, side by side.

The loop's namesake verb. Given N candidate cells and an objection, run one
adversarial agent per (challenge × candidate) — code execution on, so the
challenger *tries to break things* rather than opining — and emit a
survived/failed evidence matrix (``challenges.challenge``, rendered by the
``challenge`` renderer).

Leave the prompt blank and the challenges come from the candidates' own
recorded assumptions: differential **seams** first (the places candidates
genuinely disagree), then fact-kind claims (definitionally testable), then
unstated doctrines (acted on but never chosen). The assumptions ledger mints
the questions; this generator produces the evidence.

Challenge results are files, not verdicts — the human kills cells. What this
buys is that an elimination can carry a reproduction instead of a vibe:
"killed because it failed the NAT challenge" is a decision you can
reconstruct.
"""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from typing import Literal, Optional

from pydantic import BaseModel, Field

import gen

# The shared _* cell-folders are SIBLINGS at run time (materialised into
# the cell); in the repo/tests they live at the asset root, one level above
# this generator's cell parent folder. Insert both.
_here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(_here))
sys.path.insert(0, os.path.dirname(os.path.dirname(_here)))
from _agent_shared import (  # noqa: E402
    gather_agent_calls,
    oneshot_tag_values,
    to_bool,
    to_int,
)
from _agent_shared import ledger as ledger_mod  # noqa: E402

REPORT_FORMAT = "collimate.challenge-report"
REPORT_VERSION = 1
REPORT_FILE = "challenges.challenge"
REPORT_MD = "challenges.md"

# Hard cap on (challenges × candidates) agent runs per invocation.
_MAX_RUNS = 24

_OUTCOME_ORDER = {"failed": 0, "error": 1, "inconclusive": 2, "survived": 3}


class Evidence(BaseModel):
    ref: str = Field(description="Where the evidence lives: a file path, a command, or a quote location.")
    detail: str = Field(description="The concrete observation, one or two sentences.")


class ChallengeVerdict(BaseModel):
    outcome: Literal["survived", "failed", "inconclusive"]
    evidence: list[Evidence] = Field(default_factory=list)
    reproduction: Optional[str] = Field(
        default=None,
        description="Commands + observed output that demonstrate the failure (or the survival), when you actually ran something.",
    )
    reasoning: str = Field(description="2-5 sentences: why this outcome, and what would change it.")


async def run() -> None:
    raw_cfg = gen.config("config.set_yaml")
    # The parent-generator convention: agent settings come from ONE named
    # config tag on the agent generator (blank → its defaults); this
    # generator overrides only what it has opinions about below.
    tag_values = gen.tag_config("agent", raw_cfg.get("agent_config_tag")).get(
        "agent-config.set_yaml", {})
    max_challenges = max(1, min(8, to_int(raw_cfg.get("max_challenges"), 3)))
    # Python ON is this generator's own default (a challenger that can't run
    # code can only opine) — the engine-wide default is off.
    enable_python = to_bool(raw_cfg.get("enable_python_tool"), True)
    user_system = (tag_values.get("system_prompt") or "").strip()

    candidates = list(gen.input_groups().items())
    if not candidates:
        raise Exception("Challenge needs at least 1 input cell.")

    prompt = (gen.prompt or "").strip()
    challenges = derive_challenges(prompt, candidates, max_challenges)
    if not challenges:
        raise Exception(
            "Nothing to challenge: give an objection in the picker prompt, or "
            "attach candidates that carry an assumptions.ledger (agent-produced "
            "cells record one by default) so challenges can be derived from "
            "their recorded assumptions."
        )
    challenges, candidates = _cap_fanout(challenges, candidates)

    gen.phase("running", f"{len(challenges)} challenge(s) × {len(candidates)} candidate(s)")
    gen.status(f"Challenging {len(candidates)} candidate(s)…")

    system = (
        (user_system + "\n\n" if user_system else "")
        + "You are an adversarial reviewer trying to REFUTE a candidate solution "
        "against one specific challenge. The candidate's files are in your "
        "workspace — read them, and when code execution is available, RUN "
        "things: a reproduction (commands + observed output) beats an argument. "
        "Default to `inconclusive` unless you have concrete evidence either "
        "way; `failed` requires evidence of the break, `survived` requires "
        "evidence of a real attempt that didn't break it. Never pad evidence."
    )

    # Fold the tag into the one-shot probe config and VALIDATE it parent-side
    # (oneshot_tag_values raises here, before the fan-out spends a single call,
    # and reconciles a claude-terminal tag to the claude-agent-sdk backend so
    # auth=claude_code survives the mode override). The probe's own companion
    # ledger is meta-bookkeeping — off — but its trace is reproduction evidence
    # the agent now writes regardless.
    probe_config = {"agent-config.set_yaml": oneshot_tag_values(
        tag_values,
        system_prompt=system,
        enable_file_tools=True,
        enable_python_tool=enable_python,
        output_schema=ChallengeVerdict.model_json_schema(),
        ledger=False,
    )}

    pairs = [(ch, label, files) for ch in challenges for label, files in candidates]
    # Concurrent fan-out (a gather over gen.call would serialize on the bridge's
    # single IPC lock and spuriously time out successful probes queued behind
    # slow ones); raises gen.Cancelled on a user stop.
    specs = [{
        # Seed only the candidate's own material, NOT its _agent/ bookkeeping:
        # a stale _agent/output.json carried from a prior agent run would be
        # read back as THIS probe's verdict when the model's reply is
        # unparseable (the mined statement is already in the challenge text).
        "inputs": {p: c for p, c in files.items() if not p.startswith("_agent/")},
        "prompt": (
            f"## Candidate `{label}`\n\n(its files are in your workspace)\n\n"
            f"## The challenge\n\n{ch['text']}\n\n"
            "Attack this candidate on exactly this challenge and produce a ChallengeVerdict."
        ),
        "config": probe_config,
    } for ch, label, files in pairs]
    runs = await gather_agent_calls(specs, timeout=600)

    results: list[dict] = []
    traces: dict[str, str] = {}
    for (ch, label, _files), result in zip(pairs, runs):
        base = {"challenge_id": ch["id"], "candidate": label,
                "user": {"status": "unmarked", "note": "", "marked_at": None}}
        if not result.ok:
            results.append({**base, "outcome": "error", "evidence": [], "reproduction": None,
                            "reasoning": "", "error": result.error or "challenge run failed"})
            continue
        raw = result.files.get("_agent/output.json")
        try:
            verdict = ChallengeVerdict(**json.loads(raw))
        except Exception as e:  # noqa: BLE001
            results.append({**base, "outcome": "error", "evidence": [], "reproduction": None,
                            "reasoning": "", "error": f"no parseable verdict: {e}"})
            continue
        row = {
            **base,
            "outcome": verdict.outcome,
            "evidence": [e.model_dump() for e in verdict.evidence],
            "reproduction": verdict.reproduction,
            "reasoning": verdict.reasoning,
        }
        # Promote the probe's trace as auditable reproduction evidence — but
        # only for actual breaks, to keep the report cell small: a `failed`
        # verdict is the one a human will want to reconstruct.
        if verdict.outcome == "failed":
            trace = result.files.get("_agent/trace.json")
            if trace:
                path = f"evidence/{ch['id']}__{label}.trace.json"
                traces[path] = trace
                row["trace"] = path
        results.append(row)

    report = build_report(
        prompt=prompt,
        candidates=[label for label, _ in candidates],
        challenges=challenges,
        results=results,
    )

    # The report cell is the record, not a merge — drop the hydrated inputs.
    for path in list(gen.list_files()):
        gen.delete_file(path)
    gen.update_file(REPORT_FILE, json.dumps(report, indent=2) + "\n")
    gen.update_file(REPORT_MD, report_to_md(report))
    for path, content in traces.items():
        gen.update_file(path, content)

    fails = sum(1 for r in report["results"] if r["outcome"] == "failed")
    survived = sum(1 for r in report["results"] if r["outcome"] == "survived")
    other = len(report["results"]) - fails - survived
    await gen.update(
        name=f"Challenge × {len(candidates)}",
        summary=f"{fails} failed · {survived} survived · {other} inconclusive/error",
        pinned=REPORT_FILE,
    )


# ──────────────────────────────────────────────────────────────────────
# Challenge derivation — deterministic, from the prompt or the ledgers
# ──────────────────────────────────────────────────────────────────────


def derive_challenges(prompt: str, candidates: list, max_challenges: int) -> list[dict]:
    """The challenge set. A user objection is one challenge; a blank prompt
    mines the candidates' assumption ledgers — differential seams first (the
    live disagreements), then fact-kind claims (definitionally testable),
    then unstated doctrines (acted on but never chosen)."""
    if prompt:
        return [{"id": "user-1", "text": prompt, "source": "user"}]

    mined: list[tuple[tuple, dict]] = []
    seen: set[str] = set()
    for _label, files in candidates:
        for doc in _ledger_docs(files):
            for row in doc.get("commitments", []):
                statement = (row.get("statement") or "").strip()
                key = " ".join(statement.lower().split())
                if not key or key in seen:
                    continue
                is_seam = row.get("differential") == "seam"
                is_fact = row.get("kind") == "fact"
                is_doctrine = any(
                    pc.get("link") == "unstated_doctrine"
                    for pc in (row.get("per_candidate") or {}).values()
                )
                if is_seam:
                    text = (
                        "The candidates disagree on this territory: "
                        f"{row.get('seam_note') or statement}. Determine which stance "
                        "THIS candidate takes and whether it survives scrutiny."
                    )
                    priority = 0
                elif is_fact:
                    text = f"Test whether this recorded assumption actually holds here: {statement}"
                    priority = 1
                elif is_doctrine:
                    text = (
                        "This candidate enacts an assumption nobody explicitly chose: "
                        f"{statement}. Probe whether it is safe to live with."
                    )
                    priority = 2
                else:
                    continue
                seen.add(key)
                # Mint a fresh, run-unique id — never reuse the ledger row id:
                # `cm-N` is minted PER ledger doc, so candidate A's `cm-1` and
                # candidate B's `cm-1` are DIFFERENT commitments that would
                # otherwise collide into one report bucket (and one React key).
                # Provenance survives in commitment_id/statement.
                mined.append(((priority, row.get("rank", 999)), {
                    "id": f"ch-{len(mined) + 1}",
                    "text": text,
                    "source": "ledger",
                    "kind": row.get("kind"),
                    "commitment_id": row.get("id"),
                    "statement": statement,
                }))
    mined.sort(key=lambda pair: pair[0])
    return [ch for _, ch in mined[:max_challenges]]


def _ledger_docs(files: dict) -> list[dict]:
    docs: list[dict] = []
    for path, content in sorted(files.items()):
        if not path.endswith(".ledger") or not isinstance(content, str):
            continue
        try:
            doc = json.loads(content)
        except Exception:  # noqa: BLE001
            continue
        if isinstance(doc, dict) and doc.get("format") == ledger_mod.LEDGER_FORMAT:
            docs.append(doc)
    return docs


def _cap_fanout(challenges: list, candidates: list) -> tuple[list, list]:
    """Hold the total (challenges × candidates) agent-run count under
    ``_MAX_RUNS``. Drop the lowest-priority challenges first; but when ONE
    challenge already fans out over more candidates than the cap allows (every
    user-prompt run is a single challenge), the challenge dimension can't be
    trimmed further, so drop the excess candidates too — otherwise the cap is
    silently ignored and up to 99 adversarial agents launch at once."""
    kept = list(challenges)
    n = len(candidates)
    while len(kept) > 1 and len(kept) * n > _MAX_RUNS:
        dropped = kept.pop()
        gen.log(f"[challenge] fan-out cap: dropping challenge {dropped['id']!r} "
                f"({len(kept) + 1}×{n} > {_MAX_RUNS} runs)")
    if len(kept) * n > _MAX_RUNS:
        keep_n = max(1, _MAX_RUNS // len(kept))
        gen.log(f"[challenge] fan-out cap: {len(kept)}×{n} > {_MAX_RUNS} runs — "
                f"keeping the first {keep_n} of {n} candidate(s)")
        candidates = candidates[:keep_n]
    return kept, candidates


# ──────────────────────────────────────────────────────────────────────
# Report assembly — deterministic, unit-testable
# ──────────────────────────────────────────────────────────────────────


def build_report(*, prompt: str, candidates: list, challenges: list, results: list) -> dict:
    """Failures first, at both levels: challenges ordered by failure count
    (desc), each challenge's results worst-outcome-first."""
    by_challenge: dict = {ch["id"]: [] for ch in challenges}
    for r in results:
        by_challenge.setdefault(r["challenge_id"], []).append(r)

    def fail_count(ch: dict) -> int:
        return sum(1 for r in by_challenge.get(ch["id"], []) if r["outcome"] == "failed")

    ordered_challenges = sorted(challenges, key=lambda ch: (-fail_count(ch), ch["id"]))
    ordered_results: list[dict] = []
    for ch in ordered_challenges:
        ordered_results.extend(sorted(
            by_challenge.get(ch["id"], []),
            key=lambda r: (_OUTCOME_ORDER.get(r["outcome"], 9), r["candidate"]),
        ))
    return {
        "format": REPORT_FORMAT,
        "version": REPORT_VERSION,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "context": prompt or "",
        "candidates": [{"label": label} for label in candidates],
        "challenges": [
            {k: v for k, v in ch.items() if k != "statement"} for ch in ordered_challenges
        ],
        "results": ordered_results,
    }


_OUTCOME_BADGE = {"failed": "✗", "survived": "✓", "inconclusive": "?", "error": "⚠"}


def report_to_md(report: dict) -> str:
    lines = ["# Challenge report", ""]
    fails = sum(1 for r in report["results"] if r["outcome"] == "failed")
    lines.append(
        f"_{len(report['challenges'])} challenge(s) × "
        f"{len(report['candidates'])} candidate(s) · {fails} failure(s)_"
    )
    lines.append("")
    if report.get("context"):
        lines += [f"**Objection:** {report['context']}", ""]
    results = report["results"]
    for ch in report["challenges"]:
        origin = f" _(from recorded assumption `{ch['commitment_id']}`)_" if ch.get("commitment_id") else ""
        lines += [f"## {ch['id']} · {ch['text']}{origin}", ""]
        for r in [r for r in results if r["challenge_id"] == ch["id"]]:
            badge = _OUTCOME_BADGE.get(r["outcome"], "?")
            lines.append(f"### `{r['candidate']}` — {badge} {r['outcome']}")
            if r.get("error"):
                lines.append(f"- run error: {r['error']}")
            if r.get("reasoning"):
                lines.append(f"- {r['reasoning']}")
            for e in r.get("evidence", []):
                lines.append(f"- `{e.get('ref', '')}` — {e.get('detail', '')}")
            if r.get("reproduction"):
                lines += ["", "```", r["reproduction"], "```"]
            if r.get("trace"):
                lines.append(f"- full agent trace: `{r['trace']}`")
            lines.append("")
    return "\n".join(lines) + "\n"


if __name__ == "__main__":
    gen.main(run)
