# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic"]
# ///
"""Evaluate Best — independent judgments, then final pick.

Two phases:

  1. Each candidate cell is judged independently (parallel agent runs via
     ``gen.call("agent", ...)``). Output: score + strengths/weaknesses
     per candidate — plus per-axis scores when the candidates carry an
     accepted trade-off frame (``frame.axes``): the USER'S axes become the
     rubric, not axes the judge invents.
  2. A second agent sees the judgments and picks one winner, stating what
     the winner **sacrifices** on the other axes.

Judges see evidence, not just prose: each candidate's recorded assumptions
(its ``assumptions.ledger`` seams and unstated doctrines) are surfaced as
structured context, and an input cell that is a **challenge report**
(``challenges.challenge``, from the ``challenge`` generator) is detected by
format, excluded from the candidates, and its survived/failed results fed
to every judge and the pick pass.

Output cell: the winning cell's files carried over verbatim +
``results.scoreboard.json`` (rendered by the table renderer, pinned),
``why_picked.md`` (the pick reasoning), ``judgments.md`` (the prose
scoreboard), and the pick decision's own ``assumptions.ledger``.
"""
from __future__ import annotations

import json
import os
import sys

from pydantic import BaseModel, Field

import gen

# The shared _* cell-folders are SIBLINGS at run time (materialised into
# the cell); in the repo/tests they live at the asset root, one level above
# this generator's cell parent folder. Insert both.
_here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(_here))
sys.path.insert(0, os.path.dirname(os.path.dirname(_here)))
from _agent_shared import (  # noqa: E402
    gather_agent_calls,
    oneshot_tag_values,
    parse_agent_config,
)
from _agent_shared import ledger as ledger_mod  # noqa: E402

_FRAME_FORMAT = "collimate.axes-frame"
_CHALLENGE_FORMAT = "collimate.challenge-report"


class Judgment(BaseModel):
    score: int = Field(ge=0, le=100, description="0–100, how well this candidate meets the criteria.")
    axis_scores: dict[str, int] = Field(
        default_factory=dict,
        description="When a rubric is given: 0–100 per rubric axis, keyed EXACTLY by the axis names.",
    )
    strengths: list[str] = Field(default_factory=list)
    weaknesses: list[str] = Field(default_factory=list)
    summary: str = Field(description="1–2 sentence overall take.")


class Pick(BaseModel):
    winner: str = Field(description="Exact label of the winning candidate.")
    reasoning: str = Field(description="2–6 sentences on why this candidate won.")


async def run() -> None:
    raw = gen.config("config.set_yaml")
    # The parent-generator convention: agent settings come from ONE named
    # config tag on the agent generator (blank → its defaults); this
    # generator overrides only what it has opinions about below.
    tag_values = gen.tag_config("agent", raw.get("agent_config_tag")).get(
        "agent-config.set_yaml", {})
    cfg = parse_agent_config(tag_values)
    user_system = (tag_values.get("system_prompt") or "").strip()
    criteria = (gen.prompt or "").strip()
    if not criteria:
        raise Exception("Describe the criteria for 'best' in the picker prompt.")
    gen.log(f"[evaluate-best] agent: {cfg['backend']} · {cfg['model']}")

    candidates, challenge_reports = _split_inputs(gen.input_groups())
    if len(candidates) < 2:
        raise Exception(
            "Evaluate Best needs at least 2 candidate input cells "
            "(challenge-report cells are evidence, not candidates)."
        )
    rubric = _frame_rubric(candidates)

    gen.status(f"Judging {len(candidates)} candidates…")
    if challenge_reports:
        gen.log(f"[evaluate-best] using {len(challenge_reports)} challenge report(s) as evidence")
    if rubric:
        gen.log(f"[evaluate-best] rubric from accepted frame: {rubric}")

    def _agent_config(sys_prompt: str, schema: dict, *, ledger=None) -> dict:
        # oneshot_tag_values validates the FOLDED config parent-side (and
        # reconciles container-mode tags), so a tag the child would reject
        # fails here — before the fan-out spends a single call. Judges and
        # the pick are pure text evaluations over INLINED previews: no file,
        # python, or cross-cell tools (each is waste plus a prompt-injection
        # surface — the previews carry untrusted candidate content).
        overrides: dict = {
            "system_prompt": sys_prompt,
            "output_schema": schema,
            "enable_file_tools": False,
            "enable_python_tool": False,
            "exposure": "none",
        }
        if ledger is not None:
            overrides["ledger"] = ledger
        return {"agent-config.set_yaml": oneshot_tag_values(tag_values, **overrides)}

    def _judge_prompt(label: str, files: dict[str, str]) -> str:
        preview = _preview_files(files)
        sections = [f"## Criteria\n\n{criteria}"]
        if rubric:
            sections.append(
                "## Rubric\n\nScore this candidate 0–100 on EACH of these axes "
                "(the user's accepted trade-off frame — use the names exactly as "
                "`axis_scores` keys):\n" + "\n".join(f"- {a}" for a in rubric)
            )
        sections.append(f"## Candidate `{label}`\n\n{preview}")
        highlights = _ledger_highlights(files)
        if highlights:
            sections.append(
                "## Recorded assumptions for this candidate\n\n"
                "(from its assumptions ledger — weigh unstated doctrines and "
                f"live seams, they are where the cost hides)\n\n{highlights}"
            )
        evidence = _challenge_evidence(
            challenge_reports, label,
            all_labels=[lb for lb, _ in candidates],
        )
        if evidence:
            sections.append(
                "## Challenge evidence for this candidate\n\n"
                "(adversarial runs — a failed challenge is concrete evidence, "
                f"not an opinion)\n\n{evidence}"
            )
        return "\n\n".join(sections) + "\n\nProduce a Judgment. Be specific."

    # Each judge is an independent agent sub-run with its own workspace,
    # fanned out CONCURRENTLY via gather_agent_calls (a gather over gen.call
    # would serialize on the bridge lock). Judges are throwaway structured
    # calls — their assumptions ledger is discarded, so don't pay for it
    # (the pick call below keeps it: its ledger IS promoted).
    judge_specs = [{
        "prompt": _judge_prompt(label, files),
        "config": _agent_config(user_system, Judgment.model_json_schema(), ledger=False),
    } for label, files in candidates]
    judge_runs = await gather_agent_calls(judge_specs, timeout=600)
    ranked: list[tuple[str, Judgment | Exception]] = []
    for (label, _files), result in zip(candidates, judge_runs):
        if not result.ok:
            ranked.append((label, Exception(result.error or f"judge run failed for {label}")))
            continue
        try:
            j = result.structured(Judgment)   # None if absent; raises on schema mismatch
        except Exception as e:  # noqa: BLE001
            ranked.append((label, Exception(f"judge output failed validation for {label}: {e}")))
            continue
        if j is None:
            ranked.append((label, Exception(f"judge returned no structured output for {label}")))
            continue
        ranked.append((label, j))

    # Degrade only on PARTIAL failure. If every judgment failed there is
    # nothing to rank — "Winner: <first input>" would be a fabrication.
    if not any(isinstance(j, Judgment) for _label, j in ranked):
        first_err = next((str(j) for _label, j in ranked if isinstance(j, Exception)), "unknown")
        raise Exception(f"every judgment failed — first error: {first_err}")

    gen.status("Picking winner…")

    pick_system = (
        (user_system + "\n\n" if user_system else "")
        + "You pick a single winner from the independent judgments below. "
        "Weigh the criteria and scores together — and treat challenge evidence "
        "as harder currency than prose: a reproduced failure outweighs an "
        "eloquent summary. In your reasoning, state what the winner SACRIFICES "
        "relative to the alternatives; a pick that pretends to win everywhere "
        "is not credible."
    )

    async def pick() -> tuple[Pick, dict]:
        lines = [f"## Criteria\n\n{criteria}\n", "## Judgments", ""]
        for label, jmt in ranked:
            if isinstance(jmt, Exception):
                lines.append(f"### `{label}` — (judgment failed: {jmt})")
                lines.append("")
                continue
            axis_bits = (
                " · ".join(f"{k}: {v}" for k, v in jmt.axis_scores.items())
                if jmt.axis_scores else ""
            )
            lines.append(
                f"### `{label}` — score {jmt.score}"
                + (f" ({axis_bits})" if axis_bits else "")
                + "\n\n"
                + (f"**Strengths:** {'; '.join(jmt.strengths)}\n\n" if jmt.strengths else "")
                + (f"**Weaknesses:** {'; '.join(jmt.weaknesses)}\n\n" if jmt.weaknesses else "")
                + jmt.summary
            )
            lines.append("")
        for label, _ in ranked:
            evidence = _challenge_evidence(
                challenge_reports, label,
                all_labels=[lb for lb, _ in ranked],
            )
            if evidence:
                lines += [f"## Challenge evidence — `{label}`", "", evidence, ""]
        pick_msg = "\n".join(lines) + "\n\nPick one winner. The winner label MUST be one from the list."
        result = await gen.call(
            "agent",
            prompt=pick_msg,
            # ledger ON: the pick decision's own ledger is promoted (pick.assumptions.ledger).
            config=_agent_config(pick_system, Pick.model_json_schema(), ledger=True),
            timeout=300,
        )
        if not result.ok:
            raise Exception(result.error or "pick run failed")
        p = result.structured(Pick)
        if p is None:
            raise Exception("pick agent returned no structured output")
        return p, result.files

    pick_ledger = ""
    try:
        p, pick_files = await pick()
        matched = _match_winner(p.winner, ranked)
        if matched is not None:
            winner = matched
            reasoning = p.reasoning
            pick_ledger = pick_files.get("_agent/assumptions.ledger") or ""
        else:
            # An unmatchable label means the pick's prose argues for a
            # candidate we can't identify — keeping its reasoning (and
            # ledger) while promoting a DIFFERENT winner would misattribute
            # both. Fall back honestly.
            gen.log(f"pick returned unknown winner label {p.winner!r} — "
                    "falling back to the highest-scoring candidate")
            winner = _heuristic_winner(ranked)
            reasoning = (
                f"Automatic pick (the pick agent named {p.winner!r}, which "
                "matches no candidate). Chose the highest-scoring candidate."
            )
    except Exception as e:
        gen.log(f"pick agent failed: {e}")
        winner = _heuristic_winner(ranked)
        reasoning = f"Automatic pick (judge call failed: `{e}`). Chose the highest-scoring candidate."

    # Drop every input file from the output stage; we'll only carry the
    # winning candidate's files forward.
    for inp in list(gen.list_files()):
        gen.delete_file(inp)

    winning_files = dict(next((fs for label, fs in candidates if label == winner), {}))
    for rel, content in winning_files.items():
        gen.update_file(rel, content)

    gen.update_file("why_picked.md", _why_md(winner, reasoning, ranked, criteria))
    gen.update_file("judgments.md", _judgments_md(ranked))
    gen.update_file(
        "results.scoreboard.json",
        json.dumps(_scoreboard(winner, reasoning, ranked, rubric), indent=2) + "\n",
    )
    if pick_ledger:
        # The pick decision's own assumptions ride with the winner — what the
        # judge claimed to weigh vs what its choice enacted. A DISTINCT path:
        # the winner's carried-forward assumptions.ledger is its own evidence
        # chain and must not be clobbered by the pick's.
        gen.update_file("pick.assumptions.ledger", pick_ledger)

    await gen.update(
        name=f"Winner: {winner}",
        summary=_first_line(reasoning),
        pinned="results.scoreboard.json",
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _split_inputs(groups: dict) -> tuple[list, list]:
    """(candidates, challenge_reports). An input cell whose files include a
    challenge report (by format, not filename) is evidence, not a candidate."""
    candidates: list = []
    reports: list = []
    for label, files in groups.items():
        report = next(
            (doc for doc in (_json_doc(c) for c in files.values())
             if isinstance(doc, dict) and doc.get("format") == _CHALLENGE_FORMAT),
            None,
        )
        if report is not None:
            reports.append(report)
        else:
            candidates.append((label, files))
    return candidates, reports


def _json_doc(content):
    if not isinstance(content, str) or not content.lstrip().startswith("{"):
        return None
    try:
        return json.loads(content)
    except Exception:  # noqa: BLE001
        return None


def _frame_rubric(candidates: list) -> list[str]:
    """Kept, non-standing axis names from the first accepted ``frame.axes``
    a candidate carries — the USER'S chosen axes become the rubric."""
    for _label, files in candidates:
        for path, content in sorted(files.items()):
            if not path.endswith(".axes"):
                continue
            doc = _json_doc(content)
            if (isinstance(doc, dict) and doc.get("format") == _FRAME_FORMAT
                    and doc.get("status") == "accepted"):
                return [
                    a["name"] for a in doc.get("axes", [])
                    if not a.get("struck") and not a.get("standing")
                ]
    return []


def _ledger_highlights(files: dict, cap: int = 6) -> str:
    """The judgment-relevant rows of a candidate's assumptions ledger:
    live seams and unstated doctrines, in rank order."""
    lines: list[str] = []
    for path, content in sorted(files.items()):
        doc = _json_doc(content) if path.endswith(".ledger") else None
        if not (isinstance(doc, dict) and doc.get("format") == ledger_mod.LEDGER_FORMAT):
            continue
        for row in doc.get("commitments", []):
            is_seam = row.get("differential") == "seam"
            is_doctrine = any(
                pc.get("link") == "unstated_doctrine"
                for pc in (row.get("per_candidate") or {}).values()
            )
            if not (is_seam or is_doctrine):
                continue
            tag = "LIVE SEAM" if is_seam else "unstated doctrine"
            lines.append(f"- [{tag} · {row.get('kind', '')}] {row.get('statement', '')}")
            if row.get("seam_note"):
                lines.append(f"  - {row['seam_note']}")
            if len(lines) >= cap * 2:
                break
    return "\n".join(lines[: cap * 2])


def _norm_label(label: str) -> str:
    return "".join(c for c in (label or "").lower() if c.isalnum())


def _match_winner(raw_label: str, ranked: list) -> str | None:
    """Resolve the pick agent's winner label to a real candidate label:
    exact after stripping decoration, then UNIQUE normalized equality, then
    UNIQUE normalized containment. ``None`` when nothing matches uniquely —
    a guessy match would attach the pick's reasoning to the wrong cell."""
    cand = (raw_label or "").strip().strip("`'\" ")
    for label, _ in ranked:
        if label == cand:
            return label
    norm = _norm_label(cand)
    if not norm:
        return None
    exact = [label for label, _ in ranked if _norm_label(label) == norm]
    if len(exact) == 1:
        return exact[0]
    contained = [
        label for label, _ in ranked
        if norm in _norm_label(label) or _norm_label(label) in norm
    ]
    return contained[0] if len(contained) == 1 else None


def _challenge_evidence(reports: list, label: str, *, all_labels: list | None = None) -> str:
    """This candidate's rows from the challenge reports. Input-cell labels
    (``NN_slug``) and report labels (the original cell names) differ, so
    matching is normalized: exact equality first, containment only when it is
    UNAMBIGUOUS — a row whose candidate name contains two of our labels (or
    vice versa) is dropped with a log line rather than cross-attached."""
    me = _norm_label(label)
    others = [
        _norm_label(x) for x in (all_labels or [])
        if _norm_label(x) and _norm_label(x) != me
    ]

    def _matches(them: str) -> bool:
        if not me or not them:
            return False
        if them == me:
            return True
        if me not in them and them not in me:
            return False
        # Containment must single us out among ALL candidate labels.
        rivals = [o for o in others if o in them or them in o]
        if rivals:
            gen.log(f"[evaluate-best] ambiguous challenge-evidence label "
                    f"{them!r} matches {label!r} and {len(rivals)} other "
                    "candidate(s) — dropping the row")
            return False
        return True

    out: list[str] = []
    for report in reports:
        by_id = {ch.get("id"): ch for ch in report.get("challenges", [])}
        for r in report.get("results", []):
            if not _matches(_norm_label(r.get("candidate", ""))):
                continue
            ch = by_id.get(r.get("challenge_id"), {})
            out.append(f"- **{r.get('outcome', '?').upper()}** — {ch.get('text', r.get('challenge_id', ''))}")
            if r.get("reasoning"):
                out.append(f"  - {r['reasoning']}")
            for e in (r.get("evidence") or [])[:3]:
                out.append(f"  - `{e.get('ref', '')}` — {e.get('detail', '')}")
    return "\n".join(out)


def _scoreboard(winner: str, reasoning: str, ranked: list, rubric: list) -> dict:
    """The table renderer's ``.scoreboard.json`` shape."""
    rows = []
    for label, j in sorted(
        ranked,
        key=lambda pair: pair[1].score if isinstance(pair[1], Judgment) else -1,
        reverse=True,
    ):
        if isinstance(j, Exception):
            rows.append({"name": label, "scores": {}, "total": "", "notes": f"judgment failed: {j}"})
            continue
        scores = {axis: j.axis_scores[axis] for axis in rubric if axis in j.axis_scores}
        rows.append({"name": label, "scores": scores, "total": j.score, "notes": j.summary})
    return {"rubric": list(rubric), "rows": rows, "winner": winner, "verdict": reasoning}


def _preview_files(
    files: dict, max_bytes: int = 4000,
    total_budget: int = 60_000, max_files: int = 40,
) -> str:
    """Inline previews with three guards: binary files become a placeholder
    line (bytes would render as garbage and blow the prompt), a per-file cap,
    and a TOTAL budget + file count so a many-file candidate degrades to a
    named omission list instead of silently overflowing the judge's context."""
    if not files:
        return "_(no files)_"
    out: list[str] = []
    omitted: list[str] = []
    used = 0
    shown = 0
    for p in sorted(files):
        content = files[p]
        if not isinstance(content, str):
            out.append(f"### `{p}`\n\n_(binary file, {len(content)} bytes — not shown)_")
            continue
        if shown >= max_files or used >= total_budget:
            omitted.append(p)
            continue
        full_len = len(content)
        if full_len > max_bytes:
            content = content[:max_bytes] + f"\n\n_(truncated — full size {full_len} bytes)_"
        used += len(content)
        shown += 1
        out.append(f"### `{p}`\n\n```\n{content}\n```")
    if omitted:
        names = ", ".join(f"`{p}`" for p in omitted[:10])
        more = ", …" if len(omitted) > 10 else ""
        out.append(f"_({len(omitted)} more file(s) omitted from this preview: {names}{more})_")
    return "\n\n".join(out)


def _heuristic_winner(ranked: list[tuple[str, Judgment | Exception]]) -> str:
    valid = [(label, j) for label, j in ranked if isinstance(j, Judgment)]
    if valid:
        return max(valid, key=lambda pair: pair[1].score)[0]
    return ranked[0][0] if ranked else "unknown"


def _judgments_md(ranked: list[tuple[str, Judgment | Exception]]) -> str:
    lines = ["# Independent judgments", ""]
    for label, j in sorted(
        ranked,
        key=lambda pair: pair[1].score if isinstance(pair[1], Judgment) else -1,
        reverse=True,
    ):
        if isinstance(j, Exception):
            lines += [f"## `{label}` — error", "", f"```\n{j}\n```", ""]
            continue
        lines += [f"## `{label}` — score {j.score}", "", j.summary, ""]
        if j.strengths:
            lines.append("**Strengths**")
            lines += [f"- {s}" for s in j.strengths]
            lines.append("")
        if j.weaknesses:
            lines.append("**Weaknesses**")
            lines += [f"- {w}" for w in j.weaknesses]
            lines.append("")
    return "\n".join(lines) + "\n"


def _why_md(
    winner: str, reasoning: str, ranked: list[tuple[str, Judgment | Exception]], criteria: str,
) -> str:
    lines = [
        f"# Winner: `{winner}`",
        "",
        "## Why",
        "",
        reasoning.strip(),
        "",
        "## Criteria",
        "",
        criteria.strip(),
        "",
        "## Scoreboard",
        "",
    ]
    for label, j in sorted(
        ranked,
        key=lambda pair: pair[1].score if isinstance(pair[1], Judgment) else -1,
        reverse=True,
    ):
        if isinstance(j, Exception):
            lines.append(f"- `{label}` — judgment failed")
        else:
            marker = "**" if label == winner else ""
            lines.append(f"- {marker}`{label}`{marker} — score {j.score}")
    return "\n".join(lines) + "\n"


def _first_line(text: str, limit: int = 120) -> str:
    text = (text or "").strip()
    if not text:
        return ""
    first = text.splitlines()[0]
    return first[:limit] + ("…" if len(first) > limit else "")


if __name__ == "__main__":
    gen.main(run)
