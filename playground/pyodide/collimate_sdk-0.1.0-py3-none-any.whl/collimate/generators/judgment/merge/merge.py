# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic"]
# ///
"""Merge — union the files of 2+ input cells into a single output cell.

Multi-input runs are hydrated as ``inputs/NN_slug/`` subfolders where the
NN prefix preserves picker order (top = smallest number). Topmost wins on
filename collisions — with one judgment-preserving exception: colliding
``*.ledger`` assumptions ledgers are UNIONED (deterministically, via
``ledger_mod.merge_ledgers`` — no LLM) instead of clobbered, so merging
candidates never destroys their recorded-assumptions record. No LLM
anywhere; the demo ``demo/generators/merge`` mirror keeps the plain union.
"""
from __future__ import annotations

import json
import os
import sys

import gen

# The shared _* cell-folders are SIBLINGS at run time (materialised into
# the cell); in the repo/tests they live at the asset root, one level above
# this generator's cell parent folder. Insert both.
_here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(_here))
sys.path.insert(0, os.path.dirname(os.path.dirname(_here)))
from _agent_shared import ledger as ledger_mod  # noqa: E402


async def run() -> None:
    groups = gen.input_groups()
    if len(groups) < 2:
        raise Exception("Merge needs at least 2 input cells.")

    origin: dict[str, str] = {}
    overwritten: list[tuple[str, str, str]] = []
    written: list[str] = []
    ledger_versions: dict[str, dict[str, dict]] = {}   # rel -> {input label: doc}

    for label, files in groups.items():
        for rel, content in files.items():
            doc = _ledger_doc(rel, content)
            if doc is not None:
                ledger_versions.setdefault(rel, {})[label] = doc
            if rel in origin:
                if gen.read_file(rel) != content:
                    overwritten.append((rel, origin[rel], label))
                continue
            gen.update_file(rel, content)
            origin[rel] = label
            written.append(rel)

    # Colliding assumptions ledgers: union, don't clobber — the merged doc
    # keeps every input's per-candidate columns (labels = input cells).
    merged_ledgers: list[str] = []
    for rel, docs in sorted(ledger_versions.items()):
        if len(docs) < 2:
            continue
        merged = ledger_mod.merge_ledgers(docs)
        gen.update_file(rel, ledger_mod.dumps_ledger(merged))
        merged_ledgers.append(rel)
        overwritten = [(r, w, l) for r, w, l in overwritten if r != rel]
        origin[rel] = f"union of {len(docs)} inputs"

    lines = [f"# Merge — {len(groups)} cells, {len(written)} file(s)", ""]
    lines.append("## Origins")
    lines.append("")
    for rel in sorted(written):
        lines.append(f"- `{rel}` ← `{origin[rel]}`")
    if merged_ledgers:
        lines.append("")
        lines.append("## Assumptions ledgers unioned (not clobbered)")
        lines.append("")
        for rel in merged_ledgers:
            lines.append(f"- `{rel}` — one per-candidate column per input cell")
    if overwritten:
        lines.append("")
        lines.append("## Shadowed by topmost input")
        lines.append("")
        for rel, winner, loser in overwritten:
            lines.append(f"- `{rel}` — `{winner}` won over `{loser}`")
    gen.update_file("_merge.md", "\n".join(lines) + "\n")

    await gen.update(
        name=f"Merge × {len(groups)}",
        summary=f"{len(written)} files from {len(groups)} cells",
        pinned="_merge.md",
    )


def _ledger_doc(rel: str, content) -> dict | None:
    if not rel.endswith(".ledger") or not isinstance(content, str):
        return None
    try:
        doc = json.loads(content)
    except Exception:  # noqa: BLE001
        return None
    if isinstance(doc, dict) and doc.get("format") == ledger_mod.LEDGER_FORMAT:
        return doc
    return None


if __name__ == "__main__":
    gen.main(run)
