# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic", "pydantic-ai", "claude-agent-sdk"]
# ///
"""Seed Ideas — fan out N idea directions along a user-specified axis.

Multi-cell output: phase 1 seeds N short labels in one agent call;
phase 2 runs N agents in parallel to produce the idea bodies; phase 3
creates **N stack cells**, one per idea (carry-through files land in
each, along with that worker's promoted ``assumptions.ledger``); phase 4
writes the run's primary cell as a single ``index.md`` listing every
idea + its one-line summary — plus the merged cross-idea assumptions
ledger with its differential (shared commitments are background;
commitments the ideas disagree on are the live seams).
"""
from __future__ import annotations

import json
import os
import re
import sys

from pydantic import BaseModel, Field

import gen

# The shared _* cell-folders are SIBLINGS at run time (materialised into
# the cell); in the repo/tests they live at the asset root, one level above
# this generator's cell parent folder. Insert both.
_here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(_here))
sys.path.insert(0, os.path.dirname(os.path.dirname(_here)))
from _agent_shared import (  # noqa: E402
    gather_agent_calls,
    oneshot_tag_values,
    parse_agent_config,
)
from _agent_shared import ledger as ledger_mod  # noqa: E402


class Seeds(BaseModel):
    labels: list[str] = Field(
        description="Exactly N short labels (2–4 words each) for the distinct ideas."
    )


async def run() -> None:
    raw = gen.config("config.set_yaml")
    # The parent-generator convention: agent settings come from ONE named
    # config tag on the agent generator (blank → its defaults); this
    # generator overrides only what it has opinions about below.
    tag_values = gen.tag_config("agent", raw.get("agent_config_tag")).get(
        "agent-config.set_yaml", {})
    cfg = parse_agent_config(tag_values)   # normalized view: logging + ledger settings
    count = max(2, min(12, _int(raw.get("num_ideas"), default=4)))
    user_system = (tag_values.get("system_prompt") or "").strip()
    axis = (gen.prompt or "").strip()
    if not axis:
        raise Exception("Describe the axis to explore in the picker prompt.")

    gen.log(f"[seed-ideas] agent: {cfg['backend']} · {cfg['model']}"
            + (f" · tag {raw.get('agent_config_tag')!r}" if (raw.get("agent_config_tag") or "").strip() else ""))
    carry = {p: gen.read_file(p) for p in gen.list_files()}

    def agent_config(*, system_prompt: str, **extra) -> dict:
        # oneshot_tag_values validates the FOLDED config parent-side (and
        # reconciles container-mode tags), so a tag the child would reject
        # fails here — before the fan-out spends a single call.
        return {"agent-config.set_yaml": oneshot_tag_values(
            tag_values, system_prompt=system_prompt, **extra)}

    gen.status(f"Seeding {count} idea directions…")

    # An accepted trade-off frame in the carry (from axes_first) turns this
    # into the go-wide-again move INSIDE a chosen frame: directions are pinned
    # to regions of the user's axis space instead of free-floating.
    frame = _accepted_frame(carry)
    facts = ledger_mod.verified_facts_from_files(carry)

    seed_system = (
        (user_system + "\n\n" if user_system else "")
        + "You generate genuinely distinct ideas along the axis the user "
        "describes. Favor breadth over incremental variations."
        + f"\n\nReturn exactly {count} short labels (2–4 words each), "
        "genuinely distinct directions along the axis. Distinct means a "
        "different MECHANISM, not the same idea with different adjectives."
    )
    if frame:
        seed_system += (
            "\n\nThe user has accepted this trade-off frame — pin each "
            "direction to a region of it (single axes first, then "
            "combinations):\n" + _frame_summary(frame)
        )
    if carry:
        seed_system += (
            "\n\nInput files for reference (do not repeat their content):\n"
            + "\n".join(f"- `{p}`" for p in sorted(carry))
        )

    # Hold the model to the requested cardinality in the schema itself.
    seeds_schema = Seeds.model_json_schema()
    seeds_schema.get("properties", {}).get("labels", {}).update(
        {"minItems": count, "maxItems": count},
    )

    async def _seed_once() -> tuple[list[str], str]:
        """(labels, reply-head) — labels empty on any failure. The seed call
        is a throwaway structured turn: no ledger pass, no file tools."""
        seed_run = await gen.call(
            "agent",
            prompt=f"Axis and requirements:\n\n{axis}",
            config=agent_config(
                system_prompt=seed_system,
                output_schema=seeds_schema,
                ledger=False,
                enable_file_tools=False,
            ),
            timeout=300,
        )
        if not seed_run.ok:
            return [], seed_run.error or "seed agent run failed"
        text_head = seed_run.output_text.strip()[:400]
        try:
            out = seed_run.structured(Seeds)   # None if absent; raises on schema mismatch
        except Exception:  # noqa: BLE001 — malformed structured output → retry/fallback
            out = None
        if out is None:
            return [], text_head
        return [x.strip() for x in out.labels if x and x.strip()], text_head

    seeds, head = await _seed_once()
    if not seeds:
        gen.log("[seed-ideas] seed pass returned no parseable labels — retrying once")
        seeds, head = await _seed_once()
    if not seeds:
        # Burning N full builds on "Idea 1..N" placeholder labels would
        # produce N junk cells — fail honestly with the reply for diagnosis.
        raise Exception(
            "seed agent returned no parseable idea labels after a retry"
            + (f" — reply head: {head!r}" if head else "")
        )
    seeds = seeds[:count]
    if len(seeds) < count:
        gen.log(f"[seed-ideas] seed pass returned {len(seeds)} of {count} requested labels")

    gen.log(f"[seed-ideas] seeds: {seeds}")

    build_system = (
        (user_system + "\n\n" if user_system else "")
        + "Produce the seeded idea as a complete, self-contained "
        "markdown document. No preamble, no meta commentary. End with a "
        "short **Sacrifices** section: what this idea gives up relative to "
        "the other directions — an idea that pretends to win everywhere is "
        "a failed probe."
    )
    if frame:
        build_system += (
            "\n\n## Accepted trade-off frame\n\n"
            + _frame_summary(frame)
            + "\nState the sacrifices in terms of these axes."
        )
    if facts:
        build_system += (
            "\n\n## Established constraints (user-verified facts)\n\n"
            + "\n".join(f"- {f}" for f in facts)
            + "\nTreat these as ground truth; flag explicitly if the idea "
            "depends on one of them being wrong."
        )
    # Judgment artifacts stay out of the inline preview: the frame and the
    # verified facts already flow through their dedicated channels above, and
    # quoting a raw ledger would leak recorded PREFERENCES into the
    # generation prompt — the boundary is facts forward, never preferences.
    preview_paths = [
        p for p in sorted(carry)
        if isinstance(carry[p], str)
        and not p.endswith((".ledger", ".axes"))
        and not p.startswith("chats/")
    ]
    if preview_paths:
        previews = []
        for p in preview_paths:
            body = carry[p][:2000]
            if len(carry[p]) > 2000:
                body += f"\n…[truncated, full size {len(carry[p])} chars]"
            previews.append(f"### `{p}`\n\n{_fenced(body)}")
        build_system += "\n\n## Input files\n\n" + "\n\n".join(previews)

    build_prompt = (
        "Axis and requirements:\n\n{axis}\n\n"
        "Write out idea {n}: **{label}**. Just the idea body in markdown. "
        "You may call run_python to compute, analyse, or generate "
        "diagrams that strengthen the idea — any files the script "
        "creates land in this idea's cell."
    )
    build_specs = [{
        "inputs": carry,
        "prompt": build_prompt.format(axis=axis, n=i + 1, label=label),
        # ledger ON: each worker's ledger is PROMOTED into its idea cell.
        "config": agent_config(system_prompt=build_system, enable_python_tool=True, ledger=True),
    } for i, label in enumerate(seeds)]

    gen.status(f"Building {len(seeds)} ideas in parallel…")
    # Concurrent fan-out (a gather over gen.call would serialize on the
    # bridge lock); raises gen.Cancelled on a user stop instead of paying
    # for the remaining builds and emitting junk cells.
    build_runs = await gather_agent_calls(build_specs, timeout=600)

    bodies: list[str] = []
    artifacts_per_idea: list[dict] = []
    ledgers: dict[str, dict] = {}
    for i, run_res in enumerate(build_runs):
        if not run_res.ok:
            bodies.append(f"_Error: {run_res.error or 'build agent run failed'}_")
            artifacts_per_idea.append({})
            continue
        text = run_res.files.get("_agent/output.md", "") or ""
        # This idea's own files: everything outside the agent's _agent/
        # bookkeeping that is new OR that the worker EDITED (compare content,
        # not just path — a worker's edit to a carried file is its work).
        artifacts = {
            p: v
            for p, v in run_res.files.items()
            if not p.startswith("_agent/") and (p not in carry or v != carry.get(p))
        }
        # Promote the worker's assumptions ledger (and its readable md — a
        # stale carried assumptions.md would contradict the fresh ledger).
        raw_ledger = run_res.files.get(ledger_mod.LEDGER_FILE)
        if raw_ledger:
            artifacts[ledger_mod.LEDGER_PROMOTED] = raw_ledger
            md = run_res.files.get(ledger_mod.LEDGER_MD_FILE)
            if md:
                artifacts["assumptions.md"] = md
            try:
                ledgers[f"{i + 1:02d} {seeds[i]}"] = json.loads(raw_ledger)
            except Exception:  # noqa: BLE001
                pass
        bodies.append(text if isinstance(text, str) else str(text))
        artifacts_per_idea.append(artifacts)

    # Phase 3: one stack cell per idea. The carry-through files plus any
    # artifacts the agent produced are bundled into the explicit ``files``
    # arg so each side cell snapshots them deterministically.
    if gen.cancelled:
        raise gen.Cancelled("stopped before emitting idea cells")
    for seed_label, body, artifacts in zip(seeds, bodies, artifacts_per_idea):
        files = dict(carry)
        files.update(artifacts)
        if ledger_mod.LEDGER_PROMOTED in artifacts and "assumptions.md" not in artifacts:
            # Fresh ledger without a fresh md: drop the carried md rather
            # than let it misdescribe this idea's assumptions.
            files.pop("assumptions.md", None)
        files["SeedIdea.md"] = f"# {seed_label}\n\n{body}\n"
        await gen.create_stack_cell(
            seed_label[:80] or "idea",
            summary=_summary_from_body(body),
            pinned="SeedIdea.md",
            files=files,
        )

    # Phase 4: turn the placeholder into a summary index, with the merged
    # cross-idea assumptions ledger — its differential marks the seams where
    # the ideas genuinely disagree.
    if ledgers:
        gen.status("Merging assumptions ledgers…")
        try:
            merged = ledger_mod.merge_ledgers(ledgers)
            merged = await ledger_mod.compute_differential(merged, cfg)
            gen.update_file(ledger_mod.LEDGER_PROMOTED, ledger_mod.dumps_ledger(merged))
            gen.update_file("assumptions.md", ledger_mod.ledger_to_md(merged))
        except gen.Cancelled:
            raise
        except Exception as e:  # noqa: BLE001
            gen.log(f"[ledger] differential merge failed: {e}")
    else:
        # No fresh ledgers this run — carried judgment artifacts from the
        # INPUT cells must not masquerade as this run's.
        for stale in (ledger_mod.LEDGER_PROMOTED, "assumptions.md"):
            if gen.has_file(stale):
                gen.delete_file(stale)
    gen.update_file("index.md", _final_index(seeds, bodies, axis, len(seeds)))
    await gen.update(
        name=f"{len(seeds)} ideas · {cfg['backend']}",
        summary=" · ".join(seeds),
        pinned="index.md",
    )


def _fenced(content: str) -> str:
    """Code-fence ``content`` with a fence long enough that the content can't
    close it early (the CommonMark-sanctioned approach) — a carried file with
    its own ``` would otherwise break out of the preview and leak into the
    system prompt as instructions."""
    fence = "```"
    while fence in content:
        fence += "`"
    return f"{fence}\n{content}\n{fence}"


def _accepted_frame(files: dict) -> dict | None:
    """The first accepted ``collimate.axes-frame`` doc among the carry files."""
    for path in sorted(files):
        if not path.endswith(".axes"):
            continue
        content = files[path]
        if not isinstance(content, str):
            continue
        try:
            doc = json.loads(content)
        except Exception:  # noqa: BLE001
            continue
        if (isinstance(doc, dict) and doc.get("format") == "collimate.axes-frame"
                and doc.get("status") == "accepted"):
            return doc
    return None


def _frame_summary(frame: dict) -> str:
    kept = [a for a in frame.get("axes", []) if not a.get("struck") and not a.get("standing")]
    return "\n".join(
        f"- **{a['name']}** (weight {a.get('weight', 0)}) — {a.get('description', '')}"
        for a in kept
    ) + "\n"


def _final_index(seeds: list[str], bodies: list[str], axis: str, count: int) -> str:
    lines = [f"# {count} ideas along: {axis}", "", "## Generated cells", ""]
    for seed, body in zip(seeds, bodies):
        body_text = body or ""
        is_err = body_text.lstrip().lower().startswith(("_error", "**error"))
        marker = "⚠️" if is_err else "✅"
        tagline = body_text if is_err else _summary_from_body(body_text)
        if is_err:
            tagline = _first_line(tagline)
        lines.append(f"- {marker} **{seed}** — {tagline}" if tagline else f"- {marker} **{seed}**")
    lines.append("")
    lines.append("_Each idea above is its own side cell to the right of this one._")
    return "\n".join(lines) + "\n"


_INLINE_BOLD = re.compile(r"\*\*(.+?)\*\*")
_INLINE_ITAL = re.compile(r"(?<![*_])\*(?!\s)(.+?)(?<!\s)\*(?!\*)")
_INLINE_CODE = re.compile(r"`([^`]+)`")
_INLINE_LINK = re.compile(r"\[([^\]]+)\]\([^)]+\)")


def _summary_from_body(body: str | None, limit: int = 120) -> str:
    if not isinstance(body, str):
        return ""
    text = body.strip()
    if not text:
        return ""
    lower = text.lower()
    if lower.startswith("_error") or lower.startswith("**error"):
        return ""
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#"):
            continue
        cleaned = _INLINE_BOLD.sub(r"\1", line)
        cleaned = _INLINE_ITAL.sub(r"\1", cleaned)
        cleaned = _INLINE_CODE.sub(r"\1", cleaned)
        cleaned = _INLINE_LINK.sub(r"\1", cleaned)
        cleaned = cleaned.strip()
        if not cleaned:
            continue
        if len(cleaned) > limit:
            return cleaned[:limit - 1] + "…"
        return cleaned
    return ""


def _first_line(text: str, limit: int = 120) -> str:
    text = (text or "").strip()
    if not text:
        return ""
    first = text.splitlines()[0]
    return first[:limit] + ("…" if len(first) > limit else "")


def _int(raw, default: int) -> int:
    try:
        n = int(raw)
        return n if n > 0 else default
    except (TypeError, ValueError):
        return default


if __name__ == "__main__":
    gen.main(run)
