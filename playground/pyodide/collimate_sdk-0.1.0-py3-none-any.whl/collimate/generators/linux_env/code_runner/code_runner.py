# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Code Runner — run the input cell's code inside a Linux environment.

Demonstrates a *worker* driving an *environment* it never has to understand as
Docker: it spawns ``linux-env`` once, pushes the input files in, runs a command,
reads the result back, and (optionally) launches the program as a server and
shows the human a live preview — all via the generic handle verbs. Swap the
fixed command for an LLM edit/test loop and this is the "code-writing generator
that tests its own work" use case.

Commands are run through a shell, so a full command line works:
``python3 main.py && pytest -q | tee out.log``.
"""
from __future__ import annotations

import gen


async def run() -> None:
    cfg = gen.config("settings.set_yaml")
    command = (cfg.get("command") or "python3 main.py").strip()
    serve = (cfg.get("serve_command") or "").strip()
    serve_port = int(cfg.get("serve_port") or 0)
    # The parent-generator convention, non-LLM edition: the environment's
    # settings come from ONE named config tag on linux-env (blank → its
    # defaults; unknown → this run fails naming the available tags).
    env_config = gen.tag_config("linux-env", cfg.get("linux_env_config_tag"))

    # Identity first — the cell shows what it is while it works.
    await gen.update(name="Code Runner", summary=f"Running `{command}`…")

    gen.phase("spinning_up", "starting linux-env")
    async with gen.spawn("linux-env", inputs=gen.input_files(),
                         config=env_config or None) as env:
        caps = await env.capabilities()
        if caps is None:
            reason = "linux-env is not available as an environment"
            gen.log(reason)
            gen.update_file("error.md", f"# {reason}\n")
            await gen.update(name="Code Runner", summary=f"Failed: {reason}")
            return

        # Push the input cell's files into the live environment.
        await env.put_files(gen.input_files())

        # Run the command line (shell-interpreted — &&, pipes, redirects all work).
        gen.phase("running", f"running {command}")
        rc, output = await env.exec(command, cwd="/work", timeout=300)
        gen.update_file("run.txt", f"$ {command}\n(exit {rc})\n\n{output}")

        # Pull back any files the run produced into this cell.
        staged = set(gen.list_files())
        for path in await env.list_files():
            if path in staged:
                continue
            try:
                gen.update_file(path, await env.read_file(path))
            except FileNotFoundError:
                continue

        # Optionally launch a server and hand the human a live preview.
        if serve and serve_port:
            await env.exec_background(serve, cwd="/work")
            ep = await env.expose_port(serve_port)
            gen.update_file("preview.website", _website(ep.url))
            await gen.update(name="Code Runner", summary=f"ran (exit {rc}); serving :{serve_port}")
            # Keep the run alive so the preview stays up until Stop.
            import asyncio

            while not gen.cancelled:
                await asyncio.sleep(0.5)
            return

        await gen.update(name="Code Runner", summary=f"ran (exit {rc})")


def _website(url: str) -> str:
    import json

    return json.dumps({"url": url})


if __name__ == "__main__":
    gen.main(run)
