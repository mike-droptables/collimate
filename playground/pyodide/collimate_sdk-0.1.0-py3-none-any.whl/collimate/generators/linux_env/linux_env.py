# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "docker"]
# ///
"""Linux Env — the canonical base *environment*.

A warm Linux container you can run commands and servers in. A worker spawns it
to push code, run tests, launch servers, and read results; a human can run it
directly to get a live shell (the ``.terminal`` renders). All Docker lives in
``_env_shared.DockerEnvironment`` (shared generator code) — this generator is
just config + serve.

Dual-use:
  * Human runs it on a code cell → a live shell into the workspace.
  * A worker ``spawn``s it → ``handle.exec`` / ``put_files`` / ``exec_background``
    / ``expose_port`` against the same container.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import gen

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from _env_shared import DockerEnvironment  # noqa: E402


async def run() -> None:
    cfg = gen.config("settings.set_yaml")
    image = (cfg.get("image") or "collimate-linux-small:v2").strip()

    env = DockerEnvironment(
        image=image,
        mount="/work",
        # The default image builds from this generator's Dockerfile on first
        # use (cached by tag thereafter). A pre-built `image` is used as-is.
        build_context=str(Path(__file__).resolve().parent),
    )
    env.surface_terminal(label="Shell")          # human surface
    await gen.update(name="Linux Env", summary="environment ready")
    gen.status("Environment ready — serving workers and the human shell.")
    await env.serve()                            # blocks until Stop; removes the container


if __name__ == "__main__":
    gen.main(run)
