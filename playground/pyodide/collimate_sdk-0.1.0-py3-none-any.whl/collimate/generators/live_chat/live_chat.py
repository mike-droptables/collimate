# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic-ai"]
# ///
"""Live Chat — streaming pydantic-ai chat with read/write/edit tools.

A chat is just a pinned file: ``gen.serve_chat`` registers a live session,
writes & pins a ``.chatlive`` pointer the chat renderer opens its WebSocket
against, and dispatches each user message to ``on_turn``. The turn body is one
``gen.agent_chat_turn`` call: it streams text deltas to the renderer, observes
``turn.cancelled`` (interrupt / redirect), and retries once on auth failure.
The durable, editable transcript lives in ``conversation.chatlog``.
"""
from __future__ import annotations

import gen


async def run() -> None:
    cfg = gen.config("pydantic-config.set_yaml")
    agent = await gen.agent(
        system_prompt=(cfg.get("system_prompt") or "").strip(),
        tools=gen.file_tools() + [gen.python_tool()],
    )

    async def on_turn(turn: gen.ChatTurn) -> None:
        gen.history.append("user", turn.user_msg)
        await gen.update()  # surface the user turn immediately

        reply = await gen.agent_chat_turn(turn, agent)
        gen.history.append("assistant", reply or "_(empty response)_")
        await gen.update(summary=turn.user_msg[:80].replace("\n", " "))

    await gen.serve_chat(
        on_turn,
        label="Live Chat",
        resume=bool(cfg.get("resume_from_chatlog", True)),
    )


if __name__ == "__main__":
    gen.main(run)
