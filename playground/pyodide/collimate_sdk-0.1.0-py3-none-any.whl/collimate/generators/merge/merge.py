# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Merge — union the files of 2+ input cells into a single output cell.

Multi-input runs are hydrated as ``inputs/NN_slug/`` subfolders where the
NN prefix preserves picker order (top = smallest number). Topmost wins on
filename collisions. Tier-A only — the ``demo/generators/merge`` mirror is
identical bar the manifest's ``runtime:`` field.
"""
from __future__ import annotations

import gen


async def run() -> None:
    groups = gen.input_groups()
    if len(groups) < 2:
        raise Exception("Merge needs at least 2 input cells.")

    origin: dict[str, str] = {}
    overwritten: list[tuple[str, str, str]] = []
    written: list[str] = []

    for label, files in groups.items():
        for rel, content in files.items():
            if rel in origin:
                if gen.read_file(rel) != content:
                    overwritten.append((rel, origin[rel], label))
                continue
            gen.update_file(rel, content)
            origin[rel] = label
            written.append(rel)

    lines = [f"# Merge — {len(groups)} cells, {len(written)} file(s)", ""]
    lines.append("## Origins")
    lines.append("")
    for rel in sorted(written):
        lines.append(f"- `{rel}` ← `{origin[rel]}`")
    if overwritten:
        lines.append("")
        lines.append("## Shadowed by topmost input")
        lines.append("")
        for rel, winner, loser in overwritten:
            lines.append(f"- `{rel}` — `{winner}` won over `{loser}`")
    gen.update_file("_merge.md", "\n".join(lines) + "\n")

    await gen.update(
        name=f"Merge × {len(groups)}",
        summary=f"{len(written)} files from {len(groups)} cells",
        pinned="_merge.md",
    )


if __name__ == "__main__":
    gen.main(run)
