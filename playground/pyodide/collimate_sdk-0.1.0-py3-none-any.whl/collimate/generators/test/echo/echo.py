# /// script
# dependencies = ["pyyaml"]
# ///
"""
Echo Generator — SDK demo that echoes workspace context.
"""

import os
from collimate.sdk import Generator

gen = Generator()

@gen.run(name="Echo")
def main():
    settings = gen.config.read_schema_values("settings.set_yaml")
    gen.status = "Echo generator starting..."

    include_env = bool(settings.get("include_env", False))
    header = settings.get("header", "") or ""

    # New-style pre-run config from the multi-stage picker (if any).
    pickoptions = gen.config.get_pickoptions()
    config_files = gen.config.list_files()
    if pickoptions:
        gen.log.info(f"[echo] pickoptions: {pickoptions}")
    if config_files:
        gen.log.info(f"[echo] draft config files: {config_files}")

    ws_files = gen.fs.list()

    output_lines = ["# Echo Generator Output", ""]
    if header:
        output_lines += [header, ""]

    output_lines += [
        f"Files found: {', '.join(ws_files) if ws_files else '(none)'}",
        "",
    ]

    if pickoptions:
        output_lines += [f"Pickoptions: {' / '.join(map(str, pickoptions))}", ""]
    if config_files:
        output_lines += [f"Draft config files: {', '.join(config_files)}", ""]

    if include_env:
        output_lines += ["## Environment Variables", ""]
        for k in sorted(os.environ.keys()):
            output_lines.append(f"  {k}")
        output_lines.append("")

    output_lines += ["Echo complete."]

    gen.status = "Writing output..."
    gen.fs.write("output.md", "\n".join(output_lines))
    gen.update_cell(name="Echo", summary=f"Echoed {len(ws_files)} workspace file(s)")

if __name__ == "__main__":
    main()
