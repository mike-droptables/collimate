# /// script
# dependencies = ["pyyaml"]
# ///
"""Echo Settings generator — demonstrates the mid-run settings update feature.

1. Reads initial settings and writes an output file.
2. Writes a mid-run settings form to the workspace.
3. Calls gen.request_settings_update() which blocks until the user edits
   the form and clicks Continue.
4. Uses the updated settings to rewrite the output file.
"""

from collimate.sdk import Generator

gen = Generator()


@gen.run(name="Echo Settings")
def main():
    # Read initial settings from the Draft config.
    settings = gen.config.read_schema_values("settings.set_yaml")
    greeting = settings.get("greeting", "Hello")
    fmt = settings.get("format", "markdown")

    # Write initial output
    gen.status = "Writing initial output..."
    if fmt == "markdown":
        content = f"# {greeting}\n\nThis is the initial output.\n"
    else:
        content = f"{greeting}\n\nThis is the initial output.\n"
    gen.fs.write("output.md", content)
    gen.update_cell(name="Echo Settings", summary=f"Initial: {greeting}")

    # Write a mid-run settings file for the update prompt
    gen.status = "Requesting settings update..."
    update_settings = """fields:
  - key: greeting
    type: text
    label: "Updated Greeting"
    description: "Change the greeting for the final output."
    default: "{greeting}"

  - key: suffix
    type: text
    label: "Suffix"
    description: "Text to append after the greeting."
    default: "World"
""".format(greeting=greeting)
    gen.fs.write("update_settings.set_yaml", update_settings)

    # Block until the user edits and clicks Continue
    updated = gen.request_settings_update("update_settings.set_yaml")

    # Use the updated values
    new_greeting = updated.get("greeting", greeting)
    suffix = updated.get("suffix", "World")

    gen.status = "Writing updated output..."
    if fmt == "markdown":
        final_content = f"# {new_greeting}, {suffix}!\n\nUpdated after settings change.\n"
    else:
        final_content = f"{new_greeting}, {suffix}!\n\nUpdated after settings change.\n"
    gen.fs.write("output.md", final_content)
    gen.update_cell(name="Echo Settings", summary=f"Updated: {new_greeting}, {suffix}")


main()
