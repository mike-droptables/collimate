# /// script
# dependencies = ["pyyaml"]
# ///
"""Echo Update generator — diagnostic for the output_mode: in_place pipeline.

Reads the current output.md from the workspace, prepends a timestamp line,
writes it back, then commits via gen.update_cell() so the target cell is
mutated in place with a new internal-version row in cell_edges rather than
a brand new cell appearing on the canvas.
"""

from datetime import datetime

from collimate.sdk import Generator

gen = Generator()


@gen.run(name="Echo Update")
def main():
    gen.status = "Reading existing output..."
    try:
        prev = gen.fs.read("output.md")
    except FileNotFoundError:
        prev = ""

    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    new_content = f"tick at {ts}\n" + prev

    gen.status = "Writing output..."
    gen.fs.write("output.md", new_content)

    gen.update_cell(name="Echo Update", summary=f"tick at {ts}")


main()
