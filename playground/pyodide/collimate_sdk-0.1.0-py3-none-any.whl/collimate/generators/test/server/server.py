# /// script
# dependencies = []
# ///
"""
Server Generator — Demonstrates exposing a port and gracefully stopping.
"""

import http.server
import socket
import socketserver
import threading
import os
import functools
from collimate.sdk import Generator


def _find_free_port(start: int = 8080) -> int:
    port = start
    while port < 9000:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                port += 1
    raise RuntimeError("No free port found in range 8080-8999")

gen = Generator()

@gen.run(name="Local Server")
def main():
    # If the workspace is empty, give them an index.html
    if not gen.fs.exists("index.html"):
        gen.fs.write("index.html", "<h1>Hello from the Collimate Python SDK!</h1>")

    port = _find_free_port(8080)
    gen.status = f"Starting server on port {port}..."
    
    Handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=gen.workspace)
    
    class ReusableTCPServer(socketserver.TCPServer):
        allow_reuse_address = True

    with ReusableTCPServer(("127.0.0.1", port), Handler) as httpd:
        # Run the server in a background thread so it is ready immediately
        server_thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        server_thread.start()
        
        # Tell the UI to open an iframe pointing to this port
        gen.serve_port(port, name="Preview Server")
        
        channel = os.environ.get("COLLIMATE_CHANNEL", "")
        run_id = os.environ.get("COLLIMATE_RUN_ID", "")
        proxy_url = f"/proxy/{channel}/{run_id}/{port}/"
        gen.fs.write("server.website", proxy_url)
        
        gen.update_cell(
            name="Local Server",
            summary=f"Server running on port {port}",
        )
        
        gen.status = "Running! (Click stop to exit)"
        
        try:
            # Block until the user clicks the Stop button in the UI
            gen.wait_until_stopped()
        finally:
            # The finally block runs when a StopSignal is caught by the @gen.run wrapper
            gen.log.info("Shutting down server...")
            httpd.shutdown()

if __name__ == "__main__":
    main()
