# /// script
# dependencies = ["google-genai", "pyyaml", "docker"]
# ///
"""
Gen/Rend Builder — scaffolds a complete Collimate generator or renderer from
natural-language instructions, using either the Gemini API or Claude Code
running headless inside the collimate-vscode Docker image.

The two how-to reference docs (how-to-write-a-generator.md and
how-to-write-a-renderer.md) live next to this script and are shipped with the
generator at runtime so the LLM always has the authoritative spec to work
from.
"""

import json
import os
import shutil
import stat
import tempfile
import threading
import uuid
from pathlib import Path

from collimate.sdk import Generator

gen = Generator()

HERE = Path(__file__).parent
HOW_TO_GEN = HERE / "how-to-write-a-generator.md"
HOW_TO_REND = HERE / "how-to-write-a-renderer.md"

VSCODE_IMAGE = "collimate-vscode:latest"


# Read settings once at import time; every helper reads from this dict.
settings = gen.config.read_schema_values("settings.set_yaml")


def _load_instructions() -> str:
    use_first = bool(settings.get("use_first_comment", False))
    if use_first:
        if not gen.chat.history:
            raise Exception(
                "'Use first chat message' is on but this cell has no chat "
                "messages. Type your instructions into the cell's chat, or "
                "switch the toggle off and use the Instructions field."
            )
        text = (gen.chat.history[0].content or "").strip()
        if not text:
            raise Exception("First chat message is empty.")
        return text

    text = (settings.get("instructions") or "").strip()
    if not text:
        raise Exception(
            "Instructions are empty. Type them into the Instructions field "
            "in settings, or turn on 'Use first chat message instead'."
        )
    return text


def _load_reference(target: str) -> str:
    path = HOW_TO_GEN if target == "generator" else HOW_TO_REND
    if not path.is_file():
        raise Exception(
            f"Reference doc not found at {path}. The how-to file should be "
            f"shipped alongside this generator's source — check that the "
            f"build pipeline copied it."
        )
    return path.read_text()


def _build_system_prompt(target: str, reference: str) -> str:
    if target == "generator":
        required = (
            "Required files for a generator:\n"
            "  - manifest.gen_yaml\n"
            "  - <id>.py  (the entrypoint; filename must match 'entrypoint' in the manifest)\n"
            "  - settings.set_yaml  (only if the generator exposes user-editable knobs)\n"
        )
    else:
        required = (
            "Required files for a renderer:\n"
            "  - manifest.rend_yaml\n"
            "  - main.tsx  (or whatever 'entrypoint' the manifest declares)\n"
        )

    return (
        f"You are scaffolding a complete, working Collimate {target} from a "
        f"user's natural-language instructions. Follow the reference guide "
        f"below exactly — it is the authoritative spec for the manifest "
        f"schema, the SDK API, and the file layout.\n\n"
        f"{required}\n"
        f"Output every file in full. Do not abbreviate, do not use "
        f"placeholders, do not include explanatory prose. Every file must be "
        f"complete and ready to drop into "
        f"`collimate-sdk/{'generators' if target == 'generator' else 'renderers'}/<id>/`.\n\n"
        f"--- BEGIN REFERENCE GUIDE ---\n{reference}\n--- END REFERENCE GUIDE ---\n"
    )


# ---------------------------------------------------------------------------
# Gemini backend
# ---------------------------------------------------------------------------

def _run_gemini(system_prompt: str, instructions: str, target: str) -> list[dict]:
    from google import genai
    from google.genai import types

    api_key = os.environ.get("GEMINI_API_KEY", "")
    if not api_key:
        raise Exception(
            "GEMINI_API_KEY is not set in the environment. Add it via the "
            "Key Manager in the UI (top-right) before running the gemini "
            "backend."
        )

    model_id = settings.get("model") or "gemini-3.1-pro-preview"
    gen.status = f"Streaming from {model_id}..."
    gen.log.info("[gemini] model=%s target=%s", model_id, target)

    json_instructions = (
        f"Respond with a single JSON object matching this schema:\n"
        f'{{"files": [{{"path": "<relative path>", "content": "<full file body>"}}]}}\n'
        f"Return ONLY the JSON object — no markdown fences, no commentary.\n\n"
        f"USER INSTRUCTIONS:\n{instructions}"
    )

    client = genai.Client(api_key=api_key)
    stream = client.models.generate_content_stream(
        model=model_id,
        contents=json_instructions,
        config=types.GenerateContentConfig(
            system_instruction=system_prompt,
            temperature=0.3,
            response_mime_type="application/json",
        ),
    )

    chunks: list[str] = []
    for chunk in stream:
        try:
            text = chunk.text or ""
        except Exception:
            text = ""
        if text:
            chunks.append(text)
            for line in text.splitlines() or [text]:
                gen.log.info("[gemini] %s", line)

    full_text = "".join(chunks).strip()
    if not full_text:
        raise Exception("Gemini returned an empty response.")

    try:
        data = json.loads(full_text)
    except json.JSONDecodeError as e:
        raise Exception(
            f"Gemini returned malformed JSON ({e}). First 2000 chars:\n"
            f"{full_text[:2000]}"
        )

    files = data.get("files") if isinstance(data, dict) else None
    if not isinstance(files, list) or not files:
        raise Exception(
            f"Gemini JSON did not include a non-empty 'files' array. Got:\n"
            f"{full_text[:2000]}"
        )
    return files


# ---------------------------------------------------------------------------
# Claude Code (headless, in Docker) backend
# ---------------------------------------------------------------------------

def _chmod_world_writable(path: str) -> None:
    """Open the host temp dir up so the container's coder user (uid 1000)
    can write into it. tempfile.mkdtemp creates 0700 by default."""
    try:
        os.chmod(path, 0o777)
        for root, dirs, files in os.walk(path):
            for d in dirs:
                try:
                    os.chmod(os.path.join(root, d), 0o777)
                except OSError:
                    pass
            for f in files:
                try:
                    os.chmod(os.path.join(root, f), 0o666)
                except OSError:
                    pass
    except OSError as e:
        gen.log.warning("Could not relax temp dir perms on %s: %s", path, e)


def _log_claude_event(line: str) -> None:
    """Pretty-print a stream-json line from Claude Code into the run log."""
    line = line.rstrip()
    if not line:
        return
    try:
        evt = json.loads(line)
    except json.JSONDecodeError:
        gen.log.info("[claude] %s", line[:1000])
        return

    if not isinstance(evt, dict):
        gen.log.info("[claude] %s", line[:1000])
        return

    evt_type = evt.get("type", "?")

    if evt_type == "system":
        subtype = evt.get("subtype", "")
        gen.log.info("[claude:system] %s %s", subtype, json.dumps({k: v for k, v in evt.items() if k not in ("type", "subtype")})[:500])
        return

    if evt_type == "assistant":
        msg = evt.get("message")
        if isinstance(msg, dict):
            for block in msg.get("content", []) or []:
                if not isinstance(block, dict):
                    continue
                btype = block.get("type")
                if btype == "text":
                    text = (block.get("text") or "").strip()
                    if text:
                        for ln in text.splitlines():
                            gen.log.info("[claude:text] %s", ln)
                elif btype == "tool_use":
                    tool = block.get("name", "?")
                    inp = block.get("input", {})
                    inp_str = json.dumps(inp)[:600]
                    gen.log.info("[claude:tool_use] %s %s", tool, inp_str)
                elif btype == "thinking":
                    thought = (block.get("thinking") or "").strip()
                    if thought:
                        gen.log.info("[claude:thinking] %s", thought[:500])
                else:
                    gen.log.info("[claude:assistant:%s] %s", btype, json.dumps(block)[:500])
        return

    if evt_type == "user":
        msg = evt.get("message")
        if isinstance(msg, dict):
            for block in msg.get("content", []) or []:
                if isinstance(block, dict) and block.get("type") == "tool_result":
                    content = block.get("content", "")
                    if isinstance(content, list):
                        content = " ".join(
                            (c.get("text", "") if isinstance(c, dict) else str(c))
                            for c in content
                        )
                    gen.log.info("[claude:tool_result] %s", str(content)[:600])
        return

    if evt_type == "result":
        gen.log.info("[claude:result] success=%s duration_ms=%s",
                     evt.get("subtype") == "success",
                     evt.get("duration_ms"))
        return

    gen.log.info("[claude:%s] %s", evt_type, line[:600])


def _collect_files_from_dir(root: str) -> list[dict]:
    out: list[dict] = []
    root_p = Path(root)
    for path in sorted(root_p.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root_p).as_posix()
        try:
            content = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            gen.log.warning("Skipping non-utf8 file from claude output: %s", rel)
            continue
        out.append({"path": rel, "content": content})
    return out


def _run_claude_docker(system_prompt: str, instructions: str, target: str) -> list[dict]:
    import docker
    import docker.errors

    try:
        client = docker.from_env()
        client.ping()
    except docker.errors.DockerException as e:
        raise Exception(
            f"Cannot connect to Docker: {e}. Make sure Docker is running."
        )

    try:
        client.images.get(VSCODE_IMAGE)
    except docker.errors.ImageNotFound:
        raise Exception(
            f"Docker image '{VSCODE_IMAGE}' not found. Run the 'VS Code "
            f"Docker' generator once to build it (or rebuild it after the "
            f"recent Dockerfile change that added the claude CLI), then "
            f"retry."
        )

    mount_host_claude = bool(settings.get("mount_host_claude", True))

    out_host = tempfile.mkdtemp(prefix="collimate-genrend-out-")
    ref_host = tempfile.mkdtemp(prefix="collimate-genrend-ref-")
    try:
        ref_file = Path(ref_host) / "reference.md"
        ref_file.write_text(_load_reference(target))
        _chmod_world_writable(out_host)
        _chmod_world_writable(ref_host)

        prompt = (
            f"You are scaffolding a complete, working Collimate {target}.\n\n"
            f"STEP 1. Read /home/coder/reference/reference.md — this is the "
            f"complete and authoritative guide for writing a Collimate "
            f"{target}. Read the WHOLE file before writing anything.\n\n"
            f"STEP 2. Based on the user instructions below, scaffold a "
            f"complete working {target} by writing every required file into "
            f"the current working directory (/home/coder/output). Use the "
            f"Write tool. Do not write to any other directory. Do not write "
            f"any extra files like README.md or notes.md — only the files "
            f"the {target} actually needs to run.\n\n"
            f"STEP 3. When you are done writing files, stop. Do not "
            f"summarize, do not explain, do not ask follow-up questions.\n\n"
            f"--- USER INSTRUCTIONS ---\n{instructions}\n"
            f"--- END USER INSTRUCTIONS ---\n"
        )

        volumes: dict = {
            out_host: {"bind": "/home/coder/output", "mode": "rw"},
            ref_host: {"bind": "/home/coder/reference", "mode": "ro"},
        }
        if mount_host_claude:
            host_claude = os.path.expanduser("~/.claude")
            if os.path.isdir(host_claude):
                volumes[host_claude] = {"bind": "/home/coder/.claude", "mode": "rw"}
                gen.log.info("[claude] mounting host ~/.claude into container")
            else:
                gen.log.warning(
                    "mount_host_claude is on but %s does not exist; container "
                    "will start unauthenticated", host_claude
                )

        container_name = f"collimate-genrend-{uuid.uuid4().hex[:8]}"
        gen.status = "Starting Claude Code container..."
        gen.log.info("[claude] launching container %s", container_name)

        container = client.containers.run(
            VSCODE_IMAGE,
            entrypoint=["claude"],
            command=[
                "-p", prompt,
                "--output-format", "stream-json",
                "--verbose",
                "--dangerously-skip-permissions",
            ],
            working_dir="/home/coder/output",
            volumes=volumes,
            name=container_name,
            detach=True,
            stdout=True,
            stderr=True,
        )

        try:
            gen.status = "Claude Code is generating files..."
            buf = b""
            for chunk in container.logs(stream=True, follow=True, stdout=True, stderr=True):
                buf += chunk
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    _log_claude_event(line.decode("utf-8", errors="replace"))
            if buf:
                _log_claude_event(buf.decode("utf-8", errors="replace"))

            result = container.wait()
            exit_code = result.get("StatusCode", 0) if isinstance(result, dict) else 0
            gen.log.info("[claude] container exited with code %s", exit_code)
            if exit_code != 0:
                raise Exception(
                    f"Claude Code container exited non-zero ({exit_code}). "
                    f"See run log above for details."
                )
        finally:
            try:
                container.remove(force=True)
            except docker.errors.NotFound:
                pass
            except Exception as e:
                gen.log.warning("Failed to remove container %s: %s", container_name, e)

        files = _collect_files_from_dir(out_host)
        if not files:
            raise Exception(
                "Claude Code container exited cleanly but produced no files "
                "in /home/coder/output. Check the run log above for what "
                "Claude actually did."
            )
        return files

    finally:
        shutil.rmtree(out_host, ignore_errors=True)
        shutil.rmtree(ref_host, ignore_errors=True)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

@gen.run(name="Gen/Rend Builder")
def main():
    target = (settings.get("target") or "generator").strip().lower()
    if target not in ("generator", "renderer"):
        raise Exception(f"Invalid target '{target}'. Must be 'generator' or 'renderer'.")

    backend = (settings.get("backend") or "gemini").strip().lower()
    if backend not in ("gemini", "claude_docker"):
        raise Exception(f"Invalid backend '{backend}'. Must be 'gemini' or 'claude_docker'.")

    instructions = _load_instructions()
    gen.log.info("[builder] target=%s backend=%s instructions=%d chars",
                 target, backend, len(instructions))

    reference = _load_reference(target)
    system_prompt = _build_system_prompt(target, reference)
    gen.log.info("[builder] reference doc loaded (%d chars), system prompt is %d chars",
                 len(reference), len(system_prompt))

    if backend == "gemini":
        files = _run_gemini(system_prompt, instructions, target)
    else:
        files = _run_claude_docker(system_prompt, instructions, target)

    gen.status = f"Writing {len(files)} file(s) to output cell..."
    written: list[str] = []
    for entry in files:
        if not isinstance(entry, dict):
            gen.log.warning("Skipping non-dict file entry: %r", entry)
            continue
        path = str(entry.get("path") or "").strip().lstrip("/")
        content = entry.get("content")
        if not path or content is None:
            gen.log.warning("Skipping malformed file entry: %r", entry)
            continue
        if not isinstance(content, str):
            content = str(content)
        gen.fs.write(path, content)
        written.append(path)
        gen.log.info("[builder] wrote %s (%d bytes)", path, len(content))

    if not written:
        raise Exception("No files were written. The LLM produced no usable output.")

    summary = (
        f"Scaffolded a {target} via {backend}.\n\n"
        f"Files:\n" + "\n".join(f"  - {p}" for p in written)
    )
    gen.chat.append(role="assistant", content=summary)
    gen.status = f"Done — scaffolded {len(written)} file(s)."
    gen.update_cell(
        name=f"{target.title()} scaffold",
        summary=f"Scaffolded {len(written)} file(s) via {backend}",
    )


if __name__ == "__main__":
    main()
