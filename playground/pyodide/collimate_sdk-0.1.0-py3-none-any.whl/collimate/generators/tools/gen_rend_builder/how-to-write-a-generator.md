# How to Write a Collimate Generator

This is a comprehensive reference for building generators in Collimate. It contains every detail needed to write a generator from scratch, including the full SDK API, manifest format, file structure, and real-world patterns.

## What Is a Generator?

A generator is a **Python script** that runs in an isolated subprocess to transform inputs into outputs. Generators:

- Execute arbitrary Python logic (LLM calls, file transformations, git operations, web servers, etc.)
- Read input files from a temporary workspace directory
- Write output files that get committed to a content-addressable store (CAS)
- Communicate live status/progress to the UI via IPC
- Can produce one or many output cells (DAG nodes)
- Can run once ("oneshot") or continuously ("daemon") until the user clicks Stop

## File Structure

Generators are organised into **groups**. Every generator lives in its own directory under `collimate-sdk/generators/<group>/`:

```
generators/
  chat/                        # group folder
    claude_code_chat/
      manifest.gen_yaml        # REQUIRED: metadata, parameters, execution config
      claude_code_chat.py      # REQUIRED: the entrypoint script
      settings.set_yaml        # OPTIONAL: user-editable settings schema
    anthropic_chat/
      ...
  generate/                    # another group
    gemini/
      ...
  test/                        # diagnostic / demo generators
    echo/
      ...
  tools/                       # utility generators
    git_clone/
      ...
  problem_space/               # structured creative workflow
    brainstorm/
      ...
```

A group is just a top-level subdirectory. There is no per-group config file — group membership is folder location and nothing else. The build script copies the entire tree recursively to `api/templates/generators/`, and on new-channel creation each group is seeded as one cell inside a single Generators stack. So a fresh channel comes up with one cell per group (e.g. "Chat", "Generate", "Problem Space"), each containing the source for its members.

To add a new group, just create a new top-level subdirectory under `collimate-sdk/generators/` and put generator folders inside it. To add a generator to an existing group, drop a new subdirectory under that group's folder. No registry, no manifest list, no code changes — folder location is the contract.

The `.gen_yaml` and `.set_yaml` extensions are how the frontend recognises these files and routes them through the **schema_form** renderer — a form-based editor with dropdowns, checkboxes, and validated text fields, instead of a free-form Monaco text area. You don't have to do anything to opt in; just use the right extension.

## Step 1: Write the manifest.gen_yaml

The manifest declares everything about your generator: its identity, how it runs, what parameters it accepts, and what inputs it requires. When opened in the UI it renders as a form with a fixed schema, so you cannot mistype a field name or set `execution_mode` to an invalid value by hand.

### Full Manifest Schema

```yaml
# REQUIRED FIELDS
id: "my-generator"                # Unique identifier (lowercase, hyphens ok)
name: "My Generator"              # Display name in the UI
version: "1.0.0"                  # Semantic version
summary: "Short description of what this generator does."
entrypoint: "my_generator.py"     # Filename of the Python entry script

# EXECUTION CONFIG
execution_mode: "oneshot"         # "oneshot" = runs once and exits
                                  # "daemon"  = runs until user clicks Stop

# LIVE MODE FLAGS (only meaningful during running — see "Running Behavior" below)
live_chat_mode: "none"            # "none"              = chat locked during running
                                  # "locked_history"    = history read-only, new messages at bottom only
                                  # "unlocked_history"  = user can edit/delete old messages during running

live_files_mode: "none"           # "none"              = files locked during running
                                  # "live_files"        = files editable during running

# OPTIONAL FIELDS
summary_artifact: "output.md"     # File to display as the cell's primary content in the UI

# DRAFT + MULTI-STAGE PICK FIELDS (see "The Picking → Draft → Standard lifecycle" below)
draft_files:                           # Zero or more files seeded into the run's
  - "settings.set_yaml"                # .colreserved/config/files/ on every run.
  - "prompt.md"                        # Routed through a Draft cell when the
                                       # generator default_route is 'draft' OR a
                                       # pickoption terminal route is 'draft'.
pickoptions_file: "pickoptions.yaml"   # Optional multi-stage pre-run pick tree
summary_file: "settings.set_yaml"      # Draft first-tab hint — relative to a
                                       # Draft cell's files, must match one of
                                       # the draft_files entries
default_route: "run"                   # "run" | "draft" — where a generator
                                       # lands after pick if no pickoption
                                       # terminal overrides. Defaults to 'draft'
                                       # when draft_files is set and there's no
                                       # pickoptions_file (so the user gets to
                                       # edit); otherwise defaults to 'run'.

# PARAMETERS (raw YAML escape hatch — use sparingly; prefer settings.set_yaml)
parameters:
  param_name:
    type: "string"
    default: ""
    description: "Human-readable description"
    enum: ["option1", "option2"]

# INPUT CONSTRAINTS  (ENFORCED — backend rejects runs that violate these bounds)
inputs:
  cells:
    min: 0                        # Minimum number of input cells required
    max: 10                       # Maximum number of input cells allowed
                                  # Set max: 1 if your generator only makes sense
                                  # with a single input — see "Multi-cell input
                                  # handling" below for what changes when max > 1.

# ENVIRONMENT KEYS (required secrets)
# Listed keys gate the generator in the picker: if any of these aren't
# set the generator is greyed out. The key names also appear in the Keys
# settings tab automatically — the tab's list is derived from the active
# channel's generators (manifest `keys:` plus any pickoption
# `required_keys:`), not from a user-maintained allowlist. A key is
# considered "set" when its env var exists and contains non-whitespace
# content.
keys: [API_KEY_NAME]
```

### Real Examples

**Simple oneshot generator:**
```yaml
id: "echo"
name: "Echo"
version: "1.1.0"
summary: "Diagnostic generator that echoes workspace context."
entrypoint: "echo.py"
execution_mode: "oneshot"

draft_files:
  - "settings.set_yaml"
summary_artifact: "output.md"
inputs:
  cells:
    min: 0
    max: 10
```

**LLM generator with model selection:**
```yaml
id: "gemini"
name: "Gemini"
version: "1.1.0"
summary: "Calls Google Gemini to generate code and responses from chat context."
entrypoint: "gemini.py"
execution_mode: "oneshot"

draft_files:
  - "settings.set_yaml"
summary_artifact: "response.md"
inputs:
  cells:
    min: 0
    max: 10
```

**Multi-cell output generator:**
```yaml
id: "three-versions"
name: "Three Versions"
version: "1.1.0"
summary: "Generates 3 parallel stylistic variations using Google Gemini."
entrypoint: "three_versions.py"
execution_mode: "oneshot"

draft_files:
  - "settings.set_yaml"
inputs:
  cells:
    min: 1
    max: 5
```

**Long-running daemon:**
```yaml
id: "server"
name: "Local Web Server"
version: "1.0.0"
summary: "Demonstrates long-running port exposure via the Python SDK."
entrypoint: "server.py"
execution_mode: "daemon"

summary_artifact: "server.website"
inputs:
  cells:
    min: 0
    max: 10
```

## Step 2: Declare Draft Files (Optional)

If your generator needs anything from the user before the run starts — a settings form, a natural-language prompt, a YAML config, a template to fill in — declare those files under `draft_files:` in the manifest. They get seeded into `.colreserved/config/files/` on every run, editable in a Draft cell when the pick routes there, and readable from Python via `gen.config`.

**There is no special "settings" concept.** A `.set_yaml` schema_form file is just one draft file among any number of others. Your generator can have zero, one, or many; pick any filenames; mix schema_form files with plain markdown prompts, JSON configs, whatever makes sense. One of them can be named in `summary_file` so the Draft editor opens it first.

```yaml
# manifest.gen_yaml
draft_files:
  - "settings.set_yaml"    # flat form knobs (model, api_key, etc.)
  - "prompt.md"            # long-form natural-language input
summary_file: "prompt.md"  # open this tab first in the Draft editor
default_route: "draft"     # always route through Draft so the user edits
```

The file contents ship inside your generator directory alongside `manifest.gen_yaml` and get copied into the run's config at dispatch time.

### Schema-form files (`.set_yaml`)

Files with the `.set_yaml` extension get the schema_form renderer automatically — a form with validated text boxes, dropdowns, checkboxes, and list editors that saves the user's edits back into a `values:` block at the top of the file.

You author only the `fields:` list:

```yaml
# settings.set_yaml
fields:
  - key: api_key
    type: text
    label: "API Key"
    description: "Leave blank to fall back to GEMINI_API_KEY in the environment."
    secret: true
    default: ""

  - key: model
    type: dropdown
    label: "Model"
    required: true
    options:
      - "gemini-2.0-flash"
      - "gemini-3-flash-preview"
    default: "gemini-2.0-flash"

  - key: include_env
    type: checkbox
    label: "Include environment variables"
    default: false
```

After the user edits anything, the file is rewritten in place:

```yaml
values:
  api_key: ""
  model: "gemini-2.0-flash"
  include_env: true

fields:
  - key: api_key
    ...
```

You never need to look at `values:` yourself — `gen.config.read_schema_values(path)` handles the fall-through (see "Reading from Python" below).

### Field schema reference (`.set_yaml` only)

| key | required | meaning |
|---|---|---|
| `key` | yes | Identifier for `gen.config.read_schema_values()` lookup. |
| `type` | yes | One of `text`, `textarea`, `number`, `checkbox`, `dropdown`, `list`, `object`. |
| `label` | no | Display label shown above the input. Defaults to `key`. |
| `description` | no | Help text shown below the label. |
| `required` | no | If true, the form flags the field as missing when empty. |
| `default` | no | Initial value when no `values:` block exists yet. Also what the SDK reader falls back to when the key is missing. |
| `options` | dropdown only | List of allowed values. |
| `secret` | text only | If true, the input is masked (use for API keys). |
| `min` / `max` | number only | Numeric bounds. |

The `object` type renders a small embedded YAML text area and is a rare escape hatch. Prefer structured types.

### Non-schema draft files

Anything else: just drop a file in your generator directory and list it under `draft_files`. The Draft editor opens it with whichever renderer matches the extension (Monaco for code, Milkdown for markdown, etc.).

Typical pattern for an LLM generator with a long prompt:

```yaml
# manifest.gen_yaml
draft_files:
  - "prompt.md"            # the user's main authoring surface
  - "settings.set_yaml"    # model, api_key, secondary knobs
summary_file: "prompt.md"
default_route: "draft"
```

```python
# my_generator.py
prompt = gen.config.get_file("prompt.md") or ""
settings = gen.config.read_schema_values("settings.set_yaml")
model = settings.get("model", "gemini-2.0-flash")
```

### Reading from Python

Generators read every draft file through `gen.config`:

```python
# Schema-form file (applies values/defaults fall-through)
settings = gen.config.read_schema_values("settings.set_yaml")
api_key = settings.get("api_key", "")
model   = settings.get("model")

# Any other file (raw string; parse however you like)
prompt = gen.config.get_file("prompt.md")   # str or None
cfg    = gen.config.get_file("config.json") # str or None

# List every config file (pickoptions.json lives a level up — it's
# metadata, not a file from the Draft)
paths = gen.config.list_files()
```

Never import `yaml` or `json` and open these files directly — always go through `gen.config`. That keeps your generator robust to future changes in where the backend puts config (e.g. alternate transports).

## The Picking → Draft → Standard Lifecycle

Every cell produced from the picker flows through three explicit states:

- **Picking** — transient client-side UI while the user chooses a generator (and, optionally, walks a multi-stage pickoptions tree). Never hits the DB; dismissed by Esc, view changes, or completing the pick. At most one Picking active in the whole app.
- **Draft** — persisted pre-run config cell. Has parents pinned to specific Standard versions, stores user-editable files in a dedicated `draft_cell_files` table, shows a sky-blue Draft banner with `Cancel` / `Run` buttons. Not on the DAG — nothing can build on a Draft. Duplication copies parents + files to an independent Draft.
- **Standard** — first-class persisted cell. May be running, stopped, completed, or idle. The only state that appears in version history and that can be input to other generators. Promoting a Draft flips the same row's state from `Draft` → `Standard` and starts the run — the cell id is stable through the transition.

A generator can opt into progressively richer pre-run interaction. Every opt-in writes to the same `.colreserved/config/` location — what varies is whether the user sees a Draft cell to edit the files, a multi-stage pick to shape the run, or nothing at all.

| Opt-in | What the user does before your script starts |
|---|---|
| Nothing | Picks your generator in the picker, hits Enter → your script runs. |
| `draft_files` | Picker routes to a Draft cell seeded with your declared files. User edits them, clicks Run → your script runs with the edits visible via `gen.config`. (Only auto-routes to Draft when no `pickoptions_file`; override with `default_route: "run"` to skip the Draft and use the defaults.) |
| `pickoptions_file` | Picker walks a declared tree of choices. Terminal options set `route: run` or `route: draft` — the run path is recorded at `.colreserved/config/pickoptions.json` and readable via `gen.config.get_pickoptions()`. |
| Both | Picker walks the pickoptions tree. Terminal `route: draft` creates a Draft with your declared `draft_files` seeded and the chosen path recorded. Terminal `route: run` skips the Draft and runs with the defaults. |

All paths end at the same place on disk. "Settings" is not a special concept — it's just a schema_form file (`.set_yaml`) in your `draft_files` list, read via `gen.config.read_schema_values()`.

### When to use pickoptions_file

Use pickoptions when the user's choice should *shape the run itself* (mode, strategy, variant) rather than *parameterise* it. If the options are mutually exclusive buckets like "fast / thorough / exhaustive", or "just run / let me edit first / let me review results first", prefer pickoptions over a dropdown in settings — it's faster (fewer clicks, visible tags) and it produces a recorded `pickoptions_path` that downstream tooling can inspect.

### When to route to Draft

Route to Draft when the generator needs the user to **edit the initial config/content before running**. Common cases:

- Brainstorm generators where the user writes the seed prompt into a Draft file, then runs
- Scaffolders where the user fills in template variables in a Draft before code-gen kicks off
- Multi-turn chats where the first turn's content is authored in a Draft file

If your generator just needs a few flat knobs, use `settings_file` — Draft is heavier (it creates a real persisted cell the user has to explicitly Run or Cancel).

### The `.pickoptions` file format

Declare options as either a flat sequence or a nested tree. Both render the same way in the picker:

```yaml
# pickoptions.yaml
options:
  - name: "Minimal"
    description: "Fast, one line per file."
    value: "minimal"
    children:
      - name: "Plain text → Run"
        value: "plain"
        route: "run"
      - name: "Markdown → Draft"
        description: "Open a Draft so you can tweak the output template."
        value: "markdown"
        route: "draft"

  - name: "Verbose"
    description: "Include file sizes, env vars, etc."
    value: "verbose"
    children:
      - name: "Plain text → Run"
        value: "plain"
        route: "run"
      - name: "Markdown → Draft"
        value: "markdown"
        route: "draft"
```

Each option supports:

| key | required | meaning |
|---|---|---|
| `name` | yes | Label shown in the picker (the user sees this). |
| `description` | no | Secondary text under the label. |
| `value` | yes | The value recorded in `pickoptions_path`. **Never shown to the user.** Can be any JSON-serialisable type. |
| `children` | no | Nested options. If present, picking this option descends instead of terminating. |
| `route` | **terminal only, required** | `"run"` or `"draft"` — decides whether the terminal pick lands in a Draft for editing or goes straight to Run. Every terminal option must declare exactly one. |
| `required_keys` | no | `[API_KEY, …]` — env vars that must be set for *this* option to be pickable. Greys the option out when missing. Use it when the choice of option decides which key is needed (e.g. a "Gemini" branch vs an "OpenAI" branch) so the generator itself can stay pickable without any key. If every option in a frame is gated and the user has none of the keys, the picker shows "No valid options". |

Terminal options (no children) end the pick. The chosen path is the ordered list of `value` fields from root to leaf: with the tree above, selecting `Verbose → Markdown → Draft` yields `pickoptions_path = ["verbose", "markdown"]`.

No other keys are accepted — the server rejects pickoptions files that declare extra fields (including the old `tags` pills).

**When to use `required_keys` vs manifest `keys:`** — put a key under the manifest `keys:` list if *every* path through the generator needs it (absolute prerequisite). Put it under a pickoption's `required_keys` if only the branch starting at that option needs it. Example: a single "LLM" generator offering Gemini and OpenAI branches leaves `keys:` empty in the manifest and declares `required_keys: [GEMINI_API_KEY]` and `required_keys: [OPENAI_API_KEY]` on the respective branches — the generator is pickable with either key, and the other branch is greyed.

### Reading pre-run config from Python: `gen.config`

The SDK exposes a `gen.config` wrapper that reads everything assembled by the picker + Draft stages from `.colreserved/config/`:

```python
# Ordered list of values chosen through the pickoptions tree
pickoptions = gen.config.get_pickoptions()     # [] if no pickoptions path

# Draft files (only present if the run came from a Draft cell)
files = gen.config.list_files()                # e.g. ["seed.md", "template.md"]
seed = gen.config.get_file("seed.md")          # str or None
```

`gen.config` is **distinct from `gen.fs`**: `gen.fs` reads the hydrated input workspace (files from parent cells), `gen.config` reads the user's pre-run authoring (draft files + pickoptions path). Use `gen.config.get_file(path)` or `gen.config.read_schema_values(path)` — never open these files directly.

### summary_file — which Draft tab opens first

Set `summary_file` in the manifest to the relative path of the file (within the Draft cell's files) that should open as the first tab when the user opens the Draft. This is purely a UX hint — the Draft still contains every file. If unset, the Draft opens on the normal file list.

## Step 3: Write the Python Script

### Boilerplate Template

Every generator script follows this structure:

```python
# /// script
# dependencies = ["pyyaml"]
# ///
"""
My Generator — short description.
"""

import os
from collimate.sdk import Generator

gen = Generator()

@gen.run(name="My Generator")
def main():
    # Read user-edited config (no YAML parsing in your code)
    settings = gen.config.read_schema_values("settings.set_yaml")
    header = settings.get("header", "")
    gen.status = "Working..."
    gen.fs.write("output.md", f"{header}\n\n# Hello World")

if __name__ == "__main__":
    main()
```

### PEP 723 Script Dependencies

The `# /// script` block at the top declares pip dependencies. The runtime uses `uv run` which automatically resolves and installs them in an isolated environment. No requirements.txt or virtualenv needed.

```python
# /// script
# dependencies = ["google-genai", "pyyaml", "requests"]
# ///
```

If your generator has no external dependencies beyond the SDK, use:
```python
# /// script
# dependencies = []
# ///
```

### The `@gen.run()` Decorator

Always wrap your main function with `@gen.run(name="...")`. This provides:

1. **Automatic status**: Sets initial status to "Running {name}..."
2. **Exception handling**: Catches `StopSignal` (raised by `gen.wait_until_stopped()` after the user clicks Stop — see below) and unhandled exceptions
3. **Auto-finish**: Calls `gen.finish(success=True)` on normal return, `gen.finish(success=False)` on error

**The wrapper does NOT auto-create cell content.** You must call `gen.update_cell()` explicitly at least once to populate the auto-created placeholder cell with content. A generator that returns successfully without ever calling `gen.update_cell()` leaves an empty placeholder on the canvas. The "implicit" word in the API refers to *artifact selection* inside `update_cell()` — when you pass `artifacts=None`, it auto-includes everything you wrote via `gen.fs` and `gen.chat` — not to cell creation.

## Complete SDK API Reference

### Generator Class

```python
from collimate.sdk import Generator
gen = Generator()
```

**On construction**, the Generator reads these environment variables (set by the backend):
- `COLLIMATE_WORKSPACE` - Absolute path to the isolated workspace directory
- `COLLIMATE_PARAMS` - JSON dict of merged parameters (manifest defaults + user overrides)
- `COLLIMATE_IPC_PORT` - TCP port for backend communication
- `COLLIMATE_CHANNEL` - Channel name
- `COLLIMATE_RUN_ID` - Unique run identifier

**Properties and attributes:**
- `gen.workspace` (str) - The workspace directory path
- `gen.params` (dict) - Merged parameters from manifest + user input
- `gen.fs` (FSWrapper) - Scoped filesystem API
- `gen.chat` (ChatWrapper) - Chat history API
- `gen.config` (ConfigWrapper) - Read-only access to pre-run config (draft files + pickoptions path)
- `gen.log` (Logger) - Python logger writing to stderr
- `gen.StopSignal` (Exception class) - The exception raised on SIGTERM

### gen.fs - Workspace FileSystem

All paths are relative to the workspace. The SDK auto-tracks every `write()` call so the next `gen.update_cell()` knows which files to include — see "Single-Cell Output" below for how that artifact-selection shortcut works.

```python
# Read a file
content = gen.fs.read("input.txt")       # Returns str, raises if missing

# Write a file (creates parent dirs, auto-tracked for commit)
gen.fs.write("output/result.md", "# Result\nDone.")

# Check existence
if gen.fs.exists("config.json"):
    ...

# List all files (excludes .collimate_messages.json)
file_list = gen.fs.list()  # Returns ["file1.txt", "dir/file2.py", ...]
```

### gen.config - Pre-Run Config (Draft files + pickoptions)

Read-only view onto `.colreserved/config/`, the canonical location for everything the user authored **before the run started**. Populated by the backend on every run:

- `.colreserved/config/pickoptions.json` — ordered list of values the user chose walking the generator's `pickoptions.yaml` tree (empty when not used)
- `.colreserved/config/files/…` — every file declared in the manifest's `draft_files`, with user edits overlaid when the run came from a Draft

```python
# Ordered pickoption values. [] if the generator didn't declare pickoptions_file.
path = gen.config.get_pickoptions()
# e.g. ["verbose", "markdown"]

# Every config file — whether seeded from manifest defaults (direct run)
# or the user's edits (Draft run). The storage is the same.
files = gen.config.list_files()
# e.g. ["prompt.md", "settings.set_yaml"]

# Raw-string reads — parse however you like.
prompt = gen.config.get_file("prompt.md")     # str or None

# Schema-form convenience: reads a .set_yaml file and applies the
# fields/values fall-through logic. No special "settings" name —
# any schema_form file works.
settings = gen.config.read_schema_values("settings.set_yaml")
api_key  = settings.get("api_key", "")
model    = settings.get("model")
```

The two workspace wrappers have crisp, non-overlapping roles:

| Wrapper | Reads from | Represents |
|---|---|---|
| `gen.fs` | workspace root (hydrated input files) | files copied from **parent cells** |
| `gen.config` | `.colreserved/config/` | the user's **pre-run authoring** (draft files + pickoptions path) |

Prefer `gen.config.get_file()` over `gen.fs.read()` when you specifically want the draft-authored version — it disambiguates from parent-cell input files that may have the same name (the draft wins semantically because the user wrote it *for this run*).

### gen.chat - Chat History

Manages the conversation history stored in `.collimate_messages.json` in the workspace.

```python
# Read full history
messages = gen.chat.history  # List of Message(role, content, timestamp)

# Get last message
last = gen.chat.last()       # Message or None
if last:
    user_prompt = last.content

# Append a message (auto-tracked for commit)
gen.chat.append(role="assistant", content="Here is the generated code...")
```

The `Message` dataclass:
```python
@dataclass
class Message:
    role: str       # "user", "assistant", "system"
    content: str
    timestamp: str = ""
```

### gen.status - Live Status

A property setter that updates the status text shown in the UI in real time.

```python
gen.status = "Loading settings..."
gen.status = "Calling Gemini API..."
gen.status = "Writing output files..."
```

### gen.progress() - Progress Bar

Updates the progress bar in the UI.

```python
gen.progress(0, 10)   # 0% complete
gen.progress(5, 10)   # 50% complete
gen.progress(10, 10)  # 100% complete
```

### gen.update_cell() - Update the run's first cell

Every run auto-creates a placeholder cell on the canvas. `gen.update_cell()` populates and mutates that cell. Each call (except the initial one) creates a new internal-version row in the DB linked via `cell_edges(parent_key='previous_version')`. The visible cell id stays stable; full history lives in SQLite and powers the version scrubber.

```python
cell_id = gen.update_cell(
    name="Output",                    # None = keep the previous name
    summary="Generated 3 functions",  # None = keep the previous summary
    artifacts=None,                   # List[Artifact] or None to use tracked writes
    metadata={"tokens": 150},         # Arbitrary metadata dict
    deleted_files=["old_output.txt"], # Optional: files to remove from the cell
)
```

The first call to `update_cell()` is automatically detected and treated as the **initial** update — it populates the placeholder without creating a version-history entry. All subsequent calls create proper version rows. You don't need to track this yourself; the SDK handles it.

**Implicit artifact selection** (`artifacts=None`): automatically includes every file written via `gen.fs.write()` and any chat messages appended via `gen.chat.append()` since the last call. Files the generator did *not* explicitly rewrite are carried forward from the previous version.

**`deleted_files`**: An optional list of file paths to remove from the cell. These are dropped from the carried-forward file set. Use this when the generator intentionally removes a file that existed in a prior version.

**Explicit artifact selection**: Pass a list of `Artifact` objects:

```python
from collimate.sdk import Artifact

gen.update_cell(
    name="My Output",
    summary="Description",
    artifacts=[
        Artifact.from_workspace("output.py", "output.py"),
        Artifact.from_workspace("README.md", "README.md"),
    ]
)
```

### gen.create_cell() - Create additional side cells

For generators that produce multiple output cells, use `gen.create_cell()` after populating the first cell via `gen.update_cell()`. The first call creates a new stack to the right; subsequent calls append to that same stack.

```python
cell_id = gen.create_cell(
    name="Variant B",
    summary="Alternative approach",
    artifacts=None,           # Same implicit selection rules as update_cell()
    metadata={"index": 1},
)
```

**Pattern for multi-output generators:**

```python
@gen.run(name="Multi Output")
def main():
    results = generate_multiple_outputs()
    for i, result in enumerate(results):
        gen.fs.write(f"output_{i}.md", result.content)
        if i == 0:
            gen.update_cell(name=result.title, summary=result.summary)
        else:
            gen.create_cell(name=result.title, summary=result.summary)
```

### gen.request_settings_update() - Mid-run settings prompt

Presents a settings form to the user during a run and blocks until they press Continue. The generator writes a `.set_yaml` file to the workspace, then calls this method. The frontend renders the form in an overlay.

```python
# Write the settings file first
gen.fs.write("mid_run_settings.set_yaml", settings_yaml_content)

# Block until the user edits and clicks Continue
updated_values = gen.request_settings_update("mid_run_settings.set_yaml")
# updated_values is a dict of the user's choices
new_greeting = updated_values.get("greeting", "Hello")
```

This is useful for generators that need user input mid-run, such as confirmation steps, parameter tuning, or iterative refinement workflows.

### gen.chat.start_session() / send_turn() - Persistent streaming sessions against a sandbox container

Despite the `gen.chat.*` namespace, these are **general-purpose streaming primitives** any `in_place` generator can use. The name is historical (the chat generator was the first consumer). What they actually provide is: *"spin up a Docker container running a long-lived agent client bound to this cell, send it a prompt, stream back tokens + tool calls + file edits as events, persist live to the UI, block until done."*

That's useful well beyond chat. Examples of other generators that would use the same primitives:

| Generator | How it uses `gen.chat.send_turn` |
|---|---|
| `pair_refactor` | "Claude, refactor these three files to use the new API." Streams tool calls, user watches edits land in the Files tab live. |
| `bug_hunter` | "Find and fix any null-pointer bugs in this cell." Bash output from `pytest` runs flows into the log panel as it streams. |
| `architecture_review` | "Walk this cell's codebase and write REVIEW.md summarizing concerns." One turn, heavy tool use, visible progress. |

All of these benefit from the same machinery: per-cell persistent session, mid-turn interrupt/redirect, streaming Bash, `.claude/` per-cell overrides, DB version chain per run. None of it is chat-exclusive.

#### The generator declares the sandbox — there is no system default

Every generator that uses this primitive declares the docker image and the Dockerfile directory that builds it. The host has **no system-wide image default**. This is the principle: a generator talks to its sandbox; the host routes bytes between the two but has no opinion about what's inside the container.

```python
gen.chat.start_session(
    image="collimate-chat-worker",            # REQUIRED — docker tag to spawn
    dockerfile_dir=gen.shared(),              # REQUIRED — build context for lazy build
    shared=True,                              # opt-in multiplexing; see below
    backend="claude_code_session",            # identifier passed to the daemon
    model="sonnet",                           # "haiku" | "sonnet" | "opus"
    system_prompt="You are terse.",
)
result = gen.chat.send_turn(content=latest_user_message)   # blocks until turn_end
# result keys:
#   turn_id        -- hex id of the last turn that actually ran
#   usage          -- dict of input/output token counts
#   file_changes   -- list[str] of workspace paths that saw Write/Edit events
#   assistant_text -- the final aggregated assistant reply text
#   cancelled      -- bool; True if the user hit Escape / the interrupt endpoint
gen.update_cell(name="Chat", summary=latest_user_message[:80])
```

`start_session` is idempotent — on subsequent runs of the same cell it reuses the existing session. `send_turn` blocks until the daemon emits `turn_end`; token-level deltas, tool calls, and file_changed events stream directly from the API process to the frontend via SSE (the generator does not handle streaming itself).

The `image` you name does not have to be unique to your generator. If two generators pick the same image string (and `shared=True`), they share one container — the image is looked up once on the local Docker daemon; the build step only runs if nothing with that tag exists. To share Dockerfiles cleanly, use [`gen.shared()`](#genshared---cross-generator-shared-assets) and point `dockerfile_dir` at another generator's `shared/` directory.

#### `shared=True` vs `shared=False` — sandbox sharing model

- **`shared=True` (default).** One daemon container per image for the whole app. The first session to ask for that image lazily spawns the container; subsequent sessions (including cells from other generators that pick the same image) multiplex into it, each scoped to its own `/workspace/<session_id>/` directory. The container is **reference-counted** — when the last session closes, the container is torn down. There is no warm pool and no idle keep-alive: nothing runs in the background that some live cell doesn't need.

  Soft isolation: each session gets its own cwd, ClaudeSDKClient, and workspace subdirectory, but they share the container's filesystem, MCP servers, and resource limits. Fine for "all running under the user's own auth editing the user's own repo" scenarios; not appropriate for untrusted execution.

  Latency note: the shared daemon saves the per-container docker-run + Python boot (~3s) on subsequent cells, but **each session still pays its own ClaudeSDKClient init (~3-15s)** because the client is session-stateful (cwd, conversation, model, system prompt). Cell #2 opens faster than cell #1, but not instant.

- **`shared=False`.** A fresh container is spawned for this session alone and dies when the session closes. Hard container boundary between cells, full per-session boot.

Whichever you pick, the lifecycle is explicit: sandbox is born when a cell needs it, dies when the cell's session ends. Nothing pre-warms at app startup; nothing secretly stays alive after a cell stops.

#### UI signal — `shared:<image>` tag

Once a cell has an open session, the chat panel renders a small green `shared:<image>` or `fresh:<image>` tag in its header (in line with the streaming stop button) and surfaces daemon lifecycle lines — image build, container spawn, ready, teardown — inline in the messages area. Mouseover the tag for the full explanation of what the sharing model means for startup cost and isolation. Your generator does nothing to enable this; the chat session emits `session_started` / `daemon_log` / `session_closed` events automatically.

For in-process backends, `gen.chat.emit_stream_event(turn_id, event)` lets a streaming loop inside the generator subprocess push its own `chat_stream` events to the frontend without routing through a container.

#### `gen.shared()` — cross-generator shared assets

A generator may have a `shared/` subdirectory alongside its `manifest.gen_yaml`. Files inside `shared/` are a **public surface**: other generators can reference them by path. The directory is opaque to generator discovery (no `manifest.gen_yaml` inside, no picker entry) — it is plain assets, whatever your generator wants to expose: Dockerfiles, prompt templates, `.set_yaml` schemas, shared configuration files, anything.

```python
# Your own generator's shared/ directory.
my_shared = gen.shared()
# -> /path/to/this/generator/shared

# Another generator's shared/ directory.
claude_shared = gen.shared("chat/claude_code_chat")
# -> /path/to/collimate-sdk/generators/chat/claude_code_chat/shared
```

The path is computed from `COLLIMATE_APP_DIR` (own) and `COLLIMATE_GENERATORS_DIR` (cross-generator) env vars that the host sets on every run.

**Typical use: reusing another generator's image.** The `claude_code_chat` generator ships `shared/Dockerfile` (+ `chat_daemon.py`) as its sandbox image build context. Any other generator that wants the same Claude Code sandbox does:

```python
gen.chat.start_session(
    image="collimate-chat-worker",
    dockerfile_dir=gen.shared("chat/claude_code_chat"),
    shared=True,
    backend="claude_code_session",
    model="sonnet",
    system_prompt="...",
)
```

Because the image tag is identical, the host reuses the already-built image (and, with `shared=True`, the already-running daemon). The only cost the second generator pays is its own per-session ClaudeSDKClient init.

**Typical use: reusing a prompt template.** Any generator can drop a template file in its `shared/` dir and let others read it via `os.path.join(gen.shared("other"), "template.md")`. Collimate has no opinion on file formats — the convention is just "files in `shared/` are intended to be linked against."

Directory layout:

```
generators/
  chat/
    claude_code_chat/
      claude_code_chat.py
      manifest.gen_yaml
      settings.set_yaml
      shared/              <-- exposed to other generators
        Dockerfile
        chat_daemon.py
```

#### In-process alternative backends (no container)

A container-backed session is the primary path for streaming agent loops, but it is **not the only way**. A generator can skip sandbox spawning entirely and run an LLM client directly in its own subprocess, emitting `chat_stream` events via `gen.chat.emit_stream_event()` so the frontend UI works identically.

Reference implementations of this pattern live in the repo:

- `generators/chat/gemini_chat/` — streams `google-genai` responses, runs four hand-rolled tools (read_file / write_file / edit_file / run_bash) in-process, emits token deltas and tool status events, and wraps Bash in a streaming `subprocess.Popen` wrapper that feeds both the chat card and the run log panel.
- `generators/chat/goose_chat/` — shells out to Block's `goose` CLI, streams its combined stdout line by line as `bash_stdout` + `text_delta` events, and diffs the workspace before/after to emit `file_changed` events for anything goose modified. The whole experience is "treat goose as a black box with a streaming output", which turns out to be enough for a good UX because goose's own output is already human-readable.

Both use:

- `inputs.cells: {min: 1, max: 1}` + `gen.update_cell()` for in-place mutation (same pattern as the chat generators)
- `gen.chat.emit_stream_event(turn_id, event)` with the wire shape documented in "Stream event protocol reference" below
- `gen.fs.write()` for file edits, so `gen.update_cell()`'s implicit artifact selection picks them up at the end
- `gen.stop_requested()` polled at every natural checkpoint (between streaming chunks, between tool calls, on every line of Bash/process output) to honor Escape / the interrupt endpoint

The `chat_stream_event` IPC op is fire-and-forget — there is no ack — so these events don't block the generator the way `commit` or `update_cell` do. You can emit thousands per turn without stalling.

**What in-process backends give up**: mid-turn **redirect** (⌘Enter while streaming to cancel and replace with new content) only works for sandbox-daemon-backed sessions. It goes through `chat_session.pending_redirect`, which lives in the API process and is driven by the `/chat/redirect` HTTP route talking to a running daemon via its stdin pipe. An in-process generator subprocess has no equivalent inbound channel for new content mid-turn. **Interrupt** (Escape / `/chat/interrupt`) still works because it can ride on Collimate's existing SIGTERM-based stop mechanism that `gen.stop_requested()` exposes. Document the limitation in the generator's manifest summary so users aren't surprised.

If you want redirect on a new in-process backend, the path forward is to add an IPC op the API process can push *down* to the generator subprocess mid-run, not a workaround in the generator itself.

#### Handling mid-turn user corrections (interrupt and redirect)

While a turn is in flight, the user can hit **Escape** or the Stop button to interrupt, or press **⌘Enter** with new content in the draft textarea to redirect (cancel and replace). Both go through the API routes:

```
POST /api/channels/{channel}/cells/{cell_id}/chat/interrupt
POST /api/channels/{channel}/cells/{cell_id}/chat/redirect   {"content": "..."}
```

What the generator sees:

- **Interrupt**: `send_turn()` returns normally with `result["cancelled"] = True`. The `assistant_text` contains whatever was streamed so far; a `*[interrupted by user]*` marker is appended to the cell's in-memory `.collimate_messages.json`; the in-memory file edits the model made before the cancel are already captured in `pending_file_hashes` and will land in the next `update_cell` commit. Your generator should still call `gen.update_cell()` to persist the partial state as a new version row — users can scrub back to it or resume from it.
- **Redirect**: *transparent* to the generator. The whole cancel + new-turn dance happens inside a single `send_turn()` call. When it returns, `result["turn_id"]` is the id of the final (successful) turn, not the one that was redirected away from. The interrupted turn's partial text is preserved as a prior assistant message in `.collimate_messages.json` so the conversation history captures the back-and-forth honestly.

The lesson for generator authors: after `send_turn()` returns, *always* call `update_cell()` regardless of the cancel flag. Partial state is real state and belongs in the version chain.

#### Bash output streams to the run log panel automatically

When the `claude_code_session` backend runs a shell command (via the daemon's streaming Bash tool), each output line becomes a `bash_stdout` event on the chat_stream feed. The host-side drain loop forwards these events two ways:

1. **To the frontend** as `chat_stream` SSE events, so `MessageList` can render a live monospace block under the "Running bash: ..." status line.
2. **Into your generator's `log_buffer`** via the ordinary `run_events` pipeline. The standard run-log panel at the bottom of the cell renders the output line by line, exactly the same way it renders a normal generator's stdout.

Your generator code does *nothing* to enable this — it's automatic for any generator that uses `gen.chat.send_turn()` with the primary backend. If you're building a custom streaming backend using `gen.chat.emit_stream_event`, mirror the event shape:

```python
gen.chat.emit_stream_event(turn_id, {
    "type": "bash_stdout",
    "turn_id": turn_id,
    "text": "npm install output line",
})
```

The host's drain loop doesn't see your events (they came from inside the generator subprocess, not the daemon), so for the run-log-panel side you just use `print()` or your own logging — generator stdout always flows into the run log automatically.

#### Per-cell Claude Code customization via `.claude/`

Inside a chat worker container, `/workspace` is Claude Code's working directory. Anything the SDK looks for under `<cwd>/.claude/` it will find — so **any file in your cell whose path starts with `.claude/` is picked up as per-cell Claude Code configuration**, exactly like it would be in a real project directory.

What this enables out of the box:

| Cell file path | Effect |
|---|---|
| `.claude/commands/<name>.md` | Registers a `/<name>` slash command for this cell only |
| `.claude/agents/<name>.md` | Registers a subagent definition |
| `.claude/settings.json` | Project-scoped settings (hooks, permissions, MCP server refs) |
| `.claude/skills/<name>.md` | Custom skill definition scoped to this cell |
| `.mcp.json` (cell root) | Project-level MCP server registration |

Two important properties:

1. **Zero new protocol surface**: the chat worker's `sync_workspace` op already writes every cell file verbatim into `/workspace`, so these paths become live config automatically on the next turn. There is no special-casing inside the daemon.
2. **Portability**: because the config lives in `cell_files`, it travels with the cell through forks, restores, and channel exports. Sharing a chat cell with a collaborator means sharing its slash commands and subagents — a genuine improvement over CLI projects where `.claude/` lives on disk and has to be copied manually.

What the chat worker image ships by default for the binaries these configs usually reference: `git`, `gh`, `jq`, `ripgrep` (`rg`), `fd`, `less`, `tree`, `zip`/`unzip`, `build-essential`, plus the `@modelcontextprotocol/server-filesystem`, `@modelcontextprotocol/server-fetch`, and `@modelcontextprotocol/server-github` MCP servers. User-global config in `~/.claude/` is mounted into the container on startup, so user-level slash commands, skills, and MCP server declarations apply to every cell's session automatically.

#### Stream event protocol reference

For anyone building an alternate streaming backend — a new CLI tool, a different LLM provider, an in-process Python loop, or a wrapper around a tool that isn't Claude Code — the frontend consumes a fixed set of `chat_stream` event types. Emit these (either directly from the generator subprocess via `gen.chat.emit_stream_event`, or from a container daemon that pipes events to the host-side drain loop) and the existing `MessageList`, Files tab, history scrubber, and log panel just work. The name `chat_stream` is a convention — the protocol is not chat-specific.

Wire envelope (as seen by the frontend over SSE):

```json
{"type": "chat_stream", "cell_id": "<visible cell id>", "turn_id": "<hex>", "event": { ...one of the types below... }}
```

Event types:

| `type` | Fields | Meaning / frontend effect |
|---|---|---|
| `turn_start` | `turn_id` | Begins a new turn. The streaming cursor appears in `MessageList`; `inProgressAssistantText` and the Bash output buffer reset. |
| `text_delta` | `turn_id`, `text` | A fragment of assistant text. Appended to the in-progress block. |
| `thinking_delta` | `turn_id`, `text` | A fragment of the model's thinking channel (if exposed). Currently surfaced only to SSE; MessageList ignores it by default. |
| `tool_start` | `turn_id`, `name`, `input`, `tool_use_id` | The model is invoking a tool. `MessageList` renders "Running <name>..." under the streaming block. For Bash, it also opens an empty monospace output buffer. |
| `tool_end` | `turn_id`, `name`, `tool_use_id` | The tool call completed. Clears the tool status line. |
| `bash_stdout` | `turn_id`, `text` | One line of live stdout/stderr from a running Bash invocation. Goes to both the chat-stream UI (live monospace block) and the generator's `log_buffer` → `run_events` → run log panel. See below. |
| `file_changed` | `turn_id`, `path`, `content` | The tool call wrote/edited a workspace file. The host merges the new content into the in-memory cell's VirtualFile list, the frontend re-renders the Files tab, and the new blob hash lands in `pending_file_hashes` so the next `update_cell` persists it to the DB. |
| `turn_interrupted` | `turn_id` | Fires when the user hit the interrupt endpoint (or redirect). Host drain loop marks the session as cancelled and preserves partial state. Always followed by a terminal `turn_end`. |
| `turn_end` | `turn_id`, `usage` | Turn is over. `isStreaming` flips off, the streaming cursor disappears, `send_turn()` unblocks. |
| `error` | `turn_id`, `message` | Fatal error during the turn. Host raises `ChatSessionError`. Daemon should emit a terminal `turn_end` after this so the drain loop doesn't hang. |

**Two destinations for events from an external container daemon**: the host-side drain loop forwards everything to `chat_stream` SSE *and* selectively into the generator subprocess's `log_buffer`. Today that selection is just `bash_stdout`, but the pattern is extensible — if your custom tool has output worth seeing in the log panel (build output, test runs, container logs), emit it as `bash_stdout` or add a new event type and extend `chat_session._forward_bash_output_to_log` to route it.

**Two destinations for events from an in-process Python backend**: `gen.chat.emit_stream_event(turn_id, event_dict)` pushes one event through the IPC socket as a fire-and-forget `chat_stream_event` op; the host's `ProcessManager._handle_ipc` branch unwraps and broadcasts it. For anything that should also land in the run log panel, just `print()` it — generator stdout already flows through `run_events` via the normal microbatch writer.

### Artifact Class

Two factory methods for creating artifacts:

```python
# From a file in the workspace (most common)
Artifact.from_workspace(
    local_path="output.py",    # Path relative to workspace
    cell_path="output.py"      # Path in the output cell (usually same)
)

# From in-memory content (no file on disk needed)
Artifact.from_memory(
    cell_path="generated.txt",
    content="Hello World",
    encoding="utf-8"           # Default: "utf-8"
)
```

### gen.serve_port() - Expose a Port to the UI

Tells the frontend to open a proxied iframe pointing to a port on localhost. Used by daemon generators that run web servers.

```python
gen.serve_port(8080, name="Preview Server")
```

**Optional `path`** — appended to the proxy URL the iframe loads. Useful for opening at a specific page or running a workbench command on first paint:

```python
gen.serve_port(8080, name="Docs", path="/index.html")
gen.serve_port(8443, name="VS Code", path="?command=claude-code.chat.focus")
```

The `path` is a literal suffix appended to `/proxy/{channel}/{run_id}/{port}/`. Include the leading `?` for query strings or the leading `/` for sub-paths.

**Optional `snapshot_source` — opt in to the Snapshot toolbar.** When your generator runs a long-lived service inside a docker container, you can pass `snapshot_source` to tell the UI it can pull files out of that container at any time. Two buttons appear above the live iframe:

- **Write Out Files** — creates a new cell containing the current file tree from the container.
- **Write Out & Shutdown** — replaces the running cell's files with the current file tree, then sends SIGTERM (graceful shutdown).

The contract is:

1. The generator must run a docker container that the host docker daemon can see (use `docker.from_env()`).
2. `snapshot_source` is a dict with two keys:
   - `container_name` — the exact `name=` you passed to `client.containers.run`.
   - `project_dir` — the absolute path inside the container that the user is editing (e.g. `/home/coder/project`).
3. The container must have `git` and `jq` installed if you want `.gitignore` filtering and Claude transcript extraction (the snapshot endpoint uses `git ls-files` and a `jq`-driven bash script via `container.exec_run`).

Example, taken from the `vscode_docker` generator:

```python
container_name = f"my-image-{uuid.uuid4().hex[:8]}"
container = client.containers.run(image_tag, name=container_name, ...)

gen.serve_port(
    port,
    name="VS Code",
    path="?command=claude-code.chat.focus",
    snapshot_source={
        "container_name": container_name,
        "project_dir": "/home/coder/project",
    },
)
```

When the user clicks one of the snapshot buttons, the backend calls `container.get_archive(project_dir)` to pull a tarball, filters it through `git ls-files --cached --others --exclude-standard` (so `.gitignore` is honoured), and writes the result into a cell. It also calls `container.exec_run(...)` to grab the latest Claude assistant message from any transcript at `/home/coder/.claude/projects/*/*.jsonl` and writes it as `summary.md` (set as the cell's `summary_artifact`).

If your generator's container doesn't expose Claude transcripts, that part is silently skipped — the snapshot still works, just without `summary.md`.

If `snapshot_source` is omitted, no buttons appear and the iframe behaves the same as before.

### gen.start_terminal() / gen.stop_terminal() - Expose a live terminal to the UI

Attaches a fully interactive xterm.js terminal to the run's cell, backed by a PTY wired to `docker exec -ti <container> <command>`. The browser renderer and the container's TTY exchange bytes over a WebSocket; the generator itself does none of the pumping — it just registers the session and writes a small pointer file.

Use this when you want the user to drive a containerized CLI (shells, REPLs, Claude Code, vim, anything that expects a TTY) directly from the cell, instead of producing static output.

```python
sess = gen.chat.start_session(
    image="collimate-chat-worker",
    dockerfile_dir=gen.shared("chat/claude_code_chat"),
    shared=True,
    backend="claude_code_session",
)
term = gen.start_terminal(
    container_id=sess["container_id"],
    command=["claude"],
    cwd="/home/coder/project",
    env={"TERM": "xterm-256color"},
)
gen.fs.write("claude.terminal", json.dumps({**term, "label": "Claude Code"}))
gen.update_cell(name="Claude Terminal", summary="live")
try:
    gen.wait_until_stopped()
finally:
    gen.stop_terminal(term["session_id"])
```

The contract:

1. **Container source.** `container_id` is the container name/id you want `docker exec` to target. The `claude_code_session` backend's `container_id` ack field is the normal source, but anything visible to `docker exec` works (e.g. a container you spawned yourself with `docker.from_env().containers.run(name=...)`).
2. **Pointer file.** `start_terminal` returns `{"session_id", "ws_path", "token"}`. Write that dict (plus a human `label`) as JSON into a `*.terminal` file in the workspace, then commit it with `gen.update_cell()`. The `terminal` renderer (registered for the `.terminal` extension) reads the pointer at mount time and opens the WebSocket.
3. **Lazy spawn.** No PTY is spawned by `start_terminal` itself — the backend just reserves a session id and auth token. The `docker exec -ti` is launched only when the browser's WebSocket actually upgrades. This means you can call `start_terminal` before the user has opened the cell and nothing runs until they do.
4. **Lifetime.** The session lives as long as the generator process does. The backend unregisters every session bound to the run's cell when the generator exits (so leaks are bounded), but calling `stop_terminal(session_id)` in a `finally` is the clean pattern — it tears down the PTY as soon as you know you're done.
5. **Single-attach.** Only one WebSocket can be connected to a given session at a time. Reloading the browser tab closes the old socket and the next attach spawns a fresh PTY — scrollback is not preserved across reconnects.

**When to use this vs. `gen.serve_port()`.** They're both "daemon surfaces one interactive UI from a container", but they answer different questions:

| Use case | Primitive |
|---|---|
| Your container runs a web server (VS Code, Jupyter, a preview) | `gen.serve_port()` |
| Your container ships a CLI you want the user to drive interactively | `gen.start_terminal()` |

Both pair naturally with `gen.wait_until_stopped()` — the generator process holds the run open (and, for shared-container backends, keeps the refcount up) until the user clicks Stop.

### gen.wait_until_stopped() - Block Until Stop

Blocks the generator until the user clicks the Stop button in the UI (which sends SIGTERM). Use this for daemon-mode generators.

```python
gen.wait_until_stopped()  # Blocks here until SIGTERM
# After this line, StopSignal is raised and caught by @gen.run()
```

**Important — this is the only place `StopSignal` is raised.** The SDK's SIGTERM handler is intentionally minimal (it writes to a self-pipe and returns). It does not interrupt arbitrary Python code. The `StopSignal` exception is raised inside `wait_until_stopped()` itself, *after* the pipe read returns. What this means for how you write generators:

- **Daemon generators** (long-running servers, VS Code containers, watch loops): call `gen.wait_until_stopped()` somewhere the main thread reaches, inside a `try/finally` that owns any resources you created (containers, child processes, temp dirs). On Stop, the finally block runs and your cleanup happens before the process exits.
- **Oneshot generators** (LLM calls, git clone, file transforms): don't need to call this at all. They run to completion naturally. If the user clicks Stop while a oneshot is mid-execution, the generator will *not* be interrupted — the supervisor escalates to SIGKILL after 15 seconds, at which point your process is killed abruptly with no cleanup. If a oneshot owns a resource that must be released cleanly (e.g. an external subprocess), either keep the critical section short or poll from inside a loop and exit when the user clicks Stop (see the pattern below).
- **Do not try to catch `StopSignal` yourself.** The `@gen.run()` wrapper already catches it and reports the run as gracefully stopped. Your job is just to put cleanup in a `finally` around `wait_until_stopped()`.

**Polling pattern for long oneshot loops.** If you need early-exit behavior without blocking in `wait_until_stopped()` — for example, a loop over many items that should halt quickly on Stop — use `gen.stop_requested()`, which is a non-blocking check:

```python
@gen.run(name="Many Items")
def main():
    for i, item in enumerate(items):
        if gen.stop_requested():
            break
        process(item)
        gen.progress(i + 1, len(items))
```

On exit from the loop the function returns normally, the `@gen.run()` wrapper calls `gen.finish(success=True)`, and the run is reported as completed — not as stopped. If you want the run to report as "gracefully stopped" in the UI, raise `gen.StopSignal` yourself from inside the loop instead of `break`.

### gen.wait_for_action() - Handle Button Clicks from a Renderer

Renderers whose artifact format supports top-bar buttons (for example the `.website` renderer, which accepts a JSON payload `{"url": "...", "buttons": [{"id": "<action_id>", "label": "..."}]}`) can emit named actions to the running generator. Use `gen.wait_for_action(timeout=<seconds>)` to consume them.

Returns the action id (a string) when a button is pressed, `None` on timeout, or `None` when Stop has been requested. Pass `timeout=None` to block until an action arrives or the user stops the run.

This is the canonical way for a daemon generator to react to user clicks inside the live renderer without going through a full `request_settings_update()` round-trip. Typical uses: "Capture current state into a new cell", "Snapshot", "Export", "Restart service".

```python
@gen.run(name="My Daemon")
def main():
    # ... start the service, write a .website artifact with buttons ...
    gen.fs.write("app.website", json.dumps({
        "url": proxy_url,
        "buttons": [{"id": "capture", "label": "Capture Session"}],
    }))
    gen.update_cell(name="My App", summary="running")

    while not gen.stop_requested():
        action = gen.wait_for_action(timeout=1.0)
        if action == "capture":
            # Populate new state, then spawn a side cell
            gen.chat.append(role="assistant", content="...")
            gen.fs.write("snapshot.txt", "...")
            gen.create_cell(name="Captured", summary="snapshot")
    raise gen.StopSignal()  # report run as gracefully stopped
```

Notes:
- Action ids are plain strings. Namespace them if a renderer exposes more than one button.
- `wait_for_action` pairs naturally with `create_cell` — the button is the user's way of saying "promote the current live state into a persistent side cell", and the implicit-artifact collection picks up any files/messages you wrote during the handler.
- See `vscode_docker` for a complete example (Claude session transcript + container files → new side cell on a single button press).

### gen.finish() - Signal Completion

Normally called automatically by `@gen.run()`. You can call it manually if needed:

```python
gen.finish(success=True)                           # Happy path
gen.finish(success=False, error_message="API key missing")  # Error
```

### gen.log - Logging

Standard Python logger writing to stderr:

```python
gen.log.info("Processing file %s", filename)
gen.log.warning("Skipping binary file: %s", path)
gen.log.error("API call failed: %s", error)
gen.log.debug("Detailed trace info")
```

## Common Patterns

### Loading Settings

Use `gen.config.read_schema_values(path)` — never parse the YAML yourself. Read once at the top of your function and combine with `gen.params` and environment variables for the typical precedence:

```python
settings = gen.config.read_schema_values("settings.set_yaml")

# Precedence: draft edits > gen.params > environment variable > error
api_key = (
    settings.get("api_key")
    or gen.params.get("api_key")
    or os.environ.get("API_KEY", "")
)
if not api_key:
    raise Exception("API key not set.")
```

### Single-Cell Output

The simplest pattern. Write files, append a chat message, then call `gen.update_cell()` once. With no `artifacts` argument, it picks up everything you wrote via `gen.fs` and any chat append since startup.

```python
@gen.run(name="Simple")
def main():
    gen.status = "Working..."
    gen.fs.write("output.md", "# Result\nDone.")
    gen.chat.append(role="assistant", content="Generated output.")
    gen.update_cell(name="Simple Output", summary="Wrote output.md")
    # ^ required — without this call no DAG cell is created
```

If you want explicit control over which files end up in the cell, pass an `artifacts` list:

```python
gen.update_cell(
    name="Curated Output",
    summary="Just the report and the manifest",
    artifacts=[
        Artifact.from_workspace("report.md", "report.md"),
        Artifact.from_memory("meta.json", '{"version": 1}'),
    ],
)
```

### Multi-Cell Output

Use `gen.update_cell()` for the first output, then `gen.create_cell()` for each additional cell. Each `create_cell()` call places a new cell in a side stack.

```python
@gen.run(name="Multi Output")
def main():
    for i, variant in enumerate(["Standard", "OOP", "Concise"]):
        gen.status = f"Generating {variant}..."
        gen.fs.write("code.py", generate_code(variant))
        gen.chat.append(role="assistant", content=f"Approach: {variant}")

        if i == 0:
            gen.update_cell(
                name=f"Version: {variant}",
                summary=f"Approach: {variant}",
                metadata={"style": variant},
            )
        else:
            gen.create_cell(
                name=f"Version: {variant}",
                summary=f"Approach: {variant}",
                metadata={"style": variant},
            )
        gen.progress(i + 1, 3)
```

### Parallel Execution

Use `concurrent.futures` for parallel work (e.g., multiple LLM calls):

```python
import concurrent.futures

@gen.run(name="Parallel")
def main():
    tasks = ["task_a", "task_b", "task_c"]

    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        futures = {executor.submit(do_work, t): t for t in tasks}

        for future in concurrent.futures.as_completed(futures):
            task_name = futures[future]
            result = future.result()

            gen.fs.write(f"{task_name}.md", result)
            gen.update_cell(name=task_name, summary=f"Completed {task_name}")
```

### Daemon Mode (Long-Running with Port)

For generators that start a server and stay running until stopped:

```python
import http.server
import socket
import socketserver
import threading
import functools

def _find_free_port(start=8080):
    port = start
    while port < 9000:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                port += 1
    raise RuntimeError("No free port found")

@gen.run(name="My Server")
def main():
    port = _find_free_port()
    gen.status = f"Starting on port {port}..."

    Handler = functools.partial(
        http.server.SimpleHTTPRequestHandler,
        directory=gen.workspace
    )

    class ReusableTCPServer(socketserver.TCPServer):
        allow_reuse_address = True

    with ReusableTCPServer(("127.0.0.1", port), Handler) as httpd:
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()

        gen.serve_port(port, name="Preview")

        # Write a .website file so the website renderer auto-opens
        channel = os.environ.get("COLLIMATE_CHANNEL", "")
        run_id = os.environ.get("COLLIMATE_RUN_ID", "")
        gen.fs.write("server.website", f"/proxy/{channel}/{run_id}/{port}/")

        gen.update_cell(name="Server", summary=f"Running on port {port}")
        gen.status = "Running! (Click stop to exit)"

        try:
            gen.wait_until_stopped()
        finally:
            httpd.shutdown()
```

### Reading Input Files from Parent Cells

Input files from parent cells are hydrated into the workspace before the generator runs. Just read them:

```python
@gen.run(name="Process Input")
def main():
    files = gen.fs.list()
    gen.log.info("Input files: %s", files)

    for path in files:
        content = gen.fs.read(path)
        # Process each file...
```

### Multi-cell input handling

When the user attaches **more than one input cell**, the workspace layout changes. The hydrator namespaces each parent cell into its own subdirectory under `inputs/` so that files from different cells cannot collide. This matters because nothing else in the system would otherwise distinguish two parents that both contain a file called `idea.md`.

The convention is:

| Number of input cells | Workspace layout                                  |
|----------------------:|---------------------------------------------------|
| 0                     | Empty workspace (modulo `.colreserved/`)          |
| 1                     | Files at the workspace root (legacy behaviour)    |
| N > 1                 | Files under `inputs/<NN>_<slug>/` per parent cell |

Where `<NN>` is the zero-padded position (`00`, `01`, ...) in the input cell list and `<slug>` is the parent cell's human-readable name slugified to `[a-z0-9_]`, falling back to a short id when the name is empty. Example layout for a three-input run:

```
inputs/00_distributed_approach/idea.md
inputs/00_distributed_approach/notes.md
inputs/01_oauth_provider/idea.md
inputs/02_session_based_auth/idea.md
```

**What this means for you as a generator author:**

- If `inputs.cells.max == 1` in your manifest, you never see this layout. Files always land at the workspace root and you can use `gen.fs.read("input.txt")` with no nesting. This is the right choice for any generator whose semantics are "operate on one thing" — refine, critique, materialize, translate, three_versions, vscode_docker, claude_code, etc.

- If `inputs.cells.max > 1`, your generator must be aware of the `inputs/` namespace. The recommended pattern is to group workspace files by their `inputs/<NN>_<slug>/` prefix and treat each subdirectory as one logical candidate. The directory name (the `<NN>_<slug>` segment) is also the natural label to use when the generator needs to refer back to the candidate in its output (e.g. Judge's scoreboard rows, Synthesize's "what this combines" section).

Recommended grouping snippet:

```python
grouped: dict[str, list[str]] = {}   # candidate label -> list of file paths
flat: list[str] = []                 # stray files at workspace root
for p in gen.fs.list():
    norm = p.replace("\\", "/")
    if norm.startswith("inputs/"):
        parts = norm.split("/", 2)
        if len(parts) >= 3:
            grouped.setdefault(parts[1], []).append(p)
            continue
    flat.append(p)

# `grouped` now maps "00_distributed_approach" -> ["inputs/00_distributed_approach/idea.md", ...]
# `flat` covers the single-cell or stray-file case so the same generator works for N=1 too.
```

Generators that just want to build a flat context bag (LLM context, search indexing, file listing) can ignore the grouping entirely and iterate `gen.fs.list()` as before — paths will simply include the `inputs/<NN>_<slug>/` prefix in the multi-input case, which is harmless and arguably *more* informative for the model.

`.colreserved/` is **not** namespaced — it stays at the workspace root regardless of how many inputs there are. That namespace is reserved for the SDK and the backend. Current layout:

```
.colreserved/
  .collimate_messages.json         # chat history (runtime + live editing)
  config/
    pickoptions.json               # user's ordered picks (if any)
    files/                         # every Draft file the user authored pre-run
      settings.set_yaml            # schema_form settings (if declared in manifest)
      <anything else>              # other Draft files
```

**The bounds in your manifest are enforced.** The backend reads `inputs.cells.min` and `inputs.cells.max` before hydrating anything and rejects runs that violate them with HTTP 400. So `max: 1` is a real contract — you can rely on never being called with two cells if you set it.

### Building Context from Chat History + Workspace

Common pattern for LLM-based generators:

```python
@gen.run(name="LLM Generator")
def main():
    # Gather workspace context
    context_parts = []
    for path in gen.fs.list():
        context_parts.append(f"--- FILE: {path} ---\n{gen.fs.read(path)}")

    # Gather chat history
    msg_parts = [f"[{m.role.upper()}]\n{m.content}" for m in gen.chat.history]

    full_context = "\n\n".join(context_parts + msg_parts)

    # Send to LLM
    response = call_llm(full_context)

    gen.fs.write("response.md", response)
    gen.chat.append(role="assistant", content=response)
```

### Error Handling

The `@gen.run()` decorator catches all exceptions. To raise user-visible errors:

```python
@gen.run(name="My Generator")
def main():
    if not gen.chat.history:
        raise Exception("No input messages found. Please type a prompt.")

    api_key = load_api_key()
    if not api_key:
        raise Exception("API key not configured. Set it in Settings.")
```

The error message string is sent to the UI via `gen.finish(success=False, error_message=str(e))`.

### Subprocess Execution

For generators that shell out to external tools:

```python
import subprocess
import tempfile

@gen.run(name="Git Clone")
def main():
    repo_url = gen.params.get("repo_url", "")
    if not repo_url:
        raise ValueError("No repository URL provided.")

    gen.status = f"Cloning {repo_url}..."

    with tempfile.TemporaryDirectory() as tmp:
        result = subprocess.run(
            ["git", "clone", "--depth", "1", repo_url, os.path.join(tmp, "repo")],
            capture_output=True, text=True, timeout=300,
        )
        if result.returncode != 0:
            raise RuntimeError(f"git clone failed:\n{result.stderr.strip()}")

        # Copy files into workspace
        for path in walk_files(os.path.join(tmp, "repo")):
            gen.fs.write(path, read_file(path))
```

## Complete Working Examples

### Minimal Echo Generator

**manifest.gen_yaml:**
```yaml
id: "echo"
name: "Echo"
version: "1.1.0"
summary: "Diagnostic generator that echoes workspace context."
entrypoint: "echo.py"
execution_mode: "oneshot"

draft_files:
  - "settings.set_yaml"
summary_artifact: "output.md"
inputs:
  cells:
    min: 0
    max: 10
```

**settings.set_yaml:**
```yaml
fields:
  - key: include_env
    type: checkbox
    label: "Include environment variables"
    default: false
  - key: header
    type: text
    label: "Header"
    default: ""
```

**echo.py:**
```python
# /// script
# dependencies = ["pyyaml"]
# ///
"""
Echo Generator -- SDK demo that echoes workspace context.
"""

import os
from collimate.sdk import Generator

gen = Generator()

@gen.run(name="Echo")
def main():
    gen.status = "Echo generator starting..."

    settings = gen.config.read_schema_values("settings.set_yaml")
    include_env = bool(settings.get("include_env", False))
    header = settings.get("header", "") or ""
    ws_files = gen.fs.list()

    output_lines = ["# Echo Generator Output", ""]
    if header:
        output_lines += [header, ""]
    output_lines += [f"Files found: {', '.join(ws_files) if ws_files else '(none)'}", ""]

    if include_env:
        output_lines += ["## Environment Variables", ""]
        for k in sorted(os.environ.keys()):
            output_lines.append(f"  {k}")
        output_lines.append("")

    output_lines += ["Echo complete."]

    gen.status = "Writing output..."
    gen.fs.write("output.md", "\n".join(output_lines))
    gen.update_cell(name="Echo", summary="Echoed workspace context")

if __name__ == "__main__":
    main()
```

### LLM Generator (Gemini)

**manifest.gen_yaml:**
```yaml
id: "gemini"
name: "Gemini"
version: "1.1.0"
summary: "Calls Google Gemini to generate code and responses from chat context."
entrypoint: "gemini.py"
execution_mode: "oneshot"

draft_files:
  - "settings.set_yaml"
summary_artifact: "response.md"
inputs:
  cells:
    min: 0
    max: 10
```

**settings.set_yaml:**
```yaml
fields:
  - key: api_key
    type: text
    label: "API Key"
    description: "Leave blank to fall back to GEMINI_API_KEY in the environment."
    secret: true
    default: ""
  - key: model
    type: dropdown
    label: "Model"
    required: true
    options:
      - "gemini-2.0-flash"
      - "gemini-3-flash-preview"
    default: "gemini-2.0-flash"
```

**gemini.py:**
```python
# /// script
# dependencies = ["google-genai", "pyyaml"]
# ///
"""
Gemini Generator -- calls Google Gemini using the pristine SDK.
"""

import os
from google import genai
from collimate.sdk import Generator

gen = Generator()

@gen.run(name="Gemini")
def main():
    settings = gen.config.read_schema_values("settings.set_yaml")
    api_key = settings.get("api_key") or os.environ.get("GEMINI_API_KEY", "")
    if not api_key:
        raise Exception("GEMINI_API_KEY not set. Provide it in Settings or environment.")

    if not gen.chat.history:
        raise Exception("No input messages found. Please type a prompt.")

    model_id = settings.get("model", "gemini-2.0-flash")
    gen.status = f"Calling {model_id}..."

    parts = [f"[{m.role.upper()}]\n{m.content}" for m in gen.chat.history]
    prompt = "\n\n".join(parts)

    client = genai.Client(api_key=api_key)
    response = client.models.generate_content(model=model_id, contents=prompt)
    reply = response.text

    gen.fs.write("response.md", reply)
    gen.chat.append(role="assistant", content=reply)
    gen.update_cell(name="Gemini", summary="LLM response")

if __name__ == "__main__":
    main()
```

## Execution Environment Details

When a generator runs, the backend:

1. **Creates a temporary app directory** with the generator's source files (manifest, script, settings)
2. **Creates a temporary workspace directory** with hydrated input files from parent cells
3. **Writes pre-run config** into `{workspace}/.colreserved/config/`:
   - `.colreserved/config/pickoptions.json` — the ordered `pickoptions_path` (if any)
   - `.colreserved/config/files/*` — every file declared in the manifest's `draft_files`, either seeded from defaults (direct-Run path) or copied from the Draft cell's edits (Draft-Run path)
   Read via `gen.config.get_pickoptions()`, `gen.config.list_files()`, `gen.config.get_file()`, or `gen.config.read_schema_values()` (for schema_form `.set_yaml` files).
5. **Sets environment variables**: `COLLIMATE_WORKSPACE`, `COLLIMATE_PARAMS`, `COLLIMATE_IPC_PORT`, `COLLIMATE_CHANNEL`, `COLLIMATE_RUN_ID`, `PYTHONPATH` (pointing to SDK)
6. **Launches**: `uv run {entrypoint}` with the app directory as CWD
7. **Listens on IPC socket** for status/progress/commit/finish messages
8. **On commit**: hashes artifacts, stores in CAS, creates DAG cell record
9. **On finish**: cleans up temp directories

## Checklist for Creating a New Generator

1. Create directory: `collimate-sdk/generators/my_generator/`
2. Write `manifest.gen_yaml` with id, name, version, summary, entrypoint, execution_mode, live_chat_mode, live_files_mode
3. Write `my_generator.py` with PEP 723 dependencies block
4. Import `Generator` from `collimate.sdk`, create instance, use `@gen.run()` decorator
5. Write output files via `gen.fs.write()`, optionally append chat via `gen.chat.append()`
6. Set `summary_artifact` in manifest to the file the UI should display prominently
7. If you need user-editable config (a schema_form for flat knobs, a long-form prompt, a template, anything), write one or more files in your generator directory and list them under `draft_files` in the manifest. Use `.set_yaml` for schema_form validation; any other extension is just a plain editable file. Read via `gen.config.read_schema_values("path")` (schema_form) or `gen.config.get_file("path")` (anything else).
8. If producing multiple cells, use `gen.update_cell()` for the first output and `gen.create_cell()` for each additional one
9. For iterative workflows (chat, refactor, format, review), call `gen.update_cell()` on each iteration. The history scrubber works automatically.
10. If you want streaming tool calls, mid-turn interrupt/redirect, and Bash output in the log panel for free, use `gen.chat.start_session()` + `gen.chat.send_turn()` (despite the name, not chat-specific — see "Persistent streaming sessions against a sandbox container" above). You declare the docker image and Dockerfile path; the host has no system default.
11. If you want the user to drive a containerized CLI interactively (a shell, Claude Code, a REPL), use `gen.start_terminal()` and commit the returned pointer as a `.terminal` file — the `terminal` renderer dispatches on that extension and attaches a live xterm.js. See "Expose a live terminal to the UI" above.
12. If long-running, set `execution_mode: "daemon"` and use `gen.wait_until_stopped()`
12. If the user's choice should *shape the run* (variant / strategy / route-to-Draft), author a `pickoptions.yaml` and set `pickoptions_file` in the manifest. Read the chosen path via `gen.config.get_pickoptions()`.
13. If the user needs to edit files *before* the run starts, the Draft flow handles it automatically: a generator with `draft_files` and no `pickoptions_file` auto-routes to Draft by default. Override with `default_route: "run"` to skip Draft, or give each pickoption terminal an explicit `route: "run"` / `route: "draft"`.
14. Use `summary_file: "<path>"` to pick which draft file opens as the first tab in the Draft editor. Purely a UX hint.
15. Test by running the script directly: `COLLIMATE_WORKSPACE=/tmp/test python my_generator.py` (runs in dev mode without IPC)

## IPC Protocol Reference (Internal)

The generator communicates with the backend over a TCP socket using JSON-per-line messages. You never need to use this directly (the SDK handles it), but it helps to understand what's happening:

**Generator -> Backend:**
```json
{"op": "status", "status": "running", "message": "Processing..."}
{"op": "progress", "current": 5, "total": 10}
{"op": "port_bound", "port": 8080, "name": "Preview"}
{"op": "update_cell", "name": "Chat", "summary": "...", "artifacts": [...], "metadata": {}, "deleted_files": []}
{"op": "create_side_cell", "name": "Output", "summary": "...", "artifacts": [...], "metadata": {}}
{"op": "request_settings_update", "settings_file_path": "update.set_yaml"}
{"op": "chat_start_session", "cell_id": "...", "image": "collimate-chat-worker", "dockerfile_dir": "/abs/path/to/shared", "shared": true, "backend": "claude_code_session", "model": "sonnet", "system_prompt": "..."}
{"op": "chat_send_turn", "cell_id": "...", "content": "..."}
{"op": "chat_stream_event", "cell_id": "...", "turn_id": "...", "event": {...}}
{"op": "create_terminal_session", "cell_id": "...", "container_id": "collimate-sandbox-...", "command": ["claude"], "cwd": "/home/coder/project", "env": {"TERM": "xterm-256color"}}
{"op": "destroy_terminal_session", "session_id": "tmnl_..."}
{"op": "finish", "success": true, "error_message": ""}
```

**Backend -> Generator (ACKs):**
```json
{"op": "ack_update", "cell_id": "uuid-here"}
{"op": "ack_create_side_cell", "cell_id": "uuid-here"}
{"op": "ack_settings_update", "ok": true, "values": {"key": "value"}}
{"op": "ack_chat_start_session", "ok": true, "session_id": "...", "backend": "...", "image": "...", "shared": true, "container_id": "collimate-sandbox-...", "reused": false}
{"op": "ack_chat_send_turn", "ok": true, "turn_id": "...", "usage": {...}, "file_changes": [...], "assistant_text": "...", "cancelled": false}
{"op": "ack_create_terminal_session", "ok": true, "session_id": "tmnl_...", "ws_path": "/api/terminals/tmnl_...", "token": "..."}
```

`gen.update_cell()`, `gen.create_cell()`, `gen.request_settings_update()`, `gen.chat.start_session()`, `gen.chat.send_turn()`, and `gen.start_terminal()` all block on their matching ACK. `gen.chat.emit_stream_event()` and `gen.stop_terminal()` are fire-and-forget — there is no ack for `chat_stream_event` or `destroy_terminal_session`.

**Backend endpoints the frontend uses to steer a running turn** (these are *not* IPC ops — they're HTTP routes that the API process handles directly against the active `chat_session`, bypassing the generator subprocess entirely):

```
POST /api/channels/{channel}/cells/{cell_id}/chat/interrupt
POST /api/channels/{channel}/cells/{cell_id}/chat/redirect   {"content": "..."}
```

Any generator that uses `gen.chat.send_turn()` automatically benefits — the cancel / redirect loop happens entirely inside `chat_session.send_turn()` and is transparent to the generator subprocess apart from the `cancelled` flag in the returned ack.

**History scrubber endpoints** — available for any cell whose visible id starts a `previous_version` chain, regardless of which generator produced the chain:

```
GET  /api/channels/{channel}/cells/{visible_cell_id}/versions
GET  /api/channels/{channel}/cells/{internal_cell_id}/files-tree
POST /api/channels/{channel}/cells/{visible_cell_id}/restore   {"target_cell_id": "..."}
POST /api/channels/{channel}/cells/{visible_cell_id}/fork      {"target_cell_id": "..."}
```

These are generator-agnostic. If your generator calls `gen.update_cell()` across runs, the scrubber UI and these endpoints just work.
