# How to Write a Collimate Renderer

This is a comprehensive reference for building renderers in Collimate. It contains every detail needed to write a renderer from scratch, including the full SDK API, manifest format, styling constraints, and real-world patterns.

## What Is a Renderer?

A renderer is an **ES module** (TypeScript/React or vanilla JS) that displays and optionally edits a file in the Collimate workspace. Renderers:

- Are matched to files by extension (e.g., `.md` files open in the markdown renderer)
- Can be read-only viewers or full editors with two-way content sync
- Can optionally render diff views (before/after comparison)
- Can load external libraries from CDNs
- Run in one of two hosting modes: **native** (Shadow DOM) or **iframe** (sandboxed)

## CRITICAL: Styling Constraints

**Native renderers run inside Shadow DOM.** This means:

- **className and Tailwind classes DO NOT WORK** - the host page's stylesheets do not cascade into the shadow root
- **You MUST use inline `style={}` attributes** for all styling
- Use full hex/rgb color values, not CSS variables or Tailwind utilities
- If you need CSS classes, inject them via `api.injectStyle()` or `api.loadCSS()`

**Iframe renderers** have full CSS isolation and can use any styling approach (classes, Tailwind, external sheets). However, they have higher overhead due to postMessage communication.

**Rule of thumb**: Use `embed: "native"` with inline styles for simple/lightweight renderers. Use `embed: "iframe"` when you need external CSS frameworks or full DOM isolation.

## File Structure

Renderers are organised into **groups**. Every renderer lives in its own directory under `collimate-sdk/renderers/<group>/`:

```
renderers/
  basic/                       # group folder
    monaco/
      manifest.rend_yaml       # REQUIRED: metadata, extensions, embed mode
      main.tsx                 # REQUIRED: the entrypoint module
    markdown/
      ...
  problem_space/               # another group
    mermaid/
      ...
```

A group is just a top-level subdirectory. Folder location is the only thing that determines group membership — there is no per-group config file. The build script copies the entire tree recursively to `api/templates/renderers/`, and on new-channel creation each group is seeded as one cell inside a single Renderers stack. So a fresh channel comes up with one cell per group (e.g. "Basic", "Problem Space"), each containing the source for its members.

To add a new group, create a new top-level subdirectory under `collimate-sdk/renderers/`. To add a renderer to an existing group, drop a new subdirectory under that group's folder. The runtime discovers renderers by scanning every `manifest.rend_yaml` in the channel's renderer source cells, so depth doesn't matter — it works at one level, two levels, or arbitrarily deep.

The `.rend_yaml` extension is what makes the frontend recognise this file as a renderer manifest and route it through the **schema_form** renderer for editing — you get a form with a fixed schema (dropdowns for `embed`, a list editor for `extensions`, etc.) instead of free-form YAML, so it is impossible to typo a required field or set `embed` to a value the runtime doesn't accept.

The `schema_form` renderer claims three extensions in total — `.gen_yaml` (generator manifests), `.rend_yaml` (renderer manifests), and `.set_yaml` (generator settings). Picking one of these extensions for any structured config file is enough to get the form UI for free.

## Step 1: Write the manifest.rend_yaml

### Full Manifest Schema

```yaml
# REQUIRED FIELDS
id: "my-renderer"              # Unique identifier (lowercase, hyphens ok)
name: "My Renderer"            # Display name in the UI
version: "1.0.0"               # Semantic version
entrypoint: "main.tsx"         # Entry file (.tsx, .ts, or .js)
embed: "native"                # "native" = Shadow DOM (inline styles only!)
                               # "iframe" = sandboxed iframe (any CSS ok)

# FILE MATCHING
extensions:                    # File extensions this renderer handles
  - ".myext"
  - ".other"

# DIFF SUPPORT
supports_diff: true            # true if you provide a diff view component

# OPTIONAL
summary: "Short description of what this renderer does."
```

### Real Examples

**Simple native text editor:**
```yaml
id: "text"
name: "Text Editor"
version: "1.1.0"
summary: "Plain-text viewer and editor powered by the React SDK."
entrypoint: "main.tsx"
embed: "native"
extensions:
  - ".txt"
  - ".log"
  - ".env"
  - ".gitignore"
  - ".cfg"
  - ".ini"
  - ".csv"
  - ".sh"
supports_diff: true
```

**Iframe renderer with external library:**
```yaml
id: "html"
name: "HTML Renderer"
version: "1.1.0"
summary: "Renders HTML with linked siblings and split-pane Monaco editor."
entrypoint: "main.tsx"
embed: "iframe"
extensions:
  - ".html"
  - ".htm"
supports_diff: true
```

**Native renderer with no editing (viewer only):**
```yaml
id: "website"
name: "Website Viewer"
version: "1.1.0"
summary: "Renders a URL in a sandboxed iframe."
entrypoint: "main.tsx"
embed: "native"
extensions:
  - ".website"
supports_diff: false
```

**Fallback renderer (no extensions = only used when explicitly selected):**
```yaml
id: "markdown"
name: "Markdown Renderer"
version: "1.1.0"
summary: "Fallback markdown renderer."
entrypoint: "main.tsx"
embed: "native"
extensions: []
supports_diff: true
```

## Step 2: Write the Renderer Module

### Two SDKs Available

**React SDK** (recommended for most renderers):
```typescript
import React from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';
```

**Vanilla SDK** (for imperative DOM manipulation):
```typescript
import { defineRenderer } from '/api/sdk/vanilla.js';
```

### Imports

Renderers use ES module imports. There is no build step - the runtime transpiles `.tsx` on the fly via Babel.

```typescript
// React from CDN
import React, { useState, useEffect, useRef } from 'https://esm.sh/react@18';

// Collimate React SDK (provides hooks and defineRenderer)
import { defineRenderer, useCollimateFile, useSiblingFile } from '/api/sdk/react.js';

// OR Collimate Vanilla SDK
import { defineRenderer } from '/api/sdk/vanilla.js';

// External libraries from CDN
import SomeLib from 'https://esm.sh/some-library@1.0.0';
```

**Important**: Always use `https://esm.sh/` for React and other npm packages. Always use `/api/sdk/react.js` or `/api/sdk/vanilla.js` for the Collimate SDK (root-relative paths).

## React SDK API

### defineRenderer()

Wraps your React component(s) and exports the mount/unmount lifecycle:

```typescript
export default defineRenderer({
    component: MyEditorComponent,           // REQUIRED: main view
    diffComponent: MyDiffComponent,         // OPTIONAL: diff view
});
```

### useCollimateFile() Hook

The primary hook. Returns everything you need to read/edit the file:

```typescript
const {
    initialContent,  // string: file content when renderer first opened (never changes)
    content,         // string: current synced content (updates on external changes)
    saveContent,     // (newContent: string) => void: push edits back to the workspace
    isReadOnly,      // boolean: true if file should not be editable
    fileName,        // string: name of the file being rendered (e.g., "output.md")
    api,             // RendererAPI: full API object (see below)
    diffContent,     // string | null: previous version content (only in diff mode)
} = useCollimateFile();
```

### useSiblingFile() Hook

Fetches a related file from the same cell (e.g., an HTML file loading its CSS):

```typescript
const { url, loading } = useSiblingFile('./styles.css');
// url: Blob URL string (pass to <link href> or <script src>)
// loading: boolean
```

### Full RendererAPI Object

Available via `const { api } = useCollimateFile()` or passed directly in vanilla SDK:

```typescript
interface RendererAPI {
    // Content access
    getContent(): Promise<string>;                    // Current file content
    getDiffContent(): Promise<string | null>;         // Previous version (diff mode only)
    getFilename(): string;                            // File name
    getCellId(): string;                              // Cell UUID

    // Sibling files (other files in the same cell)
    getSiblingFile(path: string): Promise<string>;    // Fetch sibling file content

    // Editing
    onChange(newContent: string): void;                // Push content changes to workspace
    isReadOnly(): boolean;                            // Check if editing is disabled

    // File change notifications
    onFilesChanged(cb: (detail: any) => void): () => void;  // Subscribe; returns unsubscribe fn

    // Scroll persistence (renderer reloads preserve scroll position)
    onScrollRestore(cb: (top: number) => void): () => void; // Called with saved scroll position
    reportScroll(top: number): void;                         // Save current scroll position

    // Styling (for native/shadow DOM renderers)
    injectStyle(css: string): void;    // Inject a <style> tag into the shadow root
    loadCSS(href: string): void;       // Inject a <link rel="stylesheet"> into the shadow root
}
```

## Vanilla SDK API

For renderers that don't use React:

```typescript
import { defineRenderer } from '/api/sdk/vanilla.js';

export default defineRenderer({
    mount: async (container: HTMLElement, api: RendererAPI) => {
        // container: the DOM element to render into
        // api: the full RendererAPI object

        const content = await api.getContent();
        const filename = api.getFilename();

        container.innerHTML = `<pre>${content}</pre>`;

        // Return a cleanup function (optional)
        return () => {
            container.innerHTML = '';
        };
    },

    mountDiff: async (container: HTMLElement, api: RendererAPI) => {
        // Optional: custom diff view
        const current = await api.getContent();
        const previous = await api.getDiffContent();
        container.innerHTML = `<div>Old: ${previous}</div><div>New: ${current}</div>`;
    }
});
```

## Complete Working Examples

### Example 1: Simple Text Editor (Native, React)

The simplest possible renderer. A textarea with a status bar.

**manifest.rend_yaml:**
```yaml
id: "text"
name: "Text Editor"
version: "1.1.0"
summary: "Plain-text viewer and editor."
entrypoint: "main.tsx"
embed: "native"
extensions:
  - ".txt"
  - ".log"
supports_diff: true
```

**main.tsx:**
```tsx
import React, { useState } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

function TextEditor() {
    const { content, saveContent, isReadOnly, fileName } = useCollimateFile();

    return (
        <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: '#0a0b0d' }}>
            <textarea
                value={content}
                disabled={isReadOnly}
                onChange={e => saveContent(e.target.value)}
                spellCheck={false}
                style={{
                    flex: 1,
                    width: '100%',
                    background: 'transparent',
                    color: '#e2e8f0',
                    fontFamily: 'monospace',
                    fontSize: 13,
                    lineHeight: 1.6,
                    padding: 16,
                    border: 'none',
                    outline: 'none',
                    resize: 'none'
                }}
            />
            <div style={{
                height: 22,
                background: '#1a1c23',
                borderTop: '1px solid #2a2d3a',
                display: 'flex',
                alignItems: 'center',
                padding: '0 12px',
                gap: 12,
                fontFamily: 'monospace',
                fontSize: 10,
                color: '#6b7280'
            }}>
                <span>{content.split('\n').length} lines</span>
                <span>{content.length} chars</span>
                <span style={{ marginLeft: 'auto' }}>{fileName}</span>
            </div>
        </div>
    );
}

export default defineRenderer({ component: TextEditor });
```

**Key takeaways:**
- Every style is inline (Shadow DOM requirement for `embed: "native"`)
- `saveContent()` is called on every keystroke for real-time sync
- `isReadOnly` disables the textarea when the file is read-only
- Root div fills 100% width and height

### Example 2: Markdown Renderer (Native, React, Split Pane)

A split-pane editor with raw markdown on the left and rendered preview on the right.

**manifest.rend_yaml:**
```yaml
id: "markdown"
name: "Markdown Renderer"
version: "1.1.0"
summary: "Fallback markdown renderer."
entrypoint: "main.tsx"
embed: "native"
extensions: []
supports_diff: true
```

**main.tsx:**
```tsx
import React, { useState, useEffect } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

function parseMarkdown(md) {
    if (!md) return '';
    let html = md.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

    // Code blocks (fenced)
    html = html.replace(/```(\w*)\n([\s\S]*?)```/gm, (_, lang, code) =>
        `<pre><code style="background:#1a1c23;padding:12px;display:block;border-radius:6px;border:1px solid #2a2d3a;">${code.trimEnd()}</code></pre>`
    );
    // Inline code
    html = html.replace(/`([^`\n]+)`/g,
        '<code style="background:#1f2937;color:#f59e0b;padding:2px 4px;border-radius:3px;">$1</code>'
    );
    // Headings (h6 down to h1 to avoid greedy matching)
    html = html.replace(/^###### (.+)$/gm, '<h6 style="color:#f9fafb;font-weight:600;margin-top:1em;">$1</h6>');
    html = html.replace(/^##### (.+)$/gm, '<h5 style="color:#f9fafb;font-weight:600;margin-top:1em;">$1</h5>');
    html = html.replace(/^#### (.+)$/gm, '<h4 style="color:#f9fafb;font-weight:600;margin-top:1em;">$1</h4>');
    html = html.replace(/^### (.+)$/gm, '<h3 style="color:#f9fafb;font-weight:600;margin-top:1em;font-size:1.1em;">$1</h3>');
    html = html.replace(/^## (.+)$/gm, '<h2 style="color:#f9fafb;font-weight:600;margin-top:1em;font-size:1.35em;">$1</h2>');
    html = html.replace(/^# (.+)$/gm, '<h1 style="color:#f9fafb;font-weight:600;margin-top:1em;font-size:1.75em;border-bottom:1px solid #374151;padding-bottom:4px;">$1</h1>');
    // Emphasis
    html = html.replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>');
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
    // Links and images
    html = html.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img alt="$1" src="$2" style="max-width:100%">');
    html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" style="color:#60a5fa;text-decoration:underline;">$1</a>');
    // Paragraphs
    html = html.replace(/\n\n+/g, '\n\n');
    html = html.split('\n\n').map(block => {
        if (/^<[hpuobldi]/.test(block.trim())) return block;
        return `<p style="margin:0.75em 0;">${block}</p>`;
    }).join('\n');

    return html;
}

function MarkdownEditor() {
    const { content, saveContent, isReadOnly } = useCollimateFile();
    const [local, setLocal] = useState(content);

    useEffect(() => { setLocal(content); }, [content]);

    return (
        <div style={{ display: 'flex', width: '100%', height: '100%', background: '#0a0b0d' }}>
            {!isReadOnly && (
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', borderRight: '1px solid #2a2d3a' }}>
                    <textarea
                        value={local}
                        onChange={e => {
                            setLocal(e.target.value);
                            saveContent(e.target.value);
                        }}
                        style={{
                            flex: 1,
                            background: 'transparent',
                            color: '#e2e8f0',
                            fontFamily: 'monospace',
                            fontSize: 13,
                            lineHeight: 1.6,
                            padding: 16,
                            border: 'none',
                            outline: 'none',
                            resize: 'none'
                        }}
                        spellCheck={false}
                    />
                </div>
            )}
            <div
                style={{
                    flex: 1,
                    overflowY: 'auto',
                    padding: 24,
                    color: '#d1d5db',
                    fontFamily: 'sans-serif',
                    fontSize: 14,
                    lineHeight: 1.6
                }}
                dangerouslySetInnerHTML={{ __html: parseMarkdown(local) }}
            />
        </div>
    );
}

export default defineRenderer({ component: MarkdownEditor });
```

**Key takeaways:**
- Split pane: editor (left) hides when `isReadOnly` is true, showing only the preview
- Custom markdown parser uses regex (avoids heavy library dependency)
- All generated HTML also uses inline styles (shadow DOM!)
- Local state (`local`) syncs from `content` on external changes

### Example 3: Monaco Code Editor (Iframe, React, with Diff Support)

A full code editor using the Monaco library from CDN, with language detection and diff view.

**manifest.rend_yaml:**
```yaml
id: "monaco"
name: "Code Editor"
version: "1.1.0"
summary: "VS Code-powered code editor with language detection."
entrypoint: "main.tsx"
embed: "iframe"
extensions:
  - ".js"
  - ".ts"
  - ".py"
  - ".go"
  - ".json"
  - ".yaml"
supports_diff: true
```

**main.tsx:**
```tsx
import React, { useEffect, useRef } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

const MONACO_VERSION = '0.44.0';
const MONACO_BASE = `https://cdn.jsdelivr.net/npm/monaco-editor@${MONACO_VERSION}/min/vs`;

// Dynamic script loader (singleton pattern)
function loadScript(src) {
    return new Promise((resolve, reject) => {
        if (document.querySelector(`script[src="${src}"]`)) { resolve(); return; }
        const s = document.createElement('script');
        s.src = src;
        s.onload = resolve;
        s.onerror = () => reject(new Error(`Failed to load: ${src}`));
        document.head.appendChild(s);
    });
}

let _monacoPromise = null;
function ensureMonaco() {
    if (_monacoPromise) return _monacoPromise;
    _monacoPromise = loadScript(`${MONACO_BASE}/loader.js`).then(() =>
        new Promise((resolve) => {
            window.require.config({ paths: { vs: MONACO_BASE } });
            window.require(['vs/editor/editor.main'], () => resolve(window.monaco));
        })
    );
    return _monacoPromise;
}

// Language detection from file extension or content
function detectLanguage(content = '', filename = '') {
    const ext = filename.split('.').pop().toLowerCase();
    const extMap = {
        'js': 'javascript', 'jsx': 'javascript', 'mjs': 'javascript',
        'ts': 'typescript', 'tsx': 'typescript',
        'py': 'python', 'go': 'go', 'rs': 'rust', 'java': 'java',
        'c': 'c', 'cpp': 'cpp', 'css': 'css', 'scss': 'scss',
        'html': 'html', 'xml': 'xml', 'svg': 'xml',
        'json': 'json', 'yaml': 'yaml', 'yml': 'yaml',
        'sql': 'sql', 'sh': 'shell', 'bash': 'shell',
    };
    if (extMap[ext]) return extMap[ext];

    // Content-based fallback
    const t = content.trimStart();
    if (/^(import|export|const|let|var|function|class)\b/.test(t)) return 'typescript';
    if (/^(import |from |def |class )/.test(t)) return 'python';
    if (t.startsWith('{') || t.startsWith('[')) return 'json';
    return 'plaintext';
}

// Main editor component
function MonacoEditor() {
    const { content, saveContent, isReadOnly, fileName } = useCollimateFile();
    const containerRef = useRef(null);
    const editorRef = useRef(null);

    useEffect(() => {
        if (!containerRef.current) return;
        let editor;
        ensureMonaco().then(monaco => {
            editor = monaco.editor.create(containerRef.current, {
                value: content || '',
                language: detectLanguage(content, fileName),
                theme: 'vs-dark',
                readOnly: isReadOnly,
                automaticLayout: true,
                minimap: { enabled: false }
            });
            if (!isReadOnly) {
                editor.onDidChangeModelContent(() => saveContent(editor.getValue()));
            }
            editorRef.current = editor;
        });
        return () => { if (editor) editor.dispose(); };
    }, []);

    // Sync external content changes
    useEffect(() => {
        if (editorRef.current && editorRef.current.getValue() !== content) {
            editorRef.current.setValue(content || '');
        }
    }, [content]);

    return <div ref={containerRef} style={{ width: '100%', height: '100%', backgroundColor: '#1e1e1e' }} />;
}

// Diff editor component
function MonacoDiffEditor() {
    const { content, diffContent, fileName } = useCollimateFile();
    const containerRef = useRef(null);

    useEffect(() => {
        if (!containerRef.current) return;
        let diffEditor;
        ensureMonaco().then(monaco => {
            diffEditor = monaco.editor.createDiffEditor(containerRef.current, {
                theme: 'vs-dark',
                automaticLayout: true,
                renderSideBySide: true,
                readOnly: true
            });
            const lang = detectLanguage(content, fileName);
            diffEditor.setModel({
                original: monaco.editor.createModel(diffContent || '', lang),
                modified: monaco.editor.createModel(content || '', lang)
            });
        });
        return () => { if (diffEditor) diffEditor.dispose(); };
    }, [content, diffContent, fileName]);

    return <div ref={containerRef} style={{ width: '100%', height: '100%', backgroundColor: '#1e1e1e' }} />;
}

export default defineRenderer({
    component: MonacoEditor,
    diffComponent: MonacoDiffEditor
});
```

**Key takeaways:**
- Uses `embed: "iframe"` because Monaco manages its own DOM (needs full document context)
- Singleton promise pattern (`_monacoPromise`) prevents loading Monaco twice
- Cleanup function `editor.dispose()` prevents memory leaks
- Separate `diffComponent` provides side-by-side diff view
- External content changes synced via `useEffect` on `content`

### Example 4: HTML Preview (Iframe, React, Sibling File Loading)

Split-pane HTML renderer with Monaco editor (left) and live preview (right), resolving local asset references.

**main.tsx:**
```tsx
import React, { useEffect, useRef, useState } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

// ... (ensureMonaco() same as Monaco example above) ...

function HtmlEditor() {
    const { content, saveContent, isReadOnly, api } = useCollimateFile();
    const containerRef = useRef(null);
    const [previewHtml, setPreviewHtml] = useState('');

    // Resolve local asset references (./style.css, ./script.js) to blob URLs
    useEffect(() => {
        const process = async () => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(content, 'text/html');
            const elements = [...doc.querySelectorAll('[src], [href]')];

            for (const el of elements) {
                let url = el.getAttribute('src') || el.getAttribute('href');
                if (url && !url.startsWith('http') && !url.startsWith('data:') && !url.startsWith('#')) {
                    try {
                        const cleanPath = url.replace(/^\.\//, '');
                        const siblingContent = await api.getSiblingFile(cleanPath);
                        let mime = 'text/plain';
                        if (cleanPath.endsWith('.js')) mime = 'application/javascript';
                        else if (cleanPath.endsWith('.css')) mime = 'text/css';
                        else if (cleanPath.endsWith('.svg')) mime = 'image/svg+xml';

                        const blob = new Blob([siblingContent], { type: mime });
                        const blobUrl = URL.createObjectURL(blob);
                        if (el.hasAttribute('src')) el.setAttribute('src', blobUrl);
                        if (el.hasAttribute('href')) el.setAttribute('href', blobUrl);
                    } catch(e) {}
                }
            }
            setPreviewHtml(doc.documentElement.outerHTML);
        };
        process();
    }, [content, api]);

    // Monaco editor for editing HTML
    useEffect(() => {
        if (isReadOnly || !containerRef.current) return;
        let editor;
        ensureMonaco().then(monaco => {
            editor = monaco.editor.create(containerRef.current, {
                value: content,
                language: 'html',
                theme: 'vs-dark',
                automaticLayout: true,
                minimap: { enabled: false }
            });
            editor.onDidChangeModelContent(() => saveContent(editor.getValue()));
        });
        return () => { if (editor) editor.dispose(); };
    }, [isReadOnly]);

    return (
        <div style={{ display: 'flex', width: '100%', height: '100%', backgroundColor: '#1e1e1e' }}>
            {!isReadOnly && <div ref={containerRef} style={{ flex: 1, borderRight: '1px solid #333' }} />}
            <div style={{ flex: 1, backgroundColor: 'white', position: 'relative' }}>
                <iframe
                    srcDoc={previewHtml}
                    style={{ width: '100%', height: '100%', border: 'none' }}
                    sandbox="allow-scripts allow-forms allow-same-origin allow-popups"
                />
            </div>
        </div>
    );
}

export default defineRenderer({ component: HtmlEditor });
```

**Key takeaways:**
- `api.getSiblingFile()` fetches other files from the same cell (CSS, JS assets)
- Local references converted to blob URLs for the preview iframe
- `srcDoc` used instead of `src` for the preview iframe

### Example 5: Website Viewer (Native, React, No Edit)

A URL viewer with address bar. Renders `.website` files (which contain a URL string).

**main.tsx:**
```tsx
import React, { useState } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

function WebsiteViewer() {
    const { content, saveContent, isReadOnly } = useCollimateFile();
    const [localUrl, setLocalUrl] = useState(content.trim());
    const [activeUrl, setActiveUrl] = useState(content.trim());

    const commit = () => {
        const u = localUrl.trim();
        saveContent(u);
        setActiveUrl(u);
    };

    return (
        <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: '#0a0b0d' }}>
            <div style={{
                height: 32,
                background: '#1a1c23',
                borderBottom: '1px solid #2a2d3a',
                display: 'flex',
                alignItems: 'center',
                padding: '0 8px',
                gap: 8,
                flexShrink: 0
            }}>
                <input
                    type="text"
                    value={localUrl}
                    onChange={e => setLocalUrl(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && commit()}
                    readOnly={isReadOnly}
                    placeholder="https://..."
                    style={{
                        flex: 1, height: 22,
                        background: '#0d0f14',
                        border: '1px solid #2a2d3a',
                        borderRadius: 4,
                        padding: '0 8px',
                        color: '#e2e8f0',
                        fontFamily: 'monospace',
                        fontSize: 11,
                        outline: 'none'
                    }}
                />
                {!isReadOnly && (
                    <button
                        onClick={commit}
                        style={{
                            height: 22, padding: '0 12px',
                            background: '#2d2f3e',
                            border: '1px solid #3a3d52',
                            borderRadius: 4,
                            color: '#e2e8f0',
                            fontFamily: 'monospace',
                            fontSize: 11,
                            cursor: 'pointer'
                        }}
                    >Go</button>
                )}
            </div>
            {activeUrl ? (
                <iframe
                    src={activeUrl}
                    style={{ flex: 1, width: '100%', border: 'none', background: 'white' }}
                    sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                />
            ) : (
                <div style={{
                    flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
                    color: '#4b5563', fontFamily: 'monospace', fontSize: 13
                }}>
                    Enter a URL above and press Enter
                </div>
            )}
        </div>
    );
}

export default defineRenderer({ component: WebsiteViewer });
```

**Key takeaways:**
- File content is just a URL string
- `saveContent()` only called on explicit "Go" action (not every keystroke)
- Empty state shows a placeholder message
- Native embed with all inline styles

## Styling Patterns

### Dark Theme Color Palette (Used Across All Built-in Renderers)

```
Background (darkest):  #0a0b0d
Background (panels):   #1a1c23
Background (inputs):   #0d0f14
Background (code):     #1f2937
Borders:               #2a2d3a
Text (primary):        #e2e8f0
Text (secondary):      #d1d5db
Text (muted):          #6b7280
Text (dimmer):         #4b5563
Accent (links):        #60a5fa
Accent (code):         #f59e0b
Headings:              #f9fafb
Dividers:              #374151
```

### Inline Style Object Patterns

**Full-bleed container:**
```typescript
style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: '#0a0b0d' }}
```

**Split pane (horizontal):**
```typescript
<div style={{ display: 'flex', width: '100%', height: '100%' }}>
    <div style={{ flex: 1, borderRight: '1px solid #2a2d3a' }}>Left</div>
    <div style={{ flex: 1 }}>Right</div>
</div>
```

**Status bar:**
```typescript
<div style={{
    height: 22,
    background: '#1a1c23',
    borderTop: '1px solid #2a2d3a',
    display: 'flex',
    alignItems: 'center',
    padding: '0 12px',
    gap: 12,
    fontFamily: 'monospace',
    fontSize: 10,
    color: '#6b7280'
}}>
```

**Monospace textarea:**
```typescript
<textarea style={{
    flex: 1,
    width: '100%',
    background: 'transparent',
    color: '#e2e8f0',
    fontFamily: 'monospace',
    fontSize: 13,
    lineHeight: 1.6,
    padding: 16,
    border: 'none',
    outline: 'none',
    resize: 'none'
}} />
```

### Injecting CSS (for Native Renderers That Need Classes)

If you must use CSS classes in a native renderer, inject them into the shadow root:

```typescript
function MyRenderer() {
    const { api } = useCollimateFile();

    useEffect(() => {
        api.injectStyle(`
            .my-container { display: flex; gap: 8px; }
            .my-button { background: #2d2f3e; color: white; border: none; padding: 4px 12px; }
            .my-button:hover { background: #3d3f4e; }
        `);
    }, []);

    return <div className="my-container">...</div>;
}
```

For external CSS (e.g., from a CDN):
```typescript
api.loadCSS('https://cdn.jsdelivr.net/npm/some-library/dist/styles.css');
```

## Loading External Libraries

### Pattern: CDN Script Loading with Singleton Promise

```typescript
const LIB_VERSION = '1.0.0';
const LIB_CDN = `https://cdn.jsdelivr.net/npm/my-lib@${LIB_VERSION}/dist/index.js`;

function loadScript(src) {
    return new Promise((resolve, reject) => {
        if (document.querySelector(`script[src="${src}"]`)) { resolve(); return; }
        const s = document.createElement('script');
        s.src = src;
        s.onload = resolve;
        s.onerror = () => reject(new Error(`Failed to load: ${src}`));
        document.head.appendChild(s);
    });
}

let _libPromise = null;
function ensureLib() {
    if (_libPromise) return _libPromise;
    _libPromise = loadScript(LIB_CDN).then(() => window.MyLib);
    return _libPromise;
}

// Usage in component:
useEffect(() => {
    ensureLib().then(lib => {
        // Use lib here
    });
}, []);
```

### Pattern: ESM Import from CDN

```typescript
import SomeLib from 'https://esm.sh/some-library@1.0.0';
```

## Hosting Modes: Native vs Iframe

### Native (`embed: "native"`)

- Renderer is mounted inside a Shadow DOM container in the main page
- **Pros**: Better performance, shared memory, no postMessage overhead
- **Cons**: CSS isolation via shadow root means only inline styles or injected CSS
- **Use for**: Simple renderers, text editors, status displays, URL viewers
- **All existing native renderers**: text, markdown, website

### Iframe (`embed: "iframe"`)

- Renderer is mounted inside a sandboxed iframe
- **Pros**: Full CSS support (classes, external sheets), complete DOM isolation
- **Cons**: Higher memory usage, postMessage-based communication
- **Use for**: Complex renderers needing external CSS libraries, security-sensitive content
- **All existing iframe renderers**: monaco, html, milkdown, excalidraw, react-diff

### How the Runtime Loads Your Renderer

1. Frontend fetches renderer source from `/api/renderers/{id}/source`
2. If entrypoint is `.tsx` or `.ts`, it's transpiled on-the-fly via Babel standalone
3. SDK import paths (`/api/sdk/react.js`) are rewritten to absolute URLs
4. The transpiled code is loaded as a dynamic ES module
5. `renderer.mount(containerElement, apiObject)` is called
6. On unmount, the cleanup function (if returned) is called

## Checklist for Creating a New Renderer

1. Create directory: `collimate-sdk/renderers/my_renderer/`
2. Write `manifest.rend_yaml` with id, name, version, entrypoint, embed mode, extensions
3. Write `main.tsx` (or `.ts`/`.js`)
4. Import React from `https://esm.sh/react@18` and SDK from `/api/sdk/react.js`
5. Create your component using `useCollimateFile()` hook
6. Export via `defineRenderer({ component: MyComponent })`
7. If supporting diff mode, add `diffComponent` to `defineRenderer()`
8. **If embed is "native"**: use ONLY inline styles, no className/Tailwind
9. **If embed is "iframe"**: any styling approach works
10. Ensure your root element is `width: 100%` and `height: 100%`
11. Handle both `isReadOnly === true` (viewer) and `isReadOnly === false` (editor) states
12. Call `saveContent()` to push edits back (not needed for read-only renderers)
13. Return a cleanup function from mount if your renderer allocates resources (editors, event listeners)

## Renderer Resolution Order

When a file needs to be displayed, the frontend picks a renderer using this priority:

1. **User preferences** - If the user has set a preferred renderer for this extension
2. **Extension match** - First renderer whose `extensions` array includes the file's extension
3. **Hardcoded fallbacks**:
   - `.md` -> milkdown (iframe)
   - `.txt`, `.log` -> text (native)
   - `.excalidraw` -> excalidraw (iframe)
   - Everything else -> monaco (iframe)

If your renderer has `extensions: []` (empty), it will only be used when explicitly selected by the user or referenced by name in the code.
