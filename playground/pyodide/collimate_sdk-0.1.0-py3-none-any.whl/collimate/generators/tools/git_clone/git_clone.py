# /// script
# dependencies = ["pyyaml"]
# ///
"""
Git Clone Generator — clones a GitHub/GitLab repo and copies its files
into the output cell.
"""

import os
import subprocess
import tempfile
from collimate.sdk import Generator

gen = Generator()


def _collect_files(root):
    """Walk directory and return list of (relative_path, bytes) pairs, skipping .git."""
    files = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d != ".git"]
        for fname in filenames:
            abs_path = os.path.join(dirpath, fname)
            rel_path = os.path.relpath(abs_path, root)
            try:
                with open(abs_path, "rb") as f:
                    data = f.read()
                files.append((rel_path, data))
            except (OSError, PermissionError):
                gen.log.warning("Skipping unreadable file: %s", rel_path)
    return files


def _build_auth_url(repo_url: str, user: str, password: str) -> str:
    """Inject credentials into an https:// URL. Public clone is unchanged."""
    if not user and not password:
        return repo_url
    if not repo_url.startswith("https://"):
        # Only https supports inline credentials; ssh/git URLs use keys instead
        return repo_url
    from urllib.parse import quote
    encoded_user = quote(user, safe="")
    encoded_pw = quote(password, safe="")
    return f"https://{encoded_user}:{encoded_pw}@{repo_url[len('https://'):]}"


@gen.run(name="Git Clone")
def main():
    settings = gen.config.read_schema_values("settings.set_yaml")
    repo_url = gen.params.get("repo_url") or settings.get("repo_url", "")
    github_user = settings.get("github_user", "") or ""
    github_password = settings.get("github_password", "") or ""

    if not repo_url:
        raise ValueError("No repository URL provided. Set repo_url in parameters or settings.")

    gen.status = f"Cloning {repo_url}..."
    clone_url = _build_auth_url(repo_url, github_user, github_password)

    with tempfile.TemporaryDirectory() as tmp_dir:
        clone_dest = os.path.join(tmp_dir, "repo")
        result = subprocess.run(
            ["git", "clone", "--depth", "1", clone_url, clone_dest],
            capture_output=True,
            text=True,
            timeout=300,
        )
        if result.returncode != 0:
            # Scrub credentials from git's error output before raising
            stderr = result.stderr.strip()
            if github_password:
                stderr = stderr.replace(github_password, "***")
            if github_user:
                stderr = stderr.replace(github_user, "***")
            raise RuntimeError(f"git clone failed:\n{stderr}")

        gen.status = "Copying files to output cell..."
        files = _collect_files(clone_dest)

        for rel_path, data in files:
            try:
                text = data.decode("utf-8")
                gen.fs.write(rel_path, text)
            except UnicodeDecodeError:
                gen.fs.write_bytes(rel_path, data)

        gen.status = "Writing summary..."
        summary_lines = [
            "# Git Clone Output",
            "",
            f"**Repository:** {repo_url}",
            f"**Files copied:** {len(files)}",
            "",
            "## File listing",
            "",
        ]
        for rel_path, _ in sorted(files):
            summary_lines.append(f"- `{rel_path}`")

        gen.fs.write("clone_summary.md", "\n".join(summary_lines))

    gen.update_cell(name="Git Clone", summary=f"Cloned {repo_url}")


if __name__ == "__main__":
    main()
