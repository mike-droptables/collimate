# /// script
# requires-python = ">=3.11"
# dependencies = ["docker", "pyyaml"]
# ///
"""VS Code Env — containerised VS Code Server for the cell.

Owns its own image (``collimate-vscode-env:v2``, single-consumer) and runs it
through the shared ``_env_shared.DockerEnvironment`` helper — no embedded
docker-py lifecycle. The image's own entrypoint launches code-server; this
generator publishes the port and surfaces it as a live preview.
"""
from __future__ import annotations

import asyncio
import json
import os
import socket
import sys
import threading
import time
import urllib.request
from pathlib import Path

import gen

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from _env_shared import DockerEnvironment  # noqa: E402

IMAGE_TAG = "collimate-vscode-env:v2"


async def run() -> None:
    cfg = gen.config("settings.set_yaml")
    github_login = bool(cfg.get("github_login", False))
    startup_commands = _as_string_list(cfg.get("startup_commands"))
    mount_host_claude = bool(cfg.get("mount_host_claude", True))

    port = _find_free_port(8080)
    gen.log(f"Using port {port}")
    _ensure_workspace_has_placeholder()

    env: dict[str, str] = {"PORT": str(port)}
    if github_login:
        env["GITHUB_USER"] = await gen.secret(
            "githubuser", prompt_if_missing=True,
            description="GitHub username for HTTPS clone/push from VSCode",
        )
        env["GITHUB_PASSWORD"] = await gen.secret(
            "githubpassword", prompt_if_missing=True,
            description="GitHub personal-access token (HTTPS password)",
        )
        gen.log("Passing keystore git credentials into the container")
    if startup_commands:
        env["STARTUP_COMMANDS"] = json.dumps(startup_commands)

    volumes: dict = {}
    if mount_host_claude:
        host_claude = os.path.expanduser("~/.claude")
        if os.path.isdir(host_claude):
            volumes[host_claude] = {"bind": "/home/coder/.claude", "mode": "rw"}
            gen.log("Mounting host ~/.claude into the container")
        else:
            gen.log(
                f"mount_host_claude is on but {host_claude} does not exist — "
                "Claude Code will start unauthenticated"
            )

    # The image ships its own ENTRYPOINT (entrypoint.sh launches code-server) —
    # command=None lets it run. The cell workspace is mounted read-only at
    # /workspace; the entrypoint copies it into the project dir.
    container_name_prefix = "collimate-vscode-env"
    docker_env = DockerEnvironment(
        image=IMAGE_TAG,
        mount="/workspace", mount_mode="ro",
        build_context=str(Path(__file__).resolve().parent),
        environment=env, volumes=volumes,
        ports={f"{port}/tcp": ("127.0.0.1", port)},
        command=None,
        name_prefix=container_name_prefix, kind="vscode_env",
    )
    container = docker_env.container
    try:
        gen.status("Waiting for VS Code Server…")
        if not _wait_for_ready(port, timeout=120):
            raise RuntimeError("VS Code Server did not become ready within 120s.")

        iframe_path = "?command=claude-code.chat.focus"
        await gen.serve_port(
            port, name="VS Code", path=iframe_path,
            snapshot_source={
                "container_name": container.name,
                "project_dir": "/home/coder/project",
            },
        )

        channel = os.environ.get("COLLIMATE_CHANNEL", "")
        run_id = os.environ.get("COLLIMATE_RUN_ID", "")
        proxy_url = f"/proxy/{channel}/{run_id}/{port}/{iframe_path}"
        gen.update_file("vscode-server.website", json.dumps({"url": proxy_url}))

        await gen.update(
            name="VS Code Env",
            summary=f"VS Code Server on port {port}",
            pinned="vscode-server.website",
        )
        gen.status("VS Code Server is running.")

        threading.Thread(target=_tail_logs, args=(container,), daemon=True).start()

        while not gen.cancelled:
            await asyncio.sleep(0.5)
    finally:
        gen.log("Stopping VS Code Env container…")
        docker_env.close()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _find_free_port(start: int = 8080) -> int:
    port = start
    while port < 9000:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                port += 1
    raise RuntimeError("No free port found in range 8080-8999")


def _wait_for_ready(port: int, timeout: int = 120) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=2)
            return True
        except Exception:
            time.sleep(2)
    return False


def _ensure_workspace_has_placeholder() -> None:
    """Empty workspaces get a README so VS Code's explorer isn't blank."""
    if gen.list_files():
        return
    gen.update_file(
        "README.md",
        "# Empty workspace\n\n"
        "No input cell was attached. Create files with the VS Code explorer "
        "or run a previous generator (e.g. `git_clone`) to populate this "
        "cell before running `VS Code Env`.\n",
    )


def _tail_logs(container) -> None:
    try:
        for chunk in container.logs(stream=True, follow=True):
            line = chunk.decode("utf-8", errors="replace").rstrip()
            if line:
                gen.log(f"[container] {line}")
    except Exception as e:
        gen.log(f"log tail ended: {e}")


def _as_string_list(raw) -> list[str]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return [str(x) for x in raw if x is not None and str(x).strip()]
    if isinstance(raw, str):
        return [raw] if raw.strip() else []
    return []


if __name__ == "__main__":
    gen.main(run)
