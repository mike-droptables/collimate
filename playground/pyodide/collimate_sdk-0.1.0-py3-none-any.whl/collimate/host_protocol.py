# SPDX-License-Identifier: Apache-2.0
"""Runtime-neutral host protocol shared by native and wasm backends.

A generator's ``run()`` ultimately drives a host that implements
:class:`Host`. Two implementations exist today:

* **WASM** — :class:`process_manager.wasm_runner.WasmRunnerMixin`
  (in-process, direct method calls).
* **Native** — :class:`process_manager.host.HostMixin` is invoked
  by the IPC handler in ``api/process_manager/ipc.py`` after a
  generator subprocess sends an op over TCP-JSON. The subprocess
  side stays in :class:`collimate._host.HostBridge` for now —
  Phase 3 of the cleanup plan migrates it onto a ``HostClient``
  that mirrors this protocol exactly.

The protocol is **deliberately small**. Anything bigger
(terminals, ports, subprocess streaming, mid-run settings modal,
renderer action polling, snapshot diffing, live streaming chat) is
**Tier B** and lives outside this contract: native-only, no shared
signature.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Protocol, runtime_checkable


class Cancelled(Exception):
    """Raised when the user cancels a modal (api_key, secret, settings)
    or stops the run.

    Single class shared by both runtimes — a Tier-A-only generator
    catches the same identity regardless of whether it's running
    under :mod:`collimate.native` or :mod:`collimate.wasm`. Each
    runtime re-exports this from its top-level module so existing
    ``from collimate.native import Cancelled`` / ``from collimate.wasm
    import Cancelled`` imports keep working.
    """


@dataclass
class Message:
    """A single chat message. role ∈ {"user", "assistant", "system"}."""
    role: str
    content: str
    timestamp: str = ""

    def to_dict(self) -> dict:
        return {"role": self.role, "content": self.content, "timestamp": self.timestamp}


@runtime_checkable
class Host(Protocol):
    """The runtime contract.

    Every native or wasm runner must implement these. Generator code
    never calls them directly — they sit behind ``gen.update``,
    ``gen.cancelled``, ``gen.log``, ``gen.status``,
    ``gen.create_stack_cell``, ``gen.api_key`` etc.
    """

    async def emit_partial(
        self,
        *,
        files: Optional[dict[str, "str | bytes"]] = None,
        cell_name: Optional[str] = None,
        summary: Optional[str] = None,
        pinned: Optional[str] = None,
    ) -> None: ...

    def is_cancelled(self) -> bool: ...

    def push_log(self, line: str) -> None: ...

    def set_status(self, message: str) -> None: ...

    async def create_side_cell(
        self,
        *,
        name: Optional[str] = None,
        summary: Optional[str] = None,
        pinned: Optional[str] = None,
        files: Optional[dict[str, "str | bytes"]] = None,
    ) -> str: ...

    async def request_key(
        self,
        key_name: str,
        description: str = "",
        force: bool = False,
    ) -> str: ...


__all__ = ["Cancelled", "Host", "Message"]
