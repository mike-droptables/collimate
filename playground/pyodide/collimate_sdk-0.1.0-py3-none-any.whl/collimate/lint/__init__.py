"""Manifest linter for Collimate generators and renderers.

Entry points
------------

- :func:`lint_generator_manifest`       — lint a ``manifest.gen_yaml`` file.
- :func:`lint_renderer_manifest`        — lint a ``manifest.rend_yaml`` file.
- :func:`lint_generator_manifest_data`  — lint a parsed dict (in-memory),
                                          checking files against a stage
                                          ``files_present`` set. Used by the
                                          generator-builders to validate the
                                          agent's scaffold before commit.
- :func:`lint_renderer_manifest_data`   — same, for renderers.
- :func:`lint_path`                     — auto-detect by filename or walk a
                                          directory.

Each returns a list of :class:`Issue` values. :func:`run_cli` is the
``collimate-lint`` entry point; see :mod:`collimate.lint.cli`.
"""

from .core import (
    Issue,
    Level,
    lint_generator_manifest,
    lint_generator_manifest_data,
    lint_renderer_manifest,
    lint_renderer_manifest_data,
    lint_path,
)

__all__ = [
    "Issue",
    "Level",
    "lint_generator_manifest",
    "lint_generator_manifest_data",
    "lint_renderer_manifest",
    "lint_renderer_manifest_data",
    "lint_path",
]
