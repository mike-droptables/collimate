"""Core linting logic for Collimate manifests.

Kept dependency-light: only the stdlib + PyYAML (already a transitive dep
via the SDK). No pydantic models — the manifest surface is small enough that
a handful of typed checks per field are clearer than a big schema.
"""

from __future__ import annotations

import enum
import os
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError as e:  # pragma: no cover — PyYAML is always installed
    raise ImportError(
        "collimate-lint requires PyYAML. Install it with `pip install pyyaml`."
    ) from e


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


class Level(str, enum.Enum):
    ERROR = "error"
    WARNING = "warning"


@dataclass
class Issue:
    """A single lint finding."""

    level: Level
    code: str
    message: str
    path: Path
    field: str | None = None

    def format(self) -> str:
        loc = f"{self.path}" + (f":{self.field}" if self.field else "")
        return f"{self.level.value}: {self.code}: {loc}: {self.message}"


# ---------------------------------------------------------------------------
# Shared schemas
# ---------------------------------------------------------------------------

_GEN_REQUIRED = ("id", "name", "entrypoint")
_GEN_KNOWN = {
    "id", "name", "category", "version", "summary", "entrypoint",
    "chat", "daemon", "prompt_intent",
    "draft_files", "summary_file",
    "default_route",
    "inputs", "runtime",
    # Host-side subprocess controls (process_manager/manager.py): rlimits
    # caps RLIMIT_AS/CPU/etc. for native generators; env_passthrough lists
    # env vars that survive the per-subprocess scrub.
    "rlimits", "env_passthrough",
}
_GEN_DEFAULT_ROUTES = {"run", "draft"}
# ``both`` is a manifest declaration that the generator can run under
# either runtime. The host's per-runtime gate (process_manager) accepts
# it on either side.
_GEN_RUNTIMES = {"native", "wasm", "both"}
_GEN_CATEGORIES = {"chat", "iterate", "widen", "narrow", "tools"}

_REND_REQUIRED = ("id", "name", "entrypoint")
_REND_KNOWN = {
    "id", "name", "version", "summary", "entrypoint",
    "embed", "extensions", "supports_diff",
}
_REND_EMBED_MODES = {"native", "iframe"}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


@dataclass
class _Ctx:
    """Shared lint context.

    ``path`` is informational — for file-based linting it points at the
    manifest on disk; for in-memory linting (used by the
    generator-builders to validate the agent's stage before persisting)
    it's a synthetic Path like ``Path("(stage)/manifest.gen_yaml")``
    that just makes the Issue rendering readable.

    ``file_exists`` is the predicate the file-existence checks consult.
    For path-based linting it's ``lambda rel: (path.parent / rel).exists()``;
    for in-memory linting it's ``lambda rel: rel in stage_files``.
    """
    path: Path
    file_exists: Callable[[str], bool]
    issues: list[Issue] = field(default_factory=list)

    def error(self, code: str, message: str, field: str | None = None) -> None:
        self.issues.append(Issue(Level.ERROR, code, message, self.path, field))

    def warn(self, code: str, message: str, field: str | None = None) -> None:
        self.issues.append(Issue(Level.WARNING, code, message, self.path, field))


def _load_yaml(path: Path, ctx: _Ctx) -> dict[str, Any] | None:
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as e:
        ctx.error("io-error", f"cannot read: {e}")
        return None
    try:
        data = yaml.safe_load(raw)
    except yaml.YAMLError as e:
        ctx.error("yaml-parse", f"invalid YAML: {e}")
        return None
    if data is None:
        ctx.error("empty", "manifest file is empty")
        return None
    if not isinstance(data, dict):
        ctx.error("bad-root", f"manifest root must be a mapping, got {type(data).__name__}")
        return None
    return data


def _check_required(data: dict[str, Any], keys: tuple[str, ...], ctx: _Ctx) -> None:
    for key in keys:
        if key not in data:
            ctx.error("missing-required", f"required field '{key}' is missing", field=key)
        elif not isinstance(data[key], str) or not data[key].strip():
            ctx.error("bad-type", f"'{key}' must be a non-empty string", field=key)


def _check_string(data: dict[str, Any], key: str, ctx: _Ctx, *, required: bool = False) -> None:
    v = data.get(key)
    if v is None:
        if required:
            ctx.error("missing-required", f"required field '{key}' is missing", field=key)
        return
    if not isinstance(v, str):
        ctx.error("bad-type", f"'{key}' must be a string", field=key)


def _check_bool(data: dict[str, Any], key: str, ctx: _Ctx) -> None:
    if key in data and not isinstance(data[key], bool):
        ctx.error("bad-type", f"'{key}' must be a bool", field=key)


def _check_enum(data: dict[str, Any], key: str, choices: set[str], ctx: _Ctx) -> None:
    if key not in data:
        return
    v = data[key]
    if not isinstance(v, str):
        ctx.error("bad-type", f"'{key}' must be a string", field=key)
        return
    if v not in choices:
        ctx.error(
            "bad-enum",
            f"'{key}' must be one of {sorted(choices)}, got {v!r}",
            field=key,
        )


def _check_unknown(data: dict[str, Any], known: set[str], ctx: _Ctx) -> None:
    for k in data:
        if k not in known:
            ctx.warn("unknown-field", f"unknown field '{k}' — will be ignored", field=k)


def _check_file_exists(
    data: dict[str, Any], key: str, ctx: _Ctx, *, optional: bool = False
) -> None:
    v = data.get(key)
    if v is None:
        if not optional:
            ctx.error("missing-required", f"required field '{key}' is missing", field=key)
        return
    if not isinstance(v, str):
        ctx.error("bad-type", f"'{key}' must be a string filename", field=key)
        return
    if not ctx.file_exists(v):
        ctx.error(
            "missing-file",
            f"'{key}' references {v!r} but no such file exists",
            field=key,
        )


def _check_file_list(data: dict[str, Any], key: str, ctx: _Ctx) -> None:
    v = data.get(key)
    if v is None:
        return
    if not isinstance(v, list):
        ctx.error("bad-type", f"'{key}' must be a list of filenames", field=key)
        return
    for i, item in enumerate(v):
        if not isinstance(item, str):
            ctx.error(
                "bad-type",
                f"'{key}[{i}]' must be a string filename, got {type(item).__name__}",
                field=key,
            )
            continue
        if not ctx.file_exists(item):
            ctx.warn(
                "missing-file",
                f"'{key}' references {item!r} but no such file exists",
                field=key,
            )


def _check_inputs(data: dict[str, Any], ctx: _Ctx) -> None:
    inputs = data.get("inputs")
    if inputs is None:
        return
    if not isinstance(inputs, dict):
        ctx.error("bad-type", "'inputs' must be a mapping", field="inputs")
        return
    cells = inputs.get("cells")
    if cells is None:
        return
    if not isinstance(cells, dict):
        ctx.error("bad-type", "'inputs.cells' must be a mapping", field="inputs.cells")
        return
    lo = cells.get("min")
    hi = cells.get("max")
    for name, val in (("min", lo), ("max", hi)):
        if val is not None and not isinstance(val, int):
            ctx.error(
                "bad-type",
                f"'inputs.cells.{name}' must be an integer",
                field=f"inputs.cells.{name}",
            )
    if isinstance(lo, int) and isinstance(hi, int) and lo > hi:
        ctx.error(
            "bad-range",
            f"'inputs.cells.min' ({lo}) > 'inputs.cells.max' ({hi})",
            field="inputs.cells",
        )


def _check_extensions(data: dict[str, Any], ctx: _Ctx) -> None:
    v = data.get("extensions")
    if v is None:
        return
    if not isinstance(v, list):
        ctx.error("bad-type", "'extensions' must be a list", field="extensions")
        return
    for i, ext in enumerate(v):
        if not isinstance(ext, str):
            ctx.error(
                "bad-type",
                f"'extensions[{i}]' must be a string, got {type(ext).__name__}",
                field="extensions",
            )
            continue
        if not ext.startswith("."):
            ctx.warn(
                "ext-no-dot",
                f"extension {ext!r} should start with a dot (e.g. '.md')",
                field="extensions",
            )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def _lint_generator_body(
    data: dict[str, Any],
    ctx: _Ctx,
    *,
    target_runtime: str | None,
) -> None:
    """Run the generator-manifest checks against an already-loaded dict.

    ``target_runtime`` enforces that the manifest's declared runtime is
    compatible with the caller's environment. When set:

    - ``"wasm"`` requires ``runtime`` to be one of {"wasm", "both"}.
    - ``"native"`` accepts ``runtime`` absent (legacy default), or
      one of {"native", "both"}.

    Used by the generator-builders to refuse to commit a scaffold whose
    runtime declaration won't actually run on the target host.
    """
    _check_required(data, _GEN_REQUIRED, ctx)
    _check_string(data, "version", ctx)
    _check_string(data, "summary", ctx)
    if not data.get("summary"):
        ctx.warn("no-summary", "'summary' is empty — generators without a summary look bare in the picker", field="summary")
    _check_string(data, "prompt_intent", ctx)
    _check_string(data, "category", ctx)
    _check_enum(data, "category", _GEN_CATEGORIES, ctx)

    _check_bool(data, "chat", ctx)
    _check_bool(data, "daemon", ctx)
    _check_enum(data, "default_route", _GEN_DEFAULT_ROUTES, ctx)
    _check_enum(data, "runtime", _GEN_RUNTIMES, ctx)

    if target_runtime is not None:
        rt = data.get("runtime")
        if target_runtime == "wasm":
            if rt not in ("wasm", "both"):
                ctx.error(
                    "runtime-mismatch",
                    f"this builder targets the wasm runtime, so 'runtime' "
                    f"must be 'wasm' or 'both' (got {rt!r})",
                    field="runtime",
                )
        elif target_runtime == "native":
            # Absent ``runtime`` defaults to native at the host gate, so
            # accept None. Reject only an explicit non-native value.
            if rt is not None and rt not in ("native", "both"):
                ctx.error(
                    "runtime-mismatch",
                    f"this builder targets the native runtime, so 'runtime' "
                    f"must be 'native', 'both', or omitted (got {rt!r})",
                    field="runtime",
                )

    _check_file_exists(data, "entrypoint", ctx, optional=False)
    _check_file_list(data, "draft_files", ctx)

    _check_inputs(data, ctx)
    _check_unknown(data, _GEN_KNOWN, ctx)


def _lint_renderer_body(data: dict[str, Any], ctx: _Ctx) -> None:
    """Run the renderer-manifest checks against an already-loaded dict."""
    _check_required(data, _REND_REQUIRED, ctx)
    _check_string(data, "version", ctx)
    _check_string(data, "summary", ctx)

    _check_enum(data, "embed", _REND_EMBED_MODES, ctx)
    _check_bool(data, "supports_diff", ctx)

    _check_file_exists(data, "entrypoint", ctx, optional=False)
    _check_extensions(data, ctx)

    _check_unknown(data, _REND_KNOWN, ctx)


def lint_generator_manifest(
    path: str | os.PathLike[str],
    *,
    target_runtime: str | None = None,
) -> list[Issue]:
    """Lint a single ``manifest.gen_yaml`` file on disk."""
    p = Path(path)
    ctx = _Ctx(path=p, file_exists=lambda rel: (p.parent / rel).exists())
    data = _load_yaml(p, ctx)
    if data is None:
        return ctx.issues
    _lint_generator_body(data, ctx, target_runtime=target_runtime)
    return ctx.issues


def lint_renderer_manifest(path: str | os.PathLike[str]) -> list[Issue]:
    """Lint a single ``manifest.rend_yaml`` file on disk."""
    p = Path(path)
    ctx = _Ctx(path=p, file_exists=lambda rel: (p.parent / rel).exists())
    data = _load_yaml(p, ctx)
    if data is None:
        return ctx.issues
    _lint_renderer_body(data, ctx)
    return ctx.issues


def lint_generator_manifest_data(
    data: dict[str, Any],
    *,
    files_present: set[str],
    target_runtime: str | None = None,
    pseudo_path: str = "(stage)/manifest.gen_yaml",
) -> list[Issue]:
    """Lint a generator manifest already parsed into a dict.

    Used by the generator-builders to validate the agent's staged
    manifest before persisting — no filesystem write needed.

    ``files_present`` is the set of relative paths the agent has staged
    so far (e.g. ``set(stage.keys())`` for the Standard builder or
    ``set(gen.list_files())`` for the WASM one). ``entrypoint`` and
    ``draft_files`` are checked against this set instead of disk.

    ``target_runtime`` enforces runtime compatibility — see
    :func:`_lint_generator_body`.
    """
    ctx = _Ctx(path=Path(pseudo_path), file_exists=lambda rel: rel in files_present)
    if not isinstance(data, dict):
        ctx.error(
            "bad-root",
            f"manifest must be a mapping, got {type(data).__name__}",
        )
        return ctx.issues
    _lint_generator_body(data, ctx, target_runtime=target_runtime)
    return ctx.issues


def lint_renderer_manifest_data(
    data: dict[str, Any],
    *,
    files_present: set[str],
    pseudo_path: str = "(stage)/manifest.rend_yaml",
) -> list[Issue]:
    """Lint a renderer manifest already parsed into a dict.

    Used by the renderer-builders, mirror of
    :func:`lint_generator_manifest_data`.
    """
    ctx = _Ctx(path=Path(pseudo_path), file_exists=lambda rel: rel in files_present)
    if not isinstance(data, dict):
        ctx.error(
            "bad-root",
            f"manifest must be a mapping, got {type(data).__name__}",
        )
        return ctx.issues
    _lint_renderer_body(data, ctx)
    return ctx.issues


def _detect_kind(path: Path) -> str | None:
    """Return 'generator', 'renderer', or None based on filename suffix."""
    name = path.name
    if name == "manifest.gen_yaml" or name.endswith(".gen_yaml"):
        return "generator"
    if name == "manifest.rend_yaml" or name.endswith(".rend_yaml"):
        return "renderer"
    # Legacy: a bare manifest.yaml in a renderers/ subtree is a renderer.
    if name == "manifest.yaml":
        parts = set(path.resolve().parts)
        if "renderers" in parts:
            return "renderer"
        if "generators" in parts:
            return "generator"
    return None


def lint_path(path: str | os.PathLike[str]) -> list[Issue]:
    """Lint a manifest file, or walk a directory and lint every manifest it
    finds. Unknown filenames are skipped with no error.
    """
    p = Path(path)
    if p.is_file():
        kind = _detect_kind(p)
        if kind == "generator":
            return lint_generator_manifest(p)
        if kind == "renderer":
            return lint_renderer_manifest(p)
        return [Issue(
            Level.ERROR, "unknown-kind",
            "cannot auto-detect manifest type — pass manifest.gen_yaml or manifest.rend_yaml",
            path=p,
        )]
    if not p.is_dir():
        return [Issue(Level.ERROR, "not-found", f"path does not exist: {p}", path=p)]

    issues: list[Issue] = []
    for sub in sorted(p.rglob("manifest.*_yaml")):
        kind = _detect_kind(sub)
        if kind == "generator":
            issues.extend(lint_generator_manifest(sub))
        elif kind == "renderer":
            issues.extend(lint_renderer_manifest(sub))
    return issues
