"""Core linting logic for Collimate manifests.

Kept dependency-light: only the stdlib + PyYAML (already a transitive dep
via the SDK). No pydantic models — the manifest surface is small enough that
a handful of typed checks per field are clearer than a big schema.
"""

from __future__ import annotations

import enum
import os
import re
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError as e:  # pragma: no cover — PyYAML is always installed
    raise ImportError(
        "collimate-lint requires PyYAML. Install it with `pip install pyyaml`."
    ) from e

# Shared per-field-type "empty value" semantics (stdlib-only module;
# pinned cross-language by shared/empty-values-contract.json).
from collimate.config_values import is_empty, type_empty_default


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


class Level(str, enum.Enum):
    ERROR = "error"
    WARNING = "warning"


@dataclass
class Issue:
    """A single lint finding."""

    level: Level
    code: str
    message: str
    path: Path
    field: str | None = None

    def format(self) -> str:
        loc = f"{self.path}" + (f":{self.field}" if self.field else "")
        return f"{self.level.value}: {self.code}: {loc}: {self.message}"


# ---------------------------------------------------------------------------
# Shared schemas
# ---------------------------------------------------------------------------

_GEN_REQUIRED = ("id", "name", "entrypoint", "summary")
_GEN_KNOWN = {
    "id", "name", "version", "summary", "entrypoint",
    "chat", "daemon", "prompt_intent",
    "draft_files",
    "inputs",
    # Host-side subprocess controls (process_manager/manager.py): rlimits
    # caps RLIMIT_AS/CPU/etc. for native generators; env_passthrough lists
    # env vars that survive the per-subprocess scrub.
    "rlimits", "env_passthrough",
    # ``type`` is a list of 1–2 of {"modify", "create"} declaring every
    # invocation mode the generator supports. The user picks the mode at
    # invocation time; the host injects it as ``gen.invocation_type``.
    #   - ``modify`` rewrites the single current cell in place (was 'iterate').
    #   - ``create`` produces fresh cells; its input shape is read from
    #     ``inputs.cells`` (no input / single cell / stack). Folds in the old
    #     'spawn' (no input) and 'explore' (stack) modes.
    "type",
    # ``live_files_mode`` is native-only: opt-in for mid-run editing of
    # the cell's files. Consumed by api/routes/runs/queries.py and
    # frontend useGeneratorRun. wasm ignores it.
    "live_files_mode",
    # ``environment`` (native-only) declares this is an environment generator —
    # a daemon that owns a runtime and serves a parent (gen.serve_environment).
    # ``true`` for the core contract, or a mapping of declared extras. Implies
    # ``daemon: true``.
    "environment",
    # ``ephemeral`` (bool, default false) marks a generator whose output cell
    # is a throwaway live session — it never enters the DAG history, and the
    # cell offers "close" (stop + remove) instead of "stop". Browser/webview
    # generators set this.
    "ephemeral",
    # ``prompt_required`` gates running on a non-empty prompt; only
    # legal alongside ``prompt_intent``. ``config_tags`` is the ordered
    # mapping of named default-value sets (see _check_config_tags).
    "prompt_required", "config_tags",
    # Picker-visibility baseline (boolean, default true). ``available_ui:
    # false`` ships a generator hidden from the UI picker (a composition-only
    # toolset like the ``agent`` generator); an explicit per-channel toggle
    # overrides it. Callability by other generators is NOT a per-generator
    # flag — it's the source cell's "expose to generators" setting.
    "available_ui",
}
_GEN_TYPES = {"modify", "create"}
_GEN_ENV_KNOWN_KEYS = {
    "exec", "exec_background", "expose_port", "files",
    "terminals", "watch", "concurrent_exec",
}
_GEN_RLIMIT_KEYS = {"memory_bytes", "cpu_seconds", "open_files"}
_SECRET_NAME_RE = re.compile(r"KEY|TOKEN|SECRET|PASSWORD", re.IGNORECASE)
_TAG_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._-]{0,31}$")
_TAG_KNOWN_KEYS = {"prompt", "files"}

_REND_REQUIRED = ("id", "name", "entrypoint", "summary")
_REND_KNOWN = {
    "id", "name", "version", "summary", "entrypoint",
    "embed", "extensions", "supports_diff",
}
_REND_EMBED_MODES = {"native", "iframe"}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


@dataclass
class _Ctx:
    """Shared lint context.

    ``path`` is informational — for file-based linting it points at the
    manifest on disk; for in-memory linting (used by the
    generator-builders to validate the agent's stage before persisting)
    it's a synthetic Path like ``Path("(stage)/manifest.gen_yaml")``
    that just makes the Issue rendering readable.

    ``file_exists`` is the predicate the file-existence checks consult.
    For path-based linting it's ``lambda rel: (path.parent / rel).exists()``;
    for in-memory linting it's ``lambda rel: rel in stage_files``.

    ``read_file`` returns a sibling file's text, or None when it can't
    be read. Checks that inspect file *contents* (config-tag field
    validation, required-on-checkbox) skip silently when it's None or
    the read fails — content checks are best-effort.
    """
    path: Path
    file_exists: Callable[[str], bool]
    read_file: Callable[[str], str | None] | None = None
    issues: list[Issue] = field(default_factory=list)

    def error(self, code: str, message: str, field: str | None = None) -> None:
        self.issues.append(Issue(Level.ERROR, code, message, self.path, field))

    def warn(self, code: str, message: str, field: str | None = None) -> None:
        self.issues.append(Issue(Level.WARNING, code, message, self.path, field))


def _load_yaml(path: Path, ctx: _Ctx) -> dict[str, Any] | None:
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as e:
        ctx.error("io-error", f"cannot read: {e}")
        return None
    try:
        data = yaml.safe_load(raw)
    except yaml.YAMLError as e:
        ctx.error("yaml-parse", f"invalid YAML: {e}")
        return None
    if data is None:
        ctx.error("empty", "manifest file is empty")
        return None
    if not isinstance(data, dict):
        ctx.error("bad-root", f"manifest root must be a mapping, got {type(data).__name__}")
        return None
    return data


def _check_required(data: dict[str, Any], keys: tuple[str, ...], ctx: _Ctx) -> None:
    for key in keys:
        if key not in data:
            ctx.error("missing-required", f"required field '{key}' is missing", field=key)
        elif not isinstance(data[key], str) or not data[key].strip():
            ctx.error("bad-type", f"'{key}' must be a non-empty string", field=key)


def _check_string(data: dict[str, Any], key: str, ctx: _Ctx, *, required: bool = False) -> None:
    v = data.get(key)
    if v is None:
        if required:
            ctx.error("missing-required", f"required field '{key}' is missing", field=key)
        return
    if not isinstance(v, str):
        ctx.error("bad-type", f"'{key}' must be a string", field=key)


def _check_bool(data: dict[str, Any], key: str, ctx: _Ctx) -> None:
    if key in data and not isinstance(data[key], bool):
        ctx.error("bad-type", f"'{key}' must be a bool", field=key)


def _check_enum(data: dict[str, Any], key: str, choices: set[str], ctx: _Ctx) -> None:
    if key not in data:
        return
    v = data[key]
    if not isinstance(v, str):
        ctx.error("bad-type", f"'{key}' must be a string", field=key)
        return
    if v not in choices:
        ctx.error(
            "bad-enum",
            f"'{key}' must be one of {sorted(choices)}, got {v!r}",
            field=key,
        )


def _check_unknown(data: dict[str, Any], known: set[str], ctx: _Ctx) -> None:
    for k in data:
        if k not in known:
            ctx.warn("unknown-field", f"unknown field '{k}' — will be ignored", field=k)


def _check_file_exists(
    data: dict[str, Any], key: str, ctx: _Ctx, *, optional: bool = False
) -> None:
    v = data.get(key)
    if v is None:
        if not optional:
            ctx.error("missing-required", f"required field '{key}' is missing", field=key)
        return
    if not isinstance(v, str):
        ctx.error("bad-type", f"'{key}' must be a string filename", field=key)
        return
    if not ctx.file_exists(v):
        ctx.error(
            "missing-file",
            f"'{key}' references {v!r} but no such file exists",
            field=key,
        )


def _check_file_list(data: dict[str, Any], key: str, ctx: _Ctx) -> None:
    v = data.get(key)
    if v is None:
        return
    if not isinstance(v, list):
        ctx.error("bad-type", f"'{key}' must be a list of filenames", field=key)
        return
    for i, item in enumerate(v):
        if not isinstance(item, str):
            ctx.error(
                "bad-type",
                f"'{key}[{i}]' must be a string filename, got {type(item).__name__}",
                field=key,
            )
            continue
        if not ctx.file_exists(item):
            ctx.warn(
                "missing-file",
                f"'{key}' references {item!r} but no such file exists",
                field=key,
            )


def _type_set(data: dict[str, Any]) -> set[str]:
    """Return the set of valid type-array entries from ``data``.

    Tolerant — returns whatever subset of ``_GEN_TYPES`` the field
    contains, ignoring shape errors. Used by ``_check_inputs`` so it can
    consult the type without re-doing all the validation in
    ``_check_type_array``.
    """
    raw = data.get("type")
    if not isinstance(raw, list):
        return set()
    return {v for v in raw if isinstance(v, str) and v in _GEN_TYPES}


def _check_type_array(data: dict[str, Any], ctx: _Ctx) -> None:
    """Validate the ``type`` field.

    Shape: a list of 1–2 entries, each drawn from ``_GEN_TYPES``, with no
    duplicates. The list declares every mode the generator supports;
    the host picks one at invocation time and passes it as
    ``gen.invocation_type``.
    """
    if "type" not in data:
        ctx.error(
            "missing-required",
            "required field 'type' is missing — declare a list like ['modify'], "
            "['create'], or both (1–2 entries)",
            field="type",
        )
        return
    v = data["type"]
    if not isinstance(v, list):
        ctx.error(
            "bad-type",
            f"'type' must be a list of {sorted(_GEN_TYPES)} (1–2 entries), got {type(v).__name__}",
            field="type",
        )
        return
    if len(v) < 1 or len(v) > 2:
        ctx.error(
            "bad-range",
            f"'type' must have 1–2 entries, got {len(v)}",
            field="type",
        )
        return
    seen: set[str] = set()
    for i, entry in enumerate(v):
        if not isinstance(entry, str):
            ctx.error(
                "bad-type",
                f"'type[{i}]' must be a string, got {type(entry).__name__}",
                field="type",
            )
            continue
        if entry not in _GEN_TYPES:
            ctx.error(
                "bad-enum",
                f"'type[{i}]' must be one of {sorted(_GEN_TYPES)}, got {entry!r}",
                field="type",
            )
            continue
        if entry in seen:
            ctx.error(
                "bad-range",
                f"'type[{i}]' duplicates {entry!r} — list entries must be unique",
                field="type",
            )
        seen.add(entry)


_SENTENCE_END_RE = re.compile(r"[.!?]+\s+\S")


def _check_summary_length(data: dict[str, Any], ctx: _Ctx) -> None:
    """Warn (don't error) when ``summary`` is more than 2 sentences.

    Heuristic: count ``[.!?]+`` followed by whitespace + a non-whitespace
    glyph. A trailing period doesn't count (no following non-whitespace).
    Two such transitions ⇒ three sentences ⇒ too long.
    """
    summary = data.get("summary")
    if not isinstance(summary, str):
        return
    transitions = len(_SENTENCE_END_RE.findall(summary))
    if transitions >= 2:
        ctx.warn(
            "summary-too-long",
            "'summary' should be 1–2 sentences — keep it tight enough to read at a glance",
            field="summary",
        )


def _check_inputs(data: dict[str, Any], ctx: _Ctx) -> None:
    """Validate ``inputs.cells`` against the declared ``type`` array.

    ``inputs.cells`` is optional — when absent, each declared mode contributes
    its implicit bounds (modify → 1/1, create → 0/99) and the runtime takes
    the union. When the author DOES declare bounds explicitly, they apply to
    every mode in ``type`` and must satisfy each mode's per-mode rule:

        - 'modify'  : rewrites the single current cell → ``min <= 1 <= max``
        - 'create'  : produces fresh cells; the declared bounds pick its input
                      shape — no input (0/0), single cell (1/1), or a stack
                      (``min`` may be 0 for an optional stack). Only requires
                      ``min >= 0`` and ``max >= min`` (checked above).

    A multi-type generator must satisfy every applicable rule (e.g. a
    ``['modify', 'create']`` gen with bounds ``2/5`` fails the modify rule
    because 1 isn't in [2,5]). The lint surfaces every mismatch individually
    so the author sees which mode is conflicting.
    """
    inputs = data.get("inputs")
    types = _type_set(data)

    if inputs is None:
        return
    if not isinstance(inputs, dict):
        ctx.error("bad-type", "'inputs' must be a mapping", field="inputs")
        return
    cells = inputs.get("cells")
    if cells is None:
        return
    if not isinstance(cells, dict):
        ctx.error("bad-type", "'inputs.cells' must be a mapping", field="inputs.cells")
        return
    lo = cells.get("min")
    hi = cells.get("max")
    for name, val in (("min", lo), ("max", hi)):
        if val is not None and not isinstance(val, int):
            ctx.error(
                "bad-type",
                f"'inputs.cells.{name}' must be an integer",
                field=f"inputs.cells.{name}",
            )
    if isinstance(lo, int) and isinstance(hi, int) and lo > hi:
        ctx.error(
            "bad-range",
            f"'inputs.cells.min' ({lo}) > 'inputs.cells.max' ({hi})",
            field="inputs.cells",
        )

    # Per-mode bound validation. Each rule fires only when the type array
    # includes that mode AND the relevant bound is explicitly declared
    # (well-typed integer). Unset bounds use the implicit defaults
    # described in the docstring.
    if "modify" in types:
        if isinstance(lo, int) and lo > 1:
            ctx.error(
                "bad-inputs-for-type",
                f"type contains 'modify' so 'inputs.cells.min' must be ≤ 1 — "
                f"modify rewrites the single current cell (got min={lo})",
                field="inputs.cells.min",
            )
        if isinstance(hi, int) and hi < 1:
            ctx.error(
                "bad-inputs-for-type",
                f"type contains 'modify' so 'inputs.cells.max' must be ≥ 1 — "
                f"modify rewrites the single current cell (got max={hi})",
                field="inputs.cells.max",
            )

    if "create" in types and isinstance(lo, int) and lo < 0:
        ctx.error(
            "bad-inputs-for-type",
            f"type contains 'create' so 'inputs.cells.min' must be ≥ 0 (got {lo})",
            field="inputs.cells.min",
        )


def _check_extensions(data: dict[str, Any], ctx: _Ctx) -> None:
    v = data.get("extensions")
    if v is None:
        return
    if not isinstance(v, list):
        ctx.error("bad-type", "'extensions' must be a list", field="extensions")
        return
    for i, ext in enumerate(v):
        if not isinstance(ext, str):
            ctx.error(
                "bad-type",
                f"'extensions[{i}]' must be a string, got {type(ext).__name__}",
                field="extensions",
            )
            continue
        if not ext.startswith("."):
            ctx.error(
                "ext-no-dot",
                f"extension {ext!r} must start with a dot (e.g. '.md')",
                field="extensions",
            )


def _check_rlimits(data: dict[str, Any], ctx: _Ctx) -> None:
    """Validate the optional ``rlimits`` block.

    Shape: a mapping with any subset of ``{memory_bytes, cpu_seconds,
    open_files}`` as keys, each mapped to a positive integer. The host's
    subprocess setup (process_manager/manager.py:_build_preexec_fn) reads
    exactly these three keys; anything else is silently ignored, so call
    it out at lint time.
    """
    v = data.get("rlimits")
    if v is None:
        return
    if not isinstance(v, dict):
        ctx.error("bad-type", "'rlimits' must be a mapping", field="rlimits")
        return
    for key, val in v.items():
        if key not in _GEN_RLIMIT_KEYS:
            ctx.error(
                "bad-enum",
                f"'rlimits.{key}' is unknown — must be one of {sorted(_GEN_RLIMIT_KEYS)}",
                field=f"rlimits.{key}",
            )
            continue
        if not isinstance(val, int) or isinstance(val, bool) or val <= 0:
            ctx.error(
                "bad-type",
                f"'rlimits.{key}' must be a positive integer, got {val!r}",
                field=f"rlimits.{key}",
            )


def _check_environment(data: dict[str, Any], ctx: _Ctx) -> None:
    """Validate the optional ``environment`` declaration.

    Shape: ``true`` (core contract) or a mapping of declared extras drawn from
    ``{exec, exec_background, expose_port, files, terminals, watch,
    concurrent_exec}``. ``terminals`` must be a non-negative int; ``files`` one
    of ``read-write``/``none``; the rest booleans. An environment is a daemon
    that serves its parent, so it implies ``daemon: true`` — a manifest that
    sets ``daemon: false`` alongside ``environment`` is contradictory.
    """
    if "environment" not in data:
        return
    v = data.get("environment")
    if isinstance(v, bool):
        pass
    elif isinstance(v, dict):
        for key, val in v.items():
            if key not in _GEN_ENV_KNOWN_KEYS:
                ctx.error(
                    "bad-enum",
                    f"'environment.{key}' is unknown — must be one of {sorted(_GEN_ENV_KNOWN_KEYS)}",
                    field=f"environment.{key}",
                )
                continue
            if key == "terminals":
                if not isinstance(val, int) or isinstance(val, bool) or val < 0:
                    ctx.error("bad-type",
                              f"'environment.terminals' must be a non-negative integer, got {val!r}",
                              field="environment.terminals")
            elif key == "files":
                if val not in ("read-write", "none"):
                    ctx.error("bad-enum",
                              "'environment.files' must be 'read-write' or 'none'",
                              field="environment.files")
            elif not isinstance(val, bool):
                ctx.error("bad-type",
                          f"'environment.{key}' must be a boolean, got {val!r}",
                          field=f"environment.{key}")
    else:
        ctx.error("bad-type",
                  "'environment' must be true or a mapping of declared extras",
                  field="environment")
        return
    # environment implies daemon — a false daemon flag contradicts it.
    # `environment: {}` (an empty mapping) is falsy but still declares a core
    # environment, so guard on `is not False`, not truthiness.
    if v is not False and data.get("daemon") is False:
        ctx.error("contradiction",
                  "'environment' implies a daemon, but 'daemon: false' is set",
                  field="daemon")


def _check_env_passthrough(data: dict[str, Any], ctx: _Ctx) -> None:
    """Validate the optional ``env_passthrough`` list.

    Shape: a list of non-empty strings naming env vars that survive the
    per-subprocess scrub in process_manager/manager.py. Warn (don't
    error) when a name looks like a secret — secrets belong in the
    keystore, not in inherited env vars.
    """
    v = data.get("env_passthrough")
    if v is None:
        return
    if not isinstance(v, list):
        ctx.error("bad-type", "'env_passthrough' must be a list of env var names", field="env_passthrough")
        return
    for i, name in enumerate(v):
        if not isinstance(name, str) or not name.strip():
            ctx.error(
                "bad-type",
                f"'env_passthrough[{i}]' must be a non-empty string, got {name!r}",
                field="env_passthrough",
            )
            continue
        if _SECRET_NAME_RE.search(name):
            ctx.warn(
                "env-passthrough-looks-secret",
                f"'env_passthrough' entry {name!r} looks like a secret — prefer the keystore (gen.secret/gen.api_key)",
                field="env_passthrough",
            )


def _has_prompt_intent(data: dict[str, Any]) -> bool:
    v = data.get("prompt_intent")
    return isinstance(v, str) and bool(v.strip())


def _set_yaml_draft_files(data: dict[str, Any]) -> list[str]:
    raw = data.get("draft_files")
    if not isinstance(raw, list):
        return []
    return [f for f in raw if isinstance(f, str) and f.endswith(".set_yaml")]


def _read_set_yaml_fields(rel: str, ctx: _Ctx) -> list[dict[str, Any]] | None:
    """Parse ``rel`` via ``ctx.read_file`` and return its ``fields:`` list.

    Returns None when the file can't be read or parsed (or no
    ``read_file`` callback was wired) — content-level checks skip
    silently in that case.
    """
    if ctx.read_file is None:
        return None
    raw = ctx.read_file(rel)
    if raw is None:
        return None
    try:
        parsed = yaml.safe_load(raw)
    except yaml.YAMLError:
        return None
    if not isinstance(parsed, dict):
        return None
    fields = parsed.get("fields")
    if not isinstance(fields, list):
        return None
    return [f for f in fields if isinstance(f, dict)]


def _check_prompt_required(data: dict[str, Any], ctx: _Ctx) -> None:
    _check_bool(data, "prompt_required", ctx)
    if data.get("prompt_required") is True and not _has_prompt_intent(data):
        ctx.error(
            "prompt-required-without-intent",
            "'prompt_required: true' needs a 'prompt_intent' — without one "
            "the picker never shows a prompt box, so the run could never start",
            field="prompt_required",
        )


def _check_config_tags(data: dict[str, Any], ctx: _Ctx) -> None:
    """Validate the optional ``config_tags`` block.

    Shape: an ordered mapping of tag name → tag body, where each body
    allows only ``prompt`` (string seeded into the prompt box) and
    ``files`` (mapping of ``.set_yaml`` draft-file path → sparse field
    overlay). A generator "takes tags" when it has a ``prompt_intent``
    or at least one ``.set_yaml`` in ``draft_files``; such generators
    must declare ``config_tags`` with a ``default`` tag (``{}`` = pure
    field defaults).
    """
    set_yamls = _set_yaml_draft_files(data)
    takes_tags = _has_prompt_intent(data) or bool(set_yamls)
    set_yaml_fields = {rel: _read_set_yaml_fields(rel, ctx) for rel in set_yamls}

    # required: true is meaningless on a field type whose empty-base
    # value is itself non-empty (only checkbox today — it always holds
    # true/false), so the field can never be "empty" and never gates a
    # run. Derived from the shared rule in collimate.config_values.
    for rel, fields in set_yaml_fields.items():
        for f in fields or []:
            ftype = f.get("type")
            if f.get("required") is True and not is_empty(
                    type_empty_default(ftype), ftype):
                ctx.warn(
                    "required-on-checkbox",
                    f"{rel}: field {f.get('key')!r} is a checkbox with "
                    "'required: true' — a checkbox is never empty, so the "
                    "flag does nothing",
                    field=f"{rel}:{f.get('key')}",
                )

    tags = data.get("config_tags")
    if tags is None:
        if takes_tags:
            ctx.error(
                "missing-config-tags",
                "generator takes config (prompt_intent and/or a .set_yaml "
                "draft file) so 'config_tags' with a 'default' tag is "
                "required — 'config_tags: {default: {}}' means pure field "
                "defaults",
                field="config_tags",
            )
        return
    if not isinstance(tags, dict):
        ctx.error(
            "bad-type",
            "'config_tags' must be a mapping of tag name → tag body",
            field="config_tags",
        )
        return
    if not takes_tags:
        ctx.warn(
            "config-tags-unused",
            "'config_tags' declared but the generator has no prompt_intent "
            "and no .set_yaml draft files — the tags have nothing to configure",
            field="config_tags",
        )
    if "default" not in tags:
        ctx.error(
            "config-tags-missing-default",
            "'config_tags' must contain a 'default' tag ({} = pure field defaults)",
            field="config_tags",
        )

    for name, body in tags.items():
        if not isinstance(name, str) or not _TAG_NAME_RE.match(name):
            ctx.error(
                "bad-tag-name",
                f"config tag name {name!r} is invalid — must match "
                f"{_TAG_NAME_RE.pattern} (1–32 chars; letters, digits, "
                "spaces, dots, underscores, hyphens; can't start with a "
                "space or punctuation)",
                field="config_tags",
            )
            continue
        if body is None:
            continue  # bare `default:` ≡ {}
        if not isinstance(body, dict):
            ctx.error(
                "bad-type",
                f"'config_tags.{name}' must be a mapping (or {{}})",
                field=f"config_tags.{name}",
            )
            continue
        for k in body:
            if k not in _TAG_KNOWN_KEYS:
                ctx.error(
                    "tag-unknown-key",
                    f"'config_tags.{name}.{k}' is unknown — only 'prompt' "
                    "and 'files' are allowed in a tag body",
                    field=f"config_tags.{name}.{k}",
                )
        if "prompt" in body:
            if not isinstance(body["prompt"], str):
                ctx.error(
                    "bad-type",
                    f"'config_tags.{name}.prompt' must be a string",
                    field=f"config_tags.{name}.prompt",
                )
            elif not _has_prompt_intent(data):
                ctx.warn(
                    "tag-prompt-without-intent",
                    f"'config_tags.{name}.prompt' is set but the manifest "
                    "has no prompt_intent — the seeded prompt is never shown",
                    field=f"config_tags.{name}.prompt",
                )
        if "files" not in body:
            continue
        files = body["files"]
        if not isinstance(files, dict):
            ctx.error(
                "bad-type",
                f"'config_tags.{name}.files' must be a mapping of "
                ".set_yaml draft-file path → field overlay",
                field=f"config_tags.{name}.files",
            )
            continue
        for rel, overlay in files.items():
            if not isinstance(rel, str) or rel not in set_yamls:
                ctx.error(
                    "tag-unknown-file",
                    f"'config_tags.{name}.files' references {rel!r} which "
                    "is not a .set_yaml member of draft_files",
                    field=f"config_tags.{name}.files",
                )
                continue
            if not isinstance(overlay, dict):
                ctx.error(
                    "bad-type",
                    f"'config_tags.{name}.files.{rel}' must be a mapping "
                    "of field key → value",
                    field=f"config_tags.{name}.files.{rel}",
                )
                continue
            fields = set_yaml_fields.get(rel)
            if fields is None:
                continue  # file contents unavailable — skip silently
            known = {f["key"] for f in fields if isinstance(f.get("key"), str)}
            for fkey in overlay:
                if fkey not in known:
                    ctx.error(
                        "tag-unknown-field",
                        f"'config_tags.{name}.files.{rel}' sets {fkey!r} "
                        f"but {rel} declares no such field",
                        field=f"config_tags.{name}.files.{rel}",
                    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


# Shared ``_*`` sibling cells the platform materialises next to every
# generator/renderer at build/seed time. A source cell must NOT ship its own
# copy — a hand-rolled one collides with (or shadows) the real cell and
# usually carries incomplete logic. Builder agents commonly fabricate
# ``_agent_shared.py`` because the docs say ``from _agent_shared import …``;
# this rule catches it before install.
_RESERVED_SHARED_CELLS = ("_agent_shared", "_env_shared", "_cdp_shared")


def _check_no_reserved_shared_cells(ctx: _Ctx) -> None:
    for name in _RESERVED_SHARED_CELLS:
        for rel in (f"{name}.py", f"{name}/__init__.py"):
            if ctx.file_exists(rel):
                ctx.error(
                    "reserved-shared-cell",
                    f"ships {rel!r}, but {name!r} is a shared sibling cell the "
                    f"platform provides at runtime — remove it and just "
                    f"`from {name} import …` (a hand-rolled copy collides with "
                    f"the real cell).",
                )
                break


def _lint_generator_body(data: dict[str, Any], ctx: _Ctx) -> None:
    """Run the generator-manifest checks against an already-loaded dict."""
    _check_required(data, _GEN_REQUIRED, ctx)
    _check_string(data, "version", ctx)
    _check_summary_length(data, ctx)
    _check_string(data, "prompt_intent", ctx)

    _check_bool(data, "chat", ctx)
    _check_bool(data, "daemon", ctx)
    _check_bool(data, "ephemeral", ctx)
    _check_bool(data, "available_ui", ctx)
    _check_type_array(data, ctx)

    _check_file_exists(data, "entrypoint", ctx, optional=False)
    _check_file_list(data, "draft_files", ctx)

    _check_prompt_required(data, ctx)
    _check_config_tags(data, ctx)
    _check_inputs(data, ctx)
    _check_rlimits(data, ctx)
    _check_environment(data, ctx)
    _check_env_passthrough(data, ctx)
    _check_no_reserved_shared_cells(ctx)
    _check_unknown(data, _GEN_KNOWN, ctx)


def _lint_renderer_body(data: dict[str, Any], ctx: _Ctx) -> None:
    """Run the renderer-manifest checks against an already-loaded dict."""
    _check_required(data, _REND_REQUIRED, ctx)
    _check_string(data, "version", ctx)
    _check_summary_length(data, ctx)

    _check_enum(data, "embed", _REND_EMBED_MODES, ctx)
    _check_bool(data, "supports_diff", ctx)

    _check_file_exists(data, "entrypoint", ctx, optional=False)
    _check_extensions(data, ctx)

    _check_no_reserved_shared_cells(ctx)
    _check_unknown(data, _REND_KNOWN, ctx)


def lint_generator_manifest(path: str | os.PathLike[str]) -> list[Issue]:
    """Lint a single ``manifest.gen_yaml`` file on disk."""
    p = Path(path)

    def _read_rel(rel: str) -> str | None:
        try:
            return (p.parent / rel).read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            return None

    ctx = _Ctx(
        path=p,
        file_exists=lambda rel: (p.parent / rel).exists(),
        read_file=_read_rel,
    )
    data = _load_yaml(p, ctx)
    if data is None:
        return ctx.issues
    _lint_generator_body(data, ctx)
    return ctx.issues


def lint_renderer_manifest(path: str | os.PathLike[str]) -> list[Issue]:
    """Lint a single ``manifest.rend_yaml`` file on disk."""
    p = Path(path)
    ctx = _Ctx(path=p, file_exists=lambda rel: (p.parent / rel).exists())
    data = _load_yaml(p, ctx)
    if data is None:
        return ctx.issues
    _lint_renderer_body(data, ctx)
    return ctx.issues


def lint_generator_manifest_data(
    data: dict[str, Any],
    *,
    files_present: set[str],
    pseudo_path: str = "(stage)/manifest.gen_yaml",
    file_contents: dict[str, str] | None = None,
) -> list[Issue]:
    """Lint a generator manifest already parsed into a dict.

    Used by the generator-builders to validate the agent's staged
    manifest before persisting — no filesystem write needed.

    ``files_present`` is the set of relative paths the agent has staged
    so far (e.g. ``set(stage.keys())`` for the native builder or
    ``set(gen.list_files())`` for the demo/wasm one). ``entrypoint`` and
    ``draft_files`` are checked against this set instead of disk.

    ``file_contents`` optionally maps staged paths to their text so
    content-level checks (config-tag field validation,
    required-on-checkbox) can run; files absent from the mapping — or
    the mapping itself when omitted — are skipped silently.
    """
    ctx = _Ctx(
        path=Path(pseudo_path),
        file_exists=lambda rel: rel in files_present,
        read_file=(
            None if file_contents is None
            else lambda rel: file_contents.get(rel)
        ),
    )
    if not isinstance(data, dict):
        ctx.error(
            "bad-root",
            f"manifest must be a mapping, got {type(data).__name__}",
        )
        return ctx.issues
    _lint_generator_body(data, ctx)
    return ctx.issues


def lint_renderer_manifest_data(
    data: dict[str, Any],
    *,
    files_present: set[str],
    pseudo_path: str = "(stage)/manifest.rend_yaml",
) -> list[Issue]:
    """Lint a renderer manifest already parsed into a dict.

    Used by the renderer-builders, mirror of
    :func:`lint_generator_manifest_data`.
    """
    ctx = _Ctx(path=Path(pseudo_path), file_exists=lambda rel: rel in files_present)
    if not isinstance(data, dict):
        ctx.error(
            "bad-root",
            f"manifest must be a mapping, got {type(data).__name__}",
        )
        return ctx.issues
    _lint_renderer_body(data, ctx)
    return ctx.issues


def _detect_kind(path: Path) -> str | None:
    """Return 'generator', 'renderer', or None based on filename suffix."""
    name = path.name
    if name == "manifest.gen_yaml" or name.endswith(".gen_yaml"):
        return "generator"
    if name == "manifest.rend_yaml" or name.endswith(".rend_yaml"):
        return "renderer"
    return None


def lint_path(path: str | os.PathLike[str]) -> list[Issue]:
    """Lint a manifest file, or walk a directory and lint every manifest it
    finds. Unknown filenames are skipped with no error.
    """
    p = Path(path)
    if p.is_file():
        kind = _detect_kind(p)
        if kind == "generator":
            return lint_generator_manifest(p)
        if kind == "renderer":
            return lint_renderer_manifest(p)
        return [Issue(
            Level.ERROR, "unknown-kind",
            "cannot auto-detect manifest type — pass manifest.gen_yaml or manifest.rend_yaml",
            path=p,
        )]
    if not p.is_dir():
        return [Issue(Level.ERROR, "not-found", f"path does not exist: {p}", path=p)]

    issues: list[Issue] = []
    for sub in sorted(p.rglob("manifest.*_yaml")):
        kind = _detect_kind(sub)
        if kind == "generator":
            issues.extend(lint_generator_manifest(sub))
        elif kind == "renderer":
            issues.extend(lint_renderer_manifest(sub))
    return issues
