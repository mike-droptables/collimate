# SPDX-License-Identifier: Apache-2.0
"""Provider-agnostic helpers for LLM-driven generators.

This module is deliberately thin. API key resolution, model
construction, and chat-history translation now live behind
:mod:`gen` (``await gen.api_key(provider)``, ``await gen.agent(...)``,
``gen.history.as_pai()``) — generators import those, not these helpers.

What stays here:

  * :func:`looks_like_auth_error` — heuristic used by every chat-style
    generator to decide whether to re-prompt for an API key with
    ``force=True`` after a 401. Walks the exception cause chain.
  * :data:`PROVIDER_KEY_ENV` — canonical env-var name per provider.
    Consumed by the host's static key scanner so the
    Settings → Keys "in use" list can pre-populate provider env vars.
"""
from __future__ import annotations


# Canonical env-var (and keystore key) name per provider. Mirrored in
# :mod:`collimate.native`'s singleton; this re-export exists so the
# host's static key scanner (api/key_scan.py) has a single name to
# import.
PROVIDER_KEY_ENV: dict[str, str] = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
    "groq": "GROQ_API_KEY",
    "cerebras": "CEREBRAS_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
    "gemini": "GEMINI_API_KEY",
    "mistral": "MISTRAL_API_KEY",
}


# ---------------------------------------------------------------------------
# Auth-error detection
# ---------------------------------------------------------------------------

_AUTH_NEEDLES: tuple[str, ...] = (
    "unauthor",         # "Unauthorized", "unauthorized request"
    "invalid api key",  # OpenAI / Groq / Cerebras
    "invalid x-api-key",
    "authentication",   # "Authentication failed"
    "not authenticated",
    "auth credential",  # Google API uses "auth credentials"
    "api key not valid",
    "incorrect api key",
)


def _exc_chain(exc: BaseException) -> "list[BaseException]":
    """Yield ``exc`` plus everything reachable through ``__cause__`` /
    ``__context__``. pydantic-ai routinely wraps provider errors, so
    the auth marker often sits one or two links deep."""
    out: list[BaseException] = []
    seen: set[int] = set()
    cur: BaseException | None = exc
    while cur is not None and id(cur) not in seen:
        seen.add(id(cur))
        out.append(cur)
        cur = cur.__cause__ or cur.__context__
    return out


def looks_like_auth_error(exc: BaseException) -> bool:
    """Heuristic: does this exception look like an LLM provider auth
    failure?

    Used by chat generators to decide whether to call
    ``await gen.api_key(provider, force=True)`` and retry one turn.
    Three signals, any one is enough:

      1. Exception class name contains ``Authentication``,
         ``PermissionDenied``, or ``Unauthorized`` — catches typed
         exceptions like ``openai.AuthenticationError`` and
         ``anthropic.PermissionDeniedError`` without importing every
         provider SDK at module load time.
      2. ``str(exc)`` (or any ``__cause__`` / ``__context__`` link)
         contains ``"401"`` / ``"403"``.
      3. Same chain matches a known auth phrase.

    Walking the cause chain matters: pydantic-ai wraps provider errors
    so the real ``AuthenticationError`` may be one or two links deep.
    """
    chain = _exc_chain(exc)
    for cur in chain:
        cls = type(cur).__name__.lower()
        if "authentication" in cls or "permissiondenied" in cls or cls == "unauthorized":
            return True
        if "auth" in cls and "error" in cls:
            return True
    for cur in chain:
        msg = (str(cur) or "").lower()
        if "401" in msg or "403" in msg:
            return True
        for needle in _AUTH_NEEDLES:
            if needle in msg:
                return True
    return False


__all__ = [
    "PROVIDER_KEY_ENV",
    "looks_like_auth_error",
]
