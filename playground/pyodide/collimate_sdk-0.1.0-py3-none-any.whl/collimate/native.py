# SPDX-License-Identifier: Apache-2.0
"""Singleton runtime API for native generators.

A generator script imports the top-level :mod:`gen` package — a thin
runtime-aware shim that re-exports from this module under native and
from :mod:`collimate.wasm` under pyodide. The shape is the same on both
runtimes for **Tier A** symbols; **Tier B** symbols (terminals, ports,
subprocess streaming, raw filesystem access, snapshot, settings modal,
action polling, container-backed chat sessions, IPC error types) are
native-only.

Entrypoint contract::

    import gen

    async def run():
        gen.update_file("output.md", "...")
        await gen.update(summary="hello")

    if __name__ == "__main__":
        gen.main(run)

``gen.main`` constructs a single :class:`collimate._host.HostBridge`
(IPC + signal handling + filesystem + state tracking), hydrates the
singleton, dispatches ``run_fn`` (sync or async), and emits the finish
IPC on the way out.

Two tiers:

  * **Tier A** (portable; mirrors :mod:`collimate.wasm` 1:1): inputs,
    file I/O, cells, user input, secrets, status, agent / file_tools.
    A generator using only Tier A is runtime-portable (the demo/WASM
    runtime exposes the same surface).
  * **Tier B** (native-only): real filesystem path, subprocess
    streaming, port binding, terminals, settings modal, action polling,
    snapshot diffing, container-backed chat sessions, IPC error types.
    These are the canonical native capabilities; the demo/WASM runtime
    omits them. (Runtime is folder-based — there is no ``runtime:``
    manifest field.)

Cell operations are deliberately limited to two:

  * :func:`update` flushes any staged file writes (and dirty chat
    history) to the placeholder/top cell. May be called many times
    during a run; the last call before return is the final state.
  * :func:`create_stack_cell` adds a new cell below in the right-side
    stack. Used by fan-out generators.

Plus one narrow handoff: :func:`start_modify_run` (Tier B) fires an
independent ``modify`` run of another generator on a cell this run just
created via :func:`create_stack_cell`. One shot per cell,
fire-and-forget — no handle, no monitoring, no further access to the
handed-off cell.

Calling ``update_file`` without ever calling ``update`` produces an
empty placeholder — explicit by design.
"""
from __future__ import annotations

from contextlib import asynccontextmanager
from typing import Any, AsyncIterator, Callable, Iterator, Optional
import asyncio
import json
import os

from collimate._host import (
    HostBridge,
    IPCDisconnectedError as _IPCDisconnectedError,
    IPCError as _IPCError,
    IPCNakError as _IPCNakError,
    IPCTimeoutError as _IPCTimeoutError,
    Message,
    _StopRequested,
)

# The single result/spec abstraction shared by the host-free testing
# harness and the composition API. Re-exported here so generators can
# refer to them as ``gen.GeneratorResult`` etc. (same object identity as
# ``collimate.testing``'s re-exports).
from collimate._results import (  # noqa: F401
    CellRecord,
    ConfigField,
    ConfigTag,
    DraftFileSchema,
    Endpoint,
    EnvironmentSpec,
    GeneratorInfo,
    GeneratorResult,
    RendererCheck,
    Request,
    _decode_files,
    _encode_files,
    _endpoint_from_dict,
    _env_spec_from_dict,
    _info_from_dict,
    _result_from_ack,
)


# ──────────────────────────────────────────────────────────────────────
# Module-level singleton state.
#
# ``_set_bridge()`` (called by :func:`main`) stores the live
# :class:`HostBridge`. Generators read/write through the public
# ``gen.*`` functions; they never touch ``_bridge`` directly.
# ──────────────────────────────────────────────────────────────────────

_bridge: Optional[HostBridge] = None


# ──────────────────────────────────────────────────────────────────────
# Public exception types (Tier A / Tier B)
# ──────────────────────────────────────────────────────────────────────


# Re-exported from collimate.host_protocol so native + wasm share the
# same Cancelled class identity. A Tier-A-only generator that runs on
# both runtimes catches the same exception type either way.
from collimate.host_protocol import Cancelled  # noqa: F401,E402


# Tier B re-exports (raise under WASM via the shim in `gen/__init__.py`).
IPCError = _IPCError
IPCNakError = _IPCNakError
IPCTimeoutError = _IPCTimeoutError
IPCDisconnectedError = _IPCDisconnectedError


# ──────────────────────────────────────────────────────────────────────
# Runner / lifecycle hooks
# ──────────────────────────────────────────────────────────────────────


def _set_bridge(bridge: HostBridge) -> None:
    """Hydrate the singleton with a live :class:`HostBridge`."""
    global _bridge
    _bridge = bridge


def _clear_bridge() -> None:
    global _bridge
    _bridge = None


def _require_bridge() -> HostBridge:
    if _bridge is None:
        raise RuntimeError(
            "gen.* used outside a generator run "
            "(call gen.main(run) at the entrypoint)"
        )
    return _bridge


# ──────────────────────────────────────────────────────────────────────
# Module-level dynamic attributes
#
# ``gen.prompt`` / ``gen.messages`` / ``gen.cancelled`` resolve against
# the current run's bridge. PEP 562 ``__getattr__`` at module level.
# ──────────────────────────────────────────────────────────────────────


def __getattr__(name: str) -> Any:
    if name == "prompt":
        return _require_bridge().prompt
    if name == "messages":
        return list(history)
    if name == "cancelled":
        return _require_bridge().cancelled
    if name == "invocation_type":
        return _require_bridge().invocation_type
    raise AttributeError(f"module 'collimate.native' has no attribute {name!r}")


# ──────────────────────────────────────────────────────────────────────
# Tier A — Inputs
# ──────────────────────────────────────────────────────────────────────


def read_input(path: str) -> "str | bytes":
    """Read a file from the input/parent cell workspace.

    Returns ``str`` when the bytes decode as utf-8, otherwise ``bytes``.
    Symmetric with the WASM runtime; previously native was text-only.
    """
    return _require_bridge().fs_read_any(path)


def input_files() -> dict[str, "str | bytes"]:
    """Return every input-cell file as ``{relpath: content}``.

    Each value is ``str`` when utf-8 decodable, else ``bytes``. Files
    that fail to open are silently skipped.
    """
    bridge = _require_bridge()
    out: dict[str, "str | bytes"] = {}
    for p in bridge.fs_list():
        try:
            out[p] = bridge.fs_read_any(p)
        except OSError:
            continue
    return out


def input_groups() -> dict[str, dict[str, "str | bytes"]]:
    """Return input files grouped by source cell.

    For multi-cell input (workspace hydrated as ``inputs/NN_slug/...``),
    each top-level subfolder under ``inputs/`` becomes one group; paths
    in each group are **relative to the cell root** so callers can
    re-emit them verbatim.

    For single-cell input (files at workspace root), returns one group
    keyed ``"input"`` with the original paths. Each value is ``str`` for
    utf-8 decodable files, else ``bytes``.
    """
    bridge = _require_bridge()
    all_paths = bridge.fs_list()
    inputs_prefix = "inputs/"
    under_inputs = [p for p in all_paths if p.startswith(inputs_prefix)]
    if not under_inputs:
        if not all_paths:
            return {}
        single: dict[str, "str | bytes"] = {}
        for p in all_paths:
            try:
                single[p] = bridge.fs_read_any(p)
            except OSError:
                continue
        return {"input": single}

    raw: dict[str, dict[str, "str | bytes"]] = {}
    for p in under_inputs:
        rest = p[len(inputs_prefix):]
        label, _, sub = rest.partition("/")
        if not sub:
            continue
        try:
            content = bridge.fs_read_any(p)
        except OSError:
            continue
        raw.setdefault(label, {})[sub] = content
    return {label: raw[label] for label in sorted(raw)}


def config(name: str) -> dict:
    """Read a draft file declared in the manifest's ``draft_files``.

    Always returns a dict. ``.set_yaml`` / ``.yaml`` / ``.yml`` parse
    as YAML (with ``fields:`` defaults merged into the ``values:``
    block). ``.json`` parses as JSON. Returns ``{}`` when the file is
    missing or malformed — callers can use ``cfg.get(...)`` without
    try/except.

    For raw text files, use :func:`read_file` instead.
    """
    raw = _require_bridge().config(name)
    return raw if isinstance(raw, dict) else {}


# ──────────────────────────────────────────────────────────────────────
# Tier A — Output stage (workspace filesystem)
# ──────────────────────────────────────────────────────────────────────


def update_file(path: str, content: "str | bytes") -> None:
    """Stage a write to the output cell's file at ``path``.

    Accepts either ``str`` (utf-8 text) or ``bytes`` (binary). Writes
    immediately to the workspace (so subprocesses see it) and marks the
    path for inclusion in the next :func:`update` flush. Multiple writes
    overwrite — last write wins.
    """
    _require_bridge().fs_write_any(path, content)


def read_file(path: str) -> "str | bytes":
    """Read from the output stage. Raises :class:`FileNotFoundError`
    when the path is missing. Returns ``str`` when utf-8 decodable,
    else ``bytes``."""
    bridge = _require_bridge()
    if not bridge.fs_exists(path):
        raise FileNotFoundError(path)
    return bridge.fs_read_any(path)


def has_file(path: str) -> bool:
    """Predicate over the output stage."""
    return _require_bridge().fs_exists(path)


def list_files() -> list[str]:
    """Sorted list of every staged file's relative path."""
    return sorted(_require_bridge().fs_list())


def delete_file(path: str) -> None:
    """Drop ``path`` from the output stage. The next :func:`update`
    call passes it as ``deleted_files`` so the host strips it from the
    cell's carried-forward file set."""
    _require_bridge().fs_unlink(path)


# ──────────────────────────────────────────────────────────────────────
# Tier A — Cell operations (two only)
# ──────────────────────────────────────────────────────────────────────


async def update(
    *,
    name: Optional[str] = None,
    summary: Optional[str] = None,
    pinned: Optional[str] = None,
) -> None:
    """Flush the current stage (tracked writes) to the placeholder/top cell.

    May be called many times during a run; each call refreshes the
    visible cell live. The last call before return is the final state.
    **If ``update`` is never called, the placeholder is empty.**
    """
    bridge = _require_bridge()
    deletions = sorted(bridge.tracked_deletions) if bridge.tracked_deletions else None
    bridge.tracked_deletions.clear()

    loop = asyncio.get_event_loop()
    await loop.run_in_executor(
        None,
        lambda: bridge.update_cell(
            name=name,
            summary=summary,
            pinned=pinned,
            deleted_files=deletions,
        ),
    )


async def create_stack_cell(
    name: str,
    *,
    summary: Optional[str] = None,
    pinned: Optional[str] = None,
    files: Optional[dict[str, str]] = None,
) -> str:
    """Add a new cell below in the (right-side) stack.

    If ``files`` is provided, each entry is written first, then the
    side-cell is created with those paths as artifacts. If ``files`` is
    omitted, snapshots whatever is currently tracked.

    Returns the new cell's id.

    Agent-tool twin (the same act as a live chat tool): ``create_cell``.
    """
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        None,
        lambda: bridge.create_side_cell(
            name=name,
            summary=summary,
            pinned=pinned,
            files=files,
        ),
    )


async def start_modify_run(
    cell_id: str,
    generator: str,
    *,
    prompt: Optional[str] = None,
) -> None:
    """Hand a cell this run created via :func:`create_stack_cell` to a
    ``modify`` generator (Tier B, native-only).

    One-shot, fire-and-forget::

        cell_id = await gen.create_stack_cell("Draft", files={"a.md": "..."})
        await gen.start_modify_run(cell_id, "polish", prompt="tighten the prose")

    The host starts an independent, top-level ``modify`` run of
    ``generator`` against the cell — exactly as if the user had invoked
    it from the picker — and returns nothing. There is no handle, no
    events, no status: once handed off, the cell is out of this run's
    hands, and a second call for the same ``cell_id`` is rejected.

    Constraints (enforced by the host):

      * ``cell_id`` must be one THIS run created via
        :func:`create_stack_cell` and not yet handed off.
      * ``generator`` must declare ``modify`` in its manifest ``type``;
        this is the only invocation mode available through this call.

    ``prompt`` seeds the child run's ``gen.prompt``. Raises
    :class:`RuntimeError` when the host refuses the handoff.

    Agent-tool twin (the same act as a live chat tool): ``create_cell_with_generator``.
    """
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(
        None,
        lambda: bridge.start_modify_run(
            cell_id=cell_id,
            generator=generator,
            prompt=prompt,
        ),
    )


# ──────────────────────────────────────────────────────────────────────
# Tier A — Chat history (per-thread, open-format transcript files)
# ──────────────────────────────────────────────────────────────────────


class _History:
    """In-memory transcript for the ACTIVE chat thread, persisted to a visible
    open-format JSON file (``<threads_dir>/<thread>.json``; see
    :mod:`collimate.transcript`).

    A chat run can hold many threads — independent conversations that all share
    the cell's workspace files. Each thread keeps its own transcript file;
    :func:`serve_chat` drives switching via :meth:`switch_thread`.
    ``append(role, content)`` rewrites the active thread's file through the
    normal output stage; :meth:`seed` reloads it so a resumed run continues
    where it left off.
    """

    threads_dir: str = "chats"
    active: str = "main"

    def __init__(self) -> None:
        self._messages: list[Message] = []

    @property
    def file(self) -> str:
        return f"{self.threads_dir}/{self.active}.json"

    def append(self, role: str, content: str, *, thinking: str = "") -> None:
        self._messages.append(Message(role=role, content=content, thinking=thinking))
        self._flush()

    def _flush(self) -> None:
        from collimate.transcript import serialize_transcript
        update_file(self.file, serialize_transcript(self._messages))

    def switch_thread(self, thread_id: str, *, threads_dir: Optional[str] = None,
                      load: bool = True) -> None:
        """Make ``thread_id`` the active thread and (by default) load its
        transcript from disk (empty when the thread is new)."""
        if threads_dir:
            self.threads_dir = threads_dir
        self.active = thread_id
        if load:
            self.seed()
        else:
            self._messages = []

    def seed(self) -> bool:
        """(Re)load the active thread's transcript from disk. False when none
        exists yet (and the in-memory list is reset to empty)."""
        from collimate.transcript import parse_transcript
        bridge = _require_bridge()
        if not bridge.fs_exists(self.file):
            self._messages = []
            return False
        try:
            raw = bridge.fs_read_any(self.file)
        except OSError:
            self._messages = []
            return False
        text = raw.decode("utf-8") if isinstance(raw, bytes) else raw
        self._messages = parse_transcript(text)
        return True

    def edit(self, idx: int, content: str) -> bool:
        """Replace the content of the message at ``idx`` (in place), keeping
        its role and thinking. False when the index is out of range."""
        if not (0 <= idx < len(self._messages)):
            return False
        old = self._messages[idx]
        self._messages[idx] = Message(
            role=old.role, content=str(content or ""), thinking=old.thinking,
        )
        return True

    def delete(self, idx: int) -> bool:
        """Drop the message at ``idx``. False when the index is out of range."""
        if not (0 <= idx < len(self._messages)):
            return False
        del self._messages[idx]
        return True

    def insert(self, idx: int, role: str, content: str) -> bool:
        """Insert a new message at ``idx`` (clamped to the transcript bounds).
        False when the role isn't one of user/assistant/system."""
        role = (role or "").strip().lower()
        if role not in ("user", "assistant", "system"):
            return False
        idx = max(0, min(int(idx), len(self._messages)))
        self._messages.insert(idx, Message(role=role, content=str(content or "")))
        return True

    def move(self, idx: int, to: int) -> bool:
        """Move the message at ``idx`` to position ``to`` (reorder). False when
        either index is out of range or the move is a no-op."""
        n = len(self._messages)
        if not (0 <= idx < n and 0 <= to < n) or idx == to:
            return False
        m = self._messages.pop(idx)
        self._messages.insert(to, m)
        return True

    def prepare_regenerate(self, idx: int) -> Optional[str]:
        """Truncate the transcript to before the user message at/-before ``idx``
        and return that user message's content, so the caller can re-run the
        turn (append the user message + regenerate the reply). ``None`` when
        there is no user message to regenerate from."""
        if not (0 <= idx < len(self._messages)):
            idx = len(self._messages) - 1
        j = idx
        while j >= 0 and self._messages[j].role != "user":
            j -= 1
        if j < 0:
            return None
        content = self._messages[j].content
        if not content:
            # Nothing to re-run — and the caller guards its flush/re-run on a
            # truthy prompt, so mutating here would silently desync the
            # in-memory transcript from disk.
            return None
        self._messages = self._messages[:j]
        return content

    def __iter__(self) -> Iterator[Message]:
        return iter(self._messages)

    def __len__(self) -> int:
        return len(self._messages)

    def __getitem__(self, idx):  # type: ignore[no-untyped-def]
        return self._messages[idx]


history = _History()


# ──────────────────────────────────────────────────────────────────────
# Tier A — Secrets (two-tier)
# ──────────────────────────────────────────────────────────────────────


# Provider → env var. Pyodide-only providers are excluded from native
# (CORS-locked under the browser, but we'd resolve a key anyway under
# native).
_PROVIDER_KEY_ENV: dict[str, str] = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
    "groq": "GROQ_API_KEY",
    "cerebras": "CEREBRAS_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
    "gemini": "GEMINI_API_KEY",
    "mistral": "MISTRAL_API_KEY",
}


# Per-provider locks coordinate concurrent ``force=True`` retries —
# without them, a parallel ``asyncio.gather`` of N agent calls that
# all auth-fail would pop the modal N times. With the lock, the first
# retry to acquire pops the modal; the rest wait, then read the
# freshly-set env var and skip.
_FORCE_LOCKS: dict[str, asyncio.Lock] = {}


async def api_key(
    provider: str,
    *,
    force: bool = False,
    description: str = "",
) -> str:
    """Resolve the API key for ``provider`` and set the standard env var
    so the provider's native key lookup picks it up.

    Fast path: ``os.environ[{PROVIDER}_API_KEY]`` when set and not
    ``force``. Slow path: the in-cell modal. ``force=True`` skips the
    fast path — the auth-retry door after a 401. Concurrent
    ``force=True`` calls for the same provider coordinate behind a
    per-provider lock so only one modal pops per retry burst.

    Raises :class:`Cancelled` when the user cancels the modal.
    """
    bridge = _require_bridge()
    env_name = _PROVIDER_KEY_ENV.get(provider.lower(), "")
    if not env_name:
        raise ValueError(
            f"Unknown provider {provider!r}; expected one of "
            f"{sorted(_PROVIDER_KEY_ENV)}."
        )
    if not force:
        existing = (os.environ.get(env_name) or "").strip()
        if existing:
            return existing

    lock = _FORCE_LOCKS.setdefault(env_name, asyncio.Lock())
    async with lock:
        # Re-check env inside the lock: a concurrent retry may have
        # popped the modal and set it while we were waiting. If the
        # value is fresh (matches what bridge._last_force_ts records)
        # use it instead of re-prompting.
        existing = (os.environ.get(env_name) or "").strip()
        if force and existing and bridge._was_recently_force_set(env_name):
            return existing
        if not force and existing:
            return existing

        msg = description or f"API key for {provider} (used by this generator)"
        loop = asyncio.get_event_loop()
        try:
            value = await loop.run_in_executor(
                None,
                lambda: bridge.get_key(env_name, description=msg, force=force),
            )
        except _StopRequested as exc:
            raise Cancelled(f"key request for {env_name!r} cancelled") from exc
        if value:
            os.environ[env_name] = value
            bridge._mark_force_set(env_name)
        return value


async def secret(
    name: str,
    *,
    prompt_if_missing: bool = False,
    description: str = "",
) -> str:
    """Read a non-LLM secret. Default is the env-var fast path only;
    ``prompt_if_missing=True`` opts into the modal flow."""
    fast = os.environ.get(name)
    if fast:
        return fast
    if not prompt_if_missing:
        return ""
    bridge = _require_bridge()
    msg = description or f"Secret {name}"
    loop = asyncio.get_event_loop()
    try:
        value = await loop.run_in_executor(
            None,
            lambda: bridge.get_key(name, description=msg, force=False),
        )
    except _StopRequested as exc:
        raise Cancelled(f"secret request for {name!r} cancelled") from exc
    if value:
        os.environ[name] = value
    return value


# ──────────────────────────────────────────────────────────────────────
# Tier A — Status / control
# ──────────────────────────────────────────────────────────────────────


def log(line: str) -> None:
    """Append a line to the run log (visible in the events panel)."""
    _require_bridge().push_log(line)


def phase(name: str, message: str = "") -> None:
    """Set the run's lifecycle phase — drives the cell's loading indicator.

    Active phases a generator sets: ``"spinning_up"`` (booting — container
    pull, clone, model warm-up), ``"running"`` (real work), ``"finishing"``
    (committing results). The backend drives a baseline machine on its own
    (queued → spinning_up → running → terminal), so calling this just sharpens
    the spinning-up-vs-running distinction. Pair it with a matching
    :func:`update` summary so the human and machine states agree.

    Failure is NOT a phase — signal it through the run outcome (a clear
    ``summary``/``error.md`` + return, or ``finish(success=False)``); the cell
    then renders the error state automatically.

    Portable: works on native and wasm.
    """
    _require_bridge().set_phase(name, message)


def status(msg: str) -> None:
    """Update the live status message of the run's *current* phase.

    Sugar for :func:`phase` that changes only the sub-message (e.g.
    ``"pulling image"``) shown next to the cell's spinner, without changing
    the phase itself.
    """
    _require_bridge().set_status(msg)


# ══════════════════════════════════════════════════════════════════════
# Tier B — Native-only extensions
# ══════════════════════════════════════════════════════════════════════


def workspace_path() -> str:
    """Real filesystem path to the workspace.

    Needed by Docker volume mounts, tools that take a cwd, and any path
    handed to a child process.
    """
    return _require_bridge().workspace


def progress(current: int, total: int) -> None:
    """Emit a live progress bar update."""
    _require_bridge().progress(current, total)


async def serve_port(
    port: int,
    *,
    name: str = "preview",
    path: str = "",
    snapshot_source: Optional[dict[str, str]] = None,
) -> None:
    """Bind ``port`` for daemon generators. The host opens a sandbox
    iframe on the cell at ``port``."""
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(
        None,
        lambda: bridge.serve_port(
            port, name=name, path=path, snapshot_source=snapshot_source,
        ),
    )


async def run_subprocess(
    command,
    *,
    turn_id: Optional[str] = None,
    timeout: int = 120,
    cwd: Optional[str] = None,
    shell: bool = False,
    emit_bash_stdout: bool = True,
    emit_text_delta: bool = False,
    print_stdout: bool = True,
) -> tuple[int, str]:
    """Spawn a subprocess and stream output. Returns
    ``(returncode, full_output)``. Cooperative cancellation: polls
    :func:`gen.cancelled` per line."""
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        None,
        lambda: bridge.run_streamed_subprocess(
            command=command,
            turn_id=turn_id,
            timeout=timeout,
            cwd=cwd,
            shell=shell,
            emit_bash_stdout=emit_bash_stdout,
            emit_text_delta=emit_text_delta,
            print_stdout=print_stdout,
        ),
    )


def snapshot(*, skip_dirs: Optional[set[str]] = None) -> dict[str, str]:
    """``{relpath: sha256_hex}`` for every workspace file."""
    return _require_bridge().snapshot_workspace(skip_dirs=skip_dirs)


async def terminal(
    container_id: str,
    command: list[str],
    *,
    cwd: Optional[str] = None,
    env: Optional[dict[str, str]] = None,
) -> dict:
    """Allocate a WebSocket-backed PTY session in a container.

    Returns ``{session_id, ws_path, token}``. Typical pattern: dump
    this dict (plus a human ``label``) into a ``<name>.terminal`` file
    via :func:`update_file` so the cell renders the live terminal.
    """
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        None,
        lambda: bridge.start_terminal(
            container_id=container_id, command=command, cwd=cwd, env=env,
        ),
    )


def stop_terminal(session_id: str) -> None:
    """Tear down a terminal. Idempotent."""
    _require_bridge().stop_terminal(session_id)


@asynccontextmanager
async def serve_terminal(
    container_id: str,
    command: list[str],
    *,
    cwd: Optional[str] = None,
    env: Optional[dict[str, str]] = None,
    label: str = "Terminal",
    pointer: str = "app.terminal",
    buttons: Optional[list[dict]] = None,
    name: Optional[str] = None,
    summary: Optional[str] = None,
) -> AsyncIterator[dict]:
    """Surface a live terminal on the cell for the lifetime of an ``async
    with`` block — allocate the PTY, write + pin its ``.terminal`` pointer,
    and stop the session on exit, all in one place::

        async with gen.serve_terminal(
            container_id, ["bash"], cwd="/workspace",
            label="Shell", name="Container", summary="live",
        ):
            await gen.wait_until_cancelled()

    ``pointer`` is the pointer file's path (must end in ``.terminal``);
    ``label`` is the renderer's title bar text; ``buttons`` (a list of
    ``{"id", "label"}``) adds toolbar buttons whose clicks arrive via
    :func:`actions` / :func:`wait_for_action`. ``name`` / ``summary`` ride
    the same :func:`update` flush that pins the pointer. The yielded dict is
    the raw ``{session_id, ws_path, token}`` session for callers that need
    it. On exit the PTY is stopped even when the body raises; do container
    teardown in your own ``finally`` around this block.
    """
    from collimate.pointers import terminal_pointer

    session = await terminal(container_id, command, cwd=cwd, env=env)
    update_file(
        pointer,
        json.dumps(terminal_pointer(session, label=label, buttons=buttons), indent=2),
    )
    await update(name=name, summary=summary, pinned=pointer)
    try:
        yield session
    finally:
        try:
            stop_terminal(session.get("session_id", ""))
        except Exception as exc:  # noqa: BLE001 — teardown must not mask the body's error
            log(f"stop_terminal failed: {exc}")


async def wait_for_action(timeout: Optional[float] = None) -> Optional[str]:
    """Block until a renderer emits an action, or ``timeout`` elapses,
    or Stop is requested. Returns the action id or ``None``."""
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    deadline = None if timeout is None else loop.time() + timeout
    while True:
        if bridge.cancelled:
            return None
        action = await loop.run_in_executor(None, bridge.poll_renderer_action)
        if action:
            return action
        if deadline is not None and loop.time() >= deadline:
            return None
        await asyncio.sleep(0.15)


async def actions(*, poll: float = 1.0) -> AsyncIterator[str]:
    """Yield renderer action ids (cell button clicks) until the user stops
    the run — the idiomatic daemon loop for a cell with buttons::

        async with gen.serve_terminal(
            cid, ["bash"],
            buttons=[{"id": "capture", "label": "Capture"}],
        ):
            async for action in gen.actions():
                if action == "capture":
                    ...

    The iterator ends when the run is cancelled, so the ``async for`` body
    never needs its own ``while not gen.cancelled`` bookkeeping. A daemon
    with no buttons parks on :func:`wait_until_cancelled` instead. ``poll``
    bounds how long each internal :func:`wait_for_action` blocks — it is a
    responsiveness knob, not a rate limit.
    """
    bridge = _require_bridge()
    while not bridge.cancelled:
        action = await wait_for_action(timeout=poll)
        if action:
            yield action


async def wait_until_cancelled(poll: float = 0.5) -> None:
    """Park a daemon generator until the user stops the run. The idiomatic
    body for a generator whose work is already running (a terminal, a served
    port, an ``async with gen.live_files()`` mirror) and that just needs to
    stay alive::

        async with gen.live_files():
            ...
            await gen.wait_until_cancelled()
    """
    bridge = _require_bridge()
    while not bridge.cancelled:
        await asyncio.sleep(max(0.05, poll))


async def request_settings(settings_file_path: str) -> dict:
    """Pop a ``.set_yaml`` settings overlay mid-run; block until the
    user presses Continue and return the updated values dict."""
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    try:
        return await loop.run_in_executor(
            None, lambda: bridge.request_settings_update(settings_file_path),
        )
    except _StopRequested as exc:
        raise Cancelled("settings update cancelled") from exc


def emit_stream_event(turn_id: str, event: dict) -> None:
    """Push a typed stream event to the cell's live renderer.

    Fire-and-forget. The host routes the event to the WebSocket of the chat
    session bound to this cell; the renderer reducer interprets ``event``
    (e.g. ``{"type": "text_delta", "text": ...}``). Most generators use
    :class:`ChatTurn`'s ``delta``/``tool`` rather than calling this directly.
    """
    _require_bridge().stream_event(turn_id, event)


def emit_event(event: dict) -> None:
    """Push a typed event from this run to its **parent** generator.

    The streaming twin of how a normal run streams to the UI: when this run
    was started as a parent-bound sub-run (``gen.spawn`` / ``gen.call``), the
    host buffers each ``event`` and the parent consumes it in order via
    :meth:`GeneratorHandle.events`. Fire-and-forget; a no-op when this run has
    no parent (a user-launched top-level run) or there is no host (dev mode).

    ``event`` is an arbitrary JSON-able dict; by convention it carries a
    ``"type"`` key. The ``agent`` toolset generator emits
    ``{"type": "text_delta", "text": ...}`` (token deltas),
    ``{"type": "tool", ...}`` (tool activity), and ``{"type": "status", ...}``
    so a caller can forward them to its own live surface — e.g. a chat
    renderer via ``turn.delta``.
    """
    _require_bridge().emit_event(event)


class ChatTurn:
    """One chat turn handed to a :func:`serve_chat` handler.

    The handler streams the assistant reply via :meth:`delta` / :meth:`tool`
    (typically by forwarding the deltas of a spawned ``agent`` sub-run — see
    :meth:`GeneratorHandle.events`) and may observe :attr:`cancelled` (set on
    interrupt or redirect). :func:`serve_chat` brackets the handler with
    ``turn_start`` / ``turn_end`` events automatically, so the handler only
    emits the deltas in between.

    The turn is **bound to the thread active when it started**. Read the
    conversation via :attr:`messages` and record the exchange via
    :meth:`append` — both target the bound thread, so this turn's reply can
    never be misfiled into another thread's transcript. A ``thread_switch`` /
    ``thread_new`` does **not** cancel the turn: the renderer has merely
    navigated away, so the turn keeps generating in the background and
    finalizes into its bound thread's file (every event it emits carries the
    bound ``thread_id`` so the renderer can scope it). :attr:`cancelled`
    flips only on an explicit interrupt or a same-thread redirect.
    """

    def __init__(self, user_msg: str, turn_id: str, hist: "_History", emit_fn,
                 *, thread_id: Optional[str] = None,
                 messages: Optional[list] = None) -> None:
        self.user_msg = user_msg
        self.turn_id = turn_id
        self.history = hist
        self.cancelled = False
        self.redirect: Optional[str] = None
        self._emit = emit_fn
        # Snapshot the thread this turn belongs to at start. All reads/writes
        # for the turn use this snapshot + file, independent of history.active.
        # A redirect re-run passes both explicitly (its bound thread may no
        # longer be the active one, so ``hist`` can't be consulted).
        self.thread_id = thread_id or hist.active
        self.threads_dir = hist.threads_dir
        self._file = f"{self.threads_dir}/{self.thread_id}.json"
        self._messages: list[Message] = (
            list(messages) if messages is not None else list(hist)
        )

    @property
    def messages(self) -> list["Message"]:
        """This turn's thread transcript so far (append the user message first)."""
        return list(self._messages)

    def append(self, role: str, content: str, *, thinking: str = "") -> None:
        """Append a message to THIS turn's thread transcript and persist it.

        Writes to the bound thread's file regardless of the currently-active
        thread, and keeps the shared :data:`history` singleton coherent only
        while the bound thread is still the active one. ``thinking`` carries
        the model's reasoning for an assistant message (optional).
        """
        from collimate.transcript import serialize_transcript
        self._messages.append(Message(role=role, content=content, thinking=thinking))
        update_file(self._file, serialize_transcript(self._messages))
        if self.history.active == self.thread_id:
            self.history._messages = list(self._messages)

    def emit(self, event: dict) -> None:
        # Every turn-scoped event carries the bound thread, so the renderer
        # can scope deltas/tools to the right thread while a background turn
        # streams (the turn no longer dies on thread_switch).
        if "thread_id" not in event:
            event = {**event, "thread_id": self.thread_id}
        self._emit(self.turn_id, event)

    def delta(self, text: str) -> None:
        self.emit({"type": "text_delta", "text": text})

    def thinking_delta(self, text: str) -> None:
        """Stream a chunk of the model's reasoning for this turn (rendered as
        a collapsible section by the chat renderer)."""
        self.emit({"type": "thinking_delta", "text": text})

    def tool(self, name: str, status: str = "running", **kw) -> None:
        self.emit({"type": "tool", "name": name, "status": status, **kw})


async def serve_chat(
    on_turn,
    *,
    label: str = "Chat",
    threads_dir: str = "chats",
    default_thread: str = "main",
    resume: bool = True,
    integration: Optional[dict] = None,
    pointer_file: str = "conversation.chat",
    initial_message: str = "",
) -> None:
    """Serve a live, multi-thread streaming chat against this run until Stop.

    Registers a chat session, writes & pins the ``.chat`` session pointer (so
    the assistant-ui renderer mounts), seeds the active thread's history, then
    dispatches inbound user messages to ``on_turn(turn)``. Your handler streams
    the reply via ``turn.delta`` (typically forwarding a spawned ``agent``
    sub-run's deltas) and records it with ``gen.history.append``.

    ``initial_message`` seeds the FIRST turn (the run's prompt, typically):
    it is dispatched exactly like an inbound user message, but only when the
    active thread's transcript is empty — a resumed cell never re-sends it.

    Threads are independent conversations sharing the cell's workspace files;
    each is persisted to its own open-format transcript at
    ``<threads_dir>/<id>.json``. The renderer drives them through the same
    inbound channel: ``thread_new`` (start a blank thread) and ``thread_switch``
    (load an existing one) — neither cancels an in-flight turn; the turn keeps
    generating in the background and lands in its bound thread (its events all
    carry ``thread_id``). Interrupt / same-thread redirect arrive on the
    in-flight turn as ``turn.cancelled`` / ``turn.redirect``; a message for a
    *different* thread while one is generating is refused with a ``busy``
    event (single-flight). Transcript curation commands (``edit`` / ``delete``
    / ``insert`` / ``move``) are applied to the active thread's durable
    transcript whenever *it* has no turn in flight; ``regenerate`` starts a
    turn, so it additionally requires global idle.

    ``integration`` is passed through to the pointer so the renderer picks its
    runtime: ``None`` → native (this WebSocket, the default); a dict → a direct
    backend integration (e.g. opencode). On exit the active transcript is
    flushed; the pinned pointer renders the saved threads when the session ends.
    """
    import uuid

    from collimate.pointers import chat_session_pointer

    bridge = _require_bridge()
    loop = asyncio.get_event_loop()

    # Discover existing threads (resumed cell) + ensure the default exists.
    def _discover_threads() -> list:
        found = []
        prefix = f"{threads_dir}/"
        for p in sorted(bridge.fs_list()):
            if p.startswith(prefix) and p.endswith(".json"):
                tid = p[len(prefix):-len(".json")]
                found.append({"id": tid, "title": _title_for(tid), "file": p})
        if not any(t["id"] == default_thread for t in found):
            found.insert(0, {
                "id": default_thread, "title": _title_for(default_thread),
                "file": f"{threads_dir}/{default_thread}.json",
            })
        return found

    threads = _discover_threads()
    history.switch_thread(default_thread, threads_dir=threads_dir, load=resume)

    info = await loop.run_in_executor(None, bridge.chat_register)

    def _write_pointer() -> None:
        update_file(pointer_file, json.dumps(chat_session_pointer(
            info, label=label, threads_dir=threads_dir,
            active_thread=history.active, threads=threads, integration=integration,
        )))
        # Push the live thread list so an attached renderer updates its thread
        # bar without waiting for a remount (the pointer it read at mount only
        # covers threads that existed then). turn_id="" — not tied to a turn.
        bridge.stream_event("", {
            "type": "threads", "threads": threads, "active": history.active,
        })

    _write_pointer()
    # Materialize the active transcript so a history read resolves pre-first-turn.
    history._flush()
    await update(pinned=pointer_file)

    current: list[Optional[ChatTurn]] = [None]
    pending: set = set()

    async def _run_turn(content: str, *, thread_id: Optional[str] = None,
                        seed: Optional[list] = None) -> None:
        # Re-seed the active thread from disk so user edits committed between
        # turns survive (the host flushes the edited transcript before
        # delivering the command). No-op round-trip when unchanged. Skipped
        # for a redirect re-run bound to a (possibly no-longer-active)
        # thread — its seed is the cancelled turn's own transcript.
        if resume and thread_id is None:
            try:
                history.seed()
            except Exception:
                bridge.log.exception("serve_chat: per-turn reseed failed")
        turn = ChatTurn(content, uuid.uuid4().hex, history, bridge.stream_event,
                        thread_id=thread_id, messages=seed)
        current[0] = turn
        bridge.stream_event(turn.turn_id, {
            "type": "turn_start", "thread_id": turn.thread_id,
        })
        try:
            await on_turn(turn)
        except (Cancelled, _StopRequested):
            raise
        except Exception as exc:
            bridge.log.exception("serve_chat: on_turn failed")
            bridge.stream_event(turn.turn_id, {
                "type": "error", "message": str(exc), "thread_id": turn.thread_id,
            })
        finally:
            bridge.stream_event(turn.turn_id, {
                "type": "turn_end", "thread_id": turn.thread_id,
            })
            current[0] = None
        if turn.redirect is not None:
            # Re-run bound to the SAME thread with the cancelled turn's own
            # transcript — history may have switched threads meanwhile.
            await _run_turn(turn.redirect, thread_id=turn.thread_id,
                            seed=turn._messages)

    def _refuse_busy(tid: str = "", content: str = "") -> None:
        # Single-flight: a message for another thread while a turn is
        # generating is refused, not queued — the renderer shows the hint.
        # ``content`` echoes the refused text so the renderer can restore it
        # into the composer instead of losing what the user typed.
        ev: dict = {
            "type": "busy", "thread_id": tid or history.active,
            "message": "The assistant is still replying in another thread — "
                       "wait for it to finish or stop it first.",
        }
        if content:
            ev["content"] = content
        bridge.stream_event("", ev)

    def _ensure_thread(tid: str) -> None:
        if not any(t["id"] == tid for t in threads):
            threads.append({"id": tid, "title": _title_for(tid),
                            "file": f"{threads_dir}/{tid}.json"})

    def _start_turn(content: str) -> None:
        t = asyncio.ensure_future(_run_turn(content))
        pending.add(t)
        t.add_done_callback(pending.discard)

    async def _sync_active(tid: str) -> None:
        """Heal a renderer↔server active-thread desync (a thread_switch lost
        across a dropped socket): a message frame that names its thread is
        authoritative about where the user is typing."""
        history.switch_thread(tid, load=True)
        _ensure_thread(tid)
        _write_pointer()
        await update(pinned=pointer_file)

    def _any_transcript_content() -> bool:
        """True when ANY discovered thread already holds messages — the whole
        chat must be virgin for the run prompt to seed the first turn (the
        active thread alone isn't enough: the conversation may live in a side
        thread while the default one sits empty)."""
        from collimate.transcript import parse_transcript
        for t in threads:
            try:
                if not bridge.fs_exists(t["file"]):
                    continue
                raw = bridge.fs_read_any(t["file"])
                text = raw.decode("utf-8") if isinstance(raw, bytes) else raw
                if parse_transcript(text):
                    return True
            except Exception:  # noqa: BLE001 — unreadable file ≠ content
                continue
        return False

    # Seed the first turn from the run's prompt — but only into a virgin
    # chat, so a resumed cell never re-sends it on rerun.
    if (initial_message or "").strip() and len(history) == 0 \
            and not _any_transcript_content():
        _start_turn(initial_message.strip())

    try:
        while not bridge.cancelled:
            cmd = await loop.run_in_executor(None, bridge.chat_poll)
            if not cmd:
                await asyncio.sleep(_CHAT_POLL_INTERVAL_S)
                continue
            kind = cmd.get("kind", "")
            if kind == "user_msg":
                content = cmd.get("content", "") or ""
                # The frame names the thread the user typed in (missing on a
                # legacy renderer → the server-side active thread).
                target = (cmd.get("thread_id") or "").strip() or history.active
                if current[0] is None:
                    if target != history.active:
                        await _sync_active(target)
                    _start_turn(content)
                elif current[0].thread_id == target:
                    # Same-thread send while streaming = redirect (cancel +
                    # re-run with the new content).
                    current[0].redirect = content
                    current[0].cancelled = True
                else:
                    _refuse_busy(target, content)
            elif kind == "interrupt":
                # Cancel only when the interrupt targets the in-flight turn's
                # thread (no thread_id = legacy renderer → unconditional).
                if current[0] is not None and (
                    (cmd.get("thread_id") or "") in ("", current[0].thread_id)
                ):
                    current[0].cancelled = True
            elif kind == "redirect":
                content = cmd.get("content", "") or ""
                target = (cmd.get("thread_id") or "").strip() or history.active
                if current[0] is not None:
                    if current[0].thread_id == target:
                        current[0].redirect = content
                        current[0].cancelled = True
                    else:
                        _refuse_busy(target, content)
                elif content:
                    # The renderer thought a turn was still running (a stale
                    # flag after a detach/reconnect). Don't drop the user's
                    # message — run it as a fresh turn.
                    if target != history.active:
                        await _sync_active(target)
                    _start_turn(content)
            elif kind == "thread_new":
                # Does NOT cancel an in-flight turn — it keeps streaming into
                # its bound thread in the background.
                tid = (cmd.get("thread_id") or uuid.uuid4().hex[:8]).strip()
                history.switch_thread(tid, load=False)
                _ensure_thread(tid)
                history._flush()          # materialize the empty thread
                _write_pointer()          # active + thread list
                await update(pinned=pointer_file)
            elif kind == "thread_switch":
                # Likewise non-cancelling (see thread_new above).
                tid = (cmd.get("thread_id") or "").strip()
                if tid and tid != history.active:
                    history.switch_thread(tid, load=True)
                    _ensure_thread(tid)
                    _write_pointer()
                    await update(pinned=pointer_file)
            elif kind in ("edit", "delete", "insert", "move", "regenerate"):
                # Transcript curation targets the ACTIVE thread — allowed
                # while a background turn streams into ANOTHER thread, blocked
                # only when the active thread itself is busy (the renderer
                # gates on the same rule). Re-seed from disk first so the
                # index matches exactly what the renderer is showing.
                if current[0] is not None and current[0].thread_id == history.active:
                    continue
                try:
                    idx = int(cmd.get("index"))
                except (TypeError, ValueError):
                    continue
                if resume:
                    try:
                        history.seed()
                    except Exception:
                        bridge.log.exception("serve_chat: reseed before %s failed", kind)
                if kind == "edit":
                    if history.edit(idx, cmd.get("content", "")):
                        history._flush()
                        await update()
                elif kind == "delete":
                    if history.delete(idx):
                        history._flush()
                        await update()
                elif kind == "insert":
                    if history.insert(idx, cmd.get("role", "user"), cmd.get("content", "")):
                        history._flush()
                        await update()
                elif kind == "move":
                    try:
                        to = int(cmd.get("to"))
                    except (TypeError, ValueError):
                        continue
                    if history.move(idx, to):
                        history._flush()
                        await update()
                else:  # regenerate — drop the reply, re-run the turn from its prompt
                    # Regenerate STARTS a turn, so it needs global idle
                    # (single-flight) — not just an idle active thread.
                    if current[0] is not None:
                        _refuse_busy()
                        continue
                    content = history.prepare_regenerate(idx)
                    if content:
                        history._flush()
                        await update()
                        _start_turn(content)
    finally:
        if pending:
            await asyncio.wait(list(pending), timeout=2.0)
        for t in list(pending):
            t.cancel()
        try:
            history._flush()
            _write_pointer()
            await update(pinned=pointer_file)
        except Exception:
            bridge.log.exception("serve_chat: final transcript flush failed")


def _title_for(thread_id: str) -> str:
    return "Main" if thread_id == "main" else f"Thread {thread_id}"


_CHAT_POLL_INTERVAL_S = 0.2


# ──────────────────────────────────────────────────────────────────────
# Entrypoint helper
# ──────────────────────────────────────────────────────────────────────


# ──────────────────────────────────────────────────────────────────────
# Composition — discover / spawn / call other generators, and compile-check
# a renderer. Host-backed, public to every generator (the builders use the
# same surface, no private powers). Invisible by default: spawning creates
# no cell unless you pass surface=. In dev mode (no host) these degrade to a
# clean "no host" result — never hanging, never raising.
# ──────────────────────────────────────────────────────────────────────


class Source:
    """An inline, uninstalled generator passed to :func:`spawn` / :func:`call`.

    Wraps a staged file set + entrypoint so a builder can validate a
    just-authored candidate without installing it. Build via :func:`inline`.
    """

    __slots__ = ("files", "entrypoint")

    def __init__(self, files: dict, entrypoint: str) -> None:
        self.files = dict(files)
        self.entrypoint = entrypoint

    def _payload(self) -> dict:
        return {"inline": {"files": _encode_files(self.files), "entrypoint": self.entrypoint}}


class SurfaceSpec:
    """How to surface a (parent-bound) sub-run as a visible cell."""

    __slots__ = ("name",)

    def __init__(self, name: str = "Preview") -> None:
        self.name = name

    def _to_dict(self) -> dict:
        return {"name": self.name}


def inline(files: dict, *, entrypoint: str) -> Source:
    """Wrap staged files as a spawnable source (an uninstalled candidate)."""
    return Source(files, entrypoint)


def _source_payload(source) -> dict:
    if isinstance(source, Source):
        return source._payload()
    return {"id": str(source)}


def generators(*, group: Optional[str] = None) -> list:
    """List generators available to spawn/call (host-backed; ``[]`` in dev
    mode). Returns :class:`GeneratorInfo` objects ordered by the host.
    Pass ``group`` to filter to a single group (the generator-source cell
    name) — replaces the old ``category`` filter.

    Agent-tool twin (the same act as a live chat tool): ``list_generators``.
    """
    raw = _require_bridge().list_generators()
    infos = [_info_from_dict(d) for d in raw if isinstance(d, dict)]
    if group is not None:
        infos = [i for i in infos if i.group == group]
    return infos


def generator_info(gid: str) -> Optional[GeneratorInfo]:
    """The :class:`GeneratorInfo` for one generator id, or ``None`` if it
    isn't installed/exposed. Sugar over :func:`generators` — no extra host
    round-trip beyond the list it already fetches."""
    for info in generators():
        if info.id == gid:
            return info
    return None


def tag_config(gid: str, tag: str, *, overrides: Optional[dict] = None) -> dict:
    """Resolve a callee generator's named config tag into a ready-made
    ``config=`` payload, with the caller's overrides layered on top.

    This backs the parent-generator convention: instead of mirroring a
    callee's settings in its own draft file, a parent surfaces ONE text
    field (e.g. "agent config tag"), resolves it here, and overrides only
    the settings it has opinions about::

        values = gen.tag_config("agent", tag)          # {} when tag is blank
        flat = values.get("agent-config.set_yaml", {})
        config = {"agent-config.set_yaml": {
            **flat,
            "mode": "oneshot",                          # the parent's opinions win
            "output_schema": MyModel.model_json_schema(),
        }}

    A blank ``tag`` returns just the ``overrides`` (the callee's own
    defaults apply). An unknown tag — or a callee that isn't reachable
    (not installed/exposed, or dev mode) — raises ``ValueError`` naming
    the available tags, so the parent's run fails with actionable guidance
    instead of silently running on the wrong settings. Tag names match
    case-insensitively. ``overrides`` uses the same per-draft-file shape
    as the returned payload (``{set_yaml_rel: {key: value}}``) and wins
    key-by-key within each file."""
    tag = (tag or "").strip()
    merged: dict = {}
    if tag:
        info = generator_info(gid)
        if info is None:
            raise ValueError(
                f"cannot resolve config tag {tag!r}: generator {gid!r} is not "
                "reachable (not installed, not exposed to generators, or dev mode)"
            )
        match = next(
            (t for t in info.config_tags if t.name.strip().lower() == tag.lower()),
            None,
        )
        if match is None:
            names = ", ".join(repr(t.name) for t in info.config_tags) or "(none declared)"
            raise ValueError(
                f"unknown config tag {tag!r} on generator {gid!r} — available tags: {names}"
            )
        merged = {
            rel: dict(vals)
            for rel, vals in (match.values or {}).items()
            if isinstance(vals, dict)
        }
    for rel, vals in (overrides or {}).items():
        if isinstance(vals, dict):
            merged[rel] = {**merged.get(rel, {}), **vals}
        else:
            merged[rel] = vals
    return merged


class ProcessHandle:
    """A long-running process started in a child environment via
    :meth:`GeneratorHandle.exec_background`. Reaped when the environment is
    torn down; ``.stop()`` / ``.wait()`` are idempotent / dev-mode safe."""

    def __init__(self, handle: "GeneratorHandle", process_id: str) -> None:
        self._handle = handle
        self.id = process_id

    async def wait(self, *, timeout: Optional[float] = None) -> int:
        """Block until the process exits; return its return code (``-1`` when
        unavailable)."""
        if not self.id:
            return -1
        ack = await self._handle._run(
            lambda: self._handle._bridge.sub_run_wait_process(
                self._handle.id, self.id, timeout=timeout
            )
        )
        return int(ack.get("rc", -1))

    async def stop(self) -> None:
        """Terminate the process. Idempotent."""
        if not self.id:
            return
        await self._handle._run(
            lambda: self._handle._bridge.sub_run_stop_process(self._handle.id, self.id)
        )


class GeneratorHandle:
    """Live handle to a parent-bound child sub-run — terminating or daemon.

    The child is stopped automatically when the parent run ends or the
    async-context exits. Invisible until :meth:`surface` is called. All
    methods degrade to a benign value when there is no host (dev mode)."""

    def __init__(self, bridge, sub_run_id: str, source) -> None:
        self._bridge = bridge
        self.id = sub_run_id
        self.source = source
        self._stopped = False

    async def _run(self, fn):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, fn)

    async def endpoints(self, *, wait: bool = True, timeout: Optional[float] = 30.0) -> list:
        """Ports/terminals the child has bound. When ``wait`` (default),
        polls until the first appears or ``timeout`` elapses."""
        if not self.id:
            return []
        loop = asyncio.get_event_loop()
        deadline = None if (not wait or timeout is None) else loop.time() + timeout
        while True:
            eps = await self._run(lambda: self._bridge.sub_run_endpoints(self.id))
            if eps or not wait:
                return [_endpoint_from_dict(e) for e in eps if isinstance(e, dict)]
            # A finished/failed child will never bind a port — stop polling
            # even when timeout is None.
            if (await self._run(lambda: self._bridge.sub_run_status(self.id))) in ("done", "failed"):
                return []
            if self._bridge.cancelled or (deadline is not None and loop.time() >= deadline):
                return []
            await asyncio.sleep(0.15)

    async def status(self) -> str:
        """``"running"`` | ``"done"`` | ``"failed"``."""
        if not self.id:
            return "failed"
        return await self._run(lambda: self._bridge.sub_run_status(self.id))

    async def events(
        self,
        *,
        poll_interval: float = 0.1,
        idle_timeout: Optional[float] = None,
        should_stop: Optional[Callable[[], bool]] = None,
    ):
        """Async stream of the events the child emitted via ``gen.emit_event``.

        Yields event dicts **in order**, draining the host-side buffer until
        the child reaches ``done``/``failed`` and no events remain. This is the
        generator→generator twin of the run→UI stream: a chat parent forwards
        ``{"type": "text_delta", "text": ...}`` events to ``turn.delta`` to
        stream a spawned ``agent`` sub-run's reply live::

            handle = gen.spawn("agent", prompt=msg, config={"stream": True})
            async for ev in handle.events(should_stop=lambda: turn.cancelled):
                if ev.get("type") == "text_delta":
                    turn.delta(ev["text"])

        Poll-based (no host push channel needed), like :meth:`watch_files`. The
        stream **ends gracefully** (returns, never raises) so the caller always
        reaches its post-loop reconcile — on child done/failed, on parent
        cancellation, when ``should_stop()`` flips True (pass
        ``lambda: turn.cancelled`` to honour a chat interrupt even while the
        child is hung between events), after ``idle_timeout`` of silence, or on
        a transient IPC fault during a poll. The authoritative output is the
        child's result (``_agent/output.md`` / :meth:`files`), so a dropped
        trailing delta never costs you the canonical text. Empty immediately in
        dev mode / when the child never started.
        """
        if not self.id:
            return
        loop = asyncio.get_event_loop()
        cursor = 0
        last_event_at = loop.time()
        while True:
            if should_stop is not None and should_stop():
                return
            try:
                ack = await self._run(
                    lambda c=cursor: self._bridge.sub_run_poll_events(self.id, c)
                )
            except (IPCTimeoutError, IPCDisconnectedError):
                # A transient stall / socket blip ends the live stream cleanly;
                # the caller falls through to its reconcile from the result.
                return
            evs = ack.get("events") or []
            if evs:
                cursor = int(ack.get("cursor", cursor + len(evs)))
                last_event_at = loop.time()
                for ev in evs:
                    yield ev
                continue
            # No new events: stop once the child is terminal (we just drained
            # the buffer above), on cancellation, or after an idle timeout.
            if ack.get("state", "running") in ("done", "failed"):
                return
            if self._bridge.cancelled or (should_stop is not None and should_stop()):
                return
            if idle_timeout is not None and (loop.time() - last_event_at) > idle_timeout:
                return
            await asyncio.sleep(poll_interval)

    async def stream_text(
        self,
        *,
        poll_interval: float = 0.1,
        idle_timeout: Optional[float] = None,
        should_stop: Optional[Callable[[], bool]] = None,
    ):
        """Yield the child's assistant **text deltas** — the ``text_delta``
        events a sub-run emits via ``gen.emit_event`` (the ``agent`` generator
        does this when ``stream`` is set). Sugar over :meth:`events` so
        streaming a spawned agent's reply to a chat turn is one loop::

            handle = gen.spawn("agent", prompt=msg, config={..., "stream": True})
            async for chunk in handle.stream_text():
                turn.delta(chunk)

        Non-text events (``thinking_delta`` / tool / status / …) are dropped —
        reach for :meth:`events` directly when you need them (the guide does,
        to forward reasoning). The authoritative full reply is still the
        child's result (``_agent/output.md`` / :meth:`files`), so a dropped
        trailing delta never costs you the canonical text.

        Pass ``should_stop=lambda: turn.cancelled`` so a chat interrupt ends the
        stream promptly even while the agent is hung between deltas."""
        async for ev in self.events(
            poll_interval=poll_interval,
            idle_timeout=idle_timeout,
            should_stop=should_stop,
        ):
            if ev.get("type") == "text_delta":
                chunk = ev.get("text")
                if chunk:
                    yield chunk

    def mirror_files(
        self,
        *,
        to_cell: bool = True,
        from_cell: bool = True,
        exclude: tuple = (),
        interval: float = 0.5,
    ) -> "_Mirror":
        """Live-sync this cell (the Files tab) with the child sub-run's
        workspace for the lifetime of an ``async with`` block — the easy way to
        give a ``live_files`` generator bidirectional editing across the spawn
        boundary::

            handle = gen.spawn("agent", inputs=cell_files, prompt=msg,
                               config={..., "enable_file_tools": True})
            async with handle.mirror_files(exclude=(".chat",)):
                async for chunk in handle.stream_text():
                    turn.delta(chunk)

        While the block is open the child's writes are mirrored into the cell
        live (``to_cell``) and the user's live edits are pushed into the running
        child (``from_cell``). Same engine as :func:`live_files`: the two
        directions are echo-suppressed (a value just synced one way is not
        bounced back), the child wins a genuine simultaneous edit, the agent's
        own ``_agent/`` bookkeeping is always excluded, and a final reconcile
        runs on exit so a last-moment write is never lost. Seed the child's
        initial state at spawn via ``inputs=``. Degrades to a no-op without a
        host."""
        return _Mirror(
            _ChildWorkspace(self), _CellStore(),
            to_remote=to_cell, from_remote=from_cell,
            exclude=tuple(exclude), interval=interval,
            guard=lambda: bool(self.id),
        )

    async def files(self) -> dict:
        """The child's output files so far."""
        if not self.id:
            return {}
        return _decode_files(await self._run(lambda: self._bridge.sub_run_files(self.id)))

    async def wait(self, *, timeout: Optional[float] = None) -> GeneratorResult:
        """Block until the child finishes; return its :class:`GeneratorResult`."""
        if not self.id:
            return GeneratorResult(ok=False, error="no host available")
        ack = await self._run(lambda: self._bridge.sub_run_wait(self.id, timeout))
        return _result_from_ack(ack)

    async def stop(self) -> None:
        """Idempotent teardown."""
        if not self.id or self._stopped:
            return
        self._stopped = True
        await self._run(lambda: self._bridge.stop_sub_run(self.id))

    async def surface(self, spec=None) -> str:
        """Promote the (parent-bound) sub-run to a visible cell in the
        parent's stack. Returns the new cell id."""
        if not self.id:
            return ""
        d = spec._to_dict() if isinstance(spec, SurfaceSpec) else (spec or {})
        return await self._run(lambda: self._bridge.surface_sub_run(self.id, d))

    # ── Environment surface — drive a child environment ──────────────
    # `capabilities` tells you the contract; the workspace plane (files) is
    # host-serviced and guaranteed; the execution plane (exec/exec_background/
    # expose_port/open_terminal) is routed to the child environment. All
    # degrade to a benign value when there is no host / no environment.

    async def capabilities(self) -> Optional[EnvironmentSpec]:
        """The :class:`EnvironmentSpec` this child offers, or ``None`` when it
        is not an environment (or no host)."""
        if not self.id:
            return None
        d = await self._run(lambda: self._bridge.sub_run_capabilities(self.id))
        return _env_spec_from_dict(d) if d is not None else None

    # --- workspace plane (host-serviced, guaranteed) ---

    async def put_files(self, files: dict) -> None:
        """Write a ``{path: str|bytes}`` map into the child's workspace (the
        generator-driven twin of live-file editing)."""
        if not self.id or not files:
            return
        await self._run(lambda: self._bridge.sub_run_put_files(self.id, dict(files)))

    async def write_file(self, path: str, content) -> None:
        """Single-file :meth:`put_files`."""
        await self.put_files({path: content})

    async def read_file(self, path: str):
        """Read one file from the child's workspace. utf-8 → ``str`` else
        ``bytes``. Raises ``FileNotFoundError`` when absent."""
        if not self.id:
            raise FileNotFoundError(path)
        ack = await self._run(lambda: self._bridge.sub_run_read_file(self.id, path))
        if not ack.get("ok"):
            raise FileNotFoundError(path)
        decoded = _decode_files(ack.get("file") or {})
        if path not in decoded:
            raise FileNotFoundError(path)
        return decoded[path]

    async def delete_file(self, path: str) -> None:
        """Delete one file from the child's workspace."""
        if not self.id:
            return
        await self._run(lambda: self._bridge.sub_run_delete_file(self.id, path))

    async def list_files(self) -> list:
        """Sorted paths in the child's workspace."""
        if not self.id:
            return []
        return list(await self._run(lambda: self._bridge.sub_run_list_files(self.id)))

    async def snapshot(self) -> dict:
        """``{relpath: sha256}`` of the child's workspace — pair before/after an
        :meth:`exec` to see what changed."""
        if not self.id:
            return {}
        return dict(await self._run(lambda: self._bridge.sub_run_snapshot(self.id)))

    async def watch_files(self, *, interval: float = 1.0):
        """Async stream of ``{path, change}`` events under the child's
        workspace. Pull-based (diffs :meth:`snapshot`), so it works without a
        host push channel. Exits when the run is cancelled."""
        if not self.id:
            return
        prev = await self.snapshot()
        while not self._bridge.cancelled:
            await asyncio.sleep(interval)
            cur = await self.snapshot()
            for p in sorted(p for p in cur if prev.get(p) != cur[p]):
                yield {"path": p, "change": "modified"}
            for p in sorted(p for p in prev if p not in cur):
                yield {"path": p, "change": "deleted"}
            prev = cur

    # --- execution plane (routed to the environment) ---

    async def exec(self, command, *, cwd: Optional[str] = None,
                   env: Optional[dict] = None, timeout: int = 120) -> tuple:
        """Run ``command`` in the child environment; return ``(rc, output)``.
        ``(-1, error)`` when there is no host / the environment is gone."""
        if not self.id:
            return (-1, "")
        ack = await self._run(
            lambda: self._bridge.sub_run_exec(self.id, command, cwd=cwd, env=env, timeout=timeout)
        )
        if not ack.get("ok", True):
            return (int(ack.get("rc", -1)), ack.get("error") or ack.get("output", ""))
        return (int(ack.get("rc", -1)), ack.get("output", ""))

    async def exec_background(self, command, *, cwd: Optional[str] = None,
                             env: Optional[dict] = None) -> "ProcessHandle":
        """Start a long-running process in the child environment; return a
        :class:`ProcessHandle` (``.wait()`` / ``.stop()``)."""
        if not self.id:
            return ProcessHandle(self, "")
        ack = await self._run(
            lambda: self._bridge.sub_run_exec_background(self.id, command, cwd=cwd, env=env)
        )
        return ProcessHandle(self, ack.get("process_id", ""))

    async def expose_port(self, port: int) -> Endpoint:
        """Expose a container port from the child environment; return the
        :class:`Endpoint` (also appears in :meth:`endpoints`)."""
        if not self.id:
            return Endpoint(kind="http", port=port)
        ack = await self._run(lambda: self._bridge.sub_run_expose_port(self.id, port))
        return _endpoint_from_dict(ack.get("endpoint") or {"kind": "http", "port": port})

    async def open_terminal(self, command=None, *, cwd: Optional[str] = None,
                            env: Optional[dict] = None) -> dict:
        """Open an interactive PTY in the child environment (declared
        ``terminals: N``). Returns ``{session_id, ws_path, token}`` (``{}`` when
        unavailable) — drop it into a ``.terminal`` pointer or surface it."""
        if not self.id:
            return {}
        return await self._run(
            lambda: self._bridge.sub_run_open_terminal(self.id, command or ["bash"], cwd=cwd, env=env)
        )

    async def __aenter__(self) -> "GeneratorHandle":
        return self

    async def __aexit__(self, *exc) -> None:
        await self.stop()


def _content_hash(content) -> str:
    import hashlib
    raw = content.encode("utf-8") if isinstance(content, str) else (content or b"")
    return hashlib.sha256(raw).hexdigest()


# ---------------------------------------------------------------------------
# live_files — one bidirectional, echo-suppressed file mirror behind every
# "keep two file stores in sync" relationship:
#   * gen.live_files()        the cell (Files tab) <-> this run's own workspace
#   * handle.mirror_files()   the cell (Files tab) <-> a child sub-run's workspace
# A single _Mirror engine reconciles two _FileEndpoints on a short interval; a
# shared path->hash map suppresses echoes so a value synced one way is never
# bounced back. The LEFT endpoint wins a genuine simultaneous edit.
# ---------------------------------------------------------------------------

# Directory names neither side walks, and path prefixes neither side ever
# syncs: ``.colreserved/`` is private SDK/host state and ``_agent/`` is the
# agent toolset's own bookkeeping — never part of the user's cell.
_LIVE_SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv"}


def _mirror_skip(path: str, exclude: tuple) -> bool:
    return (
        (not path)
        or path == ".colreserved" or path.startswith(".colreserved/")
        or path.startswith("_agent/")
        or (bool(exclude) and path.endswith(exclude))
    )


class _FileEndpoint:
    """One side of a mirror. ``hashes`` returns ``{path: sha256}``; ``read``
    returns one file's content (``str``/``bytes``); ``write``/``delete``
    mutate; ``commit`` flushes any batched writes (only the cell needs it)."""

    label = "endpoint"

    async def hashes(self) -> dict:
        raise NotImplementedError

    async def read(self, path):
        raise NotImplementedError

    async def write(self, path, content) -> None:
        raise NotImplementedError

    async def delete(self, path) -> None:
        raise NotImplementedError

    async def commit(self) -> None:
        return None


class _LocalWorkspace(_FileEndpoint):
    """This run's own workspace dir (the one a Docker generator bind-mounts
    into its container). Reads/writes go straight to disk — never staged for
    the cell, since the cell endpoint owns that direction."""

    label = "workspace"

    def __init__(self, skip_dirs):
        self._skip_dirs = set(skip_dirs or ())

    async def hashes(self) -> dict:
        return snapshot(skip_dirs=self._skip_dirs)

    async def read(self, path):
        return read_file(path)

    async def write(self, path, content) -> None:
        full = os.path.join(workspace_path(), path)
        os.makedirs(os.path.dirname(full) or ".", exist_ok=True)
        if isinstance(content, (bytes, bytearray)):
            with open(full, "wb") as fh:
                fh.write(content)
        else:
            with open(full, "w", encoding="utf-8") as fh:
                fh.write(content)

    async def delete(self, path) -> None:
        try:
            os.remove(os.path.join(workspace_path(), path))
        except FileNotFoundError:
            pass


class _CellStore(_FileEndpoint):
    """The cell as the user sees it in the Files tab: the committed version tip
    overlaid with pending Files-tab drafts (a host read), written back via
    ``update_file`` + a single ``update()`` flush per tick."""

    label = "cell"

    def __init__(self):
        self._cache: dict = {}

    async def hashes(self) -> dict:
        loop = asyncio.get_event_loop()
        # raise_on_error=True: a transient host/DB read failure must PROPAGATE
        # (so _Mirror._tick skips this pass) rather than return {} — an empty
        # result that looks like "the cell has no files" would make the engine
        # treat every synced file as deleted and remove it. See _Mirror._tick.
        self._cache = await loop.run_in_executor(
            None, lambda: _require_bridge().read_cell_files(raise_on_error=True))
        return {p: _content_hash(c) for p, c in self._cache.items()}

    async def read(self, path):
        if path in self._cache:
            return self._cache[path]
        return read_file(path)  # already on disk in our workspace

    async def write(self, path, content) -> None:
        update_file(path, content)

    async def delete(self, path) -> None:
        # NO has_file() guard: has_file checks the WORKSPACE, but in the
        # workspace→cell delete path the file is already gone from the workspace
        # (that's why it's being deleted), so the guard would always be False and
        # the deletion would never be staged — the cell would keep the file and
        # resurrect it next tick. delete_file/fs_unlink no-ops harmlessly when
        # the workspace file is absent and records tracked_deletions, which is
        # exactly what the next update() flush needs to drop it from the cell.
        delete_file(path)

    async def commit(self) -> None:
        await update()


class _ChildWorkspace(_FileEndpoint):
    """A child sub-run's workspace, reached over its handle."""

    label = "child"

    def __init__(self, handle):
        self._h = handle

    async def hashes(self) -> dict:
        return await self._h.snapshot()

    async def read(self, path):
        return await self._h.read_file(path)

    async def write(self, path, content) -> None:
        await self._h.write_file(path, content)

    async def delete(self, path) -> None:
        await self._h.delete_file(path)


class _Mirror:
    """Bidirectional, echo-suppressed sync between two :class:`_FileEndpoint`\\ s,
    run for the lifetime of an ``async with`` block.

    One reconcile pass per ``interval``: each path is compared on both sides
    against a shared ``path -> sha256`` map. Whichever side changed relative to
    the last sync is propagated to the other and re-recorded, so a value can't
    ping-pong. The ``local`` (left) side wins a genuine simultaneous edit;
    ``to_remote``/``from_remote`` gate the two directions. A ``guard`` callable
    (host present? child alive?) makes the whole thing a clean no-op in dev
    mode. A final reconcile on exit captures a write landing after the last
    tick."""

    def __init__(self, local, remote, *, to_remote=True, from_remote=True,
                 exclude=(), interval=0.5, guard=None):
        self._a = local
        self._b = remote
        self._a_to_b = bool(to_remote)
        self._b_to_a = bool(from_remote)
        self._exclude = tuple(exclude)
        self._interval = max(0.1, float(interval))
        self._synced: dict = {}
        self._task = None
        self._stopped = False
        self._guard = guard

    async def __aenter__(self) -> "_Mirror":
        if self._guard is not None and not self._guard():
            return self  # no host / dead child — nothing to mirror
        # Seed the echo map from the already-identical files on both sides so
        # seeded inputs aren't redundantly re-pushed on the first tick.
        try:
            a0, b0 = await self._a.hashes(), await self._b.hashes()
            for p in set(a0) & set(b0):
                if a0[p] == b0[p]:
                    self._synced[p] = a0[p]
        except Exception:
            pass
        self._task = asyncio.ensure_future(self._loop())
        return self

    async def _loop(self) -> None:
        try:
            while not self._stopped and not _require_bridge().cancelled:
                await asyncio.sleep(self._interval)
                if self._stopped:
                    break
                try:
                    await self._tick()
                except asyncio.CancelledError:
                    raise
                except Exception:
                    pass  # transient read race / host hiccup — retry next tick
        except asyncio.CancelledError:
            raise
        except Exception:
            pass

    async def _tick(self) -> None:
        a_h = await self._a.hashes()
        b_h = await self._b.hashes()
        # Transient-empty guard. If we already have synced state but one side now
        # reports ZERO files, that is almost always a raced/failed snapshot, not
        # a real wipe — propagating it would mass-delete the other side. Skip the
        # whole reconcile this tick rather than destroy files. (_CellStore.hashes
        # RAISES on a host read error so it can't reach here as a silent {}; this
        # guards the workspace/child snapshot paths, which can momentarily read
        # empty. A genuine "user emptied the cell" is left for them to re-trigger
        # — never inferred from an empty read.)
        if self._synced and (not a_h or not b_h):
            return
        a_dirty = b_dirty = False
        for p in set(a_h) | set(b_h) | set(self._synced):
            if _mirror_skip(p, self._exclude):
                continue
            try:
                ah, bh, sh = a_h.get(p), b_h.get(p), self._synced.get(p)
                if ah == bh:
                    # Already in sync (or gone from both) — record / forget it.
                    self._synced.pop(p, None) if ah is None else self._synced.__setitem__(p, ah)
                    continue
                if ah != sh and self._a_to_b:          # left changed → push to right
                    if ah is None:
                        await self._b.delete(p)
                        self._synced.pop(p, None)
                    else:
                        await self._b.write(p, await self._a.read(p))
                        self._synced[p] = ah
                    b_dirty = True
                elif bh != sh and self._b_to_a:        # right changed → push to left
                    if bh is None:
                        await self._a.delete(p)
                        self._synced.pop(p, None)
                    else:
                        await self._a.write(p, await self._b.read(p))
                        self._synced[p] = bh
                    a_dirty = True
            except Exception:
                # One racing path (a file read mid-write, a transient unlink)
                # must not abort the whole reconcile or skip the commit for the
                # paths that already synced this tick.
                continue
        if b_dirty:
            await self._b.commit()
        if a_dirty:
            await self._a.commit()

    async def __aexit__(self, *exc) -> None:
        self._stopped = True
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass
        # Final reconcile so a write between the last tick and teardown is kept.
        try:
            await self._tick()
        except Exception:
            pass


def live_files(
    *,
    to_cell: bool = True,
    from_cell: bool = True,
    exclude: tuple = (),
    interval: float = 0.5,
    skip_dirs: Optional[set] = None,
) -> _Mirror:
    """Keep this run's workspace and its cell (the Files tab) in live,
    **bidirectional** sync for the lifetime of an ``async with`` block — the
    one-liner that makes a ``live_files`` generator foolproof::

        async with gen.live_files():
            term = await gen.terminal(...)          # or any daemon
            gen.update_file("app.terminal", ptr)
            await gen.update(pinned="app.terminal")
            await gen.wait_until_cancelled()

    While the block is open, files the run writes to its workspace appear in the
    cell live (``to_cell``) and the user's Files-tab edits are written into the
    workspace the run reads (``from_cell``). The two directions are
    echo-suppressed, the workspace wins a genuine simultaneous edit, and a final
    reconcile on exit captures a last-moment write.

    Set ``live_files_mode: "auto"`` in the manifest to have the runtime open
    this for the whole run with zero code; use ``"manual"`` + this call when you
    need custom ``exclude`` globs or a one-way mirror. No-op without a host."""
    sd = set(skip_dirs) if skip_dirs is not None else _LIVE_SKIP_DIRS
    return _Mirror(
        _LocalWorkspace(sd), _CellStore(),
        to_remote=to_cell, from_remote=from_cell,
        exclude=tuple(exclude), interval=interval,
        guard=_has_host,
    )


def _has_host() -> bool:
    """True when a real host IPC channel is wired (so the mirror should run)."""
    try:
        bridge = _require_bridge()
    except Exception:
        return False
    return getattr(bridge, "_sock_wfile", None) is not None


def spawn(
    source,
    *,
    inputs: Optional[dict] = None,
    input_groups: Optional[dict] = None,
    prompt: str = "",
    invocation_type: str = "create",
    config: Optional[dict] = None,
    secrets: Optional[list] = None,
    surface=None,
) -> GeneratorHandle:
    """Start a child generator as a parent-bound sub-run and return a live
    handle immediately. Works for terminating AND daemon children. Invisible
    unless ``surface=`` is given. ``source`` is an installed generator id or
    a :func:`inline` candidate."""
    bridge = _require_bridge()
    surface_d = surface._to_dict() if isinstance(surface, SurfaceSpec) else surface
    sub_run_id = bridge.start_sub_run(
        _source_payload(source),
        inputs=inputs, input_groups=input_groups, prompt=prompt,
        invocation_type=invocation_type, config=config, secrets=secrets,
        surface=surface_d,
    )
    return GeneratorHandle(bridge, sub_run_id, source)


async def call(
    source,
    *,
    inputs: Optional[dict] = None,
    input_groups: Optional[dict] = None,
    prompt: str = "",
    invocation_type: str = "create",
    config: Optional[dict] = None,
    secrets: Optional[list] = None,
    timeout: Optional[float] = 300.0,
) -> GeneratorResult:
    """Sugar for the terminating case — spawn, wait, stop. Child failure
    returns ``ok=False`` (call :meth:`GeneratorResult.raise_for_status` to
    opt into raising). Do NOT ``call()`` a daemon (it never completes) —
    ``spawn()`` it and read :meth:`GeneratorHandle.endpoints`.

    Agent-tool twin (the same act as a live chat tool): ``call_generator``.
    """
    handle = spawn(
        source, inputs=inputs, input_groups=input_groups, prompt=prompt,
        invocation_type=invocation_type, config=config, secrets=secrets,
    )
    try:
        return await handle.wait(timeout=timeout)
    finally:
        # Best-effort teardown — must never replace an in-flight exception
        # (e.g. a broken-socket emit during stop).
        try:
            await handle.stop()
        except Exception:
            pass


async def call_many(
    specs,
    *,
    timeout: Optional[float] = 600.0,
    poll_interval: float = 0.4,
    max_concurrent: Optional[int] = None,
) -> list["GeneratorResult"]:
    """Run N terminating sub-runs **concurrently** — one :class:`GeneratorResult`
    per spec, in the order given.

    Each ``spec`` is a mapping of :func:`spawn` keyword arguments and MUST carry
    a ``"source"`` (an installed generator id or an :func:`inline` candidate)::

        results = await gen.call_many([
            {"source": "agent", "prompt": p1, "config": cfg},
            {"source": "agent", "prompt": p2, "config": cfg},
        ])

    **Why this exists (do not hand-roll it):** ``asyncio.gather(gen.call(...),
    gen.call(...))`` does NOT parallelize — each :func:`call`'s ``wait`` holds
    the bridge's single IPC transaction lock for the child's entire runtime, so
    the children run one-at-a-time and the event loop stalls. ``call_many``
    spawns every child first (quick transactions — the host runs them
    concurrently) and then *polls* to completion (cheap status checks that don't
    hold the lock), so wall-clock ≈ the slowest child, not the sum.

    Contract:

    * **Per-item isolation** — a child that fails or times out, or a spec that
      can't be spawned, comes back as ``GeneratorResult(ok=False, error=...)``.
      The call itself never raises for a single bad child; filter on ``.ok``.
    * ``timeout`` bounds the whole batch's wall-clock (``None`` waits forever).
    * ``max_concurrent`` caps how many run at once (a spawn window); ``None``
      launches them all together. Use it to stay under host limits for large
      fan-outs.
    * **Honors a stop** — when the run is cancelled mid-batch, the remaining
      children are stopped and :class:`Cancelled` is raised (so the caller
      unwinds instead of paying for the rest).
    """
    import time as _time

    specs = list(specs)
    n = len(specs)
    results: list = [None] * n
    if n == 0:
        return results
    bridge = _require_bridge()
    limit = max_concurrent if (max_concurrent and 0 < max_concurrent < n) else n
    sem = asyncio.Semaphore(limit)
    handles: dict = {}
    deadline = None if timeout is None else _time.monotonic() + timeout

    async def _worker(i: int, spec: dict) -> None:
        async with sem:
            if bridge.cancelled:
                results[i] = GeneratorResult(ok=False, error="stopped by user")
                return
            spec = dict(spec)
            source = spec.pop("source", None)
            if source is None:
                results[i] = GeneratorResult(
                    ok=False, error="call_many spec is missing 'source'")
                return
            try:
                h = spawn(source, **spec)
            except Exception as e:  # noqa: BLE001 — per-item isolation
                results[i] = GeneratorResult(ok=False, error=str(e))
                return
            handles[i] = h
            while True:
                if bridge.cancelled:
                    results[i] = GeneratorResult(ok=False, error="stopped by user")
                    return
                try:
                    st = await h.status()
                    if st in ("done", "failed"):
                        # The child is terminal — wait() returns promptly (holds
                        # the lock only for that brief final read).
                        results[i] = await h.wait(timeout=10)
                        return
                except IPCError as e:
                    # A transient IPC fault on ONE child's poll must not abort
                    # the batch — per-item isolation (the contract). Convert to
                    # an ok=False result for this item and move on.
                    results[i] = GeneratorResult(ok=False, error=f"IPC fault: {e}")
                    return
                if deadline is not None and _time.monotonic() > deadline:
                    results[i] = GeneratorResult(
                        ok=False, error=f"sub-run timed out after {timeout:.0f}s")
                    return
                await asyncio.sleep(poll_interval)

    try:
        await asyncio.gather(*(_worker(i, s) for i, s in enumerate(specs)))
    finally:
        for h in handles.values():
            try:
                await h.stop()
            except Exception:  # noqa: BLE001 — teardown is best-effort
                pass
    if bridge.cancelled:
        raise Cancelled("stopped during call_many")
    return results


def check_renderer(files: dict, *, entrypoint: str) -> RendererCheck:
    """Compile-check a renderer via the host's esbuild — a public capability
    any generator can call (the renderer-builder uses exactly this). Returns
    ``ok=False`` with a diagnostic in dev mode (no host).

    Agent-tool twin (the same act as a live chat tool): ``check_renderer``.
    """
    ack = _require_bridge().check_renderer(dict(files), entrypoint)
    return RendererCheck(
        ok=bool(ack.get("ok", False)),
        errors=list(ack.get("errors") or []),
        warnings=list(ack.get("warnings") or []),
    )


# ──────────────────────────────────────────────────────────────────────
# Cross-cell read / write — introspect and edit OTHER generators' source.
#
# Gated entirely on cell exposure: a generator may read or write only cells
# the user marked "expose to generators" (generator- AND renderer-source
# cells). Every write_cell lands as a normal, undoable cell VERSION and takes
# effect on the target cell's next run. Host-backed; dev-mode safe (no host →
# empty / no-op). Distinct from read_cell_files/update_cell, which only ever
# touch THIS run's own cell.
# ──────────────────────────────────────────────────────────────────────


def exposed_cells() -> list:
    """List the source cells currently exposed to generators in this channel —
    the cells you may :func:`read_cell` / :func:`write_cell`. Each entry is a
    dict ``{cell_id, name, stack_type, generators: [id], files: [path]}``.
    ``[]`` in dev mode.

    Agent-tool twin (the same act as a live chat tool): ``list_exposed_cells``.
    """
    return list(_require_bridge().list_exposed_cells())


def read_cell(cell_id: str) -> dict:
    """Return the full file tree of an exposed cell as ``{path: str | bytes}``
    (its current/visible state — the same files a run of that cell sees).

    Raises ``PermissionError`` if the cell is not exposed and ``LookupError``
    if it does not exist. ``{}`` in dev mode (no host).

    Agent-tool twin (the same act as a live chat tool): ``read_other_cell``.
    """
    return dict(_require_bridge().read_cell(cell_id))


def write_cell(
    cell_id: str,
    files: dict,
    *,
    summary: Optional[str] = None,
    deleted: Optional[list] = None,
) -> str:
    """Commit a new VERSION of an exposed cell from a partial overlay.

    ``files`` (``{path: str | bytes}``) is merged over the cell's current
    files; ``deleted`` lists paths to drop. The edit is recorded as an
    undoable cell version (``source_type='generator_edit'``, visible in the
    cell's history scrubber) AND applied to the cell's live state, so it takes
    effect on that cell's next run. Returns the new version id.

    Raises ``PermissionError`` when the cell is not exposed and ``ValueError``
    when an included ``manifest.gen_yaml`` fails lint. Returns ``""`` in dev
    mode.

    Agent-tool twin (the same act as a live chat tool): ``write_other_cell``.
    """
    return _require_bridge().write_cell(
        cell_id,
        dict(files),
        summary=summary,
        deleted=list(deleted) if deleted else None,
    )


def _find_manifest_in_tree(tree: dict, generator_id: str):
    """Locate ``generator_id``'s ``manifest.gen_yaml`` within a read_cell tree.
    Returns ``(path, parsed_dict)`` or raises ``LookupError``."""
    import yaml

    for path, content in tree.items():
        if not path.endswith("manifest.gen_yaml"):
            continue
        text = content.decode("utf-8") if isinstance(content, bytes) else content
        try:
            data = yaml.safe_load(text) or {}
        except Exception:
            continue
        if isinstance(data, dict) and data.get("id") == generator_id:
            return path, data
    raise LookupError(
        f"generator {generator_id!r} has no manifest.gen_yaml in cell tree"
    )


def add_generator(
    cell_id: str,
    *,
    id: str,
    name: str,
    entrypoint: str,
    files: dict,
    summary: str = "",
    type: Optional[list] = None,
    **manifest_fields,
) -> str:
    """Add a NEW generator to an exposed cell and commit a version.

    Writes ``<id>/manifest.gen_yaml`` (built from the given fields) and the
    generator's ``files`` (``{relpath: content}``, rooted at the generator's
    own dir — must include ``entrypoint``) under ``<id>/``. Extra manifest
    fields (``inputs``, ``config_tags``, ``draft_files``, ``prompt_intent``,
    …) pass through ``manifest_fields``. Returns the new version id; raises
    ``ValueError`` if the manifest fails lint.

    Agent-tool twin (the same act as a live chat tool): ``add_generator``.
    """
    import yaml

    manifest = {
        "id": id,
        "name": name,
        "entrypoint": entrypoint,
        "summary": summary,
        "type": list(type or ["create"]),
    }
    manifest.update(manifest_fields)
    overlay = {f"{id}/manifest.gen_yaml": yaml.safe_dump(manifest, sort_keys=False)}
    for rel, content in dict(files).items():
        overlay[f"{id}/{rel}"] = content
    return write_cell(cell_id, overlay, summary=summary or f"Add generator {id!r}")


def add_renderer(
    cell_id: str,
    *,
    id: str,
    name: str,
    entrypoint: str,
    files: dict,
    summary: str = "",
    extensions: Optional[list] = None,
    **manifest_fields,
) -> str:
    """Add a NEW renderer to an exposed (renderer-source) cell and commit a
    version — the renderer twin of :func:`add_generator`.

    Writes ``<id>/manifest.rend_yaml`` (built from the given fields) and the
    renderer's ``files`` (``{relpath: content}``, rooted at the renderer's own
    dir — must include ``entrypoint``) under ``<id>/``. ``extensions`` is the
    list of file extensions the renderer handles (each must start with ``.``);
    extra manifest fields (``embed``, ``supports_diff``, …) pass through
    ``manifest_fields``. Returns the new version id; raises ``ValueError`` if
    the manifest fails lint.

    Agent-tool twin (the same act as a live chat tool): ``add_renderer``.
    """
    import yaml

    manifest = {
        "id": id,
        "name": name,
        "entrypoint": entrypoint,
        "summary": summary,
    }
    if extensions:
        manifest["extensions"] = list(extensions)
    manifest.update(manifest_fields)
    overlay = {f"{id}/manifest.rend_yaml": yaml.safe_dump(manifest, sort_keys=False)}
    for rel, content in dict(files).items():
        overlay[f"{id}/{rel}"] = content
    return write_cell(cell_id, overlay, summary=summary or f"Add renderer {id!r}")


def create_generator_cell(
    name: str,
    *,
    files: dict,
    summary: Optional[str] = None,
    pinned: Optional[str] = None,
) -> str:
    """Create a brand-new GENERATOR source cell in the channel's generator
    stack and return its cell id.

    ``files`` is the cell's full file tree (``{path: str | bytes}``) and MUST
    contain a valid ``manifest.gen_yaml`` + the entrypoint it names. The new
    cell is committed as its first version, placed in the generator nav stack,
    and **exposed to generators** immediately — so the creating run can turn
    around and :func:`read_cell` / :func:`write_cell` / :func:`add_generator`
    it to iterate.

    A generator is a real program with a contract, not just any cell — the
    intentional act of adding capability. Distinct from :func:`create_stack_cell`,
    which adds an OUTPUT (content) cell to this run's right-side stack. Raises
    ``ValueError`` (illegal path or a missing/invalid manifest). Returns ``""``
    in dev mode (no host).

    Agent-tool twin (the same act as a live chat tool): ``commit_generator``.
    """
    return _require_bridge().create_source_cell(
        "generator", name, dict(files or {}), summary=summary, pinned=pinned,
    )


def create_renderer_cell(
    name: str,
    *,
    files: dict,
    summary: Optional[str] = None,
    pinned: Optional[str] = None,
) -> str:
    """Create a brand-new RENDERER source cell in the channel's renderer stack
    and return its cell id.

    ``files`` is the cell's full file tree (``{path: str | bytes}``) and MUST
    contain a valid ``manifest.rend_yaml`` (declaring the extensions it claims)
    + the entrypoint it names. The new cell is committed as its first version,
    placed in the renderer nav stack, and **exposed to generators** immediately
    — so the creating run can :func:`read_cell` / :func:`write_cell` /
    :func:`add_renderer` it to iterate.

    A renderer is a real component with a contract, not just any cell — the
    intentional act of adding a new way to view a file type. Distinct from
    :func:`create_stack_cell`, which adds an OUTPUT (content) cell to this run's
    right-side stack. Raises ``ValueError`` (illegal path or a missing/invalid
    manifest). Returns ``""`` in dev mode (no host).

    Agent-tool twin (the same act as a live chat tool): ``commit_renderer``.
    """
    return _require_bridge().create_source_cell(
        "renderer", name, dict(files or {}), summary=summary, pinned=pinned,
    )


def set_config_tag(
    cell_id: str,
    generator_id: str,
    tag: str,
    body: dict,
    *,
    summary: Optional[str] = None,
) -> str:
    """Add or replace one config tag in ``generator_id``'s manifest within an
    exposed cell, committing a version. ``body`` is the tag mapping
    (``{prompt?, files?}``). Returns the new version id."""
    import yaml

    tree = read_cell(cell_id)
    mpath, manifest = _find_manifest_in_tree(tree, generator_id)
    tags = dict(manifest.get("config_tags") or {})
    tags[tag] = body
    manifest["config_tags"] = tags
    return write_cell(
        cell_id,
        {mpath: yaml.safe_dump(manifest, sort_keys=False)},
        summary=summary or f"Set config tag {tag!r} on {generator_id!r}",
    )


def delete_config_tag(
    cell_id: str,
    generator_id: str,
    tag: str,
    *,
    summary: Optional[str] = None,
) -> str:
    """Remove one config tag from ``generator_id``'s manifest within an
    exposed cell, committing a version. Raises ``KeyError`` if the tag is
    absent. Returns the new version id."""
    import yaml

    tree = read_cell(cell_id)
    mpath, manifest = _find_manifest_in_tree(tree, generator_id)
    tags = dict(manifest.get("config_tags") or {})
    if tag not in tags:
        raise KeyError(f"config tag {tag!r} not found on {generator_id!r}")
    del tags[tag]
    manifest["config_tags"] = tags
    return write_cell(
        cell_id,
        {mpath: yaml.safe_dump(manifest, sort_keys=False)},
        summary=summary or f"Delete config tag {tag!r} from {generator_id!r}",
    )


# ──────────────────────────────────────────────────────────────────────
# Environments — the environment-author side. A daemon generator that owns a
# runtime calls serve_environment(...) to field its parent's exec/file/port
# requests (the typed twins of the surfaces a human drives on the cell). The
# Docker boilerplate + default handlers live in the generators' _env_shared
# raw runtime primitive the helper fills. Dev-mode safe: with no host, the
# poll yields nothing and the loop idles until Stop (it is a daemon).
# ──────────────────────────────────────────────────────────────────────


_EXEC_OUTPUT_CAP = 8_000_000  # keep a routed reply under the host's 10MB IPC frame limit


async def _maybe_await(fn, request):
    # Run the handler in a worker thread: a sync handler (e.g. a blocking
    # docker exec, or wait_process polling) must not freeze the serve-loop
    # event thread. An async handler just builds its coroutine off-thread (cheap)
    # and is awaited back on the loop.
    loop = asyncio.get_event_loop()
    res = await loop.run_in_executor(None, lambda: fn(request))
    if asyncio.iscoroutine(res):
        return await res
    return res


def _normalize_exec_result(res) -> tuple:
    """Coerce an on_exec handler's return to ``(rc, output)``."""
    if isinstance(res, tuple) and len(res) == 2:
        rc, output = res
        return int(rc), _as_text(output)
    if isinstance(res, dict):
        return int(res.get("rc", 0)), _as_text(res.get("output", ""))
    return 0, _as_text(res)


def _as_text(v) -> str:
    if isinstance(v, bytes):
        return v.decode("utf-8", errors="replace")
    return "" if v is None else str(v)


def _endpoint_payload(res, *, default_port=None) -> dict:
    if isinstance(res, Endpoint):
        return {"kind": res.kind, "name": res.name, "url": res.url,
                "port": res.port, "path": res.path, "session_id": res.session_id}
    if isinstance(res, dict):
        return res
    if isinstance(res, str):
        return {"kind": "http", "url": res, "port": default_port}
    return {"kind": "http", "port": default_port}


async def serve_environment(
    *,
    on_exec=None,
    on_exec_background=None,
    on_expose_port=None,
    on_terminal=None,
    on_wait_process=None,
    on_stop_process=None,
    max_concurrency: int = 1,
) -> None:
    """Serve parent requests against this run's runtime until Stop.

    Register the handlers your environment supports; each receives a typed
    :class:`Request` and **returns** its result (the loop sends the reply):

    - ``on_exec(req) -> (rc, output)`` — run ``req.command``, one-shot.
    - ``on_exec_background(req) -> process_id`` — start a long-running process.
    - ``on_wait_process(req) -> rc`` / ``on_stop_process(req)`` — its lifecycle.
    - ``on_expose_port(req) -> Endpoint | url | dict`` — expose ``req.port``.
    - ``on_terminal(req) -> {session_id, ws_path, token}`` — open a PTY.

    Handlers may be sync or async (sync ones run in a worker thread). Blocks
    until the user clicks Stop. Each request is dispatched as its own task so a
    long ``wait_process`` never blocks a subsequent ``stop_process`` (the two are
    a lifecycle pair); the serve loop is the *only* IPC user (poll + replies),
    so the per-bridge IPC lock never starves replies. The
    ``_env_shared.DockerEnvironment`` helper (shared generator code) fills these
    from a container, so most environments never call this directly.
    """
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    spec = {
        "exec": on_exec is not None,
        "exec_background": on_exec_background is not None,
        "expose_port": on_expose_port is not None,
        "terminals_handler": on_terminal is not None,
    }
    await loop.run_in_executor(None, lambda: bridge.serve_environment_register(spec))

    handlers = {
        "exec": on_exec,
        "exec_background": on_exec_background,
        "wait_process": on_wait_process,
        "stop_process": on_stop_process,
        "expose_port": on_expose_port,
        "open_terminal": on_terminal,
    }

    reply_q: "asyncio.Queue" = asyncio.Queue()
    pending: set = set()

    async def _handle(request: dict) -> None:
        result = await _compute_env_result(request, handlers)
        await reply_q.put((request.get("request_id", ""), result))

    try:
        while not bridge.cancelled:
            # Flush ready replies first (the loop is the sole IPC user, so poll
            # and reply never race for the IPC lock).
            while not reply_q.empty():
                rid, result = reply_q.get_nowait()
                await loop.run_in_executor(
                    None, lambda rid=rid, result=result: bridge.serve_environment_reply(rid, result)
                )
            # Short poll so replies/cancellation cycle within ~1s.
            req = await loop.run_in_executor(None, lambda: bridge.serve_environment_poll(1.0))
            if not req:
                continue
            t = asyncio.ensure_future(_handle(req))
            pending.add(t)
            t.add_done_callback(pending.discard)
    finally:
        # Give in-flight handlers a short grace to finish + flush their replies,
        # then cancel any that are still blocked (e.g. a forever wait_process).
        if pending:
            await asyncio.wait(list(pending), timeout=2.0)
        while not reply_q.empty():
            rid, result = reply_q.get_nowait()
            try:
                await loop.run_in_executor(
                    None, lambda rid=rid, result=result: bridge.serve_environment_reply(rid, result)
                )
            except Exception:
                pass
        for t in list(pending):
            t.cancel()


async def _compute_env_result(req: dict, handlers: dict) -> dict:
    kind = req.get("kind", "")
    r = Request(
        kind=kind,
        command=req.get("command"),
        cwd=req.get("cwd", "") or "",
        env=req.get("env") or {},
        port=req.get("port"),
        process_id=req.get("process_id"),
        timeout=req.get("timeout"),
    )
    fn = handlers.get(kind)
    try:
        if fn is None:
            return {"ok": False, "error": f"environment does not serve {kind!r}"}
        if kind == "exec":
            rc, output = _normalize_exec_result(await _maybe_await(fn, r))
            if len(output) > _EXEC_OUTPUT_CAP:  # keep the reply under the IPC frame limit
                output = output[:_EXEC_OUTPUT_CAP] + "\n[output truncated]"
            return {"ok": True, "rc": rc, "output": output}
        if kind == "exec_background":
            return {"ok": True, "process_id": str(await _maybe_await(fn, r) or "")}
        if kind == "wait_process":
            return {"ok": True, "rc": int(await _maybe_await(fn, r) or 0)}
        if kind == "stop_process":
            await _maybe_await(fn, r)
            return {"ok": True}
        if kind == "expose_port":
            return {"ok": True, "endpoint": _endpoint_payload(await _maybe_await(fn, r), default_port=r.port)}
        if kind == "open_terminal":
            sess = await _maybe_await(fn, r)
            return {"ok": True, **(dict(sess) if isinstance(sess, dict) else {})}
        return {"ok": False, "error": f"unknown request kind {kind!r}"}
    except Exception as exc:  # a failing handler must not kill the serve loop
        return {"ok": False, "error": str(exc)}


async def _run_with_auto_live_files(run_fn) -> None:
    """Dispatch an async ``run()``, wrapping it in a default :func:`live_files`
    mirror when the manifest asked for it via ``live_files_mode: "auto"`` (the
    host passes the mode through ``COLLIMATE_LIVE_FILES_MODE``). ``"manual"`` /
    unset leaves the generator to manage its own sync."""
    if os.environ.get("COLLIMATE_LIVE_FILES_MODE", "").strip().lower() == "auto" and _has_host():
        async with live_files():
            await run_fn()
    else:
        await run_fn()


def main(run_fn) -> None:
    """Run a generator's ``run`` function under the singleton API.

    Construct the IPC bridge, hydrate the singleton, dispatch ``run_fn``
    (sync or async), auto-flush any pending writes to the cell, and emit
    the finish IPC. Catches :class:`Cancelled` and :class:`_StopRequested`
    as graceful stop; every other exception is reported via the run's error
    channel.

    **Auto-flush**: if ``run_fn`` returns cleanly with files written via
    :func:`update_file` (including the ``.chatlog`` transcript) but never
    called :func:`update`, this commits them as the final cell state.
    Generators that explicitly want an empty placeholder simply don't write
    anything — same as before.
    """
    bridge = HostBridge()
    _set_bridge(bridge)
    try:
        if asyncio.iscoroutinefunction(run_fn):
            asyncio.run(_run_with_auto_live_files(run_fn))
        else:
            # A sync generator can't host the async mirror; auto live_files
            # requires an async run(). It can still call gen.live_files()
            # itself if it has its own loop.
            run_fn()
        if bridge.tracked_writes or bridge.tracked_deletions:
            try:
                deleted = sorted(bridge.tracked_deletions) or None
                bridge.tracked_deletions.clear()
                bridge.update_cell(deleted_files=deleted)
            except Exception:
                bridge.log.exception("auto-flush update_cell failed")
        bridge.finish(success=True)
    except (Cancelled, _StopRequested):
        bridge.log.info("Stopped gracefully by user.")
        bridge.finish(success=False, error_message="Stopped by user")
    except Exception as exc:
        if bridge.cancelled:
            # A graceful stop's SIGTERM goes to the whole process group, so a
            # child (e.g. the claude CLI) can die first and its error surface
            # before any gen.* checkpoint raises Cancelled. Once the cancel
            # flag is set, ANY exception is the stop unwinding — report it as
            # the user's stop, not a generator failure with a traceback.
            bridge.log.info("Stopped gracefully by user.")
            bridge.finish(success=False, error_message="Stopped by user")
        else:
            bridge.log.exception("Generator failed")
            bridge.finish(success=False, error_message=str(exc))
    finally:
        _clear_bridge()


__all__ = [
    # Result / spec types (shared with collimate.testing + composition)
    "CellRecord",
    "ConfigField",
    "ConfigTag",
    "DraftFileSchema",
    "Endpoint",
    "EnvironmentSpec",
    "GeneratorInfo",
    "GeneratorResult",
    "RendererCheck",
    "Request",
    # Composition + renderer compile (host-backed; dev-mode safe)
    "GeneratorHandle",
    "ProcessHandle",
    "Source",
    "SurfaceSpec",
    "call",
    "call_many",
    "check_renderer",
    "emit_event",
    "generators",
    "generator_info",
    "tag_config",
    "inline",
    "serve_environment",
    "spawn",
    # Cross-cell read / write (gated on cell exposure; host-backed)
    "exposed_cells",
    "read_cell",
    "write_cell",
    "add_generator",
    "add_renderer",
    "create_generator_cell",
    "create_renderer_cell",
    "set_config_tag",
    "delete_config_tag",
    # Exceptions
    "Cancelled",
    "IPCDisconnectedError",
    "IPCError",
    "IPCNakError",
    "IPCTimeoutError",
    # Inputs / config
    "config",
    "input_files",
    "input_groups",
    "read_input",
    # Output stage
    "delete_file",
    "has_file",
    "list_files",
    "read_file",
    "update_file",
    # Cell ops
    "create_stack_cell",
    "start_modify_run",
    "update",
    # Chat
    "ChatTurn",
    "emit_stream_event",
    "history",
    "serve_chat",
    # Secrets
    "api_key",
    "secret",
    # Status / control
    "log",
    "phase",
    "progress",
    "status",
    # Native filesystem / subprocess / ports / terminals
    "actions",
    "request_settings",
    "run_subprocess",
    "serve_port",
    "serve_terminal",
    "snapshot",
    "stop_terminal",
    "terminal",
    "wait_for_action",
    "wait_until_cancelled",
    "workspace_path",
    # Live file sync (cell <-> workspace; mirror_files is on the handle)
    "live_files",
    # Entrypoint
    "main",
]
