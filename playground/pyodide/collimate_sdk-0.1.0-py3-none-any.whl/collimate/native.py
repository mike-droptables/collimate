# SPDX-License-Identifier: Apache-2.0
"""Singleton runtime API for native (Standard) generators.

A generator script imports the top-level :mod:`gen` package — a thin
runtime-aware shim that re-exports from this module under native and
from :mod:`collimate.wasm` under pyodide. The shape is the same on both
runtimes for **Tier A** symbols; **Tier B** symbols (terminals, ports,
subprocess streaming, raw filesystem access, snapshot, settings modal,
action polling, container-backed chat sessions, IPC error types) are
native-only.

Entrypoint contract::

    import gen

    async def run():
        gen.update_file("output.md", "...")
        await gen.update(summary="hello")

    if __name__ == "__main__":
        gen.main(run)

``gen.main`` constructs a single :class:`collimate._host.HostBridge`
(IPC + signal handling + filesystem + state tracking), hydrates the
singleton, dispatches ``run_fn`` (sync or async), and emits the finish
IPC on the way out.

Two tiers:

  * **Tier A** (portable; mirrors :mod:`collimate.wasm` 1:1): inputs,
    file I/O, cells, user input, secrets, status, agent / file_tools.
    A generator using only Tier A is runtime-portable — flip
    ``runtime:`` in the manifest and it runs on the other backend
    unchanged.
  * **Tier B** (native-only): real filesystem path, subprocess
    streaming, port binding, terminals, settings modal, action polling,
    snapshot diffing, container-backed chat sessions, IPC error types.
    Generators that use Tier B declare ``runtime: native``.

Cell operations are deliberately limited to two:

  * :func:`update` flushes any staged file writes (and dirty chat
    history) to the placeholder/top cell. May be called many times
    during a run; the last call before return is the final state.
  * :func:`create_stack_cell` adds a new cell below in the right-side
    stack. Used by fan-out generators.

Calling ``update_file`` without ever calling ``update`` produces an
empty placeholder — explicit by design.
"""
from __future__ import annotations

from typing import Any, AsyncIterator, Iterator, Optional
import asyncio
import os

from collimate._host import (
    HostBridge,
    IPCDisconnectedError as _IPCDisconnectedError,
    IPCError as _IPCError,
    IPCNakError as _IPCNakError,
    IPCTimeoutError as _IPCTimeoutError,
    Message,
    _StopRequested,
)


# ──────────────────────────────────────────────────────────────────────
# Module-level singleton state.
#
# ``_set_bridge()`` (called by :func:`main`) stores the live
# :class:`HostBridge`. Generators read/write through the public
# ``gen.*`` functions; they never touch ``_bridge`` directly.
# ──────────────────────────────────────────────────────────────────────

_bridge: Optional[HostBridge] = None


# ──────────────────────────────────────────────────────────────────────
# Public exception types (Tier A / Tier B)
# ──────────────────────────────────────────────────────────────────────


class Cancelled(Exception):
    """Raised when the user cancels a modal (api_key, secret, settings)
    or stops the run while ``chat_loop`` is awaiting a message.

    Same exception identity as :class:`collimate.wasm.Cancelled` so a
    Tier-A-only generator catches the same type on both runtimes.
    """


# Tier B re-exports (raise under WASM via the shim in `gen/__init__.py`).
IPCError = _IPCError
IPCNakError = _IPCNakError
IPCTimeoutError = _IPCTimeoutError
IPCDisconnectedError = _IPCDisconnectedError


# ──────────────────────────────────────────────────────────────────────
# Runner / lifecycle hooks
# ──────────────────────────────────────────────────────────────────────


def _set_bridge(bridge: HostBridge) -> None:
    """Hydrate the singleton with a live :class:`HostBridge`."""
    global _bridge
    _bridge = bridge


def _clear_bridge() -> None:
    global _bridge
    _bridge = None


def _require_bridge() -> HostBridge:
    if _bridge is None:
        raise RuntimeError(
            "gen.* used outside a generator run "
            "(call gen.main(run) at the entrypoint)"
        )
    return _bridge


# ──────────────────────────────────────────────────────────────────────
# Module-level dynamic attributes
#
# ``gen.prompt`` / ``gen.messages`` / ``gen.cancelled`` resolve against
# the current run's bridge. PEP 562 ``__getattr__`` at module level.
# ──────────────────────────────────────────────────────────────────────


def __getattr__(name: str) -> Any:
    if name == "prompt":
        return _require_bridge().prompt
    if name == "messages":
        return list(_require_bridge().chat_history())
    if name == "cancelled":
        return _require_bridge().cancelled
    raise AttributeError(f"module 'collimate.native' has no attribute {name!r}")


# ──────────────────────────────────────────────────────────────────────
# Tier A — Inputs
# ──────────────────────────────────────────────────────────────────────


def read_input(path: str) -> str:
    """Read a file from the input/parent cell workspace."""
    return _require_bridge().fs_read(path)


def input_files() -> dict[str, str]:
    """Return every input-cell file as ``{relpath: content}``.

    Files that fail to read are silently skipped.
    """
    bridge = _require_bridge()
    out: dict[str, str] = {}
    for p in bridge.fs_list():
        try:
            out[p] = bridge.fs_read(p)
        except OSError:
            continue
    return out


def input_groups() -> dict[str, dict[str, str]]:
    """Return input files grouped by source cell.

    For multi-cell input (workspace hydrated as ``inputs/NN_slug/...``),
    each top-level subfolder under ``inputs/`` becomes one group; paths
    in each group are **relative to the cell root** so callers can
    re-emit them verbatim.

    For single-cell input (files at workspace root), returns one group
    keyed ``"input"`` with the original paths.
    """
    bridge = _require_bridge()
    all_paths = bridge.fs_list()
    inputs_prefix = "inputs/"
    under_inputs = [p for p in all_paths if p.startswith(inputs_prefix)]
    if not under_inputs:
        if not all_paths:
            return {}
        single: dict[str, str] = {}
        for p in all_paths:
            try:
                single[p] = bridge.fs_read(p)
            except OSError:
                continue
        return {"input": single}

    raw: dict[str, dict[str, str]] = {}
    for p in under_inputs:
        rest = p[len(inputs_prefix):]
        label, _, sub = rest.partition("/")
        if not sub:
            continue
        try:
            content = bridge.fs_read(p)
        except OSError:
            continue
        raw.setdefault(label, {})[sub] = content
    return {label: raw[label] for label in sorted(raw)}


def config(name: str) -> dict:
    """Read a draft file declared in the manifest's ``draft_files``.

    Always returns a dict. ``.set_yaml`` / ``.yaml`` / ``.yml`` parse
    as YAML (with ``fields:`` defaults merged into the ``values:``
    block). ``.json`` parses as JSON. Returns ``{}`` when the file is
    missing or malformed — callers can use ``cfg.get(...)`` without
    try/except.

    For raw text files, use :func:`read_file` instead.
    """
    raw = _require_bridge().config(name)
    return raw if isinstance(raw, dict) else {}


# ──────────────────────────────────────────────────────────────────────
# Tier A — Output stage (workspace filesystem)
# ──────────────────────────────────────────────────────────────────────


def update_file(path: str, content: str) -> None:
    """Stage a write to the output cell's file at ``path``.

    Writes immediately to the workspace (so subprocesses see it) and
    marks the path for inclusion in the next :func:`update` flush.
    Multiple writes overwrite — last write wins.
    """
    _require_bridge().fs_write(path, content)


def read_file(path: str) -> str:
    """Read from the output stage. Raises :class:`FileNotFoundError`
    when the path is missing."""
    bridge = _require_bridge()
    if not bridge.fs_exists(path):
        raise FileNotFoundError(path)
    return bridge.fs_read(path)


def has_file(path: str) -> bool:
    """Predicate over the output stage."""
    return _require_bridge().fs_exists(path)


def list_files() -> list[str]:
    """Sorted list of every staged file's relative path."""
    return sorted(_require_bridge().fs_list())


def delete_file(path: str) -> None:
    """Drop ``path`` from the output stage. The next :func:`update`
    call passes it as ``deleted_files`` so the host strips it from the
    cell's carried-forward file set."""
    _require_bridge().fs_unlink(path)


# ──────────────────────────────────────────────────────────────────────
# Tier A — Cell operations (two only)
# ──────────────────────────────────────────────────────────────────────


async def update(
    *,
    name: Optional[str] = None,
    summary: Optional[str] = None,
    summary_artifact: Optional[str] = None,
) -> None:
    """Flush the current stage (tracked writes + dirty chat history) to
    the placeholder/top cell.

    May be called many times during a run; each call refreshes the
    visible cell live. The last call before return is the final state.
    **If ``update`` is never called, the placeholder is empty.**
    """
    bridge = _require_bridge()
    deletions = sorted(bridge.tracked_deletions) if bridge.tracked_deletions else None
    bridge.tracked_deletions.clear()

    loop = asyncio.get_event_loop()
    await loop.run_in_executor(
        None,
        lambda: bridge.update_cell(
            name=name,
            summary=summary,
            summary_artifact=summary_artifact,
            deleted_files=deletions,
        ),
    )


async def create_stack_cell(
    name: str,
    *,
    summary: Optional[str] = None,
    summary_artifact: Optional[str] = None,
    files: Optional[dict[str, str]] = None,
) -> str:
    """Add a new cell below in the (right-side) stack.

    If ``files`` is provided, each entry is written first, then the
    side-cell is created with those paths as artifacts. If ``files`` is
    omitted, snapshots whatever is currently tracked.

    Returns the new cell's id.
    """
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        None,
        lambda: bridge.create_side_cell(
            name=name,
            summary=summary,
            summary_artifact=summary_artifact,
            files=files,
        ),
    )


# ──────────────────────────────────────────────────────────────────────
# Tier A — User input mid-run
# ──────────────────────────────────────────────────────────────────────


_POLL_INTERVAL_S = 0.2


async def next_message() -> Optional[str]:
    """Block until the next user message arrives or the run is
    cancelled. Returns the message content, or ``None`` on cancel."""
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    while not bridge.cancelled:
        msg = await loop.run_in_executor(None, bridge.poll_user_message)
        if msg is not None:
            return msg
        await asyncio.sleep(_POLL_INTERVAL_S)
    return None


async def chat_loop(*, seed: bool = True) -> AsyncIterator[str]:
    """Async iterator yielding user messages, turn by turn.

    First iteration yields ``gen.prompt`` (when ``seed`` is True and
    the prompt is non-empty). Subsequent iterations block on
    :func:`next_message`. Exits cleanly when the user clicks Stop.
    """
    bridge = _require_bridge()
    pending: Optional[str] = None
    if seed:
        seed_text = (bridge.prompt or "").strip()
        if seed_text:
            pending = seed_text
    while not bridge.cancelled:
        if pending is None:
            pending = await next_message()
            if pending is None:
                return
        yield pending
        pending = None


# ──────────────────────────────────────────────────────────────────────
# Tier A — Chat history
# ──────────────────────────────────────────────────────────────────────


class _History:
    """Thin wrapper over the workspace's chat history file.

    ``append(role, content)`` mutates the persisted history and marks
    dirty so the next :func:`update` call surfaces the messages-file
    artifact. ``as_pai()`` translates to pydantic_ai ``ModelMessage``.
    """

    def append(self, role: str, content: str) -> None:
        _require_bridge().chat_append(role, content)

    def __iter__(self) -> Iterator[Message]:
        return iter(_require_bridge().chat_history())

    def __len__(self) -> int:
        return len(_require_bridge().chat_history())

    def __getitem__(self, idx):  # type: ignore[no-untyped-def]
        return _require_bridge().chat_history()[idx]

    def as_pai(self) -> list:
        history_list = _require_bridge().chat_history()
        if not history_list:
            return []
        from pydantic_ai.messages import (
            ModelRequest,
            ModelResponse,
            TextPart,
            UserPromptPart,
        )
        out: list = []
        for m in history_list:
            if m.role == "user":
                out.append(ModelRequest(parts=[UserPromptPart(content=m.content or "")]))
            elif m.role == "assistant":
                out.append(ModelResponse(parts=[TextPart(content=m.content or "")]))
        return out


history = _History()


# ──────────────────────────────────────────────────────────────────────
# Tier A — Secrets (two-tier)
# ──────────────────────────────────────────────────────────────────────


# Provider → env var. Pyodide-only providers are excluded from native
# (CORS-locked under the browser, but we'd resolve a key anyway under
# native).
_PROVIDER_KEY_ENV: dict[str, str] = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
    "groq": "GROQ_API_KEY",
    "cerebras": "CEREBRAS_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
    "gemini": "GEMINI_API_KEY",
    "mistral": "MISTRAL_API_KEY",
}


# Per-provider locks coordinate concurrent ``force=True`` retries —
# without them, a parallel ``asyncio.gather`` of N agent calls that
# all auth-fail would pop the modal N times. With the lock, the first
# retry to acquire pops the modal; the rest wait, then read the
# freshly-set env var and skip.
_FORCE_LOCKS: dict[str, asyncio.Lock] = {}


async def api_key(
    provider: str,
    *,
    force: bool = False,
    description: str = "",
) -> str:
    """Resolve the API key for ``provider`` and set the standard env var
    so pydantic_ai's native provider lookup picks it up.

    Fast path: ``os.environ[{PROVIDER}_API_KEY]`` when set and not
    ``force``. Slow path: the in-cell modal. ``force=True`` skips the
    fast path — the auth-retry door after a 401. Concurrent
    ``force=True`` calls for the same provider coordinate behind a
    per-provider lock so only one modal pops per retry burst.

    Raises :class:`Cancelled` when the user cancels the modal.
    """
    bridge = _require_bridge()
    env_name = _PROVIDER_KEY_ENV.get(provider.lower(), "")
    if not env_name:
        raise ValueError(
            f"Unknown provider {provider!r}; expected one of "
            f"{sorted(_PROVIDER_KEY_ENV)}."
        )
    if not force:
        existing = (os.environ.get(env_name) or "").strip()
        if existing:
            return existing

    lock = _FORCE_LOCKS.setdefault(env_name, asyncio.Lock())
    async with lock:
        # Re-check env inside the lock: a concurrent retry may have
        # popped the modal and set it while we were waiting. If the
        # value is fresh (matches what bridge._last_force_ts records)
        # use it instead of re-prompting.
        existing = (os.environ.get(env_name) or "").strip()
        if force and existing and bridge._was_recently_force_set(env_name):
            return existing
        if not force and existing:
            return existing

        msg = description or f"API key for {provider} (used by this generator)"
        loop = asyncio.get_event_loop()
        try:
            value = await loop.run_in_executor(
                None,
                lambda: bridge.get_key(env_name, description=msg, force=force),
            )
        except _StopRequested as exc:
            raise Cancelled(f"key request for {env_name!r} cancelled") from exc
        if value:
            os.environ[env_name] = value
            bridge._mark_force_set(env_name)
        return value


async def secret(
    name: str,
    *,
    prompt_if_missing: bool = False,
    description: str = "",
) -> str:
    """Read a non-LLM secret. Default is the env-var fast path only;
    ``prompt_if_missing=True`` opts into the modal flow."""
    fast = os.environ.get(name)
    if fast:
        return fast
    if not prompt_if_missing:
        return ""
    bridge = _require_bridge()
    msg = description or f"Secret {name}"
    loop = asyncio.get_event_loop()
    try:
        value = await loop.run_in_executor(
            None,
            lambda: bridge.get_key(name, description=msg, force=False),
        )
    except _StopRequested as exc:
        raise Cancelled(f"secret request for {name!r} cancelled") from exc
    if value:
        os.environ[name] = value
    return value


# ──────────────────────────────────────────────────────────────────────
# Tier A — Status / control
# ──────────────────────────────────────────────────────────────────────


def log(line: str) -> None:
    """Append a line to the run log (visible in the events panel)."""
    _require_bridge().push_log(line)


def status(msg: str) -> None:
    """Set the live status string shown next to the run row."""
    _require_bridge().set_status(msg)


# ──────────────────────────────────────────────────────────────────────
# LLM convenience tier
# ──────────────────────────────────────────────────────────────────────


def _build_pydantic_ai_agent(
    *,
    provider: str,
    model: str,
    max_tokens: int,
    system_prompt: str,
    tools: list,
    output_type: Optional[type],
):
    """Construct a vanilla ``pydantic_ai.Agent`` with the given config.
    Used both for the initial build and for the auth-retry rebuild
    inside :class:`_AutoRetryAgent`."""
    from pydantic_ai import Agent
    from pydantic_ai.settings import ModelSettings
    # Translate Collimate's user-facing provider label to pydantic-ai's
    # provider id. ``gemini`` is our canonical label (matching the env
    # var ``GEMINI_API_KEY``), but pydantic-ai uses ``google-gla`` for
    # the free Gemini API.
    pa_provider = "google-gla" if provider == "gemini" else provider
    # pydantic-ai 1.x rejects ``output_type=None`` ("At least one output
    # type must be provided other than `None`"). Omit the kwarg so the
    # library's default (``str``) kicks in for free-text agents.
    extra: dict = {}
    if output_type is not None:
        extra["output_type"] = output_type
    return Agent(
        f"{pa_provider}:{model}",
        system_prompt=system_prompt,
        tools=tools,
        model_settings=ModelSettings(max_tokens=max_tokens),
        **extra,
    )


class _AutoRetryAgent:
    """Wrapper around ``pydantic_ai.Agent`` that retries once on auth
    failure.

    On a 401/403 the wrapper:

      * pops the in-cell key modal via :func:`api_key` with
        ``force=True`` (the modal shows "previous key was rejected");
      * rebuilds the underlying pydantic_ai Agent with the same config
        (so any keys the SDK loaded into the env are picked up);
      * retries the call once.

    ``.run()`` is wrapped directly. ``.run_stream()`` is left passthrough
    — streaming chats use :func:`chat_turn` for retry + chat-stream
    plumbing in one call.

    Power users who need the unwrapped Agent reach via ``.raw``.
    """

    def __init__(
        self,
        *,
        provider: str,
        model: str,
        max_tokens: int,
        system_prompt: str,
        tools: list,
        output_type: Optional[type],
    ) -> None:
        self.provider = provider
        self.model = model
        self._kwargs = dict(
            provider=provider,
            model=model,
            max_tokens=max_tokens,
            system_prompt=system_prompt,
            tools=tools,
            output_type=output_type,
        )
        self.raw = _build_pydantic_ai_agent(**self._kwargs)

    async def _rebuild_after_auth_failure(self) -> None:
        await api_key(
            self.provider,
            force=True,
            description=f"Previous {self.provider} key was rejected. Enter a fresh API key.",
        )
        self.raw = _build_pydantic_ai_agent(**self._kwargs)

    async def run(self, *args, **kwargs):
        from collimate.llm import looks_like_auth_error
        try:
            return await self.raw.run(*args, **kwargs)
        except Exception as exc:
            if not looks_like_auth_error(exc):
                raise
            await self._rebuild_after_auth_failure()
            return await self.raw.run(*args, **kwargs)

    def run_stream(self, *args, **kwargs):
        # Streaming retry needs to coordinate with chat_stream events
        # and cancellation polling — don't try to do it here. Use
        # :func:`chat_turn` for streaming chat with retry. This passes
        # through to vanilla pydantic_ai.run_stream so power users can
        # still drive their own loop.
        return self.raw.run_stream(*args, **kwargs)

    def __getattr__(self, name):
        # Delegate any other attribute (overrides, instructions, …) to
        # the underlying Agent so the wrapper stays transparent.
        return getattr(self.raw, name)


async def agent(
    *,
    system_prompt: str = "",
    tools: Optional[list] = None,
    output_type: Optional[type] = None,
    provider: Optional[str] = None,
    model: Optional[str] = None,
    max_tokens: Optional[int] = None,
    config_file: str = "pydantic-config.set_yaml",
) -> _AutoRetryAgent:
    """Build a configured agent with auto-retry on auth failure.

    Reads ``provider`` / ``model`` / ``max_tokens`` from the generator's
    ``pydantic-config.set_yaml`` when not overridden. Calls :func:`api_key`
    to resolve the key and populate the env var.

    Returns an :class:`_AutoRetryAgent` whose ``.run()`` retries once on
    a 401/403 (via :func:`api_key` with ``force=True``). For streaming
    chat with the same retry behaviour, use :func:`chat_turn` instead of
    driving ``.run_stream()`` yourself.

    The unwrapped ``pydantic_ai.Agent`` is exposed as ``.raw`` for power
    users.
    """
    cfg: dict = {}
    if provider is None or model is None or max_tokens is None:
        cfg = config(config_file)

    p = (provider or cfg.get("provider") or "anthropic").strip().lower()
    m = (model or cfg.get("model") or "claude-sonnet-4-6").strip()
    mt = max_tokens
    if mt is None:
        raw = cfg.get("max_tokens")
        try:
            mt = int(raw)
            if mt <= 0:
                mt = 4096
        except (TypeError, ValueError):
            mt = 4096

    await api_key(p)
    return _AutoRetryAgent(
        provider=p,
        model=m,
        max_tokens=mt,
        system_prompt=system_prompt,
        tools=list(tools or []),
        output_type=output_type,
    )


async def chat_turn(
    agent_obj: _AutoRetryAgent,
    user_msg: str,
    *,
    message_history: Optional[list] = None,
    turn_id: Optional[str] = None,
    on_cancel_text: str = "\n\n_(stopped by user)_",
) -> str:
    """Drive one streaming chat turn end-to-end.

    Mints a turn_id, emits ``turn_start`` / ``text_delta`` chunks /
    ``turn_end`` via :func:`chat_stream`, polls :data:`gen.cancelled`
    per chunk, and retries once on a 401/403 (re-prompting for the
    provider's API key). Returns the accumulated assistant text.

    ``message_history`` defaults to ``gen.history.as_pai()`` so a
    chat-loop body stays one line: ``reply = await gen.chat_turn(agent, msg)``.
    Pass ``message_history=[]`` for stateless turns.
    """
    import uuid
    from collimate.llm import looks_like_auth_error

    bridge = _require_bridge()
    if turn_id is None:
        turn_id = uuid.uuid4().hex
    if message_history is None:
        message_history = history.as_pai()

    async def _drive() -> str:
        accum = ""
        async with agent_obj.raw.run_stream(
            user_msg, message_history=message_history,
        ) as stream:
            async for chunk in stream.stream_text(delta=True):
                if bridge.cancelled:
                    accum += on_cancel_text
                    bridge.chat_stream_event(
                        turn_id, {"type": "text_delta", "text": on_cancel_text},
                    )
                    return accum
                accum += chunk
                bridge.chat_stream_event(
                    turn_id, {"type": "text_delta", "text": chunk},
                )
        return accum

    bridge.chat_stream_event(turn_id, {"type": "turn_start"})
    try:
        try:
            return await _drive()
        except Exception as exc:
            if not looks_like_auth_error(exc):
                raise
            await agent_obj._rebuild_after_auth_failure()
            return await _drive()
    finally:
        bridge.chat_stream_event(turn_id, {"type": "turn_end"})


def file_tools() -> list:
    """Return list/read/write/edit ``pydantic_ai.Tool`` objects bound
    to the workspace.

    Reads/writes go through the same bridge that :func:`update_file`
    uses, so subsequent :func:`update` calls reflect the agent's edits.
    """
    bridge = _require_bridge()
    from pydantic_ai import Tool

    async def list_files_t() -> list[str]:
        """List every file currently visible to the agent."""
        return sorted(bridge.fs_list())

    async def read_file_t(path: str) -> str:
        """Read the full text of a workspace file."""
        if not bridge.fs_exists(path):
            return f"ERROR: file not found: {path}"
        return bridge.fs_read(path)

    async def write_file_t(path: str, content: str) -> str:
        """Create or overwrite ``path`` with ``content`` (UTF-8)."""
        bridge.fs_write(path, content)
        return f"wrote {len(content)} bytes to {path}"

    async def edit_file_t(path: str, old: str, new: str) -> str:
        """First-match string replace inside ``path``."""
        if not bridge.fs_exists(path):
            return f"ERROR: file not found: {path}"
        current = bridge.fs_read(path)
        if old not in current:
            return f"ERROR: old text not found in {path}"
        bridge.fs_write(path, current.replace(old, new, 1))
        return f"edited {path}"

    return [
        Tool(list_files_t, name="list_files"),
        Tool(read_file_t, name="read_file"),
        Tool(write_file_t, name="write_file"),
        Tool(edit_file_t, name="edit_file"),
    ]


def python_tool(
    *,
    timeout: int = 60,
    default_packages: Optional[list[str]] = None,
):
    """Return a pydantic_ai ``Tool`` that lets the agent run Python
    code in the cell's workspace.

    Wire it alongside :func:`file_tools` so the agent can both author
    files (read/write/edit) and run scripts that compute, analyse, or
    generate artifacts (matplotlib charts, pandas tables, …)::

        agent = await gen.agent(
            system_prompt=...,
            tools=gen.file_tools() + [gen.python_tool(default_packages=["matplotlib"])],
        )

    The tool's signature exposed to the LLM is::

        run_python(code: str, packages: list[str] = []) -> str

    What the tool actually does:

      * Runs ``code`` as a subprocess with the workspace as cwd.
      * If ``packages`` is non-empty, spawns a fresh ephemeral env via
        ``uv run --no-project --with <pkg> ... -- python -c <code>`` so
        the agent can pull in libraries the generator's PEP 723 manifest
        didn't declare. Otherwise runs in the generator's own
        interpreter (deps from the manifest only).
      * Snapshots the workspace before/after via :meth:`snapshot` and
        auto-stages every new or modified file into ``tracked_writes``,
        so the next :func:`update` (or auto-flush at end of run)
        commits them as cell artifacts.
      * Returns the formatted ``return code + changed files + stdout/
        stderr`` block as a string for the agent to read.

    Args:
        timeout: Hard cap (seconds) per tool call. Cooperative
            cancellation via ``gen.cancelled`` is polled per output
            line by the underlying subprocess streamer.
        default_packages: Implicit packages installed for every
            ``run_python`` call when the agent doesn't pass its own.
            Useful for generators that always want, say, matplotlib.
    """
    bridge = _require_bridge()
    from pydantic_ai import Tool
    import sys

    default_pkgs = list(default_packages or [])

    async def run_python(
        code: str,
        packages: Optional[list[str]] = None,
    ) -> str:
        """Run a Python script in this cell's workspace.

        Args:
            code: Python source to run (multi-line OK).
            packages: Extra pip packages to install for this single
                run (e.g. ["matplotlib", "pandas"]). Empty / unset
                uses the generator's existing dependencies only.

        Files the script creates or modifies are auto-included in the
        cell — just write to relative paths from cwd. The script's
        stdout and stderr are merged and returned along with the exit
        code; raise inside the script to surface a traceback.
        """
        before = bridge.snapshot_workspace()

        pkgs = list(packages) if packages else default_pkgs
        if pkgs:
            cmd: list[str] = ["uv", "run", "--no-project"]
            for pkg in pkgs:
                cmd += ["--with", str(pkg)]
            cmd += ["python", "-c", code]
        else:
            cmd = [sys.executable, "-c", code]

        loop = asyncio.get_event_loop()
        rc, output = await loop.run_in_executor(
            None,
            lambda: bridge.run_streamed_subprocess(
                cmd,
                timeout=timeout,
                print_stdout=False,
                emit_bash_stdout=False,
            ),
        )

        after = bridge.snapshot_workspace()
        changed: list[str] = []
        for path, h in after.items():
            if before.get(path) != h:
                bridge.tracked_writes.add(path)
                changed.append(path)

        lines = [
            f"return code: {rc}",
            f"files created/modified: {sorted(changed) if changed else '(none)'}",
            "",
            "--- output ---",
            output if output else "(empty)",
        ]
        return "\n".join(lines)

    return Tool(run_python, name="run_python")


# ══════════════════════════════════════════════════════════════════════
# Tier B — Native-only extensions
# ══════════════════════════════════════════════════════════════════════


def workspace_path() -> str:
    """Real filesystem path to the workspace.

    Needed by Docker volume mounts, tools that take a cwd, and any path
    handed to a child process.
    """
    return _require_bridge().workspace


def progress(current: int, total: int) -> None:
    """Emit a live progress bar update."""
    _require_bridge().progress(current, total)


async def serve_port(
    port: int,
    *,
    name: str = "preview",
    path: str = "",
    snapshot_source: Optional[dict[str, str]] = None,
) -> None:
    """Bind ``port`` for daemon generators. The host opens a sandbox
    iframe on the cell at ``port``."""
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(
        None,
        lambda: bridge.serve_port(
            port, name=name, path=path, snapshot_source=snapshot_source,
        ),
    )


async def run_subprocess(
    command,
    *,
    turn_id: Optional[str] = None,
    timeout: int = 120,
    cwd: Optional[str] = None,
    shell: bool = False,
    emit_bash_stdout: bool = True,
    emit_text_delta: bool = False,
    print_stdout: bool = True,
) -> tuple[int, str]:
    """Spawn a subprocess and stream output. Returns
    ``(returncode, full_output)``. Cooperative cancellation: polls
    :func:`gen.cancelled` per line."""
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        None,
        lambda: bridge.run_streamed_subprocess(
            command=command,
            turn_id=turn_id,
            timeout=timeout,
            cwd=cwd,
            shell=shell,
            emit_bash_stdout=emit_bash_stdout,
            emit_text_delta=emit_text_delta,
            print_stdout=print_stdout,
        ),
    )


def snapshot(*, skip_dirs: Optional[set[str]] = None) -> dict[str, str]:
    """``{relpath: sha256_hex}`` for every workspace file."""
    return _require_bridge().snapshot_workspace(skip_dirs=skip_dirs)


async def terminal(
    container_id: str,
    command: list[str],
    *,
    cwd: Optional[str] = None,
    env: Optional[dict[str, str]] = None,
) -> dict:
    """Allocate a WebSocket-backed PTY session in a container.

    Returns ``{session_id, ws_path, token}``. Typical pattern: dump
    this dict (plus a human ``label``) into a ``<name>.terminal`` file
    via :func:`update_file` so the cell renders the live terminal.
    """
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        None,
        lambda: bridge.start_terminal(
            container_id=container_id, command=command, cwd=cwd, env=env,
        ),
    )


def stop_terminal(session_id: str) -> None:
    """Tear down a terminal. Idempotent."""
    _require_bridge().stop_terminal(session_id)


async def wait_for_action(timeout: Optional[float] = None) -> Optional[str]:
    """Block until a renderer emits an action, or ``timeout`` elapses,
    or Stop is requested. Returns the action id or ``None``."""
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    deadline = None if timeout is None else loop.time() + timeout
    while True:
        if bridge.cancelled:
            return None
        action = await loop.run_in_executor(None, bridge.poll_renderer_action)
        if action:
            return action
        if deadline is not None and loop.time() >= deadline:
            return None
        await asyncio.sleep(0.15)


async def request_settings(settings_file_path: str) -> dict:
    """Pop a ``.set_yaml`` settings overlay mid-run; block until the
    user presses Continue and return the updated values dict."""
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    try:
        return await loop.run_in_executor(
            None, lambda: bridge.request_settings_update(settings_file_path),
        )
    except _StopRequested as exc:
        raise Cancelled(f"settings update cancelled") from exc


def chat_stream(turn_id: str, event: dict) -> None:
    """Push a chat-stream event directly to the frontend via SSE."""
    _require_bridge().chat_stream_event(turn_id, event)


async def chat_session(
    image: str,
    dockerfile_dir: str,
    *,
    shared: bool = True,
    backend: str = "claude_code_session",
    model: str = "sonnet",
    system_prompt: str = "",
):
    """Open (or reuse) a persistent streaming session bound to the cell.

    Returns a handle exposing ``send_turn(content) -> dict``.
    """
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    info = await loop.run_in_executor(
        None,
        lambda: bridge.chat_session_start(
            image=image,
            dockerfile_dir=dockerfile_dir,
            shared=shared,
            backend=backend,
            model=model,
            system_prompt=system_prompt,
        ),
    )

    class _SessionHandle:
        def __init__(self, info_dict: dict):
            self.info = info_dict

        async def send_turn(self, content: str) -> dict:
            return await loop.run_in_executor(
                None, lambda: bridge.chat_session_send(content),
            )

        def __getitem__(self, key):
            return self.info[key]

    return _SessionHandle(info)


# ──────────────────────────────────────────────────────────────────────
# Entrypoint helper
# ──────────────────────────────────────────────────────────────────────


def main(run_fn) -> None:
    """Run a generator's ``run`` function under the singleton API.

    Construct the IPC bridge, hydrate the singleton, dispatch ``run_fn``
    (sync or async), auto-flush any pending writes / chat history to
    the cell, and emit the finish IPC. Catches :class:`Cancelled` and
    :class:`_StopRequested` as graceful stop; every other exception is
    reported via the run's error channel.

    **Auto-flush**: if ``run_fn`` returns cleanly with files written via
    :func:`update_file` or chat appended via ``gen.history.append`` but
    never called :func:`update`, this commits them as the final cell
    state. Generators that explicitly want an empty placeholder simply
    don't write or append anything — same as before.
    """
    bridge = HostBridge()
    _set_bridge(bridge)
    try:
        if asyncio.iscoroutinefunction(run_fn):
            asyncio.run(run_fn())
        else:
            run_fn()
        if (
            bridge.tracked_writes
            or bridge.tracked_deletions
            or bridge.history_dirty
        ):
            try:
                deleted = sorted(bridge.tracked_deletions) or None
                bridge.tracked_deletions.clear()
                bridge.update_cell(deleted_files=deleted)
            except Exception:
                bridge.log.exception("auto-flush update_cell failed")
        bridge.finish(success=True)
    except (Cancelled, _StopRequested):
        bridge.log.info("Stopped gracefully by user.")
        bridge.finish(success=False, error_message="Stopped by user")
    except Exception as exc:
        bridge.log.exception("Generator failed")
        bridge.finish(success=False, error_message=str(exc))
    finally:
        _clear_bridge()


__all__ = [
    # Exceptions
    "Cancelled",
    "IPCDisconnectedError",
    "IPCError",
    "IPCNakError",
    "IPCTimeoutError",
    # Inputs / config
    "config",
    "input_files",
    "input_groups",
    "read_input",
    # Output stage
    "delete_file",
    "has_file",
    "list_files",
    "read_file",
    "update_file",
    # Cell ops
    "create_stack_cell",
    "update",
    # Chat / user input
    "chat_loop",
    "chat_session",
    "chat_stream",
    "chat_turn",
    "history",
    "next_message",
    # Secrets
    "api_key",
    "secret",
    # Status / control
    "log",
    "progress",
    "status",
    # LLM convenience
    "agent",
    "file_tools",
    "python_tool",
    # Native filesystem / subprocess / ports / terminals
    "request_settings",
    "run_subprocess",
    "serve_port",
    "snapshot",
    "stop_terminal",
    "terminal",
    "wait_for_action",
    "workspace_path",
    # Entrypoint
    "main",
]
