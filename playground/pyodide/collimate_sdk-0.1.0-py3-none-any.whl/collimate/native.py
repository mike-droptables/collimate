# SPDX-License-Identifier: Apache-2.0
"""Singleton runtime API for native generators.

A generator script imports the top-level :mod:`gen` package — a thin
runtime-aware shim that re-exports from this module under native and
from :mod:`collimate.wasm` under pyodide. The shape is the same on both
runtimes for **Tier A** symbols; **Tier B** symbols (terminals, ports,
subprocess streaming, raw filesystem access, snapshot, settings modal,
action polling, container-backed chat sessions, IPC error types) are
native-only.

Entrypoint contract::

    import gen

    async def run():
        gen.update_file("output.md", "...")
        await gen.update(summary="hello")

    if __name__ == "__main__":
        gen.main(run)

``gen.main`` constructs a single :class:`collimate._host.HostBridge`
(IPC + signal handling + filesystem + state tracking), hydrates the
singleton, dispatches ``run_fn`` (sync or async), and emits the finish
IPC on the way out.

Two tiers:

  * **Tier A** (portable; mirrors :mod:`collimate.wasm` 1:1): inputs,
    file I/O, cells, user input, secrets, status, agent / file_tools.
    A generator using only Tier A is runtime-portable (the demo/WASM
    runtime exposes the same surface).
  * **Tier B** (native-only): real filesystem path, subprocess
    streaming, port binding, terminals, settings modal, action polling,
    snapshot diffing, container-backed chat sessions, IPC error types.
    These are the canonical native capabilities; the demo/WASM runtime
    omits them. (Runtime is folder-based — there is no ``runtime:``
    manifest field.)

Cell operations are deliberately limited to two:

  * :func:`update` flushes any staged file writes (and dirty chat
    history) to the placeholder/top cell. May be called many times
    during a run; the last call before return is the final state.
  * :func:`create_stack_cell` adds a new cell below in the right-side
    stack. Used by fan-out generators.

Calling ``update_file`` without ever calling ``update`` produces an
empty placeholder — explicit by design.
"""
from __future__ import annotations

from typing import Any, AsyncIterator, Iterator, Optional
import asyncio
import os

from collimate._host import (
    HostBridge,
    IPCDisconnectedError as _IPCDisconnectedError,
    IPCError as _IPCError,
    IPCNakError as _IPCNakError,
    IPCTimeoutError as _IPCTimeoutError,
    Message,
    _StopRequested,
)

# The single result/spec abstraction shared by the host-free testing
# harness and the composition API. Re-exported here so generators can
# refer to them as ``gen.GeneratorResult`` etc. (same object identity as
# ``collimate.testing``'s re-exports).
from collimate._results import (  # noqa: F401
    CellRecord,
    Endpoint,
    EnvironmentSpec,
    GeneratorInfo,
    GeneratorResult,
    RendererCheck,
    Request,
    _decode_files,
    _encode_files,
    _endpoint_from_dict,
    _env_spec_from_dict,
    _info_from_dict,
    _result_from_ack,
)


# ──────────────────────────────────────────────────────────────────────
# Module-level singleton state.
#
# ``_set_bridge()`` (called by :func:`main`) stores the live
# :class:`HostBridge`. Generators read/write through the public
# ``gen.*`` functions; they never touch ``_bridge`` directly.
# ──────────────────────────────────────────────────────────────────────

_bridge: Optional[HostBridge] = None


# ──────────────────────────────────────────────────────────────────────
# Public exception types (Tier A / Tier B)
# ──────────────────────────────────────────────────────────────────────


# Re-exported from collimate.host_protocol so native + wasm share the
# same Cancelled class identity. A Tier-A-only generator that runs on
# both runtimes catches the same exception type either way.
from collimate.host_protocol import Cancelled  # noqa: F401,E402


# Tier B re-exports (raise under WASM via the shim in `gen/__init__.py`).
IPCError = _IPCError
IPCNakError = _IPCNakError
IPCTimeoutError = _IPCTimeoutError
IPCDisconnectedError = _IPCDisconnectedError


# ──────────────────────────────────────────────────────────────────────
# Runner / lifecycle hooks
# ──────────────────────────────────────────────────────────────────────


def _set_bridge(bridge: HostBridge) -> None:
    """Hydrate the singleton with a live :class:`HostBridge`."""
    global _bridge
    _bridge = bridge


def _clear_bridge() -> None:
    global _bridge
    _bridge = None


def _require_bridge() -> HostBridge:
    if _bridge is None:
        raise RuntimeError(
            "gen.* used outside a generator run "
            "(call gen.main(run) at the entrypoint)"
        )
    return _bridge


# ──────────────────────────────────────────────────────────────────────
# Module-level dynamic attributes
#
# ``gen.prompt`` / ``gen.messages`` / ``gen.cancelled`` resolve against
# the current run's bridge. PEP 562 ``__getattr__`` at module level.
# ──────────────────────────────────────────────────────────────────────


def __getattr__(name: str) -> Any:
    if name == "prompt":
        return _require_bridge().prompt
    if name == "messages":
        return list(history)
    if name == "cancelled":
        return _require_bridge().cancelled
    if name == "invocation_type":
        return _require_bridge().invocation_type
    raise AttributeError(f"module 'collimate.native' has no attribute {name!r}")


# ──────────────────────────────────────────────────────────────────────
# Tier A — Inputs
# ──────────────────────────────────────────────────────────────────────


def read_input(path: str) -> "str | bytes":
    """Read a file from the input/parent cell workspace.

    Returns ``str`` when the bytes decode as utf-8, otherwise ``bytes``.
    Symmetric with the WASM runtime; previously native was text-only.
    """
    return _require_bridge().fs_read_any(path)


def input_files() -> dict[str, "str | bytes"]:
    """Return every input-cell file as ``{relpath: content}``.

    Each value is ``str`` when utf-8 decodable, else ``bytes``. Files
    that fail to open are silently skipped.
    """
    bridge = _require_bridge()
    out: dict[str, "str | bytes"] = {}
    for p in bridge.fs_list():
        try:
            out[p] = bridge.fs_read_any(p)
        except OSError:
            continue
    return out


def input_groups() -> dict[str, dict[str, "str | bytes"]]:
    """Return input files grouped by source cell.

    For multi-cell input (workspace hydrated as ``inputs/NN_slug/...``),
    each top-level subfolder under ``inputs/`` becomes one group; paths
    in each group are **relative to the cell root** so callers can
    re-emit them verbatim.

    For single-cell input (files at workspace root), returns one group
    keyed ``"input"`` with the original paths. Each value is ``str`` for
    utf-8 decodable files, else ``bytes``.
    """
    bridge = _require_bridge()
    all_paths = bridge.fs_list()
    inputs_prefix = "inputs/"
    under_inputs = [p for p in all_paths if p.startswith(inputs_prefix)]
    if not under_inputs:
        if not all_paths:
            return {}
        single: dict[str, "str | bytes"] = {}
        for p in all_paths:
            try:
                single[p] = bridge.fs_read_any(p)
            except OSError:
                continue
        return {"input": single}

    raw: dict[str, dict[str, "str | bytes"]] = {}
    for p in under_inputs:
        rest = p[len(inputs_prefix):]
        label, _, sub = rest.partition("/")
        if not sub:
            continue
        try:
            content = bridge.fs_read_any(p)
        except OSError:
            continue
        raw.setdefault(label, {})[sub] = content
    return {label: raw[label] for label in sorted(raw)}


def config(name: str) -> dict:
    """Read a draft file declared in the manifest's ``draft_files``.

    Always returns a dict. ``.set_yaml`` / ``.yaml`` / ``.yml`` parse
    as YAML (with ``fields:`` defaults merged into the ``values:``
    block). ``.json`` parses as JSON. Returns ``{}`` when the file is
    missing or malformed — callers can use ``cfg.get(...)`` without
    try/except.

    For raw text files, use :func:`read_file` instead.
    """
    raw = _require_bridge().config(name)
    return raw if isinstance(raw, dict) else {}


# ──────────────────────────────────────────────────────────────────────
# Tier A — Output stage (workspace filesystem)
# ──────────────────────────────────────────────────────────────────────


def update_file(path: str, content: "str | bytes") -> None:
    """Stage a write to the output cell's file at ``path``.

    Accepts either ``str`` (utf-8 text) or ``bytes`` (binary). Writes
    immediately to the workspace (so subprocesses see it) and marks the
    path for inclusion in the next :func:`update` flush. Multiple writes
    overwrite — last write wins.
    """
    _require_bridge().fs_write_any(path, content)


def read_file(path: str) -> "str | bytes":
    """Read from the output stage. Raises :class:`FileNotFoundError`
    when the path is missing. Returns ``str`` when utf-8 decodable,
    else ``bytes``."""
    bridge = _require_bridge()
    if not bridge.fs_exists(path):
        raise FileNotFoundError(path)
    return bridge.fs_read_any(path)


def has_file(path: str) -> bool:
    """Predicate over the output stage."""
    return _require_bridge().fs_exists(path)


def list_files() -> list[str]:
    """Sorted list of every staged file's relative path."""
    return sorted(_require_bridge().fs_list())


def delete_file(path: str) -> None:
    """Drop ``path`` from the output stage. The next :func:`update`
    call passes it as ``deleted_files`` so the host strips it from the
    cell's carried-forward file set."""
    _require_bridge().fs_unlink(path)


# ──────────────────────────────────────────────────────────────────────
# Tier A — Cell operations (two only)
# ──────────────────────────────────────────────────────────────────────


async def update(
    *,
    name: Optional[str] = None,
    summary: Optional[str] = None,
    pinned: Optional[str] = None,
) -> None:
    """Flush the current stage (tracked writes) to the placeholder/top cell.

    May be called many times during a run; each call refreshes the
    visible cell live. The last call before return is the final state.
    **If ``update`` is never called, the placeholder is empty.**
    """
    bridge = _require_bridge()
    deletions = sorted(bridge.tracked_deletions) if bridge.tracked_deletions else None
    bridge.tracked_deletions.clear()

    loop = asyncio.get_event_loop()
    await loop.run_in_executor(
        None,
        lambda: bridge.update_cell(
            name=name,
            summary=summary,
            pinned=pinned,
            deleted_files=deletions,
        ),
    )


async def create_stack_cell(
    name: str,
    *,
    summary: Optional[str] = None,
    pinned: Optional[str] = None,
    files: Optional[dict[str, str]] = None,
) -> str:
    """Add a new cell below in the (right-side) stack.

    If ``files`` is provided, each entry is written first, then the
    side-cell is created with those paths as artifacts. If ``files`` is
    omitted, snapshots whatever is currently tracked.

    Returns the new cell's id.
    """
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        None,
        lambda: bridge.create_side_cell(
            name=name,
            summary=summary,
            pinned=pinned,
            files=files,
        ),
    )


# ──────────────────────────────────────────────────────────────────────
# Tier A — Chat history (a visible, editable ``.chatlog`` transcript)
# ──────────────────────────────────────────────────────────────────────


class _History:
    """In-memory chat transcript persisted to a visible ``.chatlog`` file.

    ``append(role, content)`` updates the list and rewrites the ``.chatlog``
    text artifact through the normal output stage (:func:`update_file`), so
    the next :func:`update` commits it as an ordinary versioned file — no
    reserved path, no special flush. ``seed_from_chatlog()`` rebuilds the
    list from an existing transcript so a fresh run resumes where the last
    one left off. ``as_pai()`` translates to pydantic_ai ``ModelMessage``.

    The transcript file name defaults to ``conversation.chatlog`` and is set
    by :func:`serve_chat`.
    """

    log_file: str = "conversation.chatlog"

    def __init__(self) -> None:
        self._messages: list[Message] = []

    def append(self, role: str, content: str) -> None:
        self._messages.append(Message(role=role, content=content))
        self._flush()

    def _flush(self) -> None:
        from collimate.chatlog import serialize_chatlog
        update_file(self.log_file, serialize_chatlog(self._messages))

    def seed_from_chatlog(self, path: Optional[str] = None) -> bool:
        """Load history from an existing ``.chatlog``. Returns True when one
        was found (``path``, else the first ``*.chatlog`` in the workspace)."""
        from collimate.chatlog import parse_chatlog
        bridge = _require_bridge()
        target = path or self.log_file
        candidate: Optional[str] = target if bridge.fs_exists(target) else None
        if candidate is None:
            for p in sorted(bridge.fs_list()):
                if p.endswith(".chatlog"):
                    candidate = p
                    break
        if candidate is None:
            return False
        try:
            raw = bridge.fs_read_any(candidate)
        except OSError:
            return False
        text = raw.decode("utf-8") if isinstance(raw, bytes) else raw
        self._messages = parse_chatlog(text)
        self.log_file = candidate
        return True

    def __iter__(self) -> Iterator[Message]:
        return iter(self._messages)

    def __len__(self) -> int:
        return len(self._messages)

    def __getitem__(self, idx):  # type: ignore[no-untyped-def]
        return self._messages[idx]

    def as_pai(self) -> list:
        if not self._messages:
            return []
        from pydantic_ai.messages import (
            ModelRequest,
            ModelResponse,
            TextPart,
            UserPromptPart,
        )
        out: list = []
        for m in self._messages:
            if m.role == "user":
                out.append(ModelRequest(parts=[UserPromptPart(content=m.content or "")]))
            elif m.role == "assistant":
                out.append(ModelResponse(parts=[TextPart(content=m.content or "")]))
        return out


history = _History()


# ──────────────────────────────────────────────────────────────────────
# Tier A — Secrets (two-tier)
# ──────────────────────────────────────────────────────────────────────


# Provider → env var. Pyodide-only providers are excluded from native
# (CORS-locked under the browser, but we'd resolve a key anyway under
# native).
_PROVIDER_KEY_ENV: dict[str, str] = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
    "groq": "GROQ_API_KEY",
    "cerebras": "CEREBRAS_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
    "gemini": "GEMINI_API_KEY",
    "mistral": "MISTRAL_API_KEY",
}


# Per-provider locks coordinate concurrent ``force=True`` retries —
# without them, a parallel ``asyncio.gather`` of N agent calls that
# all auth-fail would pop the modal N times. With the lock, the first
# retry to acquire pops the modal; the rest wait, then read the
# freshly-set env var and skip.
_FORCE_LOCKS: dict[str, asyncio.Lock] = {}


async def api_key(
    provider: str,
    *,
    force: bool = False,
    description: str = "",
) -> str:
    """Resolve the API key for ``provider`` and set the standard env var
    so pydantic_ai's native provider lookup picks it up.

    Fast path: ``os.environ[{PROVIDER}_API_KEY]`` when set and not
    ``force``. Slow path: the in-cell modal. ``force=True`` skips the
    fast path — the auth-retry door after a 401. Concurrent
    ``force=True`` calls for the same provider coordinate behind a
    per-provider lock so only one modal pops per retry burst.

    Raises :class:`Cancelled` when the user cancels the modal.
    """
    bridge = _require_bridge()
    env_name = _PROVIDER_KEY_ENV.get(provider.lower(), "")
    if not env_name:
        raise ValueError(
            f"Unknown provider {provider!r}; expected one of "
            f"{sorted(_PROVIDER_KEY_ENV)}."
        )
    if not force:
        existing = (os.environ.get(env_name) or "").strip()
        if existing:
            return existing

    lock = _FORCE_LOCKS.setdefault(env_name, asyncio.Lock())
    async with lock:
        # Re-check env inside the lock: a concurrent retry may have
        # popped the modal and set it while we were waiting. If the
        # value is fresh (matches what bridge._last_force_ts records)
        # use it instead of re-prompting.
        existing = (os.environ.get(env_name) or "").strip()
        if force and existing and bridge._was_recently_force_set(env_name):
            return existing
        if not force and existing:
            return existing

        msg = description or f"API key for {provider} (used by this generator)"
        loop = asyncio.get_event_loop()
        try:
            value = await loop.run_in_executor(
                None,
                lambda: bridge.get_key(env_name, description=msg, force=force),
            )
        except _StopRequested as exc:
            raise Cancelled(f"key request for {env_name!r} cancelled") from exc
        if value:
            os.environ[env_name] = value
            bridge._mark_force_set(env_name)
        return value


async def secret(
    name: str,
    *,
    prompt_if_missing: bool = False,
    description: str = "",
) -> str:
    """Read a non-LLM secret. Default is the env-var fast path only;
    ``prompt_if_missing=True`` opts into the modal flow."""
    fast = os.environ.get(name)
    if fast:
        return fast
    if not prompt_if_missing:
        return ""
    bridge = _require_bridge()
    msg = description or f"Secret {name}"
    loop = asyncio.get_event_loop()
    try:
        value = await loop.run_in_executor(
            None,
            lambda: bridge.get_key(name, description=msg, force=False),
        )
    except _StopRequested as exc:
        raise Cancelled(f"secret request for {name!r} cancelled") from exc
    if value:
        os.environ[name] = value
    return value


# ──────────────────────────────────────────────────────────────────────
# Tier A — Status / control
# ──────────────────────────────────────────────────────────────────────


def log(line: str) -> None:
    """Append a line to the run log (visible in the events panel)."""
    _require_bridge().push_log(line)


def status(msg: str) -> None:
    """Set the live status string shown next to the run row."""
    _require_bridge().set_status(msg)


# ──────────────────────────────────────────────────────────────────────
# LLM convenience tier
# ──────────────────────────────────────────────────────────────────────


def _build_pydantic_ai_agent(
    *,
    provider: str,
    model: str,
    max_tokens: int,
    system_prompt: str,
    tools: list,
    output_type: Optional[type],
):
    """Construct a vanilla ``pydantic_ai.Agent`` with the given config.
    Used both for the initial build and for the auth-retry rebuild
    inside :class:`_AutoRetryAgent`."""
    from pydantic_ai import Agent
    from pydantic_ai.settings import ModelSettings
    # Translate Collimate's user-facing provider label to pydantic-ai's
    # provider id. ``gemini`` is our canonical label (matching the env
    # var ``GEMINI_API_KEY``), but pydantic-ai uses ``google-gla`` for
    # the free Gemini API.
    pa_provider = "google-gla" if provider == "gemini" else provider
    # pydantic-ai 1.x rejects ``output_type=None`` ("At least one output
    # type must be provided other than `None`"). Omit the kwarg so the
    # library's default (``str``) kicks in for free-text agents.
    extra: dict = {}
    if output_type is not None:
        extra["output_type"] = output_type
    return Agent(
        f"{pa_provider}:{model}",
        system_prompt=system_prompt,
        tools=tools,
        model_settings=ModelSettings(max_tokens=max_tokens),
        **extra,
    )


class _AutoRetryAgent:
    """Wrapper around ``pydantic_ai.Agent`` that retries once on auth
    failure.

    On a 401/403 the wrapper:

      * pops the in-cell key modal via :func:`api_key` with
        ``force=True`` (the modal shows "previous key was rejected");
      * rebuilds the underlying pydantic_ai Agent with the same config
        (so any keys the SDK loaded into the env are picked up);
      * retries the call once.

    ``.run()`` is wrapped directly. ``.run_stream()`` is left passthrough
    — streaming chats use :func:`agent_chat_turn` for retry + delta
    streaming in one call.

    Power users who need the unwrapped Agent reach via ``.raw``.
    """

    def __init__(
        self,
        *,
        provider: str,
        model: str,
        max_tokens: int,
        system_prompt: str,
        tools: list,
        output_type: Optional[type],
    ) -> None:
        self.provider = provider
        self.model = model
        self._kwargs = dict(
            provider=provider,
            model=model,
            max_tokens=max_tokens,
            system_prompt=system_prompt,
            tools=tools,
            output_type=output_type,
        )
        self.raw = _build_pydantic_ai_agent(**self._kwargs)

    async def _rebuild_after_auth_failure(self) -> None:
        await api_key(
            self.provider,
            force=True,
            description=f"Previous {self.provider} key was rejected. Enter a fresh API key.",
        )
        self.raw = _build_pydantic_ai_agent(**self._kwargs)

    async def run(self, *args, **kwargs):
        from collimate.llm import looks_like_auth_error
        try:
            return await self.raw.run(*args, **kwargs)
        except Exception as exc:
            if not looks_like_auth_error(exc):
                raise
            await self._rebuild_after_auth_failure()
            return await self.raw.run(*args, **kwargs)

    def run_stream(self, *args, **kwargs):
        # Streaming retry needs to coordinate with stream events and
        # cancellation polling — don't try to do it here. Use
        # :func:`agent_chat_turn` for streaming chat with retry. This
        # passes through to vanilla pydantic_ai.run_stream so power users
        # can still drive their own loop.
        return self.raw.run_stream(*args, **kwargs)

    def __getattr__(self, name):
        # Delegate any other attribute (overrides, instructions, …) to
        # the underlying Agent so the wrapper stays transparent.
        return getattr(self.raw, name)


async def agent(
    *,
    system_prompt: str = "",
    tools: Optional[list] = None,
    output_type: Optional[type] = None,
    provider: Optional[str] = None,
    model: Optional[str] = None,
    max_tokens: Optional[int] = None,
    config_file: str = "pydantic-config.set_yaml",
) -> _AutoRetryAgent:
    """Build a configured agent with auto-retry on auth failure.

    Reads ``provider`` / ``model`` / ``max_tokens`` from the generator's
    ``pydantic-config.set_yaml`` when not overridden. Calls :func:`api_key`
    to resolve the key and populate the env var.

    Returns an :class:`_AutoRetryAgent` whose ``.run()`` retries once on
    a 401/403 (via :func:`api_key` with ``force=True``). For streaming
    chat with the same retry behaviour, use :func:`agent_chat_turn`
    instead of driving ``.run_stream()`` yourself.

    The unwrapped ``pydantic_ai.Agent`` is exposed as ``.raw`` for power
    users.
    """
    cfg: dict = {}
    if provider is None or model is None or max_tokens is None:
        cfg = config(config_file)

    p = (provider or cfg.get("provider") or "anthropic").strip().lower()
    m = (model or cfg.get("model") or "claude-sonnet-4-6").strip()
    mt = max_tokens
    if mt is None:
        raw = cfg.get("max_tokens")
        try:
            mt = int(raw)
            if mt <= 0:
                mt = 4096
        except (TypeError, ValueError):
            mt = 4096

    await api_key(p)
    return _AutoRetryAgent(
        provider=p,
        model=m,
        max_tokens=mt,
        system_prompt=system_prompt,
        tools=list(tools or []),
        output_type=output_type,
    )


async def agent_chat_turn(
    turn: "ChatTurn",
    agent_obj: _AutoRetryAgent,
    *,
    message_history: Optional[list] = None,
    on_cancel_text: str = "\n\n_(stopped by user)_",
    cancel_poll_interval_s: float = 0.2,
) -> str:
    """Drive one streaming pydantic-ai turn against a :class:`ChatTurn`.

    Streams ``stream_text(delta=True)`` chunks to the live renderer via
    ``turn.delta``, polls ``turn.cancelled`` concurrently with the stream so
    an interrupt takes effect even when the LLM HTTP call is hung between
    chunks (the watcher cancels the stream task directly rather than waiting
    for the next byte), and retries once on a 401/403 (re-prompting for the
    provider's API key). Returns the accumulated assistant text.

    The enclosing :func:`serve_chat` brackets the turn with ``turn_start`` /
    ``turn_end`` events, so this only emits the text deltas in between.

    ``message_history`` defaults to ``turn.history.as_pai()`` minus a trailing
    duplicate of ``turn.user_msg`` — the natural pattern appends the user turn
    to history *before* calling this so the user bubble surfaces immediately,
    which would otherwise hand the model two identical consecutive user turns
    (echoey replies). Pass ``message_history=[]`` for stateless turns.
    """
    from collimate.llm import looks_like_auth_error

    user_msg = turn.user_msg
    if message_history is None:
        full_history = turn.history.as_pai()
        if full_history:
            from pydantic_ai.messages import ModelRequest, UserPromptPart
            last = full_history[-1]
            if isinstance(last, ModelRequest):
                parts = getattr(last, "parts", None) or []
                if (
                    len(parts) == 1
                    and isinstance(parts[0], UserPromptPart)
                    and getattr(parts[0], "content", None) == user_msg
                ):
                    full_history = full_history[:-1]
        message_history = full_history

    async def _drive() -> str:
        accum_box: list[str] = [""]
        cancelled_box: list[bool] = [False]

        async def consume() -> None:
            async with agent_obj.raw.run_stream(
                user_msg, message_history=message_history,
            ) as stream:
                async for chunk in stream.stream_text(delta=True):
                    if turn.cancelled:
                        cancelled_box[0] = True
                        return
                    accum_box[0] += chunk
                    turn.delta(chunk)

        async def watch_cancel(consume_task: asyncio.Task) -> None:
            while not consume_task.done():
                if turn.cancelled:
                    cancelled_box[0] = True
                    consume_task.cancel()
                    return
                await asyncio.sleep(cancel_poll_interval_s)

        consume_task = asyncio.create_task(consume())
        watch_task = asyncio.create_task(watch_cancel(consume_task))

        try:
            await consume_task
        except asyncio.CancelledError:
            # Watcher cancelled us on interrupt — swallow so the caller
            # doesn't see a stray CancelledError. Finalize accum below.
            pass
        finally:
            watch_task.cancel()
            try:
                await watch_task
            except asyncio.CancelledError:
                pass

        if cancelled_box[0]:
            accum_box[0] += on_cancel_text
            turn.delta(on_cancel_text)
        return accum_box[0]

    try:
        return await _drive()
    except Exception as exc:
        if not looks_like_auth_error(exc):
            raise
        await agent_obj._rebuild_after_auth_failure()
        return await _drive()


def file_tools() -> list:
    """Return list/read/write/edit ``pydantic_ai.Tool`` objects bound
    to the workspace.

    Reads/writes go through the same bridge that :func:`update_file`
    uses, so subsequent :func:`update` calls reflect the agent's edits.
    """
    bridge = _require_bridge()
    from pydantic_ai import Tool

    async def list_files_t() -> list[str]:
        """List every file currently visible to the agent."""
        return sorted(bridge.fs_list())

    async def read_file_t(path: str) -> str:
        """Read the full text of a workspace file."""
        if not bridge.fs_exists(path):
            return f"ERROR: file not found: {path}"
        v = bridge.fs_read_any(path)
        if isinstance(v, bytes):
            return f"BINARY ({len(v)} bytes) — read via the Python tool to inspect."
        return v

    async def write_file_t(path: str, content: str) -> str:
        """Create or overwrite ``path`` with ``content`` (UTF-8)."""
        bridge.fs_write(path, content)
        return f"wrote {len(content)} bytes to {path}"

    async def edit_file_t(path: str, old: str, new: str) -> str:
        """First-match string replace inside ``path``."""
        if not bridge.fs_exists(path):
            return f"ERROR: file not found: {path}"
        current = bridge.fs_read(path)
        if old not in current:
            return f"ERROR: old text not found in {path}"
        bridge.fs_write(path, current.replace(old, new, 1))
        return f"edited {path}"

    return [
        Tool(list_files_t, name="list_files"),
        Tool(read_file_t, name="read_file"),
        Tool(write_file_t, name="write_file"),
        Tool(edit_file_t, name="edit_file"),
    ]


def python_tool(
    *,
    timeout: int = 60,
    default_packages: Optional[list[str]] = None,
):
    """Return a pydantic_ai ``Tool`` that lets the agent run Python
    code in the cell's workspace.

    Wire it alongside :func:`file_tools` so the agent can both author
    files (read/write/edit) and run scripts that compute, analyse, or
    generate artifacts (matplotlib charts, pandas tables, …)::

        agent = await gen.agent(
            system_prompt=...,
            tools=gen.file_tools() + [gen.python_tool(default_packages=["matplotlib"])],
        )

    The tool's signature exposed to the LLM is::

        run_python(code: str, packages: list[str] = []) -> str

    What the tool actually does:

      * Runs ``code`` as a subprocess with the workspace as cwd.
      * If ``packages`` is non-empty, spawns a fresh ephemeral env via
        ``uv run --no-project --with <pkg> ... -- python -c <code>`` so
        the agent can pull in libraries the generator's PEP 723 manifest
        didn't declare. Otherwise runs in the generator's own
        interpreter (deps from the manifest only).
      * Snapshots the workspace before/after via :meth:`snapshot` and
        auto-stages every new or modified file into ``tracked_writes``,
        so the next :func:`update` (or auto-flush at end of run)
        commits them as cell artifacts.
      * Returns the formatted ``return code + changed files + stdout/
        stderr`` block as a string for the agent to read.

    Args:
        timeout: Hard cap (seconds) per tool call. Cooperative
            cancellation via ``gen.cancelled`` is polled per output
            line by the underlying subprocess streamer.
        default_packages: Implicit packages installed for every
            ``run_python`` call when the agent doesn't pass its own.
            Useful for generators that always want, say, matplotlib.
    """
    bridge = _require_bridge()
    from pydantic_ai import Tool
    import sys

    default_pkgs = list(default_packages or [])

    async def run_python(
        code: str,
        packages: Optional[list[str]] = None,
    ) -> str:
        """Run a Python script in this cell's workspace.

        Args:
            code: Python source to run (multi-line OK).
            packages: Extra pip packages to install for this single
                run (e.g. ["matplotlib", "pandas"]). Empty / unset
                uses the generator's existing dependencies only.

        Files the script creates or modifies are auto-included in the
        cell — just write to relative paths from cwd. The script's
        stdout and stderr are merged and returned along with the exit
        code; raise inside the script to surface a traceback.
        """
        before = bridge.snapshot_workspace()

        pkgs = list(packages) if packages else default_pkgs
        if pkgs:
            cmd: list[str] = ["uv", "run", "--no-project"]
            for pkg in pkgs:
                cmd += ["--with", str(pkg)]
            cmd += ["python", "-c", code]
        else:
            cmd = [sys.executable, "-c", code]

        loop = asyncio.get_event_loop()
        rc, output = await loop.run_in_executor(
            None,
            lambda: bridge.run_streamed_subprocess(
                cmd,
                timeout=timeout,
                print_stdout=False,
                emit_bash_stdout=False,
            ),
        )

        after = bridge.snapshot_workspace()
        changed: list[str] = []
        for path, h in after.items():
            if before.get(path) != h:
                bridge.tracked_writes.add(path)
                changed.append(path)

        lines = [
            f"return code: {rc}",
            f"files created/modified: {sorted(changed) if changed else '(none)'}",
            "",
            "--- output ---",
            output if output else "(empty)",
        ]
        return "\n".join(lines)

    return Tool(run_python, name="run_python")


# ══════════════════════════════════════════════════════════════════════
# Tier B — Native-only extensions
# ══════════════════════════════════════════════════════════════════════


def workspace_path() -> str:
    """Real filesystem path to the workspace.

    Needed by Docker volume mounts, tools that take a cwd, and any path
    handed to a child process.
    """
    return _require_bridge().workspace


def progress(current: int, total: int) -> None:
    """Emit a live progress bar update."""
    _require_bridge().progress(current, total)


async def serve_port(
    port: int,
    *,
    name: str = "preview",
    path: str = "",
    snapshot_source: Optional[dict[str, str]] = None,
) -> None:
    """Bind ``port`` for daemon generators. The host opens a sandbox
    iframe on the cell at ``port``."""
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(
        None,
        lambda: bridge.serve_port(
            port, name=name, path=path, snapshot_source=snapshot_source,
        ),
    )


async def run_subprocess(
    command,
    *,
    turn_id: Optional[str] = None,
    timeout: int = 120,
    cwd: Optional[str] = None,
    shell: bool = False,
    emit_bash_stdout: bool = True,
    emit_text_delta: bool = False,
    print_stdout: bool = True,
) -> tuple[int, str]:
    """Spawn a subprocess and stream output. Returns
    ``(returncode, full_output)``. Cooperative cancellation: polls
    :func:`gen.cancelled` per line."""
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        None,
        lambda: bridge.run_streamed_subprocess(
            command=command,
            turn_id=turn_id,
            timeout=timeout,
            cwd=cwd,
            shell=shell,
            emit_bash_stdout=emit_bash_stdout,
            emit_text_delta=emit_text_delta,
            print_stdout=print_stdout,
        ),
    )


def snapshot(*, skip_dirs: Optional[set[str]] = None) -> dict[str, str]:
    """``{relpath: sha256_hex}`` for every workspace file."""
    return _require_bridge().snapshot_workspace(skip_dirs=skip_dirs)


async def terminal(
    container_id: str,
    command: list[str],
    *,
    cwd: Optional[str] = None,
    env: Optional[dict[str, str]] = None,
) -> dict:
    """Allocate a WebSocket-backed PTY session in a container.

    Returns ``{session_id, ws_path, token}``. Typical pattern: dump
    this dict (plus a human ``label``) into a ``<name>.terminal`` file
    via :func:`update_file` so the cell renders the live terminal.
    """
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        None,
        lambda: bridge.start_terminal(
            container_id=container_id, command=command, cwd=cwd, env=env,
        ),
    )


def stop_terminal(session_id: str) -> None:
    """Tear down a terminal. Idempotent."""
    _require_bridge().stop_terminal(session_id)


async def wait_for_action(timeout: Optional[float] = None) -> Optional[str]:
    """Block until a renderer emits an action, or ``timeout`` elapses,
    or Stop is requested. Returns the action id or ``None``."""
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    deadline = None if timeout is None else loop.time() + timeout
    while True:
        if bridge.cancelled:
            return None
        action = await loop.run_in_executor(None, bridge.poll_renderer_action)
        if action:
            return action
        if deadline is not None and loop.time() >= deadline:
            return None
        await asyncio.sleep(0.15)


async def request_settings(settings_file_path: str) -> dict:
    """Pop a ``.set_yaml`` settings overlay mid-run; block until the
    user presses Continue and return the updated values dict."""
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    try:
        return await loop.run_in_executor(
            None, lambda: bridge.request_settings_update(settings_file_path),
        )
    except _StopRequested as exc:
        raise Cancelled("settings update cancelled") from exc


def emit_stream_event(turn_id: str, event: dict) -> None:
    """Push a typed stream event to the cell's live renderer.

    Fire-and-forget. The host routes the event to the WebSocket of the chat
    session bound to this cell; the renderer reducer interprets ``event``
    (e.g. ``{"type": "text_delta", "text": ...}``). Most generators use
    :class:`ChatTurn`'s ``delta``/``tool`` rather than calling this directly.
    """
    _require_bridge().stream_event(turn_id, event)


class ChatTurn:
    """One chat turn handed to a :func:`serve_chat` handler.

    The handler streams the assistant reply via :meth:`delta` / :meth:`tool`
    (or ``gen.agent_chat_turn(turn, agent)``) and may observe :attr:`cancelled`
    (set on interrupt or redirect). :func:`serve_chat` brackets the handler
    with ``turn_start`` / ``turn_end`` events automatically, so the handler
    only emits the deltas in between.
    """

    def __init__(self, user_msg: str, turn_id: str, hist: "_History", emit_fn) -> None:
        self.user_msg = user_msg
        self.turn_id = turn_id
        self.history = hist
        self.cancelled = False
        self.redirect: Optional[str] = None
        self._emit = emit_fn

    def emit(self, event: dict) -> None:
        self._emit(self.turn_id, event)

    def delta(self, text: str) -> None:
        self.emit({"type": "text_delta", "text": text})

    def tool(self, name: str, status: str = "running", **kw) -> None:
        self.emit({"type": "tool", "name": name, "status": status, **kw})


async def serve_chat(
    on_turn,
    *,
    label: str = "Live Chat",
    log_file: str = "conversation.chatlog",
    live_file: str = "conversation.chatlive",
    resume: bool = True,
) -> None:
    """Serve a live, streaming chat against this run until Stop.

    Registers a chat session, writes & pins the ``.chatlive`` pointer (so the
    chat renderer connects its WebSocket), optionally seeds history from an
    existing ``.chatlog`` (``resume``), then dispatches each inbound user
    message to ``on_turn(turn)``. Your handler streams the reply — typically
    one line, ``reply = await gen.agent_chat_turn(turn, agent)`` — and records
    it with ``gen.history.append`` + ``gen.update``. Interrupt and redirect
    arrive on the in-flight turn as ``turn.cancelled`` / ``turn.redirect``.

    On exit the durable ``.chatlog`` transcript is flushed and re-pinned, so a
    closed chat lands on its readable, editable record.
    """
    import json
    import uuid

    from collimate.pointers import chat_live_pointer

    bridge = _require_bridge()
    loop = asyncio.get_event_loop()

    history.log_file = log_file
    if resume:
        try:
            history.seed_from_chatlog()
        except Exception:
            bridge.log.exception("serve_chat: resume seed failed")

    info = await loop.run_in_executor(None, bridge.chat_register)
    update_file(
        live_file,
        json.dumps(chat_live_pointer(info, label=label, log_file=log_file)),
    )
    # Materialize the .chatlog now so the renderer's history read + the
    # close fallback always resolve, even before the first turn.
    history._flush()
    await update(pinned=live_file)

    current: list[Optional[ChatTurn]] = [None]
    pending: set = set()

    async def _run_turn(content: str) -> None:
        turn = ChatTurn(content, uuid.uuid4().hex, history, bridge.stream_event)
        current[0] = turn
        bridge.stream_event(turn.turn_id, {"type": "turn_start"})
        try:
            await on_turn(turn)
        except (Cancelled, _StopRequested):
            raise
        except Exception as exc:
            bridge.log.exception("serve_chat: on_turn failed")
            bridge.stream_event(turn.turn_id, {"type": "error", "message": str(exc)})
        finally:
            bridge.stream_event(turn.turn_id, {"type": "turn_end"})
            current[0] = None
        # Redirect: the turn was cancelled with replacement text — run it
        # transparently as the next turn.
        if turn.redirect is not None:
            await _run_turn(turn.redirect)

    try:
        while not bridge.cancelled:
            cmd = await loop.run_in_executor(None, bridge.chat_poll)
            if not cmd:
                await asyncio.sleep(_CHAT_POLL_INTERVAL_S)
                continue
            kind = cmd.get("kind", "")
            if kind == "user_msg":
                content = cmd.get("content", "") or ""
                if current[0] is None:
                    t = asyncio.ensure_future(_run_turn(content))
                    pending.add(t)
                    t.add_done_callback(pending.discard)
                else:
                    # A message sent mid-turn is a redirect.
                    current[0].redirect = content
                    current[0].cancelled = True
            elif kind == "interrupt":
                if current[0] is not None:
                    current[0].cancelled = True
            elif kind == "redirect":
                if current[0] is not None:
                    current[0].redirect = cmd.get("content", "") or ""
                    current[0].cancelled = True
    finally:
        if pending:
            await asyncio.wait(list(pending), timeout=2.0)
        for t in list(pending):
            t.cancel()
        try:
            history._flush()
            await update(pinned=log_file)
        except Exception:
            bridge.log.exception("serve_chat: final chatlog flush failed")


_CHAT_POLL_INTERVAL_S = 0.2


# ──────────────────────────────────────────────────────────────────────
# Entrypoint helper
# ──────────────────────────────────────────────────────────────────────


# ──────────────────────────────────────────────────────────────────────
# Composition — discover / spawn / call other generators, and compile-check
# a renderer. Host-backed, public to every generator (the builders use the
# same surface, no private powers). Invisible by default: spawning creates
# no cell unless you pass surface=. In dev mode (no host) these degrade to a
# clean "no host" result — never hanging, never raising.
# ──────────────────────────────────────────────────────────────────────


class Source:
    """An inline, uninstalled generator passed to :func:`spawn` / :func:`call`.

    Wraps a staged file set + entrypoint so a builder can validate a
    just-authored candidate without installing it. Build via :func:`inline`.
    """

    __slots__ = ("files", "entrypoint")

    def __init__(self, files: dict, entrypoint: str) -> None:
        self.files = dict(files)
        self.entrypoint = entrypoint

    def _payload(self) -> dict:
        return {"inline": {"files": _encode_files(self.files), "entrypoint": self.entrypoint}}


class SurfaceSpec:
    """How to surface a (parent-bound) sub-run as a visible cell."""

    __slots__ = ("name",)

    def __init__(self, name: str = "Preview") -> None:
        self.name = name

    def _to_dict(self) -> dict:
        return {"name": self.name}


def inline(files: dict, *, entrypoint: str) -> Source:
    """Wrap staged files as a spawnable source (an uninstalled candidate)."""
    return Source(files, entrypoint)


def _source_payload(source) -> dict:
    if isinstance(source, Source):
        return source._payload()
    return {"id": str(source)}


def generators(*, group: Optional[str] = None) -> list:
    """List generators available to spawn/call (host-backed; ``[]`` in dev
    mode). Returns :class:`GeneratorInfo` objects ordered by the host.
    Pass ``group`` to filter to a single group (the generator-source cell
    name) — replaces the old ``category`` filter."""
    raw = _require_bridge().list_generators()
    infos = [_info_from_dict(d) for d in raw if isinstance(d, dict)]
    if group is not None:
        infos = [i for i in infos if i.group == group]
    return infos


class ProcessHandle:
    """A long-running process started in a child environment via
    :meth:`GeneratorHandle.exec_background`. Reaped when the environment is
    torn down; ``.stop()`` / ``.wait()`` are idempotent / dev-mode safe."""

    def __init__(self, handle: "GeneratorHandle", process_id: str) -> None:
        self._handle = handle
        self.id = process_id

    async def wait(self, *, timeout: Optional[float] = None) -> int:
        """Block until the process exits; return its return code (``-1`` when
        unavailable)."""
        if not self.id:
            return -1
        ack = await self._handle._run(
            lambda: self._handle._bridge.sub_run_wait_process(
                self._handle.id, self.id, timeout=timeout
            )
        )
        return int(ack.get("rc", -1))

    async def stop(self) -> None:
        """Terminate the process. Idempotent."""
        if not self.id:
            return
        await self._handle._run(
            lambda: self._handle._bridge.sub_run_stop_process(self._handle.id, self.id)
        )


class GeneratorHandle:
    """Live handle to a parent-bound child sub-run — terminating or daemon.

    The child is stopped automatically when the parent run ends or the
    async-context exits. Invisible until :meth:`surface` is called. All
    methods degrade to a benign value when there is no host (dev mode)."""

    def __init__(self, bridge, sub_run_id: str, source) -> None:
        self._bridge = bridge
        self.id = sub_run_id
        self.source = source
        self._stopped = False

    async def _run(self, fn):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, fn)

    async def endpoints(self, *, wait: bool = True, timeout: Optional[float] = 30.0) -> list:
        """Ports/terminals the child has bound. When ``wait`` (default),
        polls until the first appears or ``timeout`` elapses."""
        if not self.id:
            return []
        loop = asyncio.get_event_loop()
        deadline = None if (not wait or timeout is None) else loop.time() + timeout
        while True:
            eps = await self._run(lambda: self._bridge.sub_run_endpoints(self.id))
            if eps or not wait:
                return [_endpoint_from_dict(e) for e in eps if isinstance(e, dict)]
            # A finished/failed child will never bind a port — stop polling
            # even when timeout is None.
            if (await self._run(lambda: self._bridge.sub_run_status(self.id))) in ("done", "failed"):
                return []
            if self._bridge.cancelled or (deadline is not None and loop.time() >= deadline):
                return []
            await asyncio.sleep(0.15)

    async def status(self) -> str:
        """``"running"`` | ``"done"`` | ``"failed"``."""
        if not self.id:
            return "failed"
        return await self._run(lambda: self._bridge.sub_run_status(self.id))

    async def files(self) -> dict:
        """The child's output files so far."""
        if not self.id:
            return {}
        return _decode_files(await self._run(lambda: self._bridge.sub_run_files(self.id)))

    async def wait(self, *, timeout: Optional[float] = None) -> GeneratorResult:
        """Block until the child finishes; return its :class:`GeneratorResult`."""
        if not self.id:
            return GeneratorResult(ok=False, error="no host available")
        ack = await self._run(lambda: self._bridge.sub_run_wait(self.id, timeout))
        return _result_from_ack(ack)

    async def stop(self) -> None:
        """Idempotent teardown."""
        if not self.id or self._stopped:
            return
        self._stopped = True
        await self._run(lambda: self._bridge.stop_sub_run(self.id))

    async def surface(self, spec=None) -> str:
        """Promote the (parent-bound) sub-run to a visible cell in the
        parent's stack. Returns the new cell id."""
        if not self.id:
            return ""
        d = spec._to_dict() if isinstance(spec, SurfaceSpec) else (spec or {})
        return await self._run(lambda: self._bridge.surface_sub_run(self.id, d))

    # ── Environment surface — drive a child environment ──────────────
    # `capabilities` tells you the contract; the workspace plane (files) is
    # host-serviced and guaranteed; the execution plane (exec/exec_background/
    # expose_port/open_terminal) is routed to the child environment. All
    # degrade to a benign value when there is no host / no environment.

    async def capabilities(self) -> Optional[EnvironmentSpec]:
        """The :class:`EnvironmentSpec` this child offers, or ``None`` when it
        is not an environment (or no host)."""
        if not self.id:
            return None
        d = await self._run(lambda: self._bridge.sub_run_capabilities(self.id))
        return _env_spec_from_dict(d) if d is not None else None

    # --- workspace plane (host-serviced, guaranteed) ---

    async def put_files(self, files: dict) -> None:
        """Write a ``{path: str|bytes}`` map into the child's workspace (the
        generator-driven twin of live-file editing)."""
        if not self.id or not files:
            return
        await self._run(lambda: self._bridge.sub_run_put_files(self.id, dict(files)))

    async def write_file(self, path: str, content) -> None:
        """Single-file :meth:`put_files`."""
        await self.put_files({path: content})

    async def read_file(self, path: str):
        """Read one file from the child's workspace. utf-8 → ``str`` else
        ``bytes``. Raises ``FileNotFoundError`` when absent."""
        if not self.id:
            raise FileNotFoundError(path)
        ack = await self._run(lambda: self._bridge.sub_run_read_file(self.id, path))
        if not ack.get("ok"):
            raise FileNotFoundError(path)
        decoded = _decode_files(ack.get("file") or {})
        if path not in decoded:
            raise FileNotFoundError(path)
        return decoded[path]

    async def delete_file(self, path: str) -> None:
        """Delete one file from the child's workspace."""
        if not self.id:
            return
        await self._run(lambda: self._bridge.sub_run_delete_file(self.id, path))

    async def list_files(self) -> list:
        """Sorted paths in the child's workspace."""
        if not self.id:
            return []
        return list(await self._run(lambda: self._bridge.sub_run_list_files(self.id)))

    async def snapshot(self) -> dict:
        """``{relpath: sha256}`` of the child's workspace — pair before/after an
        :meth:`exec` to see what changed."""
        if not self.id:
            return {}
        return dict(await self._run(lambda: self._bridge.sub_run_snapshot(self.id)))

    async def watch_files(self, *, interval: float = 1.0):
        """Async stream of ``{path, change}`` events under the child's
        workspace. Pull-based (diffs :meth:`snapshot`), so it works without a
        host push channel. Exits when the run is cancelled."""
        if not self.id:
            return
        prev = await self.snapshot()
        while not self._bridge.cancelled:
            await asyncio.sleep(interval)
            cur = await self.snapshot()
            for p in sorted(p for p in cur if prev.get(p) != cur[p]):
                yield {"path": p, "change": "modified"}
            for p in sorted(p for p in prev if p not in cur):
                yield {"path": p, "change": "deleted"}
            prev = cur

    # --- execution plane (routed to the environment) ---

    async def exec(self, command, *, cwd: Optional[str] = None,
                   env: Optional[dict] = None, timeout: int = 120) -> tuple:
        """Run ``command`` in the child environment; return ``(rc, output)``.
        ``(-1, error)`` when there is no host / the environment is gone."""
        if not self.id:
            return (-1, "")
        ack = await self._run(
            lambda: self._bridge.sub_run_exec(self.id, command, cwd=cwd, env=env, timeout=timeout)
        )
        if not ack.get("ok", True):
            return (int(ack.get("rc", -1)), ack.get("error") or ack.get("output", ""))
        return (int(ack.get("rc", -1)), ack.get("output", ""))

    async def exec_background(self, command, *, cwd: Optional[str] = None,
                             env: Optional[dict] = None) -> "ProcessHandle":
        """Start a long-running process in the child environment; return a
        :class:`ProcessHandle` (``.wait()`` / ``.stop()``)."""
        if not self.id:
            return ProcessHandle(self, "")
        ack = await self._run(
            lambda: self._bridge.sub_run_exec_background(self.id, command, cwd=cwd, env=env)
        )
        return ProcessHandle(self, ack.get("process_id", ""))

    async def expose_port(self, port: int) -> Endpoint:
        """Expose a container port from the child environment; return the
        :class:`Endpoint` (also appears in :meth:`endpoints`)."""
        if not self.id:
            return Endpoint(kind="http", port=port)
        ack = await self._run(lambda: self._bridge.sub_run_expose_port(self.id, port))
        return _endpoint_from_dict(ack.get("endpoint") or {"kind": "http", "port": port})

    async def open_terminal(self, command=None, *, cwd: Optional[str] = None,
                            env: Optional[dict] = None) -> dict:
        """Open an interactive PTY in the child environment (declared
        ``terminals: N``). Returns ``{session_id, ws_path, token}`` (``{}`` when
        unavailable) — drop it into a ``.terminal`` pointer or surface it."""
        if not self.id:
            return {}
        return await self._run(
            lambda: self._bridge.sub_run_open_terminal(self.id, command or ["bash"], cwd=cwd, env=env)
        )

    async def __aenter__(self) -> "GeneratorHandle":
        return self

    async def __aexit__(self, *exc) -> None:
        await self.stop()


def spawn(
    source,
    *,
    inputs: Optional[dict] = None,
    input_groups: Optional[dict] = None,
    prompt: str = "",
    invocation_type: str = "create",
    config: Optional[dict] = None,
    secrets: Optional[list] = None,
    surface=None,
) -> GeneratorHandle:
    """Start a child generator as a parent-bound sub-run and return a live
    handle immediately. Works for terminating AND daemon children. Invisible
    unless ``surface=`` is given. ``source`` is an installed generator id or
    a :func:`inline` candidate."""
    bridge = _require_bridge()
    surface_d = surface._to_dict() if isinstance(surface, SurfaceSpec) else surface
    sub_run_id = bridge.start_sub_run(
        _source_payload(source),
        inputs=inputs, input_groups=input_groups, prompt=prompt,
        invocation_type=invocation_type, config=config, secrets=secrets,
        surface=surface_d,
    )
    return GeneratorHandle(bridge, sub_run_id, source)


async def call(
    source,
    *,
    inputs: Optional[dict] = None,
    input_groups: Optional[dict] = None,
    prompt: str = "",
    invocation_type: str = "create",
    config: Optional[dict] = None,
    secrets: Optional[list] = None,
    timeout: Optional[float] = 300.0,
) -> GeneratorResult:
    """Sugar for the terminating case — spawn, wait, stop. Child failure
    returns ``ok=False`` (call :meth:`GeneratorResult.raise_for_status` to
    opt into raising). Do NOT ``call()`` a daemon (it never completes) —
    ``spawn()`` it and read :meth:`GeneratorHandle.endpoints`."""
    handle = spawn(
        source, inputs=inputs, input_groups=input_groups, prompt=prompt,
        invocation_type=invocation_type, config=config, secrets=secrets,
    )
    try:
        return await handle.wait(timeout=timeout)
    finally:
        # Best-effort teardown — must never replace an in-flight exception
        # (e.g. a broken-socket emit during stop).
        try:
            await handle.stop()
        except Exception:
            pass


def check_renderer(files: dict, *, entrypoint: str) -> RendererCheck:
    """Compile-check a renderer via the host's esbuild — a public capability
    any generator can call (the renderer-builder uses exactly this). Returns
    ``ok=False`` with a diagnostic in dev mode (no host)."""
    ack = _require_bridge().check_renderer(dict(files), entrypoint)
    return RendererCheck(
        ok=bool(ack.get("ok", False)),
        errors=list(ack.get("errors") or []),
        warnings=list(ack.get("warnings") or []),
    )


# ──────────────────────────────────────────────────────────────────────
# Environments — the environment-author side. A daemon generator that owns a
# runtime calls serve_environment(...) to field its parent's exec/file/port
# requests (the typed twins of the surfaces a human drives on the cell). The
# Docker boilerplate + default handlers live in the generators' _env_shared
# raw runtime primitive the helper fills. Dev-mode safe: with no host, the
# poll yields nothing and the loop idles until Stop (it is a daemon).
# ──────────────────────────────────────────────────────────────────────


_EXEC_OUTPUT_CAP = 8_000_000  # keep a routed reply under the host's 10MB IPC frame limit


async def _maybe_await(fn, request):
    # Run the handler in a worker thread: a sync handler (e.g. a blocking
    # docker exec, or wait_process polling) must not freeze the serve-loop
    # event thread. An async handler just builds its coroutine off-thread (cheap)
    # and is awaited back on the loop.
    loop = asyncio.get_event_loop()
    res = await loop.run_in_executor(None, lambda: fn(request))
    if asyncio.iscoroutine(res):
        return await res
    return res


def _normalize_exec_result(res) -> tuple:
    """Coerce an on_exec handler's return to ``(rc, output)``."""
    if isinstance(res, tuple) and len(res) == 2:
        rc, output = res
        return int(rc), _as_text(output)
    if isinstance(res, dict):
        return int(res.get("rc", 0)), _as_text(res.get("output", ""))
    return 0, _as_text(res)


def _as_text(v) -> str:
    if isinstance(v, bytes):
        return v.decode("utf-8", errors="replace")
    return "" if v is None else str(v)


def _endpoint_payload(res, *, default_port=None) -> dict:
    if isinstance(res, Endpoint):
        return {"kind": res.kind, "name": res.name, "url": res.url,
                "port": res.port, "path": res.path, "session_id": res.session_id}
    if isinstance(res, dict):
        return res
    if isinstance(res, str):
        return {"kind": "http", "url": res, "port": default_port}
    return {"kind": "http", "port": default_port}


async def serve_environment(
    *,
    on_exec=None,
    on_exec_background=None,
    on_expose_port=None,
    on_terminal=None,
    on_wait_process=None,
    on_stop_process=None,
    max_concurrency: int = 1,
) -> None:
    """Serve parent requests against this run's runtime until Stop.

    Register the handlers your environment supports; each receives a typed
    :class:`Request` and **returns** its result (the loop sends the reply):

    - ``on_exec(req) -> (rc, output)`` — run ``req.command``, one-shot.
    - ``on_exec_background(req) -> process_id`` — start a long-running process.
    - ``on_wait_process(req) -> rc`` / ``on_stop_process(req)`` — its lifecycle.
    - ``on_expose_port(req) -> Endpoint | url | dict`` — expose ``req.port``.
    - ``on_terminal(req) -> {session_id, ws_path, token}`` — open a PTY.

    Handlers may be sync or async (sync ones run in a worker thread). Blocks
    until the user clicks Stop. Each request is dispatched as its own task so a
    long ``wait_process`` never blocks a subsequent ``stop_process`` (the two are
    a lifecycle pair); the serve loop is the *only* IPC user (poll + replies),
    so the per-bridge IPC lock never starves replies. The
    ``_env_shared.DockerEnvironment`` helper (shared generator code) fills these
    from a container, so most environments never call this directly.
    """
    bridge = _require_bridge()
    loop = asyncio.get_event_loop()
    spec = {
        "exec": on_exec is not None,
        "exec_background": on_exec_background is not None,
        "expose_port": on_expose_port is not None,
        "terminals_handler": on_terminal is not None,
    }
    await loop.run_in_executor(None, lambda: bridge.serve_environment_register(spec))

    handlers = {
        "exec": on_exec,
        "exec_background": on_exec_background,
        "wait_process": on_wait_process,
        "stop_process": on_stop_process,
        "expose_port": on_expose_port,
        "open_terminal": on_terminal,
    }

    reply_q: "asyncio.Queue" = asyncio.Queue()
    pending: set = set()

    async def _handle(request: dict) -> None:
        result = await _compute_env_result(request, handlers)
        await reply_q.put((request.get("request_id", ""), result))

    try:
        while not bridge.cancelled:
            # Flush ready replies first (the loop is the sole IPC user, so poll
            # and reply never race for the IPC lock).
            while not reply_q.empty():
                rid, result = reply_q.get_nowait()
                await loop.run_in_executor(
                    None, lambda rid=rid, result=result: bridge.serve_environment_reply(rid, result)
                )
            # Short poll so replies/cancellation cycle within ~1s.
            req = await loop.run_in_executor(None, lambda: bridge.serve_environment_poll(1.0))
            if not req:
                continue
            t = asyncio.ensure_future(_handle(req))
            pending.add(t)
            t.add_done_callback(pending.discard)
    finally:
        # Give in-flight handlers a short grace to finish + flush their replies,
        # then cancel any that are still blocked (e.g. a forever wait_process).
        if pending:
            await asyncio.wait(list(pending), timeout=2.0)
        while not reply_q.empty():
            rid, result = reply_q.get_nowait()
            try:
                await loop.run_in_executor(
                    None, lambda rid=rid, result=result: bridge.serve_environment_reply(rid, result)
                )
            except Exception:
                pass
        for t in list(pending):
            t.cancel()


async def _compute_env_result(req: dict, handlers: dict) -> dict:
    kind = req.get("kind", "")
    r = Request(
        kind=kind,
        command=req.get("command"),
        cwd=req.get("cwd", "") or "",
        env=req.get("env") or {},
        port=req.get("port"),
        process_id=req.get("process_id"),
        timeout=req.get("timeout"),
    )
    fn = handlers.get(kind)
    try:
        if fn is None:
            return {"ok": False, "error": f"environment does not serve {kind!r}"}
        if kind == "exec":
            rc, output = _normalize_exec_result(await _maybe_await(fn, r))
            if len(output) > _EXEC_OUTPUT_CAP:  # keep the reply under the IPC frame limit
                output = output[:_EXEC_OUTPUT_CAP] + "\n[output truncated]"
            return {"ok": True, "rc": rc, "output": output}
        if kind == "exec_background":
            return {"ok": True, "process_id": str(await _maybe_await(fn, r) or "")}
        if kind == "wait_process":
            return {"ok": True, "rc": int(await _maybe_await(fn, r) or 0)}
        if kind == "stop_process":
            await _maybe_await(fn, r)
            return {"ok": True}
        if kind == "expose_port":
            return {"ok": True, "endpoint": _endpoint_payload(await _maybe_await(fn, r), default_port=r.port)}
        if kind == "open_terminal":
            sess = await _maybe_await(fn, r)
            return {"ok": True, **(dict(sess) if isinstance(sess, dict) else {})}
        return {"ok": False, "error": f"unknown request kind {kind!r}"}
    except Exception as exc:  # a failing handler must not kill the serve loop
        return {"ok": False, "error": str(exc)}


def main(run_fn) -> None:
    """Run a generator's ``run`` function under the singleton API.

    Construct the IPC bridge, hydrate the singleton, dispatch ``run_fn``
    (sync or async), auto-flush any pending writes to the cell, and emit
    the finish IPC. Catches :class:`Cancelled` and :class:`_StopRequested`
    as graceful stop; every other exception is reported via the run's error
    channel.

    **Auto-flush**: if ``run_fn`` returns cleanly with files written via
    :func:`update_file` (including the ``.chatlog`` transcript) but never
    called :func:`update`, this commits them as the final cell state.
    Generators that explicitly want an empty placeholder simply don't write
    anything — same as before.
    """
    bridge = HostBridge()
    _set_bridge(bridge)
    try:
        if asyncio.iscoroutinefunction(run_fn):
            asyncio.run(run_fn())
        else:
            run_fn()
        if bridge.tracked_writes or bridge.tracked_deletions:
            try:
                deleted = sorted(bridge.tracked_deletions) or None
                bridge.tracked_deletions.clear()
                bridge.update_cell(deleted_files=deleted)
            except Exception:
                bridge.log.exception("auto-flush update_cell failed")
        bridge.finish(success=True)
    except (Cancelled, _StopRequested):
        bridge.log.info("Stopped gracefully by user.")
        bridge.finish(success=False, error_message="Stopped by user")
    except Exception as exc:
        bridge.log.exception("Generator failed")
        bridge.finish(success=False, error_message=str(exc))
    finally:
        _clear_bridge()


__all__ = [
    # Result / spec types (shared with collimate.testing + composition)
    "CellRecord",
    "Endpoint",
    "EnvironmentSpec",
    "GeneratorInfo",
    "GeneratorResult",
    "RendererCheck",
    "Request",
    # Composition + renderer compile (host-backed; dev-mode safe)
    "GeneratorHandle",
    "ProcessHandle",
    "Source",
    "SurfaceSpec",
    "call",
    "check_renderer",
    "generators",
    "inline",
    "serve_environment",
    "spawn",
    # Exceptions
    "Cancelled",
    "IPCDisconnectedError",
    "IPCError",
    "IPCNakError",
    "IPCTimeoutError",
    # Inputs / config
    "config",
    "input_files",
    "input_groups",
    "read_input",
    # Output stage
    "delete_file",
    "has_file",
    "list_files",
    "read_file",
    "update_file",
    # Cell ops
    "create_stack_cell",
    "update",
    # Chat
    "ChatTurn",
    "agent_chat_turn",
    "emit_stream_event",
    "history",
    "serve_chat",
    # Secrets
    "api_key",
    "secret",
    # Status / control
    "log",
    "progress",
    "status",
    # LLM convenience
    "agent",
    "file_tools",
    "python_tool",
    # Native filesystem / subprocess / ports / terminals
    "request_settings",
    "run_subprocess",
    "serve_port",
    "snapshot",
    "stop_terminal",
    "terminal",
    "wait_for_action",
    "workspace_path",
    # Entrypoint
    "main",
]
