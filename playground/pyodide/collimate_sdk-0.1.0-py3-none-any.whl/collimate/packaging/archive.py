# SPDX-License-Identifier: Apache-2.0
"""Read and write .colgen / .colrend tar.gz archives.

Archive layout (v2):
    manifest.json                   — version, type, cells (id/name/summary/files[name,language])
    cells/<cell_id>/<file paths...> — file contents

Legacy v1 fallback: any tar.gz/zip of raw files is wrapped as a single synthetic cell.
"""
import io
import json
import tarfile
import uuid
import zipfile

from .errors import PackageError
from .models import CellSpec, FileSpec, PackageManifest, PACKAGE_FORMAT_VERSION

_LANG_BY_EXT = {
    "py": "python", "js": "javascript", "ts": "typescript",
    "json": "json", "yaml": "yaml", "yml": "yaml",
    "md": "markdown", "css": "css", "html": "html",
}


def _lang_for(name: str) -> str:
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    return _LANG_BY_EXT.get(ext, "text")


def _safe_member(name: str) -> None:
    if name.startswith("/") or ".." in name:
        raise PackageError(f"Unsafe path in archive: {name}")


def read_archive(content: bytes) -> PackageManifest:
    """Parse a .colgen / .colrend archive. Accepts v2 tar.gz or legacy tar.gz/zip."""
    buf = io.BytesIO(content)
    manifest_dict: dict | None = None
    raw_files: list[tuple[str, str]] = []

    try:
        with tarfile.open(fileobj=buf, mode="r:gz") as tar:
            for member in tar.getmembers():
                _safe_member(member.name)
                if not member.isfile():
                    continue
                f = tar.extractfile(member)
                if not f:
                    continue
                data = f.read()
                if member.name == "manifest.json":
                    try:
                        manifest_dict = json.loads(data.decode("utf-8"))
                    except json.JSONDecodeError as e:
                        raise PackageError("manifest.json is not valid JSON") from e
                else:
                    raw_files.append((member.name, data.decode("utf-8", errors="replace")))
    except tarfile.TarError:
        buf.seek(0)
        try:
            with zipfile.ZipFile(buf) as zf:
                for name in zf.namelist():
                    _safe_member(name)
                    if name.endswith("/"):
                        continue
                    with zf.open(name) as f:
                        raw_files.append((name, f.read().decode("utf-8", errors="replace")))
        except zipfile.BadZipFile as e:
            raise PackageError("File is not a valid archive (tar.gz or zip)") from e

    if manifest_dict and manifest_dict.get("version") == PACKAGE_FORMAT_VERSION:
        body_by_cell: dict[str, list[FileSpec]] = {}
        for name, text in raw_files:
            if not name.startswith("cells/"):
                continue
            parts = name.split("/", 2)
            if len(parts) < 3:
                continue
            cell_id, file_path = parts[1], parts[2]
            body_by_cell.setdefault(cell_id, []).append(
                FileSpec(name=file_path, language=_lang_for(file_path), content=text)
            )
        cells = [
            CellSpec(
                id=c.get("id", ""),
                name=c.get("name", "Imported"),
                summary=c.get("summary", ""),
                files=body_by_cell.get(c.get("id", ""), []),
            )
            for c in manifest_dict.get("cells", [])
        ]
        return PackageManifest(
            version=PACKAGE_FORMAT_VERSION,
            type=manifest_dict.get("type"),
            cells=cells,
        )

    if not raw_files:
        raise PackageError("Archive is empty")
    return PackageManifest(
        version=1,
        type=None,
        cells=[
            CellSpec(
                id=str(uuid.uuid4()),
                name="Imported package",
                summary=f"Extracted {len(raw_files)} files from archive",
                files=[FileSpec(name=n, language=_lang_for(n), content=c) for n, c in raw_files],
            )
        ],
    )


def inspect(content: bytes) -> PackageManifest:
    """Same as read_archive but strips file bodies (metadata-only preview)."""
    manifest = read_archive(content)
    for cell in manifest.cells:
        cell.files = [FileSpec(name=f.name, language=f.language, content="") for f in cell.files]
    return manifest


def write_archive(cells: list[CellSpec], type: str) -> bytes:
    """Build a v2 .colgen / .colrend tar.gz. `type` is 'generator' or 'renderer'."""
    if type not in ("generator", "renderer"):
        raise PackageError("type must be 'generator' or 'renderer'")

    manifest = {
        "version": PACKAGE_FORMAT_VERSION,
        "type": type,
        "cells": [
            {
                "id": c.id,
                "name": c.name,
                "summary": c.summary,
                "files": [{"name": f.name, "language": f.language} for f in c.files],
            }
            for c in cells
        ],
    }

    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        manifest_bytes = json.dumps(manifest, indent=2).encode("utf-8")
        info = tarfile.TarInfo(name="manifest.json")
        info.size = len(manifest_bytes)
        tar.addfile(info, io.BytesIO(manifest_bytes))

        for cell in cells:
            for f in cell.files:
                safe_name = f.name.lstrip("/").replace("..", "_")
                arc_path = f"cells/{cell.id}/{safe_name}"
                file_bytes = f.content.encode("utf-8")
                finfo = tarfile.TarInfo(name=arc_path)
                finfo.size = len(file_bytes)
                tar.addfile(finfo, io.BytesIO(file_bytes))

    return buf.getvalue()
