# SPDX-License-Identifier: Apache-2.0
"""One-shot build: wheel + sdist + all release archives.

Usage:
    python -m collimate.packaging.build_all

Produces (in dist/):
    collimate_sdk-<version>-py3-none-any.whl
    collimate_sdk-<version>.tar.gz
    releases/starting.colgen
    releases/starting.colrend
    releases/wasm.colgen
    releases/wasm.colrend
    ... whatever else releases.yaml declares.

Thin wrapper around the two primitive commands — `python -m build` for
the PyPI artifacts, `python -m collimate.packaging.build_releases` for
the bundle archives. CI calls the two separately for clearer log
boundaries; humans can use this for a one-shot.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m collimate.packaging.build_all",
        description="Build wheel + sdist + release archives.",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=Path("dist"),
        help="Output directory (default: ./dist).",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("releases.yaml"),
        help="Releases config (default: ./releases.yaml).",
    )
    parser.add_argument(
        "--skip-wheel",
        action="store_true",
        help="Skip the wheel/sdist build (just archives).",
    )
    parser.add_argument(
        "--skip-archives",
        action="store_true",
        help="Skip the release-archives build (just wheel/sdist).",
    )
    args = parser.parse_args(argv)

    if not args.skip_wheel:
        print("=== python -m build ===")
        r = subprocess.run(
            [sys.executable, "-m", "build", "--outdir", str(args.out)],
            check=False,
        )
        if r.returncode != 0:
            return r.returncode

    if not args.skip_archives:
        print("=== python -m collimate.packaging.build_releases ===")
        r = subprocess.run(
            [
                sys.executable,
                "-m",
                "collimate.packaging.build_releases",
                "--config",
                str(args.config),
                "--out",
                str(args.out / "releases"),
            ],
            check=False,
        )
        if r.returncode != 0:
            return r.returncode

    return 0


if __name__ == "__main__":
    sys.exit(main())
