# SPDX-License-Identifier: Apache-2.0
"""Build .colgen / .colrend release archives from releases.yaml.

Usage:
    python -m collimate.packaging.build_releases --out dist/releases
    python -m collimate.packaging.build_releases --config releases.yaml --out dist/releases

The config file (default: ``releases.yaml`` at the current working dir)
declares one bundle per produced archive. Each bundle entry has:

    filename:  final archive name (``starting.colgen``, ``wasm.colrend``, …).
               Extension determines how the file is treated downstream
               (.colgen → generator, .colrend → renderer) and must agree
               with the ``kind`` field.
    kind:      ``generator`` or ``renderer``.
    include:   list of fnmatch-style globs (relative to the SDK repo
               root). A manifest is considered part of the bundle iff
               its path (``generators/Standard/foo/manifest.gen_yaml``,
               ``renderers/basic/monaco/manifest.rend_yaml``, etc.)
               matches at least one include glob.
    exclude:   optional list of globs that remove matches.

Membership is manifest-level: each matching ``manifest.gen_yaml`` /
``manifest.rend_yaml`` becomes one cell in the archive, and every file
in the manifest's directory (recursive) ships alongside.

In-archive file names preserve the generator/renderer's original path
relative to its asset-root (``generators/``, ``renderers/``). After
round-trip through ``install_archives``, the extracted tree looks
identical to the source tree — which lets the collimate app continue
to walk ``api/templates/generators/<group>/`` as it does today.
"""
from __future__ import annotations

import argparse
import fnmatch
import sys
import uuid
from dataclasses import dataclass
from pathlib import Path

import yaml

from .archive import write_archive
from .models import CellSpec, FileSpec


# Deterministic UUID namespace. Combined with a manifest's path-from-SDK-root,
# this gives each generator / renderer a stable cell id across builds — makes
# archives byte-reproducible and diffs easy to inspect.
_CELL_ID_NAMESPACE = uuid.UUID("0bda06ef-1a24-4c63-a6a4-3c6b86e85418")

_MANIFEST_FILES = {
    "generator": "manifest.gen_yaml",
    "renderer": "manifest.rend_yaml",
}

_SDK_ROOT = Path(__file__).resolve().parents[3]


@dataclass
class _Bundle:
    filename: str
    kind: str  # "generator" | "renderer"
    include: list[str]
    exclude: list[str]


def _load_config(path: Path) -> list[_Bundle]:
    text = path.read_text()
    data = yaml.safe_load(text)
    if not isinstance(data, dict) or "bundles" not in data:
        raise ValueError(f"{path}: expected a top-level 'bundles:' list")
    bundles_raw = data["bundles"]
    if not isinstance(bundles_raw, list):
        raise ValueError(f"{path}: 'bundles' must be a list")

    out: list[_Bundle] = []
    for i, entry in enumerate(bundles_raw):
        if not isinstance(entry, dict):
            raise ValueError(f"{path}: bundle #{i} must be a mapping")
        filename = entry.get("filename")
        kind = entry.get("kind")
        include = entry.get("include") or []
        exclude = entry.get("exclude") or []
        if not filename or not isinstance(filename, str):
            raise ValueError(f"{path}: bundle #{i} missing 'filename'")
        if kind not in ("generator", "renderer"):
            raise ValueError(
                f"{path}: bundle #{i} 'kind' must be 'generator' or 'renderer', got {kind!r}"
            )
        # Cross-check extension ↔ kind so a config typo fails the build
        # instead of producing a mislabeled archive.
        if kind == "generator" and not filename.endswith(".colgen"):
            raise ValueError(
                f"{path}: bundle #{i} kind=generator but filename does not end in .colgen"
            )
        if kind == "renderer" and not filename.endswith(".colrend"):
            raise ValueError(
                f"{path}: bundle #{i} kind=renderer but filename does not end in .colrend"
            )
        if not isinstance(include, list) or not include:
            raise ValueError(f"{path}: bundle #{i} needs a non-empty 'include' list")
        if not isinstance(exclude, list):
            raise ValueError(f"{path}: bundle #{i} 'exclude' must be a list if set")
        out.append(_Bundle(filename=filename, kind=kind, include=list(include), exclude=list(exclude)))
    return out


def _find_manifests(kind: str, sdk_root: Path) -> list[Path]:
    """Every manifest path of the given kind, relative to sdk_root."""
    manifest_name = _MANIFEST_FILES[kind]
    # Both native (generators/Standard/) and wasm (generators/WASM/)
    # trees live under a single generators/ root; renderers have their
    # own root.
    roots = ["generators", "renderers"]
    found: list[Path] = []
    for root in roots:
        search_root = sdk_root / root
        if not search_root.is_dir():
            continue
        for manifest in search_root.rglob(manifest_name):
            found.append(manifest.relative_to(sdk_root))
    return found


def _matches(rel_path: Path, patterns: list[str]) -> bool:
    s = rel_path.as_posix()
    return any(fnmatch.fnmatchcase(s, pat) for pat in patterns)


def _cell_for_manifest(manifest_rel: Path, sdk_root: Path) -> CellSpec:
    """Build a CellSpec from every file in the manifest's directory.

    File names inside the cell are relative to the manifest's asset-root
    parent (``generators/`` or ``renderers/``), so extraction
    reconstructs the original tree layout.
    """
    manifest_abs = sdk_root / manifest_rel
    gen_dir = manifest_abs.parent
    # asset_root is the top-level bucket (e.g. "generators" or
    # "renderers"); drop it from file names so after extraction into
    # "<out>/generators/" the final path matches the source.
    asset_root = manifest_rel.parts[0]
    strip_prefix = sdk_root / asset_root

    # Read manifest to pull name + summary; fall back to dir name if
    # either is missing.
    try:
        manifest_data = yaml.safe_load(manifest_abs.read_text()) or {}
    except yaml.YAMLError:
        manifest_data = {}
    display_name = manifest_data.get("name") or gen_dir.name
    summary = manifest_data.get("summary") or ""

    files: list[FileSpec] = []
    for path in sorted(gen_dir.rglob("*")):
        if not path.is_file():
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            # Skip binary blobs — archives are utf-8 only today. If a
            # generator/renderer needs binary assets later, extend the
            # archive format first.
            continue
        arc_name = path.relative_to(strip_prefix).as_posix()
        files.append(FileSpec(name=arc_name, language=_lang_for(arc_name), content=text))

    # Deterministic cell id — stable across builds for the same manifest.
    cell_id = str(uuid.uuid5(_CELL_ID_NAMESPACE, manifest_rel.as_posix()))
    return CellSpec(id=cell_id, name=str(display_name), summary=str(summary), files=files)


# Duplicated from archive.py (private) to avoid an import cycle and keep
# the table locally editable.
_LANG_BY_EXT = {
    "py": "python", "js": "javascript", "ts": "typescript", "tsx": "typescript",
    "json": "json", "yaml": "yaml", "yml": "yaml",
    "md": "markdown", "css": "css", "html": "html",
}


def _lang_for(name: str) -> str:
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    return _LANG_BY_EXT.get(ext, "text")


def build_bundle(bundle: _Bundle, sdk_root: Path) -> bytes:
    all_manifests = _find_manifests(bundle.kind, sdk_root)
    matched: list[Path] = []
    for rel in all_manifests:
        if not _matches(rel, bundle.include):
            continue
        if bundle.exclude and _matches(rel, bundle.exclude):
            continue
        matched.append(rel)
    if not matched:
        raise ValueError(
            f"Bundle {bundle.filename!r} matched zero manifests — include "
            f"globs may be wrong. Patterns: include={bundle.include!r} "
            f"exclude={bundle.exclude!r}"
        )
    cells = [_cell_for_manifest(rel, sdk_root) for rel in sorted(matched)]
    return write_archive(cells, type=bundle.kind)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m collimate.packaging.build_releases",
        description="Build .colgen / .colrend archives from releases.yaml.",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("releases.yaml"),
        help="Config file (default: ./releases.yaml).",
    )
    parser.add_argument(
        "--sdk-root",
        type=Path,
        default=_SDK_ROOT,
        help="Root of the SDK checkout to scan (default: this package's parent repo).",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=Path("dist/releases"),
        help="Output directory (default: ./dist/releases).",
    )
    args = parser.parse_args(argv)

    config_path = args.config if args.config.is_absolute() else Path.cwd() / args.config
    sdk_root = args.sdk_root.resolve()
    out_dir = args.out if args.out.is_absolute() else Path.cwd() / args.out

    if not config_path.is_file():
        print(f"error: config file not found at {config_path}", file=sys.stderr)
        return 2

    bundles = _load_config(config_path)
    out_dir.mkdir(parents=True, exist_ok=True)

    for b in bundles:
        try:
            archive_bytes = build_bundle(b, sdk_root)
        except ValueError as e:
            print(f"error: {e}", file=sys.stderr)
            return 2
        dest = out_dir / b.filename
        dest.write_bytes(archive_bytes)
        print(f"built {dest} ({len(archive_bytes):,} bytes, {b.kind})")

    return 0


if __name__ == "__main__":
    sys.exit(main())
