# SPDX-License-Identifier: Apache-2.0
"""Build .colgen / .colrend release archives from releases.yaml.

Usage:
    python -m collimate.packaging.build_releases --out dist/releases
    python -m collimate.packaging.build_releases --config releases.yaml --out dist/releases

The config file (default: ``releases.yaml`` at the current working dir)
declares one bundle per produced archive. Each bundle entry has:

    filename:  final archive name (``starting.colgen``, ``wasm.colrend``, …).
               Extension determines how the file is treated downstream
               (.colgen → generator, .colrend → renderer) and must agree
               with the ``kind`` field.
    kind:      ``generator`` or ``renderer``.
    cells:     named cell layout — each entry bakes a group of source
               folders into one cell of the archive.
    gen_root:  source root for generator folders, relative to the SDK
               root (defaults to ``generators``; the demo/playground wasm
               bundle sets ``demo/generators``).

In-archive file names preserve the generator/renderer's original path
relative to its asset-root (``generators/``, ``renderers/``). After
round-trip through ``install_archives``, the extracted tree looks
identical to the source tree — which lets the collimate app continue
to walk ``api/templates/generators/<group>/`` as it does today.
"""
from __future__ import annotations

import argparse
import posixpath
import sys
import uuid
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from .archive import write_archive
from .models import CellSpec, FileSpec


# Deterministic UUID namespace. Combined with a manifest's path-from-SDK-root,
# this gives each generator / renderer a stable cell id across builds — makes
# archives byte-reproducible and diffs easy to inspect.
_CELL_ID_NAMESPACE = uuid.UUID("0bda06ef-1a24-4c63-a6a4-3c6b86e85418")

_SDK_ROOT = Path(__file__).resolve().parents[3]


@dataclass
class _Bundle:
    filename: str
    kind: str  # "generator" | "renderer"
    runtime: str | None = None       # "native" | "wasm" (used by genesis, not here)
    cells: list = field(default_factory=list)  # named cell layout: the
    # archive is built as these grouped cells.
    gen_root: str | None = None      # source root for generator folders,
    # relative to the SDK root. Defaults to "generators" (the canonical
    # native tree); the demo/playground (wasm) bundle sets it to
    # "demo/generators" so its folders resolve out of the quarantined tree.


def _load_config(path: Path) -> list[_Bundle]:
    text = path.read_text()
    data = yaml.safe_load(text)
    if not isinstance(data, dict) or "bundles" not in data:
        raise ValueError(f"{path}: expected a top-level 'bundles:' list")
    bundles_raw = data["bundles"]
    if not isinstance(bundles_raw, list):
        raise ValueError(f"{path}: 'bundles' must be a list")

    out: list[_Bundle] = []
    for i, entry in enumerate(bundles_raw):
        if not isinstance(entry, dict):
            raise ValueError(f"{path}: bundle #{i} must be a mapping")
        filename = entry.get("filename")
        kind = entry.get("kind")
        runtime = entry.get("runtime")
        cells = entry.get("cells") or []
        gen_root = entry.get("gen_root")
        if not filename or not isinstance(filename, str):
            raise ValueError(f"{path}: bundle #{i} missing 'filename'")
        if kind not in ("generator", "renderer"):
            raise ValueError(
                f"{path}: bundle #{i} 'kind' must be 'generator' or 'renderer', got {kind!r}"
            )
        # Cross-check extension ↔ kind so a config typo fails the build
        # instead of producing a mislabeled archive.
        if kind == "generator" and not filename.endswith(".colgen"):
            raise ValueError(
                f"{path}: bundle #{i} kind=generator but filename does not end in .colgen"
            )
        if kind == "renderer" and not filename.endswith(".colrend"):
            raise ValueError(
                f"{path}: bundle #{i} kind=renderer but filename does not end in .colrend"
            )
        if not isinstance(cells, list) or not cells:
            raise ValueError(
                f"{path}: bundle #{i} needs a non-empty 'cells' layout"
            )
        out.append(_Bundle(
            filename=filename, kind=kind, runtime=runtime, cells=list(cells),
            gen_root=gen_root if isinstance(gen_root, str) else None,
        ))
    return out


# Duplicated from archive.py (private) to avoid an import cycle and keep
# the table locally editable.
_LANG_BY_EXT = {
    "py": "python", "js": "javascript", "ts": "typescript", "tsx": "typescript",
    "json": "json", "yaml": "yaml", "yml": "yaml",
    "md": "markdown", "css": "css", "html": "html",
}


def _lang_for(name: str) -> str:
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    return _LANG_BY_EXT.get(ext, "text")


def _cell_folder_sources(folder: str, asset_root: str, sdk_root: Path) -> list[tuple[Path, str]]:
    """Resolve a folders[] entry to (abs_dir, arc_base) pairs. A ``D/*`` entry
    expands to each immediate subdir of D by basename; a plain entry maps to
    its own basename (``basic/monaco`` -> ``monaco``, ``vscode_env`` -> ``vscode_env``)."""
    if folder.endswith("/*"):
        parent = sdk_root / asset_root / folder[:-2]
        if not parent.is_dir():
            print(f"warning: cell folder {folder!r} parent not found under {asset_root}/", file=sys.stderr)
            return []
        return [
            (child, child.name)
            for child in sorted(parent.iterdir())
            if child.is_dir() and not child.name.startswith("__")
        ]
    base = sdk_root / asset_root / folder
    return [(base, posixpath.basename(folder.rstrip("/")))]


def _files_for_source(abs_dir: Path, arc_base: str) -> list[FileSpec]:
    """Every utf-8 file under ``abs_dir``, named ``<arc_base>/<rel>`` so the
    cell holds the folder DIRECTLY (no generators/ or renderers/basic
    nesting). ``__``-prefixed paths and binaries are skipped."""
    out: list[FileSpec] = []
    if not abs_dir.is_dir():
        print(f"warning: cell folder {arc_base!r} not found at {abs_dir}", file=sys.stderr)
        return out
    for path in sorted(abs_dir.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(abs_dir)
        if any(part.startswith("__") for part in rel.parts):
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        arc = f"{arc_base}/{rel.as_posix()}"
        out.append(FileSpec(name=arc, language=_lang_for(arc), content=text))
    return out


def _cell_from_layout_entry(
    entry: dict, kind: str, sdk_root: Path, asset_root: str | None = None,
) -> CellSpec:
    """Build one named CellSpec from a ``releases.yaml`` ``cells[]`` entry.

    Bakes the same grouped, named cell the app shows into the archive, so
    importing the archive yields the identical structure genesis seeds. Each
    ``folders`` entry is placed under its basename (so the cell holds
    ``rrweb/…`` directly, not ``renderers/basic/rrweb/…``); ``shared_docs`` are
    copied from ``shared/docs/`` (or ``demo/docs/`` for demo assets like the
    WASM guide) into a top-level ``_shared_docs/`` sibling so co-located builder
    generators resolve them at run time. Mirrors
    api/genesis._seed_stack_from_layout.

    ``asset_root`` overrides where generator folders are sourced from
    (defaults to ``generators``/``renderers`` by kind); the demo bundle passes
    ``demo/generators`` so its folders resolve out of the quarantined tree."""
    if asset_root is None:
        asset_root = "generators" if kind == "generator" else "renderers"
    folders = entry.get("folders") or []
    shared_docs = entry.get("shared_docs") or []
    name = str(entry.get("name") or "Cell")

    files: list[FileSpec] = []
    for folder in folders:
        for abs_dir, arc_base in _cell_folder_sources(folder, asset_root, sdk_root):
            files.extend(_files_for_source(abs_dir, arc_base))

    for doc in shared_docs:
        # Canonical guides live in shared/docs/; demo-only guides (the WASM
        # authoring doc) live in demo/docs/. Search both.
        doc_path = sdk_root / "shared" / "docs" / doc
        if not doc_path.is_file():
            doc_path = sdk_root / "demo" / "docs" / doc
        if not doc_path.is_file():
            print(f"warning: shared_doc {doc!r} not found under shared/docs/ or demo/docs/", file=sys.stderr)
            continue
        arc = f"_shared_docs/{doc}"
        files.append(FileSpec(
            name=arc, language=_lang_for(arc),
            content=doc_path.read_text(encoding="utf-8"),
        ))

    cell_id = str(uuid.uuid5(_CELL_ID_NAMESPACE, f"{kind}-cell-{name}"))
    summary = str(entry.get("summary") or f"{kind.capitalize()}s — {name}")
    return CellSpec(id=cell_id, name=name, summary=summary, files=files)


def build_bundle(bundle: _Bundle, sdk_root: Path) -> bytes:
    # A 'cells' layout bakes the named cells into the archive.
    asset_root = bundle.gen_root if (bundle.kind == "generator" and bundle.gen_root) else None
    cells = [_cell_from_layout_entry(e, bundle.kind, sdk_root, asset_root) for e in bundle.cells]
    cells = [c for c in cells if c.files]
    if not cells:
        raise ValueError(
            f"Bundle {bundle.filename!r} has a 'cells' layout but produced "
            f"zero files — folder paths may be wrong."
        )
    return write_archive(cells, type=bundle.kind)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m collimate.packaging.build_releases",
        description="Build .colgen / .colrend archives from releases.yaml.",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("releases.yaml"),
        help="Config file (default: ./releases.yaml).",
    )
    parser.add_argument(
        "--sdk-root",
        type=Path,
        default=_SDK_ROOT,
        help="Root of the SDK checkout to scan (default: this package's parent repo).",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=Path("dist/releases"),
        help="Output directory (default: ./dist/releases).",
    )
    args = parser.parse_args(argv)

    config_path = args.config if args.config.is_absolute() else Path.cwd() / args.config
    sdk_root = args.sdk_root.resolve()
    out_dir = args.out if args.out.is_absolute() else Path.cwd() / args.out

    if not config_path.is_file():
        print(f"error: config file not found at {config_path}", file=sys.stderr)
        return 2

    bundles = _load_config(config_path)
    out_dir.mkdir(parents=True, exist_ok=True)

    for b in bundles:
        try:
            archive_bytes = build_bundle(b, sdk_root)
        except ValueError as e:
            print(f"error: {e}", file=sys.stderr)
            return 2
        dest = out_dir / b.filename
        dest.write_bytes(archive_bytes)
        print(f"built {dest} ({len(archive_bytes):,} bytes, {b.kind})")

    return 0


if __name__ == "__main__":
    sys.exit(main())
