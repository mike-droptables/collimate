# SPDX-License-Identifier: Apache-2.0
"""Build .colgen / .colrend release archives from the asset trees.

Usage:
    python -m collimate.packaging.build_releases --out dist/releases
    python -m collimate.packaging.build_releases --config releases.yaml --out dist/releases

The cell grouping is NOT configured here — the parent folders of the asset
tree ARE the cells (see :mod:`collimate.packaging.layout`): each immediate,
non-underscore subdirectory of the bundle's root becomes one named cell,
with its display name / summary / icon / order / shared libraries /
shared docs read from the folder's optional ``cell.yaml``.

The config file (default: ``releases.yaml`` at the current working dir)
only declares which archives to produce. Each bundle entry has:

    filename:  final archive name (``starting.colgen``, ``wasm.colrend``, …).
               Extension determines how the file is treated downstream
               (.colgen → generator, .colrend → renderer) and must agree
               with the ``kind`` field.
    kind:      ``generator`` or ``renderer``.
    runtime:   ``native`` or ``wasm`` (used by genesis seeding, not here).
    default:   marks the bundle genesis seeds for new channels.
    gen_root:  source root for generator bundles, relative to the SDK
               root (defaults to ``generators``; the demo/playground wasm
               bundle sets ``demo/generators``).

Inside a cell, each content folder is placed under its basename and shared
``_*`` libraries / ``_shared_docs`` are materialised alongside — so an
extracted cell is self-contained and identical to what genesis seeds.
"""
from __future__ import annotations

import argparse
import sys
import uuid
from dataclasses import dataclass
from pathlib import Path

import yaml

from .archive import write_archive
from .layout import CELL_MANIFEST, CellLayout, scan_cells, shared_dir
from .models import CellSpec, FileSpec

# Deterministic UUID namespace. Combined with the cell name, this gives each
# cell a stable id across builds — makes archives byte-reproducible and
# diffs easy to inspect.
_CELL_ID_NAMESPACE = uuid.UUID("0bda06ef-1a24-4c63-a6a4-3c6b86e85418")

_SDK_ROOT = Path(__file__).resolve().parents[3]


@dataclass
class _Bundle:
    filename: str
    kind: str  # "generator" | "renderer"
    runtime: str | None = None       # "native" | "wasm" (used by genesis, not here)
    gen_root: str | None = None      # source root for generator folders,
    # relative to the SDK root. Defaults to "generators" (the canonical
    # native tree); the demo/playground (wasm) bundle sets it to
    # "demo/generators" so its folders resolve out of the quarantined tree.


def _load_config(path: Path) -> list[_Bundle]:
    text = path.read_text()
    data = yaml.safe_load(text)
    if not isinstance(data, dict) or "bundles" not in data:
        raise ValueError(f"{path}: expected a top-level 'bundles:' list")
    bundles_raw = data["bundles"]
    if not isinstance(bundles_raw, list):
        raise ValueError(f"{path}: 'bundles' must be a list")

    out: list[_Bundle] = []
    for i, entry in enumerate(bundles_raw):
        if not isinstance(entry, dict):
            raise ValueError(f"{path}: bundle #{i} must be a mapping")
        filename = entry.get("filename")
        kind = entry.get("kind")
        runtime = entry.get("runtime")
        gen_root = entry.get("gen_root")
        if not filename or not isinstance(filename, str):
            raise ValueError(f"{path}: bundle #{i} missing 'filename'")
        if kind not in ("generator", "renderer"):
            raise ValueError(
                f"{path}: bundle #{i} 'kind' must be 'generator' or 'renderer', got {kind!r}"
            )
        # Cross-check extension ↔ kind so a config typo fails the build
        # instead of producing a mislabeled archive.
        if kind == "generator" and not filename.endswith(".colgen"):
            raise ValueError(
                f"{path}: bundle #{i} kind=generator but filename does not end in .colgen"
            )
        if kind == "renderer" and not filename.endswith(".colrend"):
            raise ValueError(
                f"{path}: bundle #{i} kind=renderer but filename does not end in .colrend"
            )
        if entry.get("cells"):
            raise ValueError(
                f"{path}: bundle #{i} declares a 'cells' layout — the cell "
                "grouping now comes from the asset tree's parent folders "
                "(see collimate.packaging.layout); remove the key"
            )
        out.append(_Bundle(
            filename=filename, kind=kind, runtime=runtime,
            gen_root=gen_root if isinstance(gen_root, str) else None,
        ))
    return out


# Duplicated from archive.py (private) to avoid an import cycle and keep
# the table locally editable.
_LANG_BY_EXT = {
    "py": "python", "js": "javascript", "ts": "typescript", "tsx": "typescript",
    "json": "json", "yaml": "yaml", "yml": "yaml",
    "md": "markdown", "css": "css", "html": "html",
}


def _lang_for(name: str) -> str:
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    return _LANG_BY_EXT.get(ext, "text")


def _files_for_source(abs_dir: Path, arc_base: str) -> list[FileSpec]:
    """Every utf-8 file under ``abs_dir``, named ``<arc_base>/<rel>`` so the
    cell holds the folder DIRECTLY (no asset-root nesting). ``__pycache__``
    dirs and ``.pyc`` / non-utf-8 files are skipped, but ``__init__.py`` is
    kept — it is the real source of the shared ``_*`` packages
    (``_agent_shared`` / ``_env_shared`` / ``_cdp_shared``)."""
    out: list[FileSpec] = []
    if not abs_dir.is_dir():
        print(f"warning: cell folder {arc_base!r} not found at {abs_dir}", file=sys.stderr)
        return out
    for path in sorted(abs_dir.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(abs_dir)
        # Skip build/cache cruft only — NOT ``__init__.py``, which is the real
        # source of shared ``_*`` packages. Dropping it left those cells
        # unimportable in the bundle.
        if "__pycache__" in rel.parts or path.suffix == ".pyc":
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        arc = f"{arc_base}/{rel.as_posix()}"
        out.append(FileSpec(name=arc, language=_lang_for(arc), content=text))
    return out


def _cell_spec(cell: CellLayout, kind: str, asset_root: Path, sdk_root: Path) -> CellSpec:
    """Bake one tree cell into a CellSpec: the cell folder's own subfolders
    and loose files, plus its ``shared`` libraries and ``shared_docs``,
    each content folder placed under its basename — so importing the
    archive yields the identical structure genesis seeds."""
    files: list[FileSpec] = []

    for child in sorted(cell.path.iterdir()):
        if child.name == CELL_MANIFEST:
            continue   # layout metadata, not cell content
        if child.is_dir():
            if child.name == "__pycache__":
                continue
            files.extend(_files_for_source(child, child.name))
        elif child.is_file():
            try:
                text = child.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            files.append(FileSpec(name=child.name, language=_lang_for(child.name), content=text))

    for ref in cell.shared:
        lib = shared_dir(asset_root, ref)
        if lib is None:
            print(f"warning: cell {cell.name!r}: shared library {ref!r} not found "
                  f"under {asset_root}/", file=sys.stderr)
            continue
        files.extend(_files_for_source(lib, lib.name))

    for doc in cell.shared_docs:
        # Canonical guides live in shared/docs/; demo-only guides (the WASM
        # authoring doc) live in demo/docs/. Search both.
        doc_path = sdk_root / "shared" / "docs" / doc
        if not doc_path.is_file():
            doc_path = sdk_root / "demo" / "docs" / doc
        if not doc_path.is_file():
            print(f"warning: shared_doc {doc!r} not found under shared/docs/ or demo/docs/",
                  file=sys.stderr)
            continue
        arc = f"_shared_docs/{doc}"
        files.append(FileSpec(
            name=arc, language=_lang_for(arc),
            content=doc_path.read_text(encoding="utf-8"),
        ))

    cell_id = str(uuid.uuid5(_CELL_ID_NAMESPACE, f"{kind}-cell-{cell.name}"))
    summary = cell.summary or f"{kind.capitalize()}s — {cell.name}"
    return CellSpec(
        id=cell_id, name=cell.name, summary=summary, files=files,
        folder=cell.folder, icon=cell.icon, order=cell.order, extra=cell.extra,
    )


def build_bundle(bundle: _Bundle, sdk_root: Path) -> bytes:
    if bundle.kind == "generator":
        asset_root = sdk_root / (bundle.gen_root or "generators")
    else:
        asset_root = sdk_root / "renderers"
    cells = [
        _cell_spec(cell, bundle.kind, asset_root, sdk_root)
        for cell in scan_cells(asset_root)
    ]
    cells = [c for c in cells if c.files]
    if not cells:
        raise ValueError(
            f"Bundle {bundle.filename!r} produced zero cells from "
            f"{asset_root} — is the tree structured as <cell>/<folder>/…?"
        )
    return write_archive(cells, type=bundle.kind)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m collimate.packaging.build_releases",
        description="Build .colgen / .colrend archives from the asset trees.",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("releases.yaml"),
        help="Config file (default: ./releases.yaml).",
    )
    parser.add_argument(
        "--sdk-root",
        type=Path,
        default=_SDK_ROOT,
        help="Root of the SDK checkout to scan (default: this package's parent repo).",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=Path("dist/releases"),
        help="Output directory (default: ./dist/releases).",
    )
    args = parser.parse_args(argv)

    config_path = args.config if args.config.is_absolute() else Path.cwd() / args.config
    sdk_root = args.sdk_root.resolve()
    out_dir = args.out if args.out.is_absolute() else Path.cwd() / args.out

    if not config_path.is_file():
        print(f"error: config file not found at {config_path}", file=sys.stderr)
        return 2

    bundles = _load_config(config_path)
    out_dir.mkdir(parents=True, exist_ok=True)

    for b in bundles:
        try:
            archive_bytes = build_bundle(b, sdk_root)
        except (ValueError, FileNotFoundError) as e:
            print(f"error: {e}", file=sys.stderr)
            return 2
        dest = out_dir / b.filename
        dest.write_bytes(archive_bytes)
        print(f"built {dest} ({len(archive_bytes):,} bytes, {b.kind})")

    return 0


if __name__ == "__main__":
    sys.exit(main())
