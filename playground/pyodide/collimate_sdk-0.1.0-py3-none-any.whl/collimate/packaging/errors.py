# SPDX-License-Identifier: Apache-2.0
class PackageError(Exception):
    """Raised when a .colgen / .colrend archive cannot be parsed or built."""
