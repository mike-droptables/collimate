# SPDX-License-Identifier: Apache-2.0
"""Extract .colgen / .colrend archives into a templates directory.

Usage:
    python -m collimate.packaging.install_archives \\
        --gen path/to/starting.colgen \\
        --rend path/to/starting.colrend \\
        --out api/templates

Produces a directory layout shape-compatible with
``vendor_defaults --runtime native``:

    <out>/generators/<group>/<name>/...
    <out>/renderers/<group>/<name>/...

so the collimate app's ``_resolve_assets_dir`` / ``seed_channel`` logic
keeps working unmodified whether the templates dir was populated by
``vendor_defaults`` (dev sibling checkout) or by this installer (release
build fetching pinned GitHub-release archives).

Multiple archives of the same kind can be passed and are merged in
declaration order; later archives overwrite earlier ones on collision.
"""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

from .archive import read_archive


_KIND_TO_SUBDIR = {"generator": "generators", "renderer": "renderers"}


def _extract_archive(path: Path, out_dir: Path) -> None:
    content = path.read_bytes()
    manifest = read_archive(content)
    if manifest.type not in _KIND_TO_SUBDIR:
        raise ValueError(
            f"{path}: archive type must be 'generator' or 'renderer', "
            f"got {manifest.type!r}"
        )
    target_root = out_dir / _KIND_TO_SUBDIR[manifest.type]
    target_root.mkdir(parents=True, exist_ok=True)

    for cell in manifest.cells:
        for f in cell.files:
            # File names inside the archive are pre-baked with the
            # asset-root-relative prefix (e.g. "chat/foo/manifest.gen_yaml")
            # by build_releases, so we write straight into the subdir.
            safe = f.name.lstrip("/").replace("..", "_")
            dest = target_root / safe
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(f.content, encoding="utf-8")


def install(
    gen_archives: list[Path],
    rend_archives: list[Path],
    out_dir: Path,
    wipe: bool = True,
) -> None:
    if wipe:
        # Match vendor_defaults' semantics: clear the target subdirs
        # before writing so stale generators from a previous build don't
        # linger.
        for sub in ("generators", "renderers"):
            target = out_dir / sub
            if target.exists():
                shutil.rmtree(target)

    out_dir.mkdir(parents=True, exist_ok=True)

    for path in gen_archives:
        _extract_archive(path, out_dir)
    for path in rend_archives:
        _extract_archive(path, out_dir)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m collimate.packaging.install_archives",
        description="Extract .colgen / .colrend archives into a templates directory.",
    )
    parser.add_argument(
        "--gen",
        type=Path,
        action="append",
        default=[],
        help="Path to a .colgen archive (repeat for multiple).",
    )
    parser.add_argument(
        "--rend",
        type=Path,
        action="append",
        default=[],
        help="Path to a .colrend archive (repeat for multiple).",
    )
    parser.add_argument(
        "--out",
        type=Path,
        required=True,
        help="Output directory (receives generators/ and renderers/ subdirs).",
    )
    parser.add_argument(
        "--no-wipe",
        action="store_true",
        help="Don't clear existing generators/ and renderers/ before extracting.",
    )
    args = parser.parse_args(argv)

    if not args.gen and not args.rend:
        print("error: at least one --gen or --rend archive required", file=sys.stderr)
        return 2

    for p in list(args.gen) + list(args.rend):
        if not p.is_file():
            print(f"error: archive not found: {p}", file=sys.stderr)
            return 2

    install(list(args.gen), list(args.rend), args.out.resolve(), wipe=not args.no_wipe)
    print(
        f"installed {len(args.gen)} .colgen + {len(args.rend)} .colrend → {args.out}"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
