# SPDX-License-Identifier: Apache-2.0
"""Extract .colgen / .colrend archives into a templates directory.

Usage:
    python -m collimate.packaging.install_archives \\
        --gen path/to/starting.colgen \\
        --rend path/to/starting.colrend \\
        --out api/templates

Produces the tree-driven layout ``vendor_defaults`` copies from the repo —
one parent folder per cell, with a synthesized ``cell.yaml`` carrying the
cell's name / summary / icon / order / extras:

    <out>/generators/<cell folder>/cell.yaml
    <out>/generators/<cell folder>/<content folder>/...
    <out>/renderers/<cell folder>/...

so the collimate app's genesis seeding (which scans parent folders +
``cell.yaml``) sees the identical structure whether the templates dir was
populated by ``vendor_defaults`` (dev sibling checkout) or by this
installer (release build fetching pinned GitHub-release archives). Shared
``_*`` libraries and ``_shared_docs`` were already materialised INTO each
cell at build time, so the synthesized ``cell.yaml`` never re-lists them.

Multiple archives of the same kind can be passed and are merged in
declaration order; later archives overwrite earlier ones on collision.
"""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

import yaml

from .archive import read_archive
from .layout import CELL_MANIFEST


_KIND_TO_SUBDIR = {"generator": "generators", "renderer": "renderers"}


def _cell_folder(cell) -> str:
    """The parent-folder name for a cell: the archive's recorded folder, or
    a slug of the display name for archives that predate the field."""
    if cell.folder:
        return cell.folder.strip("/").replace("/", "_")
    slug = "".join(c.lower() if c.isalnum() else "_" for c in cell.name).strip("_")
    return "_".join(p for p in slug.split("_") if p) or "cell"


def _cell_manifest_text(cell) -> str:
    meta: dict = {"name": cell.name}
    if cell.summary:
        meta["summary"] = cell.summary
    if cell.icon:
        meta["icon"] = cell.icon
    if cell.order != 100:
        meta["order"] = cell.order
    if cell.extra:
        meta["extra"] = cell.extra
    return yaml.safe_dump(meta, sort_keys=False, allow_unicode=True)


def _extract_archive(path: Path, out_dir: Path) -> None:
    content = path.read_bytes()
    manifest = read_archive(content)
    if manifest.type not in _KIND_TO_SUBDIR:
        raise ValueError(
            f"{path}: archive type must be 'generator' or 'renderer', "
            f"got {manifest.type!r}"
        )
    target_root = out_dir / _KIND_TO_SUBDIR[manifest.type]
    target_root.mkdir(parents=True, exist_ok=True)

    for cell in manifest.cells:
        cell_dir = target_root / _cell_folder(cell)
        cell_dir.mkdir(parents=True, exist_ok=True)
        (cell_dir / CELL_MANIFEST).write_text(
            _cell_manifest_text(cell), encoding="utf-8",
        )
        for f in cell.files:
            # File names inside the archive are cell-relative (e.g.
            # "axes_first/manifest.gen_yaml"), baked by build_releases.
            safe = f.name.lstrip("/").replace("..", "_")
            dest = cell_dir / safe
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(f.content, encoding="utf-8")


def install(
    gen_archives: list[Path],
    rend_archives: list[Path],
    out_dir: Path,
    wipe: bool = True,
) -> None:
    if wipe:
        # Match vendor_defaults' semantics: clear the target subdirs
        # before writing so stale generators from a previous build don't
        # linger.
        for sub in ("generators", "renderers"):
            target = out_dir / sub
            if target.exists():
                shutil.rmtree(target)

    out_dir.mkdir(parents=True, exist_ok=True)

    for path in gen_archives:
        _extract_archive(path, out_dir)
    for path in rend_archives:
        _extract_archive(path, out_dir)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m collimate.packaging.install_archives",
        description="Extract .colgen / .colrend archives into a templates directory.",
    )
    parser.add_argument(
        "--gen",
        type=Path,
        action="append",
        default=[],
        help="Path to a .colgen archive (repeat for multiple).",
    )
    parser.add_argument(
        "--rend",
        type=Path,
        action="append",
        default=[],
        help="Path to a .colrend archive (repeat for multiple).",
    )
    parser.add_argument(
        "--out",
        type=Path,
        required=True,
        help="Output directory (receives generators/ and renderers/ subdirs).",
    )
    parser.add_argument(
        "--no-wipe",
        action="store_true",
        help="Don't clear existing generators/ and renderers/ before extracting.",
    )
    args = parser.parse_args(argv)

    if not args.gen and not args.rend:
        print("error: at least one --gen or --rend archive required", file=sys.stderr)
        return 2

    for p in list(args.gen) + list(args.rend):
        if not p.is_file():
            print(f"error: archive not found: {p}", file=sys.stderr)
            return 2

    install(list(args.gen), list(args.rend), args.out.resolve(), wipe=not args.no_wipe)
    print(
        f"installed {len(args.gen)} .colgen + {len(args.rend)} .colrend → {args.out}"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
