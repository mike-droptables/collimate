# SPDX-License-Identifier: Apache-2.0
"""Tree-driven cell layout: the parent folders ARE the cells.

The grouping an asset tree ships is its directory structure — each
immediate, non-underscore subdirectory of an asset root (``generators/``,
``renderers/``, ``demo/generators/``) is one cell, and the folders inside
it are the cell's contents::

    generators/
      _agent_shared/          # shared library — not a cell (underscore)
      judgment/               # ← the cell "Judgment"
        cell.yaml             #   name / summary / icon / order / shared / …
        axes_first/
        challenge/
        …

``cell.yaml`` is the optional per-cell manifest:

    name: "Judgment"          # display name (default: folder name, titled)
    summary: "…"              # cell summary shown in the app / picker
    icon: "scale"             # lucide-style icon name (frontend registry)
    order: 70                 # sort key (default 100; ties by folder name)
    shared:                   # top-level _* library folders materialised
      - _agent_shared         #   into this cell at build/seed time
    shared_docs:              # files from shared/docs (or demo/docs) baked
      - README.md             #   into the cell as _shared_docs/<name>
    extra: {…}                # arbitrary passthrough metadata

Everything that consumes a layout — the archive builder
(:mod:`build_releases`), the archive installer (:mod:`install_archives`),
and the collimate app's genesis seeding — reads the same scan, so the
grouping cannot drift between the repo, the archives, and the app.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import yaml

CELL_MANIFEST = "cell.yaml"
_DEFAULT_ORDER = 100


@dataclass
class CellLayout:
    """One cell as declared by a parent folder + its ``cell.yaml``."""

    folder: str                       # the parent folder's name (stable id-ish)
    path: Path                        # absolute path of the parent folder
    name: str                         # display name
    summary: str = ""
    icon: str = ""
    order: int = _DEFAULT_ORDER
    shared: list = field(default_factory=list)        # top-level _* libraries
    shared_docs: list = field(default_factory=list)   # shared/docs files
    extra: dict = field(default_factory=dict)


def _titled(folder: str) -> str:
    return " ".join(w.capitalize() for w in folder.replace("-", "_").split("_") if w)


def read_cell_manifest(cell_dir: Path) -> dict:
    """The parsed ``cell.yaml`` of a cell folder (``{}`` when absent)."""
    manifest = cell_dir / CELL_MANIFEST
    if not manifest.is_file():
        return {}
    data = yaml.safe_load(manifest.read_text(encoding="utf-8"))
    return data if isinstance(data, dict) else {}


def scan_cells(asset_root: Path) -> list:
    """The cells of an asset tree, in display order.

    Every immediate subdirectory that doesn't start with ``_`` or ``.`` is a
    cell; underscore-prefixed directories are shared libraries cells opt into
    via ``cell.yaml``'s ``shared`` list. Sorted by (``order``, folder name).
    """
    asset_root = Path(asset_root)
    if not asset_root.is_dir():
        raise FileNotFoundError(f"asset root not found: {asset_root}")
    cells: list[CellLayout] = []
    for child in sorted(asset_root.iterdir()):
        if not child.is_dir() or child.name.startswith(("_", ".")):
            continue
        meta = read_cell_manifest(child)
        cells.append(CellLayout(
            folder=child.name,
            path=child,
            name=str(meta.get("name") or _titled(child.name)),
            summary=str(meta.get("summary") or ""),
            icon=str(meta.get("icon") or ""),
            order=int(meta.get("order") or _DEFAULT_ORDER),
            shared=[str(s) for s in (meta.get("shared") or [])],
            shared_docs=[str(d) for d in (meta.get("shared_docs") or [])],
            extra=dict(meta.get("extra") or {}),
        ))
    cells.sort(key=lambda c: (c.order, c.folder))
    return cells


def shared_dir(asset_root: Path, ref: str) -> Path | None:
    """Resolve a ``shared:`` library reference against the asset root.
    Underscore-prefixed, top-level only — anything else is rejected so a
    cell.yaml can't reach outside the tree."""
    name = ref.strip().strip("/")
    if not name.startswith("_") or "/" in name or ".." in name:
        return None
    candidate = Path(asset_root) / name
    return candidate if candidate.is_dir() else None


__all__ = ["CELL_MANIFEST", "CellLayout", "read_cell_manifest", "scan_cells", "shared_dir"]
