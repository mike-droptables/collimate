# SPDX-License-Identifier: Apache-2.0
from dataclasses import dataclass, field
from typing import Optional

PACKAGE_FORMAT_VERSION = 2


@dataclass
class FileSpec:
    name: str
    language: str
    content: str = ""


@dataclass
class CellSpec:
    id: str
    name: str
    summary: str
    files: list[FileSpec] = field(default_factory=list)


@dataclass
class PackageManifest:
    version: int
    type: Optional[str]
    cells: list[CellSpec] = field(default_factory=list)

    def to_dict(self, include_content: bool = True) -> dict:
        return {
            "version": self.version,
            "type": self.type,
            "cells": [
                {
                    "id": c.id,
                    "name": c.name,
                    "summary": c.summary,
                    "files": [
                        {
                            "name": f.name,
                            "language": f.language,
                            **({"content": f.content} if include_content else {}),
                        }
                        for f in c.files
                    ],
                }
                for c in self.cells
            ],
        }
