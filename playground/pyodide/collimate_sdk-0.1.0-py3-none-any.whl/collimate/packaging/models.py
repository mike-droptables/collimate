# SPDX-License-Identifier: Apache-2.0
from dataclasses import dataclass, field
from typing import Optional

PACKAGE_FORMAT_VERSION = 2


@dataclass
class FileSpec:
    name: str
    language: str
    content: str = ""


@dataclass
class CellSpec:
    id: str
    name: str
    summary: str
    files: list[FileSpec] = field(default_factory=list)
    # Tree-driven layout metadata (collimate.packaging.layout): the parent
    # folder the cell came from (so an installer can reconstruct the tree),
    # a lucide-style icon name, the display order, and arbitrary passthrough
    # extras. All optional — absent keys read back as their defaults.
    folder: str = ""
    icon: str = ""
    order: int = 100
    extra: dict = field(default_factory=dict)

    def meta_dict(self) -> dict:
        """The cell's manifest entry, files excluded. Optional layout keys
        are emitted only when set, keeping archives free of noise."""
        out: dict = {"id": self.id, "name": self.name, "summary": self.summary}
        if self.folder:
            out["folder"] = self.folder
        if self.icon:
            out["icon"] = self.icon
        if self.order != 100:
            out["order"] = self.order
        if self.extra:
            out["extra"] = self.extra
        return out


@dataclass
class PackageManifest:
    version: int
    type: Optional[str]
    cells: list[CellSpec] = field(default_factory=list)

    def to_dict(self, include_content: bool = True) -> dict:
        return {
            "version": self.version,
            "type": self.type,
            "cells": [
                {
                    **c.meta_dict(),
                    "files": [
                        {
                            "name": f.name,
                            "language": f.language,
                            **({"content": f.content} if include_content else {}),
                        }
                        for f in c.files
                    ],
                }
                for c in self.cells
            ],
        }
