# SPDX-License-Identifier: Apache-2.0
"""Copy bundled generators and renderers into a target directory.

Usage:
    python -m collimate.packaging.vendor_defaults --runtime {native|wasm} --out <dir>

Writes:
    <dir>/generators/Standard/   — from `generators/Standard/` (native)
    <dir>/generators/WASM/       — from `generators/WASM/`     (wasm)
    <dir>/renderers/             — always the same (renderers are browser-side JS)

Genesis seeding (in api/genesis.py) walks one level deep, treating each
top-level subdir as a single source cell. Keeping the ``Standard/`` /
``WASM/`` parent here means a fresh channel gets ONE generator cell
("Standard" or "Wasm") containing every generator in that runtime's
bundle, instead of N cells (one per generator) — matches the layout
that the wasm playground gets via the .colgen archive route.

Source resolution tries the installed-package layout first
(importlib.resources.files("collimate") / <asset>) and falls back to the
in-tree SDK repo layout, so the CLI works both from a `pip install
collimate-sdk` and from a checkout.
"""
import argparse
import shutil
import sys
from importlib.resources import as_file, files
from pathlib import Path


_IN_TREE_SDK_ROOT = Path(__file__).resolve().parents[3]


def _asset_path(*parts: str) -> Path:
    """Locate an SDK asset directory (e.g. ``('generators', 'Standard')``
    or ``('renderers',)``).

    Accepts one or more path segments so callers can point at nested
    subtrees (needed now that native vs. wasm generators live side by
    side under ``generators/`` rather than in distinct top-level dirs)."""
    rel = "/".join(parts)
    try:
        installed = files("collimate").joinpath(*parts)
        with as_file(installed) as p:
            if p.is_dir():
                return Path(p)
    except (ModuleNotFoundError, FileNotFoundError):
        pass

    in_tree = _IN_TREE_SDK_ROOT.joinpath(*parts)
    if in_tree.is_dir():
        return in_tree

    raise FileNotFoundError(
        f"Cannot locate SDK asset directory {rel!r}. "
        f"Checked installed package resources and {in_tree}."
    )


def vendor(out_dir: Path, runtime: str) -> None:
    if runtime not in ("native", "wasm"):
        raise ValueError(f"runtime must be 'native' or 'wasm', got {runtime!r}")

    # Both trees live under a single ``generators/`` parent now;
    # Standard/ holds native generators, WASM/ holds the pyodide variants.
    gen_subdir = "Standard" if runtime == "native" else "WASM"
    gen_src = _asset_path("generators", gen_subdir)
    ren_src = _asset_path("renderers")

    out_dir.mkdir(parents=True, exist_ok=True)
    # Preserve the runtime parent directory in the destination layout.
    # Result: ``<out>/generators/Standard/<gen>/...``, mirroring the SDK
    # source tree. genesis._list_groups(<out>/generators) then sees a
    # single ``Standard`` (or ``WASM``) entry and seeds one source cell
    # for the whole bundle — see the module docstring.
    gen_root = out_dir / "generators"
    gen_dst = gen_root / gen_subdir
    ren_dst = out_dir / "renderers"

    if gen_root.exists():
        shutil.rmtree(gen_root)
    if ren_dst.exists():
        shutil.rmtree(ren_dst)

    shutil.copytree(gen_src, gen_dst)
    shutil.copytree(ren_src, ren_dst)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m collimate.packaging.vendor_defaults",
        description="Copy bundled generators and renderers into a target directory.",
    )
    parser.add_argument("--runtime", choices=["native", "wasm"], default="native")
    parser.add_argument(
        "--out",
        required=True,
        type=Path,
        help="Output directory (receives generators/ and renderers/ subdirs).",
    )
    args = parser.parse_args(argv)
    vendor(args.out, args.runtime)
    print(f"vendored {args.runtime} defaults → {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
