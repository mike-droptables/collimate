# SPDX-License-Identifier: Apache-2.0
"""Copy bundled generators and renderers into a target directory.

Usage:
    python -m collimate.packaging.vendor_defaults --runtime {native|wasm} --out <dir>

Writes:
    <dir>/generators/   — from `generators/` (native) or `demo/generators/` (wasm)
    <dir>/renderers/    — always the same (renderers are browser-side JS)

Native generators are the canonical set and live flat under
``generators/<gen>/``; the demo/playground (wasm) variants are quarantined
under ``demo/generators/<gen>/``. Either tree is copied flat into
``<dir>/generators/`` so genesis seeding (api/genesis.py) resolves each
generator folder by name — the curated cell grouping comes from
``releases.yaml``'s ``cells`` layout, which genesis reads directly.

Source resolution tries the installed-package layout first
(importlib.resources.files("collimate") / <asset>) and falls back to the
in-tree SDK repo layout, so the CLI works both from a `pip install
collimate-sdk` and from a checkout.
"""
import argparse
import shutil
import sys
from importlib.resources import as_file, files
from pathlib import Path


_IN_TREE_SDK_ROOT = Path(__file__).resolve().parents[3]


def _asset_path(*parts: str) -> Path:
    """Locate an SDK asset directory (e.g. ``('generators',)`` for the
    native set, ``('demo', 'generators')`` for the demo/wasm set, or
    ``('renderers',)``).

    Accepts one or more path segments so callers can point at nested
    subtrees (the demo/wasm generators live under ``demo/generators/``,
    separate from the canonical ``generators/`` tree)."""
    rel = "/".join(parts)
    try:
        installed = files("collimate").joinpath(*parts)
        with as_file(installed) as p:
            if p.is_dir():
                return Path(p)
    except (ModuleNotFoundError, FileNotFoundError):
        pass

    in_tree = _IN_TREE_SDK_ROOT.joinpath(*parts)
    if in_tree.is_dir():
        return in_tree

    raise FileNotFoundError(
        f"Cannot locate SDK asset directory {rel!r}. "
        f"Checked installed package resources and {in_tree}."
    )


def vendor(out_dir: Path, runtime: str) -> None:
    if runtime not in ("native", "wasm"):
        raise ValueError(f"runtime must be 'native' or 'wasm', got {runtime!r}")

    # Native generators live flat under ``generators/``; the demo/playground
    # (wasm) variants are quarantined under ``demo/generators/``. Either is
    # copied flat into ``<out>/generators/`` — the curated cell grouping is
    # supplied by releases.yaml's ``cells`` layout, read by genesis.
    if runtime == "native":
        gen_src = _asset_path("generators")
    else:
        gen_src = _asset_path("demo", "generators")
    ren_src = _asset_path("renderers")

    out_dir.mkdir(parents=True, exist_ok=True)
    gen_dst = out_dir / "generators"
    ren_dst = out_dir / "renderers"

    if gen_dst.exists():
        shutil.rmtree(gen_dst)
    if ren_dst.exists():
        shutil.rmtree(ren_dst)

    shutil.copytree(gen_src, gen_dst)
    shutil.copytree(ren_src, ren_dst)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m collimate.packaging.vendor_defaults",
        description="Copy bundled generators and renderers into a target directory.",
    )
    parser.add_argument("--runtime", choices=["native", "wasm"], default="native")
    parser.add_argument(
        "--out",
        required=True,
        type=Path,
        help="Output directory (receives generators/ and renderers/ subdirs).",
    )
    args = parser.parse_args(argv)
    vendor(args.out, args.runtime)
    print(f"vendored {args.runtime} defaults → {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
