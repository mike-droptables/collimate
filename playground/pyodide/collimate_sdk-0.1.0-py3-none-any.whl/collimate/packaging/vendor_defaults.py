"""Copy bundled generators and renderers into a target directory.

Usage:
    python -m collimate.packaging.vendor_defaults --runtime {native|wasm} --out <dir>

Writes:
    <dir>/generators/   — from `generators/` (native) or `generators-wasm/` (wasm)
    <dir>/renderers/    — always the same (renderers are browser-side JS)

Source resolution tries the installed-package layout first
(importlib.resources.files("collimate") / <asset>) and falls back to the
in-tree SDK repo layout, so the CLI works both from a `pip install
collimate-sdk` and from a checkout.
"""
import argparse
import shutil
import sys
from importlib.resources import as_file, files
from pathlib import Path


_IN_TREE_SDK_ROOT = Path(__file__).resolve().parents[3]


def _asset_path(asset: str) -> Path:
    """Locate a top-level SDK asset directory (`generators`, `generators-wasm`, `renderers`)."""
    try:
        installed = files("collimate").joinpath(asset)
        with as_file(installed) as p:
            if p.is_dir():
                return Path(p)
    except (ModuleNotFoundError, FileNotFoundError):
        pass

    in_tree = _IN_TREE_SDK_ROOT / asset
    if in_tree.is_dir():
        return in_tree

    raise FileNotFoundError(
        f"Cannot locate SDK asset directory {asset!r}. "
        f"Checked installed package resources and {in_tree}."
    )


def vendor(out_dir: Path, runtime: str) -> None:
    if runtime not in ("native", "wasm"):
        raise ValueError(f"runtime must be 'native' or 'wasm', got {runtime!r}")

    gen_src_name = "generators" if runtime == "native" else "generators-wasm"
    gen_src = _asset_path(gen_src_name)
    ren_src = _asset_path("renderers")

    out_dir.mkdir(parents=True, exist_ok=True)
    gen_dst = out_dir / "generators"
    ren_dst = out_dir / "renderers"

    if gen_dst.exists():
        shutil.rmtree(gen_dst)
    if ren_dst.exists():
        shutil.rmtree(ren_dst)

    shutil.copytree(gen_src, gen_dst)
    shutil.copytree(ren_src, ren_dst)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m collimate.packaging.vendor_defaults",
        description="Copy bundled generators and renderers into a target directory.",
    )
    parser.add_argument("--runtime", choices=["native", "wasm"], default="native")
    parser.add_argument(
        "--out",
        required=True,
        type=Path,
        help="Output directory (receives generators/ and renderers/ subdirs).",
    )
    args = parser.parse_args(argv)
    vendor(args.out, args.runtime)
    print(f"vendored {args.runtime} defaults → {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
