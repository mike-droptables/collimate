# SPDX-License-Identifier: Apache-2.0
"""Canonical pointer-file contracts (shared by generators and renderers).

A *pointer file* is a small file whose **contents point at a live resource**
a renderer opens at mount time, rather than the artifact to display. Two
built-ins exist; this module pins their shape in one place so the generator
side (which writes the file) and the renderer side (which reads it) cannot
drift — the same pattern as ``shared/empty-values-contract.json`` for config
values.

- ``.terminal`` — JSON ``{session_id, ws_path, token, label}``. The
  ``terminal`` renderer (xterm.js) opens a WebSocket PTY against it. Build
  it from a :func:`gen.terminal` result with :func:`terminal_pointer`, then
  ``gen.update_file("shell.terminal", json.dumps(ptr))``.
- ``.website`` — a proxy URL path **string** (e.g.
  ``/proxy/{channel}/{run_id}/{port}/``). The ``website`` renderer opens it
  in a sandboxed iframe. Write it alongside :func:`gen.serve_port`:
  ``gen.update_file("preview.website", url)``.
- ``.chatlive`` — JSON ``{session_id, ws_path, token, label, log_file}``.
  The ``chatlive`` renderer opens a WebSocket chat session against it (the
  same shape as ``.terminal``, but the channel carries chat turns instead
  of PTY bytes). ``log_file`` names the sibling ``.chatlog`` transcript the
  renderer falls back to when the session is dead. :func:`gen.serve_chat`
  writes and pins this automatically.
- ``.chatlog`` — a human-readable, editable **text** transcript (markdown
  with ``### User`` / ``### Assistant`` section headers). The durable record;
  versioned and required at close. Not a pointer — a normal artifact.

Example::

    import json, gen
    from collimate.pointers import terminal_pointer

    sess = await gen.terminal(container_id, ["bash"], cwd="/work")
    gen.update_file("shell.terminal", json.dumps(terminal_pointer(sess, label="Shell")))
    await gen.update(name="Container", summary="terminal ready")
"""
from __future__ import annotations

TERMINAL_EXT = ".terminal"
WEBSITE_EXT = ".website"
CHATLIVE_EXT = ".chatlive"
CHATLOG_EXT = ".chatlog"

# The exact key set of a .terminal pointer file (renderer reads all four).
TERMINAL_KEYS = ("session_id", "ws_path", "token", "label")

# The exact key set of a .chatlive pointer file (renderer reads all five).
CHATLIVE_KEYS = ("session_id", "ws_path", "token", "label", "log_file")


def terminal_pointer(session: dict, *, label: str = "Terminal") -> dict:
    """Build a ``.terminal`` pointer dict from a :func:`gen.terminal` result.

    ``session`` is the ``{session_id, ws_path, token}`` returned by
    ``gen.terminal(...)``. Returns the full ``TERMINAL_KEYS`` mapping ready
    to ``json.dumps`` into a ``<name>.terminal`` file via ``gen.update_file``.
    """
    return {
        "session_id": session.get("session_id", ""),
        "ws_path": session.get("ws_path", ""),
        "token": session.get("token", ""),
        "label": label,
    }


def chat_live_pointer(
    session: dict,
    *,
    label: str = "Live Chat",
    log_file: str = "conversation.chatlog",
) -> dict:
    """Build a ``.chatlive`` pointer dict from a :func:`gen.serve_chat`
    session registration.

    ``session`` is the ``{session_id, ws_path, token}`` returned by the
    host's ``chat_register`` op. Returns the full ``CHATLIVE_KEYS`` mapping
    ready to ``json.dumps`` into a ``<name>.chatlive`` file. ``log_file`` is
    the sibling ``.chatlog`` the renderer reads for history (and falls back
    to when the live session is gone).
    """
    return {
        "session_id": session.get("session_id", ""),
        "ws_path": session.get("ws_path", ""),
        "token": session.get("token", ""),
        "label": label,
        "log_file": log_file,
    }


def is_terminal_pointer(name: str) -> bool:
    """True when ``name`` is a ``.terminal`` pointer file."""
    return name.endswith(TERMINAL_EXT)


def is_website_pointer(name: str) -> bool:
    """True when ``name`` is a ``.website`` pointer file."""
    return name.endswith(WEBSITE_EXT)


def is_chatlive_pointer(name: str) -> bool:
    """True when ``name`` is a ``.chatlive`` pointer file."""
    return name.endswith(CHATLIVE_EXT)


def is_chatlog(name: str) -> bool:
    """True when ``name`` is a ``.chatlog`` transcript file."""
    return name.endswith(CHATLOG_EXT)


__all__ = [
    "CHATLIVE_EXT",
    "CHATLIVE_KEYS",
    "CHATLOG_EXT",
    "TERMINAL_EXT",
    "TERMINAL_KEYS",
    "WEBSITE_EXT",
    "chat_live_pointer",
    "is_chatlive_pointer",
    "is_chatlog",
    "is_terminal_pointer",
    "is_website_pointer",
    "terminal_pointer",
]
