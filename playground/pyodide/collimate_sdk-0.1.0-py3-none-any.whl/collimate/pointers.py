# SPDX-License-Identifier: Apache-2.0
"""Canonical pointer-file contracts (shared by generators and renderers).

A *pointer file* is a small file whose **contents point at a live resource**
a renderer opens at mount time, rather than the artifact to display. This
module pins their shape in one place so the generator side (which writes the
file) and the renderer side (which reads it) cannot drift.

- ``.terminal`` — JSON ``{session_id, ws_path, token, label}``. The
  ``terminal`` renderer (xterm.js) opens a WebSocket PTY against it. Build it
  from a :func:`gen.terminal` result with :func:`terminal_pointer`.
- ``.website`` — a proxy URL path **string** (e.g.
  ``/proxy/{channel}/{run_id}/{port}/``). The ``website`` renderer opens it in
  a sandboxed iframe. Written alongside :func:`gen.serve_port`.
- ``.chat`` — JSON describing a live chat session for the **assistant-ui**
  renderer (see :func:`chat_session_pointer`). It carries the WebSocket coords
  for the native runtime, plus the ``integration`` block
  for the direct-backend runtime, and the thread list. Each thread's messages
  live in its own open-format transcript file (``chats/<id>.json``;
  :mod:`collimate.transcript`) so a closed chat still renders from disk.
  :func:`gen.serve_chat` writes and pins this automatically.

Example::

    import json, gen
    from collimate.pointers import terminal_pointer

    sess = await gen.terminal(container_id, ["bash"], cwd="/work")
    gen.update_file("shell.terminal", json.dumps(terminal_pointer(sess, label="Shell")))
    await gen.update(name="Container", summary="terminal ready")
"""
from __future__ import annotations

from typing import Optional

TERMINAL_EXT = ".terminal"
WEBSITE_EXT = ".website"
CHAT_EXT = ".chat"

# The required key set of a .terminal pointer file (renderer reads all
# four); an optional "buttons" key ([{id, label}, ...]) adds toolbar buttons
# whose clicks reach the generator via gen.actions() / gen.wait_for_action().
TERMINAL_KEYS = ("session_id", "ws_path", "token", "label")

# The exact key set of a .chat session pointer file.
CHAT_KEYS = (
    "session_id", "ws_path", "token", "label",
    "threads_dir", "active_thread", "threads", "integration",
)


def terminal_pointer(
    session: dict,
    *,
    label: str = "Terminal",
    buttons: Optional[list] = None,
) -> dict:
    """Build a ``.terminal`` pointer dict from a :func:`gen.terminal` result.

    ``buttons`` — an optional list of ``{"id", "label"}`` dicts — adds action
    buttons to the terminal renderer's toolbar; clicks arrive in the generator
    via ``gen.actions()`` / ``gen.wait_for_action()``. Most generators never
    build this dict directly: ``gen.serve_terminal`` writes and pins it.
    """
    out = {
        "session_id": session.get("session_id", ""),
        "ws_path": session.get("ws_path", ""),
        "token": session.get("token", ""),
        "label": label,
    }
    if buttons:
        out["buttons"] = [
            {"id": str(b["id"]), "label": str(b["label"])} for b in buttons
        ]
    return out


def chat_session_pointer(
    session: dict,
    *,
    label: str = "Chat",
    threads_dir: str = "chats",
    active_thread: str = "main",
    threads: Optional[list] = None,
    integration: Optional[dict] = None,
) -> dict:
    """Build a ``.chat`` session pointer for the assistant-ui renderer.

    ``session`` is the ``{session_id, ws_path, token}`` from the host's
    ``chat_register`` op (the native streaming channel). ``integration`` picks
    the renderer's runtime: ``None`` → assistant-ui ExternalStoreRuntime fed by
    that WebSocket (native streaming); a dict → assistant-ui uses a direct
    backend runtime (e.g. ``{"type": "opencode", "proxy_url":
    "/proxy/<ch>/<run>/<port>/"}`` → the official opencode runtime). ``threads``
    is the list of ``{id, title, file}`` thread entries (defaults to a single
    ``main``); ``active_thread`` is the open one. Each thread's messages are an
    open-format transcript at ``<threads_dir>/<id>.json``.
    """
    if threads is None:
        threads = [{
            "id": active_thread,
            "title": "Main",
            "file": f"{threads_dir}/{active_thread}.json",
        }]
    return {
        "session_id": session.get("session_id", ""),
        "ws_path": session.get("ws_path", ""),
        "token": session.get("token", ""),
        "label": label,
        "threads_dir": threads_dir,
        "active_thread": active_thread,
        "threads": threads,
        "integration": integration,
    }


def is_terminal_pointer(name: str) -> bool:
    """True when ``name`` is a ``.terminal`` pointer file."""
    return name.endswith(TERMINAL_EXT)


def is_website_pointer(name: str) -> bool:
    """True when ``name`` is a ``.website`` pointer file."""
    return name.endswith(WEBSITE_EXT)


def is_chat_pointer(name: str) -> bool:
    """True when ``name`` is a ``.chat`` session pointer file."""
    return name.endswith(CHAT_EXT)


__all__ = [
    "CHAT_EXT",
    "CHAT_KEYS",
    "TERMINAL_EXT",
    "TERMINAL_KEYS",
    "WEBSITE_EXT",
    "chat_session_pointer",
    "is_chat_pointer",
    "is_terminal_pointer",
    "is_website_pointer",
    "terminal_pointer",
]
