# Renderer credits

The renderers under `renderers/basic/` are thin Collimate wrappers around
upstream open-source libraries. Each renderer loads its dependencies
directly from public CDNs (`https://esm.sh/…`, `jsdelivr`) at runtime —
the SDK does not bundle, modify, or redistribute their source. Licenses
and copyright remain with the upstream projects.

This file exists so downstream distributors have a single place to point
end users for attribution.

| Renderer | Upstream component | Upstream license | Upstream repo |
|---|---|---|---|
| `monaco` | Monaco Editor | MIT | https://github.com/microsoft/monaco-editor |
| `milkdown` | Milkdown + Crepe | MIT | https://github.com/Milkdown/milkdown |
| `excalidraw` | Excalidraw | MIT | https://github.com/excalidraw/excalidraw |
| `mermaid` | Mermaid | MIT | https://github.com/mermaid-js/mermaid |
| `markdown` | react-markdown (+ remark / rehype ecosystem) | MIT | https://github.com/remarkjs/react-markdown |
| `react-diff` | react-diff-viewer | MIT | https://github.com/praneshr/react-diff-viewer |
| `slides` | react-markdown + rehype-slide splitters | MIT | — |
| `table` | React + Collimate table code | MIT-compatible | — |
| `terminal` | xterm.js | MIT | https://github.com/xtermjs/xterm.js |
| `schema_form` | Collimate's own schema-driven form engine | Apache-2.0 (this repo) | — |
| `website`, `html` | Monaco (editor split) + browser `<iframe>` | MIT / native | — |
| `image`, `text` | Native browser + React | — | — |

Every renderer also depends on:

- **React / ReactDOM** (Meta, MIT) — https://github.com/facebook/react
- The Collimate **renderer-hooks** runtime (`/api/sdk/react.js`), which is
  Apache-2.0 from this SDK.

Additional runtime libraries pulled from CDN by specific renderers:

- **KaTeX** (MIT) — loaded by the markdown + slides + milkdown renderers
  for LaTeX math rendering. https://github.com/KaTeX/KaTeX
- **highlight.js** / **Shiki** (MIT) — loaded by markdown / milkdown for
  code-block syntax highlighting when needed.

### What this means for redistributors

If you distribute a build of Collimate that ships the renderers (e.g. the
`starting.colrend` archive), you are redistributing only the thin
Collimate wrappers (Apache-2.0). End users' browsers fetch the upstream
components directly from their CDNs at runtime — you are not
redistributing those sources, so you do not need to ship copies of their
license texts with your wheel. A pointer to this file (or to the upstream
repos) in your attribution docs is conventional and sufficient.

If you ever choose to vendor an upstream component (bundle its source
into the renderer directory instead of loading from CDN), that component
becomes a vendored dependency and its license MUST ship with your
distribution. Update this file and the SDK's `THIRD_PARTY_LICENSES` in
that case.
