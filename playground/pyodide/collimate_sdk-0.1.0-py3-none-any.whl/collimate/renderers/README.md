# Bundled renderers

Renderers are ES modules that mount UI for a file inside a sandboxed iframe. See [`../shared/docs/how-to-write-a-renderer.md`](../shared/docs/how-to-write-a-renderer.md) for the authoring guide.

## Layout

```
renderers/
└── basic/         — reference renderers (text, markdown, monaco, excalidraw, website, milkdown, …)
```

## Runtime dependencies

Renderers load React and any other browser libraries directly from a CDN (`https://esm.sh/…`) at runtime. There is no build step — the Collimate sandbox compiles `.tsx` on the fly.

No Node packaging is required to ship a renderer; each `main.tsx` / `main.js` is self-contained.
