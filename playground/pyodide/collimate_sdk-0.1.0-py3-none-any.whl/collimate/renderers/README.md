# Bundled renderers

Renderers are ES modules that mount UI for a file inside a sandboxed iframe. See [`../shared/docs/how-to-write-a-renderer.md`](../shared/docs/how-to-write-a-renderer.md) for the authoring guide.

## Layout

**The parent folders are the cells** (see `collimate.packaging.layout`):
each top-level directory is one seeded cell, and its `cell.yaml` carries the
cell's display name, summary, icon, and order.

```
renderers/
├── live/          — cell "Live": assistant, webview, terminal, website
├── documents/     — cell "Documents": markdown, milkdown, monaco, text
├── visual/        — cell "Visual": mermaid, image, html, excalidraw, slides
└── utility/       — cell "Utility": schema_form, table, react-diff, axes, ledger, challenge
```

Three of the reference renderers are the judgment surfaces for the generator
set's decision artifacts: **`axes`** edits a proposed trade-off frame
(`.axes` — strike/add/reweight axes, disagreement badges, a Continue button
that releases the paused `axes_first` generator via `api.emitAction`),
**`ledger`** renders an `assumptions.ledger` (claimed vs enacted commitments,
grouped by kind, ranked by spread and cross-candidate seams, with
verified / overridden / contested / struck marking written back into the file),
and **`challenge`** renders a `challenges.challenge` report (each objection
thrown at every candidate side by side — survived/failed evidence,
reproductions, and accepted-risk / must-fix / disputed marking). The
`evaluate_best` scoreboard rides the existing **`table`** renderer via
`.scoreboard.json`.

## Runtime dependencies

Renderers load React and any other browser libraries directly from a CDN (`https://esm.sh/…`) at runtime. There is no build step — the Collimate sandbox compiles `.tsx` on the fly.

No Node packaging is required to ship a renderer; each `main.tsx` / `main.js` is self-contained.
