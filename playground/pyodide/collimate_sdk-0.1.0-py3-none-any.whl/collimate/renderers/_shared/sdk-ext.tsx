// SPDX-License-Identifier: Apache-2.0
//
// Canonical reference implementation for the new renderer-SDK hooks.
// These are the target exports for `/api/sdk/react.js` — the Collimate
// platform hosts the authoritative version; this file is the spec + a
// copy-pasteable fallback for reference renderers.
//
// Exports:
//   useTheme()                 — { scheme, onChange } theme handle
//   useDebouncedSaveContent()  — debounced wrapper around saveContent
//   useRemoteModule(url, opts) — dynamic ESM loader with dedupe + cache
//   useRemoteScript(url)       — dynamic <script> loader with dedupe
//
// Each hook falls back to existing `/api/sdk/react.js` primitives
// (`useCollimateFile().api.onThemeChange`, `api.loadCSS`, etc.) so the
// reference renderers work against the current platform during the
// platform rollout. Once the platform ships these exports natively,
// renderers can drop the local import.

import React from 'https://esm.sh/react@18';

// ---------------------------------------------------------------------------
// useTheme — unified handle for the host's color scheme + subscriptions
// ---------------------------------------------------------------------------
//
// Replaces the pattern every renderer copies:
//
//   const [scheme, setScheme] = useState(() =>
//     (api && api.getTheme ? api.getTheme().scheme : 'dark'));
//   useEffect(() => api?.onThemeChange?.(t => setScheme(t.scheme)), [api]);
//
// Returns { scheme, onChange }. `onChange(cb)` registers a callback and
// returns an unsubscribe handle. The callback fires immediately with
// the current scheme (per the api.onThemeChange contract), so a single
// useEffect initialises library theme state without a separate branch.

export type Scheme = 'light' | 'dark';

export interface ThemeHandle {
    scheme: Scheme;
    onChange: (cb: (scheme: Scheme) => void) => (() => void) | undefined;
}

export function useTheme(api: any): ThemeHandle {
    const getInitial = (): Scheme =>
        (api && api.getTheme ? api.getTheme().scheme : 'dark') as Scheme;
    const [scheme, setScheme] = React.useState<Scheme>(getInitial);
    React.useEffect(() => {
        if (!api || !api.onThemeChange) return;
        return api.onThemeChange((t: any) => setScheme(t.scheme));
    }, [api]);
    const onChange = React.useCallback(
        (cb: (s: Scheme) => void) => {
            if (!api || !api.onThemeChange) return undefined;
            return api.onThemeChange((t: any) => cb(t.scheme));
        },
        [api],
    );
    return { scheme, onChange };
}

// ---------------------------------------------------------------------------
// useDebouncedSaveContent — debounced wrapper around useCollimateFile's
// saveContent, with timer cleanup on unmount.
// ---------------------------------------------------------------------------
//
// Replaces the boilerplate every editing renderer copies:
//
//   const timerRef = useRef(null);
//   const scheduleSave = useCallback(next => {
//     if (timerRef.current) clearTimeout(timerRef.current);
//     timerRef.current = setTimeout(() => saveContent(next), 350);
//   }, [saveContent]);
//   useEffect(() => () => { if (timerRef.current) clearTimeout(timerRef.current); }, []);

export function useDebouncedSaveContent(
    saveContent: (next: string) => void,
    delay: number = 350,
): (next: string) => void {
    const timerRef = React.useRef<any>(null);
    const saveRef = React.useRef(saveContent);
    React.useEffect(() => { saveRef.current = saveContent; }, [saveContent]);
    React.useEffect(
        () => () => {
            if (timerRef.current) clearTimeout(timerRef.current);
        },
        [],
    );
    return React.useCallback((next: string) => {
        if (timerRef.current) clearTimeout(timerRef.current);
        timerRef.current = setTimeout(() => {
            saveRef.current(next);
        }, delay);
    }, [delay]);
}

// ---------------------------------------------------------------------------
// useRemoteModule — dynamic ESM import with dedupe, cache, and loading/
// error state. Replaces ad-hoc `ensureMonaco()` / `loadScript()` wrappers.
// ---------------------------------------------------------------------------

const _moduleCache = new Map<string, Promise<any>>();

export function useRemoteModule<T = any>(url: string): {
    module: T | null;
    loading: boolean;
    error: Error | null;
} {
    const [state, setState] = React.useState<{
        module: T | null; loading: boolean; error: Error | null;
    }>({ module: null, loading: true, error: null });
    React.useEffect(() => {
        let cancelled = false;
        let p = _moduleCache.get(url);
        if (!p) {
            // @vite-ignore / @rollup-ignore — the URL is dynamic at runtime.
            p = import(/* @vite-ignore */ url);
            _moduleCache.set(url, p);
        }
        p.then((mod) => {
            if (!cancelled) setState({ module: mod as T, loading: false, error: null });
        }).catch((err: Error) => {
            if (!cancelled) setState({ module: null, loading: false, error: err });
        });
        return () => { cancelled = true; };
    }, [url]);
    return state;
}

// ---------------------------------------------------------------------------
// useRemoteScript — dynamic <script> tag loader with dedupe. For UMD-style
// bundles that expose themselves on `window` (e.g. the monaco loader).
// ---------------------------------------------------------------------------

const _scriptCache = new Map<string, Promise<void>>();

export function useRemoteScript(url: string): { loading: boolean; error: Error | null } {
    const [state, setState] = React.useState<{ loading: boolean; error: Error | null }>(
        { loading: true, error: null },
    );
    React.useEffect(() => {
        let cancelled = false;
        let p = _scriptCache.get(url);
        if (!p) {
            p = new Promise<void>((resolve, reject) => {
                if (document.querySelector(`script[src="${url}"]`)) { resolve(); return; }
                const s = document.createElement('script');
                s.src = url;
                s.onload = () => resolve();
                s.onerror = () => reject(new Error(`Failed to load: ${url}`));
                document.head.appendChild(s);
            });
            _scriptCache.set(url, p);
        }
        p.then(() => { if (!cancelled) setState({ loading: false, error: null }); })
         .catch((err: Error) => { if (!cancelled) setState({ loading: false, error: err }); });
        return () => { cancelled = true; };
    }, [url]);
    return state;
}
