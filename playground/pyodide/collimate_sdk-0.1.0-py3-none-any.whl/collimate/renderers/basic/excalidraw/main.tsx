import React, { useEffect, useRef, useCallback } from 'https://esm.sh/react@18';
import * as ExcalidrawMod from 'https://esm.sh/@excalidraw/excalidraw@0.17.6?deps=react@18,react-dom@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

const Excalidraw = ExcalidrawMod.Excalidraw || ExcalidrawMod.default?.Excalidraw || ExcalidrawMod.default;

function ExcalidrawWrapper() {
    const { content, saveContent, isReadOnly, api } = useCollimateFile();

    useEffect(() => {
        let cancelled = false;
        api.injectStyle(`
            html, body, #mount { width: 100%; height: 100%; margin: 0; padding: 0; overflow: hidden; background: #1A1C23; }
        `);
        // Wait for the excalidraw stylesheet before signalling ready — otherwise
        // the canvas paints with default (light) styles for a flash.
        api.loadCSS('https://cdn.jsdelivr.net/npm/@excalidraw/excalidraw@0.17.6/index.css')
            .then(() => {
                if (cancelled) return;
                // One rAF so excalidraw's own first paint has landed before we
                // lift the overlay.
                requestAnimationFrame(() => { if (!cancelled && api.ready) api.ready(); });
            });
        return () => { cancelled = true; };
    }, [api]);

    let initialData = { elements: [], appState: { theme: 'dark' }, files: {} };
    try { if (content) initialData = JSON.parse(content); } catch (e) {}

    const timerRef = useRef(null);
    const handleChange = useCallback((els, state, files) => {
        if (isReadOnly) return;
        if (timerRef.current) clearTimeout(timerRef.current);
        timerRef.current = setTimeout(() => {
            const payload = {
                type: "excalidraw", version: 2, source: "collimate",
                elements: els,
                appState: { 
                    theme: state.theme, 
                    viewBackgroundColor: state.viewBackgroundColor 
                },
                files
            };
            saveContent(JSON.stringify(payload, null, 2));
        }, 500);
    }, [isReadOnly, saveContent]);

    return (
        <div style={{ width: '100%', height: '100%' }}>
            <Excalidraw 
                initialData={initialData} 
                onChange={!isReadOnly ? handleChange : undefined}
                viewModeEnabled={isReadOnly}
            />
        </div>
    );
}

// deferReady: excalidraw ships its own stylesheet; auto-ready would lift the
// overlay before that stylesheet lands.
export default defineRenderer({ component: ExcalidrawWrapper, deferReady: true });
