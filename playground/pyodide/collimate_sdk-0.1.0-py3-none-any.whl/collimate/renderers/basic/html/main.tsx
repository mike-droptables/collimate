import React, { useEffect, useRef, useState } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

const MONACO_VERSION = '0.44.0';
const MONACO_BASE = `https://cdn.jsdelivr.net/npm/monaco-editor@${MONACO_VERSION}/min/vs`;

function loadScript(src) {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`script[src="${src}"]`)) { resolve(); return; }
    const s = document.createElement('script');
    s.src = src;
    s.onload = resolve;
    s.onerror = () => reject(new Error(`Failed to load: ${src}`));
    document.head.appendChild(s);
  });
}

let _monacoPromise = null;
function ensureMonaco() {
  if (_monacoPromise) return _monacoPromise;
  _monacoPromise = loadScript(`${MONACO_BASE}/loader.js`).then(() =>
    new Promise((resolve) => {
      window.require.config({ paths: { vs: MONACO_BASE } });
      window.require(['vs/editor/editor.main'], () => resolve(window.monaco));
    })
  );
  return _monacoPromise;
}

function HtmlEditor() {
    const { content, saveContent, isReadOnly, api } = useCollimateFile();
    const containerRef = useRef(null);
    const editorRef = useRef(null);
    const [previewHtml, setPreviewHtml] = useState('');

    useEffect(() => {
        const process = async () => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(content, 'text/html');
            const elements = [...doc.querySelectorAll('[src], [href]')];
            for (const el of elements) {
                let url = el.getAttribute('src') || el.getAttribute('href');
                if (url && !url.startsWith('http') && !url.startsWith('data:') && !url.startsWith('blob:') && !url.startsWith('#')) {
                    try {
                        const cleanPath = url.replace(/^\.\//, '');
                        const siblingContent = await api.getSiblingFile(cleanPath);
                        let mime = 'text/plain';
                        if (cleanPath.endsWith('.js')) mime = 'application/javascript';
                        else if (cleanPath.endsWith('.css')) mime = 'text/css';
                        else if (cleanPath.endsWith('.svg')) mime = 'image/svg+xml';
                        
                        const blob = new Blob([siblingContent], { type: mime });
                        const blobUrl = URL.createObjectURL(blob);
                        if (el.hasAttribute('src')) el.setAttribute('src', blobUrl);
                        if (el.hasAttribute('href')) el.setAttribute('href', blobUrl);
                    } catch(e) {}
                }
            }
            setPreviewHtml(doc.documentElement.outerHTML);
        };
        process();
    }, [content, api]);

    useEffect(() => {
        if (isReadOnly || !containerRef.current) return;
        let editor;
        ensureMonaco().then(monaco => {
            editor = monaco.editor.create(containerRef.current, {
                value: content,
                language: 'html',
                theme: 'vs-dark',
                automaticLayout: true,
                minimap: { enabled: false }
            });
            editor.onDidChangeModelContent(() => {
                saveContent(editor.getValue());
            });
            editorRef.current = editor;
        });
        return () => { if (editor) editor.dispose(); };
    }, [isReadOnly]);

    return (
        <div style={{ display: 'flex', width: '100%', height: '100%', backgroundColor: '#1e1e1e' }}>
            {!isReadOnly && <div ref={containerRef} style={{ flex: 1, borderRight: '1px solid #333' }} />}
            <div style={{ flex: 1, backgroundColor: 'white', position: 'relative' }}>
                <iframe 
                    srcDoc={previewHtml} 
                    style={{ width: '100%', height: '100%', border: 'none' }} 
                    sandbox="allow-scripts allow-forms allow-same-origin allow-popups"
                />
            </div>
        </div>
    );
}

export default defineRenderer({ component: HtmlEditor });
