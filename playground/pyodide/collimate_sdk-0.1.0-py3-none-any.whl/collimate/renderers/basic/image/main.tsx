import React, { useState, useEffect, useRef } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

function ImageViewer() {
    const { fileName, api } = useCollimateFile();
    const [imgUrl, setImgUrl] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [naturalSize, setNaturalSize] = useState<{ w: number; h: number } | null>(null);
    const [zoom, setZoom] = useState(1);
    const containerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const url = api.getFileUrl(fileName);
        setImgUrl(url);
        setError(null);
        setNaturalSize(null);
        setZoom(1);
    }, [fileName, api]);

    const handleLoad = (e: React.SyntheticEvent<HTMLImageElement>) => {
        const img = e.currentTarget;
        setNaturalSize({ w: img.naturalWidth, h: img.naturalHeight });
    };

    const handleError = () => {
        setError('Failed to load image');
    };

    const ext = fileName.split('.').pop()?.toLowerCase() || '';

    return (
        <div style={{
            width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
            background: '#0a0b0d', overflow: 'hidden',
        }}>
            <div
                ref={containerRef}
                style={{
                    flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
                    overflow: 'auto', padding: 16,
                    backgroundImage: 'linear-gradient(45deg, #1a1c23 25%, transparent 25%), linear-gradient(-45deg, #1a1c23 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #1a1c23 75%), linear-gradient(-45deg, transparent 75%, #1a1c23 75%)',
                    backgroundSize: '20px 20px',
                    backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px',
                }}
            >
                {error ? (
                    <div style={{ color: '#ef4444', fontFamily: 'monospace', fontSize: 13 }}>{error}</div>
                ) : imgUrl ? (
                    <img
                        src={imgUrl}
                        onLoad={handleLoad}
                        onError={handleError}
                        style={{
                            maxWidth: zoom === 1 ? '100%' : 'none',
                            maxHeight: zoom === 1 ? '100%' : 'none',
                            width: zoom !== 1 ? `${zoom * 100}%` : 'auto',
                            height: 'auto',
                            objectFit: 'contain',
                            imageRendering: zoom > 2 ? 'pixelated' : 'auto',
                        }}
                        draggable={false}
                    />
                ) : null}
            </div>
            <div style={{
                height: 26, background: '#1a1c23', borderTop: '1px solid #2a2d3a',
                display: 'flex', alignItems: 'center', padding: '0 12px', gap: 16,
                fontFamily: 'monospace', fontSize: 10, color: '#6b7280', flexShrink: 0,
            }}>
                <span>{fileName}</span>
                {naturalSize && <span>{naturalSize.w} x {naturalSize.h}</span>}
                <span>{ext.toUpperCase()}</span>
                <div style={{ marginLeft: 'auto', display: 'flex', gap: 8, alignItems: 'center' }}>
                    <button
                        onClick={() => setZoom(z => Math.max(0.25, z / 2))}
                        style={{
                            background: 'none', border: '1px solid #2a2d3a', color: '#6b7280',
                            cursor: 'pointer', padding: '1px 6px', borderRadius: 3, fontSize: 10,
                            fontFamily: 'monospace',
                        }}
                    >-</button>
                    <span>{Math.round(zoom * 100)}%</span>
                    <button
                        onClick={() => setZoom(z => Math.min(8, z * 2))}
                        style={{
                            background: 'none', border: '1px solid #2a2d3a', color: '#6b7280',
                            cursor: 'pointer', padding: '1px 6px', borderRadius: 3, fontSize: 10,
                            fontFamily: 'monospace',
                        }}
                    >+</button>
                    <button
                        onClick={() => setZoom(1)}
                        style={{
                            background: 'none', border: '1px solid #2a2d3a', color: '#6b7280',
                            cursor: 'pointer', padding: '1px 6px', borderRadius: 3, fontSize: 10,
                            fontFamily: 'monospace',
                        }}
                    >Fit</button>
                </div>
            </div>
        </div>
    );
}

export default defineRenderer({ component: ImageViewer });
