import React, { useState, useEffect } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

// Block javascript:, data:, vbscript: URLs (and similar) — these would otherwise execute
// inside the renderer's shadow DOM, which has access to the SDK API.
function safeUrl(raw) {
  const trimmed = String(raw).trim();
  if (/^(javascript|data|vbscript|file):/i.test(trimmed)) return '#';
  return trimmed.replace(/"/g, '&quot;');
}

// Super simple regex-based markdown parser
function parseMarkdown(md) {
  if (!md) return '';
  let html = md.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  html = html.replace(/```(\w*)\n([\s\S]*?)```/gm, (_, lang, code) => `<pre><code style="background:#1a1c23;padding:12px;display:block;border-radius:6px;border:1px solid #2a2d3a;">${code.trimEnd()}</code></pre>`);
  html = html.replace(/`([^`\n]+)`/g, '<code style="background:#1f2937;color:#f59e0b;padding:2px 4px;border-radius:3px;">$1</code>');
  html = html.replace(/^###### (.+)$/gm, '<h6 style="color:#f9fafb;font-weight:600;margin-top:1em;">$1</h6>');
  html = html.replace(/^##### (.+)$/gm, '<h5 style="color:#f9fafb;font-weight:600;margin-top:1em;">$1</h5>');
  html = html.replace(/^#### (.+)$/gm, '<h4 style="color:#f9fafb;font-weight:600;margin-top:1em;">$1</h4>');
  html = html.replace(/^### (.+)$/gm, '<h3 style="color:#f9fafb;font-weight:600;margin-top:1em;font-size:1.1em;">$1</h3>');
  html = html.replace(/^## (.+)$/gm, '<h2 style="color:#f9fafb;font-weight:600;margin-top:1em;font-size:1.35em;">$1</h2>');
  html = html.replace(/^# (.+)$/gm, '<h1 style="color:#f9fafb;font-weight:600;margin-top:1em;font-size:1.75em;border-bottom:1px solid #374151;padding-bottom:4px;">$1</h1>');
  html = html.replace(/^---+$/gm, '<hr style="border-top:1px solid #374151;margin:1.5em 0;">');
  html = html.replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>');
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
  html = html.replace(/^&gt; (.+)$/gm, '<blockquote style="border-left:3px solid #374151;padding-left:1em;color:#9ca3af;margin:1em 0;"><p>$1</p></blockquote>');
  html = html.replace(/^[*\-] (.+)$/gm, '<li style="margin:0.25em 0;">$1</li>');
  html = html.replace(/(<li style="margin:0.25em 0;">[\s\S]*?<\/li>\n?)+/g, (m) => `<ul style="padding-left:1.5em;margin:0.5em 0;">${m}</ul>`);
  html = html.replace(/^\d+\. (.+)$/gm, '<li style="margin:0.25em 0;">$1</li>');
  html = html.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, (_m, alt, src) => `<img alt="${alt}" src="${safeUrl(src)}" style="max-width:100%">`);
  html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_m, text, href) => `<a href="${safeUrl(href)}" style="color:#60a5fa;text-decoration:underline;">${text}</a>`);
  html = html.replace(/\n\n+/g, '\n\n');
  html = html.split('\n\n').map((block) => {
    if (/^<[hpuobldi]/.test(block.trim())) return block;
    return `<p style="margin:0.75em 0;">${block}</p>`;
  }).join('\n');
  return html;
}

function MarkdownEditor() {
    const { content, saveContent, isReadOnly } = useCollimateFile();
    const [local, setLocal] = useState(content);

    useEffect(() => { setLocal(content); }, [content]);

    return (
        <div style={{ display: 'flex', width: '100%', height: '100%', background: '#0a0b0d' }}>
            {!isReadOnly && (
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', borderRight: '1px solid #2a2d3a' }}>
                    <textarea
                        value={local}
                        onChange={e => {
                            setLocal(e.target.value);
                            saveContent(e.target.value);
                        }}
                        style={{ flex: 1, background: 'transparent', color: '#e2e8f0', fontFamily: 'monospace', fontSize: 13, lineHeight: 1.6, padding: 16, border: 'none', outline: 'none', resize: 'none' }}
                        spellCheck={false}
                    />
                </div>
            )}
            <div
                style={{ flex: 1, overflowY: 'auto', padding: 24, color: '#d1d5db', fontFamily: 'sans-serif', fontSize: 14, lineHeight: 1.6 }}
                dangerouslySetInnerHTML={{ __html: parseMarkdown(local) }}
            />
        </div>
    );
}

export default defineRenderer({ component: MarkdownEditor });
