import React, { useState, useEffect, useRef } from 'https://esm.sh/react@18';
import mermaid from 'https://esm.sh/mermaid@10.9.0';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

mermaid.initialize({
  startOnLoad: false,
  theme: 'dark',
  securityLevel: 'strict',
  fontFamily: 'system-ui, -apple-system, Helvetica, Arial, sans-serif',
});

function MermaidView() {
  const { content, saveContent, isReadOnly } = useCollimateFile();
  const [local, setLocal] = useState(content);
  const [svg, setSvg] = useState('');
  const [error, setError] = useState('');
  const idRef = useRef(`mmd-${Math.random().toString(36).slice(2, 10)}`);

  useEffect(() => { setLocal(content); }, [content]);

  useEffect(() => {
    let cancelled = false;
    const src = (local || '').trim();
    if (!src) { setSvg(''); setError(''); return; }
    mermaid
      .render(idRef.current, src)
      .then(({ svg }) => { if (!cancelled) { setSvg(svg); setError(''); } })
      .catch((e) => { if (!cancelled) { setError(String(e && e.message || e)); setSvg(''); } });
    return () => { cancelled = true; };
  }, [local]);

  return (
    <div style={{ display: 'flex', width: '100%', height: '100%', background: '#0a0b0d', color: '#e2e8f0' }}>
      {!isReadOnly && (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', borderRight: '1px solid #2a2d3a' }}>
          <div style={{ padding: '6px 12px', fontSize: 11, color: '#6b7280', borderBottom: '1px solid #2a2d3a', background: '#0f1014' }}>
            mermaid source
          </div>
          <textarea
            value={local}
            onChange={(e) => { setLocal(e.target.value); saveContent(e.target.value); }}
            spellCheck={false}
            style={{
              flex: 1,
              background: 'transparent',
              color: '#e2e8f0',
              fontFamily: 'ui-monospace, Menlo, Consolas, monospace',
              fontSize: 13,
              lineHeight: 1.55,
              padding: 14,
              border: 'none',
              outline: 'none',
              resize: 'none',
            }}
          />
        </div>
      )}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <div style={{ padding: '6px 12px', fontSize: 11, color: '#6b7280', borderBottom: '1px solid #2a2d3a', background: '#0f1014' }}>
          preview
        </div>
        <div style={{ flex: 1, overflow: 'auto', padding: 16, display: 'flex', alignItems: 'flex-start', justifyContent: 'center' }}>
          {error ? (
            <pre style={{ color: '#f87171', fontFamily: 'ui-monospace, Menlo, monospace', fontSize: 12, whiteSpace: 'pre-wrap', maxWidth: '100%' }}>
              {error}
            </pre>
          ) : svg ? (
            <div style={{ maxWidth: '100%' }} dangerouslySetInnerHTML={{ __html: svg }} />
          ) : (
            <div style={{ color: '#4b5563', fontSize: 12 }}>(empty)</div>
          )}
        </div>
      </div>
    </div>
  );
}

export default defineRenderer({ component: MermaidView });
