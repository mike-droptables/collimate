import React, { useEffect, useRef } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';
import * as CrepeMod from 'https://esm.sh/@milkdown/crepe@7.19.1?deps=codemirror@6.0.1';

const Crepe = CrepeMod.Crepe || CrepeMod.default?.Crepe || CrepeMod.default;

function MilkdownEditor() {
    const { content, saveContent, isReadOnly, api } = useCollimateFile();
    const containerRef = useRef(null);
    const crepeRef = useRef(null);

    useEffect(() => {
        // Merge CSS load + crepe.create() into a single setup sequence so we
        // only signal api.ready() once everything the user can see is painted.
        // Previously the overlay lifted on the next rAF after mount() returned,
        // exposing ~100–300ms of unstyled content while the theme stylesheets
        // were still resolving and crepe was mid-create.
        if (!containerRef.current) return;
        let crepe = null;
        let cancelled = false;

        (async () => {
            await Promise.all([
                api.loadCSS('https://cdn.jsdelivr.net/npm/@milkdown/crepe@7.19.1/lib/theme/common/style.css'),
                api.loadCSS('https://cdn.jsdelivr.net/npm/@milkdown/crepe@7.19.1/lib/theme/frame/style.css'),
            ]);
            api.injectStyle(`
                html, body { margin: 0; padding: 0; width: 100%; height: 100%; overflow: hidden; background: #0a0b0d; }
                .milkdown { background: #0a0b0d; color: #e2e5ea; }
                .milkdown .ProseMirror { padding: 24px 32px 24px 72px; min-height: 100%; outline: none; }
            `);
            if (cancelled || !containerRef.current) return;

            crepe = new Crepe({
                root: containerRef.current,
                defaultValue: content || '',
            });
            if (!isReadOnly) {
                crepe.on((listener) => {
                    listener.markdownUpdated((ctx, markdown) => { saveContent(markdown); });
                });
            }
            await crepe.create();
            if (cancelled) { crepe.destroy(); return; }
            if (isReadOnly) crepe.setReadonly(true);
            crepeRef.current = crepe;

            // Now actually painted with the right styles — lift the overlay.
            if (api.ready) api.ready();
        })();

        return () => {
            cancelled = true;
            if (crepeRef.current) crepeRef.current.destroy();
            crepeRef.current = null;
        };
    }, []); // Run once on mount

    return <div ref={containerRef} style={{ width: '100%', height: '100%', overflowY: 'auto', background: '#0a0b0d' }} />;
}

// deferReady: crepe loads external CSS + async-creates its editor; the wrapper's
// auto-ready would lift the overlay before any of that finishes painting.
export default defineRenderer({ component: MilkdownEditor, deferReady: true });
