import React, { useEffect, useRef } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

const MONACO_VERSION = '0.44.0';
const MONACO_BASE = `https://cdn.jsdelivr.net/npm/monaco-editor@${MONACO_VERSION}/min/vs`;

function loadScript(src) {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`script[src="${src}"]`)) { resolve(); return; }
    const s = document.createElement('script');
    s.src = src;
    s.onload = resolve;
    s.onerror = () => reject(new Error(`Failed to load: ${src}`));
    document.head.appendChild(s);
  });
}

let _monacoPromise = null;
function ensureMonaco() {
  if (_monacoPromise) return _monacoPromise;
  _monacoPromise = loadScript(`${MONACO_BASE}/loader.js`).then(() =>
    new Promise((resolve) => {
      window.require.config({ paths: { vs: MONACO_BASE } });
      window.require(['vs/editor/editor.main'], () => resolve(window.monaco));
    })
  );
  return _monacoPromise;
}

function detectLanguage(content = '', filename = '') {
  const ext = filename.split('.').pop().toLowerCase();
  const extMap = {
    'js': 'javascript', 'jsx': 'javascript', 'mjs': 'javascript', 'cjs': 'javascript',
    'ts': 'typescript', 'tsx': 'typescript',
    'py': 'python', 'go': 'go', 'rs': 'rust', 'java': 'java',
    'c': 'c', 'h': 'c', 'cpp': 'cpp', 'hpp': 'cpp',
    'css': 'css', 'scss': 'scss', 'less': 'less',
    'html': 'html', 'xml': 'xml', 'svg': 'xml',
    'json': 'json', 'jsonc': 'json',
    'yaml': 'yaml', 'yml': 'yaml', 'toml': 'toml',
    'sql': 'sql', 'graphql': 'graphql', 'gql': 'graphql',
    'sh': 'shell', 'bash': 'shell', 'zsh': 'shell', 'fish': 'shell'
  };

  if (extMap[ext]) return extMap[ext];

  const t = content.trimStart();
  if (/^(import|export|const|let|var|function|class|interface|type )\b/.test(t)) return 'typescript';
  if (/^(import |from |def |class |async def )/.test(t) || t.startsWith('#!/usr/bin/env python')) return 'python';
  if (/^package /.test(t) || /^func /.test(t)) return 'go';
  if (/^(fn |use |struct |impl |pub )/.test(t)) return 'rust';
  if (/^(SELECT|INSERT|UPDATE|DELETE|CREATE|DROP)\b/i.test(t)) return 'sql';
  if (t.startsWith('<') && /<html|<div|<span/i.test(t)) return 'html';
  if (t.startsWith('{') || t.startsWith('[')) return 'json';
  if (/^(#|---\n)/.test(t)) return 'yaml';
  return 'plaintext';
}

function MonacoEditor() {
    const { content, saveContent, isReadOnly, fileName, api } = useCollimateFile();
    const containerRef = useRef(null);
    const editorRef = useRef(null);

    useEffect(() => {
        if (!containerRef.current) return;
        let editor;
        let cancelled = false;
        ensureMonaco().then(monaco => {
            if (cancelled || !containerRef.current) return;
            editor = monaco.editor.create(containerRef.current, {
                value: content || '',
                language: detectLanguage(content, fileName),
                theme: 'vs-dark',
                readOnly: isReadOnly,
                automaticLayout: true,
                minimap: { enabled: false }
            });
            if (!isReadOnly) {
                editor.onDidChangeModelContent(() => saveContent(editor.getValue()));
            }
            editorRef.current = editor;
            // Monaco's first paint lands a frame after create() — yield once
            // so the styled editor is visible before the overlay lifts.
            requestAnimationFrame(() => { if (!cancelled && api && api.ready) api.ready(); });
        });
        return () => { cancelled = true; if (editor) editor.dispose(); };
    }, []); // mount once

    useEffect(() => {
        if (editorRef.current && editorRef.current.getValue() !== content) {
            editorRef.current.setValue(content || '');
        }
    }, [content]);

    return <div ref={containerRef} style={{ width: '100%', height: '100%', backgroundColor: '#1e1e1e' }} />;
}

function MonacoDiffEditor() {
    const { content, diffContent, fileName, api } = useCollimateFile();
    const containerRef = useRef(null);

    useEffect(() => {
        if (!containerRef.current) return;
        let diffEditor;
        let cancelled = false;
        ensureMonaco().then(monaco => {
            if (cancelled || !containerRef.current) return;
            diffEditor = monaco.editor.createDiffEditor(containerRef.current, {
                theme: 'vs-dark',
                automaticLayout: true,
                renderSideBySide: true,
                readOnly: true
            });
            const lang = detectLanguage(content, fileName);
            diffEditor.setModel({
                original: monaco.editor.createModel(diffContent || '', lang),
                modified: monaco.editor.createModel(content || '', lang)
            });
            requestAnimationFrame(() => { if (!cancelled && api && api.ready) api.ready(); });
        });
        return () => { cancelled = true; if (diffEditor) diffEditor.dispose(); };
    }, [content, diffContent, fileName]);

    return <div ref={containerRef} style={{ width: '100%', height: '100%', backgroundColor: '#1e1e1e' }} />;
}

// deferReady: monaco's loader script + editor.create are async; the wrapper's
// auto-ready would reveal a blank dark box for a few frames.
export default defineRenderer({
    component: MonacoEditor,
    diffComponent: MonacoDiffEditor,
    deferReady: true,
});
