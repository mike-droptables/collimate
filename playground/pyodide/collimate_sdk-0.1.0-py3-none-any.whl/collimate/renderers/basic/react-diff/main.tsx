import React from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

function StandardEditor() {
    const { content, saveContent, isReadOnly } = useCollimateFile();

    return (
        <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: '#020617', padding: 16 }}>
            <h2 style={{ color: '#34d399', fontWeight: 'bold', marginBottom: 8, textTransform: 'uppercase', fontSize: 12, letterSpacing: '0.1em' }}>Standard Mode</h2>
            <textarea
                value={content}
                disabled={isReadOnly}
                onChange={e => saveContent(e.target.value)}
                style={{ flex: 1, background: '#0f172a', border: '1px solid #1e293b', color: '#cbd5e1', fontFamily: 'monospace', padding: 16, outline: 'none', resize: 'none' }}
            />
        </div>
    );
}

function DiffViewer() {
    const { content, diffContent } = useCollimateFile();

    return (
        <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: '#020617', padding: 16 }}>
            <h2 style={{ color: '#fbbf24', fontWeight: 'bold', marginBottom: 8, textTransform: 'uppercase', fontSize: 12, letterSpacing: '0.1em' }}>Diff Mode Component</h2>
            <div style={{ flex: 1, display: 'flex', gap: 16 }}>
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                    <span style={{ fontSize: 12, color: '#64748b', marginBottom: 4 }}>Previous</span>
                    <pre style={{ flex: 1, background: 'rgba(69, 10, 10, 0.3)', border: '1px solid rgba(127, 29, 29, 0.5)', color: '#fca5a5', padding: 16, overflow: 'auto', fontFamily: 'monospace', fontSize: 14 }}>{diffContent}</pre>
                </div>
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                    <span style={{ fontSize: 12, color: '#64748b', marginBottom: 4 }}>Current</span>
                    <pre style={{ flex: 1, background: 'rgba(6, 78, 59, 0.3)', border: '1px solid rgba(6, 95, 70, 0.5)', color: '#6ee7b7', padding: 16, overflow: 'auto', fontFamily: 'monospace', fontSize: 14 }}>{content}</pre>
                </div>
            </div>
        </div>
    );
}

export default defineRenderer({
    component: StandardEditor,
    diffComponent: DiffViewer
});
