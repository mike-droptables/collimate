import React, { useEffect, useMemo, useRef, useState } from 'https://esm.sh/react@18';
import { Terminal } from 'https://esm.sh/xterm@5.3.0';
import { FitAddon } from 'https://esm.sh/xterm-addon-fit@0.8.0';
import { WebLinksAddon } from 'https://esm.sh/xterm-addon-web-links@0.9.0';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

type Parsed = {
    session_id: string;
    ws_path: string;
    token: string;
    label: string;
};

function parseContent(raw: string): Parsed | null {
    try {
        const j = JSON.parse(raw || '');
        if (typeof j.session_id !== 'string' || !j.session_id) return null;
        if (typeof j.ws_path !== 'string' || !j.ws_path) return null;
        return {
            session_id: j.session_id,
            ws_path: j.ws_path,
            token: typeof j.token === 'string' ? j.token : '',
            label: typeof j.label === 'string' ? j.label : 'terminal',
        };
    } catch {
        return null;
    }
}

function buildWsUrl(ws_path: string, token: string): string {
    const base = new URL(ws_path, window.location.origin);
    base.protocol = base.protocol === 'https:' ? 'wss:' : 'ws:';
    if (token) base.searchParams.set('token', token);
    return base.toString();
}

function TerminalViewer() {
    const { content, api } = useCollimateFile();
    const parsed = useMemo<Parsed | null>(() => parseContent(content), [content]);
    const hostRef = useRef<HTMLDivElement | null>(null);
    const [status, setStatus] = useState<'connecting' | 'open' | 'closed' | 'error' | 'idle'>('idle');
    const [attempt, setAttempt] = useState(0);

    useEffect(() => {
        if (!parsed || !hostRef.current) return;
        let cancelled = false;

        api.loadCSS('https://esm.sh/xterm@5.3.0/css/xterm.css');

        const term = new Terminal({
            cursorBlink: true,
            fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
            fontSize: 13,
            theme: {
                background: '#0a0b0d',
                foreground: '#e2e8f0',
                cursor: '#7fcfa8',
            },
            convertEol: false,
            scrollback: 5000,
            allowProposedApi: true,
        });
        const fit = new FitAddon();
        term.loadAddon(fit);
        term.loadAddon(new WebLinksAddon());
        term.open(hostRef.current);
        try { fit.fit(); } catch {}

        const url = buildWsUrl(parsed.ws_path, parsed.token);
        setStatus('connecting');
        const ws = new WebSocket(url);
        ws.binaryType = 'arraybuffer';
        const encoder = new TextEncoder();
        let lastCols = 0;
        let lastRows = 0;

        const sendResize = () => {
            try { fit.fit(); } catch { return; }
            const cols = term.cols;
            const rows = term.rows;
            if (cols === lastCols && rows === lastRows) return;
            lastCols = cols;
            lastRows = rows;
            if (ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({ t: 'resize', cols, rows }));
            }
        };

        ws.onopen = () => {
            if (cancelled) return;
            setStatus('open');
            sendResize();
            term.focus();
        };

        ws.onmessage = (ev) => {
            if (ev.data instanceof ArrayBuffer) {
                term.write(new Uint8Array(ev.data));
            } else if (typeof ev.data === 'string') {
                term.write(ev.data);
            }
        };

        ws.onclose = () => {
            if (cancelled) return;
            setStatus('closed');
            term.write('\r\n\x1b[33m[connection closed]\x1b[0m\r\n');
        };

        ws.onerror = () => {
            if (cancelled) return;
            setStatus('error');
        };

        const disposeOnData = term.onData((d) => {
            if (ws.readyState === WebSocket.OPEN) {
                ws.send(encoder.encode(d));
            }
        });

        const ro = new ResizeObserver(() => sendResize());
        ro.observe(hostRef.current);

        return () => {
            cancelled = true;
            ro.disconnect();
            disposeOnData.dispose();
            try { ws.close(); } catch {}
            term.dispose();
        };
    }, [parsed?.session_id, parsed?.token, parsed?.ws_path, attempt]);

    if (!parsed) {
        return (
            <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#0a0b0d', color: '#6b7280', fontFamily: 'monospace', fontSize: 12, padding: 16, textAlign: 'center' }}>
                Invalid .terminal file — expected JSON with {`{ session_id, ws_path, token }`}.
            </div>
        );
    }

    const statusColor =
        status === 'open' ? '#7fcfa8' :
        status === 'connecting' ? '#d4a94f' :
        status === 'error' ? '#e06c75' :
        '#6b7280';

    return (
        <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: '#0a0b0d' }}>
            <div style={{ height: 24, background: '#1a1c23', borderBottom: '1px solid #2a2d3a', display: 'flex', alignItems: 'center', padding: '0 8px', gap: 8, flexShrink: 0, fontFamily: 'monospace', fontSize: 11 }}>
                <span style={{ color: '#9ca3af' }}>{parsed.label}</span>
                <span style={{ color: statusColor }}>● {status}</span>
                {(status === 'closed' || status === 'error') && (
                    <button
                        onClick={() => setAttempt(a => a + 1)}
                        style={{ marginLeft: 'auto', height: 18, padding: '0 8px', background: '#2d2f3e', border: '1px solid #3a3d52', borderRadius: 3, color: '#e2e8f0', fontFamily: 'monospace', fontSize: 10, cursor: 'pointer' }}
                    >
                        Reconnect
                    </button>
                )}
            </div>
            <div
                ref={hostRef}
                style={{ flex: 1, padding: 4, overflow: 'hidden' }}
            />
        </div>
    );
}

export default defineRenderer({ component: TerminalViewer });
