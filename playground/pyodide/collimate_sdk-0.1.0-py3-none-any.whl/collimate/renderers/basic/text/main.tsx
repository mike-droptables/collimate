import React, { useState } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

function TextEditor() {
    const { content, saveContent, isReadOnly, fileName } = useCollimateFile();

    return (
        <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: '#0a0b0d' }}>
            <textarea
                value={content}
                disabled={isReadOnly}
                onChange={e => saveContent(e.target.value)}
                spellCheck={false}
                style={{ flex: 1, width: '100%', background: 'transparent', color: '#e2e8f0', fontFamily: 'monospace', fontSize: 13, lineHeight: 1.6, padding: 16, border: 'none', outline: 'none', resize: 'none' }}
            />
            <div style={{ height: 22, background: '#1a1c23', borderTop: '1px solid #2a2d3a', display: 'flex', alignItems: 'center', padding: '0 12px', gap: 12, fontFamily: 'monospace', fontSize: 10, color: '#6b7280' }}>
                <span>{content.split('\n').length} lines</span>
                <span>{content.length} chars</span>
                <span style={{ marginLeft: 'auto' }}>{fileName}</span>
            </div>
        </div>
    );
}

export default defineRenderer({ component: TextEditor });
