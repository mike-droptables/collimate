import React, { useMemo, useState } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

type ButtonSpec = { id: string; label: string };

type Parsed = { url: string; buttons: ButtonSpec[] };

function parseContent(raw: string): Parsed {
    const s = (raw || '').trim();
    if (s.startsWith('{')) {
        try {
            const j = JSON.parse(s);
            const url = typeof j.url === 'string' ? j.url.trim() : '';
            const buttons: ButtonSpec[] = Array.isArray(j.buttons)
                ? j.buttons
                      .filter((b: any) => b && typeof b.id === 'string' && typeof b.label === 'string')
                      .map((b: any) => ({ id: b.id, label: b.label }))
                : [];
            return { url, buttons };
        } catch {
            // fall through to plain-URL treatment
        }
    }
    return { url: s, buttons: [] };
}

function WebsiteViewer() {
    const { content, saveContent, isReadOnly, api } = useCollimateFile();
    const parsed = useMemo<Parsed>(() => parseContent(content), [content]);
    const [localUrl, setLocalUrl] = useState(parsed.url);
    const [activeUrl, setActiveUrl] = useState(parsed.url);
    const [pendingAction, setPendingAction] = useState<string | null>(null);
    const [actionStatus, setActionStatus] = useState<string>('');

    const commit = () => {
        const u = localUrl.trim();
        // Preserve the buttons config when the user edits the URL.
        if (parsed.buttons.length > 0) {
            saveContent(JSON.stringify({ url: u, buttons: parsed.buttons }));
        } else {
            saveContent(u);
        }
        setActiveUrl(u);
    };

    const resolveExternal = (u: string): string => {
        if (!u) return '';
        if (u.startsWith('http://') || u.startsWith('https://')) return u;
        try {
            return new URL(u, window.location.origin).toString();
        } catch {
            return u;
        }
    };

    const openExternal = () => {
        const target = resolveExternal(localUrl.trim() || activeUrl);
        if (target) window.open(target, '_blank', 'noopener,noreferrer');
    };

    const clickAction = async (id: string, label: string) => {
        if (pendingAction) return;
        setPendingAction(id);
        setActionStatus('');
        const ok = typeof api.emitAction === 'function' ? await api.emitAction(id) : false;
        setActionStatus(ok ? `${label} sent` : `${label} failed`);
        setPendingAction(null);
        setTimeout(() => setActionStatus(''), 2500);
    };

    return (
        <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: '#0a0b0d' }}>
            <div style={{ height: 32, background: '#1a1c23', borderBottom: '1px solid #2a2d3a', display: 'flex', alignItems: 'center', padding: '0 8px', gap: 8, flexShrink: 0 }}>
                <input
                    type="text"
                    value={localUrl}
                    onChange={e => setLocalUrl(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && commit()}
                    readOnly={isReadOnly}
                    placeholder="https://..."
                    style={{ flex: 1, height: 22, background: '#0d0f14', border: '1px solid #2a2d3a', borderRadius: 4, padding: '0 8px', color: '#e2e8f0', fontFamily: 'monospace', fontSize: 11, outline: 'none' }}
                />
                {!isReadOnly && (
                    <button
                        onClick={commit}
                        style={{ height: 22, padding: '0 12px', background: '#2d2f3e', border: '1px solid #3a3d52', borderRadius: 4, color: '#e2e8f0', fontFamily: 'monospace', fontSize: 11, cursor: 'pointer' }}
                    >
                        Go
                    </button>
                )}
                <button
                    onClick={openExternal}
                    title="Open in new browser tab"
                    style={{ height: 22, padding: '0 12px', background: '#2d2f3e', border: '1px solid #3a3d52', borderRadius: 4, color: '#e2e8f0', fontFamily: 'monospace', fontSize: 11, cursor: 'pointer' }}
                >
                    Open ↗
                </button>
                {parsed.buttons.map(b => {
                    const busy = pendingAction === b.id;
                    return (
                        <button
                            key={b.id}
                            onClick={() => clickAction(b.id, b.label)}
                            disabled={busy || !!pendingAction}
                            style={{ height: 22, padding: '0 12px', background: busy ? '#3a3d52' : '#1f4f3a', border: '1px solid #2e6b50', borderRadius: 4, color: '#d6f5e4', fontFamily: 'monospace', fontSize: 11, cursor: busy ? 'wait' : 'pointer', opacity: pendingAction && !busy ? 0.6 : 1 }}
                        >
                            {busy ? '…' : b.label}
                        </button>
                    );
                })}
                {actionStatus && (
                    <span style={{ color: '#7fcfa8', fontFamily: 'monospace', fontSize: 11 }}>{actionStatus}</span>
                )}
            </div>

            {activeUrl ? (
                <iframe
                    src={activeUrl}
                    style={{ flex: 1, width: '100%', border: 'none', background: 'white' }}
                    sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                />
            ) : (
                <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#4b5563', fontFamily: 'monospace', fontSize: 13 }}>
                    Enter a URL above and press Enter
                </div>
            )}
        </div>
    );
}

export default defineRenderer({ component: WebsiteViewer });
