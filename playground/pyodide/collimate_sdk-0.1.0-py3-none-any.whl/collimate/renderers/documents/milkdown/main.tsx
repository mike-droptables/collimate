import React, { useEffect, useRef, useState } from 'https://esm.sh/react@18';
import * as CrepeMod from 'https://esm.sh/@milkdown/crepe@7.21.2?deps=codemirror@6.0.1';
// ProseMirror plugin primitives, pulled from the SAME @milkdown/kit@7.21.2
// graph crepe itself imports. Both funnel through
// @milkdown/prose@7.21.2 → prosemirror-state/view, so these classes are the
// exact singletons crepe's editor uses — a separately-versioned import would
// hand us a different prosemirror instance and the plugin would be rejected.
import { $prose } from 'https://esm.sh/@milkdown/kit@7.21.2/utils?deps=codemirror@6.0.1';
import { Plugin, PluginKey } from 'https://esm.sh/@milkdown/kit@7.21.2/prose/state?deps=codemirror@6.0.1';
import { Decoration, DecorationSet } from 'https://esm.sh/@milkdown/kit@7.21.2/prose/view?deps=codemirror@6.0.1';
import {
    defineRenderer,
    useCollimateFile,
    useTheme,
} from '/api/sdk/react.js';

const Crepe = CrepeMod.Crepe || CrepeMod.default?.Crepe || CrepeMod.default;

// Crepe's "frame" theme assumes a dark surface; the dark-mode variant
// overrides it on [data-theme="dark"]. Toggle the attribute when the
// host scheme flips so Crepe's selectors fire.
function applySchemeToDocument(scheme) {
    document.documentElement.setAttribute('data-theme', scheme);
    if (scheme === 'dark') document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
}

// Text-size (reader zoom) bounds + persistence key. Stored in the iframe's
// localStorage so the chosen size survives reloads of the same channel.
const ZOOM_KEY = 'collimate.milkdown.readerZoom';
const ZOOM_MIN = 0.7;
const ZOOM_MAX = 2.2;
const ZOOM_STEP = 0.1;
const clampZoom = (v) => Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, Math.round(v * 100) / 100));
function readStoredZoom() {
    try {
        const v = parseFloat(localStorage.getItem(ZOOM_KEY) || '');
        return Number.isFinite(v) ? clampZoom(v) : 1;
    } catch { return 1; }
}

// ---------------------------------------------------------------------------
// Obsidian-style heading folding.
//
// Implemented as a ProseMirror plugin that paints DECORATIONS, never by
// mutating the editor DOM by hand: PM owns the contentEditable and its own
// DOM observer would treat a stray `display:none`/`data-*` we wrote as a
// foreign change, redraw the node, and wipe it (then our re-apply fights
// back — a flicker loop). Node decorations are applied by PM during its own
// render, so they're stable across edits and never trigger that fight.
//
// Fold state is a Set of "<level>|<heading text>" keys, kept in a React ref
// so it survives the destroy+recreate Crepe swap (FILES_CHANGED / SET_CONTENT)
// — fold the same headings back as long as their text is unchanged. Keying by
// text (not position) is what makes folds stick across an external edit that
// shifts positions; two headings with identical text fold together, an
// acceptable edge.
// ---------------------------------------------------------------------------
function foldKey(level, text) {
    return level + '|' + (text || '').replace(/\s+/g, ' ').trim().slice(0, 240);
}

// Folding is strictly additive: it depends on esm.sh handing us the SAME
// prosemirror-state/view instance crepe loaded (see the import note up top).
// That holds — both funnel through @milkdown/prose@7.21.2 — but if it ever
// didn't, a mismatched Plugin/Decoration would throw at editor-create time and
// take the whole editor down. This flag flips off the first time anything
// fold-related fails so every (re)build after that comes up as a plain crepe
// editor. The version bump alone is independently safe, so the editor always
// mounts.
let foldSupported = true;

// One plugin instance per editor (a PM Plugin is bound to a single state, and
// we recreate the editor on content swaps). The key is created per-instance.
//
// Everything is painted with DECORATIONS, never hand-mutated DOM — PM owns the
// contentEditable and its DOM observer would wipe foreign edits (then our
// re-apply fights back: a flicker loop). Per top-level heading we add:
//   • a node decoration carrying colmd-foldable [+colmd-folded] [+colmd-active]
//     so CSS can scope the chevron's reveal/rotation and the "…" indicator;
//   • a WIDGET decoration in the left gutter — a real <span> chevron that owns
//     its own click handler, so toggling is zoom-independent (no clientX math);
//   • when folded: a trailing WIDGET "…" (clickable, unfolds) plus display:none
//     node decorations on every block down to the next heading of equal-or-
//     higher rank (Obsidian's fold range).
// colmd-active = the caret sits inside this heading. That, or hovering the
// heading row, is the ONLY thing that reveals the chevron — hovering the body
// blocks beneath the heading does not.
function createFoldPlugin(foldStateRef) {
    const key = new PluginKey('colmd-fold');

    // Toggle the fold for whichever heading owns the clicked widget. Resolves
    // the heading from the live doc via getPos(), so there's no stale closure
    // even after edits shift positions.
    const toggleFromWidget = (view, getPos) => {
        const pos = getPos();
        if (pos == null) return;
        let heading;
        try { heading = view.state.doc.resolve(pos).parent; } catch { return; }
        if (!heading || heading.type.name !== 'heading') return;
        const fkey = foldKey(heading.attrs.level || 1, heading.textContent);
        const set = foldStateRef.current;
        if (set.has(fkey)) set.delete(fkey); else set.add(fkey);
        view.dispatch(view.state.tr.setMeta(key, true));
    };

    const widget = (className) => (view, getPos) => {
        const el = document.createElement('span');
        el.className = className;
        el.setAttribute('contenteditable', 'false');
        el.addEventListener('mousedown', (e) => {
            e.preventDefault();
            e.stopPropagation();
            toggleFromWidget(view, getPos);
        });
        return el;
    };

    const build = (state) => {
        const { doc, selection } = state;
        const head = selection.head;
        const tops = [];
        doc.forEach((node, offset) => { tops.push({ node, offset }); });
        const decos = [];
        for (let i = 0; i < tops.length; i++) {
            const { node, offset } = tops[i];
            if (node.type.name !== 'heading') continue;
            const level = node.attrs.level || 1;
            const folded = foldStateRef.current.has(foldKey(level, node.textContent));
            const active = head > offset && head < offset + node.nodeSize;
            const cls = ['colmd-foldable'];
            if (folded) cls.push('colmd-folded');
            if (active) cls.push('colmd-active');
            decos.push(Decoration.node(offset, offset + node.nodeSize, { class: cls.join(' ') }));
            // Gutter chevron — present on every heading, revealed by CSS.
            decos.push(Decoration.widget(offset + 1, widget('colmd-fold-toggle'),
                { side: -1, ignoreSelection: true, key: 'colmd-fold-toggle' }));
            if (!folded) continue;
            // Trailing "…" indicator (clickable to unfold), then hide the range.
            decos.push(Decoration.widget(offset + node.nodeSize - 1, widget('colmd-fold-ellipsis'),
                { side: 1, ignoreSelection: true, key: 'colmd-fold-ellipsis' }));
            for (let j = i + 1; j < tops.length; j++) {
                const sib = tops[j];
                if (sib.node.type.name === 'heading' && (sib.node.attrs.level || 1) <= level) break;
                decos.push(Decoration.node(sib.offset, sib.offset + sib.node.nodeSize, {
                    style: 'display: none;',
                }));
            }
        }
        return DecorationSet.create(doc, decos);
    };

    return new Plugin({
        key,
        state: {
            init: (_config, state) => build(state),
            // Rebuild on doc changes, explicit fold toggles, AND selection moves
            // (so the caret entering/leaving a heading flips colmd-active).
            apply: (tr, value, _old, newState) => {
                if (tr.docChanged || tr.getMeta(key) || tr.selectionSet) return build(newState);
                return value.map(tr.mapping, tr.doc);
            },
        },
        props: {
            decorations(state) { return key.getState(state); },
        },
    });
}

// Compact reader-size control (A− / % / A+) pinned to the top-right corner.
// Lives OUTSIDE the .milkdown surface (it's a sibling React node in the
// iframe) so its styling is independent of crepe's theme variables — it just
// follows the host light/dark scheme.
function ReaderSizeControl({ zoom, setZoom, scheme }) {
    const [hovered, setHovered] = useState(false);
    const dark = scheme === 'dark';
    const bg = dark ? '#232323' : '#f4f4f4';
    const border = dark ? '#3a3a3a' : '#d6d6d6';
    const fg = dark ? '#d1d1d1' : '#333333';
    const btn = {
        appearance: 'none',
        border: 'none',
        background: 'transparent',
        color: fg,
        cursor: 'pointer',
        fontFamily: 'Arial, Helvetica, sans-serif',
        fontWeight: 600,
        lineHeight: 1,
        padding: '4px 7px',
        borderRadius: 5,
    };
    return (
        <div
            onMouseEnter={() => setHovered(true)}
            onMouseLeave={() => setHovered(false)}
            style={{
                position: 'absolute',
                top: 8,
                right: 12,
                zIndex: 20,
                display: 'flex',
                alignItems: 'center',
                gap: 1,
                padding: 2,
                borderRadius: 8,
                background: bg,
                border: `1px solid ${border}`,
                boxShadow: dark
                    ? '0 1px 3px rgba(0,0,0,0.4)'
                    : '0 1px 3px rgba(0,0,0,0.12)',
                opacity: hovered ? 1 : 0.45,
                transition: 'opacity 0.15s ease',
                userSelect: 'none',
            }}
        >
            <button
                title="Smaller text"
                aria-label="Decrease text size"
                disabled={zoom <= ZOOM_MIN}
                onClick={() => setZoom((z) => clampZoom(z - ZOOM_STEP))}
                style={{ ...btn, fontSize: 12, opacity: zoom <= ZOOM_MIN ? 0.4 : 1 }}
            >A−</button>
            <button
                title="Reset text size"
                aria-label="Reset text size"
                onClick={() => setZoom(1)}
                style={{ ...btn, fontSize: 11, minWidth: 38, fontVariantNumeric: 'tabular-nums' }}
            >{Math.round(zoom * 100)}%</button>
            <button
                title="Larger text"
                aria-label="Increase text size"
                disabled={zoom >= ZOOM_MAX}
                onClick={() => setZoom((z) => clampZoom(z + ZOOM_STEP))}
                style={{ ...btn, fontSize: 17, opacity: zoom >= ZOOM_MAX ? 0.4 : 1 }}
            >A+</button>
        </div>
    );
}

function MilkdownEditor() {
    const { content, saveContent, isReadOnly, api } = useCollimateFile();
    const { scheme, onChange: onThemeChange } = useTheme(api);
    const containerRef = useRef(null);
    const crepeRef = useRef(null);
    // Tracks the markdown the editor last emitted, so an external
    // FILES_CHANGED roundtrip of our own save can be deduped.
    const lastEmittedRef = useRef(content || '');
    // Latest saveContent, read by the flush handler without re-binding
    // the mount effect (which runs once with []).
    const saveContentRef = useRef(saveContent);
    saveContentRef.current = saveContent;
    // Folded-heading keys, persisted across the destroy+recreate Crepe swap.
    const foldStateRef = useRef(new Set());

    // Reader text size. Applied as a CSS variable on the document root that a
    // `zoom: var(--colmd-zoom)` rule on .ProseMirror reads — so it survives
    // Crepe being torn down and rebuilt without re-touching the editor, and
    // scales every content element (headings are absolute px, so a plain
    // font-size wouldn't cascade to them) while leaving the chrome native.
    const [zoom, setZoom] = useState(readStoredZoom);
    useEffect(() => {
        try { document.documentElement.style.setProperty('--colmd-zoom', String(zoom)); } catch {}
        try { localStorage.setItem(ZOOM_KEY, String(zoom)); } catch {}
    }, [zoom]);

    useEffect(() => {
        if (!containerRef.current) return;
        let cancelled = false;
        let unsubFiles = null;
        let unsubSetContent = null;
        let unsubFlush = null;
        applySchemeToDocument(scheme);

        // Destroy + recreate Crepe with fresh markdown. Crepe has no
        // public replaceAll, so this is the cleanest swap. Shared by the
        // FILES_CHANGED path (external edits) and the host SET_CONTENT
        // path (generator-modal tag load). Cursor position is lost — the
        // same as the pre-existing src-swap refresh.
        const replaceContent = async (fresh) => {
            if (cancelled || !crepeRef.current || !containerRef.current) return;
            if (fresh == null || fresh === lastEmittedRef.current) return;
            crepeRef.current.destroy();
            crepeRef.current = null;
            const next = await createWithFallback(fresh);
            if (cancelled) { next.destroy(); return; }
            if (isReadOnly) next.setReadonly(true);
            crepeRef.current = next;
            lastEmittedRef.current = fresh;
        };

        const buildCrepe = (initial) => {
            const c = new Crepe({
                root: containerRef.current,
                defaultValue: initial || '',
                // Drop the "Please enter…" block placeholder that trails the
                // caret on empty lines. Feature value is the stable enum
                // string 'placeholder' (fall back to it if the static enum
                // isn't on this build of Crepe).
                features: {
                    [(Crepe.Feature && Crepe.Feature.Placeholder) || 'placeholder']: false,
                },
            });
            // Obsidian-style heading folding (decoration plugin). Registered
            // before create(); reads/writes the persisted fold-state ref so
            // folds survive a content swap. Guarded so a plugin-wiring error
            // can't stop the editor mounting (see foldSupported).
            if (foldSupported) {
                try {
                    c.editor.use($prose(() => createFoldPlugin(foldStateRef)));
                } catch {
                    foldSupported = false;
                }
            }
            if (!isReadOnly) {
                c.on((listener) => {
                    listener.markdownUpdated((ctx, markdown) => {
                        // Crepe fires markdownUpdated for every transaction
                        // including selection-only ones. Without this guard,
                        // a click or drag-select would saveContent → host
                        // autosave → server PUT → dag_commit → FILES_CHANGED
                        // broadcast → sibling iframes (e.g. SummaryPane's
                        // mirror of the same file) destroy+rebuild Crepe and
                        // visually jump. The byte-equal short-circuit kills
                        // the cycle at the source. (Fold toggles dispatch a
                        // meta-only transaction with no doc change, so they
                        // never reach here.)
                        if (markdown === lastEmittedRef.current) return;
                        lastEmittedRef.current = markdown;
                        saveContent(markdown);
                    });
                });
            }
            return c;
        };

        // Build + create a crepe editor, retrying once without the fold
        // plugin if create() throws (e.g. a prosemirror instance mismatch).
        // Guarantees the editor mounts even if folding can't be wired.
        const createWithFallback = async (initial) => {
            let c = buildCrepe(initial);
            try {
                await c.create();
                return c;
            } catch (e) {
                try { c.destroy(); } catch {}
                if (!foldSupported) throw e;
                foldSupported = false;
                c = buildCrepe(initial);
                await c.create();
                return c;
            }
        };

        (async () => {
            await api.loadCSS('https://cdn.jsdelivr.net/npm/@milkdown/crepe@7.21.2/lib/theme/common/style.css');
            // Inline both frame-light and frame-dark palettes, scoped by
            // data-theme on the document root. We deliberately ship our
            // OWN palette instead of propagating parent-app tokens — the
            // renderer should be a self-contained dark or light surface,
            // not a recoloured version of whatever the host's theme
            // happens to look like. applySchemeToDocument flips the
            // attribute on scheme change so the palette swap is
            // instant without a stylesheet reload.
            //
            // Values lifted from @milkdown/crepe's built-in `frame`
            // (light) and `frame-dark` themes verbatim — those are
            // already balanced for readability across every crepe
            // widget (slash menu, block handle, toolbar, image
            // picker, latex, code fence).
            api.injectStyle(`
                html, body { margin: 0; padding: 0; width: 100%; height: 100%; overflow: hidden; background: #ffffff; }
                html[data-theme="dark"], html[data-theme="dark"] body { background: #1a1a1a; }

                /* Light palette — crepe frame defaults. */
                .milkdown {
                    --crepe-color-background: #ffffff;
                    --crepe-color-on-background: #000000;
                    --crepe-color-surface: #f7f7f7;
                    --crepe-color-surface-low: #ededed;
                    --crepe-color-on-surface: #1c1c1c;
                    --crepe-color-on-surface-variant: #4d4d4d;
                    --crepe-color-outline: #a8a8a8;
                    --crepe-color-primary: #333333;
                    --crepe-color-secondary: #cfcfcf;
                    --crepe-color-on-secondary: #000000;
                    --crepe-color-inverse: #f0f0f0;
                    --crepe-color-on-inverse: #1a1a1a;
                    --crepe-color-inline-code: #ba1a1a;
                    --crepe-color-error: #ba1a1a;
                    --crepe-color-hover: #e0e0e0;
                    --crepe-color-selected: #d5d5d5;
                    --crepe-color-inline-area: #cacaca;
                    --crepe-font-title: 'Noto Serif', Cambria, 'Times New Roman', Times, serif;
                    --crepe-font-default: 'Noto Sans', Arial, Helvetica, sans-serif;
                    --crepe-font-code: 'Space Mono', Fira Code, Menlo, Monaco, 'Courier New', Courier, monospace;
                    --crepe-shadow-1: 0px 1px 3px 1px rgba(0,0,0,0.15), 0px 1px 2px 0px rgba(0,0,0,0.3);
                    --crepe-shadow-2: 0px 2px 6px 2px rgba(0,0,0,0.15), 0px 1px 2px 0px rgba(0,0,0,0.3);
                }

                /* Dark palette — crepe frame-dark defaults. */
                html[data-theme="dark"] .milkdown {
                    --crepe-color-background: #1a1a1a;
                    --crepe-color-on-background: #e6e6e6;
                    --crepe-color-surface: #121212;
                    --crepe-color-surface-low: #1c1c1c;
                    --crepe-color-on-surface: #d1d1d1;
                    --crepe-color-on-surface-variant: #a9a9a9;
                    --crepe-color-outline: #757575;
                    --crepe-color-primary: #b5b5b5;
                    --crepe-color-secondary: #4d4d4d;
                    --crepe-color-on-secondary: #d6d6d6;
                    --crepe-color-inverse: #e5e5e5;
                    --crepe-color-on-inverse: #2a2a2a;
                    --crepe-color-inline-code: #ff6666;
                    --crepe-color-error: #ff6666;
                    --crepe-color-hover: #232323;
                    --crepe-color-selected: #2f2f2f;
                    --crepe-color-inline-area: #2b2b2b;
                    --crepe-shadow-1: 0px 1px 2px 0px rgba(255,255,255,0.3), 0px 1px 3px 1px rgba(255,255,255,0.15);
                    --crepe-shadow-2: 0px 1px 2px 0px rgba(255,255,255,0.3), 0px 2px 6px 2px rgba(255,255,255,0.15);
                }

                /* .milkdown is the content shell. Give it the theme bg and
                   min-height: 100% so the surface colour extends below
                   the last paragraph instead of clinging to just the
                   text (the default — .milkdown's built-in rules leave
                   it transparent and shrink to content, which let the
                   iframe's body bg peek through only around the text
                   block). */
                .milkdown { background: var(--crepe-color-background); min-height: 100%; }

                /* Reader text size. zoom (not font-size) so it scales every
                   content element uniformly — crepe sizes headings in
                   absolute px, which font-size on the container wouldn't
                   touch. Chromium reports post-zoom rects, so crepe's
                   floating chrome (slash menu, toolbar) still positions
                   correctly. Defaults to 1 until the React effect sets the
                   var from the persisted value. */
                .milkdown .ProseMirror { zoom: var(--colmd-zoom, 1); }

                /* The left block handle (the "+" / drag grip that tracks the
                   mouse down the left margin) is hidden — it's the one bit of
                   crepe chrome we don't want. The slash menu (type "/") still
                   works; it's a separate widget. */
                .milkdown .milkdown-block-handle { display: none !important; }

                /* Reading measure. Left padding is now symmetric-ish with the
                   right (the old 88px only existed to clear the block handle,
                   which is gone) but keeps ~48px of gutter for the fold
                   chevron to sit in. */
                .milkdown .ProseMirror { padding: 24px 48px 24px 48px; min-height: 100%; outline: none; }

                /* Crepe's "Please enter…" placeholder. The feature is also
                   disabled at construction; this hides the decoration's
                   ::before belt-and-suspenders so no prompt text trails the
                   caret on an empty line. */
                .milkdown .ProseMirror .crepe-placeholder::before { content: none !important; }

                /* Obsidian-style heading fold control.
                   The chevron is a real <span> WIDGET decoration (not a pseudo)
                   so it owns its own click handler — toggling is independent of
                   the reader-zoom and needs no clientX math. It's absolutely
                   positioned in the left gutter and made 30px wide so its hit
                   area runs flush to the heading text: hovering text → chevron
                   is one continuous region, no dead gap to cross.
                   It is revealed ONLY when the heading row is hovered or holds
                   the caret (.colmd-active) — never on a bare editor hover, and
                   never by hovering the body blocks beneath the heading. While
                   collapsed it stays visible (and rotated). */
                .milkdown .ProseMirror .colmd-foldable { position: relative; }
                .milkdown .ProseMirror .colmd-fold-toggle {
                    position: absolute;
                    left: -30px;
                    top: 0;
                    width: 30px;
                    height: 1.3em;
                    display: flex;
                    align-items: center;
                    justify-content: flex-start;
                    padding-left: 6px;
                    box-sizing: border-box;
                    opacity: 0;
                    transition: opacity 0.12s ease;
                    cursor: pointer;
                    user-select: none;
                }
                .milkdown .ProseMirror .colmd-fold-toggle::before {
                    content: '';
                    width: 0;
                    height: 0;
                    border-style: solid;
                    border-width: 6px 4px 0 4px;
                    border-color: var(--crepe-color-on-surface-variant, #888) transparent transparent transparent;
                }
                .milkdown .ProseMirror .colmd-foldable:hover > .colmd-fold-toggle,
                .milkdown .ProseMirror .colmd-foldable.colmd-active > .colmd-fold-toggle { opacity: 0.5; }
                .milkdown .ProseMirror .colmd-foldable.colmd-folded > .colmd-fold-toggle { opacity: 0.9; }
                .milkdown .ProseMirror .colmd-fold-toggle:hover { opacity: 1; }
                .milkdown .ProseMirror .colmd-foldable.colmd-folded > .colmd-fold-toggle::before {
                    border-width: 4px 0 4px 6px;
                    border-color: transparent transparent transparent var(--crepe-color-on-surface-variant, #888);
                }

                /* Obsidian-style "…" trailing a collapsed heading, signalling
                   hidden content. A clickable widget (unfolds on click). */
                .milkdown .ProseMirror .colmd-fold-ellipsis {
                    margin-left: 0.4em;
                    opacity: 0.4;
                    cursor: pointer;
                    user-select: none;
                }
                .milkdown .ProseMirror .colmd-fold-ellipsis::before { content: '…'; }
                .milkdown .ProseMirror .colmd-fold-ellipsis:hover { opacity: 0.7; }

                /* Crepe's reset.css sets margin-top on h1–h6 (32/28/24/20/16/16px)
                   to space headings from preceding content. On the very first
                   block that margin lives ABOVE the first line — visible as an
                   "extra line" at the top when the cursor lands there. Zero it
                   out so the top line sits flush with the editor's top padding.
                   The second selector handles the moment a selection starts:
                   prosemirror-virtual-cursor inserts a zero-height div as the
                   ACTUAL first DOM child, knocking the heading out of
                   :first-child. Without the sibling rule the heading's
                   margin-top suddenly reappears and the document visibly jumps
                   by 32px the moment you click+drag (CSS :first-child matches
                   on DOM order, ignoring display, so display:none on the
                   cursor doesn't fix this). */
                .milkdown .ProseMirror > *:first-child,
                .milkdown .ProseMirror > .prosemirror-virtual-cursor + *,
                .milkdown .ProseMirror > .ProseMirror-widget:first-child + * { margin-top: 0; }

                /* Disable prosemirror-virtual-cursor.
                   Milkdown ships a custom caret renderer whose -left /
                   -right variants paint L-shaped border overlays that
                   dangle ABOVE the caret by 1ch × line-height (see
                   prosemirror-virtual-cursor/style/virtual-cursor.css).
                   At position 0 of the document the -left variant
                   hangs above-and-before the first line — that's the
                   "phantom line" above the top and the cursor you see
                   briefly when holding arrow-up. Making a selection
                   hides the caret entirely so the phantom vanishes.
                   The native browser caret handles everything the
                   virtual cursor did for our case, so force caret-color
                   back and hide the virtual cursor DOM. */
                .milkdown .ProseMirror,
                .milkdown .ProseMirror.virtual-cursor-enabled {
                    caret-color: auto !important;
                }
                /* Drop the .milkdown ancestor: the cursor is a child of
                   .ProseMirror but the original scope was overspecific in
                   ways that didn't bite earlier. Cover the -animation
                   variant explicitly — it's the one that fires on
                   selection. (Note: display:none on the cursor does NOT
                   fix the heading jump on its own — the cursor still
                   inserts as a DOM first-child and CSS :first-child
                   matches by DOM order regardless of display. The
                   jump fix is the sibling rule above.) */
                .prosemirror-virtual-cursor,
                .prosemirror-virtual-cursor-animation,
                .prosemirror-virtual-cursor-left,
                .prosemirror-virtual-cursor-right {
                    display: none !important;
                }

                /* Belt-and-suspenders: also suppress the legacy
                   ProseMirror gap-cursor, which would render a short
                   horizontal bar above the first block for a different
                   reason (non-text-node entry points). Harmless to
                   keep disabled for a markdown editor. */
                .milkdown .ProseMirror-gapcursor,
                .milkdown .ProseMirror-focused .ProseMirror-gapcursor {
                    display: none !important;
                }
            `);
            if (cancelled || !containerRef.current) return;

            const crepe = await createWithFallback(content);
            if (cancelled) { crepe.destroy(); return; }
            if (isReadOnly) crepe.setReadonly(true);
            crepeRef.current = crepe;
            lastEmittedRef.current = content || '';
            if (api.ready) api.ready();

            // Pick up external edits (other clients, API writes, git pulls)
            // via the host's FILES_CHANGED broadcast. Host only fires this
            // on server dag_commits, so keystrokes don't churn through here.
            // We still dedupe against lastEmittedRef for the roundtrip on
            // our own save. Crepe has no public replaceAll, so destroy+
            // recreate is the cleanest path — cursor position is lost, but
            // that was the pre-existing behavior when this refresh was
            // driven by an iframe src swap.
            if (api.onFilesChanged) {
                unsubFiles = api.onFilesChanged(async () => {
                    let fresh;
                    try { fresh = await api.getSiblingFile(api.getFilename()); } catch { return; }
                    await replaceContent(fresh);
                });
            }

            // Host content push (generator-modal tag load): replace the
            // editor's markdown in place — no iframe reload, no spinner.
            if (api.onSetContent) {
                unsubSetContent = api.onSetContent((next) => { void replaceContent(next); });
            }

            // Host flush request (generator-modal Save): emit the editor's
            // current markdown immediately so the freshest in-place edit
            // lands before the host reads values. markdownUpdated already
            // saves on a near-zero delay, but a flush right after the last
            // keystroke guarantees the final transaction is committed.
            if (api.onFlush) {
                unsubFlush = api.onFlush(() => {
                    const crepe = crepeRef.current;
                    if (!crepe || isReadOnly) return;
                    let md;
                    try { md = crepe.getMarkdown(); } catch { return; }
                    if (md == null || md === lastEmittedRef.current) return;
                    lastEmittedRef.current = md;
                    saveContentRef.current(md);
                });
            }
        })();

        const unsubTheme = onThemeChange(applySchemeToDocument);

        return () => {
            cancelled = true;
            if (unsubFiles) unsubFiles();
            if (unsubSetContent) unsubSetContent();
            if (unsubFlush) unsubFlush();
            if (unsubTheme) unsubTheme();
            if (crepeRef.current) crepeRef.current.destroy();
            crepeRef.current = null;
        };
    }, []);

    // No inline background — the scheme-aware body rule in injectStyle
    // handles the page surface, and .milkdown inside paints itself via
    // --crepe-color-background. Relying on --void-main here left the
    // container transparent (the var isn't defined inside the iframe
    // now that we ship a self-contained palette) which let the browser
    // default white flash through under the milkdown body.
    // overflowAnchor: 'none' — Crepe inserts/removes widgets (toolbar,
    // block handle, link tooltip) on selection. Default scroll-anchoring
    // re-anchors when DOM mutates above the viewport, which manifests
    // as "the whole document jumps up by ~24px the moment selection
    // starts." Disabling anchoring keeps the scroll position stable.
    //
    // scrollPaddingTop matches the ProseMirror top padding (24px) so
    // that ProseMirror's scrollIntoView (called on selection) doesn't
    // hide that padding behind the top edge.
    return (
        <div style={{ position: 'relative', width: '100%', height: '100%' }}>
            <div ref={containerRef} style={{ width: '100%', height: '100%', overflowY: 'auto', overflowAnchor: 'none', scrollPaddingTop: '24px' }} />
            <ReaderSizeControl zoom={zoom} setZoom={setZoom} scheme={scheme} />
        </div>
    );
}

export default defineRenderer({ component: MilkdownEditor, deferReady: true });
