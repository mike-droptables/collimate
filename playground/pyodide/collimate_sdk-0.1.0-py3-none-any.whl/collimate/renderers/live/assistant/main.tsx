/**
 * Assistant — the chat renderer (binds `.chat`), powered by assistant-ui.
 *
 * The pinned `.chat` file is a session pointer (collimate/pointers.py
 * `chat_session_pointer`):
 *
 *   { session_id, ws_path, token, label, threads_dir, active_thread,
 *     threads: [{id, title, file}],
 *     integration: null | { type:"opencode", proxy_url } }
 *
 * Two runtimes, chosen by the pointer:
 *   • NATIVE  (integration = null) — assistant-ui ExternalStoreRuntime fed by
 *     the Collimate chat WebSocket at `ws_path`. Per-thread history is the
 *     open-format transcript at the thread's `file` (collimate/transcript.py:
 *     {"messages":[{role,content}]}).
 *   • INTEGRATION (opencode) — assistant-ui's OFFICIAL opencode runtime
 *     (@assistant-ui/react-opencode), pointed at `opencode serve` through the
 *     cell's `/proxy/...` route.
 *
 * Native-runtime conversation curation (edit / delete / insert / reorder any
 * message — "sculpt the transcript into any structure") works in two modes:
 *   • LIVE (WebSocket open, no turn in flight): ops ride the socket as
 *     `edit` / `delete` / `insert` / `move` frames; gen.serve_chat applies
 *     them to the durable transcript and the next files-changed reconciles.
 *   • STOPPED (run ended, socket gone): ops apply locally and persist through
 *     the host's draft pipeline (`PUT …/drafts/<file>` + `POST …/checkpoint`,
 *     both derived from api.getFileUrl) — so a finished chat can still be
 *     re-shaped. Sending new messages / regenerating needs a running
 *     generator and stays disabled while stopped.
 *
 * Rendered by the host's NativeRenderer (shadow DOM, main document) — see the
 * manifest's `embed: native`. That is deliberate: a live chat holds a WebSocket,
 * and native renderers unmount cleanly (socket closes) on tab-away and persist
 * across file-content changes without remounting. It ships as `.tsx`,
 * babel-transpiled, imports resolved from esm.sh at runtime; React + react-dom +
 * the assistant-ui packages all pin `?deps=react@19.2.0` so the whole graph
 * shares ONE React instance. Styling is inline (Tailwind/className from the
 * host do not reach the shadow root) against a self-contained assistant-ui
 * (shadcn zinc) palette — only the light/dark SCHEME follows the host via
 * api.getTheme(); the palette itself is deliberately not the host's. The one
 * injected <style> covers what inline styles cannot express (keyframes,
 * ::placeholder, :hover, :focus-within).
 *
 * NOTE: this renderer intentionally does NOT use defineRenderer from
 * /api/sdk/react.js — that module pins React 18, and mixing it with the
 * React 19 instance assistant-ui needs would split the tree across two
 * Reacts. It exports the raw { mount } lifecycle (NativeRenderer's other
 * supported shape) plus the defineRenderer marker for the compile check.
 */
import React, { useEffect, useMemo, useRef, useState } from "https://esm.sh/react@19.2.0";
import { createRoot } from "https://esm.sh/react-dom@19.2.0/client?deps=react@19.2.0";
import {
  ActionBarPrimitive,
  AssistantRuntimeProvider,
  AuiIf,
  BranchPickerPrimitive,
  ComposerPrimitive,
  ErrorPrimitive,
  MessagePrimitive,
  ThreadPrimitive,
  useExternalStoreRuntime,
  useMessage,
  useMessagePartReasoning,
  useMessagePartSource,
  useMessagePartText,
} from "https://esm.sh/@assistant-ui/react@0.14.24?deps=react@19.2.0,react-dom@19.2.0";
import type { AppendMessage, ThreadMessageLike } from "https://esm.sh/@assistant-ui/react@0.14.24?deps=react@19.2.0,react-dom@19.2.0";
// Markdown rendering — MarkdownTextPrimitive with an inline-styled `components`
// override map (no Tailwind; shadow-DOM safe). The deps pin MUST carry the same
// @assistant-ui/react so esm.sh reuses one core/store instance.
import { MarkdownTextPrimitive } from "https://esm.sh/@assistant-ui/react-markdown@0.14.5?deps=react@19.2.0,react-dom@19.2.0,@assistant-ui/react@0.14.24";
// Official opencode runtime — full-featured (sessions↔threads, SSE, fork/revert).
// The deps pin includes @assistant-ui/react so its peer resolves to the SAME
// build as ours (a floating ^0.14.x resolution would split the store instance).
import { createOpencodeClient, useOpenCodeRuntime } from "https://esm.sh/@assistant-ui/react-opencode@0.2.10?deps=react@19.2.0,react-dom@19.2.0,@assistant-ui/react@0.14.24";
// Framework-free session-socket helper (no React inside — safe to mix with
// this renderer's React 19 pin, unlike /api/sdk/react.js).
import { apiOrigin, openSessionSocket, sessionWsUrl } from "/api/sdk/session.js";
import {
  ArrowDown, ArrowUp, Check, ChevronDown, ChevronLeft, ChevronRight, ChevronUp,
  Copy, Loader, MessageSquarePlus, PanelLeftClose, PanelLeftOpen,
  Pencil, Plus, RefreshCw, Square, Trash2,
} from "https://esm.sh/lucide-react@1.23.0?deps=react@19.2.0&exports=ArrowDown,ArrowUp,Check,ChevronDown,ChevronLeft,ChevronRight,ChevronUp,Copy,Loader,MessageSquarePlus,PanelLeftClose,PanelLeftOpen,Pencil,Plus,RefreshCw,Square,Trash2";

// ── theme ─────────────────────────────────────────────────────────────
//
// assistant-ui's own default look (shadcn zinc), NOT the host's palette —
// only the light/dark scheme follows the host (api.getTheme().scheme). The
// palette lands as CSS custom properties on the root container, so every
// inline style below (and the injected CSS) resolves per scheme without
// threading a theme object through the tree.

const PALETTES = {
  light: {
    bg: "#ffffff", panel: "#fafafa", fg: "#09090b", dim: "#71717a",
    muted: "#f4f4f5", active: "#e4e4e7", line: "#e4e4e7", destructive: "#dc2626",
  },
  dark: {
    bg: "#18181b", panel: "#131316", fg: "#fafafa", dim: "#a1a1aa",
    muted: "#27272a", active: "#3f3f46", line: "#2b2b30", destructive: "#ef4444",
  },
};

function paletteVars(scheme: "light" | "dark"): Record<string, string> {
  const p = PALETTES[scheme] || PALETTES.dark;
  return {
    "--aui-bg": p.bg, "--aui-panel": p.panel, "--aui-fg": p.fg,
    "--aui-dim": p.dim, "--aui-muted": p.muted, "--aui-active": p.active,
    "--aui-line": p.line, "--aui-destructive": p.destructive,
  };
}

const T = {
  bg: "var(--aui-bg)",
  panel: "var(--aui-panel)",
  fg: "var(--aui-fg)",
  dim: "var(--aui-dim)",
  muted: "var(--aui-muted)",
  active: "var(--aui-active)",
  line: "var(--aui-line)",
  destructive: "var(--aui-destructive)",
  accent: "#0ea5e9",
  accentFg: "#000000",
};

/** The host's light/dark scheme (palette stays ours — see PALETTES). */
function useScheme(api: any): "light" | "dark" {
  const initial = (): "light" | "dark" => {
    try {
      const s = api?.getTheme?.().scheme;
      if (s === "light" || s === "dark") return s;
    } catch { /* noop */ }
    try {
      return matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
    } catch { /* noop */ }
    return "dark";
  };
  const [scheme, setScheme] = useState<"light" | "dark">(initial);
  useEffect(() => {
    try {
      return api?.onThemeChange?.((t: any) => {
        if (t?.scheme === "light" || t?.scheme === "dark") setScheme(t.scheme);
      });
    } catch { return undefined; }
  }, [api]);
  return scheme;
}

const THREAD_MAX_WIDTH = 704; // 44rem

// What inline styles can't express: keyframes, pseudo-classes/-elements, and
// the [hidden] attribute assistant-ui's autohiding action bars rely on.
// The box-sizing reset matters: the shadow root has no host CSS, so without
// it every "width: 100%" + padding element (the inline editor, the composer)
// is content-box and overflows its parent by its padding.
const SHADOW_CSS = `
  *, *::before, *::after { box-sizing: border-box; }
  @keyframes aui-spin { to { transform: rotate(360deg); } }
  .aui-spin { animation: aui-spin 1s linear infinite; }
  @keyframes aui-pulse { 50% { opacity: .35; } }
  .aui-pulse { animation: aui-pulse 1.4s ease-in-out infinite; }
  [hidden] { display: none !important; }
  .aui-input::placeholder { color: ${T.dim}; opacity: .8; }
  .aui-composer { transition: border-color .15s; }
  .aui-composer:focus-within { border-color: color-mix(in srgb, ${T.fg} 55%, transparent); }
  .aui-stb[disabled] { visibility: hidden; }
  .aui-iconbtn { transition: background .12s, color .12s, opacity .12s; }
  .aui-iconbtn:hover:not([disabled]) { background: ${T.muted}; color: ${T.fg}; }
  .aui-listbtn:hover { background: ${T.muted}; }
`;

// ── pointer + transcript helpers ──────────────────────────────────────

interface ThreadEntry { id: string; title: string; file: string }
interface Pointer {
  session_id: string;
  ws_path: string;
  token: string;
  label: string;
  threads_dir: string;
  active_thread: string;
  threads: ThreadEntry[];
  integration: null | { type: string; proxy_url: string };
}

type Role = "user" | "assistant" | "system";
interface Msg { id: string; role: Role; text: string; thinking?: string }

function parsePointer(raw: string): Pointer | null {
  try {
    const p = JSON.parse(raw);
    if (!p || typeof p !== "object") return null;
    return {
      session_id: p.session_id || "",
      ws_path: p.ws_path || "",
      token: p.token || "",
      label: p.label || "Chat",
      threads_dir: p.threads_dir || "chats",
      active_thread: p.active_thread || "main",
      threads: Array.isArray(p.threads) ? p.threads : [],
      integration: p.integration || null,
    };
  } catch {
    return null;
  }
}

/** Parse the open transcript ({"messages":[...]}) or a bare array. Ids are the
 *  transcript index (`h<i>`), so curation ops map back to a position. */
function parseTranscript(raw: string): Msg[] {
  if (!raw || !raw.trim()) return [];
  let data: any;
  try { data = JSON.parse(raw); } catch { return []; }
  const items = Array.isArray(data) ? data : data?.messages;
  if (!Array.isArray(items)) return [];
  const out: Msg[] = [];
  for (let i = 0; i < items.length; i++) {
    const m = items[i];
    if (!m || typeof m !== "object") continue;
    const role = String(m.role || "").toLowerCase();
    if (role !== "user" && role !== "assistant" && role !== "system") continue;
    out.push({
      id: `h${i}`, role: role as Role, text: String(m.content ?? ""),
      // Thinking is an assistant-message concept — assistant-ui rejects
      // reasoning parts on other roles, so never carry it for them.
      thinking: role === "assistant" ? String(m.thinking ?? "") : "",
    });
  }
  return out;
}

/** Serialize back to the exact shape collimate.transcript writes (pretty,
 *  trailing newline, optional "thinking" only when non-empty) so offline
 *  curation diffs cleanly against generator writes. */
function serializeTranscript(msgs: Msg[]): string {
  const messages = msgs.map((m) => ({
    role: m.role, content: m.text || "",
    ...(m.thinking ? { thinking: m.thinking } : {}),
  }));
  return JSON.stringify({ messages }, null, 2) + "\n";
}

// carry our stable id through so curation callbacks map back to the position.
// The reasoning part is added ONLY for assistant messages with thinking
// (assistant-ui rejects reasoning parts on other roles), and only when it
// exists — so the "Thinking…" spinner condition (content.length === 0) still
// fires before any delta.
const convertMessage = (m: Msg): ThreadMessageLike => ({
  id: m.id,
  role: m.role,
  content: [
    ...(m.role === "assistant" && m.thinking
      ? [{ type: "reasoning" as const, text: m.thinking }] : []),
    { type: "text" as const, text: m.text },
  ],
});

const textOf = (m: AppendMessage): string =>
  (m.content || [])
    .map((p: any) => (p.type === "text" ? p.text : ""))
    .join("")
    .trim();

// ── native runtime: ExternalStore fed by the chat WebSocket ───────────

type ConnStatus = "connecting" | "open" | "closed";

// One in-flight turn's stream buffer, keyed by its bound thread. The buffer —
// not the message list — is the source of truth for the partial reply, so a
// background turn's deltas accumulate while another thread is displayed and
// re-materialize on switch-back.
interface Stream { id: string; text: string; thinking: string }

function useNativeChat(api: any, pointer: Pointer) {
  const [threads, setThreads] = useState<ThreadEntry[]>(pointer.threads);
  const [active, setActive] = useState<string>(pointer.active_thread);
  const [messages, setMessages] = useState<Msg[]>([]);
  // The thread with a turn in flight (serve_chat is single-flight), or null.
  const [runningThread, setRunningThread] = useState<string | null>(null);
  // Threads with new content since last viewed (background turns).
  const [unread, setUnread] = useState<Record<string, boolean>>({});
  const [status, setStatus] = useState<ConnStatus>("connecting");
  const [banner, setBanner] = useState<string>("");
  const sockRef = useRef<any>(null);  // SessionSocket from /api/sdk/session.js
  const streamsRef = useRef<Record<string, Stream>>({});
  const activeRef = useRef(active);
  activeRef.current = active;
  const threadsRef = useRef(threads);
  threadsRef.current = threads;
  const messagesRef = useRef<Msg[]>(messages);
  messagesRef.current = messages;
  const runningThreadRef = useRef(runningThread);
  runningThreadRef.current = runningThread;
  const persistQueueRef = useRef<Promise<void>>(Promise.resolve());

  const markUnread = React.useCallback((tid: string) => {
    if (tid !== activeRef.current) {
      setUnread((prev) => (prev[tid] ? prev : { ...prev, [tid]: true }));
    }
  }, []);
  const clearUnread = React.useCallback((tid: string) => {
    setUnread((prev) => {
      if (!prev[tid]) return prev;
      const next = { ...prev };
      delete next[tid];
      return next;
    });
  }, []);

  const threadFile = React.useCallback((tid: string): string => {
    const entry = pointer.threads.find((t) => t.id === tid) ||
      threadsRef.current.find((t) => t.id === tid);
    return entry?.file || `${pointer.threads_dir}/${tid}.json`;
  }, [pointer.threads, pointer.threads_dir]);

  // Load a thread's transcript from its file. While a turn is streaming into
  // THIS thread, the disk transcript doesn't hold the in-flight assistant
  // bubble yet, so a wholesale replace would wipe the accumulated stream —
  // re-materialize it from the thread's stream buffer (which also brings a
  // BACKGROUND turn's partial back on switch-to).
  //
  // Id stability: when the reload confirms what's already on screen (same
  // length, same role+text per index — the common optimistic-append reconcile),
  // KEEP the existing message ids. Swapping an optimistic id for its h<i>
  // transcript id at the same position makes assistant-ui's repository record
  // a phantom sibling branch ("2/2" pickers on untouched messages).
  const loadThread = React.useCallback(async (tid: string) => {
    try {
      const raw = await api.getSiblingFile(threadFile(tid));
      const parsed = parseTranscript(typeof raw === "string" ? raw : "");
      setMessages((prev: Msg[]) => {
        const stream = tid === activeRef.current ? streamsRef.current[tid] : undefined;
        const live: Msg | undefined = stream
          ? { id: stream.id, role: "assistant", text: stream.text, thinking: stream.thinking }
          : undefined;
        const base = live ? prev.filter((m: Msg) => m.id !== live.id) : prev;
        let next = parsed;
        if (base.length === parsed.length) {
          next = parsed.map((p: Msg, i: number) =>
            base[i].role === p.role && base[i].text === p.text
              ? { ...p, id: base[i].id } : p);
          const ids = new Set(next.map((m: Msg) => m.id));
          if (ids.size !== next.length) next = parsed;  // collision → fresh ids
        }
        return live ? [...next, live] : next;
      });
    } catch {
      setMessages([]);
    }
  }, [api, threadFile]);

  useEffect(() => { loadThread(active); /* on switch */ }, [active, loadThread]);

  // Re-read the active transcript whenever the cell's files change (the
  // generator commits the durable transcript after each turn / curation op).
  useEffect(() => {
    const off = api.onFilesChanged?.(() => loadThread(activeRef.current));
    return () => { try { off && off(); } catch { /* noop */ } };
  }, [api, loadThread]);

  // The WebSocket carries live turns + the live thread list. The connection
  // lifecycle (backoff on transient closes, final stop on 4404/4401 with a
  // dead-session marker, slow 4409 takeover poll so two views of one cell
  // don't ping-pong the single-attach session) is openSessionSocket's job —
  // this effect only supplies the frame reducer.
  useEffect(() => {
    if (!pointer.ws_path) { setStatus("closed"); return; }
    // Get-or-create the stream buffer for a thread's in-flight turn. Also
    // self-heals after a mid-turn reload, where no turn_start was (re)sent —
    // history/delta frames can still land. The bubble id derives from the
    // TURN id, so a reconnect's history replay reuses the pre-disconnect
    // bubble instead of appending a duplicate.
    const ensureStream = (tid: string, turnId?: string): Stream => {
      let s = streamsRef.current[tid];
      if (!s) {
        s = { id: turnId ? `a-${turnId}` : `a${Date.now()}`, text: "", thinking: "" };
        streamsRef.current[tid] = s;
      }
      return s;
    };
    // Push the buffer's state into the visible message list — appending the
    // bubble when it isn't there yet (first frame after a switch-back).
    const materialize = (s: Stream) => {
      setMessages((prev) => prev.some((m) => m.id === s.id)
        ? prev.map((m) => (m.id === s.id ? { ...m, text: s.text, thinking: s.thinking } : m))
        : [...prev, { id: s.id, role: "assistant", text: s.text, thinking: s.thinking }]);
    };
    const endStream = (tid: string) => {
      delete streamsRef.current[tid];
      setRunningThread((cur) => (cur === tid ? null : cur));
    };
    const sock = openSessionSocket({
      url: sessionWsUrl(api, pointer.ws_path, pointer.token),
      sessionId: pointer.session_id,
      onStatus: (st: string) => {
        // The composer only needs the tri-state; busy/ended read as closed.
        setStatus(st === "open" ? "open" : st === "connecting" ? "connecting" : "closed");
        if (st !== "open") setRunningThread(null);
      },
      onOpen: () => {
        // Reset stale stream state from before a detach: if a turn IS in
        // flight, the host's history replay (or the next delta) rebuilds it.
        // Purge the stale materialized bubbles too — a replay under a NEW
        // turn would otherwise sit next to the pre-disconnect duplicate.
        const stale = new Set(Object.values(streamsRef.current).map((s) => s.id));
        setRunningThread(null);
        streamsRef.current = {};
        if (stale.size) {
          setMessages((prev) => prev.filter((m) => !stale.has(m.id)));
        }
        // Re-assert the viewed thread — a thread_switch sent while the socket
        // was down is silently lost, and the server routes messages by ITS
        // notion of the active thread.
        sockRef.current?.sendJson({ t: "thread_switch", thread_id: activeRef.current });
      },
      onMessage: (ev: MessageEvent) => {
        let f: any; try { f = JSON.parse(ev.data); } catch { return; }
        // Turn-scoped frames always carry the turn's bound thread (the SDK
        // is injected fresh into every run, so no frame producer predates
        // thread scoping); frames without one (threads) never use tid.
        const tid: string = f.thread_id || "";
        switch (f.t) {
          case "turn_start": {
            setRunningThread(tid);
            const s = ensureStream(tid, f.turn_id);
            if (tid === activeRef.current) {
              setBanner("");
              materialize(s);
            }
            break;
          }
          case "history": {
            // Authoritative accumulated partial replayed on (re)connect —
            // sent whenever a turn is in flight, even before its first delta.
            setRunningThread(tid);
            const s = ensureStream(tid, f.turn_id);
            s.text = f.text || "";
            s.thinking = f.thinking || "";
            if (tid === activeRef.current) materialize(s);
            else if (s.text) markUnread(tid);
            break;
          }
          case "delta": {
            if (!f.text) break;
            setRunningThread(tid);
            const s = ensureStream(tid, f.turn_id);
            s.text += f.text;
            if (tid === activeRef.current) materialize(s);
            else markUnread(tid);
            break;
          }
          case "thinking_delta": {
            if (!f.text) break;
            setRunningThread(tid);
            const s = ensureStream(tid, f.turn_id);
            s.thinking += f.text;
            if (tid === activeRef.current) materialize(s);
            break;
          }
          case "threads": {
            if (Array.isArray(f.threads)) setThreads(f.threads);
            if (f.active) {
              setActive(f.active);
              activeRef.current = f.active;
              clearUnread(f.active);
            }
            break;
          }
          case "turn_end":
            endStream(tid);
            if (tid === activeRef.current) {
              loadThread(tid);   // reconcile from the durable transcript
            } else {
              markUnread(tid);   // finished in the background — badge it
            }
            break;
          case "busy": {
            // Server refusal of a cross-thread send while a turn is running.
            // Echo the refused text so the user's message isn't just lost.
            const refused = f.content
              ? ` Your message: “${String(f.content).slice(0, 200)}”` : "";
            if (tid === activeRef.current) {
              setBanner((f.message || "The assistant is still replying in another thread.") + refused);
            }
            break;
          }
          case "error":
            // Surface as a dismissable banner instead of a fake transcript
            // message — injected rows would skew the index-based curation ops.
            endStream(tid);
            if (tid === activeRef.current) {
              setBanner(f.message || "error");
              loadThread(tid);
            } else {
              markUnread(tid);
            }
            break;
        }
      },
    });
    sockRef.current = sock;
    // Cleanup CLOSES the socket (final — no redial), freeing the host's
    // single-attach session for whichever view mounts next.
    return () => { sockRef.current = null; sock.close(); };
  }, [pointer.ws_path, pointer.token, pointer.session_id, loadThread, markUnread, clearUnread]);

  const send = (obj: any): boolean => sockRef.current?.sendJson(obj) ?? false;

  const runningVisible = runningThread !== null && runningThread === active;
  const busyElsewhere = runningThread !== null && runningThread !== active;

  const onNew = async (message: AppendMessage) => {
    const text = textOf(message);
    if (!text) return;
    const rt = runningThreadRef.current;
    if (rt !== null && rt !== activeRef.current) {
      // Backstop — the composer is disabled while busy elsewhere, and the
      // server would refuse with a `busy` frame anyway (single-flight).
      setBanner("The assistant is still replying in another thread — wait for it to finish or stop it first.");
      return;
    }
    const sameThreadBusy = rt !== null && rt === activeRef.current;
    // thread_id names the thread this was typed in — the server treats it as
    // authoritative, healing any active-thread desync from a dropped socket.
    if (!send({ t: sameThreadBusy ? "redirect" : "user_msg", content: text,
                thread_id: activeRef.current })) {
      setBanner("The generator is stopped — run the cell again to continue chatting.");
      return;
    }
    setBanner("");
    setMessages((prev) => [...prev, { id: `u${Date.now()}`, role: "user", text }]);
  };

  // ── conversation curation (edit / delete / insert / move) ───────────
  //
  // Allowed while no turn is streaming. Two persistence paths:
  //   live    — the op rides the WebSocket; the generator re-seeds its
  //             in-memory history from disk first, applies the op by index,
  //             and flushes, so indices line up with what we render.
  //   stopped — the socket is gone; apply locally and persist through the
  //             host draft pipeline (draft PUT + checkpoint POST, both
  //             derived from api.getFileUrl), which promotes a
  //             'Manual Edit' version the next run resumes from.
  const indexOf = (id: string) => messagesRef.current.findIndex((m) => m.id === id);

  const persistOffline = React.useCallback((next: Msg[]) => {
    const file = threadFile(activeRef.current);
    let base = "";
    try {
      const fileUrl: string = api.getFileUrl ? api.getFileUrl(file) : "";
      const cut = fileUrl.lastIndexOf("/files/");
      if (cut > 0) base = fileUrl.slice(0, cut);
    } catch { /* noop */ }
    if (!base) {
      setBanner("This host can't persist edits to a stopped chat.");
      return;
    }
    const doc = serializeTranscript(next.filter((m) => m.role !== "system" || m.text));
    persistQueueRef.current = persistQueueRef.current.then(async () => {
      const r = await fetch(`${base}/drafts/${encodeURIComponent(file)}`, {
        method: "PUT", headers: { "Content-Type": "text/plain" }, body: doc,
      });
      if (!r.ok) throw new Error(`draft save HTTP ${r.status}`);
      await fetch(`${base}/checkpoint`, { method: "POST" });
    }).catch((e) => { setBanner(`Saving edit failed: ${e?.message || e}`); });
  }, [api, threadFile]);

  const applyCuration = React.useCallback((fn: (prev: Msg[]) => Msg[], liveFrame: any) => {
    // Curation edits the ACTIVE thread — blocked only while ITS turn streams;
    // a background turn in another thread doesn't lock this one (the server
    // gates on the same rule).
    if (runningThreadRef.current !== null &&
        runningThreadRef.current === activeRef.current) return;
    const next = fn(messagesRef.current);
    setMessages(next);
    // Live path first: the frame rides the socket when it's open; otherwise
    // persist through the host draft pipeline.
    if (!sockRef.current?.sendJson(liveFrame)) {
      persistOffline(next);
    }
  }, [persistOffline]);

  const editMessage = (id: string, text: string) => {
    const i = indexOf(id);
    if (i < 0) return;
    applyCuration(
      (prev) => prev.map((m, k) => (k === i ? { ...m, text } : m)),
      { t: "edit", index: i, content: text },
    );
  };
  const deleteMessage = (id: string) => {
    const i = indexOf(id);
    if (i < 0) return;
    applyCuration(
      (prev) => prev.filter((_, k) => k !== i),
      { t: "delete", index: i },
    );
  };
  /** Insert a new message at `index` (end of thread when afterId is null). */
  const insertMessage = (afterId: string | null, role: Role, text: string) => {
    const i = afterId === null ? messagesRef.current.length : indexOf(afterId) + 1;
    if (i < 0) return;
    applyCuration(
      (prev) => [...prev.slice(0, i), { id: `n${Date.now()}`, role, text }, ...prev.slice(i)],
      { t: "insert", index: i, role, content: text },
    );
  };
  const moveMessage = (id: string, dir: -1 | 1) => {
    const i = indexOf(id);
    const j = i + dir;
    if (i < 0 || j < 0 || j >= messagesRef.current.length) return;
    applyCuration(
      (prev) => {
        const out = [...prev];
        const [m] = out.splice(i, 1);
        out.splice(j, 0, m);
        return out;
      },
      { t: "move", index: i, to: j },
    );
  };

  // parentId is the user message that produced the assistant reply being reloaded.
  // Regenerate STARTS a turn, so it needs global idle (single-flight) — refuse
  // with the busy hint rather than silently doing nothing under a visible button.
  const regenerate = (parentId: string | null) => {
    if (!parentId) return;
    if (runningThreadRef.current !== null) {
      setBanner("The assistant is still replying in another thread — wait for it to finish or stop it first.");
      return;
    }
    const i = indexOf(parentId);
    if (i < 0) return;
    if (!send({ t: "regenerate", index: i })) return;
    setMessages((prev) => prev.slice(0, i + 1));   // drop the old reply; keep the prompt
  };

  const newThread = () => send({ t: "thread_new" });
  const switchThread = (tid: string) => {
    setActive(tid);
    activeRef.current = tid;
    clearUnread(tid);
    send({ t: "thread_switch", thread_id: tid });
  };

  const runtime = useExternalStoreRuntime({
    messages,
    // Running means THIS thread's turn — a background turn in another thread
    // doesn't flip the visible composer to its stop state.
    isRunning: runningVisible,
    convertMessage,
    onNew,
    // Interrupt only — `runningThread` stays set until the generator's
    // turn_end actually arrives. Clearing it optimistically opened a window
    // where curation ops passed the renderer's gate but were silently dropped
    // by serve_chat (its turn is still winding down), desyncing the view.
    // thread_id scopes the cancel to the visible thread's turn.
    onCancel: async () => { send({ t: "interrupt", thread_id: activeRef.current }); },
    setMessages: (ms: readonly Msg[]) => setMessages(ms as Msg[]),
    onReload: async (parentId: string | null) => { regenerate(parentId); },
    unstable_capabilities: { copy: true },
  });

  return {
    runtime, messages, status, banner,
    running: runningVisible, runningThread, busyElsewhere, unread,
    dismissBanner: () => setBanner(""),
    threads: threads.length ? threads : pointer.threads, active,
    newThread, switchThread,
    curation: { editMessage, deleteMessage, insertMessage, moveMessage },
  };
}

// ── shared UI bits ────────────────────────────────────────────────────

const IconBtn = ({ title, danger, style, ...rest }: any) => (
  <button
    type="button"
    className="aui-iconbtn"
    title={title}
    aria-label={title}
    style={{
      display: "inline-flex", alignItems: "center", justifyContent: "center",
      width: 28, height: 28, borderRadius: 8, border: "none", padding: 0,
      background: "transparent", color: danger ? T.destructive : T.dim,
      cursor: "pointer", ...style,
    }}
    {...rest}
  />
);

const smallBtn: React.CSSProperties = {
  border: `1px solid ${T.line}`, background: "transparent", color: T.fg,
  borderRadius: 8, padding: "4px 12px", fontSize: 13, cursor: "pointer",
};

// ── message parts (markdown, reasoning, sources, tools) ──────────────

// Markdown element overrides — inline-styled so they render correctly in the
// shadow root (react-markdown emits no default classes).
const md = {
  p: (p: any) => <p style={{ margin: "0 0 8px" }} {...p} />,
  a: (p: any) => <a style={{ color: T.accent }} target="_blank" rel="noopener noreferrer" {...p} />,
  ul: (p: any) => <ul style={{ margin: "0 0 8px", paddingLeft: 20 }} {...p} />,
  ol: (p: any) => <ol style={{ margin: "0 0 8px", paddingLeft: 20 }} {...p} />,
  li: (p: any) => <li style={{ margin: "2px 0" }} {...p} />,
  h1: (p: any) => <h1 style={{ fontSize: 20, margin: "10px 0 6px" }} {...p} />,
  h2: (p: any) => <h2 style={{ fontSize: 17, margin: "10px 0 6px" }} {...p} />,
  h3: (p: any) => <h3 style={{ fontSize: 15, margin: "8px 0 4px" }} {...p} />,
  blockquote: (p: any) => <blockquote style={{ margin: "0 0 8px", padding: "2px 10px", borderLeft: `3px solid ${T.line}`, color: T.dim }} {...p} />,
  hr: () => <hr style={{ border: "none", borderTop: `1px solid ${T.line}`, margin: "10px 0" }} />,
  pre: (p: any) => <pre style={{ background: T.panel, border: `1px solid ${T.line}`, padding: 10, borderRadius: 10, overflow: "auto", margin: "0 0 8px" }} {...p} />,
  code: (p: any) => <code style={{ background: T.panel, padding: "1px 4px", borderRadius: 4, fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace", fontSize: "0.92em" }} {...p} />,
  table: (p: any) => <table style={{ borderCollapse: "collapse", margin: "0 0 8px" }} {...p} />,
  th: (p: any) => <th style={{ border: `1px solid ${T.line}`, padding: "3px 8px", textAlign: "left" }} {...p} />,
  td: (p: any) => <td style={{ border: `1px solid ${T.line}`, padding: "3px 8px" }} {...p} />,
};
const MarkdownText = () => <MarkdownTextPrimitive smooth components={md} />;

// Plain text for user bubbles (no markdown, preserve newlines).
const UserText = () => {
  const part: any = useMessagePartText();
  return <span style={{ whiteSpace: "pre-wrap" }}>{part?.text ?? ""}</span>;
};

// Reasoning + Sources message parts (populated by runtimes that emit them,
// e.g. opencode). Defensive about the exact part shape so a mismatch renders
// nothing rather than crashing the thread.
const Reasoning = () => {
  const part: any = useMessagePartReasoning();
  const text = part?.text ?? "";
  if (!text) return null;
  return (
    <details style={{ margin: "0 0 8px", color: T.dim, fontSize: 13 }}>
      <summary style={{ cursor: "pointer" }}>Reasoning</summary>
      <div style={{ whiteSpace: "pre-wrap", paddingTop: 4, fontStyle: "italic" }}>{text}</div>
    </details>
  );
};
const SourcePart = () => {
  const part: any = useMessagePartSource();
  const url = part?.url;
  if (!url) return null;
  return (
    <a href={url} target="_blank" rel="noopener noreferrer"
      style={{ display: "inline-block", margin: "2px 6px 2px 0", padding: "1px 8px",
        border: `1px solid ${T.line}`, borderRadius: 999, color: T.accent,
        fontSize: 12, textDecoration: "none" }}>🔗 {part?.title || url}</a>
  );
};

// Generic tool-call rendering (opencode runtime emits tool parts).
const ToolFallback = (p: any) => {
  const name = p?.toolName || p?.part?.toolName || "tool";
  const args = p?.argsText ?? (p?.args ? JSON.stringify(p.args, null, 2) : "");
  const result = typeof p?.result === "string" ? p.result
    : p?.result !== undefined ? JSON.stringify(p.result, null, 2) : "";
  return (
    <details style={{ margin: "0 0 8px", border: `1px solid ${T.line}`, borderRadius: 10, padding: "6px 10px", fontSize: 13 }}>
      <summary style={{ cursor: "pointer", color: T.dim }}>
        🔧 {name}
      </summary>
      {args ? <pre style={{ margin: "6px 0 0", overflow: "auto", fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace", fontSize: 12, color: T.dim }}>{args}</pre> : null}
      {result ? <pre style={{ margin: "6px 0 0", overflow: "auto", fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace", fontSize: 12 }}>{result}</pre> : null}
    </details>
  );
};

const assistantParts = {
  Text: MarkdownText,
  Reasoning,
  Source: SourcePart,
  tools: { Fallback: ToolFallback },
};

// ── curation context ─────────────────────────────────────────────────
//
// The native runtime provides these; the opencode runtime provides none
// (opencode owns its own session history).
interface Curation {
  canCurate: boolean;      // no turn streaming (live-idle or stopped)
  canGenerate: boolean;    // socket open → send / regenerate work
  messages: Msg[];
  editMessage: (id: string, text: string) => void;
  deleteMessage: (id: string) => void;
  insertMessage: (afterId: string | null, role: Role, text: string) => void;
  moveMessage: (id: string, dir: -1 | 1) => void;
}
const CurationCtx = React.createContext<Curation | null>(null);

// A small inline editor used for both "edit message" and "insert message".
function InlineEditor(props: {
  initial: string;
  saveLabel: string;
  role?: Role;                       // when set, show a role toggle
  onRole?: (r: Role) => void;
  onSave: (text: string) => void;
  onCancel: () => void;
}) {
  const [text, setText] = useState(props.initial);
  const taRef = useRef<HTMLTextAreaElement | null>(null);
  useEffect(() => { taRef.current?.focus(); }, []);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8, background: T.muted,
      borderRadius: 16, padding: 12, width: "100%" }}>
      {props.role && props.onRole && (
        <div style={{ display: "flex", gap: 6 }}>
          {(["user", "assistant"] as Role[]).map((r) => (
            <button key={r} type="button" onClick={() => props.onRole!(r)}
              style={{ ...smallBtn, padding: "2px 10px", fontSize: 12,
                borderColor: props.role === r ? T.accent : T.line,
                color: props.role === r ? T.fg : T.dim }}>
              {r === "user" ? "User" : "Assistant"}
            </button>
          ))}
        </div>
      )}
      <textarea
        ref={taRef}
        className="aui-input"
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Escape") props.onCancel();
          if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) props.onSave(text);
        }}
        style={{ minHeight: 72, width: "100%", resize: "vertical", background: "transparent",
          border: "none", outline: "none", color: T.fg, font: "inherit", lineHeight: 1.5 }}
      />
      <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
        <button type="button" style={{ ...smallBtn, border: "none", color: T.dim }} onClick={props.onCancel}>Cancel</button>
        <button type="button" style={{ ...smallBtn, background: T.fg, color: T.bg, border: "none" }}
          onClick={() => props.onSave(text)}>{props.saveLabel}</button>
      </div>
    </div>
  );
}

// "+" flow: pick a role, type the message, save → insert below this message
// (or at the end of the thread when afterId is null).
function InsertComposer(props: { afterId: string | null; defaultRole: Role; onDone: () => void }) {
  const cur = React.useContext(CurationCtx);
  const [role, setRole] = useState<Role>(props.defaultRole);
  if (!cur) return null;
  return (
    <div style={{ margin: "8px 0" }}>
      <InlineEditor
        initial=""
        saveLabel="Insert"
        role={role}
        onRole={setRole}
        onCancel={props.onDone}
        onSave={(text) => {
          const t = text.trim();
          if (t) cur.insertMessage(props.afterId, role, t);
          props.onDone();
        }}
      />
    </div>
  );
}

// The per-message curation buttons (insert / move / delete + custom edit).
function CurationButtons(props: { id: string; onEdit: () => void; onInsert: () => void }) {
  const cur = React.useContext(CurationCtx);
  if (!cur || !cur.canCurate) return null;
  const i = cur.messages.findIndex((m) => m.id === props.id);
  const last = i === cur.messages.length - 1;
  return (
    <>
      <IconBtn title="Edit message" onClick={props.onEdit}><Pencil size={14} /></IconBtn>
      <IconBtn title="Insert message below" onClick={props.onInsert}><Plus size={14} /></IconBtn>
      <IconBtn title="Move up" disabled={i <= 0} style={i <= 0 ? { opacity: 0.3, cursor: "default" } : undefined}
        onClick={() => cur.moveMessage(props.id, -1)}><ChevronUp size={14} /></IconBtn>
      <IconBtn title="Move down" disabled={last} style={last ? { opacity: 0.3, cursor: "default" } : undefined}
        onClick={() => cur.moveMessage(props.id, 1)}><ChevronDown size={14} /></IconBtn>
      <IconBtn title="Delete message" danger onClick={() => cur.deleteMessage(props.id)}><Trash2 size={14} /></IconBtn>
    </>
  );
}

// ── thread UI ─────────────────────────────────────────────────────────

function BranchPicker(props: { style?: React.CSSProperties }) {
  return (
    <BranchPickerPrimitive.Root
      hideWhenSingleBranch
      style={{ display: "inline-flex", alignItems: "center", gap: 2, fontSize: 12,
        color: T.dim, ...props.style }}
    >
      <BranchPickerPrimitive.Previous asChild>
        <IconBtn title="Previous"><ChevronLeft size={14} /></IconBtn>
      </BranchPickerPrimitive.Previous>
      <span style={{ fontWeight: 500 }}>
        <BranchPickerPrimitive.Number /> / <BranchPickerPrimitive.Count />
      </span>
      <BranchPickerPrimitive.Next asChild>
        <IconBtn title="Next"><ChevronRight size={14} /></IconBtn>
      </BranchPickerPrimitive.Next>
    </BranchPickerPrimitive.Root>
  );
}

function ThreadWelcome(props: { label: string }) {
  return (
    <div style={{ margin: "auto", display: "flex", flexDirection: "column",
      justifyContent: "center", width: "100%", maxWidth: THREAD_MAX_WIDTH,
      flexGrow: 1, padding: "0 24px" }}>
      <div style={{ fontSize: 24, fontWeight: 600, color: T.fg }}>{props.label}</div>
      <div style={{ fontSize: 24, color: T.dim }}>How can I help you today?</div>
    </div>
  );
}

function UserMessage() {
  const id = useMessage((m: any) => m.id) as string;
  const cur = React.useContext(CurationCtx);
  const [editing, setEditing] = useState(false);
  const [inserting, setInserting] = useState(false);
  return (
    <MessagePrimitive.Root
      data-role="user"
      style={{ margin: "0 auto", width: "100%", maxWidth: THREAD_MAX_WIDTH, padding: "10px 8px 0" }}
    >
      {editing && cur ? (
        <div style={{ display: "flex", justifyContent: "flex-end" }}>
          <div style={{ width: "min(100%, 85%)" }}>
            <InlineEditor
              initial={cur.messages.find((m) => m.id === id)?.text ?? ""}
              saveLabel="Update"
              onCancel={() => setEditing(false)}
              onSave={(text) => { cur.editMessage(id, text); setEditing(false); }}
            />
          </div>
        </div>
      ) : (
        <div style={{ display: "flex", justifyContent: "flex-end", minWidth: 0 }}>
          <div style={{ background: T.muted, color: T.fg, borderRadius: 16,
            padding: "10px 16px", maxWidth: "85%", overflowWrap: "break-word",
            lineHeight: 1.55, minWidth: 0 }}>
            <MessagePrimitive.Parts components={{ Text: UserText }} />
          </div>
        </div>
      )}
      {inserting && <InsertComposer afterId={id} defaultRole="assistant" onDone={() => setInserting(false)} />}
      {/* Action row UNDER the bubble. Always present with a fixed height so
          the hover-revealed icons never shift the message layout. */}
      {!editing && (
        <div style={{ display: "flex", justifyContent: "flex-end", alignItems: "center",
          gap: 4, minHeight: 28 }}>
          {!cur && <BranchPicker />}
          <ActionBarPrimitive.Root
            hideWhenRunning
            autohide="always"
            style={{ display: "flex", alignItems: "center", gap: 2 }}
          >
            <ActionBarPrimitive.Copy asChild>
              <IconBtn title="Copy"><Copy size={14} /></IconBtn>
            </ActionBarPrimitive.Copy>
            <CurationButtons id={id} onEdit={() => setEditing(true)} onInsert={() => setInserting(true)} />
          </ActionBarPrimitive.Root>
        </div>
      )}
    </MessagePrimitive.Root>
  );
}

function SystemMessage() {
  const id = useMessage((m: any) => m.id) as string;
  const cur = React.useContext(CurationCtx);
  const [editing, setEditing] = useState(false);
  const [inserting, setInserting] = useState(false);
  return (
    <MessagePrimitive.Root
      data-role="system"
      style={{ margin: "0 auto", width: "100%", maxWidth: THREAD_MAX_WIDTH, padding: "10px 8px" }}
    >
      {editing && cur ? (
        <InlineEditor
          initial={cur.messages.find((m) => m.id === id)?.text ?? ""}
          saveLabel="Update"
          onCancel={() => setEditing(false)}
          onSave={(text) => { cur.editMessage(id, text); setEditing(false); }}
        />
      ) : (
        <div style={{ display: "flex", alignItems: "flex-start", gap: 6 }}>
          <div style={{ flex: 1, minWidth: 0, border: `1px dashed ${T.line}`, borderRadius: 12,
            padding: "8px 12px", color: T.dim, fontSize: 13, whiteSpace: "pre-wrap" }}>
            <div style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: 1, marginBottom: 2 }}>system</div>
            <MessagePrimitive.Parts components={{ Text: UserText }} />
          </div>
          <span style={{ display: "flex", alignItems: "center" }}>
            <CurationButtons id={id} onEdit={() => setEditing(true)} onInsert={() => setInserting(true)} />
          </span>
        </div>
      )}
      {inserting && <InsertComposer afterId={id} defaultRole="user" onDone={() => setInserting(false)} />}
    </MessagePrimitive.Root>
  );
}

function MessageError() {
  return (
    <MessagePrimitive.Error>
      <ErrorPrimitive.Root style={{ marginTop: 8, borderRadius: 10, padding: 12,
        border: `1px solid ${T.destructive}`, color: T.destructive, fontSize: 13,
        background: "color-mix(in srgb, currentColor 8%, transparent)" }}>
        <ErrorPrimitive.Message />
      </ErrorPrimitive.Root>
    </MessagePrimitive.Error>
  );
}

function AssistantMessage() {
  const id = useMessage((m: any) => m.id) as string;
  const cur = React.useContext(CurationCtx);
  const [editing, setEditing] = useState(false);
  const [inserting, setInserting] = useState(false);
  return (
    <MessagePrimitive.Root
      data-role="assistant"
      style={{ position: "relative", margin: "0 auto", width: "100%",
        maxWidth: THREAD_MAX_WIDTH, padding: "10px 8px" }}
    >
      {editing && cur ? (
        <InlineEditor
          initial={cur.messages.find((m) => m.id === id)?.text ?? ""}
          saveLabel="Update"
          onCancel={() => setEditing(false)}
          onSave={(text) => { cur.editMessage(id, text); setEditing(false); }}
        />
      ) : (
        <div style={{ color: T.fg, lineHeight: 1.6, overflowWrap: "break-word", minWidth: 0 }}>
          <MessagePrimitive.Parts components={assistantParts} />
          <MessageError />
          <AuiIf condition={(s: any) => s.thread.isRunning && s.message.content.length === 0}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, color: T.dim }}>
              <Loader size={15} className="aui-spin" />
              <span style={{ fontSize: 13 }}>Thinking…</span>
            </div>
          </AuiIf>
        </div>
      )}
      {inserting && <InsertComposer afterId={id} defaultRole="user" onDone={() => setInserting(false)} />}
      {/* Action row with fixed height (hover-only icons must not shift text). */}
      {!editing && (
        <div style={{ display: "flex", alignItems: "center", gap: 4, minHeight: 28, marginTop: 2 }}>
          {!cur && <BranchPicker />}
          <ActionBarPrimitive.Root
            hideWhenRunning
            autohide="always"
            style={{ display: "flex", alignItems: "center", gap: 2 }}
          >
            <ActionBarPrimitive.Copy asChild>
              <IconBtn title="Copy">
                <AuiIf condition={(s: any) => s.message.isCopied}><Check size={14} /></AuiIf>
                <AuiIf condition={(s: any) => !s.message.isCopied}><Copy size={14} /></AuiIf>
              </IconBtn>
            </ActionBarPrimitive.Copy>
            {(!cur || cur.canGenerate) && (
              <ActionBarPrimitive.Reload asChild>
                <IconBtn title="Regenerate"><RefreshCw size={14} /></IconBtn>
              </ActionBarPrimitive.Reload>
            )}
            <CurationButtons id={id} onEdit={() => setEditing(true)} onInsert={() => setInserting(true)} />
          </ActionBarPrimitive.Root>
        </div>
      )}
    </MessagePrimitive.Root>
  );
}

function ScrollToBottom() {
  return (
    <ThreadPrimitive.ScrollToBottom asChild>
      <button type="button" className="aui-stb" title="Scroll to bottom"
        style={{ position: "absolute", top: -44, left: "50%", transform: "translateX(-50%)",
          width: 34, height: 34, borderRadius: 999, border: `1px solid ${T.line}`,
          background: T.bg, color: T.fg, cursor: "pointer", display: "inline-flex",
          alignItems: "center", justifyContent: "center", boxShadow: "0 1px 6px #0006", zIndex: 10 }}>
        <ArrowDown size={16} />
      </button>
    </ThreadPrimitive.ScrollToBottom>
  );
}

function Composer(props: { disabled: boolean; disabledHint: string }) {
  return (
    <ComposerPrimitive.Root className="aui-composer"
      style={{ display: "flex", flexDirection: "column", width: "100%",
        border: `1px solid ${T.line}`, borderRadius: 16, background: T.bg }}>
      <ComposerPrimitive.Input
        className="aui-input"
        placeholder={props.disabled ? props.disabledHint : "Send a message…"}
        rows={1}
        autoFocus
        disabled={props.disabled}
        aria-label="Message input"
        style={{ width: "100%", minHeight: 52, maxHeight: 128, resize: "none",
          background: "transparent", border: "none", outline: "none",
          color: T.fg, font: "inherit", lineHeight: 1.5, padding: "12px 14px 4px" }}
      />
      <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", padding: "0 8px 8px" }}>
        <AuiIf condition={(s: any) => !s.thread.isRunning}>
          <ComposerPrimitive.Send asChild>
            <button type="button" title="Send message" aria-label="Send message"
              disabled={props.disabled}
              style={{ width: 32, height: 32, borderRadius: 999, border: "none",
                background: props.disabled ? T.muted : T.accent,
                color: props.disabled ? T.dim : T.accentFg,
                display: "inline-flex", alignItems: "center", justifyContent: "center",
                cursor: props.disabled ? "default" : "pointer" }}>
              <ArrowUp size={16} />
            </button>
          </ComposerPrimitive.Send>
        </AuiIf>
        <AuiIf condition={(s: any) => s.thread.isRunning}>
          <ComposerPrimitive.Cancel asChild>
            <button type="button" title="Stop generating" aria-label="Stop generating"
              style={{ width: 32, height: 32, borderRadius: 999, border: "none",
                background: T.accent, color: T.accentFg, display: "inline-flex",
                alignItems: "center", justifyContent: "center", cursor: "pointer" }}>
              <Square size={12} fill="currentColor" />
            </button>
          </ComposerPrimitive.Cancel>
        </AuiIf>
      </div>
    </ComposerPrimitive.Root>
  );
}

// Left thread sidebar — pick / start conversations, collapsible. Native threads
// come from the pointer + live `threads` frames; opencode manages its own
// sessions, so its sidebar shows the label only.
function Sidebar(props: {
  label: string; threads: ThreadEntry[]; active: string; status: string;
  expanded: boolean; onToggle: () => void;
  onNew?: () => void; onSwitch?: (id: string) => void; canNew: boolean;
  unread?: Record<string, boolean>; runningThread?: string | null;
}) {
  const dot = props.status === "open" || props.status === "opencode" ? "#3fb950"
    : props.status === "connecting" ? "#d29922" : "#f85149";
  const statusTitle = props.status === "open" ? "connected"
    : props.status === "opencode" ? "opencode" : props.status === "connecting" ? "connecting…" : "stopped";
  // A non-active thread with unread content or an in-flight background turn.
  const flagged = (tid: string) =>
    tid !== props.active && (!!props.unread?.[tid] || props.runningThread === tid);
  const anyFlagged = props.threads.some((t) => flagged(t.id));
  if (!props.expanded) {
    return (
      <div style={{ width: 44, minWidth: 44, display: "flex", flexDirection: "column",
        alignItems: "center", gap: 6, padding: "10px 0",
        borderRight: `1px solid ${T.line}`, background: T.panel }}>
        <IconBtn title="Show threads" onClick={props.onToggle}><PanelLeftOpen size={16} /></IconBtn>
        {props.onNew && (
          <IconBtn title="New thread" disabled={!props.canNew}
            style={!props.canNew ? { opacity: 0.35, cursor: "default" } : undefined}
            onClick={props.canNew ? props.onNew : undefined}>
            <MessageSquarePlus size={16} />
          </IconBtn>
        )}
        {anyFlagged && (
          <span title="New messages in another thread"
            className={props.runningThread && props.runningThread !== props.active ? "aui-pulse" : undefined}
            style={{ width: 8, height: 8, borderRadius: 999, background: T.accent }} />
        )}
        <span title={statusTitle} style={{ marginTop: "auto", width: 8, height: 8,
          borderRadius: 999, background: dot }} />
      </div>
    );
  }
  return (
    <div style={{ width: 232, minWidth: 232, display: "flex", flexDirection: "column",
      borderRight: `1px solid ${T.line}`, background: T.panel }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "10px 8px 10px 12px",
        borderBottom: `1px solid ${T.line}` }}>
        <span title={statusTitle} style={{ width: 8, height: 8, borderRadius: 999,
          background: dot, flex: "0 0 auto" }} />
        <strong style={{ color: T.fg, fontSize: 13, flex: 1, overflow: "hidden",
          textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{props.label}</strong>
        <IconBtn title="Hide threads" onClick={props.onToggle}><PanelLeftClose size={15} /></IconBtn>
      </div>
      {props.onNew && (
        <button type="button" className="aui-listbtn"
          disabled={!props.canNew}
          onClick={props.canNew ? props.onNew : undefined}
          title={props.canNew ? "Start a new thread" : "The generator is stopped"}
          style={{ display: "flex", alignItems: "center", gap: 8, margin: 8,
            padding: "7px 10px", background: "transparent", color: props.canNew ? T.fg : T.dim,
            border: `1px solid ${T.line}`, borderRadius: 10,
            cursor: props.canNew ? "pointer" : "default", fontSize: 13 }}>
          <Plus size={14} /> New thread
        </button>
      )}
      <div style={{ flex: 1, overflowY: "auto", padding: "0 6px 8px" }}>
        {props.threads.map((t) => {
          const streaming = props.runningThread === t.id && t.id !== props.active;
          return (
            <button key={t.id} type="button" className="aui-listbtn"
              onClick={() => props.onSwitch?.(t.id)}
              style={{ display: "flex", alignItems: "center", gap: 8, width: "100%",
                textAlign: "left", marginBottom: 2,
                padding: "7px 10px", borderRadius: 8, cursor: "pointer", fontSize: 13,
                color: T.fg, border: "none",
                background: t.id === props.active ? T.active : "transparent",
                fontWeight: t.id === props.active ? 600 : 400 }}
              title={t.title || t.id}>
              <span style={{ flex: 1, minWidth: 0, overflow: "hidden",
                textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {t.title || t.id}
              </span>
              {flagged(t.id) && (
                <span className={streaming ? "aui-pulse" : undefined}
                  title={streaming ? "Assistant is replying…" : "New messages"}
                  style={{ width: 8, height: 8, borderRadius: 999,
                    background: T.accent, flex: "0 0 auto" }} />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

const SIDEBAR_KEY = "collimate.assistant.sidebar";

function ChatUI(props: {
  label: string; threads: ThreadEntry[]; active: string; status: string;
  scheme: "light" | "dark";
  banner?: string; onDismissBanner?: () => void;
  onNew?: () => void; onSwitch?: (id: string) => void;
  composerDisabled: boolean; composerHint: string;
  canCurate: boolean;
  unread?: Record<string, boolean>; runningThread?: string | null;
}) {
  const [expanded, setExpanded] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(SIDEBAR_KEY);
      if (saved === "open") return true;
      if (saved === "closed") return false;
    } catch { /* noop */ }
    return props.threads.length > 1;
  });
  const toggle = () => setExpanded((v) => {
    try { localStorage.setItem(SIDEBAR_KEY, v ? "closed" : "open"); } catch { /* noop */ }
    return !v;
  });
  const [appending, setAppending] = useState(false);
  const canNew = props.status === "open" || props.status === "opencode";
  return (
    <div style={{ display: "flex", flexDirection: "row", height: "100%", minHeight: 0,
      ...paletteVars(props.scheme),
      background: T.bg, color: T.fg,
      font: "14px system-ui, sans-serif" }}>
      <Sidebar label={props.label} threads={props.threads} active={props.active}
        status={props.status} expanded={expanded} onToggle={toggle}
        onNew={props.onNew} onSwitch={props.onSwitch} canNew={canNew}
        unread={props.unread} runningThread={props.runningThread} />
      <ThreadPrimitive.Root style={{ flex: 1, minWidth: 0, display: "flex",
        flexDirection: "column", minHeight: 0 }}>
        {/* No turnAnchor: anchoring the new turn to the viewport top scrolls
            the prior context out ("only show the new response"). The default
            follow-bottom just reveals new content and yields to user scroll. */}
        <ThreadPrimitive.Viewport
          style={{ position: "relative", flex: 1, display: "flex", flexDirection: "column",
            overflowY: "auto", overflowX: "hidden", scrollBehavior: "smooth",
            padding: "16px 16px 0" }}
        >
          <AuiIf condition={(s: any) => s.thread.isEmpty}>
            <ThreadWelcome label={props.label} />
          </AuiIf>

          <ThreadPrimitive.Messages
            components={{ UserMessage, AssistantMessage, SystemMessage }}
          />

          <ThreadPrimitive.ViewportFooter
            style={{ position: "sticky", bottom: 0, marginTop: "auto",
              marginLeft: "auto", marginRight: "auto", width: "100%",
              maxWidth: THREAD_MAX_WIDTH, display: "flex", flexDirection: "column",
              gap: 8, background: T.bg, paddingBottom: 12,
              borderRadius: "20px 20px 0 0" }}
          >
            <ScrollToBottom />
            {props.banner ? (
              <div style={{ display: "flex", alignItems: "center", gap: 8,
                border: `1px solid ${T.destructive}`, borderRadius: 10,
                padding: "8px 12px", color: T.destructive, fontSize: 13 }}>
                <span style={{ flex: 1, minWidth: 0, overflowWrap: "break-word" }}>⚠ {props.banner}</span>
                {props.onDismissBanner && (
                  <button type="button" onClick={props.onDismissBanner}
                    style={{ border: "none", background: "transparent", color: T.destructive,
                      cursor: "pointer", fontSize: 13 }}>dismiss</button>
                )}
              </div>
            ) : null}
            {/* Available on an EMPTY thread too — a stopped chat with no
                messages is still curatable (seed a first message). */}
            {props.canCurate && (
              appending ? (
                <InsertComposer afterId={null} defaultRole="user" onDone={() => setAppending(false)} />
              ) : (
                <button type="button" className="aui-listbtn"
                  onClick={() => setAppending(true)}
                  style={{ alignSelf: "center", display: "inline-flex", alignItems: "center",
                    gap: 6, border: "none", background: "transparent", color: T.dim,
                    fontSize: 12, cursor: "pointer", padding: "2px 10px", borderRadius: 8 }}>
                  <Plus size={12} /> Add message
                </button>
              )
            )}
            <Composer disabled={props.composerDisabled} disabledHint={props.composerHint} />
          </ThreadPrimitive.ViewportFooter>
        </ThreadPrimitive.Viewport>
      </ThreadPrimitive.Root>
    </div>
  );
}

// ── apps (native / opencode) ─────────────────────────────────────────

function NativeApp({ api, pointer }: { api: any; pointer: Pointer }) {
  const chat = useNativeChat(api, pointer);
  const scheme = useScheme(api);
  useEffect(() => { try { api.ready?.(); } catch { /* noop */ } }, [api]);
  const curation: Curation = useMemo(() => ({
    canCurate: !chat.running && chat.status !== "connecting",
    canGenerate: chat.status === "open",
    messages: chat.messages,
    editMessage: chat.curation.editMessage,
    deleteMessage: chat.curation.deleteMessage,
    insertMessage: chat.curation.insertMessage,
    moveMessage: chat.curation.moveMessage,
  }), [chat.running, chat.status, chat.messages]);
  return (
    <AssistantRuntimeProvider runtime={chat.runtime}>
      <CurationCtx.Provider value={curation}>
        <ChatUI
          label={pointer.label}
          threads={chat.threads} active={chat.active} status={chat.status}
          scheme={scheme}
          banner={chat.banner} onDismissBanner={chat.dismissBanner}
          onNew={chat.newThread} onSwitch={chat.switchThread}
          composerDisabled={chat.status === "closed" || chat.busyElsewhere}
          composerHint={chat.busyElsewhere
            ? "The assistant is replying in another thread — wait or stop it first"
            : "Generator stopped — the saved conversation is still editable"}
          canCurate={curation.canCurate}
          unread={chat.unread} runningThread={chat.runningThread}
        />
      </CurationCtx.Provider>
    </AssistantRuntimeProvider>
  );
}

/** Absolute base URL for the proxied opencode server: the API origin (which
 *  handles split-origin deployments — see apiOrigin) + the pointer's
 *  app-relative /proxy/ path. */
function _opencodeBase(api: any, proxyUrl: string): string {
  return (apiOrigin(api) + proxyUrl).replace(/\/$/, "");
}

function OpencodeApp({ api, pointer }: { api: any; pointer: Pointer }) {
  const client = useMemo(
    () => createOpencodeClient({ baseUrl: _opencodeBase(api, pointer.integration!.proxy_url) }),
    [api, pointer],
  );
  const runtime = useOpenCodeRuntime({ client });
  const scheme = useScheme(api);
  useEffect(() => { try { api.ready?.(); } catch { /* noop */ } }, [api]);
  return (
    <AssistantRuntimeProvider runtime={runtime}>
      <CurationCtx.Provider value={null}>
        <ChatUI
          label={`${pointer.label} · opencode`}
          threads={[]} active="" status="opencode"
          scheme={scheme}
          composerDisabled={false} composerHint=""
          canCurate={false}
        />
      </CurationCtx.Provider>
    </AssistantRuntimeProvider>
  );
}

function App({ api, initialPointer }: { api: any; initialPointer: Pointer }) {
  // Follow pointer rewrites without a remount: a NEW RUN registers a fresh
  // chat session (new session_id/token), and NativeRenderer deliberately does
  // not remount on file-content changes — so re-read the pointer when files
  // change / content is pushed and remount the runtime tree only when the
  // session identity actually changed.
  const [pointer, setPointer] = useState(initialPointer);
  const pointerRef = useRef(pointer);
  pointerRef.current = pointer;
  useEffect(() => {
    const apply = (raw: string) => {
      const next = parsePointer(raw || "");
      if (!next) return;
      const p = pointerRef.current;
      if (next.session_id !== p.session_id || next.token !== p.token ||
          next.ws_path !== p.ws_path ||
          (next.integration?.proxy_url || "") !== (p.integration?.proxy_url || "")) {
        setPointer(next);
      }
    };
    const offContent = api.onSetContent?.((c: string) => apply(c));
    const offFiles = api.onFilesChanged?.(() => {
      Promise.resolve(api.getContent()).then((c: string) => apply(c)).catch(() => { /* noop */ });
    });
    return () => {
      try { offContent && offContent(); } catch { /* noop */ }
      try { offFiles && offFiles(); } catch { /* noop */ }
    };
  }, [api]);
  const key = `${pointer.session_id}:${pointer.token}:${pointer.integration?.proxy_url || ""}`;
  return pointer.integration?.type === "opencode"
    ? <OpencodeApp key={key} api={api} pointer={pointer} />
    : <NativeApp key={key} api={api} pointer={pointer} />;
}

// ── entry ─────────────────────────────────────────────────────────────

async function mount(el: HTMLElement, api: any) {
  let raw = "";
  try { raw = (await api.getContent()) || ""; } catch { /* noop */ }
  const pointer = parsePointer(raw);
  if (!pointer) {
    el.innerHTML = `<div style="color:${"#e6e6e6"};background:${"#0f1115"};padding:12px;font:14px system-ui;">Not a valid .chat session.</div>`;
    try { api.ready?.(); } catch { /* noop */ }
    return;
  }
  // Keyframes / pseudo-class rules — injected into the shadow root (falls back
  // to a local <style> so the renderer also works standalone).
  try {
    if (api.injectStyle) api.injectStyle(SHADOW_CSS);
    else {
      const s = document.createElement("style");
      s.textContent = SHADOW_CSS;
      (el.getRootNode() as any)?.appendChild?.(s);
    }
  } catch { /* noop */ }
  const root = createRoot(el);
  root.render(<App api={api} initialPointer={pointer} />);
  // Cleanup so NativeRenderer's unmount (tab-away) tears down the React tree —
  // which fires useNativeChat's effect cleanup and CLOSES the WebSocket, freeing
  // the host session. Without this the socket would linger like a parked iframe.
  return () => { try { root.unmount(); } catch { /* noop */ } };
}

// NativeRenderer mounts via `mount`; the defineRenderer marker + component
// keep scripts/check_renderer.mjs's export-shape check meaningful (we can't
// call the real defineRenderer — /api/sdk/react.js pins a second React).
export default { __collimate_renderer__: true, component: App, mount };
