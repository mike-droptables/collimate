import React, { useEffect, useMemo, useRef, useState } from 'https://esm.sh/react@18';
import { Terminal } from 'https://esm.sh/xterm@5.3.0';
import { FitAddon } from 'https://esm.sh/xterm-addon-fit@0.8.0';
import { WebLinksAddon } from 'https://esm.sh/xterm-addon-web-links@0.9.0';
import {
    defineRenderer,
    useCollimateFile,
    useTheme,
    useVisibility,
} from '/api/sdk/react.js';
import {
    clearDeadSession,
    isSessionDead,
    openSessionSocket,
    sessionWsUrl,
} from '/api/sdk/session.js';

/** Local shape of the /api/sdk/session.js socket handle (URL imports carry
 *  no types; see collimate-sdk/packages/renderer-hooks/src/session.ts). */
type SessionSocket = {
    readonly status: string;
    send(data: string | ArrayBufferLike | ArrayBufferView): boolean;
    sendJson(value: unknown): boolean;
    socket(): WebSocket | null;
    redial(): void;
    close(): void;
};

type ButtonSpec = { id: string; label: string };

type Parsed = {
    session_id: string;
    ws_path: string;
    token: string;
    label: string;
    buttons: ButtonSpec[];
};

function parseContent(raw: string): Parsed | null {
    try {
        const j = JSON.parse(raw || '');
        if (typeof j.session_id !== 'string' || !j.session_id) return null;
        if (typeof j.ws_path !== 'string' || !j.ws_path) return null;
        const buttons: ButtonSpec[] = Array.isArray(j.buttons)
            ? j.buttons
                  .filter((b: any) => b && typeof b.id === 'string' && typeof b.label === 'string')
                  .map((b: any) => ({ id: b.id, label: b.label }))
            : [];
        return {
            session_id: j.session_id,
            ws_path: j.ws_path,
            token: typeof j.token === 'string' ? j.token : '',
            label: typeof j.label === 'string' ? j.label : 'terminal',
            buttons,
        };
    } catch {
        return null;
    }
}

// Read xterm theme colors from the host's CSS vars, resolved against the
// current :root. Background is hard-pinned to solid black — a terminal
// is the one surface where TTY palettes (colored prompts, ANSI escape
// codes, syntax highlighting) are authored against a true-black
// background; swapping to the host's off-dark palette mutes contrast
// on high-saturation fore colors.
function buildXtermTheme(): Record<string, string> {
    if (typeof document === 'undefined') {
        return { background: '#000000', foreground: '#e2e8f0', cursor: '#7fcfa8' };
    }
    const cs = getComputedStyle(document.documentElement);
    const read = (name: string, fallback: string) => (cs.getPropertyValue(name).trim() || fallback);
    return {
        background: '#000000',
        foreground: read('--signal-white', '#e2e8f0'),
        cursor: read('--electric-teal', '#7fcfa8'),
        selectionBackground: read('--muted', '#2a2d3a'),
    };
}

// ---------------------------------------------------------------------------
// Font size — a user preference shared across all terminal cells and persisted
// so it survives reconnects, remounts, and brand-new sessions. Applied live to
// the cached xterm instance, then re-fit against the cell box (new cell metrics
// → new cols/rows → SIGWINCH to the PTY) and repainted.
// ---------------------------------------------------------------------------

const FONT_SIZE_KEY = 'collimate.terminal.fontSize';
const FONT_SIZE_MIN = 8;
const FONT_SIZE_MAX = 32;
const FONT_SIZE_DEFAULT = 13;

function readFontSize(): number {
    try {
        const v = parseInt(window.localStorage.getItem(FONT_SIZE_KEY) || '', 10);
        if (Number.isFinite(v) && v >= FONT_SIZE_MIN && v <= FONT_SIZE_MAX) return v;
    } catch { /* localStorage unavailable (private mode / sandbox) */ }
    return FONT_SIZE_DEFAULT;
}

function writeFontSize(n: number): void {
    try { window.localStorage.setItem(FONT_SIZE_KEY, String(n)); } catch { /* ignore */ }
}

// Font size is a single preference shared by every terminal cell. localStorage
// 'storage' events only fire in OTHER tabs, so to keep multiple terminal cells
// on the SAME page in lockstep we also fan out through a module-level listener
// set (all terminal cells in a page share this module + SESSION_CACHE).
const FONT_SIZE_LISTENERS = new Set<(n: number) => void>();
function broadcastFontSize(n: number): void {
    for (const cb of Array.from(FONT_SIZE_LISTENERS)) {
        try { cb(n); } catch { /* listener disposed mid-iterate */ }
    }
}

const FONT_BTN_STYLE: React.CSSProperties = {
    height: 18,
    minWidth: 20,
    padding: '0 5px',
    background: 'var(--muted, #2d2f3e)',
    border: '1px solid var(--tungsten-dim, #3a3d52)',
    borderRadius: 'var(--radius-sm, 3px)',
    color: 'var(--signal-white, #e2e8f0)',
    fontFamily: 'var(--font-mono, monospace)',
    fontSize: 11,
    lineHeight: 1,
};

// ---------------------------------------------------------------------------
// Module-level session cache — keeps xterm + WebSocket alive across
// component unmount/remount so tab switches, dive-deep, and zoom transitions
// don't lose scrollback or drop the connection.
//
// Key: session_id. Value: { term, ws, fit, container, status, status_listeners }.
// The ``container`` is the xterm DOM root — when the component unmounts we
// re-parent it into a hidden graveyard div in document.body so xterm's
// internal renderer keeps painting (it computes dimensions off
// `getBoundingClientRect`, which still resolves on a detached-from-host but
// in-DOM element). On remount we move it back into the new hostRef.
//
// Sessions self-evict when their socket leaves 'open' for good — no point
// keeping a dead terminal in memory across the rest of the page lifetime.
// ---------------------------------------------------------------------------

// Mirrors SessionSocketStatus from /api/sdk/session.js. The socket policy
// (final 4404/4401 → 'ended' + dead-session marking, 4409 → 'busy', no
// auto-retry for a stateful PTY) lives entirely in openSessionSocket.
type CachedStatus = 'connecting' | 'open' | 'closed' | 'busy' | 'ended';

type CachedSession = {
    sessionId: string;
    term: Terminal;
    fit: FitAddon;
    sock: SessionSocket;
    container: HTMLDivElement;
    // The grid size we last *sent to the PTY* — NOT the size xterm currently
    // displays. Only advanced when a resize actually goes out over an open
    // socket, so the first resize after the socket opens always lands even if
    // a mount-time fit already computed the same dims (see fitAndSync).
    lastCols: number;
    lastRows: number;
    status: CachedStatus;
    statusListeners: Set<(s: CachedStatus) => void>;
    disposeOnData: { dispose: () => void };
    unsubTheme: (() => void) | null;
    // Per-mount visibility subscription (the cell scrolling on/off screen),
    // routed through the cached session like unsubTheme so the latest mount wins.
    unsubVisible: (() => void) | null;
    // Canvas renderer is brought up lazily once, after the first fit against a
    // real layout box; this guards that one-shot upgrade.
    rendererTried: boolean;
};

const SESSION_CACHE: Map<string, CachedSession> = new Map();

function getGraveyard(): HTMLDivElement {
    const ID = '__collimate_terminal_graveyard__';
    let el = document.getElementById(ID) as HTMLDivElement | null;
    if (el) return el;
    el = document.createElement('div');
    el.id = ID;
    // Off-screen but in-DOM so xterm's renderer keeps a valid layout
    // and we don't lose its measured cell dimensions.
    el.style.position = 'fixed';
    el.style.left = '-99999px';
    el.style.top = '0';
    el.style.width = '1px';
    el.style.height = '1px';
    el.style.overflow = 'hidden';
    el.style.pointerEvents = 'none';
    document.body.appendChild(el);
    return el;
}

function notifyStatus(session: CachedSession) {
    for (const cb of Array.from(session.statusListeners)) {
        try { cb(session.status); } catch { /* listener disposed */ }
    }
}

function buildSession(parsed: Parsed, api: unknown): CachedSession {
    const container = document.createElement('div');
    container.style.width = '100%';
    container.style.height = '100%';
    container.style.background = '#000000';

    const term = new Terminal({
        cursorBlink: true,
        fontFamily: getComputedStyle(document.documentElement).getPropertyValue('--font-mono').trim()
            || 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
        fontSize: readFontSize(),
        theme: buildXtermTheme(),
        convertEol: false,
        scrollback: 5000,
        allowProposedApi: true,
    });
    const fit = new FitAddon();
    term.loadAddon(fit);
    term.loadAddon(new WebLinksAddon());

    // Stash the container in the graveyard so xterm has a parent
    // when we call open(). We'll move it into the live hostRef
    // on mount.
    getGraveyard().appendChild(container);
    term.open(container);

    const encoder = new TextEncoder();
    // One-shot guard for the first-output repaint — see onMessage below.
    let firstPaint = false;

    const session: CachedSession = {
        sessionId: parsed.session_id,
        term,
        fit,
        sock: null as unknown as SessionSocket,  // assigned right below
        container,
        lastCols: 0,
        lastRows: 0,
        status: 'connecting',
        statusListeners: new Set(),
        disposeOnData: { dispose: () => {} },
        unsubTheme: null,
        unsubVisible: null,
        rendererTried: false,
    };

    // The socket policy — dead-session marking on 4404/4401, the 4409 busy
    // message, and NO auto-retry (a PTY is stateful and single-attach; a
    // reconnect is always the user's explicit Reconnect click) — lives in
    // openSessionSocket. This renderer only reacts to status + bytes.
    session.sock = openSessionSocket({
        url: sessionWsUrl(api, parsed.ws_path, parsed.token),
        sessionId: parsed.session_id,
        binaryType: 'arraybuffer',
        transientRetryMs: false,
        busyRetryMs: false,
        onOpen: () => {
            // Push the real size now that the socket is up. By this point the
            // mount effect has re-parented the container into the live host, so
            // the box is measurable and this is the resize that takes the
            // program off the PTY's 24×80 default.
            fitAndSync(session);
            try { term.focus(); } catch {}
        },
        onMessage: (ev) => {
            if (ev.data instanceof ArrayBuffer) {
                term.write(new Uint8Array(ev.data));
            } else if (typeof ev.data === 'string') {
                term.write(ev.data);
            }
            // First output after connect. xterm and the canvas renderer were
            // brought up while the container was parked in the 1×1 graveyard,
            // so the first render of fresh content can come up unpainted — the
            // grid only appears once something forces a full repaint. None of
            // the other refresh paths (mount re-attach, fit, addon load) are
            // guaranteed to run *after* the program's first bytes have actually
            // landed, so force one here. Once is enough; the short follow-up
            // covers the case where the canvas renderer finishes loading just
            // after this first batch.
            if (!firstPaint) {
                firstPaint = true;
                refreshTerm(session);
                setTimeout(() => refreshTerm(session), 250);
            }
        },
        onStatus: (st) => {
            session.status = st as CachedStatus;
            notifyStatus(session);
            if (st === 'ended') {
                term.write('\r\n\x1b[33m[session ended — run the cell again to start a new terminal]\x1b[0m\r\n');
            } else if (st === 'busy') {
                term.write('\r\n\x1b[33m[already attached in another view — close it or hit Reconnect]\x1b[0m\r\n');
            } else if (st === 'closed') {
                term.write('\r\n\x1b[33m[connection closed]\x1b[0m\r\n');
            }
            // Self-evict the cache once the connection is dead. With auto-retry
            // off, every non-open state is final for this session object — no
            // value in keeping the rendered scrollback for a session only an
            // explicit Reconnect (which rebuilds from scratch) can revive.
            if (st === 'ended' || st === 'busy' || st === 'closed') {
                SESSION_CACHE.delete(session.sessionId);
            }
        },
    });

    session.disposeOnData = term.onData((d: string) => {
        session.sock.send(encoder.encode(d));
    });

    SESSION_CACHE.set(parsed.session_id, session);
    return session;
}

function disposeSession(sessionId: string) {
    const session = SESSION_CACHE.get(sessionId);
    if (!session) return;
    SESSION_CACHE.delete(sessionId);
    try { session.disposeOnData.dispose(); } catch {}
    if (session.unsubTheme) { try { session.unsubTheme(); } catch {} }
    if (session.unsubVisible) { try { session.unsubVisible(); } catch {} }
    try { session.sock.close(); } catch {}
    try { session.term.dispose(); } catch {}
    try { session.container.remove(); } catch {}
}

// Re-measure the box and resize the PTY to match — the one place every fit
// path funnels through (WS open, ResizeObserver, mount). The two halves are
// deliberately decoupled:
//   * xterm's display grid is always refit to the box (fit.fit()), so the
//     rendered columns track the cell's width pixel-for-pixel; and
//   * the PTY winsize is only pushed when it actually differs from what we
//     last told the kernel, and lastCols/lastRows only advance when the send
//     actually goes out (sock.send is OPEN-guarded). That ordering is the fix for
//     the intermittent "stuck at 80×24" layout: a mount-time fit used to set
//     lastCols before the socket was open, so the onopen fit then saw an
//     unchanged size and never sent the real dimensions, leaving the program
//     rendering against the PTY's 24×80 default in a much larger cell.
function fitAndSync(session: CachedSession): void {
    // A box smaller than a cell can't be fit — during a zoom transition or
    // while parked in the graveyard the container measures 0–1px, and fitting
    // then would compute a 1-column grid and fire a bogus 1×1 resize at the
    // program. Wait for the ResizeObserver to fire again with a real box.
    const rect = session.container.getBoundingClientRect();
    if (rect.width < 2 || rect.height < 2) return;
    try {
        session.fit.fit();
    } catch {
        return;
    }
    const cols = session.term.cols;
    const rows = session.term.rows;
    if (cols !== session.lastCols || rows !== session.lastRows) {
        // sock.send is OPEN-guarded and returns whether the frame went out —
        // only then advance last*, so a reconnect re-pushes the real size.
        if (session.sock.sendJson({ t: 'resize', cols, rows })) {
            session.lastCols = cols;
            session.lastRows = rows;
        }
    }
}

// Upgrade xterm's default DOM renderer to the 2D-canvas renderer. The DOM
// renderer repaints cell-by-cell and visibly tears on the full-screen redraws
// Ink/tcell TUIs (Claude Code, lazygit) emit on every keystroke and every
// SIGWINCH — the "odd flashing" seen while resizing. The canvas renderer paints
// the whole grid in one pass, so each repaint is atomic and flicker-free.
//
// We use the 2D-canvas renderer, NOT WebGL, on purpose. A WebGL context can be
// lost (GPU reset / too many live contexts) and — in this shadow-DOM,
// GPU-composited zoom scene — its canvas could come up un-composited: solid
// black yet fully live (keystrokes and clickable links work, nothing paints)
// until a DOM re-attach. The 2D canvas has neither failure mode: it composites
// like any other element and has no GPU context to lose, at a negligible
// throughput cost for an interactive terminal. Loaded once per session, lazily
// (after a real box exists), via dynamic import so a CDN hiccup degrades
// cleanly to xterm's built-in DOM renderer.
async function loadRendererAddon(session: CachedSession): Promise<void> {
    if (session.rendererTried) return;
    session.rendererTried = true;
    try {
        const mod: any = await import('https://esm.sh/xterm-addon-canvas@0.5.0');
        session.term.loadAddon(new mod.CanvasAddon());
        // The addon's first paint is async (its atlas builds on the next
        // render). Force a full repaint once it's installed so a terminal just
        // re-attached from the graveyard draws its current buffer immediately.
        refreshTerm(session);
    } catch {
        // Canvas addon unavailable — xterm's built-in DOM renderer (already
        // active) is the fallback.
    }
}

// Force xterm to repaint every visible row from its in-memory buffer. The GPU
// (WebGL/canvas) renderers paint into a drawing buffer that the browser may
// clear or release whenever the <canvas> is detached, parked in the 1×1
// graveyard, or hidden via an ancestor `display:none` (the frontend flips
// offscreen cells to display:none — see StackItem). A full-screen TUI only
// emits output on input or SIGWINCH, so after the buffer is cleared there is
// nothing to trigger a redraw and the grid shows black until a keystroke.
// Re-issuing refresh(0, rows-1) repaints the existing buffer with no PTY
// round-trip. Deferred to a rAF so the box has been laid out (and, for the
// addon path, so the renderer has finished installing) before we repaint.
function refreshTerm(session: CachedSession): void {
    requestAnimationFrame(() => {
        try {
            const rows = session.term.rows;
            if (rows > 0) session.term.refresh(0, rows - 1);
        } catch { /* term disposed mid-frame */ }
    });
}

function TerminalViewer() {
    const { content, api } = useCollimateFile();
    const { onChange: onThemeChange } = useTheme(api);
    const { onChange: onVisibleChange } = useVisibility(api);
    const parsed = useMemo<Parsed | null>(() => parseContent(content), [content]);
    const hostRef = useRef<HTMLDivElement | null>(null);
    const [status, setStatus] = useState<CachedStatus | 'idle'>('idle');
    const [attempt, setAttempt] = useState(0);
    const [pendingAction, setPendingAction] = useState<string | null>(null);
    const [actionStatus, setActionStatus] = useState<string>('');
    const [fontSize, setFontSize] = useState<number>(readFontSize());

    // Step the shared font size and apply it live to the cached xterm: bump the
    // option, refit the grid to the cell box (which pushes a resize to the PTY),
    // then force a repaint so the new metrics land without waiting for output.
    const changeFontSize = (delta: number) => {
        const next = Math.max(FONT_SIZE_MIN, Math.min(FONT_SIZE_MAX, readFontSize() + delta));
        if (next === readFontSize()) return;
        writeFontSize(next);
        // Fan out to every terminal cell (incl. this one, via the listener
        // effect below) so the shared preference stays in lockstep; cross-tab is
        // covered by the 'storage' handler.
        broadcastFontSize(next);
    };

    // Live-apply the shared font size to this cell's cached xterm when ANY cell
    // changes it (same-page via broadcastFontSize, cross-tab via 'storage').
    useEffect(() => {
        const apply = (n: number) => {
            setFontSize(n);
            const session = parsed ? SESSION_CACHE.get(parsed.session_id) : undefined;
            if (session) {
                try { session.term.options.fontSize = n; } catch { /* term disposed */ }
                fitAndSync(session);
                refreshTerm(session);
            }
        };
        FONT_SIZE_LISTENERS.add(apply);
        const onStorage = (e: StorageEvent) => {
            if (e.key === FONT_SIZE_KEY) apply(readFontSize());
        };
        window.addEventListener('storage', onStorage);
        return () => {
            FONT_SIZE_LISTENERS.delete(apply);
            window.removeEventListener('storage', onStorage);
        };
    }, [parsed?.session_id]);

    const clickAction = async (id: string, label: string) => {
        if (pendingAction) return;
        setPendingAction(id);
        setActionStatus('');
        const ok = typeof api.emitAction === 'function' ? await api.emitAction(id) : false;
        setActionStatus(ok ? `${label} sent` : `${label} failed`);
        setPendingAction(null);
        setTimeout(() => setActionStatus(''), 2500);
    };

    useEffect(() => {
        if (!parsed || !hostRef.current) return;
        api.loadCSS('https://esm.sh/xterm@5.3.0/css/xterm.css');

        // Reconnect button (Reconnect: bumps `attempt`) lets the user
        // explicitly recreate after a closed/errored socket. Kill the
        // cached session on a manual retry so buildSession reconstructs
        // a fresh WebSocket; the React effect cleanup below will then
        // re-attach the new session's container. An explicit click also
        // clears the dead-session marker: one deliberate dial, re-marked
        // if the server still rejects it.
        if (attempt > 0) {
            clearDeadSession(parsed.session_id);
            disposeSession(parsed.session_id);
        }

        let session = SESSION_CACHE.get(parsed.session_id);
        if (!session) {
            if (isSessionDead(parsed.session_id)) {
                // The server already told us this session is gone (4404/4401).
                // Don't redial on remount — that's the forever-retry loop.
                setStatus('ended');
                return;
            }
            session = buildSession(parsed, api);
        }

        // Move the cached container into our host. document.adoptNode
        // isn't needed — appendChild on an in-DOM element relocates it
        // and preserves all internal state (event listeners, refs).
        // xterm's renderer recomputes layout via ResizeObserver below.
        const host = hostRef.current;
        host.appendChild(session.container);
        // Re-attaching from the graveyard (or un-hiding after the frontend
        // flipped this cell's subtree to display:none while offscreen) can
        // leave the GPU renderer's drawing buffer cleared. Force a repaint
        // from the in-memory buffer so the grid shows its current content
        // immediately instead of black — a full-screen TUI won't redraw on
        // its own until the next keystroke/SIGWINCH.
        refreshTerm(session);

        // Status subscription. Surface the cached session's current
        // status immediately on mount so we don't show 'idle' for the
        // brief window before the first state change after remount.
        setStatus(session.status);
        const statusCb = (s: CachedStatus) => setStatus(s);
        session.statusListeners.add(statusCb);

        // Theme hot-swap is per-mount (each component mount has its
        // own `onThemeChange` subscription), but we route the new
        // listener through the cached session so the most recent
        // mount's subscriber wins. Replace any prior listener.
        if (session.unsubTheme) {
            try { session.unsubTheme(); } catch {}
        }
        session.unsubTheme = onThemeChange(() => {
            try { session!.term.options.theme = buildXtermTheme(); } catch {}
        });

        // Visibility hot-swap — the first-class host signal for "this cell
        // scrolled back on screen." While offscreen the host display:none's
        // the subtree, which can clear the GPU renderer's drawing buffer; on
        // return we repaint from the in-memory buffer so the grid is never
        // black. Routed through the cached session like the theme listener so
        // the latest mount's subscriber wins. (The ResizeObserver 0→box
        // repaint below is a belt-and-suspenders fallback for the same case;
        // this is the documented, first-class path GPU renderers should use.)
        if (session.unsubVisible) {
            try { session.unsubVisible(); } catch {}
        }
        session.unsubVisible = onVisibleChange((vis: boolean) => {
            if (vis) refreshTerm(session!);
        });

        // Coalesce resize work onto a single rAF. A cell drag fires the
        // ResizeObserver many times per frame; fitting synchronously inside
        // the RO callback both wastes layout passes and trips the
        // "ResizeObserver loop completed with undelivered notifications"
        // feedback — fit.fit() mutates the DOM (it resizes xterm's canvas),
        // which re-notifies the very observer that called it. Deferring the
        // fit to a rAF runs it out-of-band, at most once per frame, which is
        // the documented way to avoid that loop and is the main cure for the
        // resize flicker. Each fit only pushes a SIGWINCH when the grid
        // actually crosses a row/column boundary, so a smooth drag reflows
        // the program live, exactly like dragging a native terminal's edge.
        let rafId = 0;
        // Tracks whether the box was measurable on the previous fit. The
        // frontend hides offscreen cells with `display:none` (StackItem), which
        // keeps this component mounted but collapses the box to 0×0 and lets the
        // browser clear the GPU renderer's drawing buffer. When the cell comes
        // back the ResizeObserver fires (0 → real box) but the PTY emits no
        // output, so we must repaint the existing buffer ourselves — otherwise
        // the grid stays black until the next keystroke.
        let wasMeasurable = false;
        const scheduleFit = () => {
            if (rafId) return;
            rafId = requestAnimationFrame(() => {
                rafId = 0;
                fitAndSync(session!);
                // First fit against a real box → safe to bring up the canvas
                // renderer (it needs a real box to size its canvas).
                const r = session!.container.getBoundingClientRect();
                const measurable = r.width >= 2 && r.height >= 2;
                if (measurable) void loadRendererAddon(session!);
                // Box just became measurable again (un-hidden / un-parked):
                // force a full repaint of the buffer the renderer may have lost.
                if (measurable && !wasMeasurable) refreshTerm(session!);
                wasMeasurable = measurable;
            });
        };
        const ro = new ResizeObserver(scheduleFit);
        ro.observe(host);
        scheduleFit();

        // Focus the terminal so keypresses land directly without an
        // explicit click — matches the prior behavior. Skip if the
        // socket isn't yet open (we'll focus from the onopen handler
        // in the build path on first connect).
        if (session.status === 'open') {
            try { session.term.focus(); } catch {}
        }

        return () => {
            if (rafId) cancelAnimationFrame(rafId);
            ro.disconnect();
            session!.statusListeners.delete(statusCb);
            // DO NOT dispose the term/ws here — the whole point of
            // the cache is that the next mount re-attaches. Just
            // park the container in the graveyard so xterm keeps a
            // valid in-DOM parent (its renderer wants a layout-able
            // ancestor for cell-size measurement; an unparented div
            // returns 0×0 from getBoundingClientRect and the next
            // remount's fit.fit() would compute zero cols).
            try { getGraveyard().appendChild(session!.container); } catch {}
        };
    // attempt → forces effect re-run on Reconnect click
    }, [parsed?.session_id, parsed?.token, parsed?.ws_path, attempt]);

    if (!parsed) {
        return (
            <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#000000', color: 'var(--muted-foreground, #6b7280)', fontFamily: 'var(--font-mono, monospace)', fontSize: 12, padding: 16, textAlign: 'center' }}>
                Invalid .terminal file — expected JSON with {`{ session_id, ws_path, token }`}.
            </div>
        );
    }

    // Status pill colors pull semantic tokens where they fit and fall
    // back to fixed hexes for warn/error that don't map cleanly.
    const statusColor =
        status === 'open' ? 'var(--electric-teal, #7fcfa8)' :
        status === 'connecting' ? 'var(--filament-amber, #d4a94f)' :
        status === 'busy' ? 'var(--destructive, #e06c75)' :
        'var(--muted-foreground, #6b7280)';

    return (
        <div style={{
            width: '100%',
            height: '100%',
            display: 'flex',
            flexDirection: 'column',
            background: '#000000',
            // Box-sizing: border-box so the host's reported width is the
            // outer width — matters for cell-width fitting; without it
            // any padding/border on a parent would push the terminal
            // wider than the cell.
            boxSizing: 'border-box',
            // Hard-cap to the parent's width. The cell can ask the
            // renderer for an exact pixel size; this prevents the
            // xterm canvas from extending past the cell on a wider-than-
            // expected font fallback.
            minWidth: 0,
            overflow: 'hidden',
        }}>
            <div style={{ height: 24, background: 'var(--obsidian-plate, #1a1c23)', borderBottom: '1px solid var(--tungsten-dim, #2a2d3a)', display: 'flex', alignItems: 'center', padding: '0 8px', gap: 8, flexShrink: 0, fontFamily: 'var(--font-mono, monospace)', fontSize: 11 }}>
                <span style={{ color: 'var(--muted-foreground, #9ca3af)' }}>{parsed.label}</span>
                <span style={{ color: statusColor }}>● {status}</span>
                <div style={{ display: 'flex', alignItems: 'center', gap: 2 }} title="Terminal font size">
                    <button
                        onClick={() => changeFontSize(-1)}
                        disabled={fontSize <= FONT_SIZE_MIN}
                        title="Decrease font size"
                        style={{ ...FONT_BTN_STYLE, opacity: fontSize <= FONT_SIZE_MIN ? 0.4 : 1, cursor: fontSize <= FONT_SIZE_MIN ? 'default' : 'pointer' }}
                    >
                        A−
                    </button>
                    <span style={{ color: 'var(--muted-foreground, #9ca3af)', minWidth: 16, textAlign: 'center' }}>{fontSize}</span>
                    <button
                        onClick={() => changeFontSize(1)}
                        disabled={fontSize >= FONT_SIZE_MAX}
                        title="Increase font size"
                        style={{ ...FONT_BTN_STYLE, opacity: fontSize >= FONT_SIZE_MAX ? 0.4 : 1, cursor: fontSize >= FONT_SIZE_MAX ? 'default' : 'pointer' }}
                    >
                        A+
                    </button>
                </div>
                {actionStatus && (
                    <span style={{ color: 'var(--electric-teal, #7fcfa8)' }}>{actionStatus}</span>
                )}
                <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6 }}>
                    {parsed.buttons.map(b => {
                        const busy = pendingAction === b.id;
                        // Tinted-green CTA background mirrors the .website
                        // renderer's action buttons — color-mix keeps it
                        // readable under light themes too.
                        const ctaBg = busy
                            ? 'var(--muted, #3a3d52)'
                            : 'color-mix(in srgb, #10b981 35%, var(--void-main))';
                        return (
                            <button
                                key={b.id}
                                onClick={() => clickAction(b.id, b.label)}
                                disabled={busy || !!pendingAction}
                                style={{ height: 18, padding: '0 8px', background: ctaBg, border: '1px solid color-mix(in srgb, #10b981 60%, var(--tungsten-dim))', borderRadius: 'var(--radius-sm, 3px)', color: 'var(--signal-white, #d6f5e4)', fontFamily: 'var(--font-mono, monospace)', fontSize: 10, cursor: busy ? 'wait' : 'pointer', opacity: pendingAction && !busy ? 0.6 : 1 }}
                            >
                                {busy ? '…' : b.label}
                            </button>
                        );
                    })}
                    {(status === 'closed' || status === 'busy' || status === 'ended') && (
                        <button
                            onClick={() => setAttempt(a => a + 1)}
                            style={{ height: 18, padding: '0 8px', background: 'var(--muted, #2d2f3e)', border: '1px solid var(--tungsten-dim, #3a3d52)', borderRadius: 'var(--radius-sm, 3px)', color: 'var(--signal-white, #e2e8f0)', fontFamily: 'var(--font-mono, monospace)', fontSize: 10, cursor: 'pointer' }}
                        >
                            Reconnect
                        </button>
                    )}
                </div>
            </div>
            <div
                ref={hostRef}
                style={{
                    flex: 1,
                    // No padding here — xterm wants the full container
                    // box for accurate cell-size measurement, and the
                    // padding was eating ~1 column off the right side
                    // at narrow cell widths.
                    overflow: 'hidden',
                    minWidth: 0,
                    minHeight: 0,
                    display: status === 'ended' ? 'flex' : undefined,
                    alignItems: status === 'ended' ? 'center' : undefined,
                    justifyContent: status === 'ended' ? 'center' : undefined,
                }}
            >
                {status === 'ended' && (
                    <span style={{ color: 'var(--muted-foreground, #6b7280)', fontFamily: 'var(--font-mono, monospace)', fontSize: 12, padding: 16, textAlign: 'center' }}>
                        Terminal session ended — run the cell again to start a new one.
                    </span>
                )}
            </div>
        </div>
    );
}

export default defineRenderer({ component: TerminalViewer });
