import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';
import { apiOrigin, openSessionSocket } from '/api/sdk/session.js';

type ArtifactAction = {
    id: string;
    label: string;
};

type Artifact = {
    url?: string;
    proxyBase?: string;
    /** Visual transport the generator streams: "image" (default) is
     *  CDP screencast JPEG frames painted into an <img>, with input
     *  forwarded over the WS; "live" runs the real page natively in a
     *  reverse-proxied iframe (no screencast, no input forwarding). */
    renderMode?: 'image' | 'live';
    /** Live mode only: this cell's subdomain token. The live iframe loads from
     *  `<scheme>//<liveToken>.<apphost>/` — its own clean origin, which the
     *  daemon's reverse proxy serves the target page on. Absent → fall back to
     *  the per-cell proxy path (single-cell / pre-subdomain hosts). */
    liveToken?: string;
    viewport?: { width?: number; height?: number };
    /** Renderer-side action buttons. Each click fires
     *  `api.emitAction(id)` which the generator picks up via
     *  `gen.wait_for_action()`. Empty/absent → no buttons. */
    actions?: ArtifactAction[];
    /** When true, the session can pop the hidden browser into a real
     *  desktop window (for clearing a bot challenge headless loops on)
     *  via `kind:"window"` WS messages — show the Open/Hide control. */
    window?: boolean;
};

function parse(raw: string): Artifact {
    const s = (raw || '').trim();
    if (!s) return {};
    try { return JSON.parse(s) as Artifact; } catch { return {}; }
}

function wsUrlFromProxyBase(api: unknown, proxyBase: string): string {
    // proxyBase is host-relative (`/proxy/<ch>/<run>/<port>/`). Resolve
    // against the API origin (split-origin aware — /proxy is served by the
    // backend, not necessarily the frontend origin) and swap http(s) → ws(s).
    // The control channel lives under the reserved /__collimate/ prefix so it
    // never collides with a proxied site's own paths on the live subdomain.
    const abs = new URL(proxyBase + '__collimate/ws', apiOrigin(api));
    abs.protocol = abs.protocol === 'https:' ? 'wss:' : 'ws:';
    return abs.toString();
}

type Status =
    | { kind: 'idle' }
    | { kind: 'connecting' }
    | { kind: 'live' }
    | { kind: 'closed'; reason: string };

// A focused <input>/<textarea> in the captured page, reported by the daemon so
// the renderer can float a local input over it for instant typing echo.
// Geometry is in page CSS pixels (the screencast's native vw×vh space).
type FocusField = {
    multiline: boolean;
    value: string;
    rect: { x: number; y: number; w: number; h: number } | null;
    fontSize: string; fontFamily: string; lineHeight: string; color: string;
    bg: string;
    padTop: string; padLeft: string; padRight: string; padBottom: string;
    textAlign: string; dir: string;
    selStart: number; selEnd: number;
};

function WebView() {
    const { content, api } = useCollimateFile();
    const artifact = useMemo<Artifact>(() => parse(content), [content]);
    const imgRef = useRef<HTMLImageElement | null>(null);
    // Live mode: the iframe embeds the cell's subdomain, where the daemon's
    // reverse proxy serves the real target page. A nav bridge the daemon injects
    // into the page reports the current URL up and takes back/forward/reload
    // down, over the same postMessage protocol (collimateLive url/ready up;
    // collimateLiveNav down).
    const liveIframeRef = useRef<HTMLIFrameElement | null>(null);
    const fitRef = useRef<HTMLDivElement | null>(null);
    const overlayRef = useRef<HTMLDivElement | null>(null);
    const sockRef = useRef<any>(null);  // SessionSocket from /api/sdk/session.js
    // Image-mode clipboard + typing-echo support. The captured page's OS
    // clipboard isn't the user's, so the daemon bridges copied text here, and
    // we mirror the live page selection so Ctrl+C works on a plain drag-select.
    const selectionCacheRef = useRef('');
    // The focused editable field in the captured page (geometry + value),
    // pushed by the daemon; drives the local typing-echo overlay below.
    const [focusField, setFocusField] = useState<FocusField | null>(null);
    const typeOverlayRef = useRef<HTMLTextAreaElement | null>(null);
    const lastTypeEditRef = useRef(0);
    // Transient "popup blocked" notice (image mode blocks new pages so they
    // don't steal the foreground and freeze the screencast).
    const [blockedNote, setBlockedNote] = useState<string | null>(null);
    const blockedTimerRef = useRef<number | undefined>(undefined);

    // Keep the typing-echo overlay in sync with the captured field. On (re)focus
    // seed it from the page value + caret and focus it. While the user is
    // actively typing, local echo leads and the page mirrors via forwarded keys
    // — only reconcile to the page's value once they pause (catches Tab/submit/
    // page-side edits) so a scroll/position push never clobbers mid-keystroke.
    useEffect(() => {
        const ta = typeOverlayRef.current;
        if (!ta || !focusField) return;
        const recentlyTyped = Date.now() - lastTypeEditRef.current < 300;
        if (document.activeElement !== ta) {
            ta.value = focusField.value;
            ta.focus({ preventScroll: true });
            try { ta.setSelectionRange(focusField.selStart, focusField.selEnd); } catch { /* ignore */ }
        } else if (!recentlyTyped && ta.value !== focusField.value) {
            const pos = focusField.selEnd;
            ta.value = focusField.value;
            try { ta.setSelectionRange(pos, pos); } catch { /* ignore */ }
        }
    }, [focusField]);
    // Which surface paints the page: screencast <img> or DOM-mirror
    // <iframe>. Seeded by the artifact, confirmed by the WS init
    // message (authoritative — the artifact can lag a generator edit).
    const [mode, setMode] = useState<'image' | 'live'>(
        () => (artifact.renderMode === 'live' ? 'live' : 'image'));
    // Read inside event/WS callbacks captured at mount so they branch on the
    // current transport without re-binding.
    const modeRef = useRef(mode);
    useEffect(() => { modeRef.current = mode; }, [mode]);
    const [status, setStatus] = useState<Status>({ kind: 'idle' });
    const [busyAction, setBusyAction] = useState<string | null>(null);
    // Tracks whether the generator is running the browser as a real
    // desktop window (true) or hidden/headless (false). Driven by the
    // server's init + `kind:"window"` messages.
    const [windowOpen, setWindowOpen] = useState(false);
    const [scale, setScale] = useState(1);
    // vw/vh start from the artifact's recorded viewport, then get
    // overwritten by the WS init/viewport messages so live page
    // resizes propagate without an artifact rewrite.
    const [vw, setVw] = useState<number>(() => artifact.viewport?.width || 1280);
    const [vh, setVh] = useState<number>(() => artifact.viewport?.height || 800);
    // Address bar: `urlInput` is the local edit buffer, live URL pushes
    // (init / link clicks / redirects) only overwrite it while the user
    // isn't mid-edit in the field.
    const [urlInput, setUrlInput] = useState<string>(() => artifact.url || '');
    const editingUrlRef = useRef(false);
    const liveUrlRef = useRef(artifact.url || '');
    // The live iframe's src (the subdomain nav bootstrap for the initial
    // target). Set once when we first have a base; link clicks inside the page
    // navigate natively without changing this, so the iframe isn't reloaded.
    const [liveSrc, setLiveSrc] = useState('');
    const postToLive = (msg: Record<string, unknown>) => {
        const w = liveIframeRef.current?.contentWindow;
        if (w) { try { w.postMessage(msg, '*'); } catch { /* gone */ } }
    };
    // Origin the live page is served from: this cell's subdomain (a clean
    // origin the reverse proxy serves the target page on), else the per-cell
    // proxy path as a fallback.
    const liveBaseUrl = (): string => {
        const token = (artifact.liveToken || '').trim();
        return token
            ? `${window.location.protocol}//${token}.${window.location.host}/`
            : (artifact.proxyBase || '').trim();
    };
    // The nav bootstrap: it sets the proxy's target origin and 302s to its path,
    // so the iframe then renders the real page from the subdomain root.
    const liveSrcFor = (target: string): string =>
        liveBaseUrl() + '__collimate/go?url=' + encodeURIComponent(
            /^[a-z][a-z0-9+.-]*:/i.test(target) ? target : 'https://' + target);

    // Refs mirror state so event handlers (captured once at mount) can
    // read the current scale without re-binding on every render.
    const scaleRef = useRef(scale);
    useEffect(() => { scaleRef.current = scale; }, [scale]);

    // The artifact can arrive after first render (content streams in) —
    // follow its renderMode until the WS init confirms.
    useEffect(() => {
        if (artifact.renderMode === 'live' || artifact.renderMode === 'image') {
            setMode(artifact.renderMode);
        }
    }, [artifact.renderMode]);

    // Live mode: point the iframe at the cell's subdomain nav bootstrap, where
    // the daemon's reverse proxy serves the target page from its OWN clean
    // origin (<token>.<apphost>); otherwise fall back to the per-cell proxy
    // path. Set the initial src here; address-bar navigation and Reload re-point
    // the src (a fresh load — reliable, and it re-reads the session so it picks
    // up a login done via Open-window). Link clicks INSIDE the page stay native.
    useEffect(() => {
        if (mode !== 'live') { setLiveSrc(''); return; }
        if (!liveBaseUrl()) return;
        setLiveSrc(liveSrcFor((artifact.url || '').trim() || 'about:blank'));
        setStatus({ kind: 'connecting' });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [mode, artifact.proxyBase, artifact.liveToken]);

    // Messages from the page's nav bridge: url (→ address bar + capture sync),
    // ready (→ status dot).
    useEffect(() => {
        if (mode !== 'live') return;
        const onMessage = (e: MessageEvent) => {
            const d: any = e.data || {};
            if (d.collimateLive === 'url' && typeof d.url === 'string') {
                liveUrlRef.current = d.url;
                if (!editingUrlRef.current) setUrlInput(d.url);
                // Keep the headless browser on the same page for the capture
                // scraper (best-effort; sendJson is OPEN-guarded).
                sockRef.current?.sendJson({ kind: 'nav', action: 'go', url: d.url });
            } else if (d.collimateLive === 'ready') {
                setStatus({ kind: 'live' });
            } else if (d.collimateLive === 'error') {
                setStatus({ kind: 'closed', reason: 'live proxy failed to start' });
            }
        };
        window.addEventListener('message', onMessage);
        return () => window.removeEventListener('message', onMessage);
    }, [mode]);

    const sendInput = (msg: Record<string, unknown>) => {
        sockRef.current?.sendJson(msg);
    };

    // Translate the overlay's screen-space coords into page coords.
    // Overlay sits on the scaled wrapper (vw*scale × vh*scale), so
    // dividing by scale recovers the pre-transform position the
    // live page actually responds to.
    const toPageCoords = (clientX: number, clientY: number): { x: number; y: number } => {
        const rect = overlayRef.current?.getBoundingClientRect();
        const s = scaleRef.current || 1;
        if (!rect) return { x: 0, y: 0 };
        return {
            x: Math.max(0, (clientX - rect.left) / s),
            y: Math.max(0, (clientY - rect.top) / s),
        };
    };

    const fireAction = async (actionId: string) => {
        if (!api?.emitAction || busyAction) return;
        setBusyAction(actionId);
        try {
            await api.emitAction(actionId);
        } finally {
            // Reset shortly after — the generator's response shows up
            // as a sibling cell, not by mutating this artifact. A 1s
            // hold is enough to debounce double-clicks without making
            // the button feel sticky.
            setTimeout(() => setBusyAction(null), 1000);
        }
    };

    useEffect(() => {
        const proxyBase = (artifact.proxyBase || '').trim();
        if (!proxyBase) return;

        // Paint a base64 JPEG into the img element. Setting `src`
        // hands the bytes to the browser's image decode pipeline,
        // which double-buffers under the hood — the previous frame
        // stays visible until the new one is ready, so swaps don't
        // flicker.
        const paintFrame = (b64: string) => {
            const el = imgRef.current;
            if (!el) return;
            el.src = `data:image/jpeg;base64,${b64}`;
        };

        const pushUrl = (u: string) => {
            liveUrlRef.current = u;
            if (!editingUrlRef.current) setUrlInput(u);
        };

        // The proxy rejects the WS handshake once this run has stopped (or its
        // freed port was reused by another run) — there is no close-code
        // contract on this channel, so "the run is gone" is detected by
        // repeated failures to OPEN (maxFailedOpens) rather than by 4404. The
        // daemon keeps its WS server up across CDP reattaches, so a live run's
        // socket stays open; retry transient closes on a fixed short delay.
        const sock = openSessionSocket({
            url: wsUrlFromProxyBase(api, proxyBase),
            transientRetryMs: 1500,
            maxFailedOpens: 5,
            onStatus: (st: string) => {
                if (st === 'open') setStatus({ kind: 'live' });
                else if (st === 'connecting') setStatus({ kind: 'connecting' });
                else if (st === 'ended') setStatus({ kind: 'closed', reason: 'session ended' });
                else setStatus({ kind: 'closed', reason: 'disconnected — retrying' });
            },
            onMessage: (msg: MessageEvent) => {
                let payload: any;
                try { payload = JSON.parse(msg.data); }
                catch { return; }
                if (payload.kind === 'init') {
                    // Server's authoritative render mode + viewport —
                    // win over the snapshot baked into the artifact,
                    // which can be stale after a live resize.
                    if (payload.mode === 'live' || payload.mode === 'image') {
                        setMode(payload.mode);
                    }
                    if (payload.viewport
                            && typeof payload.viewport.width === 'number'
                            && typeof payload.viewport.height === 'number') {
                        setVw(payload.viewport.width);
                        setVh(payload.viewport.height);
                    }
                    // In live mode the iframe drives its own URL (via the nav
                    // bridge) — don't let the daemon's headless URL override.
                    if (typeof payload.url === 'string' && payload.url
                            && modeRef.current !== 'live') {
                        pushUrl(payload.url);
                    }
                    if (typeof payload.headful === 'boolean') {
                        setWindowOpen(payload.headful);
                    }
                    // Cached last frame (image mode) — skips the blank flash
                    // before the next paint arrives.
                    if (typeof payload.frame === 'string' && payload.frame) {
                        paintFrame(payload.frame);
                    }
                } else if (payload.kind === 'window' && typeof payload.headful === 'boolean') {
                    setWindowOpen(payload.headful);
                } else if (payload.kind === 'frame' && typeof payload.data === 'string') {
                    paintFrame(payload.data);
                } else if (payload.kind === 'viewport'
                        && typeof payload.width === 'number'
                        && typeof payload.height === 'number') {
                    setVw(payload.width);
                    setVh(payload.height);
                } else if (payload.kind === 'url' && typeof payload.url === 'string'
                        && modeRef.current !== 'live') {
                    pushUrl(payload.url);
                } else if (payload.kind === 'clipboard' && typeof payload.text === 'string') {
                    // The captured page copied something (Ctrl+C handler / copy
                    // button) — mirror it into the user's real clipboard. The
                    // click/keypress that triggered it still grants transient
                    // activation, so writeText is allowed.
                    if (payload.text) navigator.clipboard?.writeText(payload.text).catch(() => {});
                } else if (payload.kind === 'selection' && typeof payload.text === 'string') {
                    selectionCacheRef.current = payload.text;
                } else if (payload.kind === 'focus') {
                    const info = payload.info;
                    setFocusField(info && info.rect ? (info as FocusField) : null);
                } else if (payload.kind === 'cursor' && typeof payload.cursor === 'string') {
                    // Mirror the page's cursor onto the capture layer for instant
                    // shape feedback. Custom (url()) cursors can't load cross-
                    // origin, so fall back to the default arrow.
                    let c = payload.cursor;
                    if (!c || c === 'auto' || c.indexOf('url(') !== -1) c = 'default';
                    if (overlayRef.current) overlayRef.current.style.cursor = c;
                } else if (payload.kind === 'blocked') {
                    const u = typeof payload.url === 'string' ? payload.url : '';
                    setBlockedNote(u ? `Popup blocked: ${u}` : 'Popup blocked');
                    if (blockedTimerRef.current) clearTimeout(blockedTimerRef.current);
                    blockedTimerRef.current = window.setTimeout(() => setBlockedNote(null), 4000);
                }
            },
        });
        sockRef.current = sock;

        return () => {
            sockRef.current = null;
            sock.close();
        };
    }, [artifact.proxyBase]);

    // Fit the live viewport (vw × vh) into whatever space the cell
    // gives us, and ALSO ask the generator to resize the browser
    // viewport so the page itself re-flows to the new cell aspect
    // (instead of just letterboxing). The debounce avoids hammering
    // the browser with viewport overrides on every drag-resize frame.
    //
    // NB: this hook MUST run on every render — keep it before the
    // proxyBase early-return below so React's hook order stays stable
    // across the "no artifact yet" → "artifact arrived" transition.
    useLayoutEffect(() => {
        const el = fitRef.current;
        if (!el) return;
        let sendTimer: number | null = null;
        let lastSent: { w: number; h: number; dpr: number } | null = null;
        const measure = () => {
            const cw = el.clientWidth;
            const ch = el.clientHeight;
            if (cw === 0 || ch === 0) return;
            const s = Math.min(cw / vw, ch / vh);
            if (s > 0 && Number.isFinite(s)) setScale(s);

            // Live mode runs the page natively in a self-sizing iframe — there's
            // no screencast to re-letterbox, so skip the viewport override.
            if (modeRef.current === 'live') return;

            const targetW = Math.round(cw);
            const targetH = Math.round(ch);
            // Report the display's pixel density so the generator
            // renders at physical resolution (deviceScaleFactor) —
            // otherwise HiDPI screens upscale a 1x frame and text
            // goes soft.
            const dpr = window.devicePixelRatio || 1;
            if (sendTimer !== null) window.clearTimeout(sendTimer);
            sendTimer = window.setTimeout(() => {
                if (lastSent && lastSent.w === targetW && lastSent.h === targetH
                        && lastSent.dpr === dpr) return;
                lastSent = { w: targetW, h: targetH, dpr };
                sendInput({ kind: 'viewport', width: targetW, height: targetH, dpr });
            }, 250);
        };
        measure();
        const ro = new ResizeObserver(measure);
        ro.observe(el);
        return () => {
            ro.disconnect();
            if (sendTimer !== null) window.clearTimeout(sendTimer);
        };
    }, [vw, vh]);

    // Same hook-order constraint as above — keep this useRef before the
    // early return so React's hook tally is stable across mounts.
    const pointerMoveSentAtRef = useRef(0);

    const statusColor =
        status.kind === 'live' ? 'var(--electric-teal, #7fcfa8)' :
        status.kind === 'closed' ? 'var(--destructive, #ef4444)' :
        'var(--muted-foreground, #9ca3af)';

    if (!artifact.proxyBase) {
        return (
            <div style={{
                width: '100%', height: '100%', display: 'flex',
                alignItems: 'center', justifyContent: 'center',
                background: 'var(--void-main, #0a0b0d)',
                color: 'var(--muted-foreground, #6b7280)',
                fontFamily: 'var(--font-mono, monospace)', fontSize: 13,
                padding: 24, textAlign: 'center',
            }}>
                Waiting for the Website Live generator to publish a session…
            </div>
        );
    }

    // ---- Address bar -----------------------------------------------
    const navigate = (action: 'back' | 'forward' | 'reload') => {
        if (modeRef.current === 'live') {
            // Reload re-loads the whole iframe via the nav bootstrap (re-reads
            // the session, so it picks up an Open-window login). back/forward
            // ride postMessage into the page's history through the nav bridge.
            if (action === 'reload') {
                const el = liveIframeRef.current;
                if (el) el.src = el.src;  // eslint-disable-line no-self-assign
            } else {
                postToLive({ collimateLiveNav: action });
            }
            return;
        }
        sendInput({ kind: 'nav', action });
    };
    const commitUrl = () => {
        const u = urlInput.trim();
        if (u) {
            // Live mode: re-point the iframe at the nav bootstrap with the new
            // target (a reliable fresh load) rather than an in-frame navigation.
            if (modeRef.current === 'live') setLiveSrc(liveSrcFor(u));
            else sendInput({ kind: 'nav', action: 'go', url: u });
        }
        editingUrlRef.current = false;
    };
    // Pop the hidden browser into a real desktop window (or hide it
    // again). Optimistically flip local state so the button reacts
    // instantly; the server echoes a `window` message that confirms it.
    const toggleWindow = () => {
        const next = !windowOpen;
        setWindowOpen(next);
        sendInput({ kind: 'window', action: next ? 'open' : 'hide' });
    };

    const navBtnStyle: React.CSSProperties = {
        width: 24, height: 20, padding: 0, flexShrink: 0,
        background: 'transparent',
        border: '1px solid var(--tungsten-dim, #2a2d3a)',
        borderRadius: 3,
        color: 'var(--signal-white, #e2e8f0)',
        fontFamily: 'var(--font-mono, monospace)', fontSize: 11,
        lineHeight: '18px', cursor: 'pointer',
    };

    // ---- Input forwarding ------------------------------------------
    // The overlay sits above the screencast image and captures pointer
    // / wheel / key events, ships them over the same WS into the live
    // page via CDP Input.dispatch* commands. Coordinates are translated
    // back to page-space by dividing by the fit-scale.
    const buttonName = (b: number): string =>
        b === 1 ? 'middle' : b === 2 ? 'right' : 'left';

    const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
        // Throttle to ~60fps so a drag doesn't flood the WS — the
        // generator serializes input dispatches and would back up
        // otherwise.
        const now = performance.now();
        if (now - pointerMoveSentAtRef.current < 16) return;
        pointerMoveSentAtRef.current = now;
        const { x, y } = toPageCoords(e.clientX, e.clientY);
        sendInput({ kind: 'pointer', type: 'move', x, y });
    };
    const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
        // Grab focus so subsequent keydowns land on the overlay rather
        // than escaping to the cell shell.
        overlayRef.current?.focus({ preventScroll: true });
        const { x, y } = toPageCoords(e.clientX, e.clientY);
        sendInput({ kind: 'pointer', type: 'down', x, y, button: buttonName(e.button) });
    };
    const onPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
        const { x, y } = toPageCoords(e.clientX, e.clientY);
        sendInput({ kind: 'pointer', type: 'up', x, y, button: buttonName(e.button) });
    };
    const onContextMenu = (e: React.MouseEvent<HTMLDivElement>) => {
        // Swallow the host context menu — the right-click already went
        // through onPointerDown/Up, so the browser menu would just
        // obscure the page response.
        e.preventDefault();
    };
    const onWheel = (e: React.WheelEvent<HTMLDivElement>) => {
        const { x, y } = toPageCoords(e.clientX, e.clientY);
        sendInput({ kind: 'wheel', x, y, deltaX: e.deltaX, deltaY: e.deltaY });
    };
    // Cmd/Ctrl+C/X/V bridge for image mode — the captured page's OS clipboard
    // isn't the user's. Copy/cut mirror the live page selection into the real
    // clipboard (cut also deletes it in the page); paste reads the real
    // clipboard and forwards it as text. Returns true when handled (swallow it).
    const handleClipboardKey = (e: React.KeyboardEvent): boolean => {
        if (!(e.metaKey || e.ctrlKey) || e.altKey) return false;
        const k = e.key.toLowerCase();
        if (k === 'c' || k === 'x') {
            const text = selectionCacheRef.current;
            if (text) navigator.clipboard?.writeText(text).catch(() => {});
            if (k === 'x' && text) {
                sendInput({ kind: 'key', type: 'down', key: 'Delete' });
                sendInput({ kind: 'key', type: 'up', key: 'Delete' });
            }
            e.preventDefault(); e.stopPropagation();
            return true;
        }
        if (k === 'v') {
            e.preventDefault(); e.stopPropagation();
            navigator.clipboard?.readText().then((text) => {
                if (text) sendInput({ kind: 'paste', text });
            }).catch(() => {});
            return true;
        }
        return false;
    };

    // CDP modifier mask for a key event: Alt=1, Ctrl=2, Meta=4, Shift=8.
    const modBits = (e: React.KeyboardEvent): number =>
        (e.altKey ? 1 : 0) | (e.ctrlKey ? 2 : 0) | (e.metaKey ? 4 : 0) | (e.shiftKey ? 8 : 0);

    // Forward every key (incl. Ctrl/Cmd combos) to the page with its modifier
    // mask — so Ctrl+A select-all, Ctrl+Z undo, Ctrl+←/Backspace word-ops all
    // work like a real browser tab. C/X/V are intercepted for the clipboard
    // bridge first; preventDefault keeps the host from also acting on the combo.
    const onKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
        if (handleClipboardKey(e)) return;
        e.preventDefault();
        sendInput({ kind: 'key', type: 'down', key: e.key, mods: modBits(e) });
    };
    const onKeyUp = (e: React.KeyboardEvent<HTMLDivElement>) => {
        e.preventDefault();
        sendInput({ kind: 'key', type: 'up', key: e.key, mods: modBits(e) });
    };

    // --- typing-echo overlay handlers ---
    // The overlay <textarea> echoes locally (instant) while forwarding the same
    // keystrokes to the captured page, so typing has no round-trip lag.
    const onOverlayKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        lastTypeEditRef.current = Date.now();
        const combo = e.metaKey || e.ctrlKey;
        const k = e.key.length === 1 ? e.key.toLowerCase() : '';
        // The overlay is a real textarea with native clipboard, so let it copy
        // (C) and paste (V; onOverlayPaste forwards the text to the page). Every
        // other key — incl. Ctrl+A select-all, Ctrl+Z undo, Ctrl+X cut — is
        // forwarded so the page field mirrors, while the textarea also performs
        // it locally for instant echo.
        if (combo && (k === 'c' || k === 'v')) return;
        sendInput({ kind: 'key', type: 'down', key: e.key, mods: modBits(e) });
        // Plain Enter submits in the page; don't add a local newline. Shift+Enter
        // keeps inserting one for multiline fields.
        if (e.key === 'Enter' && !e.shiftKey) e.preventDefault();
    };
    const onOverlayKeyUp = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        const combo = e.metaKey || e.ctrlKey;
        const k = e.key.length === 1 ? e.key.toLowerCase() : '';
        if (combo && (k === 'c' || k === 'v')) return;
        sendInput({ kind: 'key', type: 'up', key: e.key, mods: modBits(e) });
    };
    const onOverlayPaste = (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
        const text = e.clipboardData?.getData('text/plain') || '';
        if (text) { lastTypeEditRef.current = Date.now(); sendInput({ kind: 'paste', text }); }
    };

    return (
        <div style={{
            width: '100%', height: '100%', display: 'flex',
            flexDirection: 'column', background: 'var(--void-main, #0a0b0d)',
            position: 'relative',
        }}>
            {blockedNote && (
                <div style={{
                    position: 'absolute', bottom: 10, left: '50%',
                    transform: 'translateX(-50%)', zIndex: 20,
                    maxWidth: '90%', padding: '6px 12px',
                    background: 'rgba(20,22,28,0.95)',
                    border: '1px solid var(--tungsten-dim, #2a2d3a)',
                    borderRadius: 6, color: 'var(--signal-white, #e2e8f0)',
                    font: '12px var(--font-mono, monospace)',
                    whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                    pointerEvents: 'none', boxShadow: '0 2px 10px rgba(0,0,0,0.4)',
                }} title={blockedNote}>
                    🚫 {blockedNote}
                </div>
            )}
            <div style={{
                height: 32, flexShrink: 0,
                background: 'var(--obsidian-plate, #1a1c23)',
                borderBottom: '1px solid var(--tungsten-dim, #2a2d3a)',
                display: 'flex', alignItems: 'center', padding: '0 8px',
                gap: 6, fontFamily: 'var(--font-mono, monospace)', fontSize: 11,
                color: 'var(--signal-white, #e2e8f0)',
            }}>
                <span style={{
                    width: 8, height: 8, borderRadius: '50%',
                    background: statusColor, flexShrink: 0,
                }} title={status.kind === 'closed' ? status.reason : status.kind} />
                <button style={navBtnStyle} title="Back"
                        onClick={() => navigate('back')}>←</button>
                <button style={navBtnStyle} title="Forward"
                        onClick={() => navigate('forward')}>→</button>
                <button style={navBtnStyle} title="Reload"
                        onClick={() => navigate('reload')}>⟳</button>
                <input
                    type="text"
                    value={urlInput}
                    spellCheck={false}
                    placeholder="https://…"
                    onChange={(e) => setUrlInput(e.target.value)}
                    onFocus={(e) => {
                        editingUrlRef.current = true;
                        e.target.select();
                    }}
                    onBlur={() => {
                        // Abandoned edit — snap back to the page's real URL.
                        editingUrlRef.current = false;
                        setUrlInput(liveUrlRef.current);
                    }}
                    onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                            commitUrl();
                            (e.target as HTMLInputElement).blur();
                        } else if (e.key === 'Escape') {
                            (e.target as HTMLInputElement).blur();
                        }
                        // Keep address-bar keystrokes out of the page
                        // overlay's forwarding handlers.
                        e.stopPropagation();
                    }}
                    style={{
                        flex: 1, height: 20, minWidth: 60,
                        background: 'var(--void-main, #0d0f14)',
                        border: '1px solid var(--tungsten-dim, #2a2d3a)',
                        borderRadius: 3, padding: '0 8px',
                        color: 'var(--signal-white, #e2e8f0)',
                        fontFamily: 'var(--font-mono, monospace)', fontSize: 11,
                        outline: 'none',
                    }}
                />
                {artifact.window && (
                    <button
                        onClick={toggleWindow}
                        title={windowOpen
                            ? 'Hide the desktop browser window (return to streaming only)'
                            : 'Open a real browser window to solve a sign-in / Cloudflare challenge'}
                        style={{
                            flexShrink: 0,
                            padding: '2px 10px',
                            background: windowOpen
                                ? 'var(--electric-teal, #63B0A6)'
                                : 'transparent',
                            color: windowOpen
                                ? 'var(--void-main, #0a0b0d)'
                                : 'var(--signal-white, #e2e8f0)',
                            border: windowOpen
                                ? 'none'
                                : '1px solid var(--tungsten-dim, #2a2d3a)',
                            borderRadius: 3,
                            fontFamily: 'var(--font-mono, monospace)',
                            fontSize: 11,
                            cursor: 'pointer',
                            whiteSpace: 'nowrap',
                        }}
                    >
                        {windowOpen ? 'Hide window' : 'Open window'}
                    </button>
                )}
                {(artifact.actions || []).map((act) => (
                    <button
                        key={act.id}
                        onClick={() => fireAction(act.id)}
                        disabled={busyAction === act.id}
                        style={{
                            flexShrink: 0,
                            padding: '2px 10px',
                            background: 'var(--filament-amber, #d4a23c)',
                            color: 'var(--void-main, #0a0b0d)',
                            border: 'none',
                            borderRadius: 3,
                            fontFamily: 'var(--font-mono, monospace)',
                            fontSize: 11,
                            cursor: busyAction === act.id ? 'wait' : 'pointer',
                            opacity: busyAction === act.id ? 0.6 : 1,
                        }}
                    >
                        {busyAction === act.id ? '…' : act.label}
                    </button>
                ))}
            </div>
            <div
                ref={fitRef}
                style={{
                    flex: 1, minHeight: 0, overflow: 'hidden',
                    // Letterbox bars during cell resizes (before the
                    // page reflows to the new aspect) follow the host
                    // scheme: --renderer-surface flips dark/light with
                    // the theme, so dark mode never flashes white.
                    background: 'var(--renderer-surface, #1a1a1a)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}
            >
                {mode === 'live' ? (
                    // Live mode: embed the cell's subdomain, where the daemon's
                    // reverse proxy serves the real target page. It's the real
                    // page, so pointer / keyboard / scroll are native — no scaling,
                    // no input-capture overlay. Blank until liveSrc is set.
                    liveSrc ? (
                        <iframe
                            ref={liveIframeRef}
                            title="Live page"
                            src={liveSrc}
                            style={{
                                width: '100%', height: '100%',
                                border: 'none', background: '#fff', display: 'block',
                            }}
                        />
                    ) : <div style={{ width: '100%', height: '100%' }} />
                ) : (
                    // Image mode: the screencast frame sized at the page's native
                    // vw × vh and CSS-scaled to fit, with an input-capture overlay
                    // forwarding events to the live browser over the WS. The
                    // scaled-size wrapper lets flexbox center the visible area
                    // rather than the un-transformed native-size box.
                    <div style={{
                        width: vw * scale, height: vh * scale,
                        position: 'relative', flexShrink: 0,
                    }}>
                        <img
                            ref={imgRef}
                            alt=""
                            draggable={false}
                            style={{
                                width: vw, height: vh,
                                position: 'absolute', top: 0, left: 0,
                                transform: `scale(${scale})`,
                                transformOrigin: 'top left',
                                // Crisp scaling keeps text legible when the
                                // cell is enlarged past the captured frame's
                                // native pixel density.
                                imageRendering: 'auto',
                                // Suppress the broken-image icon flash during
                                // the brief window before the first frame.
                                background: 'var(--renderer-surface, #1a1a1a)',
                                userSelect: 'none',
                                pointerEvents: 'none',
                            }}
                        />
                        {/* Input-capture layer. Sits above the screencast img
                            so clicks / wheel / keys flow through the WS to the
                            live page instead of just landing on the (non-
                            interactive) image element. tabIndex makes it
                            focusable so keydowns dispatch here. */}
                        <div
                            ref={overlayRef}
                            tabIndex={0}
                            // Marks this element as a keyboard sink so the host
                            // app's global shortcut handler steps aside (it
                            // checks the event's composedPath for this flag) and
                            // lets keystrokes reach onKeyDown instead of eating
                            // them as cell-navigation shortcuts. Without it,
                            // focus on a plain <div> reads as "not an editor".
                            data-capture-keys="true"
                            onPointerMove={onPointerMove}
                            onPointerDown={onPointerDown}
                            onPointerUp={onPointerUp}
                            onContextMenu={onContextMenu}
                            onWheel={onWheel}
                            onKeyDown={onKeyDown}
                            onKeyUp={onKeyUp}
                            style={{
                                position: 'absolute', inset: 0,
                                background: 'transparent',
                                cursor: 'default',
                                outline: 'none',
                                // Prevent the browser's pinch-zoom / pan
                                // gestures from hijacking pointer events
                                // before we get them.
                                touchAction: 'none',
                                userSelect: 'none',
                            }}
                        />
                        {/* Typing-echo overlay: a local textarea floated exactly
                            over the captured page's focused field. The user types
                            into it (instant, no round-trip), and the keystrokes
                            are forwarded to the real page so it stays in sync. It
                            sits above the capture layer and is opaque (field's
                            effective background) so it cleanly covers the lagging
                            screencast underneath. */}
                        {focusField && focusField.rect
                            && focusField.rect.w > 1 && focusField.rect.h > 1
                            && (() => {
                                const f = focusField;
                                const r = f.rect!;
                                const pv = (s: string, fb = 0) => {
                                    const n = parseFloat(s);
                                    return (isNaN(n) ? fb : n) * scale;
                                };
                                return (
                                    <textarea
                                        ref={typeOverlayRef}
                                        spellCheck={false}
                                        dir={(f.dir as any) || 'ltr'}
                                        onKeyDown={onOverlayKeyDown}
                                        onKeyUp={onOverlayKeyUp}
                                        onPaste={onOverlayPaste}
                                        onContextMenu={(e) => e.preventDefault()}
                                        onPointerMove={onPointerMove}
                                        onPointerUp={onPointerUp}
                                        onPointerDown={(e) => {
                                            // Position the page's caret where the
                                            // user clicked (the textarea sets its
                                            // own caret natively) — keep both in
                                            // sync without stealing focus.
                                            const { x, y } = toPageCoords(e.clientX, e.clientY);
                                            sendInput({ kind: 'pointer', type: 'down', x, y, button: buttonName(e.button) });
                                        }}
                                        style={{
                                            position: 'absolute',
                                            left: Math.max(0, r.x * scale),
                                            top: Math.max(0, r.y * scale),
                                            width: r.w * scale, height: r.h * scale,
                                            margin: 0, border: 'none', outline: 'none',
                                            resize: 'none', overflow: 'hidden',
                                            boxSizing: 'border-box',
                                            background: f.bg || '#fff', color: f.color || '#000',
                                            fontSize: pv(f.fontSize, 16),
                                            fontFamily: f.fontFamily || 'inherit',
                                            lineHeight: f.multiline
                                                ? (parseFloat(f.lineHeight) ? `${pv(f.lineHeight)}px` : 'normal')
                                                : `${Math.max(1, r.h * scale - pv(f.padTop) - pv(f.padBottom))}px`,
                                            paddingTop: pv(f.padTop), paddingLeft: pv(f.padLeft),
                                            paddingRight: pv(f.padRight), paddingBottom: pv(f.padBottom),
                                            textAlign: (f.textAlign as any) || 'start',
                                            whiteSpace: f.multiline ? 'pre-wrap' : 'pre',
                                            zIndex: 5,
                                        }}
                                    />
                                );
                            })()}
                    </div>
                )}
            </div>
        </div>
    );
}

export default defineRenderer({ component: WebView });
