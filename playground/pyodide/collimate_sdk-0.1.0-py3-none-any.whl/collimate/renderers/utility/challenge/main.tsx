import React, { useState, useEffect, useMemo, useCallback } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile, useDebouncedSaveContent } from '/api/sdk/react.js';

const FORMAT = 'collimate.challenge-report';

const OUTCOME_META = {
  failed: { badge: '✗', label: 'FAILED', color: '#ef4444' },
  survived: { badge: '✓', label: 'survived', color: '#22c55e' },
  inconclusive: { badge: '?', label: 'inconclusive', color: '#94a3b8' },
  error: { badge: '⚠', label: 'run error', color: '#f59e0b' },
};

// A challenge result is evidence, not an assumption — the reader's actions
// differ from the ledger's verify/override/contest vocabulary.
const MARKS = ['accepted_risk', 'must_fix', 'disputed'];
const MARK_META = {
  accepted_risk: { label: 'accepted risk', color: '#60a5fa' },
  must_fix: { label: 'must fix', color: '#ef4444' },
  disputed: { label: 'disputed', color: '#f59e0b' },
};

const KIND_COLORS = { frame: '#a78bfa', preference: '#60a5fa', fact: '#34d399' };

const text = { color: 'var(--signal-white, #d1d5db)' };
const dim = { color: 'var(--muted-foreground, #9ca3af)' };
const faint = { color: 'var(--comment-grey, #6b7280)' };
const border = '1px solid var(--tungsten-dim, #2a2d3a)';

function Chip({ label, color, title }) {
  return (
    <span title={title || ''} style={{
      display: 'inline-block', padding: '1px 7px', borderRadius: 9, fontSize: 10,
      fontWeight: 600, letterSpacing: 0.4, whiteSpace: 'nowrap',
      color, border: `1px solid ${color}`,
    }}>{label}</span>
  );
}

function ResultCard({ result, isReadOnly, onMark, onNote }) {
  const [open, setOpen] = useState(result.outcome === 'failed');
  const meta = OUTCOME_META[result.outcome] || OUTCOME_META.inconclusive;
  const user = result.user || { status: 'unmarked', note: '' };

  const markBtn = (m) => (
    <button
      key={m}
      disabled={isReadOnly}
      onClick={() => onMark(result, m)}
      style={{
        padding: '2px 9px', fontSize: 11, borderRadius: 4, fontWeight: 600,
        cursor: isReadOnly ? 'default' : 'pointer', opacity: isReadOnly ? 0.5 : 1,
        background: user.status === m ? MARK_META[m].color : 'transparent',
        color: user.status === m ? '#0b0e14' : MARK_META[m].color,
        border: `1px solid ${MARK_META[m].color}`,
      }}
    >{MARK_META[m].label}</button>
  );

  return (
    <div style={{ border, borderRadius: 6, padding: '8px 10px', minWidth: 180, flex: '1 1 220px' }}>
      <div
        onClick={() => setOpen((o) => !o)}
        style={{ display: 'flex', gap: 8, alignItems: 'center', cursor: 'pointer' }}
      >
        <span style={{ color: meta.color, fontWeight: 700, fontSize: 13 }}>{meta.badge}</span>
        <span style={{ ...text, fontSize: 12, fontWeight: 600, flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {result.candidate}
        </span>
        <Chip label={meta.label} color={meta.color} />
        {user.status !== 'unmarked' && (
          <span style={{ fontSize: 10, color: MARK_META[user.status]?.color || '#6b7280' }}>●</span>
        )}
      </div>
      {open && (
        <div style={{ marginTop: 8 }}>
          {result.error && (
            <div style={{ fontSize: 12, color: OUTCOME_META.error.color }}>run error: {result.error}</div>
          )}
          {result.reasoning && (
            <div style={{ ...dim, fontSize: 12, lineHeight: 1.5 }}>{result.reasoning}</div>
          )}
          {(result.evidence || []).length > 0 && (
            <ul style={{ margin: '6px 0 0', paddingLeft: 18 }}>
              {result.evidence.map((e, i) => (
                <li key={i} style={{ ...dim, fontSize: 12, lineHeight: 1.5 }}>
                  <code style={{ fontSize: 11, ...text }}>{e.ref || ''}</code>
                  {e.detail ? <span> — {e.detail}</span> : null}
                </li>
              ))}
            </ul>
          )}
          {result.reproduction && (
            <pre style={{
              margin: '8px 0 0', padding: '8px 10px', fontSize: 11, lineHeight: 1.5,
              background: 'var(--obsidian-plate, #11131a)', border, borderRadius: 4,
              overflowX: 'auto', ...text, whiteSpace: 'pre-wrap',
            }}>{result.reproduction}</pre>
          )}
          <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
            {MARKS.map(markBtn)}
          </div>
          {(user.status !== 'unmarked' || user.note) && (
            <textarea
              key={`${result.challenge_id}:${result.candidate}`}
              defaultValue={user.note || ''}
              disabled={isReadOnly}
              placeholder="note (why this mark)…"
              spellCheck={false}
              onChange={(e) => onNote(result, e.target.value)}
              style={{
                width: '100%', minHeight: 28, marginTop: 6, boxSizing: 'border-box',
                background: 'transparent', ...text, border, borderRadius: 4,
                padding: '4px 8px', fontSize: 12, outline: 'none', resize: 'vertical',
                fontFamily: 'inherit',
              }}
            />
          )}
        </div>
      )}
    </div>
  );
}

function ChallengeView() {
  const { content, saveContent, isReadOnly, api } = useCollimateFile();
  const [filter, setFilter] = useState('');

  const doc = useMemo(() => {
    try {
      const d = JSON.parse(content || '');
      return d && d.format === FORMAT ? d : null;
    } catch (e) {
      return null;
    }
  }, [content]);

  const save = useDebouncedSaveContent(saveContent, 350);
  useEffect(() => {
    if (api && typeof api.onFlush === 'function') return api.onFlush(() => save.flush());
  }, [api, save]);

  // Only user blocks are mutated; everything the generator wrote survives.
  const patchUser = useCallback((target, patch, immediate) => {
    if (!doc || isReadOnly) return;
    const next = {
      ...doc,
      results: (doc.results || []).map((r) =>
        r.challenge_id === target.challenge_id && r.candidate === target.candidate
          ? { ...r, user: { status: 'unmarked', note: '', marked_at: null, ...(r.user || {}), ...patch } }
          : r),
    };
    const json = JSON.stringify(next, null, 2) + '\n';
    if (immediate) { save.flush(); saveContent(json); } else save(json);
  }, [doc, isReadOnly, saveContent, save]);

  const onMark = useCallback((result, status) => {
    const cur = result.user?.status || 'unmarked';
    patchUser(result, {
      status: cur === status ? 'unmarked' : status,
      marked_at: new Date().toISOString(),
    }, true);
  }, [patchUser]);

  const onNote = useCallback((result, note) => patchUser(result, { note }, false), [patchUser]);

  if (!doc) {
    return (
      <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--renderer-surface, #1a1a1a)' }}>
        <div style={{ ...dim, fontSize: 13 }}>Not a challenge report — expected {FORMAT} JSON</div>
      </div>
    );
  }

  const results = doc.results || [];
  const challenges = doc.challenges || [];
  const needle = filter.trim().toLowerCase();
  const visibleChallenges = needle
    ? challenges.filter((ch) => (ch.text || '').toLowerCase().includes(needle))
    : challenges;
  const fails = results.filter((r) => r.outcome === 'failed').length;
  const survived = results.filter((r) => r.outcome === 'survived').length;
  const marked = results.filter((r) => r.user && r.user.status !== 'unmarked').length;

  return (
    <div style={{ width: '100%', height: '100%', background: 'var(--renderer-surface, #1a1a1a)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ padding: '10px 16px', background: 'var(--obsidian-plate, #11131a)', borderBottom: border }}>
        <div style={{ display: 'flex', gap: 14, alignItems: 'baseline', flexWrap: 'wrap' }}>
          <span style={{ ...text, fontSize: 14, fontWeight: 600 }}>Challenge report</span>
          <span style={{ ...dim, fontSize: 12 }}>
            {challenges.length} challenge(s) × {(doc.candidates || []).length} candidate(s)
          </span>
          <span style={{ color: OUTCOME_META.failed.color, fontSize: 12 }}>{fails} failed</span>
          <span style={{ color: OUTCOME_META.survived.color, fontSize: 12 }}>{survived} survived</span>
          <span style={{ ...faint, fontSize: 12 }}>{marked} marked</span>
        </div>
        {doc.context && (
          <div style={{ ...dim, fontSize: 12, marginTop: 6, lineHeight: 1.5 }}>
            <strong>Objection:</strong> {doc.context}
          </div>
        )}
        <input
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          placeholder="filter challenges…"
          spellCheck={false}
          style={{ marginTop: 8, width: 220, background: 'transparent', ...text, border, borderRadius: 4, padding: '4px 8px', fontSize: 12, outline: 'none' }}
        />
      </div>
      <div style={{ flex: 1, overflow: 'auto', padding: '4px 0' }}>
        {visibleChallenges.map((ch) => {
          const rows = results.filter((r) => r.challenge_id === ch.id);
          const chFails = rows.filter((r) => r.outcome === 'failed').length;
          return (
            <div key={ch.id} style={{ padding: '10px 16px', borderBottom: border }}>
              <div style={{ display: 'flex', gap: 8, alignItems: 'baseline', flexWrap: 'wrap' }}>
                <span style={{ ...faint, fontSize: 11 }}>{ch.id}</span>
                <span style={{ ...text, fontSize: 13, fontWeight: 500, flex: '1 1 260px' }}>{ch.text}</span>
                {ch.source === 'ledger'
                  ? <Chip label={`recorded assumption${ch.kind ? ` · ${ch.kind}` : ''}`}
                      color={KIND_COLORS[ch.kind] || '#94a3b8'}
                      title={ch.commitment_id ? `from ledger commitment ${ch.commitment_id}` : ''} />
                  : <Chip label="your objection" color="#f472b6" />}
                {chFails > 0 && <Chip label={`${chFails} FAILED`} color={OUTCOME_META.failed.color} />}
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
                {rows.map((r) => (
                  <ResultCard
                    key={`${r.challenge_id}:${r.candidate}`}
                    result={r}
                    isReadOnly={isReadOnly}
                    onMark={onMark}
                    onNote={onNote}
                  />
                ))}
              </div>
            </div>
          );
        })}
        {visibleChallenges.length === 0 && (
          <div style={{ padding: 16, ...faint, fontSize: 13 }}>
            {needle ? `no challenges match “${filter.trim()}”` : 'no challenges in this report'}
          </div>
        )}
      </div>
    </div>
  );
}

export default defineRenderer({ component: ChallengeView });
