import React, { useState, useEffect, useMemo, useCallback } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile, useDebouncedSaveContent } from '/api/sdk/react.js';

const FORMAT = 'collimate.assumptions-ledger';

// The reader's action differs per kind: verify a fact, override a preference,
// contest a frame choice — the chips carry that vocabulary.
const KIND_META = {
  frame: { label: 'frame', hint: 'contest', color: '#a78bfa' },
  preference: { label: 'preference', hint: 'override', color: '#60a5fa' },
  fact: { label: 'fact', hint: 'verify', color: '#34d399' },
};

const LINK_META = {
  confirmed: { badge: '✔', label: 'confirmed', color: '#22c55e' },
  decoration: { badge: '✱', label: 'decoration', color: '#94a3b8' },
  unstated_doctrine: { badge: '⚠', label: 'unstated doctrine', color: '#f59e0b' },
};

const DIFF_META = {
  seam: { label: 'LIVE SEAM', color: '#f59e0b' },
  partial: { label: 'partial', color: '#94a3b8' },
  background: { label: 'background', color: '#4b5563' },
};

const MARKS = ['verified', 'overridden', 'contested', 'struck'];
const MARK_COLORS = {
  verified: '#22c55e', overridden: '#60a5fa', contested: '#f59e0b', struck: '#ef4444',
};

const text = { color: 'var(--signal-white, #d1d5db)' };
const dim = { color: 'var(--muted-foreground, #9ca3af)' };
const faint = { color: 'var(--comment-grey, #6b7280)' };
const border = '1px solid var(--tungsten-dim, #2a2d3a)';

function Chip({ label, color, title }) {
  return (
    <span title={title || ''} style={{
      display: 'inline-block', padding: '1px 7px', borderRadius: 9,
      fontSize: 10, fontWeight: 600, letterSpacing: 0.4, whiteSpace: 'nowrap',
      color, border: `1px solid ${color}`, background: 'transparent',
    }}>{label}</span>
  );
}

function Sites({ sites }) {
  if (!sites || sites.length === 0) return null;
  return (
    <ul style={{ margin: '4px 0 0', paddingLeft: 18 }}>
      {sites.map((s, i) => (
        <li key={i} style={{ ...dim, fontSize: 12, lineHeight: 1.5 }}>
          <code style={{ fontSize: 11, ...text }}>{s.ref || ''}</code>
          {s.evidence ? <span> — {s.evidence}</span> : null}
        </li>
      ))}
    </ul>
  );
}

function CandidateLine({ label, pc, showLabel }) {
  const link = LINK_META[pc.link] || { badge: '?', label: pc.link || 'unknown', color: '#6b7280' };
  const caveat = pc.no_trace && pc.link === 'unstated_doctrine';
  return (
    <div style={{ marginTop: 6 }}>
      <span style={{ color: link.color, fontWeight: 600, fontSize: 12 }}>
        {link.badge} {link.label}
      </span>
      {showLabel && <span style={{ ...dim, fontSize: 12 }}> · <code>{label}</code></span>}
      <span style={{ ...faint, fontSize: 11 }}> · spread {pc.spread ?? 0}</span>
      {caveat && (
        <span
          title="This candidate has no trace — 'never claimed' cannot be established, only 'not found stated'."
          style={{ ...faint, fontSize: 11, fontStyle: 'italic' }}
        > · no trace — unverifiable</span>
      )}
      <details>
        <summary style={{ ...faint, fontSize: 11, cursor: 'pointer' }}>
          sites ({(pc.claimed_sites || []).length + (pc.enacted_sites || []).length})
        </summary>
        {(pc.claimed_sites || []).length > 0 && (
          <div style={{ ...faint, fontSize: 10, marginTop: 4, textTransform: 'uppercase', letterSpacing: 0.5 }}>claimed</div>
        )}
        <Sites sites={pc.claimed_sites} />
        {(pc.enacted_sites || []).length > 0 && (
          <div style={{ ...faint, fontSize: 10, marginTop: 4, textTransform: 'uppercase', letterSpacing: 0.5 }}>enacted</div>
        )}
        <Sites sites={pc.enacted_sites} />
      </details>
    </div>
  );
}

function NoteEditor({ id, initial, disabled, onChange }) {
  // Uncontrolled (keyed by commitment id): typing must never round-trip
  // through the debounced save → content → parse cycle.
  return (
    <textarea
      key={id}
      defaultValue={initial || ''}
      disabled={disabled}
      placeholder="note (why this mark)…"
      spellCheck={false}
      onChange={(e) => onChange(e.target.value)}
      style={{
        width: '100%', minHeight: 30, marginTop: 6, boxSizing: 'border-box',
        background: 'transparent', ...text, border, borderRadius: 4,
        padding: '4px 8px', fontSize: 12, outline: 'none', resize: 'vertical',
        fontFamily: 'inherit',
      }}
    />
  );
}

function Row({ row, multi, isReadOnly, onMark, onNote }) {
  const user = row.user || { status: 'unmarked', note: '' };
  const kind = KIND_META[row.kind] || KIND_META.fact;
  const diff = DIFF_META[row.differential];
  const struck = user.status === 'struck';
  const [expanded, setExpanded] = useState(false);

  const markBtn = (m) => (
    <button
      key={m}
      disabled={isReadOnly}
      onClick={() => onMark(row.id, m)}
      style={{
        padding: '2px 9px', fontSize: 11, borderRadius: 4, cursor: isReadOnly ? 'default' : 'pointer',
        background: user.status === m ? MARK_COLORS[m] : 'transparent',
        color: user.status === m ? '#0b0e14' : MARK_COLORS[m],
        border: `1px solid ${MARK_COLORS[m]}`,
        opacity: isReadOnly ? 0.5 : 1, fontWeight: 600,
      }}
    >{m}</button>
  );

  if (struck && !expanded) {
    return (
      <div style={{ padding: '6px 16px', borderBottom: border, opacity: 0.45, display: 'flex', gap: 8, alignItems: 'center' }}>
        <span style={{ ...faint, fontSize: 12, textDecoration: 'line-through', flex: 1 }}>
          {row.statement}
        </span>
        {user.note && <span style={{ ...faint, fontSize: 11, fontStyle: 'italic' }}>“{user.note}”</span>}
        <button
          onClick={() => setExpanded(true)}
          style={{ ...faint, fontSize: 11, background: 'transparent', border: 'none', cursor: 'pointer' }}
        >show</button>
      </div>
    );
  }

  return (
    <div style={{ padding: '10px 16px', borderBottom: border }}>
      <div style={{ display: 'flex', gap: 8, alignItems: 'baseline', flexWrap: 'wrap' }}>
        <span style={{ ...faint, fontSize: 11, fontVariantNumeric: 'tabular-nums' }}>#{row.rank}</span>
        <span style={{ ...text, fontSize: 13, fontWeight: 500, flex: '1 1 260px', textDecoration: struck ? 'line-through' : 'none' }}>
          {row.statement}
        </span>
        <Chip label={kind.label} color={kind.color} title={`kind: ${kind.label} → ${kind.hint}`} />
        {multi && diff && <Chip label={diff.label} color={diff.color} />}
      </div>
      {row.seam_note && (
        <div style={{
          margin: '6px 0 0', padding: '6px 10px', borderLeft: `3px solid ${DIFF_META.seam.color}`,
          background: 'color-mix(in srgb, #f59e0b 8%, transparent)', fontSize: 12, ...dim,
        }}>
          <strong style={{ color: DIFF_META.seam.color }}>Seam:</strong> {row.seam_note}
        </div>
      )}
      {Object.entries(row.per_candidate || {}).map(([label, pc]) => (
        <CandidateLine key={label} label={label} pc={pc} showLabel={multi} />
      ))}
      <div style={{ display: 'flex', gap: 6, marginTop: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        {MARKS.map(markBtn)}
        {user.status !== 'unmarked' && (
          <span style={{ ...faint, fontSize: 11 }}>
            marked {user.marked_at ? new Date(user.marked_at).toLocaleString() : ''}
          </span>
        )}
        {struck && (
          <button onClick={() => setExpanded(false)}
            style={{ ...faint, fontSize: 11, background: 'transparent', border: 'none', cursor: 'pointer' }}
          >collapse</button>
        )}
      </div>
      {(user.status !== 'unmarked' || user.note) && (
        <NoteEditor id={row.id} initial={user.note} disabled={isReadOnly} onChange={(v) => onNote(row.id, v)} />
      )}
    </div>
  );
}

function LedgerView() {
  const { content, saveContent, isReadOnly, api } = useCollimateFile();
  const [groupBy, setGroupBy] = useState('kind');
  const [filter, setFilter] = useState('');

  const doc = useMemo(() => {
    try {
      const d = JSON.parse(content || '');
      return d && d.format === FORMAT ? d : null;
    } catch (e) {
      return null;
    }
  }, [content]);

  const save = useDebouncedSaveContent(saveContent, 350);
  useEffect(() => {
    if (api && typeof api.onFlush === 'function') return api.onFlush(() => save.flush());
  }, [api, save]);

  // Only the user block is ever mutated; everything the generator wrote —
  // including keys this renderer doesn't know about — survives verbatim.
  const patchUser = useCallback((id, patch, immediate) => {
    if (!doc || isReadOnly) return;
    const next = {
      ...doc,
      commitments: (doc.commitments || []).map((row) => row.id === id
        ? { ...row, user: { status: 'unmarked', note: '', marked_at: null, ...(row.user || {}), ...patch } }
        : row),
    };
    const json = JSON.stringify(next, null, 2) + '\n';
    if (immediate) { save.flush(); saveContent(json); } else save(json);
  }, [doc, isReadOnly, saveContent, save]);

  const onMark = useCallback((id, status) => {
    const row = (doc?.commitments || []).find((r) => r.id === id);
    const cur = row?.user?.status || 'unmarked';
    patchUser(id, {
      status: cur === status ? 'unmarked' : status,
      marked_at: new Date().toISOString(),
    }, true);
  }, [doc, patchUser]);

  const onNote = useCallback((id, note) => patchUser(id, { note }, false), [patchUser]);

  if (!doc) {
    return (
      <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--renderer-surface, #1a1a1a)' }}>
        <div style={{ ...dim, fontSize: 13 }}>Not an assumptions ledger — expected {FORMAT} JSON</div>
      </div>
    );
  }

  const rows = doc.commitments || [];
  const candidates = doc.candidates || [];
  const multi = candidates.length > 1;
  const needle = filter.trim().toLowerCase();
  const visible = needle
    ? rows.filter((r) => (r.statement || '').toLowerCase().includes(needle))
    : rows;

  const seams = rows.filter((r) => r.differential === 'seam').length;
  const doctrines = rows.filter((r) =>
    Object.values(r.per_candidate || {}).some((pc) => pc.link === 'unstated_doctrine')).length;
  const marked = rows.filter((r) => r.user && r.user.status !== 'unmarked').length;

  const groups = [];
  if (groupBy === 'kind') {
    for (const k of ['frame', 'preference', 'fact']) {
      const g = visible.filter((r) => r.kind === k);
      if (g.length) groups.push({ title: `${KIND_META[k].label} — ${KIND_META[k].hint}`, rows: g });
    }
  } else {
    for (const d of ['seam', 'partial', 'background']) {
      const g = visible.filter((r) => r.differential === d);
      if (g.length) groups.push({ title: DIFF_META[d].label.toLowerCase(), rows: g });
    }
  }
  const leftovers = visible.filter((r) => !groups.some((g) => g.rows.includes(r)));
  if (leftovers.length) groups.push({ title: 'other', rows: leftovers });

  const toggleStyle = (active) => ({
    padding: '3px 10px', fontSize: 11, borderRadius: 4, cursor: 'pointer',
    background: active ? 'var(--tungsten-dim, #2a2d3a)' : 'transparent',
    color: active ? 'var(--signal-white, #e2e8f0)' : 'var(--muted-foreground, #9ca3af)',
    border, fontWeight: 600,
  });

  return (
    <div style={{ width: '100%', height: '100%', background: 'var(--renderer-surface, #1a1a1a)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ padding: '10px 16px', background: 'var(--obsidian-plate, #11131a)', borderBottom: border }}>
        <div style={{ display: 'flex', gap: 14, alignItems: 'baseline', flexWrap: 'wrap' }}>
          <span style={{ ...text, fontSize: 14, fontWeight: 600 }}>Assumptions ledger</span>
          <span style={{ ...dim, fontSize: 12 }}>{candidates.length} candidate(s)</span>
          <span style={{ ...dim, fontSize: 12 }}>{rows.length} commitment(s)</span>
          <span style={{ color: DIFF_META.seam.color, fontSize: 12 }}>{seams} live seam(s)</span>
          <span style={{ color: LINK_META.unstated_doctrine.color, fontSize: 12 }}>{doctrines} unstated doctrine(s)</span>
          <span style={{ ...faint, fontSize: 12 }}>{marked} marked</span>
        </div>
        {doc.error && (
          <div style={{ marginTop: 6, fontSize: 12, color: '#f59e0b' }}>⚠ extraction degraded: {doc.error}</div>
        )}
        <div style={{ display: 'flex', gap: 8, marginTop: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <button style={toggleStyle(groupBy === 'kind')} onClick={() => setGroupBy('kind')}>by kind</button>
          <button style={toggleStyle(groupBy === 'differential')} onClick={() => setGroupBy('differential')}>by differential</button>
          <input
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="filter commitments…"
            spellCheck={false}
            style={{ flex: '0 1 220px', background: 'transparent', ...text, border, borderRadius: 4, padding: '4px 8px', fontSize: 12, outline: 'none' }}
          />
        </div>
      </div>
      <div style={{ flex: 1, overflow: 'auto' }}>
        {groups.map((g) => (
          <div key={g.title}>
            <div style={{ padding: '8px 16px 4px', ...faint, fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.6 }}>
              {g.title}
            </div>
            {g.rows.map((row) => (
              <Row key={row.id} row={row} multi={multi} isReadOnly={isReadOnly} onMark={onMark} onNote={onNote} />
            ))}
          </div>
        ))}
        {visible.length === 0 && (
          <div style={{ padding: 16, ...faint, fontSize: 13 }}>
            {needle ? `no commitments match “${filter.trim()}”` : 'no commitments extracted'}
          </div>
        )}
      </div>
    </div>
  );
}

export default defineRenderer({ component: LedgerView });
