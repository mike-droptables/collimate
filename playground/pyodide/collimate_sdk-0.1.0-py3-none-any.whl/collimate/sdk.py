"""
Collimate SDK — Strongly-typed Python API for building generators.

Generators communicate with the Collimate backend via a localhost TCP socket
to keep stdout/stderr free for human-readable logs.
"""

import json
import logging
import os
import signal
import socket
import sys
import threading
from dataclasses import dataclass
from typing import Callable, Optional, Any


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class StopSignal(Exception):
    """Raised when the backend sends a SIGTERM (user clicked Stop)."""
    pass


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class Message:
    """A single chat message in the generator conversation."""
    role: str  # "user", "assistant", "system"
    content: str
    timestamp: str = ""


@dataclass
class Artifact:
    """Describes a single file to include in a commit."""
    cell_path: str
    type: str  # "workspace" or "memory"
    local_path: Optional[str] = None
    content: Optional[str] = None
    encoding: str = "utf-8"

    @staticmethod
    def from_workspace(local_path: str, cell_path: str) -> "Artifact":
        return Artifact(cell_path=cell_path, type="workspace", local_path=local_path)

    @staticmethod
    def from_memory(cell_path: str, content: str, encoding: str = "utf-8") -> "Artifact":
        return Artifact(cell_path=cell_path, type="memory", content=content, encoding=encoding)


# ---------------------------------------------------------------------------
# Wrappers (FS & Chat)
# ---------------------------------------------------------------------------

def _is_colreserved_path(path: str) -> bool:
    """`.colreserved/` is a private namespace for SDK/backend use only.

    Generators must not see it or attempt to commit into it. Settings files
    and other internal state live there and flow through dedicated SDK APIs
    (gen.chat, gen.log, settings loading) rather than gen.fs.

    Exception: `.colreserved/.collimate_messages.json` is allowed through
    because it must be committed as a cell artifact for chat history.
    """
    norm = path.replace("\\", "/").lstrip("/")
    if norm == ".colreserved/.collimate_messages.json":
        return False
    return norm == ".colreserved" or norm.startswith(".colreserved/")


class FSWrapper:
    """Virtual FileSystem scoped to the Collimate Workspace."""

    def __init__(self, workspace: str):
        self.workspace = workspace
        self.tracked_writes = set()

    def read(self, path: str) -> str:
        """Read a file from the workspace."""
        if _is_colreserved_path(path):
            raise PermissionError(f".colreserved/ is reserved for SDK internals: {path}")
        with open(os.path.join(self.workspace, path), "r", encoding="utf-8") as f:
            return f.read()

    def write(self, path: str, content: str):
        """Write a file to the workspace. Automatically tracks it for the next commit."""
        if _is_colreserved_path(path):
            raise PermissionError(f".colreserved/ is reserved for SDK internals: {path}")
        full = os.path.join(self.workspace, path)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8") as f:
            f.write(content)
        self.tracked_writes.add(path)

    def write_bytes(self, path: str, data: bytes):
        """Write binary data to the workspace. Automatically tracks it for the next commit."""
        if _is_colreserved_path(path):
            raise PermissionError(f".colreserved/ is reserved for SDK internals: {path}")
        full = os.path.join(self.workspace, path)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "wb") as f:
            f.write(data)
        self.tracked_writes.add(path)

    def exists(self, path: str) -> bool:
        """Check if a file exists in the workspace."""
        if _is_colreserved_path(path):
            return False
        return os.path.exists(os.path.join(self.workspace, path))

    def list(self) -> list[str]:
        """Get a list of all relative file paths in the workspace.

        `.colreserved/` and `.collimate_messages*` are filtered out.
        """
        res = []
        for root, dirs, files in os.walk(self.workspace):
            # Prune .colreserved at the directory level so we don't even walk it
            dirs[:] = [d for d in dirs if not _is_colreserved_path(
                os.path.relpath(os.path.join(root, d), self.workspace)
            )]
            for f in files:
                if f.startswith(".collimate_messages"):
                    continue
                rel = os.path.relpath(os.path.join(root, f), self.workspace).replace("\\", "/")
                if _is_colreserved_path(rel):
                    continue
                res.append(rel)
        return res


class ConfigWrapper:
    """Read-only access to the pre-run config assembled from a Picking /
    Draft cell.

    Lives at ``.colreserved/config/`` inside the workspace and is populated
    by the backend just before the generator starts:

      - ``pickoptions.json`` — ordered list of chosen ``value`` entries
        from the generator's ``pickoptions.yaml`` (if the user went
        through a multi-stage pick).
      - ``files/`` — every file the user authored pre-run. This is the
        same storage whether the file came from the generator's
        declared ``draft_files`` list (seeded defaults), from the user
        editing them in a Draft cell, or from anything else the
        generator considers config. "Settings" is not a special name —
        it's just files in here that happen to use the ``.set_yaml``
        schema_form format.

    Distinct from ``gen.fs`` (hydrated input files from **parent
    cells**). Use ``gen.config`` for "what did the user pick or author
    pre-run for THIS run".
    """

    def __init__(self, workspace: str):
        self._root = os.path.join(workspace, ".colreserved", "config")

    def get_pickoptions(self) -> list:
        """Return the ordered pickoptions values, or [] if none."""
        path = os.path.join(self._root, "pickoptions.json")
        if not os.path.isfile(path):
            return []
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError):
            return []
        return data if isinstance(data, list) else []

    def list_files(self) -> list[str]:
        """Return relative paths of config files, or []."""
        files_dir = os.path.join(self._root, "files")
        if not os.path.isdir(files_dir):
            return []
        out: list[str] = []
        for dirpath, _, filenames in os.walk(files_dir):
            for name in filenames:
                full = os.path.join(dirpath, name)
                out.append(os.path.relpath(full, files_dir))
        out.sort()
        return out

    def get_file(self, path: str) -> str | None:
        """Return the content of a config file, or None if missing."""
        full = os.path.join(self._root, "files", path)
        if not os.path.isfile(full):
            return None
        with open(full, "r", encoding="utf-8") as f:
            return f.read()

    def read_schema_values(self, path: str) -> dict[str, Any]:
        """Parse a ``.set_yaml`` schema_form file at ``path`` (relative
        to ``.colreserved/config/files/``) and return a flat dict of
        resolved values. Checks the ``values:`` block first, then
        falls back to each field's ``default``. Returns ``{}`` if the
        file is missing or malformed.

        This is the pattern you want for any generator that uses a
        schema_form file for its config:

            settings = gen.config.read_schema_values("settings.set_yaml")
            model = settings.get("model", "gemini-2.0-flash")

        The ``.set_yaml`` format is not magic — the schema_form
        renderer just recognises the extension. A generator can have
        zero, one, or many schema_form files, pick any names it wants,
        and declare them in the manifest's ``draft_files``. Use
        ``get_file()`` for non-schema files (plain markdown, prompts,
        templates, whatever) and parse however you like.
        """
        content = self.get_file(path)
        if content is None:
            return {}
        try:
            import yaml  # local import — yaml is optional outside the runtime
        except ImportError:
            return {}
        try:
            parsed = yaml.safe_load(content) or {}
        except yaml.YAMLError:
            return {}
        if not isinstance(parsed, dict):
            return {}
        values = parsed.get("values") if isinstance(parsed.get("values"), dict) else {}
        fields = parsed.get("fields") if isinstance(parsed.get("fields"), list) else []
        out: dict[str, Any] = {}
        for f in fields:
            if isinstance(f, dict) and isinstance(f.get("key"), str) and "default" in f:
                out[f["key"]] = f["default"]
        out.update(values)
        return out


class ChatWrapper:
    """Chat and streaming-session primitives for generators.

    Two distinct layers live here:

    **Workspace history** (``history``, ``append``, ``dirty``).
    Read/write the ``.collimate_messages.json`` file in the generator's
    hydrated workspace. These are primarily consumed by the
    ``anthropic_api`` in-process fallback backend in the chat generator,
    which runs the entire turn loop inside the generator subprocess
    without a warm container.  The main ``claude_code_session`` backend
    (and the inline ``POST /chat/turn`` endpoint) do NOT use these —
    messages flow through ``chat_session._append_message`` on the host
    side and are committed via ``pending_file_hashes``.

    **Session wiring** (``start_session``, ``send_turn``).
    IPC ops that delegate to the host's ``chat_pool`` + ``chat_session``
    infrastructure. Only meaningful when running inside a generator
    subprocess (i.e., when the chat generator is dispatched through the
    ``POST /runs`` pipeline rather than the inline ``/chat/turn``
    endpoint). Kept for backward compat and for other in_place
    generators that want the same warm-container streaming.
    """

    def __init__(self, generator: "Generator"):
        self.gen = generator
        self.dirty = False

    # ------------------------------------------------------------------
    # Workspace history — used by the anthropic_api fallback backend
    # ------------------------------------------------------------------

    @property
    def history(self) -> list[Message]:
        return self.gen._read_messages()

    def last(self) -> Message | None:
        """Get the most recent message."""
        hist = self.history
        return hist[-1] if hist else None

    def append(self, role: str, content: str):
        """Append a message to the history. Automatically tracks it for the next commit.

        Idempotent: if the last message in the file already has the same
        role and content, the call is a no-op (apart from marking dirty).
        This prevents duplicates when the frontend's draft flush already
        wrote the message to the workspace before the generator appends it.
        """
        messages = self.history
        # Skip if already the last entry (draft flush may have written it)
        if messages and messages[-1].role == role and messages[-1].content == content:
            self.dirty = True
            return
        messages.append(Message(role=role, content=content))
        raw = [{"role": m.role, "content": m.content} for m in messages]
        os.makedirs(os.path.dirname(self.gen._messages_path), exist_ok=True)
        with open(self.gen._messages_path, "w", encoding="utf-8") as f:
            json.dump(raw, f, indent=2, ensure_ascii=False)
        self.dirty = True

    # ------------------------------------------------------------------
    # Persistent streaming-session wiring (IPC to host)
    # ------------------------------------------------------------------

    def start_session(
        self,
        image: str,
        dockerfile_dir: str,
        shared: bool = True,
        backend: str = "claude_code_session",
        model: str = "sonnet",
        system_prompt: str = "",
    ) -> dict:
        """Open (or reuse) a persistent streaming session bound to this cell.

        The generator declares the docker image and the build context
        directory — the host has no system-wide default image. Every
        generator that uses this primitive specifies what to spawn.

        Args:
            image: Docker image tag to spawn the daemon from. Required.
            dockerfile_dir: Absolute path to the directory containing the
                Dockerfile. Used by the host to lazily build the image
                if it is not already on the local Docker daemon. Pair
                with ``gen.shared()`` to point at a Dockerfile that
                lives inside this generator's (or another generator's)
                ``shared/`` directory.
            shared: When True (default) one daemon container per image
                is reused across cells; sessions are multiplexed inside
                it and the container is reference-counted, torn down
                only when the last session ends. When False a fresh
                container is spawned for this session and dies when the
                session closes. Shared = faster subsequent cells, soft
                isolation between sessions. Not-shared = hard isolation,
                full container boot per session.
            backend: Daemon-side backend identifier. The chat-worker
                image only ships ``claude_code_session`` today.
            model: LLM model the backend should use.
            system_prompt: System prompt threaded into the model call.

        Idempotent — if a session is already open for this cell the
        backend returns it unchanged.
        """
        cell_id = os.environ.get("COLLIMATE_IN_PLACE_CELL_ID", "")
        payload = {
            "op": "chat_start_session",
            "cell_id": cell_id,
            "image": image,
            "dockerfile_dir": dockerfile_dir,
            "shared": bool(shared),
            "backend": backend,
            "model": model,
            "system_prompt": system_prompt,
        }
        ack = self.gen._emit_and_wait(payload, wait_op="ack_chat_start_session")
        if not ack.get("ok", False):
            raise RuntimeError(
                f"chat.start_session failed: {ack.get('error', 'unknown')}"
            )
        return ack

    def send_turn(self, content: str) -> dict:
        """Send one prompt to the bound persistent session and block until
        the daemon emits ``turn_end``. Token-level streaming, tool calls,
        live file edits, and Bash output are broadcast from the host
        directly to the frontend via SSE — this call just waits for the
        final aggregated result.

        Returned dict keys:
            turn_id        -- hex id of the turn that actually ran
            usage          -- token usage stats from the backend, if any
            file_changes   -- list[str] of workspace paths edited
            assistant_text -- final aggregated assistant reply
            cancelled      -- bool, True if the user hit interrupt
                              (or pressed Escape in the UI). Partial
                              state is preserved either way; the
                              caller should still proceed to commit
                              via update_cell so the partial turn
                              lands as a row in the version chain.

        If the user calls the redirect endpoint mid-turn, the cancel +
        new-turn cycle is handled transparently inside this call. The
        returned ``turn_id`` is the id of the final (successful) turn,
        not the id of the one that was redirected away from.
        """
        cell_id = os.environ.get("COLLIMATE_IN_PLACE_CELL_ID", "")
        payload = {
            "op": "chat_send_turn",
            "cell_id": cell_id,
            "content": content,
        }
        ack = self.gen._emit_and_wait(payload, wait_op="ack_chat_send_turn")
        if not ack.get("ok", False):
            raise RuntimeError(
                f"chat.send_turn failed: {ack.get('error', 'unknown')}"
            )
        return ack

    def wait_for_message(self) -> Optional[str]:
        """Block until the user sends a chat message, then return it.

        The generator subprocess calls this when it has no user message
        to process (e.g. first run from the picker). The backend queues
        messages pushed by the frontend and delivers them via the
        ``poll_user_message`` IPC round-trip.

        Returns the message content string, or ``None`` if the process
        is being stopped (SIGTERM received).
        """
        import time as _time
        while True:
            if self.gen.stop_requested():
                return None
            ack = self.gen._emit_and_wait(
                {"op": "poll_user_message"},
                wait_op="ack_poll_user_message",
            )
            content = ack.get("content")
            if content:
                return content
            # No message yet — brief sleep before next poll.
            _time.sleep(0.15)

    def emit_stream_event(self, turn_id: str, event: dict) -> None:
        """Push a chat_stream event directly to the frontend via SSE.

        Used by the Phase 7 fallback Anthropic API backend (which runs
        in-process in the generator subprocess) to stream its own text
        and tool events without going through a chat worker daemon.
        No ack — fire-and-forget.
        """
        cell_id = os.environ.get("COLLIMATE_IN_PLACE_CELL_ID", "")
        self.gen._emit({
            "op": "chat_stream_event",
            "cell_id": cell_id,
            "turn_id": turn_id,
            "event": event,
        })


# ---------------------------------------------------------------------------
# Generator
# ---------------------------------------------------------------------------

class Generator:
    """
    Main entry-point for generator scripts.
    """

    def __init__(self):
        self.workspace: str = os.environ.get("COLLIMATE_WORKSPACE", os.getcwd())
        self.params: dict = json.loads(os.environ.get("COLLIMATE_PARAMS", "{}"))
        
        self._messages_path = os.path.join(self.workspace, ".colreserved", ".collimate_messages.json")
        self.fs = FSWrapper(self.workspace)
        self.chat = ChatWrapper(self)
        self.config = ConfigWrapper(self.workspace)
        self.StopSignal = StopSignal
        self._has_updated = False  # Tracks whether update_cell has been called

        # Setup Logging
        self.log = logging.getLogger("collimate.generator")
        if not self.log.handlers:
            handler = logging.StreamHandler(sys.stderr)
            handler.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
            self.log.addHandler(handler)
            self.log.setLevel(logging.DEBUG)

        # IPC socket
        self._socket: socket.socket | None = None
        self._sock_rfile = None
        self._sock_wfile = None
        port_str = os.environ.get("COLLIMATE_IPC_PORT")
        if port_str:
            try:
                self._socket = socket.create_connection(("127.0.0.1", int(port_str)))
                self._sock_rfile = self._socket.makefile("r", encoding="utf-8")
                self._sock_wfile = self._socket.makefile("w", encoding="utf-8")
            except Exception as e:
                self._socket = None
                self.log.warning("IPC connect failed (port %s): %s", port_str, e)
        else:
            self.log.warning("COLLIMATE_IPC_PORT not set — running in dev mode")

        # Stop signal — uses a self-pipe so the handler is async-signal-safe.
        # Event.set() takes a lock and can deadlock if the handler is
        # re-entered (which happens when SIGTERM is delivered twice — once
        # by the supervisor's killpg and once forwarded by `uv run`). os.write
        # on a pipe is one of the few syscalls that is reentrant by POSIX,
        # so handlers can fire repeatedly without corrupting state.
        self._stop_pipe_r, self._stop_pipe_w = os.pipe()
        os.set_blocking(self._stop_pipe_r, True)
        os.set_blocking(self._stop_pipe_w, False)
        signal.signal(signal.SIGTERM, self._handle_stop)
        if sys.platform == "win32":
            signal.signal(signal.SIGBREAK, self._handle_stop)

    # ------------------------------------------------------------------
    # Shared assets — cross-generator file references
    # ------------------------------------------------------------------

    def shared(self, generator_name: str | None = None) -> str:
        """Return the absolute path to a generator's ``shared/`` directory.

        Files placed under a generator's ``shared/`` subdirectory are a
        public surface that other generators may reference. The
        directory is opaque to Collimate's generator discovery (no
        ``manifest.gen_yaml``, no picker entry); it is plain assets
        — Dockerfiles, prompt templates, schemas, anything.

        Args:
            generator_name: Name of the generator whose ``shared/`` dir
                to resolve, expressed as a path under
                ``collimate-sdk/generators/`` (e.g.
                ``"chat/claude_code_chat"``). When ``None`` (default)
                returns this generator's own ``shared/`` directory.

        Returns:
            Absolute path to the ``shared/`` directory. The path is
            returned even if it does not yet exist; the caller decides
            whether absence is an error.

        Examples:

            # Reference your own Dockerfile.
            gen.chat.start_session(
                image="collimate-chat-worker",
                dockerfile_dir=gen.shared(),
                shared=True, ...,
            )

            # Reuse another generator's image.
            gen.chat.start_session(
                image="collimate-chat-worker",
                dockerfile_dir=gen.shared("chat/claude_code_chat"),
                shared=True, ...,
            )
        """
        if generator_name is None:
            base = os.environ.get("COLLIMATE_APP_DIR") or os.getcwd()
            return os.path.join(base, "shared")
        gens_root = os.environ.get("COLLIMATE_GENERATORS_DIR")
        if not gens_root:
            raise RuntimeError(
                "gen.shared(<other>) requires COLLIMATE_GENERATORS_DIR to "
                "be set by the host. This is set automatically when the "
                "generator is launched from a real run; in dev mode you "
                "must set it manually to the generators source root."
            )
        norm = generator_name.strip().strip("/").replace("\\", "/")
        return os.path.join(gens_root, norm, "shared")

    # ------------------------------------------------------------------
    # Decorator / Lifecycle
    # ------------------------------------------------------------------

    def run(self, name: str = None):
        """
        Decorator that manages the entire run lifecycle.
        Catches StopSignals and generic exceptions.
        """
        def decorator(func):
            def wrapper(*args, **kwargs):
                try:
                    if name:
                        self.status = f"Running {name}..."
                    func(*args, **kwargs)
                    self.finish(success=True)
                except self.StopSignal:
                    self.log.info("Stopped gracefully by user.")
                    self.finish(success=False, error_message="Stopped by user")
                except Exception as e:
                    self.log.exception("Generator failed")
                    self.finish(success=False, error_message=str(e))
            return wrapper
        return decorator

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def status(self) -> str:
        return ""
        
    @status.setter
    def status(self, message: str):
        """Update the live status stream in the UI."""
        self._emit({"op": "status", "status": "running", "message": message})

    def progress(self, current: int, total: int):
        """Update the progress bar in the UI."""
        self._emit({"op": "progress", "current": current, "total": total})

    # ------------------------------------------------------------------
    # Core Methods
    # ------------------------------------------------------------------

    def update_cell(
        self,
        name: Optional[str] = None,
        summary: Optional[str] = None,
        artifacts: Optional[list[Artifact]] = None,
        metadata: Optional[dict[str, Any]] = None,
        deleted_files: Optional[list[str]] = None,
    ) -> str:
        """Mutate the run's first cell in place.

        The first call populates the auto-created placeholder cell
        without creating a version-history entry (the system tracks
        this automatically). All subsequent calls create proper version
        rows linked via cell_edges.

        Implicit artifact selection: if ``artifacts`` is None, all
        files written via ``gen.fs`` plus any dirty chat history are
        included. Files the generator did not rewrite are carried
        forward from the previous version automatically.

        ``name`` and ``summary`` default to None — the backend
        interprets None as "keep the existing value".

        ``deleted_files`` is an optional list of file paths to remove
        from the cell. These are dropped from the carried-forward file
        set before the new version is written.
        """
        if artifacts is None:
            artifacts = []
            for path in self.fs.tracked_writes:
                artifacts.append(Artifact.from_workspace(local_path=path, cell_path=path))
            if self.chat.dirty:
                artifacts.append(Artifact.from_workspace(
                    local_path=".colreserved/.collimate_messages.json",
                    cell_path=".colreserved/.collimate_messages.json"
                ))

        # Clear tracking
        self.fs.tracked_writes.clear()
        self.chat.dirty = False

        # Drop any .colreserved/* paths — the backend will also filter, but
        # stopping it at the source makes intent clear.
        artifacts = [a for a in artifacts if not _is_colreserved_path(a.cell_path)]

        artifact_dicts = []
        for a in artifacts:
            d = {"type": a.type, "cell_path": a.cell_path}
            if a.type == "workspace":
                d["local_path"] = a.local_path or a.cell_path
            elif a.type == "memory":
                d["content"] = a.content or ""
                d["encoding"] = a.encoding
            artifact_dicts.append(d)

        payload: dict[str, Any] = {
            "op": "update_cell",
            "name": name,
            "summary": summary,
            "artifacts": artifact_dicts,
            "metadata": metadata or {},
        }
        if deleted_files:
            payload["deleted_files"] = deleted_files

        # First call is treated as "initial" — no version chain entry.
        if not self._has_updated:
            payload["initial"] = True
            self._has_updated = True

        ack = self._emit_and_wait(payload, wait_op="ack_update")
        return ack.get("cell_id", "")

    def create_cell(
        self,
        name: str = "Output",
        summary: str = "",
        artifacts: Optional[list[Artifact]] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> str:
        """Create a new side cell during a run.

        The first call creates a new stack to the right of the run's
        first cell; subsequent calls append to that same stack. This is
        the way generators produce additional output cells beyond the
        auto-created first cell.

        Implicit artifact selection follows the same rules as
        ``update_cell()``: if ``artifacts`` is None, all files written
        via ``gen.fs`` plus any dirty chat history are included.
        """
        if artifacts is None:
            artifacts = []
            for path in self.fs.tracked_writes:
                artifacts.append(Artifact.from_workspace(local_path=path, cell_path=path))
            if self.chat.dirty:
                artifacts.append(Artifact.from_workspace(
                    local_path=".colreserved/.collimate_messages.json",
                    cell_path=".colreserved/.collimate_messages.json"
                ))

        # Clear tracking
        self.fs.tracked_writes.clear()
        self.chat.dirty = False

        artifacts = [a for a in artifacts if not _is_colreserved_path(a.cell_path)]

        artifact_dicts = []
        for a in artifacts:
            d = {"type": a.type, "cell_path": a.cell_path}
            if a.type == "workspace":
                d["local_path"] = a.local_path or a.cell_path
            elif a.type == "memory":
                d["content"] = a.content or ""
                d["encoding"] = a.encoding
            artifact_dicts.append(d)

        payload = {
            "op": "create_side_cell",
            "name": name,
            "summary": summary,
            "artifacts": artifact_dicts,
            "metadata": metadata or {},
        }

        ack = self._emit_and_wait(payload, wait_op="ack_create_side_cell")
        return ack.get("cell_id", "")

    def request_settings_update(
        self,
        settings_file_path: str,
    ) -> dict[str, Any]:
        """Present a settings form to the user mid-run and block until
        they press Continue.

        The generator must write the settings file (a ``.set_yaml``) to
        the workspace *before* calling this method. The backend reads the
        file, broadcasts it to the frontend as an overlay, and blocks
        until the user edits and clicks Continue.

        Args:
            settings_file_path: Relative path in the workspace to the
                settings file to display. Must already exist.

        Returns:
            A dict of the updated settings values after the user presses
            Continue.
        """
        payload = {
            "op": "request_settings_update",
            "settings_file_path": settings_file_path,
        }
        ack = self._emit_and_wait(payload, wait_op="ack_settings_update")
        if not ack.get("ok", False):
            raise RuntimeError(
                f"request_settings_update failed: {ack.get('error', 'unknown')}"
            )
        return ack.get("values", {})

    def serve_port(
        self,
        port: int,
        name: str = "preview",
        path: str = "",
        snapshot_source: Optional[dict[str, str]] = None,
    ):
        """Notify the UI to open a sandbox iframe on the given port.

        `path` is appended to the proxy URL the iframe loads (e.g.
        `path="?command=claude-code.chat.focus"` to run a workbench command
        on first paint). It's a literal suffix — include the leading `?`
        for query strings or the leading `/` for sub-paths.

        If `snapshot_source` is provided (e.g.
        `{"container_name": "...", "project_dir": "/home/coder/project"}`),
        the UI exposes Snapshot / Snapshot & Stop buttons above the live
        iframe. The backend uses these fields to pull files out of the
        running container on demand. Generators that don't run inside a
        docker container should leave this unset.
        """
        payload: dict[str, Any] = {"op": "port_bound", "port": port, "name": name}
        if path:
            payload["path"] = path
        if snapshot_source:
            payload["snapshot_source"] = snapshot_source
        self._emit(payload)

    def start_terminal(
        self,
        container_id: str,
        command: list[str],
        cwd: Optional[str] = None,
        env: Optional[dict[str, str]] = None,
    ) -> dict:
        """Allocate a WebSocket-backed PTY session for a command running
        inside a docker container, and return the pointer metadata the
        ``.terminal`` renderer expects.

        The host has no business launching anything until the renderer
        actually attaches — this call just reserves a session id and
        auth token in the backend's in-memory registry. The PTY is
        spawned lazily when the browser opens the WebSocket.

        Args:
            container_id: Docker container id or name (e.g. the
                ``container_id`` returned from ``gen.chat.start_session()``).
                The backend runs ``docker exec -ti <container_id> <command>``
                against this value.
            command: Argv list to launch inside the container (e.g.
                ``["claude"]`` or ``["bash"]``).
            cwd: Optional working directory inside the container
                (passed as ``docker exec -w``).
            env: Optional extra environment variables passed as
                ``docker exec -e KEY=VALUE`` pairs.

        Returns a dict with keys:
            session_id -- opaque string, key into the backend registry
            ws_path    -- path (not full URL) the renderer opens
            token      -- auth token, must be supplied as a query
                          parameter on the WebSocket upgrade

        Typical usage is to JSON-dump the whole dict (plus a human
        ``label``) into a ``<name>.terminal`` file and commit that file
        as a cell artifact:

            sess = gen.chat.start_session(image="collimate-chat-worker", ...)
            term = gen.start_terminal(
                container_id=sess["container_id"],
                command=["claude"],
                cwd="/home/coder/project",
            )
            gen.fs.write("claude.terminal", json.dumps({
                **term,
                "label": "Claude Code",
            }))
            gen.update_cell(name="Claude Terminal", summary="live")
            gen.wait_until_stopped()
        """
        cell_id = os.environ.get("COLLIMATE_IN_PLACE_CELL_ID", "")
        payload = {
            "op": "create_terminal_session",
            "cell_id": cell_id,
            "container_id": container_id,
            "command": list(command),
            "cwd": cwd or "",
            "env": dict(env or {}),
        }
        ack = self._emit_and_wait(payload, wait_op="ack_create_terminal_session")
        if not ack.get("ok", False):
            raise RuntimeError(
                f"start_terminal failed: {ack.get('error', 'unknown')}"
            )
        return {
            "session_id": ack.get("session_id", ""),
            "ws_path": ack.get("ws_path", ""),
            "token": ack.get("token", ""),
        }

    def stop_terminal(self, session_id: str) -> None:
        """Tear down a terminal session previously returned by
        ``start_terminal``. Idempotent — unknown session ids are a
        no-op. Fire-and-forget (no ack).

        The run-cleanup path also unregisters every terminal session
        bound to this cell when the generator process exits, so calling
        this explicitly is optional — do it in a ``try/finally`` if
        you want deterministic release."""
        if not session_id:
            return
        self._emit({
            "op": "destroy_terminal_session",
            "session_id": session_id,
        })

    def wait_until_stopped(self):
        """Block until the user clicks Stop (SIGTERM received), then raise
        StopSignal so the caller's try/finally cleanup runs and the
        @gen.run wrapper can mark the run as gracefully stopped."""
        # Block on the self-pipe. os.read returns as soon as the signal
        # handler has written any byte; multiple writes are harmless because
        # we never read the pipe again.
        try:
            os.read(self._stop_pipe_r, 1)
        except OSError:
            pass
        raise StopSignal()

    def wait_for_action(self, timeout: float | None = None) -> Optional[str]:
        """Block until a renderer emits an action (e.g. a top-bar button
        click in the .website renderer) and return its action_id.

        Returns None if ``timeout`` elapses without an action, or if Stop
        is requested. Pass ``timeout=None`` to poll until stopped.

        Pair with a renderer that calls ``api.emitAction(action_id)``
        and an artifact format that declares buttons (e.g. a JSON
        ``.website`` with a ``buttons`` field).
        """
        import time as _time
        deadline = None if timeout is None else _time.monotonic() + timeout
        while True:
            if self.stop_requested():
                return None
            ack = self._emit_and_wait(
                {"op": "poll_renderer_action"},
                wait_op="ack_poll_renderer_action",
            )
            action_id = ack.get("action_id")
            if action_id:
                return action_id
            if deadline is not None and _time.monotonic() >= deadline:
                return None
            _time.sleep(0.15)

    def stop_requested(self) -> bool:
        """Non-blocking check for Stop. Returns True if the user has clicked
        Stop since the generator started. Useful inside long oneshot loops
        that want to exit early without blocking in wait_until_stopped()."""
        import select
        r, _, _ = select.select([self._stop_pipe_r], [], [], 0)
        return bool(r)

    def finish(self, success: bool = True, error_message: str = ""):
        """Signal the backend that this generator is done."""
        self._emit({
            "op": "finish",
            "success": success,
            "error_message": error_message,
        })
        if self._sock_wfile:
            try: self._sock_wfile.close()
            except OSError: pass
        if self._sock_rfile:
            try: self._sock_rfile.close()
            except OSError: pass
        if self._socket:
            try: self._socket.close()
            except OSError: pass

    # ------------------------------------------------------------------
    # Internal Helpers
    # ------------------------------------------------------------------

    def _read_messages(self) -> list[Message]:
        path = self._messages_path
        if not os.path.isfile(path):
            # Fall back to the legacy root-level path for older workspaces
            legacy = os.path.join(self.workspace, ".collimate_messages.json")
            if os.path.isfile(legacy):
                path = legacy
            else:
                return []
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                return [Message(role=m.get("role", "user"), content=m.get("content", ""), timestamp=m.get("timestamp", "")) for m in data]
        except (json.JSONDecodeError, OSError):
            pass
        return []

    def _emit(self, payload: dict):
        if self._sock_wfile is None:
            self.log.debug("IPC (dev): %s", json.dumps(payload))
            return
        self._sock_wfile.write(json.dumps(payload) + "\n")
        self._sock_wfile.flush()

    def _emit_and_wait(self, payload: dict, wait_op: str) -> dict:
        self._emit(payload)
        if self._sock_rfile is None:
            return {}
        while True:
            ack_line = self._sock_rfile.readline()
            if not ack_line:
                break
            try:
                ack = json.loads(ack_line.strip())
                if ack.get("op") == wait_op:
                    return ack
            except json.JSONDecodeError:
                continue
        return {}

    def _handle_stop(self, signum, frame):
        # Async-signal-safe: write a single byte to the self-pipe. Any code
        # blocked in wait_until_stopped() will unblock from os.read and raise
        # StopSignal in normal Python context. The pipe is non-blocking on
        # the write side, so a full pipe (e.g. from repeated SIGTERMs) drops
        # extra bytes silently rather than blocking the handler.
        try:
            os.write(self._stop_pipe_w, b"x")
        except (BlockingIOError, OSError):
            pass
