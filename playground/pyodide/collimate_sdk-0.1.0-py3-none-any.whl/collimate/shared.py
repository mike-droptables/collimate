# SPDX-License-Identifier: Apache-2.0
"""Locate files under the SDK's top-level ``shared/`` tree at runtime.

The ``shared/`` directory lives at the repo root (sibling of
``generators/``, ``renderers/``, ``src/``). It holds the authoring
how-to docs (``shared/docs/*.md``) — the canonical, GitHub-browsable
source — and is the landing spot for any cross-cutting, non-Python asset
the SDK wants to expose.

``shared_path`` resolves these at the SDK level. Generators should NOT
call it to read docs at run time: the collimate app's genesis seeding
copies the docs a cell needs into that cell (``releases.yaml``
``cells[].shared_docs``), and generators read the resulting cell-local
``_shared_docs/`` sibling via :func:`shared_doc`. ``shared_path`` remains
for the seed-time copy and for any non-doc shared asset.

Two resolution paths, same pattern as ``collimate.packaging.vendor_defaults``:

1. Installed wheel — ``importlib.resources.files("collimate") / "shared" / ...``.
   Requires ``pyproject.toml`` to force-include ``shared/`` into the
   wheel's package data (``[tool.hatch.build.targets.wheel.force-include]``).

2. In-tree source / editable checkout — fall through to the SDK repo
   root (computed from this file's location) and join ``shared/`` + the
   requested segments.

Callers should not assume the path is always on the real filesystem —
``importlib.resources`` may materialize content from a zip. Use
``shared_path(...).read_text()`` / ``.read_bytes()`` instead of passing
the path to another process.
"""
from __future__ import annotations

from importlib.resources import as_file, files
from pathlib import Path


_IN_TREE_SDK_ROOT = Path(__file__).resolve().parents[2]


def shared_path(*segments: str) -> Path:
    """Resolve a path inside the SDK's ``shared/`` directory.

    Raises ``FileNotFoundError`` with both attempted locations in the
    message when neither lookup finds the asset.

    Example:
        >>> shared_path("docs", "how-to-write-a-generator.md").read_text()[:20]
        '# How to write a gen'
    """
    rel = "/".join(segments)

    # Search the canonical ``shared/`` tree first, then the quarantined
    # ``demo/`` tree (which holds demo-only assets like the WASM authoring
    # guide ``demo/docs/how-to-write-a-wasm-generator.md``). The demo
    # fallback only fires when ``shared/`` misses, so canonical assets win.
    for top in ("shared", "demo"):
        # 1. Installed wheel — importlib.resources.
        try:
            installed = files("collimate").joinpath(top, *segments)
            with as_file(installed) as p:
                if p.exists():
                    return Path(p)
        except (ModuleNotFoundError, FileNotFoundError):
            pass

        # 2. In-tree / editable checkout.
        in_tree = _IN_TREE_SDK_ROOT / top / rel
        if in_tree.exists():
            return in_tree

    raise FileNotFoundError(
        f"Cannot locate shared asset {rel!r}. "
        f"Checked installed package resources (collimate/shared/{rel}, "
        f"collimate/demo/{rel}) and in-tree paths "
        f"{_IN_TREE_SDK_ROOT / 'shared' / rel}, {_IN_TREE_SDK_ROOT / 'demo' / rel}."
    )


def shared_doc(name: str, near: str) -> Path:
    """Resolve an authoring how-to doc that's been seeded into the calling
    generator's cell as a plain ``_shared_docs/`` sibling.

    The canonical docs live in the SDK's ``shared/docs/`` tree — the
    authoring source, linked from the project README and browsable on
    GitHub. They are NOT read from there at run time. Instead the collimate
    app's genesis seeding copies the docs named in ``releases.yaml``'s
    ``cells[].shared_docs`` into the cell, and the run host co-locates the
    resulting ``_shared_docs/`` folder next to the generator — the same
    ``_*``-sibling mechanism any shared package uses (e.g.
    ``_playwright_shared``; see the app's runs/helpers._find_generator_dir
    and runs/create.py). So at run time the doc is an ordinary cell-local
    file at the parent-of-parent of the entrypoint's ``__file__``
    (``app_dir/_shared_docs/<name>``). No special wheel lookup.

    Pass ``near=__file__`` from the calling generator. Raises
    ``FileNotFoundError`` when the doc wasn't seeded alongside the generator
    — a cell that wants a builder must include the doc as a sibling, exactly
    as a cell using ``_playwright_shared`` must include that package.
    """
    local = Path(near).resolve().parent.parent / "_shared_docs" / name
    if local.is_file():
        return local
    raise FileNotFoundError(
        f"Shared doc {name!r} not found at {local}. It must be seeded into "
        f"the cell's _shared_docs/ (declared in releases.yaml as "
        f"cells[].shared_docs)."
    )
