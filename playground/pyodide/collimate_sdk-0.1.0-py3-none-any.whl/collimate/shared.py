# SPDX-License-Identifier: Apache-2.0
"""Locate files under the SDK's top-level ``shared/`` tree at runtime.

The ``shared/`` directory lives at the repo root (sibling of
``generators/``, ``renderers/``, ``src/``). It currently holds the
authoring how-to docs (``shared/docs/*.md``) but is the landing spot
for any cross-cutting, non-Python asset the SDK wants to expose to
generators, renderers, or external tooling.

Two resolution paths, same pattern as ``collimate.packaging.vendor_defaults``:

1. Installed wheel — ``importlib.resources.files("collimate") / "shared" / ...``.
   Requires ``pyproject.toml`` to force-include ``shared/`` into the
   wheel's package data (``[tool.hatch.build.targets.wheel.force-include]``).

2. In-tree source / editable checkout — fall through to the SDK repo
   root (computed from this file's location) and join ``shared/`` + the
   requested segments.

Callers should not assume the path is always on the real filesystem —
``importlib.resources`` may materialize content from a zip. Use
``shared_path(...).read_text()`` / ``.read_bytes()`` instead of passing
the path to another process.
"""
from __future__ import annotations

from importlib.resources import as_file, files
from pathlib import Path


_IN_TREE_SDK_ROOT = Path(__file__).resolve().parents[2]


def shared_path(*segments: str) -> Path:
    """Resolve a path inside the SDK's ``shared/`` directory.

    Raises ``FileNotFoundError`` with both attempted locations in the
    message when neither lookup finds the asset.

    Example:
        >>> shared_path("docs", "how-to-write-a-generator.md").read_text()[:20]
        '# How to write a gen'
    """
    rel = "/".join(segments)

    # 1. Installed wheel — importlib.resources.
    try:
        installed = files("collimate").joinpath("shared", *segments)
        with as_file(installed) as p:
            if p.exists():
                return Path(p)
    except (ModuleNotFoundError, FileNotFoundError):
        pass

    # 2. In-tree / editable checkout.
    in_tree = _IN_TREE_SDK_ROOT / "shared" / rel
    if in_tree.exists():
        return in_tree

    raise FileNotFoundError(
        f"Cannot locate shared asset {rel!r}. "
        f"Checked installed package resources (collimate/shared/{rel}) "
        f"and in-tree path {in_tree}."
    )
