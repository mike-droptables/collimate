# Collimate SDK authoring docs

The reference library for the SDK: what Collimate is, and how to author
generators and renderers against it. The bundled `guide` generator (the
in-app orientation + docs Q&A + builder chat) reads these from its
cell-local `_shared_docs/` sibling — seeded there from this tree by
genesis (`releases.yaml` `cells[].shared_docs`) — so whatever's here
ships as the canonical reference to the LLM prompt.

- **[collimate-overview.md](./collimate-overview.md)** —
  what Collimate is: vision & philosophy, core concepts, and a UI tour.
- **[how-to-write-a-generator.md](./how-to-write-a-generator.md)** —
  native Python generators (subprocess / Docker).
- **[how-to-write-a-renderer.md](./how-to-write-a-renderer.md)** —
  browser-side ES-module renderers.
- **[authoring-best-practices.md](./authoring-best-practices.md)** —
  the house style, distilled from the packaged generator/renderer set.
- **[testing-generators.md](./testing-generators.md)** —
  running generators host-free + compile-checking renderers.
- **[api-reference.md](./api-reference.md)** —
  tabular `gen.*` / manifest cross-reference.

The demo/playground (WASM) authoring guide is quarantined under
[`../../demo/docs/`](../../demo/docs/) — see `demo/README.md`.

Resolve a path programmatically via `from collimate.shared import shared_path`:

```python
from collimate.shared import shared_path
text = shared_path("docs", "how-to-write-a-generator.md").read_text()
```

The helper works both from an installed wheel (via `importlib.resources`)
and from an editable / source checkout.
