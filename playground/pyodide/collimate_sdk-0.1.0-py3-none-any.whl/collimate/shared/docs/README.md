# Collimate SDK authoring docs

Guides for authoring generators and renderers against the SDK. The
bundled builder generators (`Standard/generator_builder`,
`Standard/renderer_builder`, and their `WASM/` mirrors) load these at
runtime via `collimate.shared.shared_path`, so whatever's here ships
as the canonical reference to the LLM prompt.

- **[how-to-write-a-generator.md](./how-to-write-a-generator.md)** —
  native Python generators (subprocess / Docker).
- **[how-to-write-a-renderer.md](./how-to-write-a-renderer.md)** —
  browser-side ES-module renderers.
- **[how-to-write-a-wasm-generator.md](./how-to-write-a-wasm-generator.md)** —
  Pyodide-safe generators for the playground.

Resolve a path programmatically via `from collimate.shared import shared_path`:

```python
from collimate.shared import shared_path
text = shared_path("docs", "how-to-write-a-generator.md").read_text()
```

The helper works both from an installed wheel (via `importlib.resources`)
and from an editable / source checkout.
