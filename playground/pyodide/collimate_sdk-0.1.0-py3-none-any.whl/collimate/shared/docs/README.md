# Collimate SDK authoring docs

Guides for authoring generators and renderers against the SDK. The
bundled builder generators (`generator_builder`, `renderer_builder`)
load these at runtime via `collimate.shared.shared_path`, so whatever's
here ships as the canonical reference to the LLM prompt.

- **[how-to-write-a-generator.md](./how-to-write-a-generator.md)** —
  native Python generators (subprocess / Docker).
- **[how-to-write-a-renderer.md](./how-to-write-a-renderer.md)** —
  browser-side ES-module renderers.
- **[testing-generators.md](./testing-generators.md)** —
  running generators host-free + compile-checking renderers.
- **[api-reference.md](./api-reference.md)** —
  tabular `gen.*` / manifest cross-reference.

The demo/playground (WASM) authoring guide is quarantined under
[`../../demo/docs/`](../../demo/docs/) — see `demo/README.md`.

Resolve a path programmatically via `from collimate.shared import shared_path`:

```python
from collimate.shared import shared_path
text = shared_path("docs", "how-to-write-a-generator.md").read_text()
```

The helper works both from an installed wheel (via `importlib.resources`)
and from an editable / source checkout.
