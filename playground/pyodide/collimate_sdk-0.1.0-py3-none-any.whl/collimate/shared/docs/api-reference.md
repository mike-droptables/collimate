# API Reference

Snapshot of every manifest field and every public SDK function exported by Collimate. This is a sibling to the canonical authoring docs (`how-to-write-a-generator.md`, `how-to-write-a-renderer.md`); read those for examples and idioms — this one is the tabular cross-reference.

---

## Section 1 — Generator manifest (`manifest.gen_yaml`)

### Top-level scalar fields

| Field | Type | Required | Default | Description |
|---|---|---|---|---|
| `id` | string | Yes | — | Unique identifier (lowercase, hyphenated). |
| `name` | string | Yes | — | Display name in the picker. |
| `entrypoint` | string | Yes | — | Path to the Python script. Must exist on disk. |
| `summary` | string | Yes | — | 1–2 sentence picker description. Errors when missing/empty; warns when > 2 sentences. |
| `type` | list[`modify` \| `create`] | Yes | — | List of 1–2 invocation modes the generator supports. Host injects the user-picked mode as `gen.invocation_type`. |
| `version` | string | No | — | Semver, informational. |
| `prompt_intent` | string | No | — | Hint shown above the picker textarea. |
| `chat` | bool | No | `false` | Long-lived conversational run; implies daemon behaviour. |
| `daemon` | bool | No | `false` | Long-running non-chat daemon (port-serving, terminal). |
| `ephemeral` | bool | No | `false` | Throwaway live session (e.g. a browser); its output cell never enters DAG history and offers "close" (stop + remove) instead of "stop". |
| `live_files_mode` | string | No | — | Opt-in for mid-run cell-file editing. Only recognised value: `"live_files"`. |

### Nested: `inputs.cells`

Constraints depend on `type`. For `create`, the bounds also pick the input
shape: no input (`min == max == 0`), a single cell (`min == max == 1`), or a
stack (e.g. `min` 1/2, `max` 99; `min` may be 0 for an optional stack).

| Field | Type | Required | Description |
|---|---|---|---|
| `inputs.cells.min` | int | No (rules below) | Minimum input cells. `"create" in type` requires `>= 0`. `"modify" in type` requires `<= 1`. |
| `inputs.cells.max` | int | No | Maximum input cells. `"modify" in type` requires `>= 1` (so the bounds include the single current cell). |

Per-mode rules:
- `"modify" in type` — `inputs.cells` bounds must include 1 (`min <= 1 <= max`); the input is exactly the current cell.
- `"create" in type` — `inputs.cells.min >= 0`; the bounds choose the shape (no input, a single cell, or a stack).
- When both modes co-exist, both per-mode rules must hold simultaneously.

### List fields

| Field | Type | Required | Description |
|---|---|---|---|
| `draft_files` | list[string] | No | Files seeded into the workspace before run. Warns if a path doesn't exist. |

### Host-side subprocess controls

| Field | Type | Required | Description |
|---|---|---|---|
| `rlimits` | mapping | No | RLIMIT caps for native generators. Recognised keys: `memory_bytes` (RLIMIT_AS), `cpu_seconds` (RLIMIT_CPU), `open_files` (RLIMIT_NOFILE). Values must be positive integers. |
| `env_passthrough` | list[string] | No | Env vars that survive the per-subprocess scrub (e.g. `SSH_AUTH_SOCK`). Warns when an entry name matches `(?i)KEY|TOKEN|SECRET|PASSWORD` (route those through `gen.secret`/`gen.api_key`). |

### Removed (do not use)

`runtime`, `new_opt_in`, `default_route`, `summary_file`, `output.default`, `output.supports`, `execution_mode`, `live_chat_mode`, `output_mode`, `pinned`, `keys`, `parameters`, `pickoptions_file`, `settings_file`, `auto_dismiss_log`. Any of these in a manifest produces an `unknown-field` lint warning and is otherwise ignored.

---

## Section 2 — Renderer manifest (`manifest.rend_yaml`)

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | string | Yes | Unique identifier. |
| `name` | string | Yes | Display name (e.g. "HTML Renderer"). |
| `entrypoint` | string | Yes | Path to the entry module (`.tsx` / `.ts` / `.js`). Must exist. |
| `summary` | string | Yes | 1–2 sentence description. Errors when missing/empty; warns when > 2 sentences. |
| `version` | string | No | Semver, informational. |
| `embed` | enum: `native` \| `iframe` | No | `native` = Shadow DOM (inline styles only); `iframe` = sandboxed iframe (any CSS). |
| `extensions` | list[string] | No | File extensions this renderer handles. Each must start with `.` (error otherwise). |
| `supports_diff` | bool | No | True if the renderer provides a before/after diff view. |

---

## Section 3 — Python SDK (`gen.*`)

The runtime API is exposed by **`src/collimate/native.py`** behind the
top-level `gen` import (subprocess + workspace filesystem).

The `Tier` column marks capability scope:
- `A` — core API available to every generator.
- `B-native` — native-only features that need a subprocess, ports, terminals, or Docker.

(A demo/playground WASM runtime mirrors a subset of this surface; its deltas —
the CORS-safe provider set and the in-browser `python_tool_inline` / `bootstrap`
helpers — are documented separately in `demo/docs/wasm-api-delta.md`, not here.)

### Module-level dynamic attributes

| Attribute | Tier | Returns | Description |
|---|---|---|---|
| `gen.prompt` | A | str | Current run's user prompt. |
| `gen.messages` | A | list | Snapshot of current run's chat messages. |
| `gen.cancelled` | A | bool | True after the user hits Stop. |
| `gen.invocation_type` | A | str | One of `"modify" \| "create"` — the mode the user selected. Empty string if unset (legacy / dev). |

### Inputs

| Function | Tier | Signature | Description |
|---|---|---|---|
| `read_input` | A | `(path: str) -> str \| bytes` | Read a file from the input/parent cell. Returns `str` when utf-8 decodable, else `bytes`. |
| `input_files` | A | `() -> dict[str, str \| bytes]` | All input-cell files keyed by relpath. |
| `input_groups` | A | `() -> dict[str, dict[str, str \| bytes]]` | Multi-cell inputs grouped by source cell (`inputs/NN_slug/...`). |
| `config` | A | `(name: str) -> dict` | Parse a `draft_files` entry (YAML / JSON). Always returns a dict; `{}` on missing/malformed/non-dict content. |

### Output stage

| Function | Tier | Signature | Description |
|---|---|---|---|
| `update_file` | A | `(path: str, content: str \| bytes) -> None` | Stage a write to the output cell. |
| `read_file` | A | `(path: str) -> str \| bytes` | Read from the output stage. Raises `FileNotFoundError` if missing. |
| `has_file` | A | `(path: str) -> bool` | Predicate over the output stage. |
| `list_files` | A | `() -> list[str]` | Sorted list of staged paths. |
| `delete_file` | A | `(path: str) -> None` | Drop a path from the stage. |

### Cell operations

| Function | Tier | Signature | Description |
|---|---|---|---|
| `update` | A | `async (*, name=None, summary=None, pinned=None) -> None` | Flush stage to the placeholder/top cell. May be called many times. |
| `create_stack_cell` | A | `async (name, *, summary=None, pinned=None, files: dict[str, str \| bytes] \| None = None) -> str` | Add a new cell to the right-side stack. Returns the new cell id. |

### Live chat (`gen.serve_chat` / `ChatTurn`)

Serving a streaming chat is native-only — the WASM runtime can't hold a live WebSocket session.

| Function / member | Tier | Signature | Description |
|---|---|---|---|
| `serve_chat` | B-native | `async (on_turn, *, label="Live Chat", log_file="conversation.chatlog", live_file="conversation.chatlive", resume=True) -> None` | Serve a live streaming chat until Stop; dispatch each inbound message to `on_turn(turn)`. |
| `agent_chat_turn` | B-native | `async (turn, agent_obj, *, message_history=None, on_cancel_text=…, cancel_poll_interval_s=0.2) -> str` | Drive one streaming pydantic-ai turn against a `ChatTurn`, with retry + cancellation polling. |
| `emit_stream_event` | B-native | `(turn_id: str, event: dict) -> None` | Fire-and-forget push of a typed stream event to the live chat renderer. |
| `ChatTurn` | B-native | attrs `user_msg`, `turn_id`, `history`, `cancelled`, `redirect`; methods `emit(event)` / `delta(text)` / `tool(name, status, **kw)` | The turn object handed to `on_turn`. |

### Chat history (`gen.history`)

`append`, `seed_from_chatlog`, iteration, indexing, `as_pai()`. The in-memory transcript is persisted to a visible `.chatlog` text file via the output stage.

| Member | Tier | Signature | Description |
|---|---|---|---|
| `history.append` | A | `(role: str, content: str) -> None` | Append a message; rewrites the `.chatlog` artifact for the next `update()`. |
| `history.seed_from_chatlog` | B-native | `(path: str \| None = None) -> bool` | Reload history from an existing `.chatlog` (the `serve_chat` resume path); True when one was found. |
| `history.as_pai` | A | `() -> list[pydantic_ai.ModelMessage]` | Translate history to pydantic_ai messages. |
| `history.__iter__` / `__len__` / `__getitem__` | A | iteration helpers | Walk the raw `Message` list. |

### Secrets

| Function | Tier | Signature | Description |
|---|---|---|---|
| `api_key` | A | `async (provider, *, force=False, description="") -> str` | Resolve the API key for a provider (sets the standard env var) with a concurrency lock; pops the in-cell modal when unset. |
| `secret` | A | `async (name, *, prompt_if_missing=False, description="") -> str` | Read a non-LLM secret. Default = env-var only; opt-in modal. |

### Status / control

| Function | Tier | Signature | Description |
|---|---|---|---|
| `log` | A | `(line: str) -> None` | Append a line to the run log. |
| `status` | A | `(msg: str) -> None` | Set the live status string. |

### LLM convenience

| Function | Tier | Signature | Description |
|---|---|---|---|
| `agent` | A | `async (*, system_prompt="", tools=None, output_type=None, provider=None, model=None, max_tokens=None, config_file="pydantic-config.set_yaml")` | Returns an `_AutoRetryAgent` (auth-retry wrapper) reading provider/model/max_tokens from the config file when not overridden. |
| `file_tools` | A | `() -> list[pydantic_ai.Tool]` | `list_files`/`read_file`/`write_file`/`edit_file` tools. Returns `str` to the agent; binary files yield a `BINARY (N bytes) — read via the Python tool to inspect.` placeholder. |
| `python_tool` | B-native | `(*, timeout=60, default_packages=None)` | Subprocess runner + workspace snapshot diff. |

### Tier B (native-only)

| Function | Tier | Description |
|---|---|---|
| `workspace_path` | B-native | Real filesystem path to the workspace (for Docker mounts, child cwd). |
| `progress` | B-native | Live progress-bar update. |
| `serve_port` | B-native | Bind a port for daemon generators; host opens a sandbox iframe. |
| `run_subprocess` | B-native | Spawn a subprocess and stream output. Cooperative cancellation via `gen.cancelled`. Output-routing kwargs `turn_id`, `emit_bash_stdout`, `emit_text_delta`, `print_stdout` control which UI surfaces see the stream (terminal block, chat stream, local stdout). |
| `snapshot` | B-native | `{relpath: sha256_hex}` for every workspace file. |
| `terminal` | B-native | Allocate a WebSocket-backed PTY in a container. |
| `stop_terminal` | B-native | Tear down a terminal. Idempotent. |
| `wait_for_action` | B-native | Block until a renderer emits an action, timeout, or Stop. |
| `request_settings` | B-native | Pop a `.set_yaml` settings overlay mid-run. |

### Lifecycle entrypoint

| Function | Tier | Description |
|---|---|---|
| `main` | B-native | Construct IPC bridge, hydrate singleton, dispatch `run_fn` (sync or async), auto-flush pending writes, emit finish IPC. |

### Public exceptions

| Name | Tier | Description |
|---|---|---|
| `Cancelled` | A | Raised on user Stop. |
| `IPCError`, `IPCNakError`, `IPCTimeoutError`, `IPCDisconnectedError` | B-native | IPC-protocol failures. |

### Composition + renderer compile

Host-backed; available to **every** generator (the builders use the same
surface). In dev mode (no host) they degrade to a clean `ok=False` / empty
result — never hang, never raise.

| Function | Tier | Signature | Description |
|---|---|---|---|
| `generators` | B-native | `(*, group=None) -> list[GeneratorInfo]` | List installed generators (host-backed; `[]` in dev). |
| `inline` | A | `(files, *, entrypoint) -> Source` | Wrap a staged file set as a spawnable (uninstalled) source. |
| `spawn` | B-native | `(source, *, inputs=None, input_groups=None, prompt="", invocation_type="create", config=None, secrets=None, surface=None) -> GeneratorHandle` | Start a parent-bound child sub-run; returns a live handle. Invisible unless `surface` is set. `source` is an installed id or `inline(...)`. |
| `call` | B-native | `async (source, *, …, timeout=300.0) -> GeneratorResult` | Sugar for the terminating case: `spawn` + `wait` + `stop`. `ok=False` on child failure. |
| `check_renderer` | B-native | `(files, *, entrypoint) -> RendererCheck` | Compile-check a renderer via the host's esbuild. |

`GeneratorHandle` (returned by `spawn`): `await endpoints(*, wait=True, timeout=30.0) -> list[Endpoint]`, `await status() -> str`, `await files() -> dict`, `await wait(*, timeout=None) -> GeneratorResult`, `await stop()` (idempotent), `await surface(spec) -> cell_id`, and async-context (`async with … as h:` stops on exit). Children are **parent-bound** — stopped when the parent run ends.

### Environments (drive a child runtime)

An environment is a daemon generator (`environment:` in the manifest) that owns a
runtime and serves a parent. The SDK is Docker-free; the container-owning code is
the `_env_shared.DockerEnvironment` helper (shared *generator* code, a `_*`
sibling like `_cdp_shared` — not part of `collimate`). The host never learns a
container id.

| Function | Tier | Signature | Description |
|---|---|---|---|
| `serve_environment` | B-native | `async (*, on_exec=None, on_exec_background=None, on_expose_port=None, on_terminal=None, on_wait_process=None, on_stop_process=None, max_concurrency=1)` | The environment-author serve loop; blocks until Stop. Each handler takes a `Request` and returns its result. `DockerEnvironment.serve()` fills it. |

`GeneratorHandle` environment verbs (the worker side). **Workspace plane**
(host-serviced, guaranteed): `await put_files(map)`, `await write_file(path, content)`,
`await read_file(path)`, `await delete_file(path)`, `await list_files() -> list`,
`await snapshot() -> dict`, `watch_files()` (async iterator). **Execution plane**
(routed to the env): `await exec(cmd, *, cwd=None, env=None, timeout=120) -> (rc, output)`,
`await exec_background(cmd) -> ProcessHandle`, `await expose_port(port) -> Endpoint`,
`await open_terminal(cmd) -> {session_id, ws_path, token}`, `await capabilities() -> EnvironmentSpec | None`.
`ProcessHandle`: `await wait(*, timeout=None) -> int`, `await stop()`.

`_env_shared.DockerEnvironment(*, image, mount="/work", mount_mode="rw",
workspace=None, build_context=None, environment=None, ports=None, volumes=None,
command="sleep infinity")` — shared generator code, imported as a `_*` sibling:
`.container` / `.container_id`, `.exec`, `.exec_background`, `.wait_process`,
`.stop_process`, `.expose_port`, `.open_terminal`, `.surface_terminal`,
`.close()`, `await .serve()`.

### Result / spec types (`gen.*`, shared with `collimate.testing`)

| Type | Fields |
|---|---|
| `GeneratorResult` | `ok, files, name, summary, cells: list[CellRecord], endpoints: list[Endpoint], tier_b_calls, logs, status, error, traceback`; `.raise_for_status()` |
| `GeneratorInfo` | `id, name, summary, group, type, daemon, chat, ephemeral, min_inputs, max_inputs, prompt_intent, prompt_required, environment: EnvironmentSpec\|None` |
| `EnvironmentSpec` | `exec, exec_background, expose_port, files ("read-write"\|"none"), terminals: int, watch, concurrent_exec` |
| `Request` | `kind, command, cwd, env, port, process_id, timeout` (handed to `serve_environment` handlers) |
| `CellRecord` | `kind ("update"\|"stack"), name, summary, pinned, files` |
| `Endpoint` | `kind ("http"\|"terminal"), name, url, port, path, session_id` |
| `RendererCheck` | `ok, errors: list[str], warnings: list[str]` |

---

## Section 4 — React renderer-hooks SDK (`@collimate/renderer-hooks`)

Source: `packages/renderer-hooks/src/index.tsx`.
Authoritative copy served by the platform at `/api/sdk/react.js`; this package is the spec + out-of-sandbox artifact.

| Hook / Export | Signature | Description |
|---|---|---|
| `tokens` | `Readonly<{ color, font, radius }>` (frozen) | Design tokens as `var(--*)` CSS custom-property strings. Pierces shadow DOM. |
| `useTheme` | `(api: ThemeApi \| null \| undefined) => ThemeHandle` | `{ scheme, onChange }` — current light/dark scheme + subscribe helper. |
| `useDebouncedSaveContent` | `(saveContent: (next: string) => void, delay?: number = 350) => (next: string) => void` | Debounced wrapper with timer cleanup. |
| `useRemoteModule` | `<T = unknown>(url: string) => RemoteModuleState<T>` | Dynamic ESM loader with module-level dedupe / cache. |
| `useRemoteScript` | `(url: string) => RemoteScriptState` | Dynamic `<script>` tag loader with dedupe (for UMD bundles like the monaco loader). |

### Public types

| Type | Description |
|---|---|
| `Scheme` | `'light' \| 'dark'` |
| `ThemeApi` | Host-provided `{ getTheme?, onThemeChange? }`. |
| `ThemeHandle` | `{ scheme, onChange }` returned by `useTheme`. |
| `RemoteModuleState<T>` | `{ module: T \| null, loading, error }`. |
| `RemoteScriptState` | `{ loading, error }`. |
