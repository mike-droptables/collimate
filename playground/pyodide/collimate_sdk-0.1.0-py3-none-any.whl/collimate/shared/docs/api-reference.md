# API Reference

Snapshot of every manifest field and every public SDK function exported by Collimate. This is a sibling to the canonical authoring docs (`how-to-write-a-generator.md`, `how-to-write-a-renderer.md`); read those for examples and idioms — this one is the tabular cross-reference.

---

## Section 1 — Generator manifest (`manifest.gen_yaml`)

### Top-level scalar fields

| Field | Type | Required | Default | Description |
|---|---|---|---|---|
| `id` | string | Yes | — | Unique identifier (lowercase, hyphenated). |
| `name` | string | Yes | — | Display name in the picker. |
| `entrypoint` | string | Yes | — | Path to the Python script. Must exist on disk. |
| `summary` | string | Yes | — | 1–2 sentence picker description. Errors when missing/empty; warns when > 2 sentences. |
| `type` | list[`modify` \| `create`] | Yes | — | List of 1–2 invocation modes the generator supports. Host injects the user-picked mode as `gen.invocation_type`. |
| `version` | string | No | — | Semver, informational. |
| `prompt_intent` | string | No | — | Hint shown above the picker textarea. |
| `chat` | bool | No | `false` | Long-lived conversational run; implies daemon behaviour. |
| `daemon` | bool | No | `false` | Long-running non-chat daemon (port-serving, terminal). |
| `ephemeral` | bool | No | `false` | Throwaway live session (e.g. a browser); its output cell never enters DAG history and offers "close" (stop + remove) instead of "stop". |
| `available_ui` | bool | No | `true` | Picker-visibility baseline: appear in the human picker. Set `false` for a composition-only generator (hidden from humans but still callable by other generators, like `agent`). A per-channel on/off switch overrides this baseline. Callability by other generators is NOT a manifest/per-generator flag — it follows the source cell's "expose to generators" setting (see below). |
| `live_files_mode` | string | No | `"none"` | Opt-in for mid-run, bidirectional cell ↔ workspace file editing. `"auto"` = the runtime runs `gen.live_files()` for the whole run (zero code); `"manual"` = files stay editable but you drive the sync yourself (`gen.live_files(...)` / `handle.mirror_files()`); `"none"`/omitted locks the Files tab while the run is in flight. |

### Nested: `inputs.cells`

Constraints depend on `type`. For `create`, the bounds also pick the input
shape: no input (`min == max == 0`), a single cell (`min == max == 1`), or a
stack (e.g. `min` 1/2, `max` 99; `min` may be 0 for an optional stack).

| Field | Type | Required | Description |
|---|---|---|---|
| `inputs.cells.min` | int | No (rules below) | Minimum input cells. `"create" in type` requires `>= 0`. `"modify" in type` requires `<= 1`. |
| `inputs.cells.max` | int | No | Maximum input cells. `"modify" in type` requires `>= 1` (so the bounds include the single current cell). |

Per-mode rules:
- `"modify" in type` — `inputs.cells` bounds must include 1 (`min <= 1 <= max`); the input is exactly the current cell.
- `"create" in type` — `inputs.cells.min >= 0`; the bounds choose the shape (no input, a single cell, or a stack).
- When both modes co-exist, both per-mode rules must hold simultaneously.

### List fields

| Field | Type | Required | Description |
|---|---|---|---|
| `draft_files` | list[string] | No | Files seeded into the workspace before run. Warns if a path doesn't exist. |

### Host-side subprocess controls

| Field | Type | Required | Description |
|---|---|---|---|
| `rlimits` | mapping | No | RLIMIT caps for native generators. Recognised keys: `memory_bytes` (RLIMIT_AS), `cpu_seconds` (RLIMIT_CPU), `open_files` (RLIMIT_NOFILE). Values must be positive integers. |
| `env_passthrough` | list[string] | No | Env vars that survive the per-subprocess scrub (e.g. `SSH_AUTH_SOCK`). Warns when an entry name matches `(?i)KEY|TOKEN|SECRET|PASSWORD` (route those through `gen.secret`/`gen.api_key`). |

### Removed (do not use)

`runtime`, `new_opt_in`, `default_route`, `summary_file`, `output.default`, `output.supports`, `execution_mode`, `live_chat_mode`, `output_mode`, `pinned`, `keys`, `parameters`, `pickoptions_file`, `settings_file`, `auto_dismiss_log`, `available_generators`. Any of these in a manifest produces an `unknown-field` lint warning and is otherwise ignored.

### Cell exposure ("expose to generators")

Callability + cross-cell read/write are governed at the **cell** level, not per generator. A generator- or renderer-source cell is "exposed to generators" (a per-channel switch in the management view, **exposed by default**). Exposing a cell lets other generators: run its generators (`gen.call` / `gen.spawn`), discover them (`gen.generators`), read its code (`gen.read_cell`), and edit it (`gen.write_cell`). A cell switched off is invisible and un-callable/un-readable. The hidden `agent` generator works because its cell is exposed by default.

---

## Section 2 — Renderer manifest (`manifest.rend_yaml`)

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | string | Yes | Unique identifier. |
| `name` | string | Yes | Display name (e.g. "HTML Renderer"). |
| `entrypoint` | string | Yes | Path to the entry module (`.tsx` / `.ts` / `.js`). Must exist. |
| `summary` | string | Yes | 1–2 sentence description. Errors when missing/empty; warns when > 2 sentences. |
| `version` | string | No | Semver, informational. |
| `embed` | enum: `native` \| `iframe` | No | `native` = Shadow DOM (inline styles only); `iframe` = sandboxed iframe (any CSS). |
| `extensions` | list[string] | No | File extensions this renderer handles. Each must start with `.` (error otherwise). |
| `supports_diff` | bool | No | True if the renderer provides a before/after diff view. |

---

## Section 3 — Python SDK (`gen.*`)

The runtime API is exposed by **`src/collimate/native.py`** behind the
top-level `gen` import (subprocess + workspace filesystem).

The `Tier` column marks capability scope:
- `A` — core API available to every generator.
- `B-native` — native-only features that need a subprocess, ports, terminals, or Docker.

(A demo/playground WASM runtime mirrors a subset of this surface; its deltas —
the CORS-safe provider set and the in-browser `python_tool_inline` / `bootstrap`
helpers — are documented separately in `demo/docs/wasm-api-delta.md`, not here.)

### Module-level dynamic attributes

| Attribute | Tier | Returns | Description |
|---|---|---|---|
| `gen.prompt` | A | str | Current run's user prompt. |
| `gen.messages` | A | list | Snapshot of current run's chat messages. |
| `gen.cancelled` | A | bool | True after the user hits Stop. |
| `gen.invocation_type` | A | str | One of `"modify" \| "create"` — the mode the user selected. Empty string if unset (legacy / dev). |

### Inputs

| Function | Tier | Signature | Description |
|---|---|---|---|
| `read_input` | A | `(path: str) -> str \| bytes` | Read a file from the input/parent cell. Returns `str` when utf-8 decodable, else `bytes`. |
| `input_files` | A | `() -> dict[str, str \| bytes]` | All input-cell files keyed by relpath. |
| `input_groups` | A | `() -> dict[str, dict[str, str \| bytes]]` | Multi-cell inputs grouped by source cell (`inputs/NN_slug/...`). |
| `config` | A | `(name: str) -> dict` | Parse a `draft_files` entry (YAML / JSON). Always returns a dict; `{}` on missing/malformed/non-dict content. |

### Output stage

| Function | Tier | Signature | Description |
|---|---|---|---|
| `update_file` | A | `(path: str, content: str \| bytes) -> None` | Stage a write to the output cell. |
| `read_file` | A | `(path: str) -> str \| bytes` | Read from the output stage. Raises `FileNotFoundError` if missing. |
| `has_file` | A | `(path: str) -> bool` | Predicate over the output stage. |
| `list_files` | A | `() -> list[str]` | Sorted list of staged paths. |
| `delete_file` | A | `(path: str) -> None` | Drop a path from the stage. |

### Cell operations

| Function | Tier | Signature | Description |
|---|---|---|---|
| `update` | A | `async (*, name=None, summary=None, pinned=None) -> None` | Flush stage to the placeholder/top cell. May be called many times. |
| `create_stack_cell` | A | `async (name, *, summary=None, pinned=None, files: dict[str, str \| bytes] \| None = None) -> str` | Add a new cell to the right-side stack. Returns the new cell id. |
| `start_modify_run` | B-native | `async (cell_id, generator, *, prompt=None) -> None` | One-shot handoff: start an independent `modify` run of `generator` on a cell THIS run just created via `create_stack_cell`. Fire-and-forget — no handle, no events, no status; each cell can be handed off at most once, and only `modify` is available (the target must declare it in its manifest `type`). Raises `RuntimeError` if the host refuses. |

### Live file sync

One echo-suppressed, bidirectional mirror engine, two entry points. Prefer the manifest's `live_files_mode: "auto"` (zero code) over calling these by hand.

| Function | Tier | Signature | Description |
|---|---|---|---|
| `live_files` | A | `(*, to_cell=True, from_cell=True, exclude=(), skip_dirs=None, interval=0.5) -> async-cm` | `async with`: live-sync this run's own workspace ↔ its cell (the Files tab), both ways. No-op without a host. `live_files_mode: "auto"` opens this for the whole run automatically. |
| `wait_until_cancelled` | A | `async (poll=0.5) -> None` | Park a daemon (terminal / served port / open `live_files` block) until the user stops the run. |

`handle.mirror_files(...)` (on a `spawn`ed `GeneratorHandle`) is the same engine across a spawn boundary — cell ↔ the child sub-run's workspace.

### Live chat (`gen.serve_chat` / `ChatTurn`)

Serving a streaming chat is native-only — the WASM runtime can't hold a live WebSocket session.

| Function / member | Tier | Signature | Description |
|---|---|---|---|
| `serve_chat` | B-native | `async (on_turn, *, label="Chat", threads_dir="chats", default_thread="main", resume=True, integration=None, pointer_file="conversation.chat") -> None` | Serve a live, multi-thread streaming chat until Stop; dispatch each inbound message to `on_turn(turn)`. Writes & pins the `.chat` session pointer (rendered by the assistant-ui renderer) and a per-thread open-format transcript at `<threads_dir>/<id>.json`. Threads are independent conversations sharing the cell's files; the renderer drives `thread_new`/`thread_switch`, plus the between-turn transcript curation commands `edit`/`delete`/`insert`/`move`/`regenerate` (applied to the durable transcript by serve_chat itself — no handler code needed). `integration` passes through to the pointer to pick the renderer's runtime — `None` = native streaming (ExternalStore over the WebSocket), a dict = a direct backend integration (e.g. the official opencode runtime). |
| `emit_stream_event` | B-native | `(turn_id: str, event: dict) -> None` | Fire-and-forget push of a typed stream event to the live chat renderer (the run→UI stream; `turn.delta`/`turn.tool` use it). |
| `emit_event` | B-native | `(event: dict) -> None` | Fire-and-forget push of a JSON-able event from this run to its **parent** generator (the run→parent stream — the twin of `emit_stream_event`). No-op when the run has no parent. Consumed by `GeneratorHandle.events()`. |
| `ChatTurn` | B-native | attrs `user_msg`, `turn_id`, `history`, `cancelled`, `redirect`; methods `emit(event)` / `delta(text)` / `tool(name, status, **kw)` | The turn object handed to `on_turn`. |

### Chat history (`gen.history`)

`append`, `switch_thread`, `seed`, iteration, indexing. The in-memory transcript is the ACTIVE thread, persisted to a visible open-format JSON file (`<threads_dir>/<thread>.json`; see `collimate.transcript` — OpenAI-compatible `{"messages":[{role,content}]}`).

| Member | Tier | Signature | Description |
|---|---|---|---|
| `history.append` | A | `(role: str, content: str) -> None` | Append a message to the active thread; rewrites its transcript for the next `update()`. |
| `history.switch_thread` | B-native | `(thread_id, *, threads_dir=None, load=True) -> None` | Make `thread_id` active and (by default) load its transcript. |
| `history.seed` | B-native | `() -> bool` | (Re)load the active thread's transcript from disk; True when one exists. |
| `history.__iter__` / `__len__` / `__getitem__` | A | iteration helpers | Walk the raw `Message` list. |

### Secrets

| Function | Tier | Signature | Description |
|---|---|---|---|
| `api_key` | A | `async (provider, *, force=False, description="") -> str` | Resolve the API key for a provider (sets the standard env var) with a concurrency lock; pops the in-cell modal when unset. |
| `secret` | A | `async (name, *, prompt_if_missing=False, description="") -> str` | Read a non-LLM secret. Default = env-var only; opt-in modal. |

### Status / control

| Function | Tier | Signature | Description |
|---|---|---|---|
| `log` | A | `(line: str) -> None` | Append a line to the run log (visible in the cell's log drawer). |
| `phase` | A | `(name: str, message: str = "") -> None` | Set the run's lifecycle phase (`spinning_up` / `running` / `finishing`) — drives the cell's loading-vs-running indicator. |
| `status` | A | `(msg: str) -> None` | Update the current phase's sub-message (sugar for `phase` with no phase change). |
| `progress` | B | `(current: int, total: int) -> None` | Emit a progress counter (native-only). |

### Running an LLM agent — the `agent` generator

There is **no** built-in LLM call in `gen.*`. Running an agent is a hidden,
composition-only generator with id `agent` that other generators reach via
`gen.call` (batch) / `gen.spawn` (streaming) — see "Composition" below. Your
generator has no pydantic-ai dependency; the `agent` generator owns the LLM
engine (three backends: pydantic-ai / claude-agent-sdk / gemini).

```python
# The parent-generator convention: a callee's settings come from ONE named
# config tag on that generator (a blank tag → its defaults); the caller
# overrides only what it has opinions about. Same pattern for any callee —
# e.g. code_runner resolves a linux_env_config_tag for gen.spawn("linux-env").
tag_values = gen.tag_config(
    "agent", gen.config("config.set_yaml").get("agent_config_tag"),
).get("agent-config.set_yaml", {})

from _agent_shared import oneshot_tag_values   # folds + VALIDATES the config you send
result = await gen.call("agent", inputs=files, prompt=msg, config={
    "agent-config.set_yaml": oneshot_tag_values(  # mode=oneshot; validates parent-side
        tag_values,                                # model/backend/auth/tokens from the tag
        system_prompt="...",
        enable_file_tools=True,     # read/write/edit the workspace
        enable_python_tool=True,    # run_python
        output_schema=MyModel.model_json_schema(),  # OPTIONAL structured output
        # ledger defaults OFF for composition; pass ledger=True to PROMOTE it
    )}, timeout=300)
text = result.output_text                    # assistant reply ("" if absent)
data = result.structured(MyModel)            # validated MyModel, or None (raises on bad shape)
led = result.files.get("_agent/assumptions.ledger")      # claimed/enacted record (with ledger=True)
# (also `_agent/trace.json` — the run's full-fidelity trace — and
# `_agent/assumptions.md`.) Promote the ledger into your output cell as
# `assumptions.ledger` so the .ledger renderer picks it up.
# edited/created files = result.files minus the "_agent/" bookkeeping prefix.
# FAN OUT with gen.call_many([...specs]) — NOT asyncio.gather over gen.call
# (that serializes on the IPC lock). One GeneratorResult per spec, in order.
```

For live streaming, `gen.spawn("agent", ..., config={"agent-config.set_yaml":
{..., "stream": True}})` and forward `handle.events()` (`text_delta` events) to
`turn.delta`. See `how-to-write-a-generator.md` → "Running an LLM agent".

### Tier B (native-only)

| Function | Tier | Description |
|---|---|---|
| `workspace_path` | B-native | Real filesystem path to the workspace (for Docker mounts, child cwd). |
| `progress` | B-native | Live progress-bar update. |
| `serve_port` | B-native | Bind a port for daemon generators; host opens a sandbox iframe. |
| `run_subprocess` | B-native | Spawn a subprocess and stream output. Cooperative cancellation via `gen.cancelled`. Output-routing kwargs `turn_id`, `emit_bash_stdout`, `emit_text_delta`, `print_stdout` control which UI surfaces see the stream (terminal block, chat stream, local stdout). |
| `snapshot` | B-native | `{relpath: sha256_hex}` for every workspace file. |
| `terminal` | B-native | Allocate a WebSocket-backed PTY in a container. Returns `{session_id, ws_path, token}`. Low-level — prefer `serve_terminal`. |
| `serve_terminal` | B-native | `async with gen.serve_terminal(container_id, command, *, cwd, env, label, pointer="app.terminal", buttons=None, name=None, summary=None) as session:` — allocate the PTY, write + pin its `.terminal` pointer (with optional toolbar `buttons`), and stop the session on exit. The one-stop terminal daemon surface. |
| `stop_terminal` | B-native | Tear down a terminal. Idempotent. (`serve_terminal` calls it for you.) |
| `wait_for_action` | B-native | Block until a renderer emits an action, timeout, or Stop. |
| `actions` | B-native | `async for action in gen.actions():` — yield renderer action ids (cell button clicks) until the run is stopped. The idiomatic daemon loop for a cell with `buttons`; no `while not gen.cancelled` bookkeeping. |
| `request_settings` | B-native | Pop a `.set_yaml` settings overlay mid-run. |

### Lifecycle entrypoint

| Function | Tier | Description |
|---|---|---|
| `main` | B-native | Construct IPC bridge, hydrate singleton, dispatch `run_fn` (sync or async), auto-flush pending writes, emit finish IPC. |

### Public exceptions

| Name | Tier | Description |
|---|---|---|
| `Cancelled` | A | Raised on user Stop. |
| `IPCError`, `IPCNakError`, `IPCTimeoutError`, `IPCDisconnectedError` | B-native | IPC-protocol failures. |

### Composition + renderer compile

Host-backed; available to **every** generator (the builders use the same
surface). In dev mode (no host) they degrade to a clean `ok=False` / empty
result — never hang, never raise.

| Function | Tier | Signature | Description |
|---|---|---|---|
| `generators` | B-native | `(*, group=None) -> list[GeneratorInfo]` | List installed, **exposed** generators (host-backed; `[]` in dev). Each carries the callee's config schema — see `GeneratorInfo`. |
| `generator_info` | B-native | `(gid) -> GeneratorInfo \| None` | One generator's introspection by id (sugar over `generators()`; no extra round-trip). |
| `tag_config` | B-native | `(gid, tag, *, overrides=None) -> dict` | A ready-made `config=` from a callee's named config tag, the caller's overrides winning key-by-key. Blank tag → overrides only; unknown tag/unreachable callee → `ValueError` naming the available tags. Backs the parent-generator convention (one `agent_config_tag` field instead of mirrored settings). |
| `inline` | A | `(files, *, entrypoint) -> Source` | Wrap a staged file set as a spawnable (uninstalled) source. |
| `spawn` | B-native | `(source, *, inputs=None, input_groups=None, prompt="", invocation_type="create", config=None, secrets=None, surface=None) -> GeneratorHandle` | Start a parent-bound child sub-run; returns a live handle. Invisible unless `surface` is set. `source` is an installed id or `inline(...)`. |
| `call` | B-native | `async (source, *, …, timeout=300.0) -> GeneratorResult` | Sugar for the terminating case: `spawn` + `wait` + `stop`. `ok=False` on child failure. |
| `call_many` | B-native | `async (specs, *, timeout=600.0, poll_interval=0.4, max_concurrent=None) -> list[GeneratorResult]` | CONCURRENT fan-out — one result per spec (each a `spawn` kwargs dict with `source`), in order. Use this, never `asyncio.gather(gen.call…)` (that serializes on the IPC lock). Per-item `ok=False` isolation; `gen.Cancelled` on a user stop; `max_concurrent` caps the spawn window. |
| `check_renderer` | B-native | `(files, *, entrypoint) -> RendererCheck` | Compile-check a renderer via the host's esbuild. |

### Cross-cell read / write (gated on cell exposure)

Introspect and edit OTHER source cells — only cells marked "expose to generators" (generator- AND renderer-source; exposed by default). Every `write_cell` commits a normal, undoable cell **version** (`source_type='generator_edit'`, visible in the history scrubber) AND applies to the cell's live state, so the edit takes effect on that cell's next run. Distinct from `read_cell_files` / `update`, which only ever touch THIS run's own cell. Host-backed; dev-mode safe.

| Function | Tier | Signature | Description |
|---|---|---|---|
| `exposed_cells` | B-native | `() -> list[dict]` | The exposed source cells you may read/write: `{cell_id, name, stack_type, generators:[id], files:[path]}`. |
| `read_cell` | B-native | `(cell_id) -> {path: str\|bytes}` | Full file tree of an exposed cell's current state. Raises `PermissionError` (not exposed) / `LookupError` (missing). |
| `write_cell` | B-native | `(cell_id, files, *, summary=None, deleted=None) -> version_id` | Commit a partial overlay as a new version. Raises `PermissionError` (not exposed) / `ValueError` (bad manifest or illegal path). |
| `add_generator` | B-native | `(cell_id, *, id, name, entrypoint, files, summary="", type=None, **manifest_fields) -> version_id` | Helper: build `<id>/manifest.gen_yaml` + write the generator's files under `<id>/`, then commit. |
| `add_renderer` | B-native | `(cell_id, *, id, name, entrypoint, files, summary="", extensions=None, **manifest_fields) -> version_id` | Helper (renderer twin of `add_generator`): build `<id>/manifest.rend_yaml` + write the renderer's files under `<id>/`, then commit. |
| `create_generator_cell` | B-native | `(name, *, files, summary=None, pinned=None) -> cell_id` | Create a brand-new generator SOURCE cell. `files` must include a valid `manifest.gen_yaml` + entrypoint. Committed as its first version, placed in the generator nav stack, and **exposed to generators immediately** so you can `read_cell`/`write_cell` it next. Distinct from `create_stack_cell` (a content cell in this run's right-side stack). Raises `ValueError` on missing/invalid manifest. |
| `create_renderer_cell` | B-native | `(name, *, files, summary=None, pinned=None) -> cell_id` | Renderer twin of `create_generator_cell`: `files` must include a valid `manifest.rend_yaml` + entrypoint. Same first-version commit + nav-stack placement + auto-exposure. |
| `set_config_tag` | B-native | `(cell_id, generator_id, tag, body, *, summary=None) -> version_id` | Helper: add/replace one config tag in a generator's manifest. |
| `delete_config_tag` | B-native | `(cell_id, generator_id, tag, *, summary=None) -> version_id` | Helper: remove one config tag (raises `KeyError` if absent). |

`GeneratorHandle` (returned by `spawn`): `events(*, poll_interval=0.1, idle_timeout=None)` (async iterator yielding the child's `gen.emit_event` dicts in order until it finishes — the run→parent streaming channel), `stream_text(*, poll_interval=0.1, idle_timeout=None)` (async iterator of just the child's `text_delta` chunks — sugar over `events()` so streaming a sub-run agent's reply to `turn.delta` is one loop), `mirror_files(*, to_cell=True, from_cell=True, exclude=(), interval=0.5)` (an `async with` block that live-syncs the cell ↔ sub-run workspace BOTH ways for its lifetime — echo-suppressed, with a final reconcile; the easy way to do `live_files` across a spawn), `await endpoints(*, wait=True, timeout=30.0) -> list[Endpoint]`, `await status() -> str`, `await files() -> dict`, `await wait(*, timeout=None) -> GeneratorResult`, `await stop()` (idempotent), `await surface(spec) -> cell_id`, and async-context (`async with … as h:` stops on exit). Children are **parent-bound** — stopped when the parent run ends. The workspace plane (`put_files`/`read_file`/`files`/`snapshot`/`watch_files`) is also available if you want to drive the sync by hand.

### Environments (drive a child runtime)

An environment is a daemon generator (`environment:` in the manifest) that owns a
runtime and serves a parent. The SDK is Docker-free; the container-owning code is
the `_env_shared.DockerEnvironment` helper (shared *generator* code, a `_*`
sibling like `_cdp_shared` — not part of `collimate`). The host never learns a
container id.

| Function | Tier | Signature | Description |
|---|---|---|---|
| `serve_environment` | B-native | `async (*, on_exec=None, on_exec_background=None, on_expose_port=None, on_terminal=None, on_wait_process=None, on_stop_process=None, max_concurrency=1)` | The environment-author serve loop; blocks until Stop. Each handler takes a `Request` and returns its result. `DockerEnvironment.serve()` fills it. |

`GeneratorHandle` environment verbs (the worker side). **Workspace plane**
(host-serviced, guaranteed): `await put_files(map)`, `await write_file(path, content)`,
`await read_file(path)`, `await delete_file(path)`, `await list_files() -> list`,
`await snapshot() -> dict`, `watch_files()` (async iterator). **Execution plane**
(routed to the env): `await exec(cmd, *, cwd=None, env=None, timeout=120) -> (rc, output)`,
`await exec_background(cmd) -> ProcessHandle`, `await expose_port(port) -> Endpoint`,
`await open_terminal(cmd) -> {session_id, ws_path, token}`, `await capabilities() -> EnvironmentSpec | None`.
`ProcessHandle`: `await wait(*, timeout=None) -> int`, `await stop()`.

`_env_shared.DockerEnvironment(*, image, mount="/work", mount_mode="rw",
workspace=None, build_context=None, environment=None, ports=None, volumes=None,
command="sleep infinity")` — shared generator code, imported as a `_*` sibling:
`.container` / `.container_id`, `.exec`, `.exec_background`, `.wait_process`,
`.stop_process`, `.expose_port`, `.open_terminal`, `.surface_terminal`,
`.close()`, `await .serve()`.

### Result / spec types (`gen.*`, shared with `collimate.testing`)

| Type | Fields |
|---|---|
| `GeneratorResult` | `ok, files, name, summary, cells: list[CellRecord], endpoints: list[Endpoint], tier_b_calls, logs, status, error, traceback`; `.raise_for_status()`; `.output_text` (agent reply from `_agent/output.md`); `.structured(model=None)` (parse `_agent/output.json` → validated `model` / `None` if absent) |
| `GeneratorInfo` | `id, name, summary, group, type, daemon, chat, ephemeral, min_inputs, max_inputs, prompt_intent, prompt_required, environment: EnvironmentSpec\|None, cell_id, description, draft_files: list[DraftFileSchema], config_tags: list[ConfigTag]` |
| `DraftFileSchema` | `path, fields: list[ConfigField]` — one `.set_yaml` draft file's schema |
| `ConfigField` | `key, type, label, description, required, default, options: list` — one `.set_yaml` field |
| `ConfigTag` | `name, prompt, values: {set_yaml_rel: {field_key: value}}` — a named preset; `.values` is a ready-made `config=` overlay for `gen.call`/`gen.spawn` |
| `EnvironmentSpec` | `exec, exec_background, expose_port, files ("read-write"\|"none"), terminals: int, watch, concurrent_exec` |
| `Request` | `kind, command, cwd, env, port, process_id, timeout` (handed to `serve_environment` handlers) |
| `CellRecord` | `kind ("update"\|"stack"), name, summary, pinned, files` |
| `Endpoint` | `kind ("http"\|"terminal"), name, url, port, path, session_id` |
| `RendererCheck` | `ok, errors: list[str], warnings: list[str]` |

---

## Section 4 — React renderer-hooks SDK (`@collimate/renderer-hooks`)

Source: `packages/renderer-hooks/src/index.tsx`.
Authoritative copy served by the platform at `/api/sdk/react.js`; this package is the spec + out-of-sandbox artifact.

| Hook / Export | Signature | Description |
|---|---|---|
| `tokens` | `Readonly<{ color, font, radius }>` (frozen) | Design tokens as `var(--*)` CSS custom-property strings. Pierces shadow DOM. |
| `useTheme` | `(api: ThemeApi \| null \| undefined) => ThemeHandle` | `{ scheme, onChange }` — current light/dark scheme + subscribe helper. |
| `useDebouncedSaveContent` | `(saveContent: (next: string) => void, delay?: number = 350) => (next: string) => void` | Debounced wrapper with timer cleanup. |
| `useRemoteModule` | `<T = unknown>(url: string) => RemoteModuleState<T>` | Dynamic ESM loader with module-level dedupe / cache. |
| `useRemoteScript` | `(url: string) => RemoteScriptState` | Dynamic `<script>` tag loader with dedupe (for UMD bundles like the monaco loader). |

### Public types

| Type | Description |
|---|---|
| `Scheme` | `'light' \| 'dark'` |
| `ThemeApi` | Host-provided `{ getTheme?, onThemeChange? }`. |
| `ThemeHandle` | `{ scheme, onChange }` returned by `useTheme`. |
| `RemoteModuleState<T>` | `{ module: T \| null, loading, error }`. |
| `RemoteScriptState` | `{ loading, error }`. |
