# Authoring best practices — lessons from the packaged set

The generators and renderers that ship in the default bundles
(`starting.colgen` / `starting.colrend` — `agent`, `browser_live`,
`vscode_env`, `run_terminal`, `linux_env`, `code_runner`, `git_clone`,
`modify_files`, and the `basic/` renderers) encode a house style. This file
distills it into rules. When scaffolding new work, follow these on top of the
contracts in `how-to-write-a-generator.md` / `how-to-write-a-renderer.md`.

The meta-rule running through everything: **defaults must make the artifact
work with zero edits; every degradation is logged with the user-facing fix in
the message; every non-obvious line carries the failure it prevents as a
comment; and shared behavior is hoisted into one helper the moment a second
consumer appears.**

## Manifests

- **Declare the input shape honestly** and let it drive behavior:
  `{min: 0, max: 0}` for pure creators (`git_clone`), `{min: 1, max: 1}` for
  single-cell modifiers (`run_terminal`), `{min: 1, max: 99}` for fan-out
  (`modify_files`: 1 input edits in place, 2+ fans out one stack cell each),
  `{min: 0, max: 1}` for optional context (`agent`).
- **`type` matches mutation semantics**: `["create"]` when output is a new
  cell, `["modify"]` when it rewrites the current cell in place, both when
  both are legitimate (the host injects the picked mode as
  `gen.invocation_type`).
- **Declare lifecycle in the manifest, not in code**: `chat: true` for
  conversational generators, `daemon: true` for long-lived servers/terminals,
  `ephemeral: true` for throwaway sessions that should never enter DAG
  history (`browser_live`).
- **`live_files_mode` is a deliberate three-way choice**: `"auto"` when
  zero sync code is wanted; `"manual"` when sync needs customizing
  (`vscode_env` skips `.git`/`node_modules` noise; `agent` opens it only in
  interactive modes so a short one-shot composition turn doesn't pay for a
  mirror it doesn't need).
- **`config_tags` are curated recipes, not decoration.** `default: {}` must
  exist and must run unedited. Named tags overlay `.set_yaml` fields and/or
  seed the prompt — `run_terminal`'s `lazygit` tag collapses what used to be
  a whole generator into one preset. Prefer a new tag on a general generator
  over a new generator.
- **`prompt_intent` is a placeholder written as an instruction with an
  example** ("URL to open (e.g. https://example.com)"). Add
  `prompt_required: true` only when the prompt is truly mandatory; otherwise
  say what blank does ("leave blank for an empty chat").
- **`summary` is a capability paragraph for the picker, not marketing** —
  name the mechanism, the presets, and the composition role.
- **Host-environment needs are manifest keys with a comment naming the
  failure they prevent**: `env_passthrough: [SSH_AUTH_SOCK]` ("without this
  the ssh-agent path silently no-ops"), `rlimits.memory_bytes` for Chrome.
- List every user-editable config file in `draft_files`.

## Config handling

- **Every field defaults such that the generator runs unedited**, and code
  re-defaults anyway: `(cfg.get("backend") or "pydantic-ai").strip().lower()`.
- **Never bare `int()`/`bool()` on config** — use defensive coercion with a
  default and clamping:

  ```python
  def _int(raw, default: int) -> int:
      try:
          n = int(raw)
          return n if n > 0 else default
      except (TypeError, ValueError):
          return default
  ```

- **Invalid values fall back with a logged warning; they never crash.** The
  `agent` generator accumulates config problems into a `warnings` list the
  caller logs, swaps a model id that contradicts the chosen provider for that
  provider's default, and names inert combinations explicitly instead of
  silently ignoring them.
- **Blank `model` means auto-resolve** per backend/provider — don't hardcode
  model ids into callers.
- **`.set_yaml` field descriptions teach the failure mode and the fix**, not
  just the meaning ("the tag must already be built/pulled on the host").
  Hide expert knobs with `advanced: true`.

## Lifecycle and UX

- **The universal skeleton**: `async def run(): ...` +
  `if __name__ == "__main__": gen.main(run)`. Daemons park on
  `await gen.wait_until_cancelled()` inside `try/finally` teardown.
- **Identity first**: call `await gen.update(name=..., summary="Cloning …")`
  *before* the slow work, so the cell says what it is while it runs.
- **Three distinct progress channels**: `gen.phase()` for coarse machine
  state, `gen.status()` for human-readable progress, `gen.log()` for
  diagnostics (prefix log lines `[gen-id]`).
- **Finish the cell well**: `await gen.update(name=, summary=, pinned=)`.
  Summaries carry facts ("Cloned <url> · 128 files", "ran (exit 0); serving
  :8000"). Pin the file the user should see first.
- **User errors produce `error.md`, not a stack trace**: on bad input write a
  title + the fix ("Paste a repo URL into the picker's prompt"), set
  `summary="Failed: <reason>"`, and `return`. Reserve `raise` for real bugs.
- **Serve UIs through pointer files** (`.terminal`, `.website`, `.webview`
  JSON pointers), then pin them. For terminals use `gen.serve_terminal(...)`
  — it writes + pins the canonical pointer and stops the PTY on exit, so the
  pointer shape can't drift and teardown can't be forgotten. Register ports
  with `gen.serve_port` and gate on readiness (poll the port with a deadline
  and a clear timeout message) — never pin a dead iframe.
- **Multi-output runs**: one `gen.create_stack_cell(name, summary=, pinned=,
  files=)` per result, plus an index file in the primary cell. Captures are
  best-effort per artifact — one failed screenshot logs and skips rather than
  losing the whole capture (`browser_live`).

## Composition (running the LLM)

- **Never bundle an LLM client.** The engine is the `agent` generator,
  reached by id: `gen.call("agent", inputs=..., prompt=...,
  config={"agent-config.set_yaml": {...}}, timeout=300)` for one-shots,
  `gen.spawn` for streaming. Callers depend only on `pyyaml` (+ `pydantic`
  when re-validating structured output) in their PEP-723 header.
- **Never mirror a callee's settings in your own draft file.** Surface ONE
  text field per driven sub-generator — `<callee>_config_tag`, blank by
  default — and resolve it with `gen.tag_config(gid, tag)`: blank → the
  callee's defaults; unknown → the run fails naming the available tags.
  Override only what you have opinions about — the user tunes each callee
  once, as named tags on that generator, and every parent follows. For the
  LLM engine, fold the tag with **`oneshot_tag_values(tag_values, **overrides)`**
  (`from _agent_shared`): it validates the config you actually SEND
  parent-side (raising before the fan-out spends a call, not inside each
  child), and reconciles a container-mode tag to its oneshot backend. Applies
  to any callee with config tags (`agent_config_tag`, `linux_env_config_tag`).
- **Structured output is schema-in, JSON-out, re-validated by the caller**:
  pass `output_schema=Model.model_json_schema()`, then read it back with
  **`result.structured(Model)`** — it returns a validated `Model` (or `None`
  when there's no output; a present-but-wrong-shape output raises the model's
  own error). Keep a deterministic fallback for the `None` case (pad missing
  labels, pick the highest-scoring candidate).
- **Strip the agent's bookkeeping**: edited files =
  `{p: c for p, c in result.files.items() if not p.startswith("_agent/")}`;
  use `result.output_text` as the prose fallback when no file changed.
- **Fan out with `gen.call_many`, NEVER `asyncio.gather` over `gen.call`.**
  A gather serializes — each `gen.call`'s wait holds the bridge's single IPC
  lock for the child's whole runtime, so the children run one-at-a-time (it
  *looks* like it works, just N× too slow). `gen.call_many([{...spawn kwargs},
  ...])` spawns all children (the host runs them concurrently) and polls: one
  `GeneratorResult` per spec in order, per-item `ok=False` isolation (a failed
  child never crashes the batch), `gen.Cancelled` on a user stop, and a
  `max_concurrent` spawn window. (Agent-family generators can use the sugar
  `gather_agent_calls` from `_agent_shared`.) Each sub-run has an isolated
  workspace, so parallel candidates never collide.
- **The assumptions-ledger costs an extra LLM call** — `oneshot_tag_values`
  defaults it OFF for composition; pass `ledger=True` only on the calls whose
  ledger you actually PROMOTE into a cell.
- **Check `result.ok` before touching `result.files`,** and always pass a
  `timeout`.
- **Chat turn discipline** (`agent`'s chat mode, the Guide): append the user
  bubble and `await gen.update()` immediately; fold history into the prompt
  under a char budget (most recent first); forward deltas with
  `turn.delta`; stop the spawned handle in `finally`; on interrupt keep only
  what streamed; and make sure *every* failure path still appends an
  assistant message so no user bubble dangles. Distinguish real teardown
  (`gen.Cancelled` while `gen.cancelled`) from a per-turn cancel.

## Containers and credentials

- **Self-contained images**: ship the `Dockerfile` in the cell, build on
  first use, cache by tag, and bump the tag when the Dockerfile changes
  (`collimate-vscode-env:v3`). Stream build steps into `gen.status`. Bake
  dependencies into the image — runtime installs are unreliable.
- **Shared machinery lives in `_*` sibling helper cells** (`_env_shared`,
  `_agent_shared`, `_cdp_shared`), imported via the two-line `sys.path`
  shim; the SDK itself stays Docker-free. List the sibling in the bundle's
  `cells:` layout with a comment saying why it's required.
- **Bind-mount the cell workspace read-write at a fixed path**, match uids,
  label containers with the run id, stop with SIGTERM before force-remove so
  mounted writes aren't killed mid-flight, and make `close()` idempotent.
- **Secrets come from the keystore**: `await gen.api_key(provider)` for
  provider keys (retry once with `force=True` on a 401),
  `await gen.secret(name, prompt_if_missing=True, description=...)` for the
  rest — the description is what the user sees at prompt time. Pass tokens
  through the exec *environment*, never argv; scrub secret values from all
  error output; degrade with a note ("HTTPS push will prompt") instead of
  failing.

## Renderers

- **Native vs iframe is chosen by state, and the manifest comments the
  choice.** Anything holding a live WebSocket must be `embed: "native"` —
  the iframe pool parks offscreen iframes and a remount would double-connect
  (terminal, assistant chat). Heavy third-party editors go `embed: "iframe"`
  (monaco, excalidraw).
- **Shadow DOM styling**: inline styles or an injected `<style>` block —
  host classes never reach the shadow root. Theme against the host tokens
  (`tokens.color.*`, `var(--renderer-surface)`) so light/dark both work;
  document any deliberate exception (the terminal pins true black because
  ANSI palettes are authored against it).
- **Use the SDK hooks**: `defineRenderer`, `useCollimateFile()`, `useTheme`,
  `useVisibility`, and `useDebouncedSaveContent` for editors so keystrokes
  don't spam saves. Respect `isReadOnly`.
- **Pointer files are parsed defensively**: validate JSON field-by-field
  with fallbacks (the website renderer treats non-JSON content as a plain
  URL) and preserve fields you don't own when writing back.
- **`supports_diff: true` only where a text diff is meaningful**; comment
  why when it isn't (excalidraw's nested JSON).
- **Sanitize rendered content**: native renderers have SDK API access, so
  block `javascript:`/`data:` URLs in anything user-authored (markdown).
- **Always compile-check before calling a renderer done**
  (`compile_renderer` / `collimate-check-renderer`).

## Code style

- Every entrypoint starts with a **PEP-723 header** listing only the deps the
  generator itself imports; heavy imports (`docker`) are deferred into the
  functions that use them.
- **Module docstrings explain the design** — the flow, the modes, the
  historical why — not the API. Comments record the bug a line prevents.
- Helper functions are small, defensive, and named for what they normalize
  (`_int`, `_as_string_list`, `_scrub`).
- **Test before done**: run the generator (`run_generator` /
  `collimate.testing.run_generator`), compile the renderer, and lint
  manifests with `collimate-lint`.
