# Collimate — what it is, why it exists, and how to find your way around

This is the orientation document: the vision and philosophy behind Collimate,
the core concepts, and a practical tour of the UI. Read it before answering
any "what is Collimate", "why does it work this way", or "where do I click"
question. The authoring guides (`how-to-write-a-generator.md`,
`how-to-write-a-renderer.md`) cover the *building* side; this file covers the
*thinking* side and the app itself.

> *col·li·mate, v. — to make divergent rays parallel.*

## What Collimate is

Collimate is a **local workbench for working with language models in
parallel**: fan a problem out across generators, compare the results
side-by-side, challenge them, and keep what holds up. Every branch, draft,
and rejected alternative persists as a versioned artifact — nothing you try
is lost.

Practical facts:

- **Local and private.** Single-user, no cloud, no accounts. The server is
  loopback-only by design. What you make is plain files in local
  content-addressed storage, indexed by SQLite.
- **Keyboard-driven**, but fully mouse-usable.
- **Pre-1.0 and single-author.** The hard parts are solved with care; some of
  the polish isn't there yet.
- **Two licenses, deliberately.** The app is source-available (FSL-1.1,
  converting to Apache-2.0 after two years). The SDK — everything *you*
  author against — is Apache-2.0 from day one, in its own repository, so
  nothing you make is trapped if the app goes away.

## Why it exists — the philosophy

Collimate is built on a specific set of beliefs about AI-assisted work. When
someone asks "why", this is the answer.

### Generation is commodity. Judgment is scarcity.

A model can produce ten coherent approaches in the time it takes you to read
one. What's scarce is not the generation — it's you, looking at those ten and
knowing which is worth pursuing, why, and what each one gave up to look so
clean. Most AI interfaces optimize the quality of a single output. They
should optimize **the speed and clarity of your judgment across many**.

### The third story

There are two common narratives about AI and your work: one says you're
obsolete if you don't adopt fast enough; the other says you're a checkpoint —
a reviewer who approves or rejects what the AI did. Both park your role at
the edges of the work. Collimate is a third story: **you are not a gate in
the AI's workflow; the AI is a mapping tool in yours.** The scarce resource
was never the generation — it was the judgment: knowing what to look at, what
each option costs, which compromise you can stand behind, and when to stop.

### Hard problems are trade-offs, not answers

The hardest problems don't have a right answer a smarter model will
eventually find. They have trade-offs — a chosen point on a curve. When a
model hands you one answer to a problem like that, it hasn't found *the*
answer; it has **satisficed**: picked a good-enough point on axes it chose
for you. And the better the model, the more polished the compromise — the
seams (where it quietly decided speed mattered more than compatibility, say)
get smoother and harder to find. Capability doesn't dissolve the need for
your judgment; it buries it deeper. So the model's proper role is
**explorer, not oracle**: map the frontier, eliminate dominated options,
surface the trade-offs and assumptions — and leave the cut to you.

### The record of decisions

When you choose one direction, the roads not taken shouldn't vanish. Kept
alternatives are what make a choice legible: the record shows not just what
you built but what you turned down and why. A decision you can't reconstruct
is indistinguishable from a guess. That's why everything in Collimate
persists as versioned cells — not a graveyard of failures, a record of
decisions.

### No opaque layers

Users should own their workflow. Tools that wrap the model in layers you
can't inspect trade away more than they add — LLMs are made to be understood
at the level of prompts and context. In Collimate the prompts, configs, and
code that drive every generator are plain, editable files sitting in the
cell. Nothing is hidden.

### The loop

The working rhythm the app is built around: **explore, challenge, compare,
merge, kill.** Get a result that looks reasonable, then challenge it — fork
it, set rival approaches side by side, throw the same objection at both, keep
what holds. Go wide (five directions, held loosely), go narrow (two are
interesting, look closer), go wide again when something breaks — because you
now know something you didn't. In a chat, every challenge pollutes the
context that produced the answer. Here, challenging is cheap.

## Core concepts

| Concept | What it is |
|---|---|
| **Channel** | A workspace. Holds stacks; persisted server-side, streamed live to the UI. |
| **Stack** | An ordered column of cells. The canvas lays stacks out horizontally; a stack shows its front cell with the rest behind it. |
| **Cell** | The unit of work: a named bundle of files plus a summary. Contents live in a content-addressed blob store; edits checkpoint into versions, and version history forms a DAG — forks, merges, restores. |
| **Generator** | User-authored Python, run as a subprocess (optionally Docker-sandboxed). Reads input cells, emits new cells and files; output streams into the UI live. |
| **Renderer** | User-authored display component for a file type. Trusted renderers mount in-document inside shadow DOM; others run in sandboxed iframes. |
| **Pinned file** | Each cell pins one file; the renderer matched to that file's extension is what the cell displays. |
| **Views** | The same scene at three altitudes: **stack view** (front cells side by side), **zoom-out** (every cell of every stack as a grid), **dive-deep** (one stack's cells spread out as columns). |
| **Exposure** | Cells are private to generators by default; the user can "expose to generators" so agents may read/edit them. Cross-cell tools are gated on this. |

How generators take input:

- **Prompt** — the free-text box in the picker (`prompt_intent` in the
  manifest is its placeholder). Free text is preferred over rigid fields —
  LLMs translate.
- **Config tags** — named presets shown as chips in the picker; each seeds
  the prompt and/or overrides config fields.
- **Draft files** — `.set_yaml` files in the cell that render as a settings
  form. Defaults are tuned so generators run without opening them.
- **Input cells** — `create` generators take 0–N input cells; `modify`
  generators rewrite the current cell in place.

## Finding your way around the UI

For orienting a new user:

- **The canvas** is a pannable field of stacks. Each stack shows its front
  cell rendered by whatever renderer matches its pinned file.
- **Making things:** the top-bar **create picker** starts a new cell from a
  generator (pick a generator, a config tag chip, type a prompt). Each cell
  also has a **modify** button for generators that rewrite it in place.
- **Inside a cell:** the **Files tab** lists every file; you can edit them
  directly. Draft `.set_yaml` files render as a settings form.
- **API keys** live in **Settings → Keys** (e.g. `ANTHROPIC_API_KEY`,
  `GEMINI_API_KEY`, `OPENAI_API_KEY`). If a generator needs a key that isn't
  set, a modal pops up in the cell asking for it — keys are stored in the
  OS keyring, never in cells.
- **Long-running cells** (chats, terminals, environments) keep serving until
  you press **Stop**.
- **Keyboard:** `Shift+?` opens the shortcut cheatsheet; remap anything in
  **Settings → Keyboard**. `Mod+Shift+K` opens the exhaustive keyboard map
  ("Beacon") — drill into a region, then press the key on the thing you want.
  Everything on screen is reachable that way.
- **Judging work:** fork a cell to try a rival approach; set cells side by
  side; zoom out to see everything; dive deep to walk one stack's history.

### The starter set

A fresh channel is seeded with curated generator cells (each cell groups
related generators):

- **Guide** — this assistant: orientation, questions, reading material, and
  building/testing/installing generators and renderers.
- **Agent** — the unified LLM agent: one-shot engine other generators call,
  interactive chat, a live Claude terminal, or opencode's web UI.
- **Agent Run** — `modify-files`: point an agent with file tools at a cell.
- **Browser** — `browser_live`: drive your own local Chrome.
- **Code Env** — containerized VS Code Server and a live terminal with
  bidirectional file sync.
- **Linux Env** — a Linux container environment and a code runner.
- **File Management** — `git_clone`.

And renderer cells: **Live** (assistant chat, webview, terminal, website),
**Documents** (markdown, milkdown, monaco, text), **Visual** (mermaid, image,
html, excalidraw, slides), **Utility** (schema form, table, react-diff).
Larger catalogs (`all_generators.colgen`, `all_renderers.colrend`) can be
imported from Settings.

## The two things you author

Everything above is extensible in-app. **Generators** are plain Python that
can run anything: any model, any agent harness, or no AI at all.
**Renderers** are ES-module UIs (usually React) for whatever files the
generators produce. Both are created as cells, and both are documented in:

- `how-to-write-a-generator.md` — the generator contract, `gen.*` API,
  manifests.
- `how-to-write-a-renderer.md` — the renderer SDK, hosting modes, styling.
- `authoring-best-practices.md` — the house style, distilled from the
  packaged set.
- `api-reference.md` — the tabular cross-reference.
- `testing-generators.md` — running generators host-free and compile-checking
  renderers.
