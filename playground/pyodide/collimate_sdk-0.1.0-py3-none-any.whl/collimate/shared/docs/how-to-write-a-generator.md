# How to write a generator

Generators run as full Python processes spawned by the Collimate backend. They have access to the real filesystem, subprocesses, ports, terminals, Docker, and any pip-installable library.

The runtime API is a single top-level package: **`gen`**. A generator imports it and calls `gen.*` to read inputs, stage output files, push cells, request user input, resolve API keys, run subprocesses, bind ports, attach terminals, and more. There is no `ctx` argument — the host sets up `gen` before `run()` is called.

This doc is the full contract; it is also loaded at runtime as the system prompt for the `generator-builder` scaffolding agent, so style and idioms here are reflected in every generator the LLM produces.

---

## 1. File layout

One generator = one directory:

```
my_gen/
├── manifest.gen_yaml          # identity + schema (required)
├── my_gen.py                  # the run() function (required)
└── config.set_yaml            # optional draft file for user-editable knobs
```

The host spawns `my_gen.py` as a subprocess. The script imports `gen` and calls `gen.main(run)` from its `__main__` block.

In the SDK's shipped trees the generator directories are grouped under
**cell parent folders** — the parent folders ARE the seeded cells
(`generators/<cell>/<my_gen>/`, see `collimate.packaging.layout`), each with
an optional `cell.yaml` naming the cell and its summary/icon/order/shared
`_*` libraries. Inside the app a generator simply lives in a cell; the
directory above is only the shipping layout.

---

## 2. Minimal generator

```python
# my_gen.py
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
import gen

async def run():
    name = gen.config("agent-config.set_yaml").get("name", "world")
    gen.update_file("greeting.md", f"# Hello {name}\n")
    # No explicit gen.update() needed — main() auto-flushes pending writes
    # when run() returns. Call gen.update(name=…, summary=…) if you want
    # to set a custom cell name or summary.

if __name__ == "__main__":
    gen.main(run)
```

```yaml
# manifest.gen_yaml
id: "hello"
name: "Hello"
type: ["create"]
version: "0.1.0"
summary: "Write a greeting file."
entrypoint: "my_gen.py"
prompt_intent: "Who to greet"
inputs:
  cells: { min: 0, max: 0 }   # no input → a fresh cell from scratch
config_tags:
  default: {}   # required whenever the generator takes config (see §4)
```

That's the whole contract. The PEP 723 `# /// script` block lets `uv run` resolve dependencies on first launch.

---

## 3. The `run()` contract

```python
async def run() -> None: ...   # canonical
def run() -> None: ...         # also accepted for trivial cases
```

The function takes **no arguments**. The host sets up `gen` (workspace path, IPC, signal handling, prompt, params) before `gen.main(run)` invokes it.

When `run()` returns cleanly, `main()` auto-flushes any pending writes (files staged via `update_file`, history appended via `gen.history.append`, deletions via `delete_file`) as the final cell state. Generators that want explicit control — a custom name/summary, mid-run progressive updates — call `await gen.update(name=…, summary=…)` themselves; the auto-flush is a no-op when the stage is already clean.

`async def` is preferred for anything that touches IPC, LLMs, or subprocess streaming. Sync `def run()` is fine for trivial cases (`merge`, deterministic transforms).

### Cancellation

```python
if gen.cancelled:
    return  # or: break out of a loop
```

`gen.cancelled` flips to True when the user clicks Stop (SIGTERM is delivered). Long-running and daemon generators must poll it cooperatively. Subprocess and chat helpers (`gen.run_subprocess`, `gen.serve_chat`, `gen.wait_for_action`) handle this internally; a chat turn that forwards a spawned `agent`'s stream observes `turn.cancelled` in its `async for ev in handle.events()` loop.

If a primitive raises `gen.Cancelled` (user cancelled a key/secret/settings modal), let it propagate — `gen.main` catches it and finalises the run as gracefully stopped.

**Stop vs. Force Stop.** Stop delivers SIGTERM, so `gen.cancelled` flips and any `try/finally` cleanup runs. **Force Stop (and a crash) can't be intercepted — your `finally` won't run** — so don't hang a critical teardown on it alone. For the usual culprit, a Docker container, use `_env_shared.DockerEnvironment` (see `DockerEnvironment` below): its container is removed when the run ends, Force Stop and crashes included, so you don't have to manage that yourself.

---

## 4. Manifest fields

```yaml
id: "my-gen"                 # unique, lowercase, hyphenated
name: "My Generator"          # display name in picker
version: "0.1.0"
summary: "One-line description for the picker."   # required; 1–2 sentences
entrypoint: "my_gen.py"

prompt_intent: "What the user types into the picker textarea"

# Optional, default false. When true, the run is blocked until the
# prompt is non-empty (after trimming) — enforced by both pickers and
# by the server. Only legal alongside `prompt_intent` (lint error
# otherwise).
prompt_required: true

# Named sets of default input values (prompt + .set_yaml fields),
# shown as selectable chips in both pickers. **Required whenever the
# generator "takes config"** — i.e. it has a `prompt_intent` or at
# least one `.set_yaml` in `draft_files` — and must then contain a
# `default` tag. `default: {}` means "pure field defaults".
#
# Tag names must match ^[A-Za-z0-9][A-Za-z0-9 ._-]{0,31}$ (1–32 chars).
# Each tag body allows exactly two keys, both optional:
#   prompt — string seeded into the picker's prompt box when the tag
#            is selected.
#   files  — mapping of .set_yaml draft-file path → **sparse overlay**:
#            only the field keys it names are overridden; every other
#            field keeps its resolved default. Keys must be .set_yaml
#            members of `draft_files`, and each field key must exist in
#            that file's `fields:` list.
# Mapping order = display order; users can add/edit/delete tags from
# the UI (those edits persist to the channel's copy, not this file).
config_tags:
  default: {}
  "fast model":
    prompt: "Summarise the inputs"
    files:
      agent-config.set_yaml:
        model: claude-haiku-4-5
        max_tokens: 1024

# How the generator is invoked. **Required.** A list of 1–2 modes, each
# drawn from {"modify", "create"}. Drives which picker(s) the generator
# appears in and what inputs it receives; the input shape for `create`
# is read off `inputs.cells` (see below):
#   modify    — rewrites the single current cell in place. Takes exactly
#               1 input cell (the current cell). Surfaces in the per-cell
#               button. No new cell at run start; 'update' emissions
#               append versions. Implicit bounds: 1/1.
#   create    — produces fresh cell(s). The input shape comes from
#               `inputs.cells`: no input (min/max 0; surfaces in the
#               top-bar / empty-channel CTA), a single cell (min/max 1),
#               or a stack of cells (e.g. min 1/2, max 99 — min may be 0
#               for an optional stack). A fresh running cell is created.
#
# Declare every mode the generator supports. A generator with
# ``type: ["modify", "create"]`` (handles both a single current cell and
# producing fresh cells) appears in both pickers. The host injects the
# mode the user actually picked as ``gen.invocation_type`` so the run
# can branch.
type: ["create"]

# Whether this is a chat-shaped (long-lived, conversational) run.
# Default: false. Set to true for generators that serve a streaming
# chat via `gen.serve_chat(on_turn)`. The runtime infers Stop semantics,
# picker routing, log-drawer behaviour, and history persistence from
# this one bit. `chat: true` implies `daemon: true`.
chat: false

# Whether this is a long-running non-chat daemon. Default: false. Set
# to true for generators that stay alive serving a port or terminal
# (vscode_env, browser_live, the agent generator's container modes).
daemon: false

# Optional, default false. Marks a throwaway live session (e.g. a
# browser) whose output cell never enters the DAG history. The cell
# offers "close" (stop + remove) instead of "stop", and nothing it
# produces is recorded as a permanent cell.
ephemeral: false

# Optional picker-visibility baseline. A generator can ship OUT of the
# human picker yet remain callable by other generators (gen.call /
# gen.spawn). Default: shown in the picker.
#   available_ui  — appear in the human picker (default true)
# Set `available_ui: false` to make a composition-only toolset — invisible to
# humans but still callable via gen.call/gen.spawn. A per-channel on/off switch
# in the management view overrides this baseline. (The `agent` generator is
# visible: its `mode` presets are user-facing surfaces, and composition callers
# reach its one-shot mode by id regardless.)
#
# NOTE: callability by other generators is NOT a manifest flag — it follows
# the source CELL's "expose to generators" setting (a per-channel switch,
# exposed by default). Exposing a cell also lets other generators read and
# edit (version) its code. `agent` stays callable because its cell is
# exposed by default.
available_ui: false

# Optional (native only): keep the cell's files (the Files tab) and this
# run's workspace in live, BIDIRECTIONAL sync so the user can edit files
# while the run is in flight. Two values:
#   "auto"   — the runtime opens gen.live_files() for the whole run. Zero
#              code: write to your workspace, the user edits in the Files
#              tab, both stay in sync. Use this unless you need control.
#   "manual" — files stay editable, but YOU drive the sync, for custom
#              skip_dirs / exclude globs or a one-way mirror:
#                 async with gen.live_files(skip_dirs={".vscode"}):
#                     await gen.wait_until_cancelled()
#              (or handle.mirror_files() to sync a spawned sub-run instead).
# Omit / "none" locks the Files tab while the generator runs.
# live_files_mode: "auto"

# Optional: files seeded into the workspace before the run. The picker
# renders a form from any .set_yaml schema; the user fills it, the run
# starts.
draft_files:
  - "agent-config.set_yaml"

# Bounds on the number of input cells. For `create`, this is what picks
# the input shape (no input vs. single cell vs. stack). When omitted,
# each declared mode contributes its implicit bounds and the runtime
# takes the union (modify → 1/1, create → defaults to a stack 1/99).
# When declared, every declared mode's per-mode rule must hold:
#   "modify" in type   — bounds must include 1 (min ≤ 1 ≤ max), i.e. the
#                        single current cell
#   "create" in type   — min ≥ 0; the bounds choose the shape:
#                        no input (min/max 0), a single cell (min/max 1),
#                        or a stack (e.g. min 1/2, max 99; min may be 0
#                        for an optional stack)
inputs:
  cells:
    min: 1
    max: 99

# Optional: caps on subprocess resource usage (native only). Recognised
# keys are memory_bytes (RLIMIT_AS), cpu_seconds (RLIMIT_CPU),
# open_files (RLIMIT_NOFILE). Values must be positive integers; unknown
# keys are a lint error.
rlimits:
  memory_bytes: 8589934592  # 8 GB

# Optional: env vars that survive the per-subprocess scrub. Use only
# for non-secret host state (e.g. SSH_AUTH_SOCK for ssh-agent
# forwarding). Names that look like secrets (matching KEY/TOKEN/SECRET)
# warn at lint — route those through gen.secret/gen.api_key instead.
env_passthrough:
  - "SSH_AUTH_SOCK"
```

That's the entire schema. Anything else lints as an unknown field.

---

## 5. Settings schema (`.set_yaml`)

Generators that need user-editable knobs ship a draft file with a schema-form layout:

```yaml
# agent-config.set_yaml
fields:
  - key: provider
    type: dropdown
    label: Provider
    description: Which LLM provider to call.
    default: anthropic
    options:
      - { value: anthropic, label: Anthropic }
      - { value: openai,    label: OpenAI    }
      - { value: groq,      label: Groq      }

  - key: model
    type: text
    label: Model
    description: Provider-specific model name (e.g. `claude-sonnet-4-6`, `gpt-4o`).
    default: "claude-sonnet-4-6"
    required: true

  - key: max_tokens
    type: number
    label: Max output tokens
    default: 4096
    min: 256
    max: 16384
    required: true

  - key: system_prompt
    type: textarea
    label: System prompt
    default: "You are a concise assistant."
```

Generators read this with one line:

```python
cfg = gen.config("agent-config.set_yaml")
provider = cfg.get("provider", "anthropic")
system_prompt = cfg.get("system_prompt", "")
```

`gen.config(name)` always returns a dict. `.set_yaml` / `.yaml` / `.yml` parse as YAML and merge `fields:` defaults with the `values:` block. `.json` parses as JSON. Missing or malformed files yield `{}` so callers can use `cfg.get(...)` without try/except. For raw text files, use `gen.read_file(name)` instead.

### Field types

| Type | Purpose | Type-specific options |
|---|---|---|
| `text` | single-line input | `placeholder`, `multiline` |
| `textarea` | multi-line input | (same as text) |
| `number` | numeric input | `min`, `max`, `step`, `widget: slider` |
| `dropdown` | enum selection | `options: [{value, label, description}]` |
| `checkbox` | true/false | — |
| `list` | repeated subform | `item: { fields: [...] }` |
| `object` | grouped subform | `fields: [...]` |

Every field accepts: `key`, `label`, `description`, `default`, `required`, `advanced` (collapse under "Advanced" expander), `show_when` (conditional visibility — `{earlierFieldKey: expectedValue}`).

### Required fields and the run gate

`required: true` on a field is a **run gate**, not just a styling flag: both
pickers and the server refuse to start a run while a required field's
effective value is empty. "Empty" is defined per field type:

| Field type | Empty when |
|---|---|
| `text` / `textarea` | `null`, or `""` after trimming |
| `number` | `null` |
| `dropdown` | `null` or `""` |
| `checkbox` | never — a checkbox always holds true/false (`required:` on one is a lint warning) |
| `list` | `null` or `[]` |
| `object` | `null` |
| the prompt | `""` after trimming (gated by the manifest's `prompt_required`) |

`0` and `false` are NOT empty. The machine-readable version of this table
is `shared/empty-values-contract.json`, which every implementation is
tested against.

### Value resolution

The effective value of each field, for a given config tag, is layered
left-to-right (later wins):

```
per-type empty default  ⊕  field `default:`  ⊕  the file's `values:` block  ⊕  the tag's `files[<path>]` overlay
```

The tag overlay is sparse — it only touches the keys it names. The
effective prompt seeded by a tag is `tag.prompt`, or none when the tag
doesn't set one.

---

## 6. The `gen.*` surface

### Inputs

```python
gen.prompt              # str — the picker textarea text
gen.messages            # list[Message] — prior chat history from input cells
gen.cancelled           # bool — Stop button check (poll between chunks)
gen.invocation_type     # str — "modify" | "create", the mode the user
                        # picked. Useful when the manifest's `type` array
                        # lists more than one mode and the run needs to branch.
```

### Reading input cell files

```python
gen.read_input(path)    # str | bytes — read one input file. Returns str when
                        # the bytes decode as utf-8, otherwise bytes. Branch on
                        # isinstance(..., bytes) when the source may be binary.
gen.input_files()       # dict[str, str | bytes] — every input file
gen.input_groups()      # dict[str, dict[str, str | bytes]] — files split by source cell
                        #   single input  → {"input": {...}}
                        #   multi-input   → {"00_label": {...}, "01_other": {...}}
                        #   paths in each group are relative to the cell root
```

### Reading config files

```python
gen.config(name)        # dict — YAML / JSON, by extension; {} on missing/malformed
```

### Output stage (file I/O on the cell being written)

```python
gen.update_file(path, content)  # content: str | bytes. Stages a write (also
                                # syncs to disk so subprocesses see it).
gen.read_file(path)             # str | bytes — read from stage; raises
                                # FileNotFoundError if absent (guard with
                                # has_file). utf-8 → str, else bytes.
gen.has_file(path)              # collision predicate
gen.list_files()                # sorted staged paths
gen.delete_file(path)           # drop from stage and disk
```

### Cell operations — two only

```python
await gen.update(*, name=None, summary=None, pinned=None)
await gen.create_stack_cell(name, *, summary=None, pinned=None, files=None)
```

`gen.update()` flushes the current stage (tracked file writes + dirty chat history) as a new **version** of the running cell. The version chain is what the user sees in the cell's history side panel — each `gen.update()` adds a row; the visible cell on the canvas always shows the latest. **May be called many times during a run** — each call refreshes the visible cell live; the host debounces persistence. Maps to the manifest's `output: 'update'` kind.

When `run()` returns cleanly, `main()` calls update automatically if there are pending writes — most one-shot generators don't need an explicit `gen.update()` at the end. Use it when you want a custom name/summary, or when you want to flush mid-run so the user sees progressive output.

`gen.create_stack_cell(name, ...)` mints a new cell on the canvas. Used by fan-out generators (e.g. `seed_ideas`) to create N siblings while the running cell holds an index. If `files` is omitted, it snapshots the current stage.

**Where created cells land** is decided by the running cell's placement toggle (user-controlled via the placement chip in the log header; defaults to the channel's saved choice):

| Placement | Where the new cell lands |
|-----------|--------------------------|
| `under`     | appended below the running cell, same stack |
| `new_stack` | first cell of a fresh stack inserted to the right |
| `on_top`    | top of the stack immediately to the right (created if absent) |

The generator doesn't pick placement — it's the user's call. Just emit cells; the host places them.

There is no `update_cell(cell_id, ...)` escape hatch. Generators that want to "modify an input cell" should declare `type: ["modify"]` (which makes the input cell *be* the running cell), or for `type: ["create"]` carry the input files forward into the new running cell and update those.

### Chat history

```python
gen.history.append(role, content)   # role: "user" | "assistant"
gen.history.switch_thread("main")   # make a thread active + load its transcript
gen.history.seed()                  # bool — reload the active thread's transcript
list(gen.history)                   # iterate the active thread (read-only)
```

`history.append()` rewrites the active thread's transcript (`chats/<thread>.json`) through the normal output stage immediately; the next `gen.update()` (or the auto-flush on return) commits it as an ordinary versioned file. The transcript is the durable record of the conversation — an **open-format** JSON document (OpenAI-compatible `{"messages":[{"role","content"}]}`; see `collimate/transcript.py`), rendered by the assistant-ui chat renderer.

> **Inside a `serve_chat` `on_turn`, use `turn.append(...)`, not `gen.history.append(...)`.** `gen.history` targets the *active* thread, which moves if the user switches threads mid-turn; `turn.append` is bound to the thread the turn started on, so the reply can't be misfiled. Reserve `gen.history.*` for mutations *outside* a turn.

### Live chat

Five things a correct chat handler MUST do — the canonical shipped generators
(`generators/agent/agent/agent.py` `_run_chat`, `generators/guide/guide/guide.py`)
do all five; copy them:

1. **Record with `turn.append(...)`, NEVER `gen.history.append(...)` inside a
   turn.** `turn.append` is bound to the thread the turn *started* on;
   `gen.history` tracks the *active* thread, which moves when the user switches
   threads mid-turn (a turn keeps generating in the background — it is not
   cancelled by a switch) — so `gen.history.append` misfiles the reply into the
   wrong thread's transcript.
2. **Fold the transcript into the prompt** — the engine is stateless per turn,
   so pass the conversation so far (`turn.messages`), not just `turn.user_msg`,
   or the chat has no memory.
3. **Pass `should_stop=lambda: turn.cancelled`** to the stream so an interrupt
   halts generation promptly (not just delta-forwarding).
4. **Keep only what streamed on cancel** — don't resurrect the full background
   reply for a turn the user stopped.
5. **Wrap in `gen.live_files()`** (or set `live_files_mode: auto` in the
   manifest) so the Files tab stays editable during the session, and pass
   `initial_message=(gen.prompt or "").strip()` so the run prompt seeds the
   first turn.

```python
_BUDGET = 24000

def _compose_prompt(messages, budget):
    # Fold prior turns (most-recent-first, capped) ahead of the latest message.
    if len(messages) <= 1:
        return messages[-1].content if messages else ""
    kept, used = [], 0
    for m in reversed(messages[:-1]):
        cost = len(m.content or "") + 16
        if kept and used + cost > budget:
            break
        kept.append(m); used += cost
    kept.reverse()
    lines = ["Conversation so far:", ""]
    for m in kept:
        lines += [f"{m.role}: {m.content}", ""]
    lines += ["Reply to the latest message:", "", messages[-1].content]
    return "\n".join(lines)

async def on_turn(turn):
    # Runs once per inbound user message. Record the user bubble on THIS
    # turn's thread, then stream the reply via turn.delta(...).
    turn.append("user", turn.user_msg)
    await gen.update()                              # surface the user bubble now
    handle = gen.spawn("agent", prompt=_compose_prompt(turn.messages, _BUDGET),
                       config={"agent-config.set_yaml": {"stream": True, "ledger": False}})
    chunks = []
    try:
        async for chunk in handle.stream_text(should_stop=lambda: turn.cancelled):
            if turn.cancelled:
                break
            chunks.append(chunk)
            turn.delta(chunk)                       # forward to the chat renderer
    finally:
        await handle.stop()
    reply = "".join(chunks).strip()
    if turn.cancelled and not reply:
        reply = "_(stopped by user)_"
    turn.append("assistant", reply or "_(empty response)_")
    await gen.update(summary=turn.user_msg[:80])

# live_files keeps the Files tab editable during the session; initial_message
# seeds the first turn from the run prompt.
async with gen.live_files():
    await gen.serve_chat(on_turn, label="Chat", resume=True,
                         initial_message=(gen.prompt or "").strip())
# Serves a live, MULTI-THREAD streaming chat until Stop. Registers the
# session, pins the `.chat` session pointer (rendered by the assistant-ui
# renderer), seeds the active thread, then dispatches each inbound message to
# on_turn(turn). Threads are independent conversations sharing the cell's
# files, each saved to chats/<id>.json; the renderer drives thread_new /
# thread_switch and — between turns — the curation commands edit / delete /
# insert / move / regenerate, applied to the active thread's transcript (no
# handler code). Set the manifest's `chat: true`. `integration=` (default
# None) lets the renderer pick native streaming vs a backend like opencode.
```

### Secrets

```python
await gen.api_key(provider, *, force=False, description="")
# Resolves the API key for "anthropic"/"openai"/"groq"/"cerebras"/
# "openrouter"/"gemini"/"mistral" and sets the standard env
# var (ANTHROPIC_API_KEY etc.) so the provider's native key lookup
# picks it up. Pops the in-cell modal when the env isn't set.
# force=True skips the env-var fast path — for auth-retry after a 401.
# Raises gen.Cancelled when the user cancels the modal.

await gen.secret(name, *, prompt_if_missing=False, description="")
# Escape hatch for non-LLM secrets (webhook tokens, custom service
# keys, …). Default: env-var fast path only — empty string when not
# set. prompt_if_missing=True opts into the modal flow.
```

### Communicating with the user — title, summary, phase, logs

A running cell tells the user what's happening through four channels. Use them
deliberately — a silent generator reads as a wedged one.

```python
# 1. Identity — set EARLY, refine at the end. Don't wait until you're done.
await gen.update(name="Git Clone", summary="Cloning github.com/foo/bar…")
# … later …
await gen.update(summary="Cloned foo/bar · 142 files")

# 2. Phase — the lifecycle signal that drives the cell's loading indicator.
gen.phase("spinning_up", "pulling image")   # booting: container/clone/warm-up
gen.phase("running", "indexing")            # real work underway
gen.status("indexing src/ (3/12)")          # update just the phase's message

# 3. Logs — one line per external action or state change (NOT per loop tick).
gen.log("cloned 142 files in 3.1s")

# 4. Progress — optional numeric counter (native-only).
gen.progress(3, 12)
```

**Title + summary (set them early).** Call `gen.update(name=…, summary=…)` as
the first thing after you read your inputs — before any slow setup — so the
cell has an identity while it works. The `name` is a stable noun phrase (the
generator's identity); the `summary` is a one-clause present-tense description
that ends in a concrete result when done.

**Phase — spinning up vs running.** The backend drives a baseline phase machine
on its own (`queued → spinning_up → running → terminal`), so a cell always shows
*something*. Call `gen.phase("spinning_up", …)` around slow setup (container
boot, clone, model warm-up) and `gen.phase("running", …)` once the real work
starts — the cell's LED is amber while spinning up, hot while running, so a slow
boot doesn't look hung. `gen.status(msg)` updates only the current phase's
message. The active phases you set are `spinning_up`, `running`, `finishing`.

**Logs.** Log meaningful actions and transitions — a subprocess starting, a
sub-run dispatched, a retry, a result count — not every loop iteration and never
a secret. Each line is shown labeled + timestamped; don't add your own `[tag]`
prefix at top level (the backend already labels by source).

#### When something goes wrong

Failure is **not** a phase — signal it through the run *outcome* so the cell
renders the error state (red, auto-expanded log) automatically:

```python
if rc != 0:
    reason = f"clone failed (rc={rc})"
    gen.log(reason)                                       # durable detail
    gen.update_file("error.md", f"# Clone failed\n\n```\n{output}\n```\n")
    await gen.update(summary=f"Failed: {reason}")         # self-explanatory cell
    return                                                # expected failure: return,
                                                          # don't raise
```

Return (don't raise) for *expected* failures — no prompt, a non-zero exit, a
sub-run reporting `ok=False`. Reserve `raise` for truly unexpected states. For a
long-lived daemon, a recoverable hiccup is just a `gen.log` + transient
`gen.status` — only the run's final outcome is "failure".

### Running an LLM agent — call the `agent` toolset generator

Running an LLM is **not** a built-in `gen.*` call. It is a hidden,
composition-only generator with id `agent`: an ordinary generator (with file
+ python tools, structured output, and three interchangeable backends) that
other generators reach via `gen.call` (batch) or `gen.spawn` + the streaming
channel (live). There is no pydantic-ai dependency in your own generator —
the `agent` generator owns the LLM machinery.

```python
from pydantic import BaseModel

# THE PARENT-GENERATOR CONVENTION: don't mirror the agent's settings in
# your own draft file. Surface ONE text field (agent_config_tag, blank by
# default), resolve it with gen.tag_config, and override only what you have
# opinions about — the user tunes models/billing once, as named tags on the
# agent generator. (Same pattern for any callee: code_runner resolves a
# linux_env_config_tag for the environment it spawns.)
raw = gen.config("config.set_yaml")                       # your own knobs
tag_values = gen.tag_config("agent", raw.get("agent_config_tag")).get(
    "agent-config.set_yaml", {})
# {} when blank (the agent's defaults); ValueError naming the available
# tags when unknown/unreachable — let it fail the run with that guidance.

# Batch: spawn + wait, one shot. inputs= seeds the agent's own workspace.
result = await gen.call("agent", inputs=files, prompt=msg, config={
    "agent-config.set_yaml": {
        **tag_values,               # model/backend/auth/tokens from the tag…
        "mode": "oneshot",          # …your opinions win key-by-key:
        "system_prompt": composed,  # tag's system_prompt + your instructions
        "enable_file_tools": True,  # read/write/edit the workspace files
        "enable_python_tool": True, # run_python (artifacts land in the workspace)
        # OPTIONAL — structured output:
        "output_schema": MyModel.model_json_schema(),
        # OPTIONAL — assumptions-ledger companion pass. On a RAW config like
        # this it defaults ON (a user-facing run gets the ledger). For a
        # composition fan-out you usually don't want to pay for it — set
        # "ledger": False here, OR fold via oneshot_tag_values (below), which
        # defaults it OFF for composition and lets you opt back in per call.
        # "ledger": False,
    }}, timeout=300)

# `result.files` is the ENTIRE child workspace ({path: str|bytes}): the
# inputs you passed (possibly edited), any files the agent / its python tool
# created, plus the agent's bookkeeping under `_agent/`.
#
# Read the agent's reply + structured output through the accessors — they read
# the `_agent/output.*` convention so you don't hand-roll the magic-path +
# None-handling dance (a recurring footgun):
text = result.output_text                    # the assistant reply ("" if absent)
data = result.structured(MyModel)            # a MyModel, or None if no/blank JSON
#                                              (a schema MISMATCH raises MyModel's
#                                               own validation error — informative)
if data is None:
    ...  # no structured output — fall back to text, retry, or fail with context
# The edited / created files are the rest — strip the `_agent/` prefix:
edited = {p: c for p, c in result.files.items() if not p.startswith("_agent/")}
# The assumptions-ledger companion pass (on by default) adds three more
# bookkeeping outputs: `_agent/trace.json` (the run's full-fidelity trace —
# thinking, tool activity), `_agent/assumptions.ledger` (the claimed/enacted
# commitment record, JSON) and `_agent/assumptions.md`. PROMOTE the ledger
# into whatever cell your call's output becomes, so the `.ledger` renderer
# picks it up:
ledger = result.files.get("_agent/assumptions.ledger")
if ledger:
    gen.update_file("assumptions.ledger", ledger)
```

The `agent` generator runs in its OWN isolated sub-run workspace; the file +
python tools operate on that workspace, and the whole thing comes back in
`result.files`. (`gen.call` returns `ok=False` on a failed agent run — check
`result.ok` / `result.error`.)

#### Driving a child agent — the sharp edges

Composition has a few traps where the *obvious* code is subtly wrong. Reach
for the helpers below and you sidestep all of them.

* **Fanning out N children — use `gen.call_many`, NEVER `asyncio.gather`.**
  `asyncio.gather(gen.call(...), gen.call(...))` does **not** parallelize: each
  `gen.call`'s wait holds the bridge's single IPC lock for the child's whole
  runtime, so the children run one-at-a-time (and the event loop stalls). It
  *looks* like it works — it's just N× too slow. `gen.call_many` spawns all the
  children first (the host runs them concurrently) and polls to completion:

  ```python
  results = await gen.call_many(
      [{"source": "agent", "prompt": p, "config": cfg} for p in prompts],
      timeout=600, max_concurrent=8,   # cap the spawn window for big fan-outs
  )
  # One GeneratorResult per spec, IN ORDER. A failed/timed-out child is
  # ok=False (per-item isolation — the batch never raises for one bad child);
  # a user Stop mid-batch stops the rest and raises gen.Cancelled.
  for r in results:
      if r.ok:
          use(r.output_text)
  ```

* **`_agent_shared` is provided for you — `import` it, NEVER create it.**
  `gen.call_many` and the `GeneratorResult` accessors are on the `gen.*` /
  result surface directly (no import). The extra helpers below — `oneshot_tag_values`,
  `gather_agent_calls`, `parse_agent_config` — live in **`_agent_shared`**, a
  shared `_*` sibling cell the platform materializes next to your generator at
  run time. Just `from _agent_shared import oneshot_tag_values` and it resolves;
  your PEP 723 deps stay `["pyyaml", "pydantic"]` (it does NOT pull in
  pydantic-ai). **Do not write your own `_agent_shared.py`** — a hand-rolled
  copy ships incomplete validation and collides with the real sibling cell.
  (For a plain fan-out you don't even need it: `gen.call_many` is enough.)

* **Validate the config you SEND, before the fan-out — not the raw tag.**
  `parse_agent_config(tag_values)` validates the tag; then you override `mode`
  etc. and send a *different* config that can fail the child's strict
  validation — N wasted sub-runs. `_agent_shared.oneshot_tag_values` folds the
  tag + your overrides into the final one-shot config and validates *that*
  parent-side (raising before any call is spent), and reconciles a
  container-mode tag (`claude-terminal` → `claude-agent-sdk` backend) so
  subscription auth + CLI model aliases stay honorable:

  ```python
  from _agent_shared import oneshot_tag_values   # provided sibling — do not vendor it
  cfg = {"agent-config.set_yaml": oneshot_tag_values(
      tag_values, system_prompt=composed, output_schema=MyModel.model_json_schema())}
  ```

* **The assumptions-ledger costs an extra LLM call.** It's ON by default for a
  *user-facing* agent run, but a fan-out that discards it pays for nothing.
  `oneshot_tag_values` defaults it **off** for exactly this reason; pass
  `ledger=True` only on the calls whose ledger you actually PROMOTE into a cell.

* **Binary files just work — pass `bytes`.** `inputs=`, `gen.update_file`, and
  `create_stack_cell(files=...)` all accept `str | bytes`. Don't pre-decode an
  image or coerce it to text.

* **Observe the stop.** Between hand-rolled calls, poll `gen.cancelled` (or use
  `gen.call_many`, which does it for you) so a user Stop doesn't keep spending.

#### Streaming an agent's reply — `handle.stream_text()`

The generator→generator twin of run→UI streaming. Set `"stream": True` and
`spawn` (not `call`) for a live handle, then **`handle.stream_text()`** yields
the child's token deltas — forwarding a sub-run's reply to a chat turn is one
loop:

```python
handle = gen.spawn("agent", prompt=msg, config={"agent-config.set_yaml": {
    "backend": "pydantic-ai", "model": "claude-sonnet-4-6",
    "enable_file_tools": True, "stream": True,
}})
async for chunk in handle.stream_text():   # the agent's text deltas, in order
    turn.delta(chunk)                      # forward to the chat renderer
await handle.stop()
```

`stream_text(*, poll_interval=0.1, idle_timeout=None)` ends when the child
reaches done/failed, the parent is cancelled, or (with `idle_timeout`) the
child goes quiet. It is sugar over the lower-level `handle.events()`, which
yields the raw event dicts (`text_delta` / `tool` / `status` / `done`) if you
need more than text. Under the hood the child calls `gen.emit_event(event)`
(a no-op when the run has no parent or in dev mode). Structured-output turns
(`output_schema`) are one-shot and never streamed; the authoritative reply is
always the child's result (`_agent/output.md` / `handle.files()`), so a dropped
trailing delta never costs you the canonical text.

#### Live file sync — one engine, two entry points

Bidirectional file sync is a single, foolproof primitive. You almost never
write a sync loop:

* **`gen.live_files()`** — keep THIS run's workspace in sync with its cell (the
  Files tab). Set `live_files_mode: "auto"` and it runs for the whole run with
  zero code; use `live_files_mode: "manual"` + the `async with` block when you
  need custom `skip_dirs` / `exclude` or a one-way mirror:

  ```python
  async with gen.live_files(skip_dirs={".vscode"}):  # cell <-> own workspace
      await gen.wait_until_cancelled()                # (a Docker env, a server…)
  ```

* **`handle.mirror_files()`** — keep the cell in sync with a spawned sub-run's
  OWN workspace (the agent runs in its own dir). Same engine, echo-suppressed,
  final reconcile on exit. This is how a chat generator delegating to `agent`
  gets live editing across the spawn boundary:

```python
handle = gen.spawn("agent", inputs=cell_files, prompt=msg,   # seed initial state
    config={"agent-config.set_yaml": {..., "enable_file_tools": True, "stream": True}})
async with handle.mirror_files(exclude=(".chat",)):
    async for chunk in handle.stream_text():
        turn.delta(chunk)
await handle.stop()
```

While either block is open the two directions are echo-suppressed (a value
synced one way is never bounced back) and a final reconcile on exit keeps a
last-moment write; `.colreserved/` and the agent's `_agent/` bookkeeping are
always excluded. Both share the same signature —
`(*, to_cell=True, from_cell=True, exclude=(), interval=0.5)` for
`mirror_files`; `live_files` is the same plus `skip_dirs=` — so `from_cell=False`
gives a one-way (workspace→cell) mirror. Seed a sub-run's initial state at spawn
via `inputs=`. `GeneratorHandle` also exposes `put_files`, `read_file`, `files`,
and `snapshot` if you want to drive the workspace plane by hand.

Under the hood both are one `_Mirror`: it reconciles two file endpoints (own
workspace, the cell, or a child's workspace) on a short interval against a
shared `path → hash` map. The cell endpoint reads the user's live state — the
committed tip overlaid with pending Files-tab drafts — through the host's
`read_cell_files` op, so edits show up without waiting for a turn.

### Subprocess / ports / terminals

```python
rc, output = await gen.run_subprocess(
    command,                  # list[str] | str
    *,
    turn_id=None,             # bind output to a chat-stream turn id
    timeout=120, cwd=None, shell=False,
    emit_bash_stdout=True, emit_text_delta=False, print_stdout=True,
)
# Streams the child's stdout line-by-line. Cooperative cancellation:
# gen.cancelled polled per line; on True the process is terminate'd.

await gen.serve_port(port, *, name="preview", path="", snapshot_source=None)
# Bind a port for daemon generators; the host opens a sandbox iframe
# on the cell. Pair with daemon: true in the manifest.

async with gen.serve_terminal(
    container_id, command, *,
    cwd=None, env=None,
    label="Terminal",           # renderer title-bar text
    pointer="app.terminal",     # pointer file path (must end in .terminal)
    buttons=None,               # [{"id", "label"}] → toolbar buttons (see gen.actions)
    name=None, summary=None,    # ride the same gen.update flush that pins the pointer
) as session:
    ...
# The one-stop terminal surface: allocates the PTY, writes + pins the
# canonical .terminal pointer, and stops the session when the block exits
# (even on an exception). `session` is the raw {session_id, ws_path, token}.
# Container teardown stays yours — wrap this block in your own try/finally.

async for action in gen.actions():
    ...
# Yield renderer action ids (toolbar button clicks) until the user stops the
# run — the idiomatic daemon loop for a cell with `buttons`. Ends itself on
# cancellation, so the body needs no `while not gen.cancelled` bookkeeping.
# A daemon with no buttons parks on gen.wait_until_cancelled() instead.

session = await gen.terminal(container_id, command, *, cwd=None, env=None)
# Low-level: allocate the PTY only. Returns {session_id, ws_path, token}.
# Reach for this (plus collimate.pointers.terminal_pointer and your own
# teardown) only when serve_terminal's lifecycle doesn't fit — e.g. several
# PTYs on one cell, or a pointer you rewrite mid-run.

gen.stop_terminal(session_id)  # idempotent teardown (serve_terminal calls it)
```

### Workspace + snapshot + settings + actions

```python
gen.workspace_path()    # str — absolute path to the workspace dir

gen.snapshot()          # {relpath: sha256_hex} for every file
                        # Pair before/after a subprocess to detect changes.

values = await gen.request_settings("path/to/file.set_yaml")
# Pop a settings overlay against a .set_yaml file in the workspace;
# block until the user presses Continue and return the updated dict.

action = await gen.wait_for_action(timeout=None)
# Block until a renderer emits an action (e.g. button click), or the
# timeout / Stop. Returns the action id or None.
```

### Live stream events (custom chat backends)

```python
gen.emit_stream_event(turn_id, {"type": "text_delta", "text": chunk})
```

Fire-and-forget push of a typed stream event to the cell's live chat renderer. Used by `turn.delta` / `turn.tool` internally; reach for it directly only when driving a custom chat backend by hand inside a `serve_chat` handler.

This is the run→UI stream. Its generator→generator twin is `gen.emit_event(event)` (a child pushes an event to its parent) + `GeneratorHandle.events()` (the parent consumes them) — that is how a spawned `agent` sub-run streams its reply back to a chat handler (see "Streaming an agent's reply").

### Exceptions

```python
gen.Cancelled                   # raised by api_key / secret / request_settings on user-cancel
gen.IPCError                    # base for IPC-protocol failures (NAK, timeout, disconnected)
gen.IPCNakError, gen.IPCTimeoutError, gen.IPCDisconnectedError
```

### Composition — discover, call, and spawn other generators

A generator can run **other** generators as black-box sub-runs. This is a
public capability — the builders use the same surface, no private powers.
Children are **parent-bound**: the host stops them automatically when this
run ends (or the handle's `async with` exits). Nothing is shown to the user
unless you explicitly surface it.

```python
gen.generators(*, group=None) -> list[GeneratorInfo]   # discover (host-backed; [] in dev)
gen.generator_info(gid) -> GeneratorInfo | None           # one generator by id (sugar)
gen.inline(files, *, entrypoint) -> Source                # wrap an uninstalled candidate
gen.spawn(source, *, inputs=None, input_groups=None, prompt="",
          invocation_type="create", config=None, secrets=None,
          surface=None) -> GeneratorHandle                # start a child; live handle
await gen.call(source, *, …, timeout=300.0) -> GeneratorResult   # spawn + wait + stop
gen.check_renderer(files, *, entrypoint) -> RendererCheck        # host esbuild compile-check (any generator)
```

`source` is an installed generator **id** (from `gen.generators()`) or an
inline `gen.inline(files, entrypoint=...)` candidate. `gen.call` is sugar
for the **terminating** case; a **daemon** child (`info.daemon` true) never
completes, so `spawn` it and use the handle:

**Each `GeneratorInfo` carries the callee's config schema** so you can build a
valid `config=` without guessing: `info.config_tags` (named presets — each
tag's `.values` is a drop-in `config=` overlay) and `info.draft_files` (per
`.set_yaml`: each field's `key/type/label/description/required/default/options`).
`info.cell_id` names the source cell for the read/write API below. Only
generators in **exposed** cells are listed.

**Resolving a preset is one call — `gen.tag_config`**:

```python
gen.tag_config(gid, tag, *, overrides=None) -> dict   # a ready-made config=
```

A blank `tag` returns just the `overrides` (the callee's own defaults apply);
an unknown tag — or an unreachable callee — raises `ValueError` naming the
available tags, so your run fails with actionable guidance instead of
silently running on the wrong settings. `overrides` is the same
`{set_yaml_rel: {key: value}}` shape and wins key-by-key.

This backs **the parent-generator convention**: a generator that drives a
sub-generator does NOT mirror the callee's settings in its own draft file.
It surfaces ONE text field per callee — `<callee>_config_tag`, blank by
default — resolves it, and overrides only the settings it has opinions
about. The user tunes the callee ONCE, as named tags on that generator, and
every parent follows. It applies to any callee with config tags: the
LLM-driving generators name an `agent_config_tag` (overriding mode, tools,
output schemas, prompts); `code_runner` names a `linux_env_config_tag` and
passes the resolved payload straight to `gen.spawn("linux-env",
config=...)`. It's a convention, not a hard rule — surface one of the
callee's individual settings only when the parent genuinely owns that
decision (the way `challenge` owns its python-on default).

- `await handle.wait(timeout=None) -> GeneratorResult`
- `async for ev in handle.events(*, poll_interval=0.1, idle_timeout=None)` — the child's `gen.emit_event` stream, in order, until it finishes (the live-streaming twin of run→UI; see "Streaming an agent's reply")
- `await handle.endpoints(wait=True, timeout=30) -> list[Endpoint]` — daemon ports/terminals
- `await handle.files()` / `await handle.status()`
- `await handle.stop()` — idempotent; also runs on `async with` exit
- `await handle.surface(gen.SurfaceSpec(name=…)) -> cell_id` — promote to a visible cell

`GeneratorResult` is the same type the testing harness returns (`.ok`,
`.files`, `.name`, `.summary`, `.cells`, `.endpoints`, `.error`). `call`
returns `ok=False` on child failure — call `.raise_for_status()` to raise.

**Invisible by default** — `spawn`/`call` create no cell; the child runs in
its own isolated workspace. Surface a sub-run only when the user should see
it (e.g. a daemon's preview iframe). In dev mode (no host) these degrade to
a clean `ok=False` / empty list — they never hang or raise.

**Composition-only / hidden generators.** A generator can ship out of the
human picker yet remain callable by other generators. Picker visibility is the
manifest baseline `available_ui: false` (overridable by a per-channel on/off
switch). **Callability is separate** — it follows the source CELL's "expose to
generators" setting (a per-channel switch, exposed by default). The `agent`
generator (the LLM toolset that backs every LLM generator — see "Running an LLM
agent") is `available_ui: false` (invisible to humans) yet reachable via
`gen.call("agent", ...)` because its cell is exposed by default.

### Editing other generators — read & write exposed cells

Beyond *running* generators, you can introspect and **edit** them. The cross-cell
API is gated entirely on cell exposure: a generator may read or write only cells
the user marked "expose to generators" (generator- AND renderer-source cells;
exposed by default). Every `write_cell` commits a normal, undoable cell
**version** (it shows in the cell's history scrubber and can be rolled back) AND
applies to the cell's live state, so the edit takes effect on that cell's next
run. (This is distinct from `gen.read_file`/`gen.update` — those only touch
*your own* run's cell.)

```python
gen.exposed_cells() -> list[dict]      # {cell_id, name, stack_type, generators:[id], files:[path]}
gen.read_cell(cell_id) -> {path: str|bytes}                     # full current file tree
gen.write_cell(cell_id, files, *, summary=None, deleted=None) -> version_id
# Helpers (read → YAML edit → write):
gen.add_generator(cell_id, *, id, name, entrypoint, files, summary="", type=None, **manifest_fields) -> version_id
gen.add_renderer(cell_id, *, id, name, entrypoint, files, summary="", extensions=None, **manifest_fields) -> version_id
gen.set_config_tag(cell_id, generator_id, tag, body, *, summary=None) -> version_id
gen.delete_config_tag(cell_id, generator_id, tag, *, summary=None) -> version_id
# Create a BRAND-NEW source cell in a stack (vs add_generator/add_renderer, which
# edit an EXISTING exposed cell). The new cell is exposed to generators
# immediately, so you can read_cell/write_cell it on the next line.
gen.create_generator_cell(name, *, files, summary=None, pinned=None) -> cell_id
#   files must include a valid manifest.gen_yaml + the entrypoint it names
gen.create_renderer_cell(name, *, files, summary=None, pinned=None) -> cell_id
#   files must include a valid manifest.rend_yaml + the entrypoint it names
```

The discover → read → edit loop:

```python
# Find an exposed generator and read its code.
info = gen.generator_info("echo")              # or pick from gen.generators()
tree = gen.read_cell(info.cell_id)             # {path: content}
src  = tree["echo/echo.py"]

# Add a brand-new generator into an exposed cell (manifest is lint-checked).
gen.add_generator(
    info.cell_id,
    id="greeter", name="Greeter", entrypoint="greeter.py",
    summary="Write a greeting.", type=["create"],
    files={"greeter.py": "import gen\n\ndef run():\n    gen.update_file('hi.md', '# hi')\n"},
)

# Tweak an existing generator's config tag.
gen.set_config_tag(info.cell_id, "echo", "fast", {
    "files": {"agent-config.set_yaml": {"model": "claude-haiku-4-5"}},
})

# Or create a WHOLE NEW generator cell from scratch (lands in the generator
# stack, exposed). Renderers are identical: gen.create_renderer_cell with a
# manifest.rend_yaml.
new_id = gen.create_generator_cell(
    "Greeter",
    files={
        "manifest.gen_yaml": (
            "id: greeter\nname: Greeter\nentrypoint: greeter.py\n"
            "summary: Write a greeting.\ntype: [create]\n"
        ),
        "greeter.py": "import gen\n\nasync def run():\n    gen.update_file('hi.md', '# hi')\n",
    },
)
# Iterate on it immediately — it's already exposed:
gen.read_cell(new_id)
```

`read_cell`/`write_cell` raise `PermissionError` when the cell isn't exposed;
`write_cell` raises `ValueError` on a manifest that fails validation or an
illegal path. A generator-authored edit versions the **channel's live cell** —
it does not touch the on-disk SDK source.

### Environments — daemon generators you run work *inside*

An **environment** is a daemon that owns a runtime (a container) and lets a
parent generator run work inside it — the typed twins of the surfaces a human
drives on the cell. The mental model: *a daemon serves its parent the same way
it serves a human.* The human gets a terminal / a served port; the parent gets
the handle verbs below. Environments **compose** — one environment can be a thin
layer over another. The SDK is **Docker-free** — the only Docker-aware code is
the `_env_shared.DockerEnvironment` helper (shared generator code, copied as a
`_*` sibling like `_cdp_shared`); the host never learns a container id.

Declare it in the manifest (implies `daemon: true`):

```yaml
environment: true                    # core: workspace r/w + exec + exec_background + expose_port
# — or declare extras —
environment:
  terminals: 2                       # up to N worker-opened PTYs (default 0)
  watch: true                        # push file-change events (default pull-only)
  concurrent_exec: false             # exec may run in parallel (default serialized)
```

**Authoring an environment** — wire a container to `gen.serve_environment` via
the helper (a base environment is a few lines):

```python
import os, sys
import gen
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from _env_shared import DockerEnvironment        # shared generator code (a _* sibling)

async def run():
    env = DockerEnvironment(image="collimate-linux-small:v1", mount="/work")
    env.surface_terminal(label="Shell")          # human surface (a .terminal)
    await gen.update(name="Linux Env", summary="environment ready")
    await env.serve()                            # blocks until Stop; removes the container
```

`await gen.serve_environment(on_exec=…, on_exec_background=…, on_expose_port=…,
on_terminal=…, on_wait_process=…, on_stop_process=…)` is the raw primitive the
helper fills: each handler takes a typed `Request` (`.command`, `.cwd`, `.env`,
`.port`, `.process_id`) and **returns** its result. Only the environment author
writes this; workers never see it.

**Driving an environment** (the worker) — spawn it once and use the handle. The
worker never imports `docker` or sees a container id:

| Handle verb | Plane | Guarantee |
|---|---|---|
| `await env.capabilities()` → `EnvironmentSpec` | — | the contract; `None` if not an environment |
| `await env.put_files(map)` / `write_file` / `read_file` / `delete_file` / `list_files` / `snapshot` | workspace | guaranteed (host-serviced) |
| `await env.watch_files()` | workspace | push (declared) else poll `snapshot` |
| `await env.exec(cmd, *, cwd, env, timeout)` → `(rc, output)` | execution | guaranteed |
| `await env.exec_background(cmd)` → `ProcessHandle` (`.wait()` / `.stop()`) | execution | guaranteed |
| `await env.expose_port(port)` → `Endpoint` (also in `endpoints()`) | execution | guaranteed |
| `await env.open_terminal(cmd)` → `{session_id, ws_path, token}` | execution | declared `terminals: N` |

The **workspace plane** is host-serviced (the env just mounts its workspace
read-write), so files are guaranteed; the **execution plane** is routed to the
env's own process. Read the contract before spawning via
`gen.generators()` → `info.environment`, or `await handle.capabilities()` after.

Dual-use: the *same* environment is a normal visible cell when a human runs it
directly (its `.terminal`/`.website` render; the serve loop idles), and an
invisible child a worker drives (the serve loop fields its requests). The exec
channel is keyed to the spawning parent, so direct human use exposes no new
surface beyond the terminal/port the author chose.

**Choosing the shape — "new image = new generator".** Each Docker image is its
own generator. Make it an *environment* (`environment: true`, the helper's
`.serve()`) only when the image is meant to be **driven by other generators** —
e.g. `linux-env`, a generic Linux box many workers run code in. A generator
whose image is **single-consumer** and human-facing (a VS Code iframe, a Claude
TTY) just uses `_env_shared.DockerEnvironment` directly for the container
lifecycle + `exec` / `expose_port`; it stays a plain `daemon`, **not** an
environment, because nothing else drives it. If a second generator later wants
the same image, *that* is when you extract an environment-generator for it — and
the original becomes one of its consumers. Don't reach for `serve()`/routing
until there's a real second consumer; the indirection only pays off then.

---

## 7. Worked examples

### Example A — pure Python, no LLM (the `merge` generator)

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Union 2+ input cells into one output cell. Topmost wins on collisions."""
import gen

async def run():
    rows: list[str] = []
    for label, cell_files in gen.input_groups().items():
        rows.append(f"- **{label}**: {len(cell_files)} files")
        for path, content in cell_files.items():
            if not gen.has_file(path):
                gen.update_file(path, content)

    gen.update_file("_merge.md", "# Merge\n\n" + "\n".join(rows) + "\n")
    await gen.update(
        name=f"merged",
        summary=f"merged {len(gen.input_groups())} cells",
        pinned="_merge.md",
    )

if __name__ == "__main__":
    gen.main(run)
```

### Example B — single-shot LLM agent (modify_files-style)

Delegate the LLM turn to the `agent` toolset generator with `gen.call`. The
agent edits its own sub-run workspace; the edited files come back in
`result.files`.

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Run an agent over the input cell's files. Carries unedited files forward."""
import gen

async def run():
    cfg = gen.config("agent-config.set_yaml")
    if not gen.prompt.strip():
        gen.update_file("error.md", "# No prompt\n\nDescribe what to do.\n")
        return  # auto-flush handles the cell write

    files = gen.input_files()
    result = await gen.call("agent", inputs=files, prompt=gen.prompt, config={
        "agent-config.set_yaml": {
            "backend": (cfg.get("backend") or "pydantic-ai"),
            "provider": (cfg.get("provider") or "anthropic"),
            "model": (cfg.get("model") or "claude-sonnet-4-6"),
            "max_tokens": cfg.get("max_tokens", 4096),
            "system_prompt": cfg.get("system_prompt", "")
                + "\n\nEdit files using the read/write/edit tools. Leave "
                  "unrelated files alone. Use run_python for any computation, "
                  "analysis, or artifact generation.",
            "enable_file_tools": True,
            "enable_python_tool": True,
        }}, timeout=300)
    if not result.ok:
        gen.update_file("error.md", f"# Agent run failed\n\n{result.error}\n")
        return

    # The edited candidate = the child workspace minus the agent's bookkeeping.
    for path, content in result.files.items():
        if not path.startswith("_agent/"):
            gen.update_file(path, content)
    text = result.files.get("_agent/output.md", "")
    await gen.update(summary=text[:120])

if __name__ == "__main__":
    gen.main(run)
```

### Example C — daemon chat (the agent generator's chat mode is this pattern)

Each turn spawns the `agent` generator with `"stream": True`. The two
composition helpers keep the per-turn body tiny: `handle.stream_text()` pipes
the reply to `turn.delta`, and `handle.mirror_files()` gives full
bidirectional `live_files` editing across the spawn boundary.

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Multi-turn chat that delegates each turn to the `agent` generator. Stop
ends the conversation."""
import gen

_INFRA = (".chat",)

async def run():
    cfg = gen.config("agent-config.set_yaml")
    agent_config = {
        "backend": (cfg.get("backend") or "pydantic-ai"),
        "provider": (cfg.get("provider") or "anthropic"),
        "model": (cfg.get("model") or "claude-sonnet-4-6"),
        "system_prompt": cfg.get("system_prompt", ""),
        "enable_file_tools": True,
        "enable_python_tool": True,
        "stream": True,
    }

    def cell_files():
        return {p: gen.read_file(p) for p in gen.list_files()
                if not p.endswith(_INFRA) and not p.startswith("_agent/")}

    async def on_turn(turn):
        gen.history.append("user", turn.user_msg)
        await gen.update()
        # Seed the agent with the cell's current files (honours edits made
        # between turns); mirror_files() syncs both ways during the turn.
        handle = gen.spawn("agent", inputs=cell_files(), prompt=turn.user_msg,
                           config={"agent-config.set_yaml": dict(agent_config)})
        reply = ""
        try:
            async with handle.mirror_files(exclude=_INFRA):
                async for chunk in handle.stream_text():
                    if turn.cancelled:
                        break
                    reply += chunk
                    turn.delta(chunk)            # stream to the chat renderer
            if not reply.strip():                # canonical text if deltas were lost
                out = (await handle.files()).get("_agent/output.md")
                reply = out if isinstance(out, str) else reply
        finally:
            await handle.stop()
        gen.history.append("assistant", reply.strip() or "_(empty response)_")
        await gen.update(summary=turn.user_msg[:80])  # show the turn

    await gen.serve_chat(on_turn)

if __name__ == "__main__":
    gen.main(run)
```

Manifest needs `chat: true`. Chat generators typically declare
`type: ["modify", "create"]` so the per-cell button resumes the chat
against that cell's prior history *and* the top-bar button can fire a
fresh chat against an empty cell. Pair `create` with `inputs.cells:
{min: 0, max: 0}` so the fresh-chat path takes no input. Drop the
`mirror_files` block (and `live_files_mode`) if you don't need live file
editing; the chat still streams. The shipped `agent` generator's `chat` mode
(`generators/agent`) is this pattern, running the engine inline per turn.
```yaml
id: "live-chat"
name: "Live Chat"
type: ["modify", "create"]
version: "0.1.0"
summary: "Multi-turn chat with read/write/edit file tools."
entrypoint: "live_chat.py"
chat: true
inputs:
  cells: { min: 0, max: 1 }   # 0 → fresh chat; 1 → the modify path
draft_files:
  - "agent-config.set_yaml"
config_tags:
  default: {}
```

### Example D — subprocess one-shot (git_clone-style)

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Clone a Git repo into the cell. Streams output to the run log."""
import gen

async def run():
    cfg = gen.config("clone-config.set_yaml")
    repo = (cfg.get("repo") or "").strip()
    if not repo:
        gen.update_file("error.md", "# No repo\n\nSet `repo` in config.\n")
        await gen.update(name="Git Clone", summary="Failed: no repo")
        return

    # Identity first, then phase the lifecycle.
    await gen.update(name="Git Clone", summary=f"Cloning {repo}…")

    token = await gen.secret("GITHUB_TOKEN", prompt_if_missing=True,
                              description="GitHub token for private repos (optional)")
    env = {"GIT_TERMINAL_PROMPT": "0"}
    if token:
        env["GIT_ASKPASS"] = "echo"
        env["GITHUB_TOKEN"] = token

    gen.phase("spinning_up", "cloning")
    rc, output = await gen.run_subprocess(
        ["git", "clone", "--depth=1", repo, "."],
        cwd=gen.workspace_path(),
        timeout=300,
    )
    if rc != 0:
        reason = f"clone failed (rc={rc})"
        gen.log(reason)
        gen.update_file("error.md", f"# Clone failed\n\n```\n{output}\n```\n")
        await gen.update(summary=f"Failed: {reason}")
        return

    gen.phase("running", "writing files")
    gen.update_file("_clone.md", f"# Cloned {repo}\n")
    await gen.update(summary=f"Cloned {repo}")

if __name__ == "__main__":
    gen.main(run)
```

### Example E — port-bound daemon (browser_live-style)

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "aiohttp"]
# ///
"""Bind an HTTP server on a free port; the cell shows it as a live preview."""
import asyncio
import gen
from aiohttp import web

async def run():
    app = web.Application()
    app.router.add_get("/", lambda r: web.Response(text="hello"))

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]

    await gen.serve_port(port, name="hello-server")
    gen.update_file("_server.md", f"# Server on port {port}\n")
    await gen.update(summary=f"serving on :{port}")

    while not gen.cancelled:
        await asyncio.sleep(0.5)

    await runner.cleanup()

if __name__ == "__main__":
    gen.main(run)
```

Manifest:
```yaml
id: "hello-server"
name: "Hello Server"
type: ["create"]
version: "0.1.0"
summary: "Bind a tiny HTTP server."
entrypoint: "server.py"
inputs:
  cells: { min: 0, max: 0 }   # no input → spun up fresh
daemon: true
```

### Example F — container daemon with terminal (the agent generator's claude-terminal mode is this pattern)

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Open a Docker container, expose a terminal in the cell, wait for actions."""
import gen

async def run():
    rc, cid = await gen.run_subprocess(
        ["docker", "run", "-d", "-v",
         f"{gen.workspace_path()}:/work", "ubuntu:22.04", "sleep", "infinity"],
    )
    cid = cid.strip()
    if rc != 0 or not cid:
        gen.update_file("error.md", f"# Container failed\n\n{cid}\n")
        return

    try:
        # serve_terminal owns the PTY lifecycle: it allocates the session,
        # writes + pins the canonical shell.terminal pointer (with the
        # toolbar button), and stops the session when the block exits.
        async with gen.serve_terminal(
            cid, ["bash"], cwd="/work",
            label="Shell", pointer="shell.terminal",
            buttons=[{"id": "capture", "label": "Capture"}],
            name="Container", summary="terminal ready",
        ):
            # gen.actions() ends itself when the user stops the run — no
            # `while not gen.cancelled` bookkeeping in the loop body.
            async for action in gen.actions():
                if action == "capture":
                    rc2, listing = await gen.run_subprocess(["ls", "-la", "/work"])
                    await gen.create_stack_cell(
                        "Capture", summary="workspace listing",
                        files={"listing.txt": listing},
                    )
    finally:
        # The container is yours; serve_terminal only tears down the PTY.
        await gen.run_subprocess(["docker", "rm", "-f", cid], timeout=10)

if __name__ == "__main__":
    gen.main(run)
```

Manifest:
```yaml
id: "container-shell"
name: "Container Shell"
type: ["create"]
version: "0.1.0"
summary: "A bash shell inside a fresh Ubuntu container."
entrypoint: "container_shell.py"
inputs:
  cells: { min: 0, max: 0 }   # no input → a fresh container
daemon: true
chat: false
```

### Example G — call another generator and fold its output

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Run the installed merge generator over our inputs, then keep its files."""
import gen

async def run():
    r = await gen.call("merge", input_groups=gen.input_groups())
    if not r.ok:
        gen.update_file("error.md", f"# sub-run failed\n\n{r.error}\n")
        return
    for path, content in r.files.items():
        gen.update_file(path, content)
    await gen.update(summary=f"merged via sub-run: {len(r.files)} files")

if __name__ == "__main__":
    gen.main(run)
```

### Example H — spawn a preview daemon, surface it, tear it down

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Edit the input files (terminating child), then open them in a live
VS Code daemon the user can use while this run stays alive; stop it on
exit (parent-bound)."""
import gen

async def run():
    edited = await gen.call("modify-files", inputs=gen.input_files(),  # terminating
                            prompt="add a /hello endpoint")
    async with gen.spawn("vscode-env", inputs=edited.files,            # daemon, parent-bound
                         surface=gen.SurfaceSpec(name="Editor")) as env:
        eps = await env.endpoints()                                    # [Endpoint(http, url=…)]
        if eps:
            gen.log(f"editor at {eps[0].url}")
        # ...let the user work in the editor while THIS run stays alive...
    # context exit -> the vscode-env daemon is stopped automatically

if __name__ == "__main__":
    gen.main(run)
```

### Example I — an environment, and a worker that drives it

The environment (a daemon; `environment: true` in the manifest):

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "docker"]
# ///
"""A warm Linux container a worker can run code in, and a human can shell into."""
import os, sys
import gen
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from _env_shared import DockerEnvironment   # shared generator code (a _* sibling)

async def run():
    env = DockerEnvironment(image="collimate-linux-small:v1", mount="/work")
    env.surface_terminal(label="Shell")            # human surface
    await gen.update(name="Linux Env", summary="environment ready")
    await env.serve()                              # serve the parent; remove the container on Stop

if __name__ == "__main__":
    gen.main(run)
```

The worker (spawns it once, pushes code, runs it, launches a server — no Docker):

```python
import gen

async def run():
    async with gen.spawn("linux-env", inputs=gen.input_files()) as env:
        if await env.capabilities() is None:
            gen.update_file("error.md", "# linux-env unavailable\n"); return
        await env.put_files(gen.input_files())
        rc, out = await env.exec(["python", "-m", "pytest", "-q"], cwd="/work")
        gen.update_file("run.txt", f"(exit {rc})\n{out}")
        if rc == 0:                                 # green → launch + preview the app
            await env.exec_background(["python", "app.py"], cwd="/work")
            ep = await env.expose_port(8000)
            gen.update_file("preview.website", f'{{"url": "{ep.url}"}}')

if __name__ == "__main__":
    gen.main(run)
```

---

## 8. Checklist before shipping

- [ ] `manifest.gen_yaml` has `id`, `name`, `type`, `version`, `summary`, `entrypoint`.
- [ ] `type` is a list of 1–2 of `modify` / `create` and matches the
      input contract:
      `modify` in the array → `inputs.cells` includes 1 (the current cell);
      `create` in the array → `inputs.cells.min >= 0`, with the bounds picking
      the input shape (no input `{min: 0, max: 0}`, a single cell `{min: 1,
      max: 1}`, or a stack like `{min: 1, max: 99}`). Mixed lists like
      `["modify", "create"]` follow the strictest applicable rule.
- [ ] `summary` is present, non-empty, and 1–2 sentences. Lint warns when
      longer.
- [ ] If the manifest has a `prompt_intent` or any `.set_yaml` in
      `draft_files`, it declares `config_tags:` with a `default:` tag
      (`config_tags: {default: {}}` when no named presets are needed).
- [ ] `prompt_required: true` if the run is useless without a prompt (only
      legal with `prompt_intent`); `required: true` on `.set_yaml` fields the
      run can't proceed without (never on a `checkbox` — lint warns).
- [ ] `chat: true` if the generator loops over user messages; `daemon: true` if it stays alive serving a port/terminal; `ephemeral: true` for a throwaway live session whose cell never enters DAG history (offers "close" instead of "stop").
- [ ] If the run needs to branch on which mode the user picked, read
      `gen.invocation_type` ("modify" | "create").
- [ ] PEP 723 `# /// script` block at the top of the .py file lists every dep (`pyyaml` plus anything specific). **Do not list `collimate-sdk`** — the host injects the SDK source onto `PYTHONPATH` so `import gen` works without `uv` having to resolve a published package.
- [ ] `if __name__ == "__main__": gen.main(run)` is the entrypoint.
- [ ] Long-running loops poll `gen.cancelled` (or use `gen.serve_chat`, `gen.run_subprocess`, `gen.wait_for_action`, which handle it internally; a chat handler forwarding a spawned `agent`'s stream checks `turn.cancelled` in its `handle.events()` loop).
- [ ] Subprocess errors land in the cell as a clear error file, not as an unhandled exception.
- [ ] Daemon generators clean up resources (terminals, ports, containers) in a `try/finally`.
- [ ] Validated the run host-free with `collimate.testing.run_generator` (seed
      inputs/config/prompt, assert `result.ok` and `result.files`) before
      shipping — see [`testing-generators.md`](./testing-generators.md).
- [ ] Pointer files (`.terminal` / `.website`) follow the shared contract —
      build `.terminal` with `collimate.pointers.terminal_pointer(...)`.
- [ ] If you compose other generators, use `gen.call` (terminating) /
      `gen.spawn` (daemon) — invisible by default; surface only what the
      user should see.
- [ ] If your daemon owns a runtime others should run work in, declare
      `environment:` (implies `daemon`), build it with
      the `_env_shared.DockerEnvironment` helper (shared generator code, **not**
      in the SDK — keeps `collimate` Docker-free) and `await env.serve()`.
      Workers drive it with `handle.exec` /
      `put_files` / `exec_background` / `expose_port` — never `import docker`.
      Environments are `spawn`ed, never `call`ed.

---

## 9. `gen.*` cheat sheet

Every tool available to a generator. `await` the coroutines (noted). Tier A is
portable (mirrored on the WASM runtime); **Tier B** is native-only.

### Run shape & lifecycle
| Call | Returns | Notes |
|---|---|---|
| `gen.main(run)` | — | entrypoint, in `if __name__ == "__main__"` |
| `gen.prompt` | `str` | picker textarea text |
| `gen.invocation_type` | `str` | `"modify"`\|`"create"` the user picked |
| `gen.cancelled` | `bool` | Stop pressed — poll in loops |
| `gen.messages` | `list[Message]` | prior chat history from input cells |

### Inputs & config
| Call | Returns |
|---|---|
| `gen.read_input(path)` | `str \| bytes` |
| `gen.input_files()` | `dict[path, content]` |
| `gen.input_groups()` | `dict[label, dict]` (multi-cell) |
| `gen.config(name)` | `dict` (YAML/JSON by ext; `{}` if missing) |

### Output stage (this cell's files) & cells
| Call | Returns |
|---|---|
| `gen.update_file(path, content)` · `read_file(path)` · `has_file(path)` · `list_files()` · `delete_file(path)` | file I/O on the stage |
| `await gen.update(*, name=, summary=, pinned=)` | flush a version of the running cell |
| `await gen.create_stack_cell(name, *, summary=, pinned=, files=)` | `cell_id` — mint a sibling |
| `async with gen.live_files(*, to_cell=, from_cell=, exclude=(), skip_dirs=, interval=0.5):` | live bidirectional cell ↔ own-workspace sync (or set `live_files_mode: "auto"` for zero code) |
| `await gen.wait_until_cancelled(poll=0.5)` | park a daemon until the user stops the run |

### Chat history & live chat
| Call | Returns |
|---|---|
| `gen.history.append(role, content)` · `.switch_thread(id)` · `.seed()` · `list(gen.history)` | active thread → open transcript `chats/<id>.json` |
| `await gen.serve_chat(on_turn, *, label=, threads_dir="chats", default_thread="main", resume=True, integration=None)` | — (serves a multi-thread streaming chat, rendered by assistant-ui, until Stop) |
| `turn.user_msg` · `turn.delta(text)` · `turn.tool(name, status, **kw)` · `turn.cancelled` · `turn.redirect` | the `ChatTurn` handed to `on_turn` |
| `gen.emit_stream_event(turn_id, event)` | — (run→UI stream; custom in-handler backends) |
| `gen.emit_event(event)` | — (run→**parent** stream; consumed by `handle.events()`) |

### Secrets · status · LLM
| Call | Returns |
|---|---|
| `await gen.api_key(provider, *, force=False, description="")` | `str` (sets the env var) |
| `await gen.secret(name, *, prompt_if_missing=False, description="")` | `str` |
| `gen.log(line)` · `gen.status(msg)` · `gen.progress(cur, total)` | — |
| `await gen.call("agent", *, inputs=, prompt=, config={"agent-config.set_yaml": {...}}, timeout=)` | `GeneratorResult` — assistant text in `.files["_agent/output.md"]`, structured JSON in `.files["_agent/output.json"]` (with `output_schema`), edited files in `.files` |
| `gen.spawn("agent", *, prompt=, config={"agent-config.set_yaml": {..., "stream": True}})` + `async for chunk in handle.stream_text(): turn.delta(chunk)` | stream a sub-run agent's reply to a chat turn |
| `async with handle.mirror_files(exclude=(...)):` | live-sync the cell ↔ sub-run workspace both ways (same engine as `gen.live_files`, across a spawn) |

### Subprocess · ports · terminals · workspace — **Tier B**
| Call | Returns |
|---|---|
| `await gen.run_subprocess(cmd, *, timeout=120, cwd=, shell=, turn_id=, …)` | `(rc, output)` — runs **here**, streams |
| `await gen.serve_port(port, *, name="preview", path="", snapshot_source=None)` | — (daemon iframe; `.website`) |
| `await gen.terminal(container_id, cmd, *, cwd=, env=)` | `{session_id, ws_path, token}` (`.terminal`) |
| `gen.stop_terminal(session_id)` | — |
| `gen.workspace_path()` · `gen.snapshot()` | abs path · `{relpath: sha256}` |
| `await gen.request_settings(path)` · `await gen.wait_for_action(timeout=None)` | values dict · action id\|`None` |

### Composition — run other generators (Tier B; dev-mode safe)
| Call | Returns |
|---|---|
| `gen.generators(*, group=None)` | `list[GeneratorInfo]` (exposed only; `.config_tags`/`.draft_files` = callee schema, `.cell_id`, `.environment`) |
| `gen.generator_info(gid)` | `GeneratorInfo \| None` (sugar over `generators()`) |
| `gen.tag_config(gid, tag, *, overrides=None)` | ready-made `config=` from a named tag (blank → overrides only; unknown → `ValueError` naming the available tags) |
| `gen.inline(files, *, entrypoint)` | `Source` |
| `gen.spawn(source, *, inputs=, input_groups=, prompt=, invocation_type=, config=, secrets=, surface=)` | `GeneratorHandle` (daemon-safe) |
| `await gen.call(source, *, …, timeout=300)` | `GeneratorResult` (terminating only) |
| `gen.check_renderer(files, *, entrypoint)` | `RendererCheck` |

### Edit other generators — read/write exposed cells (Tier B; gated on cell exposure)
| Call | Returns |
|---|---|
| `gen.exposed_cells()` | `list[{cell_id, name, stack_type, generators, files}]` |
| `gen.read_cell(cell_id)` | `{path: str\|bytes}` (raises `PermissionError`/`LookupError`) |
| `gen.write_cell(cell_id, files, *, summary=None, deleted=None)` | `version_id` (undoable version + live apply) |
| `gen.add_generator(cell_id, *, id, name, entrypoint, files, summary="", type=None, **manifest_fields)` | `version_id` |
| `gen.add_renderer(cell_id, *, id, name, entrypoint, files, summary="", extensions=None, **manifest_fields)` | `version_id` |
| `gen.create_generator_cell(name, *, files, summary=None, pinned=None)` | `cell_id` — new generator source cell, auto-exposed |
| `gen.create_renderer_cell(name, *, files, summary=None, pinned=None)` | `cell_id` — new renderer source cell, auto-exposed |
| `gen.set_config_tag(cell_id, generator_id, tag, body, *, summary=None)` · `gen.delete_config_tag(cell_id, generator_id, tag, *, summary=None)` | `version_id` |

`GeneratorHandle`: `await wait(timeout=)` · `events(*, poll_interval=0.1, idle_timeout=None)` (async iterator of the child's `gen.emit_event` stream) · `stream_text(*, poll_interval=0.1, idle_timeout=None)` (just the `text_delta` chunks — chat streaming) · `mirror_files(*, to_cell=True, from_cell=True, exclude=(), interval=0.5)` (`async with`: bidirectional cell↔sub-run file sync) · `endpoints(wait=, timeout=)` · `files()` · `status()` · `surface(spec)` · `stop()` · `async with`.

### Environments — drive a child runtime (Tier B)
| Worker side (the handle) | Returns |
|---|---|
| `await handle.capabilities()` | `EnvironmentSpec \| None` |
| `await handle.put_files(map)` · `write_file` · `read_file` · `delete_file` · `list_files` · `snapshot` · `watch_files()` | workspace plane (guaranteed) |
| `await handle.exec(cmd, *, cwd=, env=, timeout=)` | `(rc, output)` |
| `await handle.exec_background(cmd)` → `ProcessHandle` (`await .wait()` / `.stop()`) | long-running process |
| `await handle.expose_port(port)` · `open_terminal(cmd)` | `Endpoint` · `{session_id, ws_path, token}` |

| Environment author side | |
|---|---|
| `await gen.serve_environment(on_exec=, on_exec_background=, on_expose_port=, on_terminal=, on_wait_process=, on_stop_process=, max_concurrency=1)` | serve loop; blocks until Stop |
| `_env_shared.DockerEnvironment(...).serve()` | the Docker-free authoring path (shared generator code) |

### Types & exceptions
`GeneratorResult` · `GeneratorInfo` · `EnvironmentSpec` · `Endpoint` · `CellRecord` ·
`RendererCheck` · `Request` · `Source` · `SurfaceSpec` · `GeneratorHandle` ·
`ProcessHandle`. Exceptions: `gen.Cancelled`, `gen.IPCError` (+ `IPCNakError` /
`IPCTimeoutError` / `IPCDisconnectedError`).
