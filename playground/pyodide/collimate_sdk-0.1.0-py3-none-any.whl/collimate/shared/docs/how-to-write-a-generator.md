# How to write a Standard generator

Standard generators run as full Python processes spawned by the Collimate backend. They have access to the real filesystem, subprocesses, ports, terminals, Docker, and any pip-installable library.

The runtime API is a single top-level package: **`gen`**. A generator imports it and calls `gen.*` to read inputs, stage output files, push cells, request user input, resolve API keys, run subprocesses, bind ports, attach terminals, and more. There is no `ctx` argument — the host sets up `gen` before `run()` is called.

This doc is the full contract; it is also loaded at runtime as the system prompt for the `generator-builder` scaffolding agent, so style and idioms here are reflected in every generator the LLM produces.

---

## 1. File layout

One generator = one directory:

```
generators/Standard/my_gen/
├── manifest.gen_yaml          # identity + schema (required)
├── my_gen.py                  # the run() function (required)
└── pydantic-config.set_yaml   # optional draft file for user-editable knobs
```

The host spawns `my_gen.py` as a subprocess. The script imports `gen` and calls `gen.main(run)` from its `__main__` block.

---

## 2. Minimal generator

```python
# my_gen.py
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
import gen

async def run():
    name = gen.config("pydantic-config.set_yaml").get("name", "world")
    gen.update_file("greeting.md", f"# Hello {name}\n")
    # No explicit gen.update() needed — main() auto-flushes pending writes
    # when run() returns. Call gen.update(name=…, summary=…) if you want
    # to set a custom cell name or summary.

if __name__ == "__main__":
    gen.main(run)
```

```yaml
# manifest.gen_yaml
id: "hello"
name: "Hello"
category: "tools"
version: "0.1.0"
summary: "Write a greeting file."
entrypoint: "my_gen.py"
prompt_intent: "Who to greet"

inputs:
  cells:
    min: 0
    max: 0
```

That's the whole contract. The PEP 723 `# /// script` block lets `uv run` resolve dependencies on first launch.

---

## 3. The `run()` contract

```python
async def run() -> None: ...   # canonical
def run() -> None: ...         # also accepted for trivial cases
```

The function takes **no arguments**. The host sets up `gen` (workspace path, IPC, signal handling, prompt, params) before `gen.main(run)` invokes it.

When `run()` returns cleanly, `main()` auto-flushes any pending writes (files staged via `update_file`, history appended via `gen.history.append`, deletions via `delete_file`) as the final cell state. Generators that want explicit control — a custom name/summary, mid-run progressive updates — call `await gen.update(name=…, summary=…)` themselves; the auto-flush is a no-op when the stage is already clean.

`async def` is preferred for anything that touches IPC, LLMs, or subprocess streaming. Sync `def run()` is fine for trivial cases (`merge`, deterministic transforms).

### Cancellation

```python
if gen.cancelled:
    return  # or: break out of a loop
```

`gen.cancelled` flips to True when the user clicks Stop (SIGTERM is delivered). Long-running and daemon generators must poll it cooperatively. Subprocess and chat helpers (`gen.run_subprocess`, `gen.chat_loop`, `gen.chat_turn`, `gen.wait_for_action`) handle this internally.

If a primitive raises `gen.Cancelled` (user cancelled a key/secret/settings modal), let it propagate — `gen.main` catches it and finalises the run as gracefully stopped.

---

## 4. Manifest fields

```yaml
id: "my-gen"                 # unique, lowercase, hyphenated
name: "My Generator"          # display name in picker
category: "tools"             # chat | iterate | widen | narrow | tools
version: "0.1.0"
summary: "One-line description for the picker."
entrypoint: "my_gen.py"

prompt_intent: "What the user types into the picker textarea"

# Whether this is a chat-shaped (long-lived, conversational) run.
# Default: false. Set to true for generators that loop over user
# messages via `gen.chat_loop()`. The runtime infers Stop semantics,
# picker routing, log-drawer behaviour, and history persistence from
# this one bit. `chat: true` implies `daemon: true`.
chat: false

# Whether this is a long-running non-chat daemon. Default: false. Set
# to true for generators that stay alive serving a port or terminal
# (vscode_env, playwright_rrweb, claude_cli).
daemon: false

# Optional: files seeded into the workspace before the run. The picker
# renders a form from any .set_yaml schema; the user fills it, the run
# starts.
draft_files:
  - "pydantic-config.set_yaml"

# Which draft file the Draft cell editor opens first (only relevant
# when default_route: "draft"). Optional.
summary_file: "pydantic-config.set_yaml"

# "run" (default with draft_files): picker submits straight to the
#   run; user never sees a Draft cell.
# "draft": picker creates a persisted Draft cell on the canvas; the
#   user opens it, may edit multiple files, then clicks Run there.
default_route: "run"

# Bounds on the number of input cells the user attaches.
inputs:
  cells:
    min: 0       # 0 = optional inputs
    max: 1       # set higher for fan-in generators (e.g. merge)
```

That's the entire schema. Anything else lints as an unknown field.

---

## 5. Settings schema (`.set_yaml`)

Generators that need user-editable knobs ship a draft file with a schema-form layout:

```yaml
# pydantic-config.set_yaml
fields:
  - key: provider
    type: dropdown
    label: Provider
    description: Which LLM provider to call.
    default: anthropic
    options:
      - { value: anthropic, label: Anthropic }
      - { value: openai,    label: OpenAI    }
      - { value: groq,      label: Groq      }

  - key: model
    type: text
    label: Model
    description: Provider-specific model name (e.g. `claude-sonnet-4-6`, `gpt-4o`).
    default: "claude-sonnet-4-6"

  - key: max_tokens
    type: number
    label: Max output tokens
    default: 4096
    min: 256
    max: 16384

  - key: system_prompt
    type: textarea
    label: System prompt
    default: "You are a concise assistant."
```

Generators read this with one line:

```python
cfg = gen.config("pydantic-config.set_yaml")
provider = cfg.get("provider", "anthropic")
system_prompt = cfg.get("system_prompt", "")
```

`gen.config(name)` always returns a dict. `.set_yaml` / `.yaml` / `.yml` parse as YAML and merge `fields:` defaults with the `values:` block. `.json` parses as JSON. Missing or malformed files yield `{}` so callers can use `cfg.get(...)` without try/except. For raw text files, use `gen.read_file(name)` instead.

### Field types

| Type | Purpose | Type-specific options |
|---|---|---|
| `text` | single-line input | `placeholder`, `multiline` |
| `textarea` | multi-line input | (same as text) |
| `number` | numeric input | `min`, `max`, `step`, `widget: slider` |
| `dropdown` | enum selection | `options: [{value, label, description}]` |
| `bool` | true/false | — |
| `file` | file picker | `extensions: [".md", ".txt"]` |
| `list` | repeated subform | `item: { fields: [...] }` |
| `object` | grouped subform | `fields: [...]` |

Every field accepts: `key`, `label`, `description`, `default`, `advanced` (collapse under "Advanced" expander), `show_when` (conditional visibility — `{earlierFieldKey: expectedValue}`).

---

## 6. The `gen.*` surface

### Inputs

```python
gen.prompt              # str — the picker textarea text
gen.messages            # list[Message] — prior chat history from input cells
gen.cancelled           # bool — Stop button check (poll between chunks)
```

### Reading input cell files

```python
gen.read_input(path)    # str — read one input file
gen.input_files()       # dict[str, str] — every input file as {relpath: content}
gen.input_groups()      # dict[str, dict[str, str]] — files split by source cell
                        #   single input  → {"input": {...}}
                        #   multi-input   → {"00_label": {...}, "01_other": {...}}
                        #   paths in each group are relative to the cell root
```

### Reading config files

```python
gen.config(name)        # dict — YAML / JSON, by extension; {} on missing/malformed
```

### Output stage (file I/O on the cell being written)

```python
gen.update_file(path, content)  # stage a write (also syncs to disk for subprocesses)
gen.read_file(path)             # read from stage
gen.has_file(path)              # collision predicate
gen.list_files()                # sorted staged paths
gen.delete_file(path)           # drop from stage and disk
```

### Cell operations — two only

```python
await gen.update(*, name=None, summary=None, summary_artifact=None)
await gen.create_stack_cell(name, *, summary=None, summary_artifact=None, files=None)
```

`gen.update()` flushes the current stage (tracked file writes + dirty chat history) to the placeholder/top cell. **May be called many times during a run** — each call refreshes the visible cell live; the host debounces persistence.

When `run()` returns cleanly, `main()` calls `update_cell` automatically if there are pending writes — most one-shot generators don't need an explicit `gen.update()` at the end. Use it when you want a custom name/summary, or when you want to flush mid-run so the user sees progressive output.

`gen.create_stack_cell(name, ...)` adds a new cell **below in the right-side stack**. Used by fan-out generators (e.g. `seed_ideas`) to create N siblings while the placeholder holds an index. If `files` is omitted, it snapshots the current stage.

There is no `update_cell(cell_id, ...)` escape hatch. Generators that want to "modify an input cell" carry input files forward to their placeholder and modify them there.

### Chat history

```python
gen.history.append(role, content)   # role: "user" | "assistant"
gen.history.as_pai()                # translate to pydantic_ai ModelMessage
list(gen.history)                   # iterate (read-only)
```

`history.append()` writes to `.colreserved/.collimate_messages.json` immediately; the next `gen.update()` (or the auto-flush on return) includes it as an artifact.

### User input mid-run

```python
async for user_msg in gen.chat_loop():
    # Body runs once per turn. Yields gen.prompt first (if non-empty),
    # then blocks on the user's chat input. Loop exits cleanly on Stop.
    ...

await gen.next_message()    # str | None — one-off polling outside chat_loop
```

### Secrets

```python
await gen.api_key(provider, *, force=False, description="")
# Resolves the API key for "anthropic"/"openai"/"groq"/"cerebras"/
# "openrouter"/"gemini"/"mistral" and sets the standard env
# var (ANTHROPIC_API_KEY etc.) so pydantic_ai's native provider lookup
# picks it up. Pops the in-cell modal when the env isn't set.
# force=True skips the env-var fast path — for auth-retry after a 401.
# Raises gen.Cancelled when the user cancels the modal.

await gen.secret(name, *, prompt_if_missing=False, description="")
# Escape hatch for non-LLM secrets (webhook tokens, custom service
# keys, …). Default: env-var fast path only — empty string when not
# set. prompt_if_missing=True opts into the modal flow.
```

### Status / logging

```python
gen.log(line)           # append to the run log (visible in the events panel)
gen.status(msg)         # set the live status string next to the run row
gen.progress(c, t)      # live progress bar in the cell card
```

### LLM convenience tier

```python
agent = await gen.agent(
    *,
    system_prompt="",
    tools=None,
    output_type=None,
    provider=None, model=None, max_tokens=None,  # override pydantic-config.set_yaml
    config_file="pydantic-config.set_yaml",
)
# Reads provider/model/max_tokens from the config file when not
# overridden, calls gen.api_key() to resolve the key, returns an
# agent wrapper whose .run() retries once on a 401/403 (popping the
# modal with "previous key was rejected"). The unwrapped pydantic_ai
# Agent is exposed as agent.raw for power users.

reply = await gen.chat_turn(agent, user_msg, *, message_history=None, turn_id=None)
# One-line streaming chat turn. Mints turn_id, emits turn_start /
# text_delta chunks / turn_end via gen.chat_stream, polls
# gen.cancelled per chunk, retries once on auth failure. Returns the
# accumulated assistant text. message_history defaults to
# gen.history.as_pai().

tools = gen.file_tools()
# list/read/write/edit pydantic_ai Tool objects bound to the workspace.

python_tool = gen.python_tool(
    *,
    timeout=60,                     # per-call hard cap (seconds)
    default_packages=None,          # implicit packages for every call
)
# Returns a single pydantic_ai Tool the agent calls as
# ``run_python(code: str, packages: list[str] = [])``. Runs the code
# as a subprocess in the cell's workspace; snapshots the workspace
# before/after and auto-stages any new or modified files into
# ``tracked_writes`` so the next ``gen.update()`` (or auto-flush)
# commits them. Returns rc + changed-files + stdout/stderr text.
#
# When ``packages`` is non-empty the SDK invokes
# ``uv run --no-project --with <pkg> ... -- python -c <code>`` so the
# agent can pull in libraries the generator's PEP 723 manifest didn't
# declare. With ``packages=[]`` (the default) it runs in the
# generator's own interpreter — same deps as the manifest.
#
# Wire it alongside ``gen.file_tools()`` for any agent that should be
# able to author files AND compute / generate artifacts:
#
#     agent = await gen.agent(
#         system_prompt=...,
#         tools=gen.file_tools() + [gen.python_tool(default_packages=["matplotlib"])],
#     )
```

### Subprocess / ports / terminals

```python
rc, output = await gen.run_subprocess(
    command,                  # list[str] | str
    *,
    turn_id=None,             # bind output to a chat-stream turn id
    timeout=120, cwd=None, shell=False,
    emit_bash_stdout=True, emit_text_delta=False, print_stdout=True,
)
# Streams the child's stdout line-by-line. Cooperative cancellation:
# gen.cancelled polled per line; on True the process is terminate'd.

await gen.serve_port(port, *, name="preview", path="", snapshot_source=None)
# Bind a port for daemon generators; the host opens a sandbox iframe
# on the cell. Pair with daemon: true in the manifest.

session = await gen.terminal(container_id, command, *, cwd=None, env=None)
# Allocate a WebSocket-backed PTY in a Docker container. Returns
# {session_id, ws_path, token}. Dump it (plus a "label") into a
# <name>.terminal file via gen.update_file for the cell to render.

gen.stop_terminal(session_id)  # idempotent teardown
```

### Workspace + snapshot + settings + actions

```python
gen.workspace_path()    # str — absolute path to the workspace dir

gen.snapshot()          # {relpath: sha256_hex} for every file
                        # Pair before/after a subprocess to detect changes.

values = await gen.request_settings("path/to/file.set_yaml")
# Pop a settings overlay against a .set_yaml file in the workspace;
# block until the user presses Continue and return the updated dict.

action = await gen.wait_for_action(timeout=None)
# Block until a renderer emits an action (e.g. button click), or the
# timeout / Stop. Returns the action id or None.
```

### Container-backed chat sessions

```python
session = await gen.chat_session(
    image="my-chat-worker",
    dockerfile_dir=...,          # build-context for lazy image build
    shared=True,
    backend="claude_code_session",
    model="sonnet",
    system_prompt="...",
)
result = await session.send_turn("user message here")
```

### Live chat-stream events (in-process backends)

```python
gen.chat_stream(turn_id, {"type": "text_delta", "turn_id": turn_id, "text": chunk})
```

Used by chat_turn internally; expose for custom in-process backends.

### Exceptions

```python
gen.Cancelled                   # raised by api_key / secret / request_settings on user-cancel
gen.IPCError                    # base for IPC-protocol failures (NAK, timeout, disconnected)
gen.IPCNakError, gen.IPCTimeoutError, gen.IPCDisconnectedError
```

---

## 7. Worked examples

### Example A — pure Python, no LLM (the `merge` generator)

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Union 2+ input cells into one output cell. Topmost wins on collisions."""
import gen

async def run():
    rows: list[str] = []
    for label, cell_files in gen.input_groups().items():
        rows.append(f"- **{label}**: {len(cell_files)} files")
        for path, content in cell_files.items():
            if not gen.has_file(path):
                gen.update_file(path, content)

    gen.update_file("_merge.md", "# Merge\n\n" + "\n".join(rows) + "\n")
    await gen.update(
        name=f"merged",
        summary=f"merged {len(gen.input_groups())} cells",
        summary_artifact="_merge.md",
    )

if __name__ == "__main__":
    gen.main(run)
```

### Example B — single-shot LLM agent (modify_files-style)

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic-ai"]
# ///
"""Run an agent over the input cell's files. Carries unedited files forward."""
import gen

async def run():
    cfg = gen.config("pydantic-config.set_yaml")
    if not gen.prompt.strip():
        gen.update_file("error.md", "# No prompt\n\nDescribe what to do.\n")
        return  # auto-flush handles the cell write

    agent = await gen.agent(
        system_prompt=cfg.get("system_prompt", "")
            + "\n\nEdit files using the read/write/edit tools. "
              "Leave unrelated files alone. Use run_python for any "
              "computation, analysis, or artifact generation.",
        tools=gen.file_tools() + [gen.python_tool()],
    )

    result = await agent.run(gen.prompt)  # auto-retries on auth failure
    gen.update_file("answer.md", str(result.output))
    await gen.update(summary=str(result.output)[:120])

if __name__ == "__main__":
    gen.main(run)
```

### Example C — daemon chat (live_chat-style)

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic-ai"]
# ///
"""Multi-turn chat with file tools. Stop ends the conversation."""
import gen

async def run():
    cfg = gen.config("pydantic-config.set_yaml")
    agent = await gen.agent(
        system_prompt=cfg.get("system_prompt", ""),
        tools=gen.file_tools() + [gen.python_tool()],
    )

    async for user_msg in gen.chat_loop():
        gen.history.append("user", user_msg)
        await gen.update()  # show the user message immediately
        reply = await gen.chat_turn(agent, user_msg)  # streaming + auth-retry
        gen.history.append("assistant", reply)
        await gen.update()  # show the assistant turn

if __name__ == "__main__":
    gen.main(run)
```

Manifest needs `chat: true`:
```yaml
id: "live-chat"
name: "Live Chat"
category: "chat"
version: "0.1.0"
summary: "Multi-turn pydantic-ai chat with read/write/edit file tools."
entrypoint: "live_chat.py"
chat: true
draft_files:
  - "pydantic-config.set_yaml"
inputs:
  cells:
    min: 0
    max: 1
```

### Example D — subprocess one-shot (git_clone-style)

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Clone a Git repo into the cell. Streams output to the run log."""
import gen

async def run():
    cfg = gen.config("pydantic-config.set_yaml")
    repo = (cfg.get("repo") or "").strip()
    if not repo:
        gen.update_file("error.md", "# No repo\n\nSet `repo` in config.\n")
        return

    token = await gen.secret("GITHUB_TOKEN", prompt_if_missing=True,
                              description="GitHub token for private repos (optional)")
    env = {"GIT_TERMINAL_PROMPT": "0"}
    if token:
        env["GIT_ASKPASS"] = "echo"
        env["GITHUB_TOKEN"] = token

    rc, output = await gen.run_subprocess(
        ["git", "clone", "--depth=1", repo, "."],
        cwd=gen.workspace_path(),
        timeout=300,
    )
    if rc != 0:
        gen.update_file("error.md", f"# Clone failed\n\n```\n{output}\n```\n")
        await gen.update(summary=f"clone failed (rc={rc})")
        return

    gen.update_file("_clone.md", f"# Cloned {repo}\n")
    await gen.update(summary=f"cloned {repo}")

if __name__ == "__main__":
    gen.main(run)
```

### Example E — port-bound daemon (playwright_rrweb-style)

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "aiohttp"]
# ///
"""Bind an HTTP server on a free port; the cell shows it as a live preview."""
import asyncio
import gen
from aiohttp import web

async def run():
    app = web.Application()
    app.router.add_get("/", lambda r: web.Response(text="hello"))

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]

    await gen.serve_port(port, name="hello-server")
    gen.update_file("_server.md", f"# Server on port {port}\n")
    await gen.update(summary=f"serving on :{port}")

    while not gen.cancelled:
        await asyncio.sleep(0.5)

    await runner.cleanup()

if __name__ == "__main__":
    gen.main(run)
```

Manifest:
```yaml
id: "hello-server"
name: "Hello Server"
category: "tools"
version: "0.1.0"
summary: "Bind a tiny HTTP server."
entrypoint: "server.py"
daemon: true
inputs:
  cells:
    min: 0
    max: 0
```

### Example F — container daemon with terminal (claude_cli-style)

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Open a Docker container, expose a terminal in the cell, wait for actions."""
import json
import gen

async def run():
    rc, cid = await gen.run_subprocess(
        ["docker", "run", "-d", "-v",
         f"{gen.workspace_path()}:/work", "ubuntu:22.04", "sleep", "infinity"],
    )
    cid = cid.strip()
    if rc != 0 or not cid:
        gen.update_file("error.md", f"# Container failed\n\n{cid}\n")
        return

    sess = await gen.terminal(cid, ["bash"], cwd="/work")
    gen.update_file("shell.terminal", json.dumps({**sess, "label": "Shell"}))
    await gen.update(name="Container", summary="terminal ready")

    try:
        while not gen.cancelled:
            action = await gen.wait_for_action(timeout=1.0)
            if action == "restart":
                gen.stop_terminal(sess["session_id"])
                sess = await gen.terminal(cid, ["bash"], cwd="/work")
                gen.update_file("shell.terminal",
                                json.dumps({**sess, "label": "Shell"}))
                await gen.update(summary="terminal restarted")
    finally:
        gen.stop_terminal(sess["session_id"])
        await gen.run_subprocess(["docker", "rm", "-f", cid], timeout=10)

if __name__ == "__main__":
    gen.main(run)
```

Manifest:
```yaml
id: "container-shell"
name: "Container Shell"
category: "tools"
version: "0.1.0"
summary: "A bash shell inside a fresh Ubuntu container."
entrypoint: "container_shell.py"
daemon: true
chat: false
inputs:
  cells:
    min: 0
    max: 1
```

---

## 8. Checklist before shipping

- [ ] `manifest.gen_yaml` has `id`, `name`, `category`, `version`, `summary`, `entrypoint`.
- [ ] `chat: true` if the generator loops over user messages; `daemon: true` if it stays alive serving a port/terminal.
- [ ] `inputs.cells.min/max` set to the right range for fan-in / fan-out / no-input shapes.
- [ ] PEP 723 `# /// script` block at the top of the .py file lists every dep (`pyyaml` plus anything specific). **Do not list `collimate-sdk`** — the host injects the SDK source onto `PYTHONPATH` so `import gen` works without `uv` having to resolve a published package.
- [ ] `if __name__ == "__main__": gen.main(run)` is the entrypoint.
- [ ] Long-running loops poll `gen.cancelled` (or use `gen.chat_loop`, `gen.chat_turn`, `gen.run_subprocess`, `gen.wait_for_action`, which handle it internally).
- [ ] Subprocess errors land in the cell as a clear error file, not as an unhandled exception.
- [ ] Daemon generators clean up resources (terminals, ports, containers) in a `try/finally`.
