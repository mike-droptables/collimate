# How to write a generator

Generators run as full Python processes spawned by the Collimate backend. They have access to the real filesystem, subprocesses, ports, terminals, Docker, and any pip-installable library.

The runtime API is a single top-level package: **`gen`**. A generator imports it and calls `gen.*` to read inputs, stage output files, push cells, request user input, resolve API keys, run subprocesses, bind ports, attach terminals, and more. There is no `ctx` argument — the host sets up `gen` before `run()` is called.

This doc is the full contract; it is also loaded at runtime as the system prompt for the `generator-builder` scaffolding agent, so style and idioms here are reflected in every generator the LLM produces.

---

## 1. File layout

One generator = one directory:

```
generators/my_gen/
├── manifest.gen_yaml          # identity + schema (required)
├── my_gen.py                  # the run() function (required)
└── pydantic-config.set_yaml   # optional draft file for user-editable knobs
```

The host spawns `my_gen.py` as a subprocess. The script imports `gen` and calls `gen.main(run)` from its `__main__` block.

---

## 2. Minimal generator

```python
# my_gen.py
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
import gen

async def run():
    name = gen.config("pydantic-config.set_yaml").get("name", "world")
    gen.update_file("greeting.md", f"# Hello {name}\n")
    # No explicit gen.update() needed — main() auto-flushes pending writes
    # when run() returns. Call gen.update(name=…, summary=…) if you want
    # to set a custom cell name or summary.

if __name__ == "__main__":
    gen.main(run)
```

```yaml
# manifest.gen_yaml
id: "hello"
name: "Hello"
type: ["create"]
version: "0.1.0"
summary: "Write a greeting file."
entrypoint: "my_gen.py"
prompt_intent: "Who to greet"
inputs:
  cells: { min: 0, max: 0 }   # no input → a fresh cell from scratch
config_tags:
  default: {}   # required whenever the generator takes config (see §4)
```

That's the whole contract. The PEP 723 `# /// script` block lets `uv run` resolve dependencies on first launch.

---

## 3. The `run()` contract

```python
async def run() -> None: ...   # canonical
def run() -> None: ...         # also accepted for trivial cases
```

The function takes **no arguments**. The host sets up `gen` (workspace path, IPC, signal handling, prompt, params) before `gen.main(run)` invokes it.

When `run()` returns cleanly, `main()` auto-flushes any pending writes (files staged via `update_file`, history appended via `gen.history.append`, deletions via `delete_file`) as the final cell state. Generators that want explicit control — a custom name/summary, mid-run progressive updates — call `await gen.update(name=…, summary=…)` themselves; the auto-flush is a no-op when the stage is already clean.

`async def` is preferred for anything that touches IPC, LLMs, or subprocess streaming. Sync `def run()` is fine for trivial cases (`merge`, deterministic transforms).

### Cancellation

```python
if gen.cancelled:
    return  # or: break out of a loop
```

`gen.cancelled` flips to True when the user clicks Stop (SIGTERM is delivered). Long-running and daemon generators must poll it cooperatively. Subprocess and chat helpers (`gen.run_subprocess`, `gen.serve_chat`, `gen.agent_chat_turn`, `gen.wait_for_action`) handle this internally.

If a primitive raises `gen.Cancelled` (user cancelled a key/secret/settings modal), let it propagate — `gen.main` catches it and finalises the run as gracefully stopped.

---

## 4. Manifest fields

```yaml
id: "my-gen"                 # unique, lowercase, hyphenated
name: "My Generator"          # display name in picker
version: "0.1.0"
summary: "One-line description for the picker."   # required; 1–2 sentences
entrypoint: "my_gen.py"

prompt_intent: "What the user types into the picker textarea"

# Optional, default false. When true, the run is blocked until the
# prompt is non-empty (after trimming) — enforced by both pickers and
# by the server. Only legal alongside `prompt_intent` (lint error
# otherwise).
prompt_required: true

# Named sets of default input values (prompt + .set_yaml fields),
# shown as selectable chips in both pickers. **Required whenever the
# generator "takes config"** — i.e. it has a `prompt_intent` or at
# least one `.set_yaml` in `draft_files` — and must then contain a
# `default` tag. `default: {}` means "pure field defaults".
#
# Tag names must match ^[A-Za-z0-9][A-Za-z0-9 ._-]{0,31}$ (1–32 chars).
# Each tag body allows exactly two keys, both optional:
#   prompt — string seeded into the picker's prompt box when the tag
#            is selected.
#   files  — mapping of .set_yaml draft-file path → **sparse overlay**:
#            only the field keys it names are overridden; every other
#            field keeps its resolved default. Keys must be .set_yaml
#            members of `draft_files`, and each field key must exist in
#            that file's `fields:` list.
# Mapping order = display order; users can add/edit/delete tags from
# the UI (those edits persist to the channel's copy, not this file).
config_tags:
  default: {}
  "fast model":
    prompt: "Summarise the inputs"
    files:
      pydantic-config.set_yaml:
        model: claude-haiku-4-5
        max_tokens: 1024

# How the generator is invoked. **Required.** A list of 1–2 modes, each
# drawn from {"modify", "create"}. Drives which picker(s) the generator
# appears in and what inputs it receives; the input shape for `create`
# is read off `inputs.cells` (see below):
#   modify    — rewrites the single current cell in place. Takes exactly
#               1 input cell (the current cell). Surfaces in the per-cell
#               button. No new cell at run start; 'update' emissions
#               append versions. Implicit bounds: 1/1.
#   create    — produces fresh cell(s). The input shape comes from
#               `inputs.cells`: no input (min/max 0; surfaces in the
#               top-bar / empty-channel CTA), a single cell (min/max 1),
#               or a stack of cells (e.g. min 1/2, max 99 — min may be 0
#               for an optional stack). A fresh running cell is created.
#
# Declare every mode the generator supports. A generator with
# ``type: ["modify", "create"]`` (handles both a single current cell and
# producing fresh cells) appears in both pickers. The host injects the
# mode the user actually picked as ``gen.invocation_type`` so the run
# can branch.
type: ["create"]

# Whether this is a chat-shaped (long-lived, conversational) run.
# Default: false. Set to true for generators that serve a streaming
# chat via `gen.serve_chat(on_turn)`. The runtime infers Stop semantics,
# picker routing, log-drawer behaviour, and history persistence from
# this one bit. `chat: true` implies `daemon: true`.
chat: false

# Whether this is a long-running non-chat daemon. Default: false. Set
# to true for generators that stay alive serving a port or terminal
# (vscode_env, browser_live, claude_cli).
daemon: false

# Optional, default false. Marks a throwaway live session (e.g. a
# browser) whose output cell never enters the DAG history. The cell
# offers "close" (stop + remove) instead of "stop", and nothing it
# produces is recorded as a permanent cell.
ephemeral: false

# Optional (native only): let the user edit the cell's files while a
# run is in flight; the host flushes their drafts to the workspace
# before each chat turn. Only recognised value: "live_files". Pair it
# with a start-of-turn workspace resync (see generators/live_chat
# for the pattern) or the end-of-turn update will overwrite the user's
# edits. Omit unless you implement the resync.
# live_files_mode: "live_files"

# Optional: files seeded into the workspace before the run. The picker
# renders a form from any .set_yaml schema; the user fills it, the run
# starts.
draft_files:
  - "pydantic-config.set_yaml"

# Bounds on the number of input cells. For `create`, this is what picks
# the input shape (no input vs. single cell vs. stack). When omitted,
# each declared mode contributes its implicit bounds and the runtime
# takes the union (modify → 1/1, create → defaults to a stack 1/99).
# When declared, every declared mode's per-mode rule must hold:
#   "modify" in type   — bounds must include 1 (min ≤ 1 ≤ max), i.e. the
#                        single current cell
#   "create" in type   — min ≥ 0; the bounds choose the shape:
#                        no input (min/max 0), a single cell (min/max 1),
#                        or a stack (e.g. min 1/2, max 99; min may be 0
#                        for an optional stack)
inputs:
  cells:
    min: 1
    max: 99

# Optional: caps on subprocess resource usage (native only). Recognised
# keys are memory_bytes (RLIMIT_AS), cpu_seconds (RLIMIT_CPU),
# open_files (RLIMIT_NOFILE). Values must be positive integers; unknown
# keys are a lint error.
rlimits:
  memory_bytes: 8589934592  # 8 GB

# Optional: env vars that survive the per-subprocess scrub. Use only
# for non-secret host state (e.g. SSH_AUTH_SOCK for ssh-agent
# forwarding). Names that look like secrets (matching KEY/TOKEN/SECRET)
# warn at lint — route those through gen.secret/gen.api_key instead.
env_passthrough:
  - "SSH_AUTH_SOCK"
```

That's the entire schema. Anything else lints as an unknown field.

---

## 5. Settings schema (`.set_yaml`)

Generators that need user-editable knobs ship a draft file with a schema-form layout:

```yaml
# pydantic-config.set_yaml
fields:
  - key: provider
    type: dropdown
    label: Provider
    description: Which LLM provider to call.
    default: anthropic
    options:
      - { value: anthropic, label: Anthropic }
      - { value: openai,    label: OpenAI    }
      - { value: groq,      label: Groq      }

  - key: model
    type: text
    label: Model
    description: Provider-specific model name (e.g. `claude-sonnet-4-6`, `gpt-4o`).
    default: "claude-sonnet-4-6"
    required: true

  - key: max_tokens
    type: number
    label: Max output tokens
    default: 4096
    min: 256
    max: 16384
    required: true

  - key: system_prompt
    type: textarea
    label: System prompt
    default: "You are a concise assistant."
```

Generators read this with one line:

```python
cfg = gen.config("pydantic-config.set_yaml")
provider = cfg.get("provider", "anthropic")
system_prompt = cfg.get("system_prompt", "")
```

`gen.config(name)` always returns a dict. `.set_yaml` / `.yaml` / `.yml` parse as YAML and merge `fields:` defaults with the `values:` block. `.json` parses as JSON. Missing or malformed files yield `{}` so callers can use `cfg.get(...)` without try/except. For raw text files, use `gen.read_file(name)` instead.

### Field types

| Type | Purpose | Type-specific options |
|---|---|---|
| `text` | single-line input | `placeholder`, `multiline` |
| `textarea` | multi-line input | (same as text) |
| `number` | numeric input | `min`, `max`, `step`, `widget: slider` |
| `dropdown` | enum selection | `options: [{value, label, description}]` |
| `checkbox` | true/false | — |
| `list` | repeated subform | `item: { fields: [...] }` |
| `object` | grouped subform | `fields: [...]` |

Every field accepts: `key`, `label`, `description`, `default`, `required`, `advanced` (collapse under "Advanced" expander), `show_when` (conditional visibility — `{earlierFieldKey: expectedValue}`).

### Required fields and the run gate

`required: true` on a field is a **run gate**, not just a styling flag: both
pickers and the server refuse to start a run while a required field's
effective value is empty. "Empty" is defined per field type:

| Field type | Empty when |
|---|---|
| `text` / `textarea` | `null`, or `""` after trimming |
| `number` | `null` |
| `dropdown` | `null` or `""` |
| `checkbox` | never — a checkbox always holds true/false (`required:` on one is a lint warning) |
| `list` | `null` or `[]` |
| `object` | `null` |
| the prompt | `""` after trimming (gated by the manifest's `prompt_required`) |

`0` and `false` are NOT empty. The machine-readable version of this table
is `shared/empty-values-contract.json`, which every implementation is
tested against.

### Value resolution

The effective value of each field, for a given config tag, is layered
left-to-right (later wins):

```
per-type empty default  ⊕  field `default:`  ⊕  the file's `values:` block  ⊕  the tag's `files[<path>]` overlay
```

The tag overlay is sparse — it only touches the keys it names. The
effective prompt seeded by a tag is `tag.prompt`, or none when the tag
doesn't set one.

---

## 6. The `gen.*` surface

### Inputs

```python
gen.prompt              # str — the picker textarea text
gen.messages            # list[Message] — prior chat history from input cells
gen.cancelled           # bool — Stop button check (poll between chunks)
gen.invocation_type     # str — "modify" | "create", the mode the user
                        # picked. Useful when the manifest's `type` array
                        # lists more than one mode and the run needs to branch.
```

### Reading input cell files

```python
gen.read_input(path)    # str | bytes — read one input file. Returns str when
                        # the bytes decode as utf-8, otherwise bytes. Branch on
                        # isinstance(..., bytes) when the source may be binary.
gen.input_files()       # dict[str, str | bytes] — every input file
gen.input_groups()      # dict[str, dict[str, str | bytes]] — files split by source cell
                        #   single input  → {"input": {...}}
                        #   multi-input   → {"00_label": {...}, "01_other": {...}}
                        #   paths in each group are relative to the cell root
```

### Reading config files

```python
gen.config(name)        # dict — YAML / JSON, by extension; {} on missing/malformed
```

### Output stage (file I/O on the cell being written)

```python
gen.update_file(path, content)  # content: str | bytes. Stages a write (also
                                # syncs to disk so subprocesses see it).
gen.read_file(path)             # str | bytes — read from stage; raises
                                # FileNotFoundError if absent (guard with
                                # has_file). utf-8 → str, else bytes.
gen.has_file(path)              # collision predicate
gen.list_files()                # sorted staged paths
gen.delete_file(path)           # drop from stage and disk
```

### Cell operations — two only

```python
await gen.update(*, name=None, summary=None, pinned=None)
await gen.create_stack_cell(name, *, summary=None, pinned=None, files=None)
```

`gen.update()` flushes the current stage (tracked file writes + dirty chat history) as a new **version** of the running cell. The version chain is what the user sees in the cell's history side panel — each `gen.update()` adds a row; the visible cell on the canvas always shows the latest. **May be called many times during a run** — each call refreshes the visible cell live; the host debounces persistence. Maps to the manifest's `output: 'update'` kind.

When `run()` returns cleanly, `main()` calls update automatically if there are pending writes — most one-shot generators don't need an explicit `gen.update()` at the end. Use it when you want a custom name/summary, or when you want to flush mid-run so the user sees progressive output.

`gen.create_stack_cell(name, ...)` mints a new cell on the canvas. Used by fan-out generators (e.g. `seed_ideas`) to create N siblings while the running cell holds an index. If `files` is omitted, it snapshots the current stage.

**Where created cells land** is decided by the running cell's placement toggle (user-controlled via the placement chip in the log header; defaults to the channel's saved choice):

| Placement | Where the new cell lands |
|-----------|--------------------------|
| `under`     | appended below the running cell, same stack |
| `new_stack` | first cell of a fresh stack inserted to the right |
| `on_top`    | top of the stack immediately to the right (created if absent) |

The generator doesn't pick placement — it's the user's call. Just emit cells; the host places them.

There is no `update_cell(cell_id, ...)` escape hatch. Generators that want to "modify an input cell" should declare `type: ["modify"]` (which makes the input cell *be* the running cell), or for `type: ["create"]` carry the input files forward into the new running cell and update those.

### Chat history

```python
gen.history.append(role, content)   # role: "user" | "assistant"
gen.history.seed_from_chatlog()     # bool — load a prior .chatlog transcript
gen.history.as_pai()                # translate to pydantic_ai ModelMessage
list(gen.history)                   # iterate (read-only)
```

`history.append()` rewrites a visible `conversation.chatlog` text transcript through the normal output stage immediately; the next `gen.update()` (or the auto-flush on return) commits it as an ordinary versioned file. The `.chatlog` is the durable, human-editable record of the conversation.

### Live chat

```python
async def on_turn(turn):
    # Runs once per inbound user message. `turn.user_msg` is the text;
    # stream the reply via `turn.delta(text)` / `turn.tool(...)` or let
    # `gen.agent_chat_turn(turn, agent)` do it. `turn.cancelled` flips on
    # interrupt/redirect; `turn.redirect` carries replacement text.
    gen.history.append("user", turn.user_msg)
    reply = await gen.agent_chat_turn(turn, agent)
    gen.history.append("assistant", reply)
    await gen.update(summary=turn.user_msg[:80])

await gen.serve_chat(on_turn, *, label="Live Chat",
                     log_file="conversation.chatlog",
                     live_file="conversation.chatlive", resume=True)
# Serves a live, streaming chat until Stop. Registers the session, pins
# the `.chatlive` pointer (so the chat renderer connects its WebSocket),
# optionally resumes from an existing `.chatlog`, then dispatches each
# inbound message to `on_turn(turn)`. Flushes the durable `.chatlog` on
# exit.
```

### Secrets

```python
await gen.api_key(provider, *, force=False, description="")
# Resolves the API key for "anthropic"/"openai"/"groq"/"cerebras"/
# "openrouter"/"gemini"/"mistral" and sets the standard env
# var (ANTHROPIC_API_KEY etc.) so pydantic_ai's native provider lookup
# picks it up. Pops the in-cell modal when the env isn't set.
# force=True skips the env-var fast path — for auth-retry after a 401.
# Raises gen.Cancelled when the user cancels the modal.

await gen.secret(name, *, prompt_if_missing=False, description="")
# Escape hatch for non-LLM secrets (webhook tokens, custom service
# keys, …). Default: env-var fast path only — empty string when not
# set. prompt_if_missing=True opts into the modal flow.
```

### Status / logging

```python
gen.log(line)           # append to the run log (visible in the events panel)
gen.status(msg)         # set the live status string next to the run row
gen.progress(c, t)      # live progress bar in the cell card
```

### LLM convenience tier

```python
agent = await gen.agent(
    *,
    system_prompt="",
    tools=None,
    output_type=None,
    provider=None, model=None, max_tokens=None,  # override pydantic-config.set_yaml
    config_file="pydantic-config.set_yaml",
)
# Reads provider/model/max_tokens from the config file when not
# overridden, calls gen.api_key() to resolve the key, returns an
# agent wrapper whose .run() retries once on a 401/403 (popping the
# modal with "previous key was rejected"). The unwrapped pydantic_ai
# Agent is exposed as agent.raw for power users.

reply = await gen.agent_chat_turn(turn, agent, *, message_history=None,
                                  on_cancel_text="…", cancel_poll_interval_s=0.2)
# One-line streaming chat turn against a serve_chat `turn`. Streams
# text deltas to the renderer via turn.delta, polls turn.cancelled
# concurrently with the stream (so an interrupt lands even mid-HTTP),
# retries once on auth failure. Returns the accumulated assistant text.
# message_history defaults to turn.history.as_pai() (minus a trailing
# duplicate of turn.user_msg).

tools = gen.file_tools()
# list/read/write/edit pydantic_ai Tool objects bound to the workspace.

python_tool = gen.python_tool(
    *,
    timeout=60,                     # per-call hard cap (seconds)
    default_packages=None,          # implicit packages for every call
)
# Returns a single pydantic_ai Tool the agent calls as
# ``run_python(code: str, packages: list[str] = [])``. Runs the code
# as a subprocess in the cell's workspace; snapshots the workspace
# before/after and auto-stages any new or modified files into
# ``tracked_writes`` so the next ``gen.update()`` (or auto-flush)
# commits them. Returns rc + changed-files + stdout/stderr text.
#
# When ``packages`` is non-empty the SDK invokes
# ``uv run --no-project --with <pkg> ... -- python -c <code>`` so the
# agent can pull in libraries the generator's PEP 723 manifest didn't
# declare. With ``packages=[]`` (the default) it runs in the
# generator's own interpreter — same deps as the manifest.
#
# Wire it alongside ``gen.file_tools()`` for any agent that should be
# able to author files AND compute / generate artifacts:
#
#     agent = await gen.agent(
#         system_prompt=...,
#         tools=gen.file_tools() + [gen.python_tool(default_packages=["matplotlib"])],
#     )
```

### Subprocess / ports / terminals

```python
rc, output = await gen.run_subprocess(
    command,                  # list[str] | str
    *,
    turn_id=None,             # bind output to a chat-stream turn id
    timeout=120, cwd=None, shell=False,
    emit_bash_stdout=True, emit_text_delta=False, print_stdout=True,
)
# Streams the child's stdout line-by-line. Cooperative cancellation:
# gen.cancelled polled per line; on True the process is terminate'd.

await gen.serve_port(port, *, name="preview", path="", snapshot_source=None)
# Bind a port for daemon generators; the host opens a sandbox iframe
# on the cell. Pair with daemon: true in the manifest.

session = await gen.terminal(container_id, command, *, cwd=None, env=None)
# Allocate a WebSocket-backed PTY in a Docker container. Returns
# {session_id, ws_path, token}. Dump it (plus a "label") into a
# <name>.terminal file via gen.update_file for the cell to render.

gen.stop_terminal(session_id)  # idempotent teardown
```

### Workspace + snapshot + settings + actions

```python
gen.workspace_path()    # str — absolute path to the workspace dir

gen.snapshot()          # {relpath: sha256_hex} for every file
                        # Pair before/after a subprocess to detect changes.

values = await gen.request_settings("path/to/file.set_yaml")
# Pop a settings overlay against a .set_yaml file in the workspace;
# block until the user presses Continue and return the updated dict.

action = await gen.wait_for_action(timeout=None)
# Block until a renderer emits an action (e.g. button click), or the
# timeout / Stop. Returns the action id or None.
```

### Live stream events (custom chat backends)

```python
gen.emit_stream_event(turn_id, {"type": "text_delta", "text": chunk})
```

Fire-and-forget push of a typed stream event to the cell's live chat renderer. Used by `gen.agent_chat_turn` / `turn.delta` internally; reach for it directly only when driving a non-pydantic-ai chat backend by hand inside a `serve_chat` handler.

### Exceptions

```python
gen.Cancelled                   # raised by api_key / secret / request_settings on user-cancel
gen.IPCError                    # base for IPC-protocol failures (NAK, timeout, disconnected)
gen.IPCNakError, gen.IPCTimeoutError, gen.IPCDisconnectedError
```

### Composition — discover, call, and spawn other generators

A generator can run **other** generators as black-box sub-runs. This is a
public capability — the builders use the same surface, no private powers.
Children are **parent-bound**: the host stops them automatically when this
run ends (or the handle's `async with` exits). Nothing is shown to the user
unless you explicitly surface it.

```python
gen.generators(*, group=None) -> list[GeneratorInfo]   # discover (host-backed; [] in dev)
gen.inline(files, *, entrypoint) -> Source                # wrap an uninstalled candidate
gen.spawn(source, *, inputs=None, input_groups=None, prompt="",
          invocation_type="create", config=None, secrets=None,
          surface=None) -> GeneratorHandle                # start a child; live handle
await gen.call(source, *, …, timeout=300.0) -> GeneratorResult   # spawn + wait + stop
gen.check_renderer(files, *, entrypoint) -> RendererCheck        # host esbuild compile-check (any generator)
```

`source` is an installed generator **id** (from `gen.generators()`) or an
inline `gen.inline(files, entrypoint=...)` candidate. `gen.call` is sugar
for the **terminating** case; a **daemon** child (`info.daemon` true) never
completes, so `spawn` it and use the handle:

- `await handle.wait(timeout=None) -> GeneratorResult`
- `await handle.endpoints(wait=True, timeout=30) -> list[Endpoint]` — daemon ports/terminals
- `await handle.files()` / `await handle.status()`
- `await handle.stop()` — idempotent; also runs on `async with` exit
- `await handle.surface(gen.SurfaceSpec(name=…)) -> cell_id` — promote to a visible cell

`GeneratorResult` is the same type the testing harness returns (`.ok`,
`.files`, `.name`, `.summary`, `.cells`, `.endpoints`, `.error`). `call`
returns `ok=False` on child failure — call `.raise_for_status()` to raise.

**Invisible by default** — `spawn`/`call` create no cell; the child runs in
its own isolated workspace. Surface a sub-run only when the user should see
it (e.g. a daemon's preview iframe). In dev mode (no host) these degrade to
a clean `ok=False` / empty list — they never hang or raise.

### Environments — daemon generators you run work *inside*

An **environment** is a daemon that owns a runtime (a container) and lets a
parent generator run work inside it — the typed twins of the surfaces a human
drives on the cell. The mental model: *a daemon serves its parent the same way
it serves a human.* The human gets a terminal / a served port; the parent gets
the handle verbs below. Environments **compose** — one environment can be a thin
layer over another. The SDK is **Docker-free** — the only Docker-aware code is
the `_env_shared.DockerEnvironment` helper (shared generator code, copied as a
`_*` sibling like `_cdp_shared`); the host never learns a container id.

Declare it in the manifest (implies `daemon: true`):

```yaml
environment: true                    # core: workspace r/w + exec + exec_background + expose_port
# — or declare extras —
environment:
  terminals: 2                       # up to N worker-opened PTYs (default 0)
  watch: true                        # push file-change events (default pull-only)
  concurrent_exec: false             # exec may run in parallel (default serialized)
```

**Authoring an environment** — wire a container to `gen.serve_environment` via
the helper (a base environment is a few lines):

```python
import os, sys
import gen
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from _env_shared import DockerEnvironment        # shared generator code (a _* sibling)

async def run():
    env = DockerEnvironment(image="collimate-linux-small:v1", mount="/work")
    env.surface_terminal(label="Shell")          # human surface (a .terminal)
    await gen.update(name="Linux Env", summary="environment ready")
    await env.serve()                            # blocks until Stop; removes the container
```

`await gen.serve_environment(on_exec=…, on_exec_background=…, on_expose_port=…,
on_terminal=…, on_wait_process=…, on_stop_process=…)` is the raw primitive the
helper fills: each handler takes a typed `Request` (`.command`, `.cwd`, `.env`,
`.port`, `.process_id`) and **returns** its result. Only the environment author
writes this; workers never see it.

**Driving an environment** (the worker) — spawn it once and use the handle. The
worker never imports `docker` or sees a container id:

| Handle verb | Plane | Guarantee |
|---|---|---|
| `await env.capabilities()` → `EnvironmentSpec` | — | the contract; `None` if not an environment |
| `await env.put_files(map)` / `write_file` / `read_file` / `delete_file` / `list_files` / `snapshot` | workspace | guaranteed (host-serviced) |
| `await env.watch_files()` | workspace | push (declared) else poll `snapshot` |
| `await env.exec(cmd, *, cwd, env, timeout)` → `(rc, output)` | execution | guaranteed |
| `await env.exec_background(cmd)` → `ProcessHandle` (`.wait()` / `.stop()`) | execution | guaranteed |
| `await env.expose_port(port)` → `Endpoint` (also in `endpoints()`) | execution | guaranteed |
| `await env.open_terminal(cmd)` → `{session_id, ws_path, token}` | execution | declared `terminals: N` |

The **workspace plane** is host-serviced (the env just mounts its workspace
read-write), so files are guaranteed; the **execution plane** is routed to the
env's own process. Read the contract before spawning via
`gen.generators()` → `info.environment`, or `await handle.capabilities()` after.

Dual-use: the *same* environment is a normal visible cell when a human runs it
directly (its `.terminal`/`.website` render; the serve loop idles), and an
invisible child a worker drives (the serve loop fields its requests). The exec
channel is keyed to the spawning parent, so direct human use exposes no new
surface beyond the terminal/port the author chose.

**Choosing the shape — "new image = new generator".** Each Docker image is its
own generator. Make it an *environment* (`environment: true`, the helper's
`.serve()`) only when the image is meant to be **driven by other generators** —
e.g. `linux-env`, a generic Linux box many workers run code in. A generator
whose image is **single-consumer** and human-facing (a VS Code iframe, a Claude
TTY) just uses `_env_shared.DockerEnvironment` directly for the container
lifecycle + `exec` / `expose_port`; it stays a plain `daemon`, **not** an
environment, because nothing else drives it. If a second generator later wants
the same image, *that* is when you extract an environment-generator for it — and
the original becomes one of its consumers. Don't reach for `serve()`/routing
until there's a real second consumer; the indirection only pays off then.

---

## 7. Worked examples

### Example A — pure Python, no LLM (the `merge` generator)

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Union 2+ input cells into one output cell. Topmost wins on collisions."""
import gen

async def run():
    rows: list[str] = []
    for label, cell_files in gen.input_groups().items():
        rows.append(f"- **{label}**: {len(cell_files)} files")
        for path, content in cell_files.items():
            if not gen.has_file(path):
                gen.update_file(path, content)

    gen.update_file("_merge.md", "# Merge\n\n" + "\n".join(rows) + "\n")
    await gen.update(
        name=f"merged",
        summary=f"merged {len(gen.input_groups())} cells",
        pinned="_merge.md",
    )

if __name__ == "__main__":
    gen.main(run)
```

### Example B — single-shot LLM agent (modify_files-style)

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic-ai"]
# ///
"""Run an agent over the input cell's files. Carries unedited files forward."""
import gen

async def run():
    cfg = gen.config("pydantic-config.set_yaml")
    if not gen.prompt.strip():
        gen.update_file("error.md", "# No prompt\n\nDescribe what to do.\n")
        return  # auto-flush handles the cell write

    agent = await gen.agent(
        system_prompt=cfg.get("system_prompt", "")
            + "\n\nEdit files using the read/write/edit tools. "
              "Leave unrelated files alone. Use run_python for any "
              "computation, analysis, or artifact generation.",
        tools=gen.file_tools() + [gen.python_tool()],
    )

    result = await agent.run(gen.prompt)  # auto-retries on auth failure
    gen.update_file("answer.md", str(result.output))
    await gen.update(summary=str(result.output)[:120])

if __name__ == "__main__":
    gen.main(run)
```

### Example C — daemon chat (live_chat-style)

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "pydantic-ai"]
# ///
"""Multi-turn chat with file tools. Stop ends the conversation."""
import gen

async def run():
    cfg = gen.config("pydantic-config.set_yaml")
    agent = await gen.agent(
        system_prompt=cfg.get("system_prompt", ""),
        tools=gen.file_tools() + [gen.python_tool()],
    )

    async def on_turn(turn):
        gen.history.append("user", turn.user_msg)
        reply = await gen.agent_chat_turn(turn, agent)  # streaming + auth-retry
        gen.history.append("assistant", reply)
        await gen.update(summary=turn.user_msg[:80])  # show the turn

    await gen.serve_chat(on_turn)

if __name__ == "__main__":
    gen.main(run)
```

Manifest needs `chat: true`. Chat generators typically declare
`type: ["modify", "create"]` so the per-cell button resumes the chat
against that cell's prior history *and* the top-bar button can fire a
fresh chat against an empty cell. Pair `create` with `inputs.cells:
{min: 0, max: 0}` so the fresh-chat path takes no input:
```yaml
id: "live-chat"
name: "Live Chat"
type: ["modify", "create"]
version: "0.1.0"
summary: "Multi-turn pydantic-ai chat with read/write/edit file tools."
entrypoint: "live_chat.py"
chat: true
inputs:
  cells: { min: 0, max: 1 }   # 0 → fresh chat; 1 → the modify path
draft_files:
  - "pydantic-config.set_yaml"
config_tags:
  default: {}
```

### Example D — subprocess one-shot (git_clone-style)

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Clone a Git repo into the cell. Streams output to the run log."""
import gen

async def run():
    cfg = gen.config("pydantic-config.set_yaml")
    repo = (cfg.get("repo") or "").strip()
    if not repo:
        gen.update_file("error.md", "# No repo\n\nSet `repo` in config.\n")
        return

    token = await gen.secret("GITHUB_TOKEN", prompt_if_missing=True,
                              description="GitHub token for private repos (optional)")
    env = {"GIT_TERMINAL_PROMPT": "0"}
    if token:
        env["GIT_ASKPASS"] = "echo"
        env["GITHUB_TOKEN"] = token

    rc, output = await gen.run_subprocess(
        ["git", "clone", "--depth=1", repo, "."],
        cwd=gen.workspace_path(),
        timeout=300,
    )
    if rc != 0:
        gen.update_file("error.md", f"# Clone failed\n\n```\n{output}\n```\n")
        await gen.update(summary=f"clone failed (rc={rc})")
        return

    gen.update_file("_clone.md", f"# Cloned {repo}\n")
    await gen.update(summary=f"cloned {repo}")

if __name__ == "__main__":
    gen.main(run)
```

### Example E — port-bound daemon (browser_live-style)

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "aiohttp"]
# ///
"""Bind an HTTP server on a free port; the cell shows it as a live preview."""
import asyncio
import gen
from aiohttp import web

async def run():
    app = web.Application()
    app.router.add_get("/", lambda r: web.Response(text="hello"))

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]

    await gen.serve_port(port, name="hello-server")
    gen.update_file("_server.md", f"# Server on port {port}\n")
    await gen.update(summary=f"serving on :{port}")

    while not gen.cancelled:
        await asyncio.sleep(0.5)

    await runner.cleanup()

if __name__ == "__main__":
    gen.main(run)
```

Manifest:
```yaml
id: "hello-server"
name: "Hello Server"
type: ["create"]
version: "0.1.0"
summary: "Bind a tiny HTTP server."
entrypoint: "server.py"
inputs:
  cells: { min: 0, max: 0 }   # no input → spun up fresh
daemon: true
```

### Example F — container daemon with terminal (claude_cli-style)

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Open a Docker container, expose a terminal in the cell, wait for actions."""
import json
import gen

async def run():
    rc, cid = await gen.run_subprocess(
        ["docker", "run", "-d", "-v",
         f"{gen.workspace_path()}:/work", "ubuntu:22.04", "sleep", "infinity"],
    )
    cid = cid.strip()
    if rc != 0 or not cid:
        gen.update_file("error.md", f"# Container failed\n\n{cid}\n")
        return

    sess = await gen.terminal(cid, ["bash"], cwd="/work")
    gen.update_file("shell.terminal", json.dumps({**sess, "label": "Shell"}))
    await gen.update(name="Container", summary="terminal ready")

    try:
        while not gen.cancelled:
            action = await gen.wait_for_action(timeout=1.0)
            if action == "restart":
                gen.stop_terminal(sess["session_id"])
                sess = await gen.terminal(cid, ["bash"], cwd="/work")
                gen.update_file("shell.terminal",
                                json.dumps({**sess, "label": "Shell"}))
                await gen.update(summary="terminal restarted")
    finally:
        gen.stop_terminal(sess["session_id"])
        await gen.run_subprocess(["docker", "rm", "-f", cid], timeout=10)

if __name__ == "__main__":
    gen.main(run)
```

Manifest:
```yaml
id: "container-shell"
name: "Container Shell"
type: ["create"]
version: "0.1.0"
summary: "A bash shell inside a fresh Ubuntu container."
entrypoint: "container_shell.py"
inputs:
  cells: { min: 0, max: 0 }   # no input → a fresh container
daemon: true
chat: false
```

### Example G — call another generator and fold its output

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Run the installed merge generator over our inputs, then keep its files."""
import gen

async def run():
    r = await gen.call("merge", input_groups=gen.input_groups())
    if not r.ok:
        gen.update_file("error.md", f"# sub-run failed\n\n{r.error}\n")
        return
    for path, content in r.files.items():
        gen.update_file(path, content)
    await gen.update(summary=f"merged via sub-run: {len(r.files)} files")

if __name__ == "__main__":
    gen.main(run)
```

### Example H — spawn a preview daemon, surface it, tear it down

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml"]
# ///
"""Edit the input files (terminating child), then open them in a live
VS Code daemon the user can use while this run stays alive; stop it on
exit (parent-bound)."""
import gen

async def run():
    edited = await gen.call("modify-files", inputs=gen.input_files(),  # terminating
                            prompt="add a /hello endpoint")
    async with gen.spawn("vscode-env", inputs=edited.files,            # daemon, parent-bound
                         surface=gen.SurfaceSpec(name="Editor")) as env:
        eps = await env.endpoints()                                    # [Endpoint(http, url=…)]
        if eps:
            gen.log(f"editor at {eps[0].url}")
        # ...let the user work in the editor while THIS run stays alive...
    # context exit -> the vscode-env daemon is stopped automatically

if __name__ == "__main__":
    gen.main(run)
```

### Example I — an environment, and a worker that drives it

The environment (a daemon; `environment: true` in the manifest):

```python
# /// script
# requires-python = ">=3.11"
# dependencies = ["pyyaml", "docker"]
# ///
"""A warm Linux container a worker can run code in, and a human can shell into."""
import os, sys
import gen
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from _env_shared import DockerEnvironment   # shared generator code (a _* sibling)

async def run():
    env = DockerEnvironment(image="collimate-linux-small:v1", mount="/work")
    env.surface_terminal(label="Shell")            # human surface
    await gen.update(name="Linux Env", summary="environment ready")
    await env.serve()                              # serve the parent; remove the container on Stop

if __name__ == "__main__":
    gen.main(run)
```

The worker (spawns it once, pushes code, runs it, launches a server — no Docker):

```python
import gen

async def run():
    async with gen.spawn("linux-env", inputs=gen.input_files()) as env:
        if await env.capabilities() is None:
            gen.update_file("error.md", "# linux-env unavailable\n"); return
        await env.put_files(gen.input_files())
        rc, out = await env.exec(["python", "-m", "pytest", "-q"], cwd="/work")
        gen.update_file("run.txt", f"(exit {rc})\n{out}")
        if rc == 0:                                 # green → launch + preview the app
            await env.exec_background(["python", "app.py"], cwd="/work")
            ep = await env.expose_port(8000)
            gen.update_file("preview.website", f'{{"url": "{ep.url}"}}')

if __name__ == "__main__":
    gen.main(run)
```

---

## 8. Checklist before shipping

- [ ] `manifest.gen_yaml` has `id`, `name`, `type`, `version`, `summary`, `entrypoint`.
- [ ] `type` is a list of 1–2 of `modify` / `create` and matches the
      input contract:
      `modify` in the array → `inputs.cells` includes 1 (the current cell);
      `create` in the array → `inputs.cells.min >= 0`, with the bounds picking
      the input shape (no input `{min: 0, max: 0}`, a single cell `{min: 1,
      max: 1}`, or a stack like `{min: 1, max: 99}`). Mixed lists like
      `["modify", "create"]` follow the strictest applicable rule.
- [ ] `summary` is present, non-empty, and 1–2 sentences. Lint warns when
      longer.
- [ ] If the manifest has a `prompt_intent` or any `.set_yaml` in
      `draft_files`, it declares `config_tags:` with a `default:` tag
      (`config_tags: {default: {}}` when no named presets are needed).
- [ ] `prompt_required: true` if the run is useless without a prompt (only
      legal with `prompt_intent`); `required: true` on `.set_yaml` fields the
      run can't proceed without (never on a `checkbox` — lint warns).
- [ ] `chat: true` if the generator loops over user messages; `daemon: true` if it stays alive serving a port/terminal; `ephemeral: true` for a throwaway live session whose cell never enters DAG history (offers "close" instead of "stop").
- [ ] If the run needs to branch on which mode the user picked, read
      `gen.invocation_type` ("modify" | "create").
- [ ] PEP 723 `# /// script` block at the top of the .py file lists every dep (`pyyaml` plus anything specific). **Do not list `collimate-sdk`** — the host injects the SDK source onto `PYTHONPATH` so `import gen` works without `uv` having to resolve a published package.
- [ ] `if __name__ == "__main__": gen.main(run)` is the entrypoint.
- [ ] Long-running loops poll `gen.cancelled` (or use `gen.serve_chat`, `gen.agent_chat_turn`, `gen.run_subprocess`, `gen.wait_for_action`, which handle it internally).
- [ ] Subprocess errors land in the cell as a clear error file, not as an unhandled exception.
- [ ] Daemon generators clean up resources (terminals, ports, containers) in a `try/finally`.
- [ ] Validated the run host-free with `collimate.testing.run_generator` (seed
      inputs/config/prompt, assert `result.ok` and `result.files`) before
      shipping — see [`testing-generators.md`](./testing-generators.md).
- [ ] Pointer files (`.terminal` / `.website`) follow the shared contract —
      build `.terminal` with `collimate.pointers.terminal_pointer(...)`.
- [ ] If you compose other generators, use `gen.call` (terminating) /
      `gen.spawn` (daemon) — invisible by default; surface only what the
      user should see.
- [ ] If your daemon owns a runtime others should run work in, declare
      `environment:` (implies `daemon`), build it with
      the `_env_shared.DockerEnvironment` helper (shared generator code, **not**
      in the SDK — keeps `collimate` Docker-free) and `await env.serve()`.
      Workers drive it with `handle.exec` /
      `put_files` / `exec_background` / `expose_port` — never `import docker`.
      Environments are `spawn`ed, never `call`ed.

---

## 9. `gen.*` cheat sheet

Every tool available to a generator. `await` the coroutines (noted). Tier A is
portable (mirrored on the WASM runtime); **Tier B** is native-only.

### Run shape & lifecycle
| Call | Returns | Notes |
|---|---|---|
| `gen.main(run)` | — | entrypoint, in `if __name__ == "__main__"` |
| `gen.prompt` | `str` | picker textarea text |
| `gen.invocation_type` | `str` | `"modify"`\|`"create"` the user picked |
| `gen.cancelled` | `bool` | Stop pressed — poll in loops |
| `gen.messages` | `list[Message]` | prior chat history from input cells |

### Inputs & config
| Call | Returns |
|---|---|
| `gen.read_input(path)` | `str \| bytes` |
| `gen.input_files()` | `dict[path, content]` |
| `gen.input_groups()` | `dict[label, dict]` (multi-cell) |
| `gen.config(name)` | `dict` (YAML/JSON by ext; `{}` if missing) |

### Output stage (this cell's files) & cells
| Call | Returns |
|---|---|
| `gen.update_file(path, content)` · `read_file(path)` · `has_file(path)` · `list_files()` · `delete_file(path)` | file I/O on the stage |
| `await gen.update(*, name=, summary=, pinned=)` | flush a version of the running cell |
| `await gen.create_stack_cell(name, *, summary=, pinned=, files=)` | `cell_id` — mint a sibling |

### Chat history & live chat
| Call | Returns |
|---|---|
| `gen.history.append(role, content)` · `.seed_from_chatlog()` · `.as_pai()` · `list(gen.history)` | conversation log → visible `.chatlog` |
| `await gen.serve_chat(on_turn, *, label=, log_file=, live_file=, resume=True)` | — (serves a streaming chat until Stop) |
| `turn.user_msg` · `turn.delta(text)` · `turn.tool(name, status, **kw)` · `turn.cancelled` · `turn.redirect` | the `ChatTurn` handed to `on_turn` |
| `gen.emit_stream_event(turn_id, event)` | — (custom in-handler backends) |

### Secrets · status · LLM
| Call | Returns |
|---|---|
| `await gen.api_key(provider, *, force=False, description="")` | `str` (sets the env var) |
| `await gen.secret(name, *, prompt_if_missing=False, description="")` | `str` |
| `gen.log(line)` · `gen.status(msg)` · `gen.progress(cur, total)` | — |
| `await gen.agent(*, system_prompt="", tools=None, output_type=None, provider=, model=, max_tokens=, config_file=)` | agent wrapper (`.run()` auth-retries) |
| `await gen.agent_chat_turn(turn, agent, *, message_history=None, on_cancel_text=, cancel_poll_interval_s=0.2)` | `str` (streaming, within `serve_chat`) |
| `gen.file_tools()` · `gen.python_tool(*, timeout=60, default_packages=None)` | pydantic-ai `Tool`s |

### Subprocess · ports · terminals · workspace — **Tier B**
| Call | Returns |
|---|---|
| `await gen.run_subprocess(cmd, *, timeout=120, cwd=, shell=, turn_id=, …)` | `(rc, output)` — runs **here**, streams |
| `await gen.serve_port(port, *, name="preview", path="", snapshot_source=None)` | — (daemon iframe; `.website`) |
| `await gen.terminal(container_id, cmd, *, cwd=, env=)` | `{session_id, ws_path, token}` (`.terminal`) |
| `gen.stop_terminal(session_id)` | — |
| `gen.workspace_path()` · `gen.snapshot()` | abs path · `{relpath: sha256}` |
| `await gen.request_settings(path)` · `await gen.wait_for_action(timeout=None)` | values dict · action id\|`None` |

### Composition — run other generators (Tier B; dev-mode safe)
| Call | Returns |
|---|---|
| `gen.generators(*, group=None)` | `list[GeneratorInfo]` (`.environment` is the contract) |
| `gen.inline(files, *, entrypoint)` | `Source` |
| `gen.spawn(source, *, inputs=, input_groups=, prompt=, invocation_type=, config=, secrets=, surface=)` | `GeneratorHandle` (daemon-safe) |
| `await gen.call(source, *, …, timeout=300)` | `GeneratorResult` (terminating only) |
| `gen.check_renderer(files, *, entrypoint)` | `RendererCheck` |

`GeneratorHandle`: `await wait(timeout=)` · `endpoints(wait=, timeout=)` · `files()` · `status()` · `surface(spec)` · `stop()` · `async with`.

### Environments — drive a child runtime (Tier B)
| Worker side (the handle) | Returns |
|---|---|
| `await handle.capabilities()` | `EnvironmentSpec \| None` |
| `await handle.put_files(map)` · `write_file` · `read_file` · `delete_file` · `list_files` · `snapshot` · `watch_files()` | workspace plane (guaranteed) |
| `await handle.exec(cmd, *, cwd=, env=, timeout=)` | `(rc, output)` |
| `await handle.exec_background(cmd)` → `ProcessHandle` (`await .wait()` / `.stop()`) | long-running process |
| `await handle.expose_port(port)` · `open_terminal(cmd)` | `Endpoint` · `{session_id, ws_path, token}` |

| Environment author side | |
|---|---|
| `await gen.serve_environment(on_exec=, on_exec_background=, on_expose_port=, on_terminal=, on_wait_process=, on_stop_process=, max_concurrency=1)` | serve loop; blocks until Stop |
| `_env_shared.DockerEnvironment(...).serve()` | the Docker-free authoring path (shared generator code) |

### Types & exceptions
`GeneratorResult` · `GeneratorInfo` · `EnvironmentSpec` · `Endpoint` · `CellRecord` ·
`RendererCheck` · `Request` · `Source` · `SurfaceSpec` · `GeneratorHandle` ·
`ProcessHandle`. Exceptions: `gen.Cancelled`, `gen.IPCError` (+ `IPCNakError` /
`IPCTimeoutError` / `IPCDisconnectedError`).
