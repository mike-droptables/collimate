# How to Write a Collimate Renderer

This is a comprehensive reference for building renderers in Collimate. It contains every detail needed to write a renderer from scratch, including the full SDK API, manifest format, styling constraints, and real-world patterns.

## What Is a Renderer?

A renderer is an **ES module** (TypeScript/React or vanilla JS) that displays and optionally edits a file in the Collimate workspace. Renderers:

- Are matched to files by extension (e.g., `.md` files open in the markdown renderer)
- Can be read-only viewers or full editors with two-way content sync
- Can optionally render diff views (before/after comparison)
- Can load external libraries from CDNs
- Run in one of two hosting modes: **native** (Shadow DOM) or **iframe** (sandboxed)

> A renderer's source cell, like a generator's, can be **"exposed to generators"** (a per-channel switch in the management view, on by default). When exposed, other generators can read and edit (version) the renderer's code via `gen.read_cell` / `gen.write_cell` — see "Editing other generators" in `how-to-write-a-generator.md`.

## CRITICAL: Styling Constraints

**Native renderers run inside Shadow DOM.** This means:

- **className and Tailwind classes DO NOT WORK** - the host page's stylesheets do not cascade into the shadow root
- **You MUST use inline `style={}` attributes** for all styling
- Use full hex/rgb color values, not CSS variables or Tailwind utilities
- If you need CSS classes, inject them via `api.injectStyle()` or `api.loadCSS()`
- **There is NO CSS reset in the shadow root — box model defaults to `content-box`.** This is a real footgun: an element with `width: 100%` *and* padding/border renders **wider than its parent** and overflows (the classic symptom is an editor or input spilling past the right edge on a narrow cell). The host cannot inject a global reset for you — that would silently reflow every already-shipped renderer (see the frozen-renderer rule below). So inject a `box-sizing` reset once, from a `useEffect` at the **top level of your component** — get `api` from `useCollimateFile()` at the top, and NEVER call a hook (`useCollimateFile`, `useEffect`) inside another hook's callback (a Rules-of-Hooks violation that crashes at mount — and the offline compile check will NOT catch it, see `testing-generators.md`):

  ```jsx
  function MyRenderer() {
    const { content, api } = useCollimateFile();     // hooks at the top, always
    React.useEffect(() => {
      api.injectStyle(`*, *::before, *::after { box-sizing: border-box; }`);
    }, [api]);
    // …render with inline styles; width: 100% now behaves as expected.
  }
  ```

  Do this in any renderer with padded, full-width elements (editors, inputs, cards).

**Iframe renderers** have full CSS isolation and can use any styling approach (classes, Tailwind, external sheets). However, they have higher overhead due to postMessage communication.

**Rule of thumb**: Use `embed: "native"` with inline styles for simple/lightweight renderers. Use `embed: "iframe"` when you need external CSS frameworks or full DOM isolation.

## Renderer ↔ generator protocol changes MUST be additive (both are frozen per channel)

A renderer's source AND its generator's source are both seeded into a channel's cells **when the channel is created** and served from those frozen cells for the channel's whole life — there is no auto-upgrade for either. (Only the underlying `collimate` SDK *library* — the `gen.*` runtime — is injected fresh into every run.) Each half can also be upgraded **independently** in an existing channel: a renderer via an in-app `.tsx` edit or a `.colrend` re-import; a generator via a re-seed / package import. So the two halves drift **in both directions** — a new renderer can meet an old generator, or a new generator an old renderer.

That makes one rule non-negotiable for the wire protocol between a renderer and its generator (WebSocket frames, a pinned pointer file, event kinds) — and the obligation is **mutual** (both sides must tolerate the other being older):

- **Add** fields / frame-types / event-kinds; never rename or repurpose an existing one.
- A message arriving **without** a new field must keep behaving exactly as before — default it on the receiving side (`const tid = f.thread_id || activeThread`), on the renderer AND in the generator.
- Don't tighten parsing to reject a shape the other (possibly older) half still emits.

If you genuinely must make a breaking protocol change, both cells have to be re-seeded together — a half-upgraded channel (new renderer, old generator, or vice-versa) will silently break live cells. Design each side to tolerate both the old and new message shapes across the transition.

## File Structure

Renderers are organised into **groups**. Every renderer lives in its own directory under `collimate-sdk/renderers/<group>/`:

```
renderers/
  basic/                       # group folder
    monaco/
      manifest.rend_yaml       # REQUIRED: metadata, extensions, embed mode
      main.tsx                 # REQUIRED: the entrypoint module
    markdown/
      ...
    terminal/
      ...
```

A group is just a top-level subdirectory. Folder location is the only thing that determines group membership — there is no per-group config file. The build script copies the entire tree recursively to `api/templates/renderers/`, and on new-channel creation each group is seeded as one cell inside a single Renderers stack. So a fresh channel comes up with one cell per group (e.g. "Basic"), each containing the source for its members.

To add a new group, create a new top-level subdirectory under `collimate-sdk/renderers/`. To add a renderer to an existing group, drop a new subdirectory under that group's folder. The runtime discovers renderers by scanning every `manifest.rend_yaml` in the channel's renderer source cells, so depth doesn't matter — it works at one level, two levels, or arbitrarily deep.

A generator can also add renderers to the running channel at run time (gated on cell exposure): `gen.add_renderer(cell_id, id=…, name=…, entrypoint=…, files=…, extensions=[".foo"])` writes `<id>/manifest.rend_yaml` + the renderer's files into an existing exposed renderer-source cell, and `gen.create_renderer_cell(name, files={…})` creates a whole new renderer source cell (auto-exposed). Compile-check a renderer's source before committing with `gen.check_renderer(files, entrypoint=…)` — that's how the Guide generator tests a renderer it scaffolds.

The `.rend_yaml` extension is what makes the frontend recognise this file as a renderer manifest and route it through the **schema_form** renderer for editing — you get a form with a fixed schema (dropdowns for `embed`, a list editor for `extensions`, etc.) instead of free-form YAML, so it is impossible to typo a required field or set `embed` to a value the runtime doesn't accept.

The `schema_form` renderer claims three extensions in total — `.gen_yaml` (generator manifests), `.rend_yaml` (renderer manifests), and `.set_yaml` (generator settings). Picking one of these extensions for any structured config file is enough to get the form UI for free.

## Step 1: Write the manifest.rend_yaml

### Full Manifest Schema

```yaml
# REQUIRED FIELDS
id: "my-renderer"              # Unique identifier (lowercase, hyphens ok)
name: "My Renderer"            # Display name in the UI
version: "1.0.0"               # Semantic version
summary: "Short description of what this renderer does."   # 1–2 sentences
entrypoint: "main.tsx"         # Entry file (.tsx, .ts, or .js)
embed: "native"                # "native" = Shadow DOM (inline styles only!)
                               # "iframe" = sandboxed iframe (any CSS ok)

# FILE MATCHING — every extension must start with a dot.
extensions:                    # File extensions this renderer handles
  - ".myext"
  - ".other"

# DIFF SUPPORT
supports_diff: true            # true if you provide a diff view component
```

### Real Examples

**Simple native text editor:**
```yaml
id: "text"
name: "Text Editor"
version: "1.1.0"
summary: "Plain-text viewer and editor powered by the React SDK."
entrypoint: "main.tsx"
embed: "native"
extensions:
  - ".txt"
  - ".log"
  - ".env"
  - ".gitignore"
  - ".cfg"
  - ".ini"
  - ".csv"
  - ".sh"
supports_diff: true
```

**Iframe renderer with external library:**
```yaml
id: "html"
name: "HTML Renderer"
version: "1.1.0"
summary: "Renders HTML with linked siblings and split-pane Monaco editor."
entrypoint: "main.tsx"
embed: "iframe"
extensions:
  - ".html"
  - ".htm"
supports_diff: true
```

**Native renderer with no editing (viewer only):**
```yaml
id: "website"
name: "Website Viewer"
version: "1.1.0"
summary: "Renders a URL in a sandboxed iframe."
entrypoint: "main.tsx"
embed: "native"
extensions:
  - ".website"
supports_diff: false
```

**Fallback renderer (no extensions = only used when explicitly selected):**
```yaml
id: "markdown"
name: "Markdown Renderer"
version: "1.1.0"
summary: "Fallback markdown renderer."
entrypoint: "main.tsx"
embed: "native"
extensions: []
supports_diff: true
```

## Step 2: Write the Renderer Module

### The SDK

Renderers use the React SDK — one supported surface, served by the host at `/api/sdk/react.js`:

```typescript
import React from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';
```

(An older `vanilla.js` SDK existed for imperative DOM mounting. It has been removed — wrap imperative renderers in a thin React component using a ref + `useEffect` instead.)

### Imports

Renderers use ES module imports. There is no build step - the runtime transpiles `.tsx` on the fly via Babel.

```typescript
// React from CDN
import React, { useState, useEffect, useRef } from 'https://esm.sh/react@18';

// Collimate React SDK (provides hooks and defineRenderer)
import { defineRenderer, useCollimateFile, useSiblingFile } from '/api/sdk/react.js';

// External libraries from CDN
import SomeLib from 'https://esm.sh/some-library@1.0.0';
```

**Important**: Always use `https://esm.sh/` for React and other npm packages. Always use `/api/sdk/react.js` for the Collimate SDK (root-relative path).

## React SDK API

### defineRenderer()

Wraps your React component(s) and exports the mount/unmount lifecycle:

```typescript
export default defineRenderer({
    component: MyEditorComponent,           // REQUIRED: main view
    diffComponent: MyDiffComponent,         // OPTIONAL: diff view
});
```

### useCollimateFile() Hook

The primary hook. Returns everything you need to read/edit the file:

```typescript
const {
    initialContent,  // string: file content when renderer first opened (never changes)
    content,         // string: current synced content (updates on external changes)
    saveContent,     // (newContent: string) => void: push edits back to the workspace
    isReadOnly,      // boolean: true if file should not be editable
    fileName,        // string: name of the file being rendered (e.g., "output.md")
    api,             // RendererAPI: full API object (see below)
    diffContent,     // string | null: previous version content (only in diff mode)
} = useCollimateFile();
```

### useSiblingFile() Hook

Fetches a related file from the same cell (e.g., an HTML file loading its CSS):

```typescript
const { url, loading } = useSiblingFile('./styles.css');
// url: Blob URL string (pass to <link href> or <script src>)
// loading: boolean
```

### useDebouncedSaveContent() Hook

A debounced wrapper around `saveContent` (350 ms by default) with
automatic timer cleanup on unmount — the standard way an editor renderer
persists keystrokes without a save-per-character.

```typescript
const save = useDebouncedSaveContent(saveContent);  // or (saveContent, delayMs)
// editor onChange:
onChange={(text) => save(text)}
```

The returned callback carries a **`.flush()`** method that fires any
pending save immediately and cancels the timer (a no-op when nothing is
pending). Wire it to `api.onFlush` (below) so the host's deterministic
Save can't lose a mid-keystroke edit to the debounce window:

```typescript
useEffect(() => api.onFlush?.(() => save.flush()), [api, save]);
```

### Following host content updates (onSetContent)

The host can push fresh content into a *live* renderer without
remounting it — this is what the generator-config modal does when the
user switches config tags, so the editor swaps values in place with no
iframe reload or spinner.

**You usually get this for free.** A renderer built with
`defineRenderer` that renders from the `content` field of
`useCollimateFile()` follows host pushes automatically — the wrapper
subscribes to `onSetContent` and updates `content` for you. Most
renderers (text, code, JSON, …) need to do **nothing**.

**Implement `api.onSetContent` yourself only if you own a private editor
model that `content` doesn't drive** — an imperative editor instance
(CodeMirror/Monaco built outside `useCollimateFile`), a rich-text engine
(milkdown's Crepe), or a parsed form (the schema form). In the callback,
apply the new value to your editor and **do not** call `onChange` — the
host already owns the value it pushed. A renderer that subscribes to
neither path still works: the host falls back to remounting it (a brief
reload/spinner on a tag switch), so content is never dropped — wiring
`onSetContent` is purely what upgrades that to a seamless in-place swap.

See the "Imperative editor (onSetContent + onFlush)" example below.

### Full RendererAPI Object

Available via `const { api } = useCollimateFile()` or passed directly in vanilla SDK:

```typescript
interface RendererAPI {
    // Content access
    getContent(): Promise<string>;                    // Current file content
    getDiffContent(): Promise<string | null>;         // Previous version (diff mode only)
    getFilename(): string;                            // File name
    getCellId(): string;                              // Cell UUID

    // Sibling files (other files in the same cell)
    getSiblingFile(path: string): Promise<string>;    // Fetch sibling file content

    // Editing
    onChange(newContent: string): void;                // Push content changes to workspace
    isReadOnly(): boolean;                            // Check if editing is disabled

    // File change notifications
    onFilesChanged(cb: (detail: any) => void): () => void;  // Subscribe; returns unsubscribe fn

    // In-place content push from the host (the generator-config modal's
    // tag load). The host hands you fresh content WITHOUT remounting the
    // renderer — apply it to your editor state in the callback. Do NOT
    // re-fire onChange from here: the host already owns the value it
    // pushed. Renderers that don't subscribe get remounted instead, so
    // wiring this is what avoids a reload/spinner on a tag click.
    // Optional — feature-detect (`if (api.onSetContent)`). Returns unsub.
    onSetContent?(cb: (content: string) => void): () => void;

    // Flush request from the host (the modal's Save). Push your latest
    // value through onChange NOW — synchronously, or return a promise the
    // host awaits — so a mid-keystroke edit isn't lost to a save debounce.
    // If you use useDebouncedSaveContent, just call its `.flush()`.
    // Optional — feature-detect. Returns unsub.
    onFlush?(cb: () => void | Promise<void>): () => void;

    // Scroll persistence (renderer reloads preserve scroll position)
    onScrollRestore(cb: (top: number) => void): () => void; // Called with saved scroll position
    reportScroll(top: number): void;                         // Save current scroll position

    // Selection reporting (feeds the top-nav "Pin prompt" button)
    // Most renderers DON'T need to call this: sandbox.html auto-reports
    // any native text selection (contentEditable, textarea, plain text,
    // ProseMirror/milkdown) via a `selectionchange` listener. Call this
    // explicitly only if your editor owns a private selection model the
    // host DOM can't see — Monaco, CodeMirror, and similar are the
    // canonical examples. Pass an empty string to clear.
    reportSelection(text: string): void;

    // Theme signal — the host's active scheme plus resolved CSS tokens.
    // See "Theming your renderer" below for which vars are piped in.
    getTheme(): {
        scheme: 'dark' | 'light';
        themeId: string;                   // e.g. 'tube-amp', 'linear-light', 'custom'
        vars: Record<string, string>;      // camelCase → CSS var value
    };
    onThemeChange(cb: (t: ReturnType<typeof getTheme>) => void): () => void;

    // Visibility signal — false while the cell is scrolled offscreen and the
    // host has display:none'd its subtree (which clears GPU/canvas drawing
    // buffers), true when on screen. Like onThemeChange, the callback fires
    // immediately on subscribe and on every flip thereafter. GPU/canvas
    // renderers repaint their buffer on visible=true. Native renderers only —
    // iframe-embedded renderers always report true. See "Reacting to
    // visibility" below. Prefer the `useVisibility(api)` hook.
    getVisible(): boolean;
    onVisibleChange(cb: (visible: boolean) => void): () => void;

    // Styling (for native/shadow DOM renderers)
    injectStyle(css: string): void;    // Inject a <style> tag into the shadow root
    loadCSS(href: string): void;       // Inject a <link rel="stylesheet"> into the shadow root

    // Renderer action button → generator. Returns true if delivered. The
    // generator receives the id via `gen.wait_for_action()`. The `.terminal`
    // and `.website` pointer renderers use this for their buttons. Optional —
    // feature-detect (`if (api.emitAction)`).
    emitAction?(id: string): Promise<boolean>;
}
```

**Selection reporting example (Monaco):**

```tsx
const { api } = useCollimateFile();
editor.onDidChangeCursorSelection(() => {
    const sel = editor.getSelection();
    const model = editor.getModel();
    const text = (sel && model && !sel.isEmpty())
        ? model.getValueInRange(sel)
        : '';
    api.reportSelection(text);
});
```

### Cheat sheet — every hook + `api.*`

The full surface available to a renderer (from `/api/sdk/react.js`). Most
renderers need only `useCollimateFile` + `useDebouncedSaveContent`.

| Hook | Returns / shape |
|---|---|
| `defineRenderer({ component, diffComponent? })` | default export; the mount/unmount lifecycle |
| `useCollimateFile()` | `{ initialContent, content, saveContent, isReadOnly, fileName, api, diffContent }` |
| `useSiblingFile(path)` | `{ url, loading }` — Blob URL for a same-cell file |
| `useDebouncedSaveContent(saveContent, delayMs=350)` | debounced `save(text)` with `.flush()` |
| `useVisibility(api)` | `{ visible, onChange }` — is the cell on screen; repaint GPU/canvas buffers on re-show |
| `tokens` | design tokens (camelCase → CSS var); see *Styling Patterns* |

`api` (the `RendererAPI` object):

| Group | Methods |
|---|---|
| Content | `getContent()` · `getDiffContent()` · `getFilename()` · `getCellId()` · `getSiblingFile(path)` |
| Editing | `onChange(next)` · `isReadOnly()` |
| Host sync | `onSetContent?(cb)` (apply pushed content, don't re-`onChange`) · `onFlush?(cb)` (commit pending edits now) · `onFilesChanged(cb)` |
| Scroll / selection | `onScrollRestore(cb)` · `reportScroll(top)` · `reportSelection(text)` (only if your editor owns a private selection model) |
| Theme | `getTheme()` → `{ scheme, themeId, vars }` · `onThemeChange(cb)` |
| Visibility | `getVisible()` → `boolean` · `onVisibleChange(cb)` — fires when the cell scrolls on/off screen; repaint GPU/canvas buffers on `true` (native only) |
| Styling (native only) | `injectStyle(css)` · `loadCSS(href)` |
| Actions | `emitAction?(id)` → `Promise<boolean>` — fires a renderer button; the generator receives it via `gen.wait_for_action()` |

Subscriptions (`onSetContent`/`onFlush`/`onFilesChanged`/`onScrollRestore`/`onThemeChange`/`onVisibleChange`)
return an **unsubscribe** fn — call it on unmount (`useEffect(() => api.on…(cb), […])`).
The `?`-marked methods are optional — feature-detect (`if (api.emitAction)`).

## Theming your renderer

Every renderer should match the host's active theme — both its color scheme (dark/light) and its specific palette. The host pushes the current theme into your renderer two ways:

**1. CSS variables on `:root` inside the iframe** — the easiest path. Sandbox.html mirrors the host's resolved theme tokens onto the iframe's own `:root` on mount and on every theme change. Write your inline styles against them:

```tsx
<div style={{
    background: 'var(--void-main)',           // app background
    color: 'var(--signal-white)',             // primary text
    border: '1px solid var(--tungsten-dim)',  // subtle border
    fontFamily: 'var(--font-mono)',
    borderRadius: 'var(--radius)',
}}>
```

Hex fallbacks are recommended (`var(--void-main, #0a0b0d)`) so the renderer still looks right in standalone unit tests before any SET_THEME arrives.

Full list of forwarded vars: `--renderer-surface` (the theme-aware renderer background — `#1a1a1a` dark / `#ededed` light; the canonical surface for a renderer's own root, distinct from `--void-main` which is the app shell), `--void-main`, `--obsidian-plate`, `--glass-panel`, `--filament-amber`, `--filament-hot`, `--electric-teal`, `--plasma-pink`, `--tungsten-dim`, `--signal-white`, `--comment-grey`, `--primary`, `--primary-foreground`, `--accent`, `--accent-foreground`, `--destructive`, `--muted`, `--muted-foreground`, `--border`, `--ring`, `--radius`, `--radius-sm`, `--radius-lg`, `--font-sans`, `--font-mono`, `--font-size-base`, `--line-height`, `--duration-fast`, `--duration-base`, `--duration-slow`, `--ease-standard`.

**2. `api.getTheme()` + `api.onThemeChange(cb)`** — for renderers embedding a library that needs a discrete dark/light prop (Monaco `vs`/`vs-dark`, Excalidraw `appState.theme`, Mermaid `theme: 'default'|'dark'`, xterm theme object):

```tsx
const initialScheme = api.getTheme().scheme;
const editor = monaco.editor.create(el, {
    theme: initialScheme === 'light' ? 'vs' : 'vs-dark',
    // …
});
const unsub = api.onThemeChange((t) => {
    monaco.editor.setTheme(t.scheme === 'light' ? 'vs' : 'vs-dark');
});
```

The callback fires *immediately* on subscribe with the current snapshot, so you don't need to also call `getTheme()` at mount — either works.

**For COLORS, prefer path 1 (inline `var(--x)`), not `getTheme().vars`.** A card/table/panel should just write `background: 'var(--renderer-surface, #1a1a1a)'` etc. — the vars follow the host palette automatically, no subscription needed. Reach for `getTheme()` only for the library-prop case above. And if you do read `theme.vars`, its keys are **camelCase token names, not CSS-var strings**: `theme.vars.rendererSurface` / `theme.vars.voidMain` — `theme.vars['--renderer-surface']` is always `undefined`. Likewise `themeId` and `scheme` are top-level on the theme object (`theme.themeId`, `theme.scheme`), not inside `vars`.

**Semantic color guidelines** — pick the token that describes what the color MEANS, not what it is today:

- Primary action, pinned accent → `var(--primary)` / `var(--filament-amber)`
- Secondary accent (links, highlights) → `var(--electric-teal)`
- Destructive / error → `var(--destructive)` / `var(--plasma-pink)`
- Border and input outlines → `var(--border)` / `var(--tungsten-dim)`
- Background chrome (toolbars, panels) → `var(--obsidian-plate)` / `var(--muted)`
- Dimmed text, placeholders → `var(--muted-foreground)` / `var(--comment-grey)`

Avoid baking a specific hex into your renderer unless the color carries inherent meaning (red=removed, green=added in a diff). For those cases, `color-mix(in srgb, <fixed hex> 25%, var(--void-main))` keeps the semantic tint readable on both light and dark.

**Preview panes that render user content** — HTML preview iframes, website embeds, etc. — should NOT adopt the host theme. The user's page owns its background and styles; forcing the host theme on the preview would give misleading feedback. The renderer's CHROME (toolbars, input fields) still follows the host theme.

## Reacting to visibility (surviving offscreen)

**Most renderers can skip this section.** A normal React/DOM renderer (text, table, markdown, a form) needs nothing here — the browser preserves DOM, and React state drives the next paint. This matters only for **native** (`embed: "native"`) renderers that paint into a **GPU or `<canvas>` drawing buffer** (xterm.js; a hypothetical WebGL/canvas chart) or hold **imperative visual state** they repaint by hand. Iframe renderers are handled differently — see the note at the end.

**The problem.** To keep many cells cheap, the host scrolls offscreen native cells out by flipping their subtree to `display:none` — and it keeps the renderer **mounted** (so scrollback, editor state, and the WebSocket survive). But `display:none` halts painting and lets the browser **discard a GPU/canvas drawing buffer**. There is no `webglcontextlost` event for this case. When the cell scrolls back, the buffer can be blank and a full-screen TUI or imperative canvas won't repaint on its own — so the surface shows **black/stale** until the next keystroke. Detaching/re-attaching the element on a remount has the same effect.

**The fix — repaint when you become visible:**

```tsx
import { useCollimateFile, useVisibility } from '/api/sdk/react.js';

function MyCanvasRenderer() {
    const { api } = useCollimateFile();
    const { visible } = useVisibility(api);

    useEffect(() => {
        if (visible) repaintMyBuffer();   // e.g. term.refresh(0, rows-1)
    }, [visible]);
    // …
}
```

`useVisibility(api)` returns `{ visible, onChange }`. Like `useTheme`, it initialises to the current state and the subscription fires **immediately on subscribe**, so a renderer that first mounts while hidden still reads the right value. `onChange(cb)` is the imperative handle (returns an unsubscribe) for repainting outside React state. It degrades safely: iframe-embedded renderers always see `visible: true`.

**WebGL context loss is separate.** `display:none` clears the *buffer*; an actual lost GPU context (a reset, or the browser reclaiming contexts when many WebGL surfaces are open) fires `webglcontextlost`. Libraries that own the context usually expose a hook — handle it so you don't get stuck blank:

- **xterm.js**: `WebglAddon.onContextLoss(() => { addon.dispose(); /* reverts to DOM renderer */ refresh(); })`. The built-in `.terminal` renderer goes further: it repaints immediately (never black), then **re-upgrades** to WebGL a bounded number of times before settling on the 2D-canvas renderer — so a context-starved page stops flapping instead of permanently dropping to the flickery DOM renderer.
- **Other native canvas libraries**: if the library owns the GL context, wire its loss/restore hooks and repaint on `onVisibleChange(true)`.

**Reference implementation:** `renderers/live/terminal/main.tsx` wires `useVisibility` (repaint on re-show), a ResizeObserver `0→box` repaint (belt-and-suspenders for the same case), and the bounded WebGL→canvas→DOM context-loss recovery described above. It is currently the only built-in renderer that needs any of this — every other native renderer is DOM/SVG/`<img>` (retained by the browser across `display:none`, so nothing goes black).

**Don't remount on visibility.** Visibility flips constantly while scrolling; treat it as a lightweight signal (repaint/pause), never as a reason to tear down and rebuild — the host deliberately keeps you mounted so your state survives.

**Iframe renderers (`embed: "iframe"`) don't need this.** They're managed by a warm iframe pool, not `display:none`: offscreen, the iframe is parked with `visibility:hidden` (which preserves its canvas buffer) or its pool slot is recycled (a full reload + remount that repaints from scratch). Either way the content returns intact. The native visibility signal is *not* forwarded across the iframe boundary, so `useVisibility` reports `visible: true` inside an iframe — calling it there is a harmless no-op. If a future iframe renderer genuinely needs a true on/offscreen signal, forward it over the same postMessage channel the host uses for `SET_THEME`.

## Diff mode

The app has a "Diff target" feature — the user picks another stack as a comparison reference, toggles Diff Mode in the top bar, and every open cell compares its files against the same-named file in the target stack's top cell. Two things make a renderer diff-capable:

1. **`supports_diff: true`** in your `manifest.rend_yaml`. The app gates the UI on this — false means "my filetype can't be diffed meaningfully" and Diff Mode shows a placeholder instead of mounting your renderer.

2. **Either** an explicit `diffComponent` in `defineRenderer()`, **or** you opt into the built-in default.

### The default diff view

If you set `supports_diff: true` and DON'T provide a `diffComponent`, the SDK mounts a built-in side-by-side text diff: two scrollable columns labeled "Before" and "After" with line-level add/remove tinting. This is free and works for anything text-shaped (plain text, markdown, HTML source, code).

```yaml
# manifest.rend_yaml
supports_diff: true
```

```tsx
// main.tsx
export default defineRenderer({
    component: MyEditor,
    // no diffComponent — you get the default diff view
});
```

### Custom diff component

For a richer diff (side-by-side Monaco, side-by-side structured comparison, visual image diff, etc.), provide your own:

```tsx
function MyDiffView() {
    const { content, diffContent } = useCollimateFile();
    // content = "after" file, diffContent = "before" file
    return <div>…custom diff UI…</div>;
}

export default defineRenderer({
    component: MyEditor,
    diffComponent: MyDiffView,
});
```

Your `diffComponent` receives the same `useCollimateFile()` context as the regular component, with `diffContent` populated as the "before" side. `isReadOnly` is forced to `true` and `saveContent` is a no-op — diff mode is view-only.

### When to set `supports_diff: false`

Set it false when line-by-line text diff is meaningless for your filetype — canvas / whiteboard renderers (Excalidraw), binary image viewers, terminal replays. Without a custom `diffComponent` that can render the filetype's diff semantics, the built-in view would just show a wall of serialized JSON or base64.

## Keyboard shortcuts and the iframe host

When your renderer runs inside an iframe (`embed: "iframe"`), the host can reclaim certain modifier combos before your renderer's own keydown listeners see them. The host pushes a dynamic list of combos into the iframe via a `SET_KEYBINDINGS` postMessage; any keydown matching one of those combos is `preventDefault`'d in the iframe's capture phase and forwarded back to the parent as a `FORWARD_KEYDOWN`.

**What this means for renderer authors:**

- Bare keys (`ArrowLeft`, `Enter`, letters with no modifier) are never forwarded — they reach your renderer normally.
- Modifier combos that the user can re-bind in Settings → Keyboard (and that have `allowedInRenderer: true` on the host side) are intercepted. At time of writing that includes `Alt+<letter>` for stack actions, `Ctrl+Arrow` for stack nav, `Ctrl+Shift+Arrow` for cell move, `Mod+K` / `Mod+,` for palette / settings, `Mod+S` for editor save, `Escape` for editor close, and `Alt+a` for zoom.
- If your renderer needs to own one of those combos (e.g. your editor has its own Mod+S save), either pick a different binding or acknowledge that the host wins. There is currently no API for a renderer to opt out of a forwarded combo.

**What this doesn't affect:**

- `window.addEventListener('keydown', …)` still works for keys the host doesn't claim. The slides renderer's bare ArrowLeft/ArrowRight listener, for example, is untouched.
- Monaco's internal command palette (F1, Ctrl+Shift+P) is untouched — nothing in the host registry binds it.
- Text input inside contenteditable / textarea — typing letters, symbols, and IME composition — is untouched.

## Imperative DOM inside React

If you need low-level DOM control (e.g. mounting an existing non-React library like Monaco or Excalidraw), wrap it in a React component that uses `useRef` + `useEffect` for the mount/cleanup lifecycle. The old `vanilla.js` SDK is no longer available.

```tsx
import React, { useEffect, useRef } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

function ImperativeView() {
    const { content } = useCollimateFile();
    const ref = useRef<HTMLDivElement | null>(null);
    useEffect(() => {
        if (!ref.current) return;
        ref.current.innerHTML = `<pre>${content}</pre>`;
        return () => { if (ref.current) ref.current.innerHTML = ''; };
    }, [content]);
    return <div ref={ref} style={{ width: '100%', height: '100%' }} />;
}

export default defineRenderer({ component: ImperativeView });
```

See the `monaco` renderer for a production example.

## Complete Working Examples

### Example 1: Simple Text Editor (Native, React)

The simplest possible renderer. A textarea with a status bar.

**manifest.rend_yaml:**
```yaml
id: "text"
name: "Text Editor"
version: "1.1.0"
summary: "Plain-text viewer and editor."
entrypoint: "main.tsx"
embed: "native"
extensions:
  - ".txt"
  - ".log"
supports_diff: true
```

**main.tsx:**
```tsx
import React, { useState } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

function TextEditor() {
    const { content, saveContent, isReadOnly, fileName } = useCollimateFile();

    return (
        <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: '#0a0b0d' }}>
            <textarea
                value={content}
                disabled={isReadOnly}
                onChange={e => saveContent(e.target.value)}
                spellCheck={false}
                style={{
                    flex: 1,
                    width: '100%',
                    background: 'transparent',
                    color: '#e2e8f0',
                    fontFamily: 'monospace',
                    fontSize: 13,
                    lineHeight: 1.6,
                    padding: 16,
                    border: 'none',
                    outline: 'none',
                    resize: 'none'
                }}
            />
            <div style={{
                height: 22,
                background: '#1a1c23',
                borderTop: '1px solid #2a2d3a',
                display: 'flex',
                alignItems: 'center',
                padding: '0 12px',
                gap: 12,
                fontFamily: 'monospace',
                fontSize: 10,
                color: '#6b7280'
            }}>
                <span>{content.split('\n').length} lines</span>
                <span>{content.length} chars</span>
                <span style={{ marginLeft: 'auto' }}>{fileName}</span>
            </div>
        </div>
    );
}

export default defineRenderer({ component: TextEditor });
```

**Key takeaways:**
- Every style is inline (Shadow DOM requirement for `embed: "native"`)
- `saveContent()` is called on every keystroke for real-time sync
- `isReadOnly` disables the textarea when the file is read-only
- Root div fills 100% width and height

### Example 2: Markdown Renderer (Native, React, Split Pane)

A split-pane editor with raw markdown on the left and rendered preview on the right.

**manifest.rend_yaml:**
```yaml
id: "markdown"
name: "Markdown Renderer"
version: "1.1.0"
summary: "Fallback markdown renderer."
entrypoint: "main.tsx"
embed: "native"
extensions: []
supports_diff: true
```

**main.tsx:**
```tsx
import React, { useState, useEffect } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

function parseMarkdown(md) {
    if (!md) return '';
    let html = md.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

    // Code blocks (fenced)
    html = html.replace(/```(\w*)\n([\s\S]*?)```/gm, (_, lang, code) =>
        `<pre><code style="background:#1a1c23;padding:12px;display:block;border-radius:6px;border:1px solid #2a2d3a;">${code.trimEnd()}</code></pre>`
    );
    // Inline code
    html = html.replace(/`([^`\n]+)`/g,
        '<code style="background:#1f2937;color:#f59e0b;padding:2px 4px;border-radius:3px;">$1</code>'
    );
    // Headings (h6 down to h1 to avoid greedy matching)
    html = html.replace(/^###### (.+)$/gm, '<h6 style="color:#f9fafb;font-weight:600;margin-top:1em;">$1</h6>');
    html = html.replace(/^##### (.+)$/gm, '<h5 style="color:#f9fafb;font-weight:600;margin-top:1em;">$1</h5>');
    html = html.replace(/^#### (.+)$/gm, '<h4 style="color:#f9fafb;font-weight:600;margin-top:1em;">$1</h4>');
    html = html.replace(/^### (.+)$/gm, '<h3 style="color:#f9fafb;font-weight:600;margin-top:1em;font-size:1.1em;">$1</h3>');
    html = html.replace(/^## (.+)$/gm, '<h2 style="color:#f9fafb;font-weight:600;margin-top:1em;font-size:1.35em;">$1</h2>');
    html = html.replace(/^# (.+)$/gm, '<h1 style="color:#f9fafb;font-weight:600;margin-top:1em;font-size:1.75em;border-bottom:1px solid #374151;padding-bottom:4px;">$1</h1>');
    // Emphasis
    html = html.replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>');
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
    // Links and images
    html = html.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img alt="$1" src="$2" style="max-width:100%">');
    html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" style="color:#60a5fa;text-decoration:underline;">$1</a>');
    // Paragraphs
    html = html.replace(/\n\n+/g, '\n\n');
    html = html.split('\n\n').map(block => {
        if (/^<[hpuobldi]/.test(block.trim())) return block;
        return `<p style="margin:0.75em 0;">${block}</p>`;
    }).join('\n');

    return html;
}

function MarkdownEditor() {
    const { content, saveContent, isReadOnly } = useCollimateFile();
    const [local, setLocal] = useState(content);

    useEffect(() => { setLocal(content); }, [content]);

    return (
        <div style={{ display: 'flex', width: '100%', height: '100%', background: '#0a0b0d' }}>
            {!isReadOnly && (
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', borderRight: '1px solid #2a2d3a' }}>
                    <textarea
                        value={local}
                        onChange={e => {
                            setLocal(e.target.value);
                            saveContent(e.target.value);
                        }}
                        style={{
                            flex: 1,
                            background: 'transparent',
                            color: '#e2e8f0',
                            fontFamily: 'monospace',
                            fontSize: 13,
                            lineHeight: 1.6,
                            padding: 16,
                            border: 'none',
                            outline: 'none',
                            resize: 'none'
                        }}
                        spellCheck={false}
                    />
                </div>
            )}
            <div
                style={{
                    flex: 1,
                    overflowY: 'auto',
                    padding: 24,
                    color: '#d1d5db',
                    fontFamily: 'sans-serif',
                    fontSize: 14,
                    lineHeight: 1.6
                }}
                dangerouslySetInnerHTML={{ __html: parseMarkdown(local) }}
            />
        </div>
    );
}

export default defineRenderer({ component: MarkdownEditor });
```

**Key takeaways:**
- Split pane: editor (left) hides when `isReadOnly` is true, showing only the preview
- Custom markdown parser uses regex (avoids heavy library dependency)
- All generated HTML also uses inline styles (shadow DOM!)
- Local state (`local`) syncs from `content` on external changes
- **Escape attribute values when string-building HTML for `dangerouslySetInnerHTML`.** Pre-escaping `&`/`<`/`>` on the input blocks tag injection, but any captured text you interpolate into a double-quoted attribute (an `alt`, a `title`, a `href`) must also have `"` replaced with `&quot;` — otherwise `![" onerror="...](x)`-style input breaks out of the attribute and injects an event handler. The renderer's shadow DOM has access to the SDK API, so this is a real XSS surface. Block `javascript:`/`data:`/`vbscript:` URLs in `href`/`src` too.

### Example 3: Monaco Code Editor (Iframe, React, with Diff Support)

A full code editor using the Monaco library from CDN, with language detection and diff view.

**manifest.rend_yaml:**
```yaml
id: "monaco"
name: "Code Editor"
version: "1.1.0"
summary: "VS Code-powered code editor with language detection."
entrypoint: "main.tsx"
embed: "iframe"
extensions:
  - ".js"
  - ".ts"
  - ".py"
  - ".go"
  - ".json"
  - ".yaml"
supports_diff: true
```

**main.tsx:**
```tsx
import React, { useEffect, useRef } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

const MONACO_VERSION = '0.44.0';
const MONACO_BASE = `https://cdn.jsdelivr.net/npm/monaco-editor@${MONACO_VERSION}/min/vs`;

// Dynamic script loader (singleton pattern)
function loadScript(src) {
    return new Promise((resolve, reject) => {
        if (document.querySelector(`script[src="${src}"]`)) { resolve(); return; }
        const s = document.createElement('script');
        s.src = src;
        s.onload = resolve;
        s.onerror = () => reject(new Error(`Failed to load: ${src}`));
        document.head.appendChild(s);
    });
}

let _monacoPromise = null;
function ensureMonaco() {
    if (_monacoPromise) return _monacoPromise;
    _monacoPromise = loadScript(`${MONACO_BASE}/loader.js`).then(() =>
        new Promise((resolve) => {
            window.require.config({ paths: { vs: MONACO_BASE } });
            window.require(['vs/editor/editor.main'], () => resolve(window.monaco));
        })
    );
    return _monacoPromise;
}

// Language detection from file extension or content
function detectLanguage(content = '', filename = '') {
    const ext = filename.split('.').pop().toLowerCase();
    const extMap = {
        'js': 'javascript', 'jsx': 'javascript', 'mjs': 'javascript',
        'ts': 'typescript', 'tsx': 'typescript',
        'py': 'python', 'go': 'go', 'rs': 'rust', 'java': 'java',
        'c': 'c', 'cpp': 'cpp', 'css': 'css', 'scss': 'scss',
        'html': 'html', 'xml': 'xml', 'svg': 'xml',
        'json': 'json', 'yaml': 'yaml', 'yml': 'yaml',
        'sql': 'sql', 'sh': 'shell', 'bash': 'shell',
    };
    if (extMap[ext]) return extMap[ext];

    // Content-based fallback
    const t = content.trimStart();
    if (/^(import|export|const|let|var|function|class)\b/.test(t)) return 'typescript';
    if (/^(import |from |def |class )/.test(t)) return 'python';
    if (t.startsWith('{') || t.startsWith('[')) return 'json';
    return 'plaintext';
}

// Main editor component
function MonacoEditor() {
    const { content, saveContent, isReadOnly, fileName } = useCollimateFile();
    const containerRef = useRef(null);
    const editorRef = useRef(null);

    useEffect(() => {
        if (!containerRef.current) return;
        let editor;
        ensureMonaco().then(monaco => {
            editor = monaco.editor.create(containerRef.current, {
                value: content || '',
                language: detectLanguage(content, fileName),
                theme: 'vs-dark',
                readOnly: isReadOnly,
                automaticLayout: true,
                minimap: { enabled: false }
            });
            if (!isReadOnly) {
                editor.onDidChangeModelContent(() => saveContent(editor.getValue()));
            }
            editorRef.current = editor;
        });
        return () => { if (editor) editor.dispose(); };
    }, []);

    // Sync external content changes
    useEffect(() => {
        if (editorRef.current && editorRef.current.getValue() !== content) {
            editorRef.current.setValue(content || '');
        }
    }, [content]);

    return <div ref={containerRef} style={{ width: '100%', height: '100%', backgroundColor: '#1e1e1e' }} />;
}

// Diff editor component
function MonacoDiffEditor() {
    const { content, diffContent, fileName } = useCollimateFile();
    const containerRef = useRef(null);

    useEffect(() => {
        if (!containerRef.current) return;
        let diffEditor;
        ensureMonaco().then(monaco => {
            diffEditor = monaco.editor.createDiffEditor(containerRef.current, {
                theme: 'vs-dark',
                automaticLayout: true,
                renderSideBySide: true,
                readOnly: true
            });
            const lang = detectLanguage(content, fileName);
            diffEditor.setModel({
                original: monaco.editor.createModel(diffContent || '', lang),
                modified: monaco.editor.createModel(content || '', lang)
            });
        });
        return () => { if (diffEditor) diffEditor.dispose(); };
    }, [content, diffContent, fileName]);

    return <div ref={containerRef} style={{ width: '100%', height: '100%', backgroundColor: '#1e1e1e' }} />;
}

export default defineRenderer({
    component: MonacoEditor,
    diffComponent: MonacoDiffEditor
});
```

**Key takeaways:**
- Uses `embed: "iframe"` because Monaco manages its own DOM (needs full document context)
- Singleton promise pattern (`_monacoPromise`) prevents loading Monaco twice
- Cleanup function `editor.dispose()` prevents memory leaks
- Separate `diffComponent` provides side-by-side diff view
- External content changes synced via `useEffect` on `content`

### Example 4: HTML Preview (Iframe, React, Sibling File Loading)

Split-pane HTML renderer with Monaco editor (left) and live preview (right), resolving local asset references.

**main.tsx:**
```tsx
import React, { useEffect, useRef, useState } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

// ... (ensureMonaco() same as Monaco example above) ...

function HtmlEditor() {
    const { content, saveContent, isReadOnly, api } = useCollimateFile();
    const containerRef = useRef(null);
    const [previewHtml, setPreviewHtml] = useState('');

    // Resolve local asset references (./style.css, ./script.js) to blob URLs
    useEffect(() => {
        const process = async () => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(content, 'text/html');
            const elements = [...doc.querySelectorAll('[src], [href]')];

            for (const el of elements) {
                let url = el.getAttribute('src') || el.getAttribute('href');
                if (url && !url.startsWith('http') && !url.startsWith('data:') && !url.startsWith('#')) {
                    try {
                        const cleanPath = url.replace(/^\.\//, '');
                        const siblingContent = await api.getSiblingFile(cleanPath);
                        let mime = 'text/plain';
                        if (cleanPath.endsWith('.js')) mime = 'application/javascript';
                        else if (cleanPath.endsWith('.css')) mime = 'text/css';
                        else if (cleanPath.endsWith('.svg')) mime = 'image/svg+xml';

                        const blob = new Blob([siblingContent], { type: mime });
                        const blobUrl = URL.createObjectURL(blob);
                        if (el.hasAttribute('src')) el.setAttribute('src', blobUrl);
                        if (el.hasAttribute('href')) el.setAttribute('href', blobUrl);
                    } catch(e) {}
                }
            }
            setPreviewHtml(doc.documentElement.outerHTML);
        };
        process();
    }, [content, api]);

    // Monaco editor for editing HTML
    useEffect(() => {
        if (isReadOnly || !containerRef.current) return;
        let editor;
        ensureMonaco().then(monaco => {
            editor = monaco.editor.create(containerRef.current, {
                value: content,
                language: 'html',
                theme: 'vs-dark',
                automaticLayout: true,
                minimap: { enabled: false }
            });
            editor.onDidChangeModelContent(() => saveContent(editor.getValue()));
        });
        return () => { if (editor) editor.dispose(); };
    }, [isReadOnly]);

    return (
        <div style={{ display: 'flex', width: '100%', height: '100%', backgroundColor: '#1e1e1e' }}>
            {!isReadOnly && <div ref={containerRef} style={{ flex: 1, borderRight: '1px solid #333' }} />}
            <div style={{ flex: 1, backgroundColor: 'white', position: 'relative' }}>
                <iframe
                    srcDoc={previewHtml}
                    style={{ width: '100%', height: '100%', border: 'none' }}
                    sandbox="allow-scripts allow-forms allow-same-origin allow-popups"
                />
            </div>
        </div>
    );
}

export default defineRenderer({ component: HtmlEditor });
```

**Key takeaways:**
- `api.getSiblingFile()` fetches other files from the same cell (CSS, JS assets)
- Local references converted to blob URLs for the preview iframe
- `srcDoc` used instead of `src` for the preview iframe

### Example 5: Website Viewer (Native, React, No Edit)

A URL viewer with address bar. Renders `.website` files (which contain a URL string).

**main.tsx:**
```tsx
import React, { useState } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile } from '/api/sdk/react.js';

function WebsiteViewer() {
    const { content, saveContent, isReadOnly } = useCollimateFile();
    const [localUrl, setLocalUrl] = useState(content.trim());
    const [activeUrl, setActiveUrl] = useState(content.trim());

    const commit = () => {
        const u = localUrl.trim();
        saveContent(u);
        setActiveUrl(u);
    };

    return (
        <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: '#0a0b0d' }}>
            <div style={{
                height: 32,
                background: '#1a1c23',
                borderBottom: '1px solid #2a2d3a',
                display: 'flex',
                alignItems: 'center',
                padding: '0 8px',
                gap: 8,
                flexShrink: 0
            }}>
                <input
                    type="text"
                    value={localUrl}
                    onChange={e => setLocalUrl(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && commit()}
                    readOnly={isReadOnly}
                    placeholder="https://..."
                    style={{
                        flex: 1, height: 22,
                        background: '#0d0f14',
                        border: '1px solid #2a2d3a',
                        borderRadius: 4,
                        padding: '0 8px',
                        color: '#e2e8f0',
                        fontFamily: 'monospace',
                        fontSize: 11,
                        outline: 'none'
                    }}
                />
                {!isReadOnly && (
                    <button
                        onClick={commit}
                        style={{
                            height: 22, padding: '0 12px',
                            background: '#2d2f3e',
                            border: '1px solid #3a3d52',
                            borderRadius: 4,
                            color: '#e2e8f0',
                            fontFamily: 'monospace',
                            fontSize: 11,
                            cursor: 'pointer'
                        }}
                    >Go</button>
                )}
            </div>
            {activeUrl ? (
                <iframe
                    src={activeUrl}
                    style={{ flex: 1, width: '100%', border: 'none', background: 'white' }}
                    sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                />
            ) : (
                <div style={{
                    flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
                    color: '#4b5563', fontFamily: 'monospace', fontSize: 13
                }}>
                    Enter a URL above and press Enter
                </div>
            )}
        </div>
    );
}

export default defineRenderer({ component: WebsiteViewer });
```

**Key takeaways:**
- File content is just a URL string
- `saveContent()` only called on explicit "Go" action (not every keystroke)
- Empty state shows a placeholder message
- Native embed with all inline styles

### Example 6: Imperative editor (onSetContent + onFlush)

A renderer whose editor owns its own document model — here a tiny stand-in
for CodeMirror/Monaco/a rich-text engine that you mutate imperatively
rather than re-rendering from `content`. Because the editor isn't driven
by the `content` field, the automatic host-push behaviour doesn't reach
it, so this renderer wires `onSetContent` (follow a host content push in
place) and `onFlush` (commit a debounced edit on demand) itself. A
plain `content`-driven renderer (Examples 1–2) needs **none** of this.

**main.tsx:**
```tsx
import React, { useEffect, useRef } from 'https://esm.sh/react@18';
import { defineRenderer, useCollimateFile, useDebouncedSaveContent } from '/api/sdk/react.js';

function ImperativeEditor() {
    const { initialContent, saveContent, isReadOnly, api } = useCollimateFile();
    const editorRef = useRef(null);   // your real editor instance
    const hostRef = useRef(null);     // DOM node the editor mounts into
    const save = useDebouncedSaveContent(saveContent);

    // Mount the editor ONCE from initialContent. It owns its document
    // model from here — we never re-render it from `content`.
    useEffect(() => {
        const ed = createMyEditor(hostRef.current, initialContent, isReadOnly);
        editorRef.current = ed;
        // User edits → debounced save back to the workspace.
        const off = ed.onChange((text) => save(text));
        return () => { off(); ed.destroy(); };
    }, []);

    // Follow host content pushes (config-tag switch) in place — set the
    // editor's value WITHOUT calling saveContent/onChange: the host
    // already owns the value it handed us. Subscribing here is what turns
    // a tag switch from a remount-with-spinner into a seamless swap.
    useEffect(() => api.onSetContent?.((next) => {
        editorRef.current?.setValue(next);
    }), [api]);

    // Commit a pending debounced edit the instant the host asks (Save),
    // so the last keystroke can't be lost to the debounce window.
    useEffect(() => api.onFlush?.(() => save.flush()), [api, save]);

    return <div ref={hostRef} style={{ width: '100%', height: '100%' }} />;
}

export default defineRenderer({ component: ImperativeEditor });
```

**Key takeaways:**
- The editor is mounted once from `initialContent` and owns its document — `content` is intentionally not consumed.
- `onSetContent` applies a host push directly to the editor; never re-fire `onChange` from it.
- `onFlush` calls `save.flush()` so the modal's Save reads the freshest value.
- Both are optional and feature-detected (`api.onSetContent?.`) — older hosts simply remount instead.

## Styling Patterns

### Design tokens — `tokens` from `/api/sdk/react.js`

Prefer importing the `tokens` table over typing `var(--…)` strings or hex codes by hand. Every value resolves to a CSS custom property the host already exposes, so renderers stay theme-aware automatically when the user flips light/dark — no per-renderer wiring needed (CSS custom properties pierce shadow DOM by design).

```tsx
import {
    defineRenderer,
    tokens,
    useCollimateFile,
} from '/api/sdk/react.js';

function MyRenderer() {
    const { content, saveContent, isReadOnly } = useCollimateFile();
    return (
        <div style={{
            background: tokens.color.voidMain,
            color:      tokens.color.signalWhite,
            fontFamily: tokens.font.sans,
            borderRadius: tokens.radius.md,
            padding: 16,
        }}>
            …
        </div>
    );
}

export default defineRenderer({ component: MyRenderer });
```

What's in the table:

```ts
tokens.color = {
    // Brand colors — fixed across themes
    voidMain, obsidianPlate, filamentAmber, filamentHot,
    electricTeal, tungstenDim, signalWhite, commentGrey,
    // Theme-aware semantics — flip with light/dark
    muted, mutedForeground, destructive,
};
tokens.font   = { sans, mono };
tokens.radius = { sm, md, lg };
```

The values are `var(--…)` references rather than literal colors, which is also why you should *not* freeze them into snapshots, copy them into hex form, or pass them to libraries that expect concrete colors. For libraries that need a real color (e.g. Monaco's theme API), use `useTheme(api)` to get the current `'light' | 'dark'` scheme and pick a known color yourself.

`tokens` is `Object.freeze`'d so a buggy renderer can't mutate the table for every other renderer in the same shadow root.

### Dark Theme Color Palette (Used Across All Built-in Renderers)

These are the resolved values behind the `tokens.color.*` table when the host is in dark mode. Reach for them directly only when you can't use a token (e.g. when generating an HTML string fragment via `dangerouslySetInnerHTML` and want to inline a style attribute).

```
Background (darkest):  #0a0b0d
Background (panels):   #1a1c23
Background (inputs):   #0d0f14
Background (code):     #1f2937
Borders:               #2a2d3a
Text (primary):        #e2e8f0
Text (secondary):      #d1d5db
Text (muted):          #6b7280
Text (dimmer):         #4b5563
Accent (links):        #60a5fa
Accent (code):         #f59e0b
Headings:              #f9fafb
Dividers:              #374151
```

### Inline Style Object Patterns

**Full-bleed container:**
```typescript
style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: '#0a0b0d' }}
```

**Split pane (horizontal):**
```typescript
<div style={{ display: 'flex', width: '100%', height: '100%' }}>
    <div style={{ flex: 1, borderRight: '1px solid #2a2d3a' }}>Left</div>
    <div style={{ flex: 1 }}>Right</div>
</div>
```

**Status bar:**
```typescript
<div style={{
    height: 22,
    background: '#1a1c23',
    borderTop: '1px solid #2a2d3a',
    display: 'flex',
    alignItems: 'center',
    padding: '0 12px',
    gap: 12,
    fontFamily: 'monospace',
    fontSize: 10,
    color: '#6b7280'
}}>
```

**Monospace textarea:**
```typescript
<textarea style={{
    flex: 1,
    width: '100%',
    background: 'transparent',
    color: '#e2e8f0',
    fontFamily: 'monospace',
    fontSize: 13,
    lineHeight: 1.6,
    padding: 16,
    border: 'none',
    outline: 'none',
    resize: 'none'
}} />
```

### Injecting CSS (for Native Renderers That Need Classes)

If you must use CSS classes in a native renderer, inject them into the shadow root:

```typescript
function MyRenderer() {
    const { api } = useCollimateFile();

    useEffect(() => {
        api.injectStyle(`
            .my-container { display: flex; gap: 8px; }
            .my-button { background: #2d2f3e; color: white; border: none; padding: 4px 12px; }
            .my-button:hover { background: #3d3f4e; }
        `);
    }, []);

    return <div className="my-container">...</div>;
}
```

For external CSS (e.g., from a CDN):
```typescript
api.loadCSS('https://cdn.jsdelivr.net/npm/some-library/dist/styles.css');
```

## Loading External Libraries

### Pattern: CDN Script Loading with Singleton Promise

```typescript
const LIB_VERSION = '1.0.0';
const LIB_CDN = `https://cdn.jsdelivr.net/npm/my-lib@${LIB_VERSION}/dist/index.js`;

function loadScript(src) {
    return new Promise((resolve, reject) => {
        if (document.querySelector(`script[src="${src}"]`)) { resolve(); return; }
        const s = document.createElement('script');
        s.src = src;
        s.onload = resolve;
        s.onerror = () => reject(new Error(`Failed to load: ${src}`));
        document.head.appendChild(s);
    });
}

let _libPromise = null;
function ensureLib() {
    if (_libPromise) return _libPromise;
    _libPromise = loadScript(LIB_CDN).then(() => window.MyLib);
    return _libPromise;
}

// Usage in component:
useEffect(() => {
    ensureLib().then(lib => {
        // Use lib here
    });
}, []);
```

### Pattern: ESM Import from CDN

```typescript
import SomeLib from 'https://esm.sh/some-library@1.0.0';
```

## Hosting Modes: Native vs Iframe

### Native (`embed: "native"`)

- Renderer is mounted inside a Shadow DOM container in the main page
- **Pros**: Better performance, shared memory, no postMessage overhead
- **Cons**: CSS isolation via shadow root means only inline styles or injected CSS
- **Use for**: Simple renderers, text editors, status displays, URL viewers
- **All existing native renderers**: text, markdown, website

### Iframe (`embed: "iframe"`)

- Renderer is mounted inside a sandboxed iframe
- **Pros**: Full CSS support (classes, external sheets), complete DOM isolation
- **Cons**: Higher memory usage, postMessage-based communication
- **Use for**: Complex renderers needing external CSS libraries, security-sensitive content
- **All existing iframe renderers**: monaco, html, milkdown, excalidraw, react-diff

### How the Runtime Loads Your Renderer

1. Frontend fetches renderer source from `/api/renderers/{id}/source`
2. If entrypoint is `.tsx` or `.ts`, it's transpiled on-the-fly via Babel standalone
3. SDK import paths (`/api/sdk/react.js`) are rewritten to absolute URLs
4. The transpiled code is loaded as a dynamic ES module
5. `renderer.mount(containerElement, apiObject)` is called
6. On unmount, the cleanup function (if returned) is called

## Checklist for Creating a New Renderer

1. Create directory: `collimate-sdk/renderers/my_renderer/`
2. Write `manifest.rend_yaml` with id, name, version, entrypoint, embed mode, extensions
3. Write `main.tsx` (or `.ts`/`.js`)
4. Import React from `https://esm.sh/react@18` and SDK from `/api/sdk/react.js`
5. Create your component using `useCollimateFile()` hook
6. Export via `defineRenderer({ component: MyComponent })`
7. If supporting diff mode, add `diffComponent` to `defineRenderer()`
8. **If embed is "native"**: use ONLY inline styles, no className/Tailwind
9. **If embed is "iframe"**: any styling approach works
10. Ensure your root element is `width: 100%` and `height: 100%`
11. Handle both `isReadOnly === true` (viewer) and `isReadOnly === false` (editor) states
12. Call `saveContent()` to push edits back (not needed for read-only renderers)
13. Return a cleanup function from mount if your renderer allocates resources (editors, event listeners)
14. Compile-check before shipping: `collimate-check-renderer <your-renderer-dir>` (a real esbuild compile — catches JSX/TS/import errors offline). See [`testing-generators.md`](./testing-generators.md).

## Renderer Resolution Order

When a file needs to be displayed, the frontend picks a renderer using this priority:

1. **User preferences** - If the user has set a preferred renderer for this extension
2. **Extension match** - First renderer whose `extensions` array includes the file's extension
3. **Hardcoded fallbacks**:
   - `.md` -> milkdown (iframe)
   - `.txt`, `.log` -> text (native)
   - `.excalidraw` -> excalidraw (iframe)
   - Everything else -> monaco (iframe)

If your renderer has `extensions: []` (empty), it will only be used when explicitly selected by the user or referenced by name in the code.

### Pointer-File Renderers (`.website`, `.terminal`)

A few built-in renderers dispatch on files whose contents are a small JSON or text *pointer* rather than the thing to display. The renderer opens an iframe or WebSocket against the pointer's target at mount time.

| Extension | Renderer | Pointer contents | Generator API |
|---|---|---|---|
| `.website` | `website` (native) | Proxy URL path, e.g. `/proxy/{channel}/{run_id}/{port}/` | `gen.serve_port()` |
| `.terminal` | `terminal` (native, xterm.js) | JSON `{"session_id","ws_path","token","label"}` (+ optional `"buttons"`) written as a single file | `gen.serve_terminal()` (or `gen.terminal()` + `collimate.pointers.terminal_pointer`) |

On the generator side `gen.serve_terminal(...)` writes, pins, and tears the pointer down for you; `gen.update_file("preview.website", "/proxy/...")` + `gen.update()` covers the website case. The renderer handles the WebSocket upgrade, PTY lifecycle, and reconnects entirely on the frontend side — via the session-socket module below.

Writing a custom renderer that claims `.terminal` or `.website` is possible but rarely useful — prefer a new extension for your own pointer format.

### Session sockets — `/api/sdk/session.js`

If your renderer opens a WebSocket against a host session (a custom pointer format, a live stream from a daemon generator), **do not hand-roll the connection lifecycle**. The platform serves a framework-free module with the one canonical reconnect state machine, and every built-in live renderer (terminal, assistant, webview) is built on it:

```tsx
import { openSessionSocket, sessionWsUrl, isSessionDead, clearDeadSession }
    from '/api/sdk/session.js';

const sock = openSessionSocket({
    // Always build the URL with sessionWsUrl — it resolves against the API
    // origin (split-origin aware), not the page origin.
    url: sessionWsUrl(api, pointer.ws_path, pointer.token),
    // With sessionId set, a session the server declared gone (close 4404/4401)
    // is remembered module-wide: remounts render "ended" instead of redialing
    // forever. Check isSessionDead(id) before building expensive per-session
    // state; call clearDeadSession(id) (or sock.redial()) on an explicit
    // user Reconnect.
    sessionId: pointer.session_id,
    binaryType: 'arraybuffer',            // for binary streams (PTY bytes)
    onStatus: (st) => { /* 'connecting' | 'open' | 'closed' | 'busy' | 'ended' */ },
    onOpen:   (ws) => { /* reset per-connection state, push initial size, … */ },
    onMessage: (ev) => { /* your frame reducer — the only part you own */ },
});
sock.sendJson({ t: 'resize', cols, rows });  // OPEN-guarded; returns false when not open
sock.close();                                 // in your unmount cleanup — final, no redial
```

The close-code policy is centralized and matches the host contract: **4401/4404** (session gone — run stopped, server restarted) end the socket for good and mark the session dead; **4409** (another mounted view holds the single-attach session) polls slowly to take over when the holder unmounts; anything else retries with backoff. Tune per surface without re-implementing the machine:

| Option | Default | Use |
|---|---|---|
| `transientRetryMs` | `min(500·attempt, 5000)` backoff | `false` for stateful single-attach sessions (a PTY) where reconnects must be an explicit user action; a fixed number for simple streams. |
| `busyRetryMs` | `5000` | `false` to park on `'busy'` instead of polling for takeover. |
| `maxFailedOpens` | unlimited | Give up (`'ended'`) after N dials that never opened — for proxied endpoints with no close-code contract, where repeated failure to open means the run is gone. |

The module is deliberately **framework-free**: unlike `/api/sdk/react.js` (which pins React 18) it can be imported by a renderer that pins its own React version, or none at all. Spec + npm artifact: `@collimate/renderer-hooks/session`.
