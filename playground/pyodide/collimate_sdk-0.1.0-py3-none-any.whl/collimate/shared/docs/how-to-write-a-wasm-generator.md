# How to write a WASM generator

WASM generators run inside the browser. The Collimate playground build compiles the FastAPI backend to WebAssembly via Pyodide and loads it on the page — no server, no subprocess, no Docker. Generators are imported and called **directly in the same Python event loop as the host**.

The runtime API is a single top-level package: **`gen`**. A generator imports it and calls `gen.*` to read inputs, stage output files, push cells, request user input, and resolve API keys. There is no `ctx` argument — the host hydrates the `gen` singleton before calling `run()`.

WASM generators live under `generators/WASM/` and never mix with the native `generators/Standard/` tree. This doc is the full contract; it is also loaded at runtime as the system prompt for the `wasm-generator-builder` scaffolding agent, so style and idioms here are reflected in every generator the LLM produces.

---

## 1. File layout

One generator = one directory:

```
generators/WASM/my-gen/
├── manifest.gen_yaml          # identity + schema (required)
├── my_gen.py                  # the run() function (required)
└── pydantic-config.set_yaml   # optional draft file for user-editable knobs
```

The host imports `my_gen.py` via `importlib` and calls `run()` (no arguments).

---

## 2. Minimal generator

```python
# my_gen.py
import gen

async def run():
    name = gen.config("pydantic-config.set_yaml").get("name", "world")
    gen.update_file("greeting.md", f"# Hello {name}\n")
    await gen.update(name="Greeting", summary=f"Greeted {name}")
```

```yaml
# manifest.gen_yaml
id: "wasm-hello"
name: "Hello"
category: "tools"
version: "0.1.0"
summary: "Write a greeting file."
entrypoint: "my_gen.py"
runtime: "wasm"
prompt_intent: "Who to greet"

inputs:
  cells:
    min: 0
    max: 0
```

That's the whole contract.

---

## 3. The `run()` contract

```python
async def run() -> None: ...   # canonical
def run() -> None: ...         # also accepted for trivial cases
```

The function takes **no arguments**. The host hydrates the `gen` singleton with the run's state before calling it. Returning produces an empty placeholder cell **unless** the generator called `gen.update()` at least once — by design.

`async def` is strongly preferred. Pyodide runs on a single thread; `asyncio.to_thread` parks forever, so any blocking I/O has to be cooperatively scheduled.

### Cancellation

```python
if gen.cancelled:
    return  # or: break out of a loop
```

`gen.cancelled` flips to True when the user clicks Stop. Long-running generators should poll it between chunks of work.

---

## 4. Manifest fields

```yaml
id: "wasm-my-gen"           # unique, lowercase, hyphenated
name: "My Generator"         # display name in picker
category: "tools"            # chat | iterate | widen | narrow | tools
version: "0.1.0"
summary: "One-line description for the picker."
entrypoint: "my_gen.py"
runtime: "wasm"              # required: "wasm" (or "both")

prompt_intent: "What the user types into the picker textarea"

# Whether this is a chat-shaped (long-lived, conversational) run.
# Default: false. Set to true for daemon-style generators that loop
# over user messages via `gen.chat_loop()`. The runtime infers Stop
# semantics, picker routing, log-drawer behaviour, and history
# persistence from this one bit.
chat: false

# Optional: files seeded into .colreserved/config/files/ before the
# run. The picker renders a form from any .set_yaml schema; the user
# fills it, the run starts.
draft_files:
  - "pydantic-config.set_yaml"

# Which draft file the Draft cell editor opens first (only relevant
# when default_route: "draft"). Optional.
summary_file: "pydantic-config.set_yaml"

# "run" (default with draft_files): picker submits straight to the
#   run; user never sees a Draft cell.
# "draft": picker creates a persisted Draft cell on the canvas; the
#   user opens it, may edit multiple files, then clicks Run there.
default_route: "run"

# Bounds on the number of input cells the user attaches.
inputs:
  cells:
    min: 0       # 0 = optional inputs
    max: 1       # set higher for fan-in generators (e.g. merge)
```

That's the entire schema. Anything else is ignored (and lints as an unknown field).

### Removed fields

The following used to exist and are no longer accepted:

- `execution_mode`, `live_chat_mode` — replaced by `chat: true|false`.
- `live_files_mode` — mid-run file editing is native-only.
- `output_mode` — runtime infers cell shape from `gen.update` / `gen.create_stack_cell` calls.
- `summary_artifact` — now a per-call argument to `gen.update(...)` / `gen.create_stack_cell(...)`.
- `keys` — key resolution is live (`gen.api_key`); no pre-flight gate.
- `parameters`, `pickoptions_file`, `settings_file`, `auto_dismiss_log` — superseded by `draft_files` + the new SDK.

Old manifests still load with deprecation warnings during the migration window; new generators must not declare them.

---

## 5. Settings schema (`.set_yaml`)

Generators that need user-editable knobs ship a draft file with a schema-form layout:

```yaml
# pydantic-config.set_yaml
fields:
  - key: provider
    type: dropdown
    label: Provider
    description: Which LLM provider to call (only CORS-safe providers work in the browser).
    default: cerebras
    options:
      - { value: cerebras, label: Cerebras }
      - { value: groq,     label: Groq     }
      - { value: openrouter, label: OpenRouter }

  - key: model
    type: text
    label: Model
    description: Provider-specific model name. Cerebras uses `llama3.1-8b`, Groq uses `openai/gpt-oss-20b`, etc.
    default: "llama3.1-8b"

  - key: max_tokens
    type: number
    label: Max output tokens
    default: 2048
    min: 256
    max: 16384

  - key: system_prompt
    type: textarea
    label: System prompt
    default: "You are a concise assistant."
```

Generators read this back with one line:

```python
cfg = gen.config("pydantic-config.set_yaml")
provider = cfg.get("provider", "cerebras")
system_prompt = cfg.get("system_prompt", "")
```

`gen.config(name)` auto-detects by extension: `.set_yaml` / `.yaml` / `.yml` parse as YAML and merge `fields:` defaults with the `values:` block (which the picker writes when the user edits the form). `.json` parses as JSON. Anything else returns the raw string.

### Field types

| Type | Purpose | Type-specific options |
|---|---|---|
| `text` | single-line input | `placeholder`, `multiline` |
| `textarea` | multi-line input | (same as text) |
| `number` | numeric input | `min`, `max`, `step`, `widget: slider` |
| `dropdown` | enum selection | `options: [{value, label, description}]` |
| `bool` | true/false | — |

Every field accepts: `key`, `label`, `description`, `default`, `advanced` (collapse under "Advanced" expander), `show_when` (conditional visibility — `{earlierFieldKey: expectedValue}`).

---

## 6. The `gen.*` core surface

These are always available and have no LLM dependency. A pure-Python generator (no API keys, no model) uses only these.

### Inputs

```python
gen.prompt              # str — the picker textarea text
gen.messages            # list[Message] — prior chat history from input cells
gen.cancelled           # bool — Stop button check (poll between chunks)
```

### Reading input cell files

```python
gen.read_input(path)    # str — read one input file
gen.input_files()       # dict[str, str] — every input file as {relpath: content}
gen.input_groups()      # dict[str, dict[str, str]] — files split by source cell
                        #   single input  → {"input": {...}}
                        #   multi-input   → {"00_label": {...}, "01_other": {...}}
                        #   paths in each group are relative to the cell root
```

### Reading draft / config files

```python
gen.config(name)        # YAML / JSON / raw, by extension
```

### Output stage (file I/O on the cell being written)

The stage starts pre-populated with every input file, so reads "just work" and unwritten input files carry forward to the placeholder.

```python
gen.update_file(path, content)  # stage a write
gen.read_file(path)             # read from stage (input + own writes)
gen.has_file(path)              # collision predicate
gen.list_files()                # sorted staged paths
gen.delete_file(path)            # drop from stage (e.g. don't carry forward)
```

### Cell operations — two only

```python
await gen.update(*, name=None, summary=None, summary_artifact=None)
await gen.create_stack_cell(name, *, summary=None, summary_artifact=None, files=None)
```

`gen.update()` flushes the current stage (files + chat history) to the placeholder/top cell. **May be called many times during a run** — each call refreshes the visible cell live; the host debounces persistence. The last call before return is the final state.

Calling `update_file()` without ever calling `update()` produces an empty placeholder. Explicit by design.

`gen.create_stack_cell(name, ...)` adds a new cell **below in the right-side stack**. Used by fan-out generators (e.g. `seed-ideas`) to create N siblings while the placeholder holds an index. If `files` is omitted, it snapshots the current stage.

There is no `update_cell(cell_id, ...)` escape hatch. Generators that want to "modify an input cell" carry input files forward to their placeholder and modify them there.

### Chat history

```python
gen.history.append(role, content)   # role: "user" | "assistant"
gen.history.as_pai()                # translate to pydantic_ai ModelMessage
list(gen.history)                   # iterate (read-only)
```

`history.append()` mutates the in-memory list and marks dirty; the next `gen.update()` flushes it to `.colreserved/.collimate_messages.json` as a memory artifact.

### User input mid-run

```python
async for user_msg in gen.chat_loop():
    # Body runs once per turn. Yields gen.prompt first (if non-empty),
    # then blocks on the user's chat input. Loop exits cleanly on Stop.
    ...

await gen.next_message()    # str | None — one-off polling outside chat_loop
```

### Secrets

```python
await gen.api_key(provider, *, force=False, description="")
# Resolves the API key for "cerebras"/"groq"/"openrouter" and sets the
# standard env var (CEREBRAS_API_KEY etc.) so pydantic_ai's native
# provider lookup picks it up. Pops the in-cell modal when the env
# isn't set. force=True skips the env-var fast path — for auth-retry
# after a 401. Raises gen.Cancelled when the user cancels the modal.

await gen.secret(name, *, prompt_if_missing=False, description="")
# Escape hatch for non-LLM secrets (webhook tokens, custom service
# keys, …). Default: env-var fast path only — empty string when not
# set. prompt_if_missing=True opts into the modal flow.
```

### Status / logging

```python
gen.log(line)           # append to the run log (visible in the events panel)
gen.status(msg)         # set the live status string next to the run row
```

### Exceptions

```python
gen.Cancelled           # raised by api_key / secret on user-cancel
```

---

## 7. The LLM convenience tier (opt-in sugar)

These are the only entries that import `pydantic_ai`. Importing them lazily triggers `ensure_pydantic_ai()` (micropip install + jiter stub + pyfetch transport patch). A non-LLM generator never touches these and never pays the install cost.

```python
agent_obj = await gen.agent(
    *,
    system_prompt="",
    tools=None,
    output_type=None,
    provider=None, model=None, max_tokens=None,  # override pydantic-config.set_yaml
    config_file="pydantic-config.set_yaml",
)
# Reads provider/model/max_tokens from the config file when not
# overridden, calls gen.api_key() to resolve the key, and returns a
# vanilla pydantic_ai.Agent. Call .run() / .run_stream() on it
# directly — we deliberately don't wrap pydantic_ai's surface.

tools = gen.file_tools()
# Returns list/read/write/edit pydantic_ai Tool objects bound to the
# output stage. read_file / list_files see input-cell files (the stage
# is pre-populated); write_file / edit_file mutate the stage so the
# next gen.update() call reflects the agent's edits.

await gen.bootstrap()
# Call this if you `import pydantic_ai` directly at module top level.
# gen.agent / gen.file_tools call it for you, so most generators don't
# need to.
```

### Provider constraint

Only **CORS-safe providers** work in the browser: `cerebras`, `groq`, `openrouter`. Anthropic / OpenAI / Gemini direct endpoints reject browser-origin CORS. Use those through the native runtime, not WASM.

---

## 8. Worked examples

### Example A — pure Python, no LLM (the `merge` generator)

```python
"""Union 2+ input cells into one output cell. Topmost wins on collisions."""
import gen

async def run():
    rows: list[str] = []
    for label, cell_files in gen.input_groups().items():
        rows.append(f"- **{label}**: {len(cell_files)} files")
        for path, content in cell_files.items():
            if not gen.has_file(path):
                gen.update_file(path, content)

    gen.update_file("_merge.md", "# Merge\n\n" + "\n".join(rows) + "\n")
    await gen.update(name="merged", summary=f"merged {len(gen.input_groups())} cells",
                     summary_artifact="_merge.md")
```

Manifest:
```yaml
id: "wasm-merge"
name: "Merge"
category: "tools"
version: "0.1.0"
summary: "Union 2+ input cells. Topmost wins on filename collisions. No LLM."
entrypoint: "merge.py"
runtime: "wasm"
inputs:
  cells:
    min: 2
    max: 99
```

### Example B — single-shot LLM agent (modify-files-style)

```python
"""Run an agent over the input cell's files. Carries unedited files forward."""
import gen

async def run():
    cfg = gen.config("pydantic-config.set_yaml")
    if not gen.prompt.strip():
        gen.update_file("error.md", "# No prompt\n\nDescribe what to do.\n")
        await gen.update(summary="empty prompt")
        return

    agent_obj = await gen.agent(
        system_prompt=cfg.get("system_prompt", "")
            + "\n\nEdit files using the read/write/edit tools. "
              "Leave unrelated files alone.",
        tools=gen.file_tools(),
    )

    result = await agent_obj.run(gen.prompt)
    gen.update_file("answer.md", str(result.output))
    await gen.update(summary=str(result.output)[:120])
```

### Example C — daemon chat (live-chat-style)

```python
"""Multi-turn chat with file tools. Stop ends the conversation."""
import gen

async def run():
    cfg = gen.config("pydantic-config.set_yaml")
    agent_obj = await gen.agent(
        system_prompt=cfg.get("system_prompt", ""),
        tools=gen.file_tools(),
    )

    async for user_msg in gen.chat_loop():
        gen.history.append("user", user_msg)
        await gen.update()  # show the user message immediately

        try:
            result = await agent_obj.run(
                user_msg, message_history=gen.history.as_pai()
            )
            answer = str(result.output) or "_(empty response)_"
        except Exception as e:
            answer = f"**Error:** `{e}`"

        gen.history.append("assistant", answer)
        await gen.update()  # show the assistant turn
```

Manifest needs `chat: true`:
```yaml
id: "wasm-live-chat"
name: "Live Chat"
category: "chat"
version: "0.1.0"
summary: "Multi-turn pydantic-ai chat with read/write/edit file tools."
entrypoint: "live_chat.py"
runtime: "wasm"
prompt_intent: "First message to the agent"
chat: true
draft_files:
  - "pydantic-config.set_yaml"
inputs:
  cells:
    min: 0
    max: 1
```

---

## 9. Pyodide constraints

Things you cannot do in WASM:

- **No threads.** Pyodide's threading module is a stub. `anyio.to_thread.run_sync`, `concurrent.futures`, `subprocess`, `multiprocessing` all raise `RuntimeError: can't start new thread`. Sync `pydantic_ai` tools fall in this trap; that's why `gen.file_tools()` returns async tools.
- **No raw sockets.** `urllib`, `requests`, `httpx` over raw sockets all fail. Use `pyodide.http.pyfetch`. `gen.agent()` configures pydantic_ai to route through `pyfetch` transparently.
- **No subprocess.** No `uv run`, no `os.system`, no Docker. Everything happens in this one Python event loop.
- **CORS-locked HTTP.** Only browser-CORS-safe providers (Cerebras, Groq, OpenRouter) work. Don't try Anthropic, OpenAI, or Gemini direct endpoints.
- **No arbitrary `micropip.install`.** The playground preloads a fixed package set; `gen.bootstrap()` knows how to add `pydantic-ai-slim[openai]`. Other packages may or may not have emscripten wheels.

---

## 10. WASM-vs-native gaps

WASM intentionally has fewer knobs than the native SDK. If your generator needs any of these, target the native runtime:

- **Mid-run file editing** — the native SDK lets the user edit cell files while a run is in flight (`live_files_mode: live_files`). WASM does not.
- **Unlocked chat history** — the native SDK supports re-running from an earlier turn by editing prior messages (`live_chat_mode: unlocked_history`). WASM only supports append-only chat.
- **Docker / sandboxes** — the native SDK can spawn Docker containers (`gen.chat.start_session(image=...)`). WASM cannot.
- **Server-only LLM providers** — Anthropic, OpenAI, Gemini direct endpoints work natively but not in the browser (CORS).

These are runtime-capability limits, not SDK design choices. The `gen.*` API surface is otherwise designed to be uniform across both runtimes; a future native sweep will mirror it.

