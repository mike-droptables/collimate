# Testing generators and renderers (host-free)

You can run a generator and inspect what it produced **without the app**,
and compile-check a renderer **without a browser**. Same iteration loop the
builder agents use to self-validate.

## Run a generator — `collimate.testing.run_generator`

```python
from collimate.testing import run_generator

res = run_generator(
    "generators/merge/merge.py",
    input_groups={"00_a": {"x.txt": "A"}, "01_b": {"y.txt": "B"}},
    # also: inputs={...}, config={"pydantic-config.set_yaml": {...}},
    # prompt="...", invocation_type="explore", secrets={"ANTHROPIC_API_KEY": "..."},
    # messages=["hi", "bye"], timeout=60.0,
)
assert res.ok, res.error
assert "x.txt" in res.files          # final output-cell files
assert res.name                       # last update()/final cell name
```

It runs the generator **in the current process** against a recording bridge
(no IPC peer) and returns a single `GeneratorResult`:

| field | meaning |
|---|---|
| `ok` | did the run finish without raising? |
| `files` | `{path: str\|bytes}` — the final output-cell files |
| `name` / `summary` | from the last `gen.update()` / final cell |
| `cells` | every `gen.update()` + `gen.create_stack_cell()` as a `CellRecord` |
| `endpoints` | ports/terminals a daemon bound (`Endpoint`) |
| `tier_b_calls` | recorded `serve_port` / `terminal` / subprocess calls |
| `logs` / `status` | `gen.log` lines / last `gen.status` |
| `error` / `traceback` | failure detail when `not ok` |

`res.raise_for_status()` raises if the run failed.

`run_generator_callable(run_fn, ...)` is the same for an already-imported
`run` coroutine/function (no entrypoint file).

### Daemons and Tier B

Daemon generators (those that call `gen.serve_port()` / `gen.terminal()`
and loop on `gen.cancelled`) are validated **structurally**: the harness
records the call into `tier_b_calls` / `endpoints` and then flips
`gen.cancelled` so the loop exits — it does not actually bind a port or
start a container.

```python
res = run_generator("generators/my_daemon/run.py")
assert any(c["op"] == "serve_port" for c in res.tier_b_calls)
assert any(e.kind == "http" for e in res.endpoints)
```

One-shot subprocesses (`gen.python_tool`, `gen.run_subprocess`) **do**
execute. Async runs are bounded by `timeout` (seconds).

**Limitation:** the in-process backend only imports packages already in the
current interpreter. A generator whose PEP 723 block pulls in an
uninstalled dependency fails at import — install it in your test env, or run
the generator in the app (which resolves deps via `uv`). Secrets/keys come
from the `secrets=` dict (a missing key ends the run as a graceful stop, not
a crash).

## Compile-check a renderer — `collimate-check-renderer`

Renderers compile in the browser at runtime, so author mistakes (JSX / TS /
bad imports) otherwise surface only when the cell is opened. The
`collimate-check-renderer` CLI runs the same esbuild compile offline:

```bash
node scripts/check_renderer.mjs renderers/basic/text     # one
node scripts/check_renderer.mjs renderers/basic/*        # all
collimate-check-renderer path/to/my_renderer --json      # machine-readable
```

It transpiles + bundles the entrypoint (stubbing the SDK, React, and any
`https://` CDN import) and asserts the default export is a
`defineRenderer(...)` result exposing a `component`. Exit 0 when every
renderer compiles, else 1. (Manifest schema validation proper is
`collimate-lint`; this checks the code.)

## In CI / pytest

`pytest` exercises both: `tests/test_testing_harness.py` runs real bundled
generators through `run_generator`, and `tests/test_check_renderer.py` runs
the renderer compile check over every bundled renderer (skipped when Node /
esbuild aren't available).

## Composition (in-app)

The same "run a generator → `GeneratorResult`" abstraction is also the
*in-app* composition API: `gen.call` / `gen.spawn` / `gen.generators` run
another generator via the host (real isolation + dependency resolution).
See the "Composition" section of
[`how-to-write-a-generator.md`](./how-to-write-a-generator.md). In tests,
`RecordingBridge.stub_sub_run` runs those children in-process — the default
delegates an inline source straight to `run_generator`, so composition and
host-free testing are literally the same execution path.

### Environments

The environment surface is testable host-free from both sides (no Docker).

**A worker that drives an environment** — stub the child's exec + capabilities;
the workspace plane round-trips through an in-memory per-sub-run dict:

```python
from collimate import native
from collimate._results import EnvironmentSpec, GeneratorResult

def test_worker(native_bridge):
    native_bridge.stub_sub_run(lambda src, kw: GeneratorResult(ok=True))
    native_bridge.stub_sub_run_exec(lambda sid, cmd, kw: (0, "ran " + " ".join(cmd)))
    # optional: native_bridge.stub_sub_run_capabilities(EnvironmentSpec(terminals=2))

    async def parent():
        async with native.spawn("linux-env") as env:
            assert (await env.capabilities()).exec        # core env once exec is stubbed
            await env.put_files({"a.py": "x = 1"})
            assert await env.read_file("a.py") == "x = 1"  # workspace round-trips
            rc, out = await env.exec(["pytest"])
            assert rc == 0
    import asyncio; asyncio.run(parent())
```

**An environment's `serve_environment` loop** — seed `env_requests`; read the
replies back from `res.tier_b_calls`:

```python
from collimate.testing import run_generator_callable

async def env_run():
    import gen
    await gen.serve_environment(on_exec=lambda r: (0, "ran " + " ".join(r.command)))

res = run_generator_callable(env_run, env_requests=[
    {"request_id": "r1", "kind": "exec", "command": ["echo", "hi"]},
])
reply = next(c["result"] for c in res.tier_b_calls if c["op"] == "serve_environment_reply")
assert reply["rc"] == 0 and reply["output"] == "ran echo hi"
```

The `_env_shared.DockerEnvironment` helper itself needs a real container —
validate it with `scripts/env_validate.py` (Docker required), not host-free.

