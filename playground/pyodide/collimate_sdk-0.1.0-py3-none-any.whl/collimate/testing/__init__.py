# SPDX-License-Identifier: Apache-2.0
"""Host-free run engine for generators — the in-process backend of the
"run a generator → :class:`GeneratorResult`" contract.

This package executes a generator **in the current Python process** against
a :class:`~collimate.testing._bridge.RecordingBridge` (no IPC peer, no
host), capturing what the run produced. It's for pytest / CI / local SDK
iteration. The *real*, isolated, dependency-installing backend is the host
sub-run (``gen.spawn`` / ``gen.call``) — same :class:`GeneratorResult`.

Quick start::

    from collimate.testing import run_generator
    res = run_generator(
        "generators/merge/merge.py",
        input_groups={"00_a": {"x.txt": "A"}, "01_b": {"y.txt": "B"}},
    )
    assert res.ok
    assert "x.txt" in res.files

Limitation: the in-process backend can only import packages already
installed in the current interpreter. A generator whose PEP 723 block pulls
in an uninstalled dependency fails at import — install it in the test env,
or run the generator in the app (host backend) for full dependency
resolution.
"""
from __future__ import annotations

import asyncio
import importlib
import importlib.util
import itertools
import json
import os
import sys
import tempfile
import traceback
from contextlib import contextmanager
from typing import Optional

from collimate._results import (
    CellRecord,
    Endpoint,
    GeneratorInfo,
    GeneratorResult,
)
from collimate.testing._bridge import RecordingBridge

__all__ = [
    "CellRecord",
    "Endpoint",
    "GeneratorInfo",
    "GeneratorResult",
    "RecordingBridge",
    "make_test_bridge",
    "run_generator",
    "run_generator_callable",
]

_modname_counter = itertools.count(1)


@contextmanager
def _native_gen_shim():
    """Ensure the top-level ``gen`` shim routes to the native runtime for
    the duration of a host-free run.

    The shim picks its backend (native vs wasm) from ``COLLIMATE_RUNTIME``
    at import time, so a wasm-runtime test elsewhere in the session can
    leave the cached ``gen`` module wasm-routed. The host-free harness IS
    the native runtime, so force native: set the env var (covers a
    not-yet-imported ``gen``) and reload an already-imported wasm-routed
    shim. The env var is restored on exit; a native-routed ``gen`` left
    behind is harmless (native is the default)."""
    prev = os.environ.get("COLLIMATE_RUNTIME")
    os.environ["COLLIMATE_RUNTIME"] = "native"
    g = sys.modules.get("gen")
    if g is not None and getattr(g, "_RUNTIME", "native") != "native":
        importlib.reload(g)
    try:
        yield
    finally:
        if prev is None:
            os.environ.pop("COLLIMATE_RUNTIME", None)
        else:
            os.environ["COLLIMATE_RUNTIME"] = prev


# ---------------------------------------------------------------------------
# Bridge factory (single construction path; tests/conftest delegate here)
# ---------------------------------------------------------------------------


def make_test_bridge(
    workspace,
    *,
    prompt: str = "",
    invocation_type: str = "",
    params: Optional[dict] = None,
    secrets: Optional[dict] = None,
    messages: Optional[list] = None,
    env_requests: Optional[list] = None,
) -> RecordingBridge:
    """Build a :class:`RecordingBridge` rooted at ``workspace`` without an
    IPC peer. The one bridge-construction path — ``tests/conftest.py``
    delegates here. ``env_requests`` seeds parent→environment requests for
    testing a generator's ``gen.serve_environment`` loop."""
    return RecordingBridge.create(
        str(workspace),
        prompt=prompt,
        invocation_type=invocation_type,
        params=params,
        secrets=secrets,
        messages=messages,
        env_requests=env_requests,
    )


# ---------------------------------------------------------------------------
# Workspace seeding
# ---------------------------------------------------------------------------


def _write_raw(ws: str, relpath: str, content) -> None:
    full = os.path.join(ws, relpath)
    os.makedirs(os.path.dirname(full) or ws, exist_ok=True)
    if isinstance(content, bytes):
        with open(full, "wb") as fh:
            fh.write(content)
    else:
        with open(full, "w", encoding="utf-8") as fh:
            fh.write(content if isinstance(content, str) else str(content))


def _write_config(cfg_dir: str, name: str, values) -> None:
    full = os.path.join(cfg_dir, name)
    os.makedirs(os.path.dirname(full) or cfg_dir, exist_ok=True)
    if name.lower().endswith(".json"):
        content = json.dumps(values)
    else:
        import yaml  # bridge.config parses a plain YAML map straight through

        content = yaml.safe_dump(values if isinstance(values, dict) else {})
    with open(full, "w", encoding="utf-8") as fh:
        fh.write(content)


def _seed_workspace(ws, inputs, input_groups, config, prompt) -> None:
    os.makedirs(os.path.join(ws, ".colreserved"), exist_ok=True)
    with open(os.path.join(ws, ".colreserved", "prompt.md"), "w", encoding="utf-8") as fh:
        fh.write(prompt or "")
    for path, content in (inputs or {}).items():
        _write_raw(ws, path, content)
    for label, files in (input_groups or {}).items():
        for path, content in (files or {}).items():
            _write_raw(ws, os.path.join("inputs", label, path), content)
    if config:
        cfg_dir = os.path.join(ws, ".colreserved", "config", "files")
        os.makedirs(cfg_dir, exist_ok=True)
        for name, values in config.items():
            _write_config(cfg_dir, name, values)


# ---------------------------------------------------------------------------
# Execution
# ---------------------------------------------------------------------------


def _build_result(bridge: RecordingBridge, *, ok: bool, error=None, tb=None) -> GeneratorResult:
    files: dict = {}
    for p in bridge.fs_list():
        try:
            files[p] = bridge.fs_read_any(p)
        except OSError:
            continue
    name = summary = None
    for c in reversed(bridge._rec_cells):
        if c.kind == "update":
            name, summary = c.name, c.summary
            break
    if name is None and bridge._rec_cells:
        name, summary = bridge._rec_cells[-1].name, bridge._rec_cells[-1].summary
    return GeneratorResult(
        ok=ok,
        files=files,
        name=name,
        summary=summary,
        cells=list(bridge._rec_cells),
        endpoints=list(bridge._rec_endpoints),
        tier_b_calls=list(bridge._rec_tier_b),
        logs=list(bridge._rec_logs),
        status=bridge._rec_status,
        error=error,
        traceback=tb,
    )


def _execute(run_fn, bridge: RecordingBridge, timeout: Optional[float]) -> GeneratorResult:
    """Run ``run_fn`` under ``bridge`` (singleton-swapped), mirroring
    ``native.main``'s dispatch + auto-flush, into a GeneratorResult."""
    from collimate import native
    from collimate._host import _StopRequested
    from collimate.host_protocol import Cancelled

    prev = native._bridge
    native._set_bridge(bridge)
    ok, error, tb = True, None, None
    try:
        if asyncio.iscoroutinefunction(run_fn):
            if timeout is None:
                asyncio.run(run_fn())
            else:
                asyncio.run(asyncio.wait_for(run_fn(), timeout))
        else:
            run_fn()
        # Auto-flush trailing writes, exactly like native.main.
        if bridge.tracked_writes or bridge.tracked_deletions:
            deleted = sorted(bridge.tracked_deletions) or None
            bridge.tracked_deletions.clear()
            bridge.update_cell(deleted_files=deleted)
    except (Cancelled, _StopRequested):
        ok, error = False, "Stopped by user"
    except asyncio.TimeoutError:
        ok, error = False, f"timed out after {timeout}s"
    except BaseException as exc:  # noqa: BLE001 — report any failure as a result
        ok = False
        error = str(exc) or exc.__class__.__name__
        tb = traceback.format_exc()
    finally:
        native._set_bridge(prev)
    return _build_result(bridge, ok=ok, error=error, tb=tb)


def run_generator_callable(
    run_fn,
    *,
    inputs: Optional[dict] = None,
    input_groups: Optional[dict] = None,
    config: Optional[dict] = None,
    prompt: str = "",
    invocation_type: str = "",
    secrets: Optional[dict] = None,
    messages: Optional[list] = None,
    env_requests: Optional[list] = None,
    workspace=None,
    timeout: Optional[float] = 60.0,
) -> GeneratorResult:
    """Run an already-imported ``run`` coroutine/function host-free.

    Lower-level than :func:`run_generator` (which imports an entrypoint
    file first). Useful when you hold the callable directly. ``env_requests``
    seeds parent→environment requests for a ``gen.serve_environment`` loop."""
    own_ws = workspace is None
    tmp = tempfile.TemporaryDirectory(prefix="colgen-") if own_ws else None
    ws = tmp.name if tmp is not None else str(workspace)
    bridge = None
    try:
        try:
            _seed_workspace(ws, inputs, input_groups, config, prompt)
        except Exception as exc:  # noqa: BLE001 — always return a result
            return GeneratorResult(ok=False, error=f"workspace seeding failed: {exc}",
                                   traceback=traceback.format_exc())
        bridge = make_test_bridge(
            ws, prompt=prompt, invocation_type=invocation_type,
            secrets=secrets, messages=messages, env_requests=env_requests,
        )
        with _native_gen_shim():
            return _execute(run_fn, bridge, timeout)
    finally:
        if bridge is not None:
            bridge.close()
        if tmp is not None:
            tmp.cleanup()


def run_generator(
    entrypoint,
    *,
    inputs: Optional[dict] = None,
    input_groups: Optional[dict] = None,
    config: Optional[dict] = None,
    prompt: str = "",
    invocation_type: str = "",
    secrets: Optional[dict] = None,
    messages: Optional[list] = None,
    env_requests: Optional[list] = None,
    workspace=None,
    timeout: Optional[float] = 60.0,
) -> GeneratorResult:
    """Run a generator entrypoint file host-free and return what it produced.

    ``entrypoint`` is the path to the generator's ``.py``. ``inputs`` seed
    the workspace root (single input cell); ``input_groups`` seed
    ``inputs/<label>/...`` (multi-cell). ``config`` is
    ``{draft_filename: values_dict}``. ``messages`` is a scripted
    ``gen.serve_chat`` inbound queue (strings → user messages, or command
    dicts for interrupt/redirect). ``env_requests`` seeds
    parent→environment requests for a ``gen.serve_environment`` loop (read the
    replies back from ``res.tier_b_calls``). The run executes in-process
    against a RecordingBridge; async generators are bounded by ``timeout``
    (seconds; ``None`` to disable)."""
    own_ws = workspace is None
    tmp = tempfile.TemporaryDirectory(prefix="colgen-") if own_ws else None
    ws = tmp.name if tmp is not None else str(workspace)
    bridge = None
    path = os.path.abspath(str(entrypoint))
    try:
        if not os.path.isfile(path):
            return GeneratorResult(ok=False, error=f"entrypoint not found: {path}")
        try:
            _seed_workspace(ws, inputs, input_groups, config, prompt)
        except Exception as exc:  # noqa: BLE001 — always return a result
            return GeneratorResult(ok=False, error=f"workspace seeding failed: {exc}",
                                   traceback=traceback.format_exc())
        bridge = make_test_bridge(
            ws, prompt=prompt, invocation_type=invocation_type,
            secrets=secrets, messages=messages, env_requests=env_requests,
        )

        with _native_gen_shim():
            parent = os.path.dirname(path)
            added = parent not in sys.path
            if added:
                sys.path.insert(0, parent)
            modname = f"_colgen_under_test_{next(_modname_counter)}"
            mods_before = set(sys.modules)
            try:
                try:
                    spec = importlib.util.spec_from_file_location(modname, path)
                    module = importlib.util.module_from_spec(spec)
                    sys.modules[modname] = module
                    spec.loader.exec_module(module)
                except BaseException as exc:  # noqa: BLE001 — surface import failure as a result
                    return _build_result(
                        bridge, ok=False,
                        error=f"import of {os.path.basename(path)} failed: {exc}",
                        tb=traceback.format_exc(),
                    )
                run_fn = getattr(module, "run", None)
                if not callable(run_fn):
                    return _build_result(
                        bridge, ok=False,
                        error=f"{os.path.basename(path)} defines no top-level run() function",
                    )
                return _execute(run_fn, bridge, timeout)
            finally:
                # Evict the entrypoint AND any sibling/helper modules it
                # imported, so a later run (or the real app) doesn't pick up
                # a stale cached module.
                for m in set(sys.modules) - mods_before:
                    sys.modules.pop(m, None)
                if added:
                    try:
                        sys.path.remove(parent)
                    except ValueError:
                        pass
    finally:
        if bridge is not None:
            bridge.close()
        if tmp is not None:
            tmp.cleanup()
