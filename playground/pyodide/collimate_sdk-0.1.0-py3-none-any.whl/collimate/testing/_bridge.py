# SPDX-License-Identifier: Apache-2.0
"""``RecordingBridge`` — a :class:`~collimate._host.HostBridge` subclass that
runs a generator **in-process** with no IPC peer, capturing what the run
emits instead of sending it to a host.

Subclass (not compose): ``fs_*`` / ``config`` / ``snapshot_workspace`` are
exactly the behaviour we want unchanged, so a subclass inherits them
verbatim and stays in sync if ``_host.py`` changes. Only the IPC-dependent
methods are overridden, to *record* into capture lists (the chat surface —
``chat_register`` / ``chat_poll`` / ``stream_event`` — is overridden to
drive a scripted inbound queue so host-free ``gen.serve_chat`` tests work).
Constructed via :meth:`RecordingBridge.create` (which skips
``HostBridge.__init__``'s socket/signal setup), so it never opens a socket
or installs a SIGTERM handler.

This backs the host-free run engine (:func:`collimate.testing.run_generator`)
and, in tests, lets a generator that uses ``gen.spawn`` / ``gen.call`` run
in-process (see ``stub_sub_run``).
"""
from __future__ import annotations

import hashlib
import logging
import os
import threading
from collections import deque
from typing import Optional

from collimate._host import HostBridge, _StopRequested
from collimate._results import CellRecord, Endpoint, _encode_files


class RecordingBridge(HostBridge):
    """A HostBridge that captures cell/log/status/Tier-B emissions in memory."""

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def create(
        cls,
        workspace: str,
        *,
        prompt: str = "",
        invocation_type: str = "",
        params: Optional[dict] = None,
        secrets: Optional[dict] = None,
        messages: Optional[list] = None,
        autocancel_on_serve: bool = True,
        env_requests: Optional[list] = None,
    ) -> "RecordingBridge":
        """Build a bridge rooted at ``workspace`` without running
        ``HostBridge.__init__`` (no socket, no signal handler). Mirrors the
        attribute set ``__init__`` would establish — including
        ``invocation_type`` (which the legacy ``conftest.make_bridge``
        omitted) — plus the capture state."""
        self = cls.__new__(cls)

        # --- attributes HostBridge.__init__ would set ---
        self.workspace = str(workspace)
        self.params = dict(params or {})
        self.tracked_writes = set()
        self.tracked_deletions = set()
        self._key_attempts = {}
        self._force_set_ts = {}
        self._has_updated = False
        self.prompt = prompt
        self.invocation_type = (invocation_type or "").strip()

        self.log = logging.getLogger("collimate.testing")

        # Dev-mode IPC: no socket. Any IPC method we DON'T override falls
        # back to HostBridge's dev-mode no-op (emit) / empty-ack
        # (emit_and_wait) path, so nothing hangs or crashes.
        self._socket = None
        self._sock_rfile = None
        self._sock_wfile = None
        self._ipc_lock = threading.RLock()

        # Cancellation self-pipe — read-only (never written) so ``cancelled``
        # stays False until we deliberately signal a stop.
        r, w = os.pipe()
        os.set_blocking(r, True)
        os.set_blocking(w, False)
        self._stop_pipe_r = r
        self._stop_pipe_w = w

        # --- capture state ---
        self._rec_cells: list[CellRecord] = []
        self._rec_endpoints: list[Endpoint] = []
        self._rec_tier_b: list[dict] = []
        self._rec_logs: list[str] = []
        self._rec_status: Optional[str] = None
        self._rec_secrets: dict = dict(secrets or {})
        # Scripted inbound chat commands for a host-free ``gen.serve_chat``
        # test: each ``chat_poll`` pops one. Plain strings are normalised to
        # ``{"kind": "user_msg", "content": ...}``; a dict passes through so a
        # test can script interrupts/redirects. Drained → stop the run.
        self._rec_messages: deque = deque(messages or [])
        # Stream events the run pushed (turn_start / text_delta / tool /
        # turn_end / error), captured for assertion.
        self._rec_stream_events: list[dict] = []
        self._chat_session_counter = 0
        self._autocancel_on_serve = autocancel_on_serve
        self._side_counter = 0
        self._update_counter = 0
        self._term_counter = 0

        # Stubs for composition (gen.spawn/gen.call/gen.check_renderer) — set
        # by tests via stub_generators / stub_sub_run / stub_check_renderer.
        # Default: an inline source runs in-process via run_generator (the
        # composition==testing unification); an installed id with no stub
        # degrades to "no host".
        self._stub_generators = None
        self._stub_sub_run = None
        self._stub_check_renderer = None
        self._sub_runs: dict = {}      # sub_run_id -> ack dict
        self._sub_counter = 0
        self._cell_surface_counter = 0

        # Environment composition: a worker driving a child environment. The
        # workspace plane round-trips through an in-memory per-sub-run dict;
        # exec/capabilities are stubbable (default: a core env once exec is
        # stubbed). The env-author side (serve_environment) is driven by
        # `env_requests` and its replies captured for assertion.
        self._stub_sub_run_exec = None
        self._stub_sub_run_capabilities = None
        self._sub_workspaces: dict = {}   # sub_run_id -> {path: content}
        self._proc_counter = 0
        self._rec_env_requests: deque = deque(env_requests or [])
        self._rec_env_replies: list = []

        return self

    # ------------------------------------------------------------------
    # Composition stubs (set by tests)
    # ------------------------------------------------------------------

    def stub_generators(self, generators) -> None:
        """Make :func:`gen.generators` return these (GeneratorInfo or dicts)."""
        from collimate._results import GeneratorInfo

        out = []
        for g in generators:
            if isinstance(g, GeneratorInfo):
                out.append({
                    "id": g.id, "name": g.name, "summary": g.summary,
                    "type": list(g.type), "daemon": g.daemon,
                    "chat": g.chat, "ephemeral": g.ephemeral,
                    "min_inputs": g.min_inputs, "max_inputs": g.max_inputs,
                    "prompt_intent": g.prompt_intent, "prompt_required": g.prompt_required,
                })
            else:
                out.append(dict(g))
        self._stub_generators = out

    def stub_sub_run(self, fn) -> None:
        """Set the sub-run executor: ``fn(source_payload, kwargs) ->
        GeneratorResult``. Default delegates inline sources to run_generator."""
        self._stub_sub_run = fn

    def stub_check_renderer(self, fn) -> None:
        """Set ``gen.check_renderer`` behaviour: ``fn(files, entrypoint) ->
        RendererCheck | dict``. Default returns ok=True."""
        self._stub_check_renderer = fn

    def stub_sub_run_exec(self, fn) -> None:
        """Set ``handle.exec`` behaviour for a child environment:
        ``fn(sub_run_id, command, kwargs) -> (rc, output) | dict``. Setting it
        also makes ``handle.capabilities()`` report a core environment."""
        self._stub_sub_run_exec = fn

    def stub_sub_run_capabilities(self, spec_or_fn) -> None:
        """Set ``handle.capabilities()`` for a child environment: an
        ``EnvironmentSpec``/dict, or ``fn(sub_run_id) -> dict | None``."""
        self._stub_sub_run_capabilities = spec_or_fn

    def env_replies(self) -> list:
        """Replies this environment sent for seeded ``env_requests`` (for
        asserting an environment generator's ``gen.serve_environment``)."""
        return list(self._rec_env_replies)

    # ------------------------------------------------------------------
    # Composition method overrides (in-process)
    # ------------------------------------------------------------------

    def list_generators(self) -> list:
        return list(self._stub_generators or [])

    def _default_inline_result(self, source_payload: dict, kw: dict):
        """Run an inline candidate in-process via run_generator, in a fresh
        thread so its asyncio.run() doesn't clash with the parent loop."""
        from collimate._results import GeneratorResult, _decode_files

        inline = source_payload.get("inline") if isinstance(source_payload, dict) else None
        if not inline:
            return GeneratorResult(
                ok=False,
                error="no host available — set stub_sub_run to run an installed-id source in-process",
            )
        import os
        import tempfile
        import threading

        files = _decode_files(inline.get("files"))
        entry = inline.get("entrypoint") or ""
        holder: dict = {}

        def _worker():
            from collimate.testing import run_generator

            with tempfile.TemporaryDirectory(prefix="colsub-") as d:
                for rel, content in files.items():
                    full = os.path.join(d, rel)
                    os.makedirs(os.path.dirname(full) or d, exist_ok=True)
                    if isinstance(content, bytes):
                        with open(full, "wb") as fh:
                            fh.write(content)
                    else:
                        with open(full, "w", encoding="utf-8") as fh:
                            fh.write(content)
                holder["r"] = run_generator(
                    os.path.join(d, entry),
                    inputs=kw.get("inputs"),
                    input_groups=kw.get("input_groups"),
                    prompt=kw.get("prompt", ""),
                    invocation_type=kw.get("invocation_type", "create"),
                    config=kw.get("config"),
                )

        t = threading.Thread(target=_worker)
        t.start()
        t.join()
        return holder.get("r") or GeneratorResult(ok=False, error="sub-run produced no result")

    def start_sub_run(self, source: dict, *, inputs=None, input_groups=None,
                      prompt: str = "", invocation_type: str = "create",
                      config=None, secrets=None, surface=None) -> str:
        from collimate._results import GeneratorResult, _result_to_ack

        kw = {
            "inputs": inputs, "input_groups": input_groups, "prompt": prompt,
            "invocation_type": invocation_type, "config": config, "secrets": secrets,
        }
        if self._stub_sub_run is not None:
            result = self._stub_sub_run(source, kw)
        elif isinstance(source, dict) and "inline" in source:
            result = self._default_inline_result(source, kw)
        else:
            # Installed id with no stub and no host — degrade.
            return ""
        if not isinstance(result, GeneratorResult):
            result = GeneratorResult(ok=False, error="stub_sub_run must return a GeneratorResult")
        self._sub_counter += 1
        sid = f"rec-subrun-{self._sub_counter}"
        self._sub_runs[sid] = _result_to_ack(result)
        # Seed the live workspace from the child's output so a worker can
        # read_file/list_files what it produced, then put_files over it.
        self._sub_workspaces[sid] = dict(result.files)
        return sid

    def sub_run_wait(self, sub_run_id: str, timeout=None) -> dict:
        return self._sub_runs.get(sub_run_id, {"ok": False, "error": "no such sub-run"})

    def sub_run_endpoints(self, sub_run_id: str) -> list:
        return list(self._sub_runs.get(sub_run_id, {}).get("endpoints") or [])

    def sub_run_status(self, sub_run_id: str) -> str:
        ack = self._sub_runs.get(sub_run_id)
        if ack is None:
            return "failed"
        return "done" if ack.get("ok") else "failed"

    def sub_run_files(self, sub_run_id: str) -> dict:
        return dict(self._sub_runs.get(sub_run_id, {}).get("files") or {})

    def stop_sub_run(self, sub_run_id: str) -> None:
        self._rec_tier_b.append({"op": "stop_sub_run", "sub_run_id": sub_run_id})

    def surface_sub_run(self, sub_run_id: str, spec=None) -> str:
        self._cell_surface_counter += 1
        self._rec_tier_b.append({"op": "surface_sub_run", "sub_run_id": sub_run_id, "spec": spec})
        return f"rec-cell-{self._cell_surface_counter}"

    # ------------------------------------------------------------------
    # Environment composition — worker side (drive a child environment)
    # ------------------------------------------------------------------

    def _env_ws(self, sub_run_id: str) -> dict:
        return self._sub_workspaces.setdefault(sub_run_id, {})

    def sub_run_capabilities(self, sub_run_id: str):
        s = self._stub_sub_run_capabilities
        if s is not None:
            from collimate._results import EnvironmentSpec
            res = s(sub_run_id) if callable(s) else s
            if isinstance(res, EnvironmentSpec):
                return {
                    "exec": res.exec, "exec_background": res.exec_background,
                    "expose_port": res.expose_port, "files": res.files,
                    "terminals": res.terminals, "watch": res.watch,
                    "concurrent_exec": res.concurrent_exec,
                }
            return res
        # Default: once exec is stubbed, present a core environment.
        return {} if self._stub_sub_run_exec is not None else None

    def sub_run_exec(self, sub_run_id, command, *, cwd=None, env=None, timeout=120) -> dict:
        self._rec_tier_b.append({"op": "sub_run_exec", "sub_run_id": sub_run_id, "command": command})
        if self._stub_sub_run_exec is not None:
            res = self._stub_sub_run_exec(sub_run_id, command, {"cwd": cwd, "env": env, "timeout": timeout})
            if isinstance(res, tuple) and len(res) == 2:
                return {"ok": True, "rc": int(res[0]), "output": str(res[1])}
            if isinstance(res, dict):
                # Honour an execution-plane failure (ok=False / error), which the
                # real host returns for "no such sub-run", "environment is gone",
                # and reply-timeout — native.exec maps it to (rc=-1, error).
                if res.get("ok") is False or "error" in res:
                    return {"ok": False, "error": str(res.get("error", "")),
                            "rc": int(res.get("rc", -1)), "output": str(res.get("output", ""))}
                return {"ok": True, "rc": int(res.get("rc", 0)), "output": str(res.get("output", ""))}
            return {"ok": True, "rc": 0, "output": str(res)}
        return {"ok": True, "rc": 0, "output": "[testing] sub_run_exec recorded (no environment)"}

    def sub_run_exec_background(self, sub_run_id, command, *, cwd=None, env=None) -> dict:
        self._proc_counter += 1
        pid = f"rec-proc-{self._proc_counter}"
        self._rec_tier_b.append({
            "op": "sub_run_exec_background", "sub_run_id": sub_run_id,
            "command": command, "process_id": pid,
        })
        return {"ok": True, "process_id": pid}

    def sub_run_stop_process(self, sub_run_id, process_id) -> None:
        self._rec_tier_b.append({
            "op": "sub_run_stop_process", "sub_run_id": sub_run_id, "process_id": process_id,
        })

    def sub_run_wait_process(self, sub_run_id, process_id, *, timeout=None) -> dict:
        return {"ok": True, "rc": 0}

    def sub_run_expose_port(self, sub_run_id, port) -> dict:
        self._rec_tier_b.append({"op": "sub_run_expose_port", "sub_run_id": sub_run_id, "port": port})
        ep = {"kind": "http", "name": "exposed", "port": port,
              "url": f"/rec/proxy/{sub_run_id}/{port}/"}
        return {"ok": True, "endpoint": ep}

    def sub_run_open_terminal(self, sub_run_id, command, *, cwd=None, env=None) -> dict:
        self._term_counter += 1
        sid = f"rec-term-{self._term_counter}"
        self._rec_tier_b.append({
            "op": "sub_run_open_terminal", "sub_run_id": sub_run_id, "command": list(command),
        })
        return {"ok": True, "session_id": sid, "ws_path": f"/rec/ws/{sid}", "token": "rec-token"}

    @staticmethod
    def _safe_env_rel(p) -> bool:
        # Mirror the host's workspace-path containment so a traversal/absolute
        # path is rejected host-free too (the host rejects it on disk).
        return (isinstance(p, str) and bool(p) and not os.path.isabs(p)
                and "\\" not in p and ".." not in p.replace("\\", "/").split("/"))

    def sub_run_put_files(self, sub_run_id, files) -> None:
        self._rec_tier_b.append({
            "op": "sub_run_put_files", "sub_run_id": sub_run_id, "paths": sorted(files),
        })
        safe = {p: c for p, c in dict(files).items() if self._safe_env_rel(p)}
        self._env_ws(sub_run_id).update(safe)

    def sub_run_read_file(self, sub_run_id, path) -> dict:
        ws = self._env_ws(sub_run_id)
        if not self._safe_env_rel(path) or path not in ws:
            return {"ok": False}
        return {"ok": True, "file": _encode_files({path: ws[path]})}

    def sub_run_delete_file(self, sub_run_id, path) -> None:
        self._env_ws(sub_run_id).pop(path, None)
        self._rec_tier_b.append({"op": "sub_run_delete_file", "sub_run_id": sub_run_id, "path": path})

    def sub_run_list_files(self, sub_run_id) -> list:
        return sorted(self._env_ws(sub_run_id))

    def sub_run_snapshot(self, sub_run_id) -> dict:
        out: dict = {}
        for p, c in self._env_ws(sub_run_id).items():
            b = c.encode("utf-8") if isinstance(c, str) else c
            out[p] = hashlib.sha256(b).hexdigest()
        return out

    # ------------------------------------------------------------------
    # Environment composition — environment side (serve_environment)
    # ------------------------------------------------------------------

    def serve_environment_register(self, spec: dict) -> None:
        self._rec_tier_b.append({"op": "serve_environment_register", "spec": dict(spec or {})})

    def serve_environment_poll(self, timeout: float = 30.0):
        if self._rec_env_requests:
            return self._rec_env_requests.popleft()
        # Drained: stop so the serve loop exits cleanly (like chat_poll).
        self._signal_stop()
        return None

    def serve_environment_reply(self, request_id: str, result: dict) -> None:
        rec = {"request_id": request_id, "result": dict(result or {})}
        self._rec_env_replies.append(rec)
        self._rec_tier_b.append({"op": "serve_environment_reply", **rec})

    def check_renderer(self, files: dict, entrypoint: str) -> dict:
        if self._stub_check_renderer is not None:
            res = self._stub_check_renderer(files, entrypoint)
            if isinstance(res, dict):
                return res
            return {"ok": getattr(res, "ok", False), "errors": list(getattr(res, "errors", [])),
                    "warnings": list(getattr(res, "warnings", []))}
        return {"ok": True, "errors": [], "warnings": []}

    def close(self) -> None:
        """Release the cancellation self-pipe. Idempotent."""
        for attr in ("_stop_pipe_r", "_stop_pipe_w"):
            fd = getattr(self, attr, -1)
            if isinstance(fd, int) and fd >= 0:
                try:
                    os.close(fd)
                except OSError:
                    pass
                setattr(self, attr, -1)

    def _signal_stop(self) -> None:
        """Flip ``cancelled`` to True (write one byte to the self-pipe)."""
        try:
            os.write(self._stop_pipe_w, b"x")
        except (BlockingIOError, OSError):
            pass

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _snapshot(self, paths) -> dict:
        out: dict = {}
        for p in paths:
            try:
                if self.fs_exists(p):
                    out[p] = self.fs_read_any(p)
            except OSError:
                continue
        return out

    # ------------------------------------------------------------------
    # Cell operations — capture instead of emit
    # ------------------------------------------------------------------

    def update_cell(
        self,
        *,
        name: Optional[str] = None,
        summary: Optional[str] = None,
        pinned: Optional[str] = None,
        deleted_files: Optional[list] = None,
    ) -> str:
        files = self._snapshot(sorted(self.tracked_writes))
        # Mirror HostBridge.update_cell's state transitions.
        self.tracked_writes.clear()
        if not self._has_updated:
            self._has_updated = True
        self._update_counter += 1
        self._rec_cells.append(CellRecord(
            kind="update",
            name=name,
            summary=summary,
            pinned=pinned,
            files=files,
        ))
        return f"rec-update-{self._update_counter}"

    def create_side_cell(
        self,
        *,
        name: str,
        summary: Optional[str] = None,
        pinned: Optional[str] = None,
        files: Optional[dict] = None,
    ) -> str:
        if files is not None:
            captured: dict = {}
            for path, content in files.items():
                self.fs_write_any(path, content)
                self.tracked_writes.discard(path)
                captured[path] = content
        else:
            captured = self._snapshot(sorted(self.tracked_writes))
        self._side_counter += 1
        self._rec_cells.append(CellRecord(
            kind="stack",
            name=name,
            summary=summary,
            pinned=pinned,
            files=captured,
        ))
        return f"rec-stack-{self._side_counter}"

    # ------------------------------------------------------------------
    # Status / control — capture
    # ------------------------------------------------------------------

    def push_log(self, line: str) -> None:
        self._rec_logs.append(line)

    def set_status(self, message: str) -> None:
        self._rec_status = message

    def progress(self, current: int, total: int) -> None:
        # No IPC; nothing to record on the result. No-op.
        return None

    # ------------------------------------------------------------------
    # Keys / secrets — from the scripted dict, never a modal
    # ------------------------------------------------------------------

    def get_key(self, name: str, *, description: str = "", force: bool = False) -> str:
        value = self._rec_secrets.get(name) or os.environ.get(name) or ""
        if value:
            os.environ[name] = value
            return value
        # No key available: end the run gracefully as "stopped/needs key"
        # rather than crashing. Log it so the result is diagnosable and not
        # confused with a real user Stop. Provide one in `secrets=` to
        # exercise the happy path.
        self.push_log(
            f"[testing] get_key({name!r}) returned no value — pass "
            f"secrets={{{name!r}: ...}} to run_generator; ending run as stopped"
        )
        raise _StopRequested()

    # ------------------------------------------------------------------
    # Live chat — scripted inbound queue; stop when drained
    # ------------------------------------------------------------------

    def chat_register(self) -> dict:
        """Allocate a (fake) chat session for a host-free ``serve_chat``
        test. Returns the same shape the host's ack does."""
        self._chat_session_counter += 1
        sid = f"rec-chat-{self._chat_session_counter}"
        self._rec_tier_b.append({"op": "chat_register", "session_id": sid})
        return {"session_id": sid, "ws_path": f"/rec/ws/{sid}", "token": "rec-token"}

    def chat_poll(self) -> Optional[dict]:
        """Pop the next scripted inbound chat command, or stop the run when
        the queue is drained so ``serve_chat`` exits cleanly. Plain strings
        are normalised to a ``user_msg`` command; dicts pass through (so a
        test can script ``interrupt`` / ``redirect``)."""
        if self._rec_messages:
            cmd = self._rec_messages.popleft()
            if isinstance(cmd, dict):
                return cmd
            return {"kind": "user_msg", "content": str(cmd)}
        # Queue drained: signal stop so gen.serve_chat exits cleanly instead
        # of polling forever.
        self._signal_stop()
        return None

    def stream_event(self, turn_id: str, event: dict) -> None:
        """Record a streamed chat event instead of routing it to a live
        WebSocket. Asserted via ``res.tier_b_calls`` / the bridge's
        ``_rec_stream_events``."""
        rec = {"turn_id": turn_id, "event": dict(event or {})}
        self._rec_stream_events.append(rec)
        self._rec_tier_b.append({"op": "stream_event", **rec})

    def poll_renderer_action(self) -> Optional[str]:
        self._rec_tier_b.append({"op": "poll_renderer_action"})
        return None

    def request_settings_update(self, settings_file_path: str) -> dict:
        self._rec_tier_b.append({
            "op": "request_settings_update",
            "settings_file_path": settings_file_path,
        })
        return {}

    # ------------------------------------------------------------------
    # Tier B (daemons / subprocess) — record structurally, don't execute
    # ------------------------------------------------------------------

    def serve_port(
        self,
        port: int,
        *,
        name: str = "preview",
        path: str = "",
        snapshot_source: Optional[dict] = None,
    ) -> None:
        self._rec_tier_b.append({"op": "serve_port", "port": port, "name": name, "path": path})
        self._rec_endpoints.append(Endpoint(kind="http", name=name, port=port, path=path))
        if self._autocancel_on_serve:
            self._signal_stop()  # let a daemon's `while not cancelled` loop exit

    def start_terminal(
        self,
        *,
        container_id: str,
        command: list,
        cwd: Optional[str] = None,
        env: Optional[dict] = None,
    ) -> dict:
        self._term_counter += 1
        sid = f"rec-term-{self._term_counter}"
        self._rec_tier_b.append({
            "op": "start_terminal", "container_id": container_id,
            "command": list(command), "cwd": cwd or "",
        })
        self._rec_endpoints.append(Endpoint(kind="terminal", name="terminal", session_id=sid))
        if self._autocancel_on_serve:
            self._signal_stop()
        return {"session_id": sid, "ws_path": f"/rec/ws/{sid}", "token": "rec-token"}

    def stop_terminal(self, session_id: str) -> None:
        self._rec_tier_b.append({"op": "stop_terminal", "session_id": session_id})

    def run_streamed_subprocess(self, command, **kwargs) -> tuple:
        # One-shot subprocess: record AND actually run it (in-process tests
        # use this via gen.python_tool / gen.run_subprocess and need real
        # output + file staging). Only daemon endpoints (serve_port /
        # start_terminal) are stubbed — those would hang or bind real
        # resources. The streaming chat IPC inside is captured by
        # stream_event being overridden.
        self._rec_tier_b.append({"op": "run_streamed_subprocess", "command": command})
        return super().run_streamed_subprocess(command, **kwargs)
