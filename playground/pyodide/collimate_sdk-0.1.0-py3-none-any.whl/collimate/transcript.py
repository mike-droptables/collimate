# SPDX-License-Identifier: Apache-2.0
"""Chat transcript format — the open, provider-agnostic standard.

Replaces the old proprietary ``.chatlog`` JSON-Lines format. A transcript is a
single JSON document holding an OpenAI-compatible ``messages`` array — the
universal de-facto interchange shape every LLM provider and chat UI (including
assistant-ui, via ``convertMessage``) understands::

    {
      "messages": [
        {"role": "system", "content": "..."},
        {"role": "user", "content": "hello there"},
        {"role": "assistant", "content": "hi — how can I help?"}
      ]
    }

One transcript file per chat **thread** (e.g. ``chats/<thread_id>.json``); the
threads all share the cell's workspace files. ``role`` is one of
``user`` / ``assistant`` / ``system`` (case-insensitive; unknown roles — incl.
``tool`` — are dropped on read so a stray object can't smuggle in a bogus
message, and so parse/compose/render agree on exactly the visible roles).
The document is pretty-printed so it diffs cleanly in the cell's version
history. ``parse_transcript(serialize_transcript(m))`` round-trips. Assistant
messages may carry an optional ``"thinking"`` field (the model's
extended-thinking text), written only when non-empty and preserved on read.
"""
from __future__ import annotations

import json

from collimate._host import Message

_ROLES = ("user", "assistant", "system")


def serialize_transcript(messages: list[Message]) -> str:
    """Render messages to the open transcript JSON (OpenAI-compatible).

    An assistant message's ``thinking`` (extended-thinking text) is written as
    an optional ``"thinking"`` field only when non-empty — plain transcripts
    stay exactly the two-key shape, and index-based curation is unaffected.
    """
    out = []
    for m in messages:
        role = (m.role or "").lower()
        if role not in _ROLES:
            continue
        entry: dict = {"role": role, "content": m.content or ""}
        # Thinking is an assistant-message concept; never written for others.
        if role == "assistant" and getattr(m, "thinking", ""):
            entry["thinking"] = m.thinking
        out.append(entry)
    return json.dumps({"messages": out}, indent=2, ensure_ascii=False) + "\n"


def parse_transcript(text: str) -> list[Message]:
    """Parse the open transcript JSON back into messages.

    Tolerant: accepts either ``{"messages": [...]}`` or a bare top-level array,
    skips entries that aren't ``{role, content}`` objects or carry an unknown
    role, and returns ``[]`` for empty/unparseable input.
    """
    if not text or not text.strip():
        return []
    try:
        data = json.loads(text)
    except ValueError:
        return []
    items = data.get("messages") if isinstance(data, dict) else data
    if not isinstance(items, list):
        return []
    messages: list[Message] = []
    for obj in items:
        if not isinstance(obj, dict):
            continue
        role = str(obj.get("role", "")).lower()
        if role not in _ROLES:
            continue
        messages.append(Message(
            role=role,
            content=str(obj.get("content", "")),
            thinking=(str(obj.get("thinking", "") or "")
                      if role == "assistant" else ""),
        ))
    return messages


__all__ = ["parse_transcript", "serialize_transcript"]
