# SPDX-License-Identifier: Apache-2.0
"""Singleton runtime API for WASM generators.

The wasm runner sets up the singleton via :func:`_set_context` before
invoking ``run()``; the generator imports the top-level ``gen`` package
(a thin shim that re-exports this module) and reads/writes via the
``gen.*`` symbols. No ``ctx`` argument is passed to ``run()``.

Two tiers:

  * **Core** (always available, no LLM dependency): inputs, file I/O,
    cells, user input, API keys, status. A pure-Python generator uses
    only these.
  * **LLM helpers** (opt-in): :func:`agent`, :func:`file_tools`,
    :func:`chat_loop`. Importing them lazily triggers ``ensure_pydantic_ai()``
    (micropip install + pyfetch transport patch).

Cell operations are deliberately limited to two:

  * :func:`update` flushes the staged output (files + chat history) to
    the placeholder/top cell. May be called many times during a run;
    the last call before return is the final state.
  * :func:`create_stack_cell` adds a new cell below in the right-side
    stack. Used by fan-out generators (e.g. seed-ideas).

Calling ``update_file`` without ever calling ``update`` produces an
empty placeholder — explicit by design.
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Any, AsyncIterator, Iterator, Optional
import asyncio
import json
import os

if TYPE_CHECKING:
    from collimate.wasm_sdk import Message, WasmContext


# ──────────────────────────────────────────────────────────────────────
# Module-level singleton state.
#
# ``_set_context()`` (called by the wasm runner) hydrates these before
# the generator's ``run()`` fires. ``_clear_context()`` wipes them when
# the run finishes. Generators never touch this state directly — they
# read/write through the public ``gen.*`` functions.
# ──────────────────────────────────────────────────────────────────────

_ctx: Optional["WasmContext"] = None
# Stage values may be ``str`` (utf-8 text) or ``bytes`` (binary
# artifacts emitted by ``run_python`` etc.). The host bridge encodes
# bytes as base64 on the wire — see ``wasm_runner.WasmRunnerHost.emit_partial``.
_stage: dict[str, "str | bytes"] = {}
_stage_dirty: bool = False
_history_list: list["Message"] = []
_history_dirty: bool = False


# ──────────────────────────────────────────────────────────────────────
# Public exception types
# ──────────────────────────────────────────────────────────────────────


class Cancelled(Exception):
    """Raised when the user cancels a modal (api_key, secret) or stops
    the run while ``chat_loop`` is awaiting a message."""


# ──────────────────────────────────────────────────────────────────────
# Runner hooks (private; called by api/process_manager/wasm_runner.py)
# ──────────────────────────────────────────────────────────────────────


def _set_context(ctx: "WasmContext") -> None:
    """Hydrate the singleton before invoking ``run()``.

    For **single-input** runs the output stage is pre-populated with
    every input-cell file so reads "just work" and unwritten files
    carry forward into the placeholder on the first ``update()`` call.
    Generators that want to drop files explicitly call
    :func:`delete_file`.

    For **multi-input** runs (workspace hydrated as ``inputs/NN_slug/``
    subfolders) the stage starts empty — those generators rebuild the
    output explicitly via :func:`input_groups` + :func:`update_file`.
    Auto-carrying the prefixed paths would land them in the output cell
    as-is, which is essentially never what a multi-input generator
    wants.
    """
    global _ctx, _stage, _stage_dirty, _history_list, _history_dirty
    _ctx = ctx
    _stage = {}
    paths = ctx.workspace_files()
    is_multi_input = any(p.startswith("inputs/") for p in paths)
    if not is_multi_input:
        for p in paths:
            try:
                _stage[p] = ctx.read_workspace_any(p)
            except OSError:
                continue
    _stage_dirty = False
    _history_list = list(ctx.messages)
    _history_dirty = False


def _clear_context() -> None:
    """Wipe the singleton after the run finishes."""
    global _ctx, _stage, _stage_dirty, _history_list, _history_dirty
    _ctx = None
    _stage = {}
    _stage_dirty = False
    _history_list = []
    _history_dirty = False


def _require_ctx() -> "WasmContext":
    if _ctx is None:
        raise RuntimeError(
            "gen.* used outside a generator run "
            "(wasm_runner._set_context was not called)"
        )
    return _ctx


# ──────────────────────────────────────────────────────────────────────
# Module-level attribute hook.
#
# Lets generators read ``gen.prompt`` / ``gen.messages`` / ``gen.cancelled``
# as plain attributes that resolve against the current run's context.
# These are properties-of-a-module — Python supports this via
# ``__getattr__`` at module level (PEP 562).
# ──────────────────────────────────────────────────────────────────────


def __getattr__(name: str) -> Any:
    if name == "prompt":
        return _require_ctx().prompt
    if name == "messages":
        # Defensive copy — generators should never mutate a snapshot of
        # the prior chat history out from under the live ``history``
        # wrapper.
        return list(_require_ctx().messages)
    if name == "cancelled":
        return _require_ctx().cancelled
    raise AttributeError(f"module 'collimate.wasm' has no attribute {name!r}")


# ──────────────────────────────────────────────────────────────────────
# Input file I/O (read-only on parent cells)
# ──────────────────────────────────────────────────────────────────────


def read_input(path: str) -> "str | bytes":
    """Read a file from the input/parent cell workspace.

    Returns ``str`` for files that decode as utf-8, otherwise ``bytes``
    — auto-detected via :meth:`WasmContext.read_workspace_any`. Use
    ``ctx.read_workspace`` (text-only) or ``ctx.read_workspace_bytes``
    on the context directly when a specific representation is required.
    """
    return _require_ctx().read_workspace_any(path)


def input_files() -> dict[str, "str | bytes"]:
    """Return every input-cell file as ``{relpath: content}``.

    Convenience for generators that want a snapshot of all parent-cell
    files. Each value is ``str`` (utf-8 text) or ``bytes`` (binary).
    Files that fail to read are silently skipped (matches the behaviour
    of the duplicated ``_carry_forward`` helpers in the old generators).
    """
    ctx = _require_ctx()
    out: dict[str, "str | bytes"] = {}
    for p in ctx.workspace_files():
        try:
            out[p] = ctx.read_workspace_any(p)
        except OSError:
            continue
    return out


def input_groups() -> dict[str, dict[str, "str | bytes"]]:
    """Return input files grouped by source cell.

    For multi-cell input (workspace hydrated as ``inputs/NN_slug/...``),
    each top-level subfolder under ``inputs/`` becomes one group. Paths
    in each group dict are **relative to the cell root** (the
    ``inputs/NN_slug/`` prefix is stripped) so callers can re-emit them
    verbatim into the output stage. Values are ``str`` or ``bytes``
    depending on whether each file decodes as utf-8.

    For single-cell input (files at the workspace root), returns one
    group keyed ``"input"`` with the original paths.
    """
    ctx = _require_ctx()
    all_paths = ctx.workspace_files()
    inputs_prefix = "inputs/"
    under_inputs = [p for p in all_paths if p.startswith(inputs_prefix)]
    if not under_inputs:
        if not all_paths:
            return {}
        out_single: dict[str, "str | bytes"] = {}
        for p in all_paths:
            try:
                out_single[p] = ctx.read_workspace_any(p)
            except OSError:
                continue
        return {"input": out_single}

    raw: dict[str, dict[str, "str | bytes"]] = {}
    for p in under_inputs:
        rest = p[len(inputs_prefix):]
        label, _, sub = rest.partition("/")
        if not sub:
            continue
        try:
            content = ctx.read_workspace_any(p)
        except OSError:
            continue
        raw.setdefault(label, {})[sub] = content
    # Sort by label so the ``NN_slug`` ordering from the host's
    # hydrator is preserved — topmost input (smallest NN) ends up
    # first. Generators that resolve collisions "topmost wins" rely on
    # this iteration order.
    return {label: raw[label] for label in sorted(raw)}


# ──────────────────────────────────────────────────────────────────────
# Draft-file reader (one method, extension-detecting)
# ──────────────────────────────────────────────────────────────────────


def config(name: str) -> Any:
    """Read a draft file declared in the manifest's ``draft_files``.

    Auto-detects by extension:

      * ``.set_yaml`` / ``.yaml`` / ``.yml`` — parsed as YAML. For
        ``.set_yaml`` schema-form files the ``fields:`` defaults are
        merged with the ``values:`` block so a flat ``{key: value}``
        dict comes back.
      * ``.json`` — parsed as JSON.
      * Anything else — returned as the raw string.

    Returns ``{}`` (or ``""`` for raw) when the file is missing or
    malformed.
    """
    ctx = _require_ctx()
    lower = name.lower()
    if lower.endswith((".set_yaml", ".yaml", ".yml")):
        return ctx.config_yaml(name)
    if lower.endswith(".json"):
        return ctx.config_json(name)
    return ctx.config(name)


# ──────────────────────────────────────────────────────────────────────
# Output stage (file I/O on the cell being written)
#
# The stage starts pre-populated with input files (see _set_context)
# so reads "just work". Writes mark _stage_dirty so the next ``update()``
# call has something to flush. ``update`` clears the dirty bit.
# ──────────────────────────────────────────────────────────────────────


def update_file(path: str, content: "str | bytes") -> None:
    """Stage a write to the output cell's file at ``path``.

    ``content`` may be ``str`` (utf-8 text) or ``bytes`` (binary
    artifacts — PNG plots, archives, etc.). The host bridge encodes the
    bytes path as base64 before persistence.

    The write is in-memory until the next :func:`update` call flushes
    the stage to the placeholder. Multiple ``update_file`` calls with
    the same path overwrite — the last write wins.
    """
    global _stage_dirty
    _require_ctx()
    if not isinstance(content, (str, bytes)):
        raise TypeError(
            f"update_file content must be str or bytes, got {type(content).__name__}"
        )
    _stage[path] = content
    _stage_dirty = True


def read_file(path: str) -> "str | bytes":
    """Read from the output stage. Input files carry forward by default
    (the stage is pre-populated in :func:`_set_context`), so this works
    for both unwritten input files and the generator's own writes.

    Returns ``str`` for text files, ``bytes`` for binary — caller can
    branch on ``isinstance(..., bytes)``.
    """
    _require_ctx()
    if path not in _stage:
        raise FileNotFoundError(path)
    return _stage[path]


def has_file(path: str) -> bool:
    """Predicate over the output stage. Used by collision-aware
    generators (e.g. ``merge``) to skip files already staged by an
    earlier input."""
    _require_ctx()
    return path in _stage


def list_files() -> list[str]:
    """Return every staged file's path, sorted."""
    _require_ctx()
    return sorted(_stage.keys())


def delete_file(path: str) -> None:
    """Drop a path from the output stage. No-op if not present."""
    global _stage_dirty
    _require_ctx()
    if path in _stage:
        del _stage[path]
        _stage_dirty = True


# ──────────────────────────────────────────────────────────────────────
# Cell operations — two only
# ──────────────────────────────────────────────────────────────────────


async def update(
    *,
    name: Optional[str] = None,
    summary: Optional[str] = None,
    summary_artifact: Optional[str] = None,
) -> None:
    """Flush the current stage (files + chat history) to the
    placeholder/top cell.

    May be called many times during a run; each call refreshes the
    visible cell live (the host debounces persistence). The last call
    before return is the final state. **If ``update`` is never called,
    the placeholder is empty.**

    One method, one mental model: stage writes via :func:`update_file`
    and :data:`history`, flush them all together by calling
    :func:`update`. ``summary_artifact`` is a per-call override of
    which staged file backs the cell-card preview (e.g. ``"index.md"``,
    ``"output.md"``, ``"why_picked.md"``).
    """
    global _stage_dirty, _history_dirty
    ctx = _require_ctx()

    files = dict(_stage) if _stage_dirty else None
    chat = list(_history_list) if _history_dirty else None

    await ctx.emit_partial(
        files=files,
        cell_name=name,
        summary=summary,
        summary_artifact=summary_artifact,
        chat_messages=chat,
    )

    if files is not None:
        _stage_dirty = False
    if chat is not None:
        _history_dirty = False


async def create_stack_cell(
    name: str,
    *,
    summary: Optional[str] = None,
    summary_artifact: Optional[str] = None,
    files: Optional[dict[str, "str | bytes"]] = None,
) -> str:
    """Add a new cell below in the (right-side) stack.

    If ``files`` is omitted, snapshots the current stage. Used by
    fan-out generators (e.g. ``seed-ideas``) to create N sibling cells
    while the placeholder/top cell holds an index. Values may be
    ``str`` or ``bytes`` (binary artifacts go through the host's
    base64 encoding path).

    Returns the new cell's id.
    """
    ctx = _require_ctx()
    snapshot = dict(_stage) if files is None else files
    return await ctx.create_side_cell(
        name=name,
        summary=summary,
        summary_artifact=summary_artifact,
        files=snapshot,
    )


# ──────────────────────────────────────────────────────────────────────
# User input mid-run
# ──────────────────────────────────────────────────────────────────────


# Polling cadence for ``next_message`` and ``chat_loop``. Short enough
# that Stop feels instant; long enough that an idle chat doesn't burn
# the event loop. Mirrors the value live-chat used to define locally.
_POLL_INTERVAL_S = 0.2


async def next_message() -> Optional[str]:
    """Block until the next user message arrives or the run is
    cancelled. Returns the message content, or ``None`` on cancel.

    Escape hatch for one-off polling outside :func:`chat_loop`. Most
    chat-shaped generators use ``async for msg in chat_loop():``
    instead — the iterator handles seeding from ``gen.prompt``,
    auth-error retry, and emit cadence.
    """
    ctx = _require_ctx()
    while not ctx.cancelled:
        msg = ctx.poll_user_message()
        if msg is not None:
            return msg.content
        await asyncio.sleep(_POLL_INTERVAL_S)
    return None


async def chat_loop(*, seed: bool = True) -> AsyncIterator[str]:
    """Async iterator yielding user messages, turn by turn.

    The first iteration yields ``gen.prompt`` (the picker textarea
    text) when ``seed`` is True and the prompt is non-empty. Subsequent
    iterations block on :func:`next_message` until a new message
    arrives. The loop exits cleanly when the user clicks Stop.

    Generators are responsible for running per-turn logic in the body
    and calling :func:`update` to flush partial state. This iterator
    intentionally doesn't auto-commit history — appending to
    :data:`history` and calling ``update()`` keeps the loop body
    explicit about what gets persisted.

    Auth-error retry, cancellation handling, and partial emits stay in
    the generator's loop body; this iterator is a thin polling
    primitive. (See ``live-chat`` for the canonical pattern.)
    """
    ctx = _require_ctx()
    pending: Optional[str] = None
    if seed:
        seed_text = (ctx.prompt or "").strip()
        if seed_text:
            pending = seed_text
    while not ctx.cancelled:
        if pending is None:
            pending = await next_message()
            if pending is None:
                return
        yield pending
        pending = None


# ──────────────────────────────────────────────────────────────────────
# Chat history
# ──────────────────────────────────────────────────────────────────────


class _History:
    """Thin wrapper over the singleton's chat history list.

    ``append(role, content)`` mutates the in-memory list and marks dirty;
    the next :func:`update` call flushes it to ``.colreserved/.collimate_messages.json``
    as a memory artifact. ``as_pai()`` translates to pydantic_ai's
    ``ModelMessage`` shape, replacing the duplicated ``_to_pai_history``
    helper that lived in live-chat.
    """

    def append(self, role: str, content: str) -> None:
        global _history_dirty
        from collimate.wasm_sdk import Message
        _require_ctx()
        _history_list.append(Message(role=role, content=content))
        _history_dirty = True

    def __iter__(self) -> Iterator["Message"]:
        return iter(_history_list)

    def __len__(self) -> int:
        return len(_history_list)

    def __getitem__(self, idx):  # type: ignore[no-untyped-def]
        return _history_list[idx]

    def as_pai(self) -> list:
        """Translate the chat history into pydantic_ai ``ModelMessage``
        objects. Empty input yields an empty list — pydantic_ai treats
        that as a fresh chat. Lazily imports pydantic_ai so non-LLM
        generators never trigger the micropip install."""
        if not _history_list:
            return []
        from pydantic_ai.messages import (
            ModelRequest,
            ModelResponse,
            TextPart,
            UserPromptPart,
        )
        out: list = []
        for m in _history_list:
            if m.role == "user":
                out.append(ModelRequest(parts=[UserPromptPart(content=m.content or "")]))
            elif m.role == "assistant":
                out.append(ModelResponse(parts=[TextPart(content=m.content or "")]))
        return out


history = _History()


# ──────────────────────────────────────────────────────────────────────
# Secrets (two-tier)
# ──────────────────────────────────────────────────────────────────────


# Map our short provider names to the env var pydantic_ai's native
# provider lookup expects. Mirrors collimate.wasm_llm.PROVIDER_KEY_ENV
# but kept local so the secrets path doesn't pull in pydantic_ai.
_PROVIDER_KEY_ENV: dict[str, str] = {
    "groq": "GROQ_API_KEY",
    "cerebras": "CEREBRAS_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
}


async def api_key(
    provider: str,
    *,
    force: bool = False,
    description: str = "",
) -> str:
    """Resolve the API key for ``provider`` and set the standard env
    var so pydantic_ai's native provider lookup picks it up.

    Fast path: ``os.environ[{PROVIDER}_API_KEY]`` when set and not
    ``force``. Slow path: pops the in-cell modal; the user submits a
    fresh key, the keystore persists it, ``os.environ`` is updated.
    ``force=True`` skips the env-var fast path — the door for
    auth-error retry after a 401.

    Raises :class:`Cancelled` when the user cancels the modal.
    """
    ctx = _require_ctx()
    env_name = _PROVIDER_KEY_ENV.get(provider.lower(), "")
    if not env_name:
        raise ValueError(
            f"Unknown provider {provider!r}; expected one of "
            f"{sorted(_PROVIDER_KEY_ENV)}."
        )
    msg = description or f"API key for {provider} (used by this generator)"
    try:
        value = await ctx.get_key(env_name, description=msg, force=force)
    except Exception as exc:
        from collimate.wasm_sdk import KeyRequestCancelled
        if isinstance(exc, KeyRequestCancelled):
            raise Cancelled(str(exc)) from exc
        raise
    if value:
        os.environ[env_name] = value
    return value


async def secret(
    name: str,
    *,
    prompt_if_missing: bool = False,
    description: str = "",
) -> str:
    """Read a non-LLM secret (webhook tokens, custom service keys, …).

    Default is the env-var fast path only — returns the empty string
    when ``name`` isn't set. ``prompt_if_missing=True`` opts into the
    modal flow (raises :class:`Cancelled` on user cancel).
    """
    ctx = _require_ctx()
    fast = os.environ.get(name)
    if fast:
        return fast
    if not prompt_if_missing:
        return ""
    msg = description or f"Secret {name}"
    try:
        value = await ctx.get_key(name, description=msg, force=False)
    except Exception as exc:
        from collimate.wasm_sdk import KeyRequestCancelled
        if isinstance(exc, KeyRequestCancelled):
            raise Cancelled(str(exc)) from exc
        raise
    if value:
        os.environ[name] = value
    return value


# ──────────────────────────────────────────────────────────────────────
# Status / control
# ──────────────────────────────────────────────────────────────────────


def log(line: str) -> None:
    """Append a line to the run log (visible in the run events panel)."""
    _require_ctx().push_log(line)


def status(msg: str) -> None:
    """Set the live status string shown next to the run row."""
    _require_ctx().set_status(msg)


# ──────────────────────────────────────────────────────────────────────
# LLM convenience tier (opt-in sugar; lazily imports pydantic_ai)
# ──────────────────────────────────────────────────────────────────────


async def bootstrap() -> None:
    """Install pydantic_ai under pyodide and apply the pyfetch transport
    patch. Call this if you ``import pydantic_ai`` directly at module
    top level — :func:`agent` and :func:`file_tools` call it for you,
    so most generators never need to."""
    from collimate.wasm_llm import ensure_pydantic_ai
    await ensure_pydantic_ai()


async def agent(
    *,
    system_prompt: str = "",
    tools: Optional[list] = None,
    output_type: Optional[type] = None,
    provider: Optional[str] = None,
    model: Optional[str] = None,
    max_tokens: Optional[int] = None,
    config_file: str = "pydantic-config.set_yaml",
):
    """Build a configured pydantic_ai ``Agent``.

    Reads ``provider``/``model``/``max_tokens`` from the generator's
    ``pydantic-config.set_yaml`` when not overridden. Calls :func:`api_key`
    to resolve the key and populate the env var so the returned
    ``Agent`` works with pydantic_ai's native provider lookup. Lazily
    triggers ``ensure_pydantic_ai()`` (micropip install + jiter stub +
    pyfetch transport patch).

    The returned object is a vanilla ``pydantic_ai.Agent`` — call
    ``.run()`` / ``.run_stream()`` directly. We deliberately don't wrap
    its surface; pydantic_ai is the user-facing API for everything LLM.
    """
    from collimate.wasm_llm import build_agent

    cfg: dict = {}
    if provider is None or model is None or max_tokens is None:
        cfg = config(config_file) if isinstance(config(config_file), dict) else {}

    p = (provider or cfg.get("provider") or "cerebras").strip().lower()
    m = (model or cfg.get("model") or "llama3.1-8b").strip()
    mt = max_tokens
    if mt is None:
        raw = cfg.get("max_tokens")
        try:
            mt = int(raw)
            if mt <= 0:
                mt = 4096
        except (TypeError, ValueError):
            mt = 4096

    key = await api_key(p)
    return await build_agent(
        provider=p,
        model=m,
        api_key=key,
        system_prompt=system_prompt,
        tools=tools,
        output_type=output_type,
        max_tokens=mt,
    )


def file_tools() -> list:
    """Return list/read/write/edit pydantic_ai ``Tool`` objects bound
    to the output stage.

    Lets an agent walk and modify the staged output. ``read_file`` /
    ``list_files`` see input-cell files because the stage is
    pre-populated; ``write_file`` / ``edit_file`` mutate the stage so
    later :func:`update` calls reflect the agent's edits.

    All tools are ``async def`` because pyodide's threading stub raises
    ``RuntimeError: can't start new thread`` when pydantic_ai dispatches
    a sync tool via ``anyio.to_thread.run_sync``.
    """
    _require_ctx()
    from pydantic_ai import Tool

    async def list_files_t() -> list[str]:
        """List every file currently visible to the agent. Input-cell
        files are pre-staged; new writes appear here once ``write_file``
        returns."""
        return sorted(_stage.keys())

    async def read_file_t(path: str) -> str:
        """Read the full text of a staged file. For binary files
        (e.g. PNG plots written by ``run_python``), returns a short
        placeholder rather than the raw bytes — inspect those via the
        Python tool."""
        if path not in _stage:
            return f"ERROR: file not found: {path}"
        v = _stage[path]
        if isinstance(v, bytes):
            return f"BINARY ({len(v)} bytes) — read via the Python tool to inspect."
        return v

    async def write_file_t(path: str, content: str) -> str:
        """Create or overwrite ``path`` with ``content`` (UTF-8). For
        binary writes (images, archives), use the Python tool's
        ``write_bytes`` helper instead."""
        global _stage_dirty
        _stage[path] = content
        _stage_dirty = True
        return f"wrote {len(content)} bytes to {path}"

    async def edit_file_t(path: str, old: str, new: str) -> str:
        """First-match string replace inside ``path``. Errors if the
        file doesn't exist, isn't text, or ``old`` isn't found."""
        global _stage_dirty
        current = _stage.get(path)
        if current is None:
            return f"ERROR: file not found: {path}"
        if isinstance(current, bytes):
            return f"ERROR: {path} is binary — edit via the Python tool."
        if old not in current:
            return f"ERROR: old text not found in {path}"
        _stage[path] = current.replace(old, new, 1)
        _stage_dirty = True
        return f"edited {path}"

    return [
        Tool(list_files_t, name="list_files"),
        Tool(read_file_t, name="read_file"),
        Tool(write_file_t, name="write_file"),
        Tool(edit_file_t, name="edit_file"),
    ]


# Top-level-await flag for ``compile()`` (PEP 530, exposed since 3.8).
# Lets ``run_python`` accept ``await install("matplotlib")`` as plain
# top-level code instead of forcing the agent to wrap calls in
# ``asyncio.run`` (which doesn't work inside the wasm event loop).
_PYCF_ALLOW_TOP_LEVEL_AWAIT = 0x2000


def python_tool(
    *,
    files: Optional[dict[str, "str | bytes"]] = None,
) -> Any:
    """Return a pydantic_ai ``Tool`` that lets the agent execute Python.

    The agent calls ``run_python(code)`` with a string of Python; the
    code runs against a *persistent* namespace (re-used across calls in
    this run) with helpers pre-bound for cell-file I/O. Top-level
    ``await`` is supported (PyCF_ALLOW_TOP_LEVEL_AWAIT), so
    ``await install("matplotlib")`` works as plain top-level code.

    ``files`` selects what the helpers operate on:

      * ``None`` (default) — the singleton stage. Suitable for the
        non-fan-out shapes (single-input ``modify-files``, ``live-chat``).
      * a ``dict`` — the helpers close over that dict instead. Used by
        parallel fan-out branches so concurrent agents don't trample
        each other through the singleton stage.

    The tool surface (visible to the agent via the docstring on
    ``run_python``):

      * ``list_files() -> list[str]``
      * ``has_file(path) -> bool``
      * ``read_text(path) -> str`` — utf-8 decode if stored as bytes
      * ``read_bytes(path) -> bytes`` — utf-8 encode if stored as text
      * ``write_text(path, content)`` — staged as ``str``
      * ``write_bytes(path, content)`` — staged as ``bytes`` (PNG, …)
      * ``delete_file(path)``
      * ``await install(pkg)`` — pyodide-only; wraps ``micropip.install``

    stdout / stderr are captured per call. Exceptions land in stderr as
    a traceback; the tool itself never raises.
    """
    from pydantic_ai import Tool

    namespace: dict = {}

    # Parameterise file-store accessors so the run_python closure has a
    # single shape regardless of whether we're hitting the singleton
    # stage or a per-branch local dict.
    if files is None:
        def _list() -> list[str]:
            return sorted(_stage.keys())

        def _has(path: str) -> bool:
            return path in _stage

        def _get(path: str) -> "str | bytes":
            if path not in _stage:
                raise FileNotFoundError(path)
            return _stage[path]

        def _set(path: str, content: "str | bytes") -> None:
            global _stage_dirty
            _stage[path] = content
            _stage_dirty = True

        def _del(path: str) -> None:
            global _stage_dirty
            if path in _stage:
                del _stage[path]
                _stage_dirty = True
    else:
        store = files

        def _list() -> list[str]:
            return sorted(store.keys())

        def _has(path: str) -> bool:
            return path in store

        def _get(path: str) -> "str | bytes":
            if path not in store:
                raise FileNotFoundError(path)
            return store[path]

        def _set(path: str, content: "str | bytes") -> None:
            store[path] = content

        def _del(path: str) -> None:
            store.pop(path, None)

    def read_text(path: str) -> str:
        v = _get(path)
        return v.decode("utf-8") if isinstance(v, bytes) else v

    def read_bytes(path: str) -> bytes:
        v = _get(path)
        return v.encode("utf-8") if isinstance(v, str) else v

    def write_text(path: str, content: str) -> None:
        if not isinstance(content, str):
            raise TypeError("write_text content must be str")
        _set(path, content)

    def write_bytes(path: str, content: "bytes | bytearray | memoryview") -> None:
        if not isinstance(content, (bytes, bytearray, memoryview)):
            raise TypeError("write_bytes content must be bytes-like")
        _set(path, bytes(content))

    def has_file(path: str) -> bool:
        return _has(path)

    def list_files_helper() -> list[str]:
        return _list()

    def delete_file(path: str) -> None:
        _del(path)

    async def install(name: str) -> str:
        """Install a Python package via micropip. Pure-Python wheels
        and pyodide-bundled packages only — no native extensions."""
        try:
            import micropip  # type: ignore[import-not-found]
        except ImportError:
            return "ERROR: micropip is only available in the pyodide runtime"
        await micropip.install(name)
        return f"installed {name}"

    namespace.update(
        {
            "read_text": read_text,
            "read_bytes": read_bytes,
            "write_text": write_text,
            "write_bytes": write_bytes,
            "has_file": has_file,
            "list_files": list_files_helper,
            "delete_file": delete_file,
            "install": install,
        }
    )

    async def run_python(code: str) -> str:
        """Execute Python with access to the cell's files.

        Helpers in scope (no imports needed):

          - ``list_files() -> list[str]``
          - ``has_file(path) -> bool``
          - ``read_text(path) -> str``
          - ``read_bytes(path) -> bytes``
          - ``write_text(path, content)`` — text file
          - ``write_bytes(path, content)`` — binary (PNG, archive, …)
          - ``delete_file(path)``
          - ``await install(pkg)`` — micropip in pyodide

        Top-level ``await`` is supported. The namespace persists across
        calls in this run so you can build up state. stdout / stderr
        are captured and returned. Exceptions surface as tracebacks in
        stderr — the tool itself never raises.

        Save plots via ``write_bytes("plot.png", buf.getvalue())`` after
        ``plt.savefig(buf, format="png")``; SVG / HTML / JSON also work
        via ``write_text``.
        """
        import contextlib as _contextlib
        import io as _io
        import traceback as _traceback

        try:
            code_obj = compile(
                code,
                "<run_python>",
                "exec",
                flags=_PYCF_ALLOW_TOP_LEVEL_AWAIT,
            )
        except SyntaxError:
            return "## stderr\n" + _traceback.format_exc().rstrip()

        before = set(_list())
        out = _io.StringIO()
        err = _io.StringIO()
        try:
            with _contextlib.redirect_stdout(out), _contextlib.redirect_stderr(err):
                result = eval(code_obj, namespace)
                if asyncio.iscoroutine(result):
                    await result
        except BaseException:
            err.write(_traceback.format_exc())

        stdout = out.getvalue()
        stderr = err.getvalue()
        after = set(_list())
        added = sorted(after - before)
        removed = sorted(before - after)

        sections: list[str] = []
        if stdout:
            sections.append("## stdout\n" + stdout.rstrip())
        if stderr:
            sections.append("## stderr\n" + stderr.rstrip())
        if added:
            sections.append("## files_written\n" + "\n".join(f"- {p}" for p in added))
        if removed:
            sections.append("## files_removed\n" + "\n".join(f"- {p}" for p in removed))
        if not sections:
            sections.append("(no output)")
        return "\n\n".join(sections)

    return Tool(run_python, name="run_python")


__all__ = [
    "Cancelled",
    "agent",
    "api_key",
    "bootstrap",
    "chat_loop",
    "config",
    "create_stack_cell",
    "delete_file",
    "file_tools",
    "has_file",
    "history",
    "input_files",
    "input_groups",
    "list_files",
    "log",
    "next_message",
    "python_tool",
    "read_file",
    "read_input",
    "secret",
    "status",
    "update",
    "update_file",
]
