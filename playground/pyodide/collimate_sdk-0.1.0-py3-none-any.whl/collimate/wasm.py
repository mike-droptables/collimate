# SPDX-License-Identifier: Apache-2.0
"""Singleton runtime API for WASM generators.

The wasm runner sets up the singleton via :func:`_set_context` before
invoking ``run()``; the generator imports the top-level ``gen`` package
(a thin shim that re-exports this module) and reads/writes via the
``gen.*`` symbols. No ``ctx`` argument is passed to ``run()``.

The demo/WASM runtime is for pure-Python and CORS-safe-LLM generators
only. It cannot hold a real streaming WebSocket session, so the native
live-chat surface (``serve_chat`` / ``ChatTurn`` / ``agent_chat_turn``)
has no WASM equivalent — those symbols are native-only.

Two tiers:

  * **Core** (always available, no LLM dependency): inputs, file I/O,
    cells, API keys, status. A pure-Python generator uses only these.
  * **LLM helpers** (opt-in): :func:`agent`, :func:`file_tools`.
    Importing them lazily triggers ``ensure_pydantic_ai()`` (micropip
    install + pyfetch transport patch).

Cell operations are deliberately limited to two:

  * :func:`update` flushes the staged output (files) to the
    placeholder/top cell. May be called many times during a run; the
    last call before return is the final state.
  * :func:`create_stack_cell` adds a new cell below in the right-side
    stack. Used by fan-out generators (e.g. seed-ideas).

Calling ``update_file`` without ever calling ``update`` produces an
empty placeholder — explicit by design.
"""
from __future__ import annotations

from contextvars import ContextVar
from typing import TYPE_CHECKING, Any, Iterator, Optional
import asyncio
import os

if TYPE_CHECKING:
    from collimate.wasm_sdk import Message, WasmContext


# ──────────────────────────────────────────────────────────────────────
# Per-run state, scoped via asyncio ContextVar.
#
# ``_set_context()`` (called by the wasm runner) hydrates these before
# the generator's ``run()`` fires. ``_clear_context()`` wipes them on
# the way out. Each WASM run lives inside its own asyncio.Task and
# therefore its own contextvars context, so two concurrent WASM
# generators each see only their own state — without ContextVars,
# chat 2's ``_set_context`` would overwrite chat 1's globals and
# chat 1's subsequent ``gen.*`` calls would land on chat 2's cell.
#
# Generators never touch this state directly — they read/write
# through the public ``gen.*`` functions, which call the per-run
# accessors below.
# ──────────────────────────────────────────────────────────────────────

_ctx_var: ContextVar[Optional["WasmContext"]] = ContextVar("collimate_wasm_ctx", default=None)
# Stage values may be ``str`` (utf-8 text) or ``bytes`` (binary
# artifacts emitted by ``run_python`` etc.). The host bridge encodes
# bytes as base64 on the wire — see ``wasm_runner.WasmRunnerHost.emit_partial``.
_stage_var: ContextVar[dict[str, "str | bytes"]] = ContextVar("collimate_wasm_stage", default=None)  # type: ignore[arg-type]
_stage_dirty_var: ContextVar[bool] = ContextVar("collimate_wasm_stage_dirty", default=False)
_history_list_var: ContextVar[list["Message"]] = ContextVar("collimate_wasm_history", default=None)  # type: ignore[arg-type]
# Invocation type — one of ``"modify" | "create"`` — is the mode the
# user selected when invoking this generator. Set by the wasm runner
# from ``WasmContext.invocation_type`` so generators can branch via
# ``gen.invocation_type``. Empty string means unset.
_invocation_type_var: ContextVar[str] = ContextVar("collimate_wasm_invocation_type", default="")


def _stage_get() -> dict[str, "str | bytes"]:
    """Per-run staged-output dict. Lazily created on first access so
    each contextvars context sees its own dict (default of None means
    'not yet seeded')."""
    s = _stage_var.get()
    if s is None:
        s = {}
        _stage_var.set(s)
    return s


def _history_get() -> list["Message"]:
    """Per-run chat history list. Same lazy-init pattern as _stage_get."""
    h = _history_list_var.get()
    if h is None:
        h = []
        _history_list_var.set(h)
    return h


# ──────────────────────────────────────────────────────────────────────
# Public exception types
# ──────────────────────────────────────────────────────────────────────


# Re-exported from collimate.host_protocol so native + wasm share the
# same Cancelled class identity.
from collimate.host_protocol import Cancelled  # noqa: F401,E402


# ──────────────────────────────────────────────────────────────────────
# Runner hooks (private; called by api/process_manager/wasm_runner.py)
# ──────────────────────────────────────────────────────────────────────


def _set_context(ctx: "WasmContext") -> None:
    """Hydrate the per-run context before invoking ``run()``.

    Sets the contextvars for this asyncio task so two concurrent
    WASM generators don't trample each other's state. Each task
    gets its own ``_ctx_var``, ``_stage_var``.

    For **single-input** runs the output stage is pre-populated with
    every input-cell file so reads "just work" and unwritten files
    carry forward into the placeholder on the first ``update()`` call.
    Generators that want to drop files explicitly call
    :func:`delete_file`.

    For **multi-input** runs (workspace hydrated as ``inputs/NN_slug/``
    subfolders) the stage starts empty — those generators rebuild the
    output explicitly via :func:`input_groups` + :func:`update_file`.
    Auto-carrying the prefixed paths would land them in the output cell
    as-is, which is essentially never what a multi-input generator
    wants.
    """
    _ctx_var.set(ctx)
    stage: dict[str, "str | bytes"] = {}
    paths = ctx.workspace_files()
    is_multi_input = any(p.startswith("inputs/") for p in paths)
    if not is_multi_input:
        for p in paths:
            try:
                stage[p] = ctx.read_workspace_any(p)
            except OSError:
                continue
    _stage_var.set(stage)
    _stage_dirty_var.set(False)
    _history_list_var.set(list(ctx.messages))
    _invocation_type_var.set(ctx.invocation_type or "")


def _clear_context() -> None:
    """Wipe the per-run context after the run finishes."""
    _ctx_var.set(None)
    _stage_var.set({})
    _stage_dirty_var.set(False)
    _history_list_var.set([])
    _invocation_type_var.set("")


def _require_ctx() -> "WasmContext":
    ctx = _ctx_var.get()
    if ctx is None:
        raise RuntimeError(
            "gen.* used outside a generator run "
            "(wasm_runner._set_context was not called)"
        )
    return ctx


# ──────────────────────────────────────────────────────────────────────
# Module-level attribute hook.
#
# Lets generators read ``gen.prompt`` / ``gen.messages`` / ``gen.cancelled``
# as plain attributes that resolve against the current run's context.
# These are properties-of-a-module — Python supports this via
# ``__getattr__`` at module level (PEP 562).
# ──────────────────────────────────────────────────────────────────────


def __getattr__(name: str) -> Any:
    if name == "prompt":
        return _require_ctx().prompt
    if name == "messages":
        # Defensive copy — generators should never mutate a snapshot of
        # the prior chat history out from under the live ``history``
        # wrapper.
        return list(_require_ctx().messages)
    if name == "cancelled":
        return _require_ctx().cancelled
    if name == "invocation_type":
        return _invocation_type_var.get()
    raise AttributeError(f"module 'collimate.wasm' has no attribute {name!r}")


# ──────────────────────────────────────────────────────────────────────
# Input file I/O (read-only on parent cells)
# ──────────────────────────────────────────────────────────────────────


def read_input(path: str) -> "str | bytes":
    """Read a file from the input/parent cell workspace.

    Returns ``str`` for files that decode as utf-8, otherwise ``bytes``
    — auto-detected via :meth:`WasmContext.read_workspace_any`. Use
    ``ctx.read_workspace`` (text-only) or ``ctx.read_workspace_bytes``
    on the context directly when a specific representation is required.
    """
    return _require_ctx().read_workspace_any(path)


def input_files() -> dict[str, "str | bytes"]:
    """Return every input-cell file as ``{relpath: content}``.

    Convenience for generators that want a snapshot of all parent-cell
    files. Each value is ``str`` (utf-8 text) or ``bytes`` (binary).
    Files that fail to read are silently skipped (matches the behaviour
    of the duplicated ``_carry_forward`` helpers in the old generators).
    """
    ctx = _require_ctx()
    out: dict[str, "str | bytes"] = {}
    for p in ctx.workspace_files():
        try:
            out[p] = ctx.read_workspace_any(p)
        except OSError:
            continue
    return out


def input_groups() -> dict[str, dict[str, "str | bytes"]]:
    """Return input files grouped by source cell.

    For multi-cell input (workspace hydrated as ``inputs/NN_slug/...``),
    each top-level subfolder under ``inputs/`` becomes one group. Paths
    in each group dict are **relative to the cell root** (the
    ``inputs/NN_slug/`` prefix is stripped) so callers can re-emit them
    verbatim into the output stage. Values are ``str`` or ``bytes``
    depending on whether each file decodes as utf-8.

    For single-cell input (files at the workspace root), returns one
    group keyed ``"input"`` with the original paths.
    """
    ctx = _require_ctx()
    all_paths = ctx.workspace_files()
    inputs_prefix = "inputs/"
    under_inputs = [p for p in all_paths if p.startswith(inputs_prefix)]
    if not under_inputs:
        if not all_paths:
            return {}
        out_single: dict[str, "str | bytes"] = {}
        for p in all_paths:
            try:
                out_single[p] = ctx.read_workspace_any(p)
            except OSError:
                continue
        return {"input": out_single}

    raw: dict[str, dict[str, "str | bytes"]] = {}
    for p in under_inputs:
        rest = p[len(inputs_prefix):]
        label, _, sub = rest.partition("/")
        if not sub:
            continue
        try:
            content = ctx.read_workspace_any(p)
        except OSError:
            continue
        raw.setdefault(label, {})[sub] = content
    # Sort by label so the ``NN_slug`` ordering from the host's
    # hydrator is preserved — topmost input (smallest NN) ends up
    # first. Generators that resolve collisions "topmost wins" rely on
    # this iteration order.
    return {label: raw[label] for label in sorted(raw)}


# ──────────────────────────────────────────────────────────────────────
# Draft-file reader (one method, extension-detecting)
# ──────────────────────────────────────────────────────────────────────


def config(name: str) -> dict:
    """Read a draft file declared in the manifest's ``draft_files``.

    Always returns a dict. ``.set_yaml`` / ``.yaml`` / ``.yml`` parse
    as YAML (with ``fields:`` defaults merged into the ``values:`` block
    for schema-form files). ``.json`` parses as JSON. Other extensions
    return ``{}`` — use the workspace read helpers directly for raw
    text/binary content. Missing or malformed files yield ``{}`` so
    callers can use ``cfg.get(...)`` without try/except. Symmetric with
    native ``collimate.config``.
    """
    ctx = _require_ctx()
    lower = name.lower()
    if lower.endswith((".set_yaml", ".yaml", ".yml")):
        raw = ctx.config_yaml(name)
    elif lower.endswith(".json"):
        raw = ctx.config_json(name)
    else:
        raw = ctx.config(name)
    return raw if isinstance(raw, dict) else {}


# ──────────────────────────────────────────────────────────────────────
# Output stage (file I/O on the cell being written)
#
# The stage starts pre-populated with input files (see _set_context)
# so reads "just work". Writes mark _stage_dirty so the next ``update()``
# call has something to flush. ``update`` clears the dirty bit.
# ──────────────────────────────────────────────────────────────────────


def update_file(path: str, content: "str | bytes") -> None:
    """Stage a write to the output cell's file at ``path``.

    ``content`` may be ``str`` (utf-8 text) or ``bytes`` (binary
    artifacts — PNG plots, archives, etc.). The host bridge encodes the
    bytes path as base64 before persistence.

    The write is in-memory until the next :func:`update` call flushes
    the stage to the placeholder. Multiple ``update_file`` calls with
    the same path overwrite — the last write wins.
    """
    _require_ctx()
    if not isinstance(content, (str, bytes)):
        raise TypeError(
            f"update_file content must be str or bytes, got {type(content).__name__}"
        )
    _stage_get()[path] = content
    _stage_dirty_var.set(True)


def read_file(path: str) -> "str | bytes":
    """Read from the output stage. Input files carry forward by default
    (the stage is pre-populated in :func:`_set_context`), so this works
    for both unwritten input files and the generator's own writes.

    Returns ``str`` for text files, ``bytes`` for binary — caller can
    branch on ``isinstance(..., bytes)``.
    """
    _require_ctx()
    stage = _stage_get()
    if path not in stage:
        raise FileNotFoundError(path)
    return stage[path]


def has_file(path: str) -> bool:
    """Predicate over the output stage. Used by collision-aware
    generators (e.g. ``merge``) to skip files already staged by an
    earlier input."""
    _require_ctx()
    return path in _stage_get()


def list_files() -> list[str]:
    """Return every staged file's path, sorted."""
    _require_ctx()
    return sorted(_stage_get().keys())


def delete_file(path: str) -> None:
    """Drop a path from the output stage. No-op if not present."""
    _require_ctx()
    stage = _stage_get()
    if path in stage:
        del stage[path]
        _stage_dirty_var.set(True)


# ──────────────────────────────────────────────────────────────────────
# Cell operations — two only
# ──────────────────────────────────────────────────────────────────────


async def update(
    *,
    name: Optional[str] = None,
    summary: Optional[str] = None,
    pinned: Optional[str] = None,
) -> None:
    """Flush the current stage (files) to the placeholder/top cell.

    May be called many times during a run; each call refreshes the
    visible cell live (the host debounces persistence). The last call
    before return is the final state. **If ``update`` is never called,
    the placeholder is empty.**

    One method, one mental model: stage writes via :func:`update_file`
    (the open transcript :data:`history` writes is an ordinary
    one of these), flush them all together by calling :func:`update`.
    ``pinned`` is a per-call override of which staged file backs the
    cell-card preview (e.g. ``"index.md"``, ``"output.md"``,
    ``"why_picked.md"``).
    """
    ctx = _require_ctx()

    files = dict(_stage_get()) if _stage_dirty_var.get() else None

    await ctx.emit_partial(
        files=files,
        cell_name=name,
        summary=summary,
        pinned=pinned,
    )

    if files is not None:
        _stage_dirty_var.set(False)


async def create_stack_cell(
    name: str,
    *,
    summary: Optional[str] = None,
    pinned: Optional[str] = None,
    files: Optional[dict[str, "str | bytes"]] = None,
) -> str:
    """Add a new cell below in the (right-side) stack.

    If ``files`` is omitted, snapshots the current stage. Used by
    fan-out generators (e.g. ``seed-ideas``) to create N sibling cells
    while the placeholder/top cell holds an index. Values may be
    ``str`` or ``bytes`` (binary artifacts go through the host's
    base64 encoding path).

    Returns the new cell's id.
    """
    ctx = _require_ctx()
    snapshot = dict(_stage_get()) if files is None else files
    return await ctx.create_side_cell(
        name=name,
        summary=summary,
        pinned=pinned,
        files=snapshot,
    )


# ──────────────────────────────────────────────────────────────────────
# Chat history (a visible open-format transcript; collimate.transcript)
# ──────────────────────────────────────────────────────────────────────


_DEFAULT_TRANSCRIPT = "chats/main.json"


class _History:
    """In-memory chat transcript persisted to a visible open-format JSON file
    (``chats/main.json``; see :mod:`collimate.transcript`).

    ``append(role, content)`` updates the in-memory list and rewrites the
    transcript through the normal output stage (:func:`update_file`), so the
    next :func:`update` commits it as an ordinary versioned file — mirroring
    native's :class:`_History`. WASM is demo-only and has no live streaming
    chat, so there is no ``serve_chat``; a demo generator that wants a readable
    transcript appends here. ``as_pai()`` translates to pydantic_ai's
    ``ModelMessage`` shape.
    """

    def append(self, role: str, content: str) -> None:
        from collimate.wasm_sdk import Message
        _require_ctx()
        _history_get().append(Message(role=role, content=content))
        self._flush()

    def _flush(self) -> None:
        from collimate.transcript import serialize_transcript
        update_file(_DEFAULT_TRANSCRIPT, serialize_transcript(_history_get()))

    def __iter__(self) -> Iterator["Message"]:
        return iter(_history_get())

    def __len__(self) -> int:
        return len(_history_get())

    def __getitem__(self, idx):  # type: ignore[no-untyped-def]
        return _history_get()[idx]

    def as_pai(self) -> list:
        """Translate the chat history into pydantic_ai ``ModelMessage``
        objects. Empty input yields an empty list — pydantic_ai treats
        that as a fresh chat. Lazily imports pydantic_ai so non-LLM
        generators never trigger the micropip install."""
        history_list = _history_get()
        if not history_list:
            return []
        from pydantic_ai.messages import (
            ModelRequest,
            ModelResponse,
            TextPart,
            UserPromptPart,
        )
        out: list = []
        for m in history_list:
            if m.role == "user":
                out.append(ModelRequest(parts=[UserPromptPart(content=m.content or "")]))
            elif m.role == "assistant":
                out.append(ModelResponse(parts=[TextPart(content=m.content or "")]))
        return out


history = _History()


# ──────────────────────────────────────────────────────────────────────
# Secrets (two-tier)
# ──────────────────────────────────────────────────────────────────────


# Map our short provider names to the env var pydantic_ai's native
# provider lookup expects. Mirrors collimate.wasm_llm.PROVIDER_KEY_ENV
# but kept local so the secrets path doesn't pull in pydantic_ai.
_PROVIDER_KEY_ENV: dict[str, str] = {
    "groq": "GROQ_API_KEY",
    "cerebras": "CEREBRAS_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
}


async def api_key(
    provider: str,
    *,
    force: bool = False,
    description: str = "",
) -> str:
    """Resolve the API key for ``provider`` and set the standard env
    var so pydantic_ai's native provider lookup picks it up.

    Fast path: ``os.environ[{PROVIDER}_API_KEY]`` when set and not
    ``force``. Slow path: pops the in-cell modal; the user submits a
    fresh key, the keystore persists it, ``os.environ`` is updated.
    ``force=True`` skips the env-var fast path — the door for
    auth-error retry after a 401.

    Raises :class:`Cancelled` when the user cancels the modal.
    """
    ctx = _require_ctx()
    env_name = _PROVIDER_KEY_ENV.get(provider.lower(), "")
    if not env_name:
        raise ValueError(
            f"Unknown provider {provider!r}; expected one of "
            f"{sorted(_PROVIDER_KEY_ENV)}."
        )
    msg = description or f"API key for {provider} (used by this generator)"
    try:
        value = await ctx.get_key(env_name, description=msg, force=force)
    except Exception as exc:
        from collimate.wasm_sdk import KeyRequestCancelled
        if isinstance(exc, KeyRequestCancelled):
            raise Cancelled(str(exc)) from exc
        raise
    if value:
        os.environ[env_name] = value
    return value


async def secret(
    name: str,
    *,
    prompt_if_missing: bool = False,
    description: str = "",
) -> str:
    """Read a non-LLM secret (webhook tokens, custom service keys, …).

    Default is the env-var fast path only — returns the empty string
    when ``name`` isn't set. ``prompt_if_missing=True`` opts into the
    modal flow (raises :class:`Cancelled` on user cancel).
    """
    ctx = _require_ctx()
    fast = os.environ.get(name)
    if fast:
        return fast
    if not prompt_if_missing:
        return ""
    msg = description or f"Secret {name}"
    try:
        value = await ctx.get_key(name, description=msg, force=False)
    except Exception as exc:
        from collimate.wasm_sdk import KeyRequestCancelled
        if isinstance(exc, KeyRequestCancelled):
            raise Cancelled(str(exc)) from exc
        raise
    if value:
        os.environ[name] = value
    return value


# ──────────────────────────────────────────────────────────────────────
# Status / control
# ──────────────────────────────────────────────────────────────────────


def log(line: str) -> None:
    """Append a line to the run log (visible in the run events panel)."""
    _require_ctx().push_log(line)


def phase(name: str, message: str = "") -> None:
    """Set the run's lifecycle phase (``spinning_up`` / ``running`` /
    ``finishing``) — drives the cell's loading indicator. Failure is not a
    phase; signal it through the run outcome. See the native docs for details."""
    _require_ctx().set_phase(name, message)


def status(msg: str) -> None:
    """Update the live status message of the current phase (sugar for
    :func:`phase` that changes only the sub-message)."""
    _require_ctx().set_status(msg)


# ──────────────────────────────────────────────────────────────────────
# LLM convenience tier (opt-in sugar; lazily imports pydantic_ai)
# ──────────────────────────────────────────────────────────────────────


async def bootstrap() -> None:
    """Install pydantic_ai under pyodide and apply the pyfetch transport
    patch. Call this if you ``import pydantic_ai`` directly at module
    top level — :func:`agent` and :func:`file_tools` call it for you,
    so most generators never need to."""
    from collimate.wasm_llm import ensure_pydantic_ai
    await ensure_pydantic_ai()


async def agent(
    *,
    system_prompt: str = "",
    tools: Optional[list] = None,
    output_type: Optional[type] = None,
    provider: Optional[str] = None,
    model: Optional[str] = None,
    max_tokens: Optional[int] = None,
    config_file: str = "pydantic-config.set_yaml",
):
    """Build a configured pydantic_ai ``Agent``.

    Reads ``provider``/``model``/``max_tokens`` from the generator's
    ``pydantic-config.set_yaml`` when not overridden. Calls :func:`api_key`
    to resolve the key and populate the env var so the returned
    ``Agent`` works with pydantic_ai's native provider lookup. Lazily
    triggers ``ensure_pydantic_ai()`` (micropip install + jiter stub +
    pyfetch transport patch).

    The returned object is a vanilla ``pydantic_ai.Agent`` — call
    ``.run()`` / ``.run_stream()`` directly. We deliberately don't wrap
    its surface; pydantic_ai is the user-facing API for everything LLM.
    """
    from collimate.wasm_llm import build_agent

    cfg: dict = {}
    if provider is None or model is None or max_tokens is None:
        raw_cfg = config(config_file)
        cfg = raw_cfg if isinstance(raw_cfg, dict) else {}

    p = (provider or cfg.get("provider") or "cerebras").strip().lower()
    m = (model or cfg.get("model") or "llama3.1-8b").strip()
    mt = max_tokens
    if mt is None:
        raw = cfg.get("max_tokens")
        try:
            mt = int(raw)
            if mt <= 0:
                mt = 4096
        except (TypeError, ValueError):
            mt = 4096

    key = await api_key(p)
    return await build_agent(
        provider=p,
        model=m,
        api_key=key,
        system_prompt=system_prompt,
        tools=tools,
        output_type=output_type,
        max_tokens=mt,
    )


def file_tools() -> list:
    """Return list/read/write/edit pydantic_ai ``Tool`` objects bound
    to the output stage.

    Lets an agent walk and modify the staged output. ``read_file`` /
    ``list_files`` see input-cell files because the stage is
    pre-populated; ``write_file`` / ``edit_file`` mutate the stage so
    later :func:`update` calls reflect the agent's edits.

    All tools are ``async def`` because pyodide's threading stub raises
    ``RuntimeError: can't start new thread`` when pydantic_ai dispatches
    a sync tool via ``anyio.to_thread.run_sync``.
    """
    _require_ctx()
    from pydantic_ai import Tool

    async def list_files_t() -> list[str]:
        """List every file currently visible to the agent. Input-cell
        files are pre-staged; new writes appear here once ``write_file``
        returns."""
        return sorted(_stage_get().keys())

    async def read_file_t(path: str) -> str:
        """Read the full text of a staged file. For binary files
        (e.g. PNG plots written by ``run_python``), returns a short
        placeholder rather than the raw bytes — inspect those via the
        Python tool."""
        stage = _stage_get()
        if path not in stage:
            return f"ERROR: file not found: {path}"
        v = stage[path]
        if isinstance(v, bytes):
            return f"BINARY ({len(v)} bytes) — read via the Python tool to inspect."
        return v

    async def write_file_t(path: str, content: str) -> str:
        """Create or overwrite ``path`` with ``content`` (UTF-8). For
        binary writes (images, archives), use the Python tool's
        ``write_bytes`` helper instead."""
        _stage_get()[path] = content
        _stage_dirty_var.set(True)
        return f"wrote {len(content)} bytes to {path}"

    async def edit_file_t(path: str, old: str, new: str) -> str:
        """First-match string replace inside ``path``. Errors if the
        file doesn't exist, isn't text, or ``old`` isn't found."""
        stage = _stage_get()
        current = stage.get(path)
        if current is None:
            return f"ERROR: file not found: {path}"
        if isinstance(current, bytes):
            return f"ERROR: {path} is binary — edit via the Python tool."
        if old not in current:
            return f"ERROR: old text not found in {path}"
        stage[path] = current.replace(old, new, 1)
        _stage_dirty_var.set(True)
        return f"edited {path}"

    return [
        Tool(list_files_t, name="list_files"),
        Tool(read_file_t, name="read_file"),
        Tool(write_file_t, name="write_file"),
        Tool(edit_file_t, name="edit_file"),
    ]


# Top-level-await flag for ``compile()`` (PEP 530, exposed since 3.8).
# Lets ``run_python`` accept ``await install("matplotlib")`` as plain
# top-level code instead of forcing the agent to wrap calls in
# ``asyncio.run`` (which doesn't work inside the wasm event loop).
_PYCF_ALLOW_TOP_LEVEL_AWAIT = 0x2000


def python_tool_inline(
    *,
    files: Optional[dict[str, "str | bytes"]] = None,
) -> Any:
    """Return a pydantic_ai ``Tool`` that lets the agent execute Python.

    Named ``python_tool_inline`` (not ``python_tool``) to flag that wasm
    runs the agent's code **inline** in the same pyodide interpreter as
    the generator — a different execution model from native
    :func:`collimate.python_tool`, which spawns a fresh subprocess and
    diffs the workspace snapshot. The agent calls ``run_python(code)``
    with a string of Python; the code runs against a *persistent*
    namespace (re-used across calls in this run) with helpers pre-bound
    for cell-file I/O. Top-level ``await`` is supported
    (PyCF_ALLOW_TOP_LEVEL_AWAIT), so ``await install("matplotlib")``
    works as plain top-level code.

    ``files`` selects what the helpers operate on:

      * ``None`` (default) — the singleton stage. Suitable for the
        non-fan-out shapes (single-input ``modify-files``, ``live-chat``).
      * a ``dict`` — the helpers close over that dict instead. Used by
        parallel fan-out branches so concurrent agents don't trample
        each other through the singleton stage.

    The tool surface (visible to the agent via the docstring on
    ``run_python``):

      * ``list_files() -> list[str]``
      * ``has_file(path) -> bool``
      * ``read_text(path) -> str`` — utf-8 decode if stored as bytes
      * ``read_bytes(path) -> bytes`` — utf-8 encode if stored as text
      * ``write_text(path, content)`` — staged as ``str``
      * ``write_bytes(path, content)`` — staged as ``bytes`` (PNG, …)
      * ``delete_file(path)``
      * ``await install(pkg)`` — pyodide-only; wraps ``micropip.install``

    stdout / stderr are captured per call. Exceptions land in stderr as
    a traceback; the tool itself never raises.
    """
    from pydantic_ai import Tool

    namespace: dict = {}

    # Parameterise file-store accessors so the run_python closure has a
    # single shape regardless of whether we're hitting the singleton
    # stage or a per-branch local dict.
    if files is None:
        def _list() -> list[str]:
            return sorted(_stage_get().keys())

        def _has(path: str) -> bool:
            return path in _stage_get()

        def _get(path: str) -> "str | bytes":
            stage = _stage_get()
            if path not in stage:
                raise FileNotFoundError(path)
            return stage[path]

        def _set(path: str, content: "str | bytes") -> None:
            _stage_get()[path] = content
            _stage_dirty_var.set(True)

        def _del(path: str) -> None:
            stage = _stage_get()
            if path in stage:
                del stage[path]
                _stage_dirty_var.set(True)
    else:
        store = files

        def _list() -> list[str]:
            return sorted(store.keys())

        def _has(path: str) -> bool:
            return path in store

        def _get(path: str) -> "str | bytes":
            if path not in store:
                raise FileNotFoundError(path)
            return store[path]

        def _set(path: str, content: "str | bytes") -> None:
            store[path] = content

        def _del(path: str) -> None:
            store.pop(path, None)

    def read_text(path: str) -> str:
        v = _get(path)
        return v.decode("utf-8") if isinstance(v, bytes) else v

    def read_bytes(path: str) -> bytes:
        v = _get(path)
        return v.encode("utf-8") if isinstance(v, str) else v

    def write_text(path: str, content: str) -> None:
        if not isinstance(content, str):
            raise TypeError("write_text content must be str")
        _set(path, content)

    def write_bytes(path: str, content: "bytes | bytearray | memoryview") -> None:
        if not isinstance(content, (bytes, bytearray, memoryview)):
            raise TypeError("write_bytes content must be bytes-like")
        _set(path, bytes(content))

    def has_file(path: str) -> bool:
        return _has(path)

    def list_files_helper() -> list[str]:
        return _list()

    def delete_file(path: str) -> None:
        _del(path)

    async def install(name: str) -> str:
        """Install a Python package via micropip. Pure-Python wheels
        and pyodide-bundled packages only — no native extensions."""
        try:
            import micropip  # type: ignore[import-not-found]
        except ImportError:
            return "ERROR: micropip is only available in the pyodide runtime"
        await micropip.install(name)
        return f"installed {name}"

    namespace.update(
        {
            "read_text": read_text,
            "read_bytes": read_bytes,
            "write_text": write_text,
            "write_bytes": write_bytes,
            "has_file": has_file,
            "list_files": list_files_helper,
            "delete_file": delete_file,
            "install": install,
        }
    )

    async def run_python(code: str) -> str:
        """Execute Python with access to the cell's files.

        Helpers in scope (no imports needed):

          - ``list_files() -> list[str]``
          - ``has_file(path) -> bool``
          - ``read_text(path) -> str``
          - ``read_bytes(path) -> bytes``
          - ``write_text(path, content)`` — text file
          - ``write_bytes(path, content)`` — binary (PNG, archive, …)
          - ``delete_file(path)``
          - ``await install(pkg)`` — micropip in pyodide

        Top-level ``await`` is supported. The namespace persists across
        calls in this run so you can build up state. stdout / stderr
        are captured and returned. Exceptions surface as tracebacks in
        stderr — the tool itself never raises.

        Save plots via ``write_bytes("plot.png", buf.getvalue())`` after
        ``plt.savefig(buf, format="png")``; SVG / HTML / JSON also work
        via ``write_text``.
        """
        import contextlib as _contextlib
        import io as _io
        import traceback as _traceback

        try:
            code_obj = compile(
                code,
                "<run_python>",
                "exec",
                flags=_PYCF_ALLOW_TOP_LEVEL_AWAIT,
            )
        except SyntaxError:
            return "## stderr\n" + _traceback.format_exc().rstrip()

        before = set(_list())
        out = _io.StringIO()
        err = _io.StringIO()
        try:
            with _contextlib.redirect_stdout(out), _contextlib.redirect_stderr(err):
                result = eval(code_obj, namespace)
                if asyncio.iscoroutine(result):
                    await result
        except BaseException:
            err.write(_traceback.format_exc())

        stdout = out.getvalue()
        stderr = err.getvalue()
        after = set(_list())
        added = sorted(after - before)
        removed = sorted(before - after)

        sections: list[str] = []
        if stdout:
            sections.append("## stdout\n" + stdout.rstrip())
        if stderr:
            sections.append("## stderr\n" + stderr.rstrip())
        if added:
            sections.append("## files_written\n" + "\n".join(f"- {p}" for p in added))
        if removed:
            sections.append("## files_removed\n" + "\n".join(f"- {p}" for p in removed))
        if not sections:
            sections.append("(no output)")
        return "\n\n".join(sections)

    return Tool(run_python, name="run_python")


__all__ = [
    "Cancelled",
    "agent",
    "api_key",
    "bootstrap",
    "config",
    "create_stack_cell",
    "delete_file",
    "file_tools",
    "has_file",
    "history",
    "input_files",
    "input_groups",
    "list_files",
    "log",
    "phase",
    "python_tool_inline",
    "read_file",
    "read_input",
    "secret",
    "status",
    "update",
    "update_file",
]
