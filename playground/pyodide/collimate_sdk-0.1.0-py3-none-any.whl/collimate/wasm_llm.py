"""Shared helpers for wasm LLM generators.

Wires a ``pydantic-ai`` Agent against one of four OpenAI-compatible
providers (Gemini, Groq, Cerebras, OpenRouter) and exposes workspace
files either inline (small inputs) or as callable tools (larger inputs).

Under pyodide, ``pydantic-ai-slim[openai]`` is installed on first use via
``micropip``. httpx is already patched to route through Fetch, so Agent
calls go straight to each provider; all four allow browser CORS for
their public APIs.

Usage (typical wasm generator)::

    from collimate.wasm_llm import (
        build_agent, files_context_block, resolve_api_key,
    )

    async def run(ctx):
        s = ctx.config_yaml("settings.set_yaml")
        provider = s.get("provider", "gemini")
        api_key = resolve_api_key(ctx, provider, s.get("api_key", ""))

        ctx_block, tools = files_context_block(ctx)
        agent = await build_agent(
            provider=provider,
            model=s.get("model", "gemini-2.0-flash"),
            api_key=api_key,
            system_prompt=s.get("system_prompt", "") + ctx_block,
            tools=tools,
        )
        result = await agent.run(prompt)
        ...
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from collimate.wasm_sdk import WasmContext


PROVIDER_BASE_URLS: dict[str, str] = {
    "gemini": "https://generativelanguage.googleapis.com/v1beta/openai",
    "groq": "https://api.groq.com/openai/v1",
    "cerebras": "https://api.cerebras.ai/v1",
    "openrouter": "https://openrouter.ai/api/v1",
}

PROVIDER_KEY_ENV: dict[str, str] = {
    "gemini": "GEMINI_API_KEY",
    "groq": "GROQ_API_KEY",
    "cerebras": "CEREBRAS_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
}

# Above this, files become tools instead of inline context.
INLINE_FILE_THRESHOLD = 5


async def ensure_pydantic_ai() -> None:
    """Import pydantic-ai, installing via micropip on first use in pyodide."""
    try:
        import pydantic_ai  # noqa: F401
        return
    except ImportError:
        pass
    try:
        import micropip
    except ImportError as exc:
        raise RuntimeError(
            "pydantic-ai is not installed and micropip is unavailable. "
            "Add `pydantic-ai-slim[openai]` to your environment."
        ) from exc
    await micropip.install("pydantic-ai-slim[openai]", keep_going=True)


def resolve_api_key(ctx: "WasmContext", provider: str, override: str = "") -> str:
    """Per-cell override wins; otherwise read the provider's keystore env."""
    if override and override.strip():
        return override.strip()
    env_name = PROVIDER_KEY_ENV.get((provider or "").lower(), "")
    return ctx.secret(env_name) if env_name else ""


async def build_agent(
    *,
    provider: str,
    model: str,
    api_key: str,
    system_prompt: str = "",
    tools: Optional[list] = None,
    output_type: Optional[type] = None,
):
    """Return a configured ``pydantic_ai.Agent``.

    Raises ValueError for unknown providers or missing keys — generators
    should surface the error text into the output cell so the user
    learns what's missing instead of seeing a failed run.
    """
    await ensure_pydantic_ai()
    from pydantic_ai import Agent
    from pydantic_ai.models.openai import OpenAIModel
    from pydantic_ai.providers.openai import OpenAIProvider

    key = (provider or "gemini").lower()
    base_url = PROVIDER_BASE_URLS.get(key)
    if not base_url:
        raise ValueError(
            f"Unknown provider {provider!r}; expected one of "
            f"{sorted(PROVIDER_BASE_URLS)}."
        )
    if not api_key:
        raise ValueError(
            f"Missing {PROVIDER_KEY_ENV[key]}. Set it in Settings → Keys "
            f"or paste a per-cell override in Draft."
        )

    openai_provider = OpenAIProvider(base_url=base_url, api_key=api_key)
    pa_model = OpenAIModel(model, provider=openai_provider)
    kwargs: dict = {
        "model": pa_model,
        "system_prompt": system_prompt or "",
        "tools": tools or [],
    }
    if output_type is not None:
        kwargs["output_type"] = output_type
    return Agent(**kwargs)


def preview_workspace_files(
    ctx: "WasmContext",
    paths: Optional[list[str]] = None,
    max_bytes: int = 4000,
) -> str:
    """Render up to ``max_bytes`` of each file as a markdown block."""
    paths = paths if paths is not None else ctx.workspace_files()
    if not paths:
        return "_(no input files)_"
    out: list[str] = []
    for p in paths:
        try:
            content = ctx.read_workspace(p)
        except OSError as e:
            out.append(f"### `{p}`\n\n_(read failed: {e})_")
            continue
        if len(content) > max_bytes:
            content = (
                content[:max_bytes]
                + f"\n\n_(truncated — full size {len(content)} bytes)_"
            )
        out.append(f"### `{p}`\n\n```\n{content}\n```")
    return "\n\n".join(out)


def make_file_tools(ctx: "WasmContext") -> list:
    """Return pydantic-ai Tool objects letting the agent walk the workspace."""
    from pydantic_ai import Tool

    def list_files() -> list[str]:
        """List every input file. Paths are relative to the workspace
        root and can be passed directly to ``read_file``."""
        return ctx.workspace_files()

    def read_file(path: str) -> str:
        """Read a workspace file and return its full text content. Use
        ``list_files`` first to learn the available paths."""
        try:
            return ctx.read_workspace(path)
        except FileNotFoundError:
            return f"ERROR: file not found: {path}"
        except OSError as e:
            return f"ERROR: could not read {path}: {e}"

    return [Tool(list_files), Tool(read_file)]


def files_context_block(
    ctx: "WasmContext",
    paths: Optional[list[str]] = None,
) -> tuple[str, list]:
    """Build a ``(system_prompt_suffix, tools)`` pair for the file context.

    Under ``INLINE_FILE_THRESHOLD`` files, everything is inlined into the
    prompt and no tools are returned. At or above the threshold, only a
    listing goes into the prompt and ``read_file`` / ``list_files`` are
    returned as tools.
    """
    paths = paths if paths is not None else ctx.workspace_files()
    if not paths:
        return "", []
    if len(paths) < INLINE_FILE_THRESHOLD:
        return (
            "\n\n## Input files (inline)\n\n" + preview_workspace_files(ctx, paths),
            [],
        )
    listing = "\n".join(f"- `{p}`" for p in paths)
    return (
        f"\n\n## Input files ({len(paths)})\n\n{listing}\n\n"
        "Use `list_files` / `read_file` to inspect contents as needed.",
        make_file_tools(ctx),
    )


def group_inputs_by_cell(ctx: "WasmContext") -> list[tuple[str, list[str]]]:
    """Split workspace files by input cell.

    Returns ``[(label, [relpath, ...])]``. For a single input (files at
    the workspace root) returns one entry with label ``"input"``. For
    multi-input hydration (``inputs/NN_slug/``) each top-level subfolder
    under ``inputs/`` becomes one group."""
    all_paths = ctx.workspace_files()
    inputs_prefix = "inputs/"
    under_inputs = [p for p in all_paths if p.startswith(inputs_prefix)]
    if not under_inputs:
        return [("input", all_paths)] if all_paths else []

    groups: dict[str, list[str]] = {}
    for p in under_inputs:
        rest = p[len(inputs_prefix):]
        label, _, _ = rest.partition("/")
        groups.setdefault(label, []).append(p)
    return [(label, sorted(paths)) for label, paths in sorted(groups.items())]


__all__ = [
    "PROVIDER_BASE_URLS",
    "PROVIDER_KEY_ENV",
    "INLINE_FILE_THRESHOLD",
    "ensure_pydantic_ai",
    "resolve_api_key",
    "build_agent",
    "preview_workspace_files",
    "make_file_tools",
    "files_context_block",
    "group_inputs_by_cell",
]
