# SPDX-License-Identifier: Apache-2.0
"""Shared helpers for wasm LLM generators.

Wires a ``pydantic-ai`` Agent against one of three OpenAI-compatible
providers (Groq, Cerebras, OpenRouter) and exposes workspace files
either inline (small inputs) or as callable tools (larger inputs).

Under pyodide, ``pydantic-ai-slim[openai]`` is installed on first use
via ``micropip``. ``ensure_pydantic_ai`` also installs an httpx
``AsyncBaseTransport`` that routes through ``js.fetch`` so Agent calls
work without raw sockets. The three providers above explicitly allow
browser-origin CORS; Gemini's openai-compatible endpoint does not, and
Anthropic / OpenAI direct endpoints don't either, so they are out of
scope for the wasm playground (use them through a server-side path or
from the native runtime).

Usage (typical wasm generator)::

    from collimate.wasm_llm import (
        build_agent, files_context_block, resolve_api_key,
    )

    async def run(ctx):
        s = ctx.config_yaml("settings.set_yaml")
        provider = s.get("provider", "groq")
        api_key = await resolve_api_key(ctx, provider)

        ctx_block, tools = files_context_block(ctx)
        agent = await build_agent(
            provider=provider,
            model=s.get("model", "openai/gpt-oss-20b"),
            api_key=api_key,
            system_prompt=s.get("system_prompt", "") + ctx_block,
            tools=tools,
        )
        result = await agent.run(prompt)
        ...
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from collimate.wasm_sdk import WasmContext


PROVIDER_BASE_URLS: dict[str, str] = {
    "groq": "https://api.groq.com/openai/v1",
    "cerebras": "https://api.cerebras.ai/v1",
    "openrouter": "https://openrouter.ai/api/v1",
}

PROVIDER_KEY_ENV: dict[str, str] = {
    "groq": "GROQ_API_KEY",
    "cerebras": "CEREBRAS_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
}

# Above this, files become tools instead of inline context.
INLINE_FILE_THRESHOLD = 5


async def ensure_pydantic_ai() -> None:
    """Import pydantic-ai, installing via micropip on first use in pyodide."""
    try:
        import pydantic_ai  # noqa: F401
        # Already installed — still re-apply http patches below in case
        # this is the first call after a fresh httpx import.
        _already_installed = True
    except ImportError:
        _already_installed = False
    try:
        import micropip
    except ImportError as exc:
        raise RuntimeError(
            "pydantic-ai is not installed and micropip is unavailable. "
            "Add `pydantic-ai-slim[openai]` to your environment."
        ) from exc
    # ``jiter`` is a Rust-built JSON parser pulled in by the openai SDK
    # for streaming response parsing; pyodide doesn't ship a wasm wheel
    # for it and PyPI's wheels aren't emscripten-built, so micropip
    # raises ``ValueError: Can't find a pure Python 3 wheel`` before
    # ``keep_going`` can kick in. Register a mock that satisfies the
    # ``jiter<1,>=0.10`` constraint so the resolver moves on. The
    # non-streaming code path through pydantic-ai → openai doesn't
    # call into jiter, so the live-chat generator works; a streaming
    # path would surface ``ImportError`` from the call site itself,
    # which is fine.
    # The empty default mock isn't enough — openai's SDK does
    # ``from jiter import from_json`` at module import time, so the
    # stub has to expose that symbol. Wrap stdlib ``json.loads`` to
    # cover the common path (bytes-or-str → parsed object). The real
    # jiter accepts more kwargs (``allow_inf_nan``, ``cache_mode``,
    # ``partial_mode``, …) — we accept and ignore them so calls don't
    # raise TypeError; behaviour-wise json.loads is a strict superset
    # for valid JSON, which is what openai feeds it.
    _jiter_stub_src = (
        "import json as _json\n"
        "def from_json(data, *args, **kwargs):\n"
        "    if isinstance(data, (bytes, bytearray, memoryview)):\n"
        "        data = bytes(data).decode('utf-8')\n"
        "    return _json.loads(data)\n"
    )
    try:
        micropip.add_mock_package(
            "jiter", "0.10.0", modules={"jiter": _jiter_stub_src},
        )
    except ValueError:
        # Already mocked from an earlier ensure_pydantic_ai() call —
        # micropip raises ValueError on duplicate registration.
        pass

    # Pin under the version that bumped pydantic's floor to >=2.12 —
    # pyodide 0.28 ships pydantic 2.10.6 baked into its wasm package
    # set, and you can't drop in a newer pydantic_core via micropip
    # because PyPI's wheels aren't emscripten-built. Bump this cap
    # when pyodide updates pydantic.
    if not _already_installed:
        await micropip.install("pydantic-ai-slim[openai]<0.3")

    # Route urllib/urllib3/httpx through ``js.fetch`` instead of raw
    # sockets (which don't exist in the browser). Has to run *after*
    # the install above brings in httpx — ``patch_all()`` only patches
    # modules that are importable when it runs, so calling it earlier
    # silently no-ops on httpx and every Agent.run then raises
    # ``ConnectError`` because the underlying TCP connect fails.
    # ``pyodide_http`` ships with pyodide as a pre-built wasm package;
    # fall back to a micropip install if for any reason it isn't pre-
    # loaded. Idempotent — safe to re-run on every ensure_pydantic_ai
    # call.
    try:
        import pyodide_http  # type: ignore[import-not-found]
    except ImportError:
        try:
            await micropip.install("pyodide-http")
            import pyodide_http  # type: ignore[import-not-found]
        except Exception:
            pyodide_http = None  # type: ignore[assignment]
    if pyodide_http is not None:
        pyodide_http.patch_all()
        print("[wasm_llm] pyodide_http.patch_all() applied")
    else:
        print("[wasm_llm] WARNING: pyodide_http unavailable — httpx will use raw sockets and fail in the browser")


async def resolve_api_key(
    ctx: "WasmContext",
    provider: str,
    override: str = "",
    *,
    description: Optional[str] = None,
    force: bool = False,
) -> str:
    """Per-cell override wins; otherwise resolve via the modal flow.

    Async because it may need to prompt the user. Behaviour:

      1. ``override`` is taken verbatim when non-blank — *unless*
         ``force=True``. Per-cell keys from draft input go here.
      2. Otherwise ``await ctx.get_key(env_name, force=...)`` fast-
         paths off ``os.environ`` and only prompts if the key is
         missing (or always prompts when ``force=True``).

    ``force=True`` is the auth-retry door: when the LLM returns 401
    you can call ``resolve_api_key(ctx, provider, force=True,
    description="Previous {provider} key was rejected")`` to re-prompt
    with the rejection hint. Both ``override`` and the ``os.environ``
    fast path are bypassed so the user actually sees the modal.

    Raises :class:`collimate.wasm_sdk.KeyRequestCancelled` if the user
    cancelled the modal — generators should let it propagate so the
    wasm dispatcher finalises the run cleanly.

    Returns ``""`` only when the provider name is unknown (no env var
    mapping) — preserves the prior contract so callers can still emit
    a "missing key" stub in that case.
    """
    if not force and override and override.strip():
        return override.strip()
    env_name = PROVIDER_KEY_ENV.get((provider or "").lower(), "")
    if not env_name:
        return ""
    msg = description or f"API key for {provider} (used by this generator)"
    return await ctx.get_key(env_name, description=msg, force=force)


def _build_wasm_async_client():
    """Return an ``httpx.AsyncClient`` that routes through ``js.fetch``.

    Always builds a client with a custom ``AsyncBaseTransport`` rather
    than trusting global monkey-patches, because:
      * pyodide_http's httpx async support varies by version.
      * openai's SDK creates httpx clients lazily and may bypass the
        global patches if any module-level state was captured first.

    Outside pyodide (``js`` import fails) the transport falls back to
    httpx's default — generators don't normally run there, but unit
    tests instantiating the client directly stay green.
    """
    import httpx

    try:
        from pyodide.http import pyfetch  # type: ignore[import-not-found]
    except ImportError:
        return httpx.AsyncClient()

    class _PyfetchTransport(httpx.AsyncBaseTransport):
        async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            method = request.method
            headers = {k.decode() if isinstance(k, bytes) else k:
                       v.decode() if isinstance(v, bytes) else v
                       for k, v in request.headers.raw}
            body = request.content if request.content else None
            kwargs: dict = {"method": method, "headers": headers}
            if body is not None:
                kwargs["body"] = body
            try:
                resp = await pyfetch(url, **kwargs)
            except Exception as exc:
                # ``pyodide.http.AbortError: Failed to fetch`` is what
                # the browser hands back on a CORS-blocked preflight,
                # a network drop, or a DNS failure. The string ``exc``
                # gives is just "Failed to fetch" — useless to a user.
                # Wrap with a hint pointing at the most common cause.
                from pyodide.http import AbortError  # type: ignore[import-not-found]
                if isinstance(exc, AbortError):
                    raise httpx.ConnectError(
                        f"Browser blocked fetch to {url} — most often this "
                        "means the LLM provider's API doesn't allow browser "
                        "CORS. The wasm playground only supports providers "
                        "that opt in (groq, cerebras, openrouter); call "
                        "any other provider through a server-side proxy."
                    ) from exc
                raise
            data = await resp.bytes()
            # FetchResponse exposes headers differently across pyodide
            # versions (.headers as dict, or only .js_response.headers).
            # Try the python-friendly path first; fall back to walking
            # the JS Headers object via entries().
            resp_headers: list[tuple[str, str]] = []
            try:
                pyhdrs = getattr(resp, "headers", None)
                if isinstance(pyhdrs, dict):
                    resp_headers = [(str(k), str(v)) for k, v in pyhdrs.items()]
                else:
                    js_resp = getattr(resp, "js_response", None)
                    if js_resp is not None:
                        for entry in js_resp.headers.entries():
                            resp_headers.append((str(entry[0]), str(entry[1])))
            except Exception:
                pass
            return httpx.Response(
                status_code=resp.status,
                headers=resp_headers,
                content=data,
                request=request,
            )

    return httpx.AsyncClient(transport=_PyfetchTransport())


async def _force_strict_false(ctx, tool_defs):
    # ``async`` so the v0.2-era ``pydantic-ai-slim<0.3`` we pin under
    # pyodide can ``await`` the result unconditionally. Newer versions
    # check ``inspect.isawaitable`` first and accept either form.
    from dataclasses import replace
    return [replace(t, strict=False) for t in tool_defs]


async def build_agent(
    *,
    provider: str,
    model: str,
    api_key: str,
    system_prompt: str = "",
    tools: Optional[list] = None,
    output_type: Optional[type] = None,
    max_tokens: Optional[int] = None,
):
    """Return a configured ``pydantic_ai.Agent``.

    Raises ValueError for unknown providers or missing keys — generators
    should surface the error text into the output cell so the user
    learns what's missing instead of seeing a failed run.
    """
    await ensure_pydantic_ai()
    from pydantic_ai import Agent
    from pydantic_ai.models.openai import OpenAIModel
    from pydantic_ai.providers.openai import OpenAIProvider

    key = (provider or "groq").lower()
    base_url = PROVIDER_BASE_URLS.get(key)
    if not base_url:
        raise ValueError(
            f"Unknown provider {provider!r}; expected one of "
            f"{sorted(PROVIDER_BASE_URLS)}."
        )
    if not api_key:
        raise ValueError(
            f"Missing {PROVIDER_KEY_ENV[key]}. Set it in Settings → Keys "
            f"or paste a per-cell override in Draft."
        )

    # Hand the provider an explicit httpx.AsyncClient. Under pyodide
    # the default client tries to open raw TCP sockets and fails; a
    # locally-built client picks up whatever transport pyodide_http
    # patched ``httpx.AsyncHTTPTransport`` to use. If pyodide_http's
    # patching missed the async path (some versions do), build a custom
    # transport that calls ``pyodide.http.pyfetch`` directly so we
    # never depend on socket-level networking.
    http_client = _build_wasm_async_client()
    openai_provider = OpenAIProvider(
        base_url=base_url, api_key=api_key, http_client=http_client,
    )
    pa_model = OpenAIModel(model, provider=openai_provider)
    kwargs: dict = {
        "model": pa_model,
        "system_prompt": system_prompt or "",
        "tools": tools or [],
        # Force ``strict=False`` on every tool. pydantic-ai otherwise
        # infers ``strict`` per-tool from each schema's ``is_strict_compatible``,
        # so a mix of strict-compatible and non-compatible tools emits
        # mixed ``strict`` values on the wire — Cerebras rejects that
        # with "tools with mixed values for 'strict' are not allowed".
        "prepare_tools": _force_strict_false,
        # pydantic-ai's default ``retries=1`` is too aggressive for
        # open-weight models (Llama, Mixtral) on Groq/Cerebras — they
        # frequently emit one slightly-malformed tool call (missing
        # required field, wrong arg name) before correcting on the
        # validation feedback. 1 retry means *one chance to fix* it,
        # so a single shaky first call kills the whole turn with the
        # bare "exceeded max retries count of 1" error. 3 retries
        # gives the model enough room to converge without papering
        # over a genuinely broken tool schema.
        "retries": 3,
        # Disable OpenTelemetry instrumentation. pydantic-ai wraps
        # tool dispatch in spans recorded via ``BatchSpanProcessor``,
        # which spawns a worker thread on first export — pyodide's
        # threading stub raises ``RuntimeError: can't start new
        # thread`` and the run dies the moment a tool fires. We have
        # no OTel collector connected in the playground anyway, so
        # the spans are being recorded for nobody. ``instrument=False``
        # short-circuits the wrap entirely; tool execution itself is
        # unaffected (instrumentation is purely observability).
        "instrument": False,
    }
    if output_type is not None:
        kwargs["output_type"] = output_type
    if max_tokens is not None:
        # Bake the cap into the agent's default settings so generators
        # don't have to thread ``ModelSettings(max_tokens=...)`` through
        # every ``.run()`` call. Per-call ``model_settings`` still
        # overrides this when the generator wants different settings
        # for a particular turn.
        from pydantic_ai.settings import ModelSettings
        kwargs["model_settings"] = ModelSettings(max_tokens=max_tokens)
    return Agent(**kwargs)


def preview_workspace_files(
    ctx: "WasmContext",
    paths: Optional[list[str]] = None,
    max_bytes: int = 4000,
) -> str:
    """Render up to ``max_bytes`` of each file as a markdown block."""
    paths = paths if paths is not None else ctx.workspace_files()
    if not paths:
        return "_(no input files)_"
    out: list[str] = []
    for p in paths:
        try:
            content = ctx.read_workspace(p)
        except UnicodeDecodeError:
            try:
                size = len(ctx.read_workspace_bytes(p))
            except OSError:
                size = 0
            out.append(f"### `{p}`\n\n_(binary, {size} bytes — not previewed)_")
            continue
        except OSError as e:
            out.append(f"### `{p}`\n\n_(read failed: {e})_")
            continue
        if len(content) > max_bytes:
            content = (
                content[:max_bytes]
                + f"\n\n_(truncated — full size {len(content)} bytes)_"
            )
        out.append(f"### `{p}`\n\n```\n{content}\n```")
    return "\n\n".join(out)


def make_file_tools(ctx: "WasmContext") -> list:
    """Return pydantic-ai Tool objects letting the agent walk the workspace.

    Tools are ``async def`` so pydantic-ai awaits them directly instead
    of dispatching via ``anyio.to_thread.run_sync`` — pyodide's
    threading stub raises ``RuntimeError: can't start new thread``, so
    a sync tool kills any agent that calls it. Wasm generators built
    on top of these helpers get the right behaviour automatically."""
    from pydantic_ai import Tool

    async def list_files() -> list[str]:
        """List every input file. Paths are relative to the workspace
        root and can be passed directly to ``read_file``."""
        return ctx.workspace_files()

    async def read_file(path: str) -> str:
        """Read a workspace file and return its full text content. Use
        ``list_files`` first to learn the available paths. Binary files
        return a placeholder rather than raw bytes — inspect those via
        the Python tool when one is available."""
        try:
            return ctx.read_workspace(path)
        except FileNotFoundError:
            return f"ERROR: file not found: {path}"
        except UnicodeDecodeError:
            try:
                size = len(ctx.read_workspace_bytes(path))
            except OSError:
                size = 0
            return f"BINARY ({size} bytes) — read via the Python tool to inspect."
        except OSError as e:
            return f"ERROR: could not read {path}: {e}"

    return [Tool(list_files), Tool(read_file)]


def files_context_block(
    ctx: "WasmContext",
    paths: Optional[list[str]] = None,
) -> tuple[str, list]:
    """Build a ``(system_prompt_suffix, tools)`` pair for the file context.

    Under ``INLINE_FILE_THRESHOLD`` files, everything is inlined into the
    prompt and no tools are returned. At or above the threshold, only a
    listing goes into the prompt and ``read_file`` / ``list_files`` are
    returned as tools.
    """
    paths = paths if paths is not None else ctx.workspace_files()
    if not paths:
        return "", []
    if len(paths) < INLINE_FILE_THRESHOLD:
        return (
            "\n\n## Input files (inline)\n\n" + preview_workspace_files(ctx, paths),
            [],
        )
    listing = "\n".join(f"- `{p}`" for p in paths)
    return (
        f"\n\n## Input files ({len(paths)})\n\n{listing}\n\n"
        "Use `list_files` / `read_file` to inspect contents as needed.",
        make_file_tools(ctx),
    )


def group_inputs_by_cell(ctx: "WasmContext") -> list[tuple[str, list[str]]]:
    """Split workspace files by input cell.

    Returns ``[(label, [relpath, ...])]``. For a single input (files at
    the workspace root) returns one entry with label ``"input"``. For
    multi-input hydration (``inputs/NN_slug/``) each top-level subfolder
    under ``inputs/`` becomes one group."""
    all_paths = ctx.workspace_files()
    inputs_prefix = "inputs/"
    under_inputs = [p for p in all_paths if p.startswith(inputs_prefix)]
    if not under_inputs:
        return [("input", all_paths)] if all_paths else []

    groups: dict[str, list[str]] = {}
    for p in under_inputs:
        rest = p[len(inputs_prefix):]
        label, _, _ = rest.partition("/")
        groups.setdefault(label, []).append(p)
    return [(label, sorted(paths)) for label, paths in sorted(groups.items())]


__all__ = [
    "PROVIDER_BASE_URLS",
    "PROVIDER_KEY_ENV",
    "INLINE_FILE_THRESHOLD",
    "ensure_pydantic_ai",
    "resolve_api_key",
    "build_agent",
    "preview_workspace_files",
    "make_file_tools",
    "files_context_block",
    "group_inputs_by_cell",
]
