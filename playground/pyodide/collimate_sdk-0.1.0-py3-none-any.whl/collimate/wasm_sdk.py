# SPDX-License-Identifier: Apache-2.0
"""Internal host-bridge types for wasm generator dispatch.

Generators do **not** import this module — the public runtime API is
the top-level ``gen`` package (see :mod:`collimate.wasm`). This module
lives here purely as the boundary between the wasm runner (host) and
the singleton state in :mod:`collimate.wasm`:

  * :class:`WasmContext` — the bag of inputs the runner constructs and
    passes to ``gen._set_context()`` before invoking ``run()``.
  * :class:`Host` — Protocol the runner implements; the only thing
    the singleton calls into when the generator emits state.
  * :class:`KeyRequestCancelled` — exception the runner raises on user
    cancel; ``gen.api_key`` / ``gen.secret`` translate it to
    :class:`gen.Cancelled`.
"""
from dataclasses import dataclass, field
from typing import Optional
import json
import os

# Host protocol + Message live in the runtime-neutral host_protocol
# module so native + wasm backends can import the same shapes.
from collimate.host_protocol import Host, Message  # noqa: F401


# ---------------------------------------------------------------------------
# Signals
# ---------------------------------------------------------------------------


class KeyRequestCancelled(Exception):
    """Raised by :meth:`WasmContext.get_key` when the user pressed
    Cancel on the in-cell key-request modal.

    The wasm runner catches this and finalises the run cleanly (status
    ``stopped``). Generators reach this through ``gen.api_key`` /
    ``gen.secret``, which translate it to :class:`gen.Cancelled`.
    """

    def __init__(self, key_name: str):
        super().__init__(f"key request for {key_name!r} cancelled by user")
        self.key_name = key_name


# ---------------------------------------------------------------------------
# WasmContext — the one argument a wasm generator's run() takes.
# ---------------------------------------------------------------------------

@dataclass
class WasmContext:
    """Inputs the host provides when invoking a wasm generator.

    ``_host`` is an internal slot the dispatcher fills before invoking
    ``run()``. Generators never set or inspect it directly — use the
    public methods (``emit_partial``, ``cancelled``, ``push_log``)."""
    workspace: str
    params: dict
    channel: str
    run_id: str
    # Primary user prompt — the single free-text input the user typed in
    # the picker modal / quick palette / pinned from a .md file. Same
    # contract as the native ``gen.prompt`` field: empty string when no
    # prompt was provided. Chat-style wasm generators append this as a
    # user message; non-chat generators use it as primary instruction.
    prompt: str = ""
    config_files: dict[str, str] = field(default_factory=dict)
    messages: list[Message] = field(default_factory=list)
    placeholder_cell_id: Optional[str] = None
    # Invocation type — one of ``"modify" | "create"`` — is the mode the
    # user picked when invoking this generator. Manifests declare a ``type``
    # array of every mode they support; the host picks one and stores it
    # here so the entrypoint can branch via ``gen.invocation_type``. Empty
    # string means the host didn't set one (legacy / dev path).
    invocation_type: str = ""
    _host: Optional[Host] = None

    # ── Workspace helpers ─────────────────────────────────────────────

    def read_workspace(self, relpath: str) -> str:
        """Read a file from the hydrated workspace. Raises FileNotFoundError
        if the path doesn't exist, ``UnicodeDecodeError`` on binary content
        — use :meth:`read_workspace_bytes` or :meth:`read_workspace_any`
        when the file may be binary."""
        with open(os.path.join(self.workspace, relpath), "r", encoding="utf-8") as f:
            return f.read()

    def read_workspace_bytes(self, relpath: str) -> bytes:
        """Read a workspace file as raw bytes. Use for binary inputs
        (PNG plots, archives, …) that won't round-trip through utf-8."""
        with open(os.path.join(self.workspace, relpath), "rb") as f:
            return f.read()

    def read_workspace_any(self, relpath: str) -> "str | bytes":
        """Read text if the file decodes as utf-8, otherwise raw bytes.

        The default reader for code paths that don't know whether a
        given file is text or binary — e.g. the singleton's auto-staging
        and the ``input_files``/``input_groups`` helpers. Generators
        that need a specific representation should call the typed
        variants directly.
        """
        try:
            return self.read_workspace(relpath)
        except UnicodeDecodeError:
            return self.read_workspace_bytes(relpath)

    def workspace_files(self) -> list[str]:
        """Return every file under the workspace as a list of relative paths.
        Skips hidden dirs (dot-prefixed) and __pycache__."""
        results: list[str] = []
        for root, dirs, files in os.walk(self.workspace):
            dirs[:] = [d for d in dirs if not d.startswith(".") and d != "__pycache__"]
            for f in files:
                if f.startswith("."):
                    continue
                abs_p = os.path.join(root, f)
                rel = os.path.relpath(abs_p, self.workspace).replace(os.sep, "/")
                results.append(rel)
        return results

    # ── Config (draft file) helpers ───────────────────────────────────

    def config(self, filename: str) -> str:
        """Raw content of a draft file named in the manifest's ``draft_files``.
        Returns '' if the file wasn't seeded."""
        return self.config_files.get(filename, "")

    def config_yaml(self, filename: str) -> dict:
        """Parse a config file as YAML. For ``.set_yaml`` schema_form files,
        merges each field's ``default`` with the ``values`` block (values
        override defaults). Matches native SDK's
        ``gen.config.read_schema_values`` behavior so a generator can be
        written identically for both backends."""
        import yaml
        text = self.config(filename)
        if not text.strip():
            return {}
        try:
            parsed = yaml.safe_load(text)
        except yaml.YAMLError:
            return {}
        if not isinstance(parsed, dict):
            return {}
        values = parsed.get("values") if isinstance(parsed.get("values"), dict) else {}
        fields = parsed.get("fields") if isinstance(parsed.get("fields"), list) else []
        if fields or values:
            out: dict = {}
            for f in fields:
                if isinstance(f, dict) and isinstance(f.get("key"), str) and "default" in f:
                    out[f["key"]] = f["default"]
            out.update(values)
            return out
        return parsed

    def config_json(self, filename: str) -> dict:
        """Parse a config file as JSON."""
        text = self.config(filename)
        if not text.strip():
            return {}
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return {}

    # ── Live-update API ───────────────────────────────────────────────

    async def emit_partial(
        self,
        *,
        files: Optional[dict[str, "str | bytes"]] = None,
        cell_name: Optional[str] = None,
        summary: Optional[str] = None,
        pinned: Optional[str] = None,
    ) -> None:
        """Push an intermediate update to the cell.

        Overwrites the cell's current files with the given dict (only the
        keys you pass — existing files not in ``files`` are preserved).
        Values may be ``str`` (utf-8 text) or ``bytes`` (binary artifacts
        like images); the host base64-encodes the bytes path on the wire.
        Updates name / summary / pinned if supplied.

        Each call writes to the DB, refreshes in-memory channel state, and
        flushes persistence so a concurrent UI poll sees the progress.
        Safe to call hundreds of times per run — the host debounces the
        IDBFS flush.

        No-op when called outside a real run (e.g. during tests that
        instantiate WasmContext directly)."""
        if self._host is None:
            return
        await self._host.emit_partial(
            files=files,
            cell_name=cell_name,
            summary=summary,
            pinned=pinned,
        )

    @property
    def cancelled(self) -> bool:
        """True if the user clicked Stop on this run. Generators should
        check this cooperatively between chunks of work. Returns False
        when called outside a real run."""
        return bool(self._host and self._host.is_cancelled())

    def push_log(self, line: str) -> None:
        """Append a line to the run's log buffer (visible to the user in
        the run events panel). No-op outside a real run."""
        if self._host is not None:
            self._host.push_log(line)

    async def get_key(
        self,
        name: str,
        description: str = "",
        force: bool = False,
    ) -> str:
        """Resolve a user-held secret, prompting via the in-cell modal
        if needed. Fast path: ``os.environ[name]`` when set and not
        ``force``. Slow path: host pops the modal; the user submits;
        ``/key_continue`` persists the value to the keystore, mirrors
        it into ``os.environ``, and unblocks this coroutine.

        Raises :class:`KeyRequestCancelled` on user cancel.
        """
        if self._host is None:
            return ""
        return await self._host.request_key(
            key_name=name,
            description=description,
            force=force,
        )

    def set_phase(self, phase: str, message: str = "") -> None:
        """Set the run's lifecycle phase. Used by ``gen.phase(name, msg)``."""
        if self._host is not None and hasattr(self._host, "set_phase"):
            self._host.set_phase(phase, message)

    def set_status(self, message: str) -> None:
        """Update the current phase's message. Used by ``gen.status(msg)``."""
        if self._host is None:
            return
        self._host.set_status(message)

    async def create_side_cell(
        self,
        *,
        name: Optional[str] = None,
        summary: Optional[str] = None,
        pinned: Optional[str] = None,
        files: Optional[dict[str, "str | bytes"]] = None,
    ) -> str:
        """Create a new cell below in the right-side stack. Used by
        ``gen.create_stack_cell(...)``. ``files`` values may be ``str``
        or ``bytes`` (binary artifacts go through the host's base64
        encoding path)."""
        if self._host is None:
            return ""
        return await self._host.create_side_cell(
            name=name,
            summary=summary,
            pinned=pinned,
            files=files,
        )


__all__ = [
    "KeyRequestCancelled",
    "Message",
    "WasmContext",
]
