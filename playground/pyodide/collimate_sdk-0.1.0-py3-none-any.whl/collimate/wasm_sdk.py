"""Pyodide-safe subset of the Collimate generator SDK.

The full SDK (collimate.sdk) uses TCP IPC between a host process and a
generator subprocess. Pyodide has no subprocess support, so we can't ship
that model in-browser. Instead, a **wasm generator** is a plain async
function — no Generator object, no IPC — that the host calls directly in
the same event loop.

BASIC CONTRACT (one module per generator, at ``generators-wasm/<id>/``):

    # manifest.gen_yaml
    id: "my-gen"
    runtime: "wasm"                   # required
    entrypoint: "my_gen.py"
    execution_mode: "oneshot"

    # my_gen.py
    from collimate.wasm_sdk import WasmContext, WasmResult

    async def run(ctx: WasmContext) -> WasmResult:
        return WasmResult(files={"out.md": "hi"}, cell_name="Demo")

SUPPORTED OPERATIONS:

- Read hydrated workspace via ``ctx.read_workspace(path)`` /
  ``ctx.workspace_files()``.
- Read draft/config files via ``ctx.config(name)`` / ``ctx.config_yaml(name)``
  / ``ctx.config_json(name)``. Schema_form ``.set_yaml`` values are
  auto-merged with defaults (matches native ``gen.config.read_schema_values``).
- Read prior chat messages via ``ctx.messages``.

- **Live / streaming updates** (new) — during ``run()``, the generator may
  call ``await ctx.emit_partial(files=..., summary=..., chat_messages=...)``
  any number of times. Each call writes to the DB + refreshes the in-memory
  state + flushes IDBFS, so the UI can poll and render incrementally.

- **Cooperative cancellation** — ``ctx.cancelled`` flips to ``True`` when
  the user clicks Stop. Long-running generators should check it between
  chunks and return early when observed.

- **Run logs** — ``ctx.push_log(line)`` appends a line to the run's log
  buffer (visible in the run events panel).

EXPLICITLY NOT SUPPORTED (raises or is unavailable in wasm):

- Docker / sandbox containers  (``gen.chat.start_session(image=...)``)
- Subprocesses / ``uv run``
- ``execution_mode: daemon``
- Multi-cell output (one call = one cell; chain generators for more)

Generators authored against this API declare ``runtime: wasm`` so the
host knows to dispatch via in-process calls.

LIVE-CHAT PATTERN:

    async def run(ctx):
        settings = ctx.config_yaml("settings.set_yaml")
        accum = ""
        async for chunk in call_llm_stream(settings, ctx.messages):
            if ctx.cancelled:
                accum += "\\n\\n*(stopped)*"
                break
            accum += chunk
            await ctx.emit_partial(
                files={"response.md": accum},
                summary=(accum.splitlines()[0] if accum else "")[:120],
            )
        return WasmResult(
            files={"response.md": accum},
            cell_name="Chat response",
            summary=(accum.splitlines()[0] if accum else "")[:120],
            chat_messages=ctx.messages + [Message(role="assistant", content=accum)],
        )
"""
from dataclasses import dataclass, field
from typing import Optional, Protocol, runtime_checkable
import json
import os


# ---------------------------------------------------------------------------
# Public dataclasses
# ---------------------------------------------------------------------------

@dataclass
class Message:
    role: str                # "user" | "assistant" | "system"
    content: str
    timestamp: str = ""

    def to_dict(self) -> dict:
        return {"role": self.role, "content": self.content, "timestamp": self.timestamp}


@dataclass
class WasmResult:
    """What a wasm generator returns — describes one output cell.
    The host translates this into a DB cell + CAS-stored file blobs.

    When ``emit_partial`` was called during the run, ``WasmResult`` is the
    final commit: the host treats ``files`` as the authoritative final
    state (superseding anything sent via ``emit_partial``)."""
    files: dict[str, str] = field(default_factory=dict)
    cell_name: str = ""
    summary: str = ""
    chat_messages: list[Message] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Host protocol — implemented by the wasm dispatcher (ProcessManager under
# pyodide). Generators never see this type directly; WasmContext delegates
# to it internally.
# ---------------------------------------------------------------------------

@runtime_checkable
class WasmHost(Protocol):
    async def emit_partial(
        self,
        *,
        files: Optional[dict[str, str]] = None,
        cell_name: Optional[str] = None,
        summary: Optional[str] = None,
        chat_messages: Optional[list[Message]] = None,
    ) -> None: ...

    def is_cancelled(self) -> bool: ...

    def push_log(self, line: str) -> None: ...

    def poll_user_message(self) -> Optional[Message]: ...


# ---------------------------------------------------------------------------
# WasmContext — the one argument a wasm generator's run() takes.
# ---------------------------------------------------------------------------

@dataclass
class WasmContext:
    """Inputs the host provides when invoking a wasm generator.

    ``_host`` is an internal slot the dispatcher fills before invoking
    ``run()``. Generators never set or inspect it directly — use the
    public methods (``emit_partial``, ``cancelled``, ``push_log``)."""
    workspace: str
    params: dict
    channel: str
    run_id: str
    config_files: dict[str, str] = field(default_factory=dict)
    messages: list[Message] = field(default_factory=list)
    placeholder_cell_id: Optional[str] = None
    _host: Optional[WasmHost] = None

    # ── Workspace helpers ─────────────────────────────────────────────

    def read_workspace(self, relpath: str) -> str:
        """Read a file from the hydrated workspace. Raises FileNotFoundError
        if the path doesn't exist."""
        with open(os.path.join(self.workspace, relpath), "r", encoding="utf-8") as f:
            return f.read()

    def workspace_files(self) -> list[str]:
        """Return every file under the workspace as a list of relative paths.
        Skips hidden dirs (dot-prefixed) and __pycache__."""
        results: list[str] = []
        for root, dirs, files in os.walk(self.workspace):
            dirs[:] = [d for d in dirs if not d.startswith(".") and d != "__pycache__"]
            for f in files:
                if f.startswith("."):
                    continue
                abs_p = os.path.join(root, f)
                rel = os.path.relpath(abs_p, self.workspace).replace(os.sep, "/")
                results.append(rel)
        return results

    # ── Config (draft file) helpers ───────────────────────────────────

    def config(self, filename: str) -> str:
        """Raw content of a draft file named in the manifest's ``draft_files``.
        Returns '' if the file wasn't seeded."""
        return self.config_files.get(filename, "")

    def config_yaml(self, filename: str) -> dict:
        """Parse a config file as YAML. For ``.set_yaml`` schema_form files,
        merges each field's ``default`` with the ``values`` block (values
        override defaults). Matches native SDK's
        ``gen.config.read_schema_values`` behavior so a generator can be
        written identically for both backends."""
        import yaml
        text = self.config(filename)
        if not text.strip():
            return {}
        try:
            parsed = yaml.safe_load(text)
        except yaml.YAMLError:
            return {}
        if not isinstance(parsed, dict):
            return {}
        values = parsed.get("values") if isinstance(parsed.get("values"), dict) else {}
        fields = parsed.get("fields") if isinstance(parsed.get("fields"), list) else []
        if fields or values:
            out: dict = {}
            for f in fields:
                if isinstance(f, dict) and isinstance(f.get("key"), str) and "default" in f:
                    out[f["key"]] = f["default"]
            out.update(values)
            return out
        return parsed

    def config_json(self, filename: str) -> dict:
        """Parse a config file as JSON."""
        text = self.config(filename)
        if not text.strip():
            return {}
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return {}

    # ── Live-update API ───────────────────────────────────────────────

    async def emit_partial(
        self,
        *,
        files: Optional[dict[str, str]] = None,
        cell_name: Optional[str] = None,
        summary: Optional[str] = None,
        chat_messages: Optional[list[Message]] = None,
    ) -> None:
        """Push an intermediate update to the cell.

        Overwrites the cell's current files with the given dict (only the
        keys you pass — existing files not in ``files`` are preserved).
        Updates name / summary if supplied. Appends ``chat_messages`` to
        the cell's ``.colreserved/.collimate_messages.json``.

        Each call writes to the DB, refreshes in-memory channel state, and
        flushes persistence so a concurrent UI poll sees the progress.
        Safe to call hundreds of times per run — the host debounces the
        IDBFS flush.

        No-op when called outside a real run (e.g. during tests that
        instantiate WasmContext directly)."""
        if self._host is None:
            return
        await self._host.emit_partial(
            files=files,
            cell_name=cell_name,
            summary=summary,
            chat_messages=chat_messages,
        )

    @property
    def cancelled(self) -> bool:
        """True if the user clicked Stop on this run. Generators should
        check this cooperatively between chunks of work. Returns False
        when called outside a real run."""
        return bool(self._host and self._host.is_cancelled())

    def push_log(self, line: str) -> None:
        """Append a line to the run's log buffer (visible to the user in
        the run events panel). No-op outside a real run."""
        if self._host is not None:
            self._host.push_log(line)

    def poll_user_message(self) -> Optional[Message]:
        """Return the next queued user message, or ``None`` if the queue
        is empty.

        Messages land in the queue via ``POST /api/channels/{c}/cells/{id}/chat/push_message``
        — the frontend calls this when the user types while a run is
        streaming (mid-turn redirect). Call this between chunks of work
        in your ``run()`` loop; append returned messages to your
        ``chat_messages`` so they carry forward into the next turn.

        No-op (returns ``None``) when called outside a real run."""
        if self._host is None:
            return None
        return self._host.poll_user_message()

    def secret(self, name: str, default: str = "") -> str:
        """Read a secret from the environment.

        On native this reads from ``os.environ`` (populated at startup by
        the OS-keychain-backed keystore). On wasm the same ``os.environ``
        is populated from the IDBFS-backed keystore, so the same lookup
        works — set once in Settings → Keys, read by every generator.

        Returns ``default`` if the key is unset. Useful pattern:

            api_key = ctx.secret("GEMINI_API_KEY") or \\
                      ctx.config_yaml("settings.set_yaml").get("api_key", "")
        """
        import os
        return os.environ.get(name) or default


__all__ = [
    "Message",
    "WasmContext",
    "WasmResult",
    "WasmHost",
]
