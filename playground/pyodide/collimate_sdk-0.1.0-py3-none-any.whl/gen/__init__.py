# SPDX-License-Identifier: Apache-2.0
"""Top-level ``gen`` package — public runtime API for Collimate generators.

A generator imports this and uses ``gen.*`` to read inputs, stage
output files, push cells, request user input, resolve API keys, and
reach OS-level helpers (subprocesses, ports, terminals, …)::

    import gen

    async def run():
        cfg = gen.config("pydantic-config.set_yaml")
        agent = await gen.agent(
            system_prompt=cfg.get("system_prompt", ""),
            tools=gen.file_tools(),
        )

        async def on_turn(turn):
            gen.history.append("user", turn.user_msg)
            reply = await gen.agent_chat_turn(turn, agent)
            gen.history.append("assistant", reply)
            await gen.update(summary=turn.user_msg[:80])

        await gen.serve_chat(on_turn)

    if __name__ == "__main__":
        gen.main(run)

This is a runtime-aware re-export shim:

  * Under **pyodide** (WASM generators) → :mod:`collimate.wasm`.
  * Otherwise (native generators) → :mod:`collimate.native`.

Both modules ship in the same ``collimate-sdk`` PyPI wheel. WASM and
native expose deliberately different surfaces — WASM cannot offer
subprocesses, ports, terminals, raw filesystem access, or non-CORS-safe
LLM providers, and tries to make those impossibilities loud rather than
silent. Calling a native-only function under WASM is an
``AttributeError`` (the symbol just isn't present), not a crash deep
inside a stub.
"""
import os
import sys


def _detect_runtime() -> str:
    explicit = os.environ.get("COLLIMATE_RUNTIME", "").strip().lower()
    if explicit in ("wasm", "native"):
        return explicit
    return "wasm" if sys.platform == "emscripten" else "native"


_RUNTIME = _detect_runtime()

if _RUNTIME == "wasm":
    from collimate.wasm import *  # noqa: F401,F403
    from collimate.wasm import __all__  # noqa: F401

    def __getattr__(name):
        from collimate import wasm
        return getattr(wasm, name)
else:
    from collimate.native import *  # noqa: F401,F403
    from collimate.native import __all__  # noqa: F401

    def __getattr__(name):
        from collimate import native
        return getattr(native, name)
